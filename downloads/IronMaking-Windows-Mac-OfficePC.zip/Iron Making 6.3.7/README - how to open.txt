IRON MAKING 6.3.7 - Windows / Mac / office PC (no install)
==========================================================

1. Unzip this folder anywhere (Desktop, Documents or a pen drive). Keep the "www" folder next to this file.
2. Double-click  "Open Iron Making.html".  It opens in Chrome or Microsoft Edge (Safari on Mac also works).
   Tip: right-click > Open with > Google Chrome, if another program opens it.
3. Sign in: Continue with Google, Continue with email (6-digit code), or your login ID.
4. The computer version opens for logins the admin has allowed. If you see "Locked by the admin",
   tap "Request access" and wait for the admin's email, then tap Try again.

Bookmark the page (Ctrl+D on Windows, Cmd+D on Mac) to open it quickly next time.
Internet is needed to sign in and once a day for the licence check; the tools work offline.

Iron Making by Niteen Kumar
