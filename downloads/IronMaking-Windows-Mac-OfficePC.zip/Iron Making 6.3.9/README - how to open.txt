IRON MAKING 6.3.9 - Mac / Windows / office PC (no install)
==========================================================

1. Unzip this folder anywhere (Desktop, Documents or a pen drive). Keep all the folders next to this file.
2. Double-click  "Open Iron Making.html".  It opens in Chrome or Microsoft Edge (Safari on Mac also works).
   Tip: right-click > Open with > Google Chrome, if another program opens it.
3. New user: tap "Create an account" (name, mobile, email, company), type the 6-digit OTP sent to your email,
   then choose a login ID and password. Already registered: "I already have a login".
4. The computer version opens for logins the admin has allowed. If you see "Locked by the admin",
   tap "Request access" and wait for the admin's email, then tap Try again.

Bookmark the page (Ctrl+D on Windows, Cmd+D on Mac) to open it quickly next time.
Internet is needed to sign in and once a day for the licence check; the tools work offline.
Every screen has a "Report" button: PDF, report file or Excel tables, saved to your Downloads.

On Windows you can instead run IronMaking-6.3.9-Windows-Setup.exe for a Start menu / desktop app.

Iron Making by Niteen Kumar
