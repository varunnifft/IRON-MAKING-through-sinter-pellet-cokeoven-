import { c as e } from "./transform-B2AI7qp--hg0kwf7R.js";
import { D as t, G as n, N as r, Q as i, T as a, a3 as o, a4 as s, aE as c, aF as l, aH as u, aI as d, aJ as f, aK as p, aW as m, aZ as h, ae as g, af as _, al as v, am as y, ar as b, at as x, b6 as S, b7 as C, b9 as w, bD as T, bL as E, bN as D, bR as O, bS as k, bT as ee, bU as te, be as ne, bf as re, bl as ie, bm as ae, bq as oe, bu as se, c as A, h as ce, j as le, n as ue } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
import { t as de } from "./chunk-5VM5RSS4-B7DhKFUG-BwybK4B6.js";
import { t as fe } from "./channel-CvOKZlC4-n3NLqOCr.js";
//#region ../react/build/blockDiagram-I7D4REHJ-DqPs4wzi.js
function pe(e) {
	return Array.isArray(e);
}
function me(e) {
	if (m(e)) return e;
	let t = x(e);
	if (!he(e)) return {};
	if (pe(e)) {
		let t = Array.from(e);
		return e.length > 0 && typeof e[0] == "string" && Object.hasOwn(e, "index") && (t.index = e.index, t.input = e.input), t;
	}
	if (h(e)) {
		let t = e, n = t.constructor;
		return new n(t.buffer, t.byteOffset, t.length);
	}
	if (t === "[object ArrayBuffer]") return new ArrayBuffer(e.byteLength);
	if (t === "[object DataView]") {
		let t = e, n = t.buffer, r = t.byteOffset, i = t.byteLength, a = new ArrayBuffer(i), o = new Uint8Array(n, r, i);
		return new Uint8Array(a).set(o), new DataView(a);
	}
	if (t === "[object Boolean]" || t === "[object Number]" || t === "[object String]") {
		let n = e.constructor, r = new n(e.valueOf());
		return t === "[object String]" ? _e(r, e) : j(r, e), r;
	}
	if (t === "[object Date]") return new Date(Number(e));
	if (t === "[object RegExp]") {
		let t = e, n = new RegExp(t.source, t.flags);
		return n.lastIndex = t.lastIndex, n;
	}
	if (t === "[object Symbol]") return Object(Symbol.prototype.valueOf.call(e));
	if (t === "[object Map]") {
		let t = e, n = /* @__PURE__ */ new Map();
		return t.forEach((e, t) => {
			n.set(t, e);
		}), n;
	}
	if (t === "[object Set]") {
		let t = e, n = /* @__PURE__ */ new Set();
		return t.forEach((e) => {
			n.add(e);
		}), n;
	}
	if (t === "[object Arguments]") {
		let t = e, n = {};
		return j(n, t), n.length = t.length, n[Symbol.iterator] = t[Symbol.iterator], n;
	}
	let n = {};
	return ve(n, e), j(n, e), ge(n, e), n;
}
function he(e) {
	switch (x(e)) {
		case ce:
		case ue:
		case le:
		case o:
		case t:
		case s:
		case g:
		case _:
		case p:
		case d:
		case f:
		case C:
		case ne:
		case re:
		case oe:
		case T:
		case E:
		case D:
		case ee:
		case te:
		case O:
		case k: return !0;
		default: return !1;
	}
}
function j(e, t) {
	for (let n in t) Object.hasOwn(t, n) && (e[n] = t[n]);
}
function ge(e, t) {
	let n = Object.getOwnPropertySymbols(t);
	for (let r = 0; r < n.length; r++) {
		let i = n[r];
		Object.prototype.propertyIsEnumerable.call(t, i) && (e[i] = t[i]);
	}
}
function _e(e, t) {
	let n = t.valueOf().length;
	for (let r in t) Object.hasOwn(t, r) && (Number.isNaN(Number(r)) || Number(r) >= n) && (e[r] = t[r]);
}
function ve(e, t) {
	let n = Object.getPrototypeOf(t);
	n !== null && typeof t.constructor == "function" && Object.setPrototypeOf(e, n);
}
var M = function() {
	var e = /* @__PURE__ */ A(function(e, t, n, r) {
		for (n ||= {}, r = e.length; r--; n[e[r]] = t);
		return n;
	}, "o"), t = [1, 15], n = [1, 7], r = [1, 13], i = [1, 14], a = [1, 19], o = [1, 16], s = [1, 17], c = [1, 18], l = [8, 30], u = [
		8,
		10,
		21,
		28,
		29,
		30,
		31,
		39,
		43,
		46
	], d = [1, 23], f = [1, 24], p = [
		8,
		10,
		15,
		16,
		21,
		28,
		29,
		30,
		31,
		39,
		43,
		46
	], m = [
		8,
		10,
		15,
		16,
		21,
		27,
		28,
		29,
		30,
		31,
		39,
		43,
		46
	], h = [1, 49], g = {
		trace: /* @__PURE__ */ A(function() {}, "trace"),
		yy: {},
		symbols_: {
			error: 2,
			spaceLines: 3,
			SPACELINE: 4,
			NL: 5,
			separator: 6,
			SPACE: 7,
			EOF: 8,
			start: 9,
			BLOCK_DIAGRAM_KEY: 10,
			document: 11,
			stop: 12,
			statement: 13,
			link: 14,
			LINK: 15,
			START_LINK: 16,
			LINK_LABEL: 17,
			STR: 18,
			nodeStatement: 19,
			columnsStatement: 20,
			SPACE_BLOCK: 21,
			blockStatement: 22,
			classDefStatement: 23,
			cssClassStatement: 24,
			styleStatement: 25,
			node: 26,
			SIZE: 27,
			COLUMNS: 28,
			"id-block": 29,
			end: 30,
			NODE_ID: 31,
			nodeShapeNLabel: 32,
			dirList: 33,
			DIR: 34,
			NODE_DSTART: 35,
			NODE_DEND: 36,
			BLOCK_ARROW_START: 37,
			BLOCK_ARROW_END: 38,
			classDef: 39,
			CLASSDEF_ID: 40,
			CLASSDEF_STYLEOPTS: 41,
			DEFAULT: 42,
			class: 43,
			CLASSENTITY_IDS: 44,
			STYLECLASS: 45,
			style: 46,
			STYLE_ENTITY_IDS: 47,
			STYLE_DEFINITION_DATA: 48,
			$accept: 0,
			$end: 1
		},
		terminals_: {
			2: "error",
			4: "SPACELINE",
			5: "NL",
			7: "SPACE",
			8: "EOF",
			10: "BLOCK_DIAGRAM_KEY",
			15: "LINK",
			16: "START_LINK",
			17: "LINK_LABEL",
			18: "STR",
			21: "SPACE_BLOCK",
			27: "SIZE",
			28: "COLUMNS",
			29: "id-block",
			30: "end",
			31: "NODE_ID",
			34: "DIR",
			35: "NODE_DSTART",
			36: "NODE_DEND",
			37: "BLOCK_ARROW_START",
			38: "BLOCK_ARROW_END",
			39: "classDef",
			40: "CLASSDEF_ID",
			41: "CLASSDEF_STYLEOPTS",
			42: "DEFAULT",
			43: "class",
			44: "CLASSENTITY_IDS",
			45: "STYLECLASS",
			46: "style",
			47: "STYLE_ENTITY_IDS",
			48: "STYLE_DEFINITION_DATA"
		},
		productions_: [
			0,
			[3, 1],
			[3, 2],
			[3, 2],
			[6, 1],
			[6, 1],
			[6, 1],
			[9, 3],
			[12, 1],
			[12, 1],
			[12, 2],
			[12, 2],
			[11, 1],
			[11, 2],
			[14, 1],
			[14, 4],
			[13, 1],
			[13, 1],
			[13, 1],
			[13, 1],
			[13, 1],
			[13, 1],
			[13, 1],
			[19, 3],
			[19, 2],
			[19, 1],
			[20, 1],
			[22, 4],
			[22, 3],
			[26, 1],
			[26, 2],
			[33, 1],
			[33, 2],
			[32, 3],
			[32, 4],
			[23, 3],
			[23, 3],
			[24, 3],
			[25, 3]
		],
		performAction: /* @__PURE__ */ A(function(e, t, n, r, i, a, o) {
			var s = a.length - 1;
			switch (i) {
				case 4:
					r.getLogger().debug("Rule: separator (NL) ");
					break;
				case 5:
					r.getLogger().debug("Rule: separator (Space) ");
					break;
				case 6:
					r.getLogger().debug("Rule: separator (EOF) ");
					break;
				case 7:
					r.getLogger().debug("Rule: hierarchy: ", a[s - 1]), r.setHierarchy(a[s - 1]);
					break;
				case 8:
					r.getLogger().debug("Stop NL ");
					break;
				case 9:
					r.getLogger().debug("Stop EOF ");
					break;
				case 10:
					r.getLogger().debug("Stop NL2 ");
					break;
				case 11:
					r.getLogger().debug("Stop EOF2 ");
					break;
				case 12:
					r.getLogger().debug("Rule: statement: ", a[s]), this.$ = typeof a[s].length == "number" ? a[s] : [a[s]];
					break;
				case 13:
					r.getLogger().debug("Rule: statement #2: ", a[s - 1]), this.$ = [a[s - 1]].concat(a[s]);
					break;
				case 14:
					r.getLogger().debug("Rule: link: ", a[s], e), this.$ = {
						edgeTypeStr: a[s],
						label: ""
					};
					break;
				case 15:
					r.getLogger().debug("Rule: LABEL link: ", a[s - 3], a[s - 1], a[s]), this.$ = {
						edgeTypeStr: a[s],
						label: a[s - 1]
					};
					break;
				case 18:
					let t = parseInt(a[s]), n = r.generateId();
					this.$ = {
						id: n,
						type: "space",
						label: "",
						width: t,
						children: []
					};
					break;
				case 23:
					r.getLogger().debug("Rule: (nodeStatement link node) ", a[s - 2], a[s - 1], a[s], " typestr: ", a[s - 1].edgeTypeStr);
					let i = r.edgeStrToEdgeData(a[s - 1].edgeTypeStr), o = r.edgeStrToEdgeStartData(a[s - 1].edgeTypeStr), c = r.edgeStrToThickness(a[s - 1].edgeTypeStr), l = r.edgeStrToPattern(a[s - 1].edgeTypeStr);
					this.$ = [
						{
							id: a[s - 2].id,
							label: a[s - 2].label,
							type: a[s - 2].type,
							directions: a[s - 2].directions
						},
						{
							id: a[s - 2].id + "-" + a[s].id,
							start: a[s - 2].id,
							end: a[s].id,
							label: a[s - 1].label,
							type: "edge",
							thickness: c,
							pattern: l,
							directions: a[s].directions,
							arrowTypeEnd: i,
							arrowTypeStart: o
						},
						{
							id: a[s].id,
							label: a[s].label,
							type: r.typeStr2Type(a[s].typeStr),
							directions: a[s].directions
						}
					];
					break;
				case 24:
					r.getLogger().debug("Rule: nodeStatement (abc88 node size) ", a[s - 1], a[s]), this.$ = {
						id: a[s - 1].id,
						label: a[s - 1].label,
						type: r.typeStr2Type(a[s - 1].typeStr),
						directions: a[s - 1].directions,
						widthInColumns: parseInt(a[s], 10)
					};
					break;
				case 25:
					r.getLogger().debug("Rule: nodeStatement (node) ", a[s]), this.$ = {
						id: a[s].id,
						label: a[s].label,
						type: r.typeStr2Type(a[s].typeStr),
						directions: a[s].directions,
						widthInColumns: 1
					};
					break;
				case 26:
					r.getLogger().debug("APA123", this ? this : "na"), r.getLogger().debug("COLUMNS: ", a[s]), this.$ = {
						type: "column-setting",
						columns: a[s] === "auto" ? -1 : parseInt(a[s])
					};
					break;
				case 27:
					r.getLogger().debug("Rule: id-block statement : ", a[s - 2], a[s - 1]), r.generateId(), this.$ = {
						...a[s - 2],
						type: "composite",
						children: a[s - 1]
					};
					break;
				case 28:
					r.getLogger().debug("Rule: blockStatement : ", a[s - 2], a[s - 1], a[s]);
					let u = r.generateId();
					this.$ = {
						id: u,
						type: "composite",
						label: "",
						children: a[s - 1]
					};
					break;
				case 29:
					r.getLogger().debug("Rule: node (NODE_ID separator): ", a[s]), this.$ = { id: a[s] };
					break;
				case 30:
					r.getLogger().debug("Rule: node (NODE_ID nodeShapeNLabel separator): ", a[s - 1], a[s]), this.$ = {
						id: a[s - 1],
						label: a[s].label,
						typeStr: a[s].typeStr,
						directions: a[s].directions
					};
					break;
				case 31:
					r.getLogger().debug("Rule: dirList: ", a[s]), this.$ = [a[s]];
					break;
				case 32:
					r.getLogger().debug("Rule: dirList: ", a[s - 1], a[s]), this.$ = [a[s - 1]].concat(a[s]);
					break;
				case 33:
					r.getLogger().debug("Rule: nodeShapeNLabel: ", a[s - 2], a[s - 1], a[s]), this.$ = {
						typeStr: a[s - 2] + a[s],
						label: a[s - 1]
					};
					break;
				case 34:
					r.getLogger().debug("Rule: BLOCK_ARROW nodeShapeNLabel: ", a[s - 3], a[s - 2], " #3:", a[s - 1], a[s]), this.$ = {
						typeStr: a[s - 3] + a[s],
						label: a[s - 2],
						directions: a[s - 1]
					};
					break;
				case 35:
				case 36:
					this.$ = {
						type: "classDef",
						id: a[s - 1].trim(),
						css: a[s].trim()
					};
					break;
				case 37:
					this.$ = {
						type: "applyClass",
						id: a[s - 1].trim(),
						styleClass: a[s].trim()
					};
					break;
				case 38: this.$ = {
					type: "applyStyles",
					id: a[s - 1].trim(),
					stylesStr: a[s].trim()
				};
			}
		}, "anonymous"),
		table: [
			{
				9: 1,
				10: [1, 2]
			},
			{ 1: [3] },
			{
				10: t,
				11: 3,
				13: 4,
				19: 5,
				20: 6,
				21: n,
				22: 8,
				23: 9,
				24: 10,
				25: 11,
				26: 12,
				28: r,
				29: i,
				31: a,
				39: o,
				43: s,
				46: c
			},
			{ 8: [1, 20] },
			e(l, [2, 12], {
				13: 4,
				19: 5,
				20: 6,
				22: 8,
				23: 9,
				24: 10,
				25: 11,
				26: 12,
				11: 21,
				10: t,
				21: n,
				28: r,
				29: i,
				31: a,
				39: o,
				43: s,
				46: c
			}),
			e(u, [2, 16], {
				14: 22,
				15: d,
				16: f
			}),
			e(u, [2, 17]),
			e(u, [2, 18]),
			e(u, [2, 19]),
			e(u, [2, 20]),
			e(u, [2, 21]),
			e(u, [2, 22]),
			e(p, [2, 25], { 27: [1, 25] }),
			e(u, [2, 26]),
			{
				19: 26,
				26: 12,
				31: a
			},
			{
				10: t,
				11: 27,
				13: 4,
				19: 5,
				20: 6,
				21: n,
				22: 8,
				23: 9,
				24: 10,
				25: 11,
				26: 12,
				28: r,
				29: i,
				31: a,
				39: o,
				43: s,
				46: c
			},
			{
				40: [1, 28],
				42: [1, 29]
			},
			{ 44: [1, 30] },
			{ 47: [1, 31] },
			e(m, [2, 29], {
				32: 32,
				35: [1, 33],
				37: [1, 34]
			}),
			{ 1: [2, 7] },
			e(l, [2, 13]),
			{
				26: 35,
				31: a
			},
			{ 31: [2, 14] },
			{ 17: [1, 36] },
			e(p, [2, 24]),
			{
				10: t,
				11: 37,
				13: 4,
				14: 22,
				15: d,
				16: f,
				19: 5,
				20: 6,
				21: n,
				22: 8,
				23: 9,
				24: 10,
				25: 11,
				26: 12,
				28: r,
				29: i,
				31: a,
				39: o,
				43: s,
				46: c
			},
			{ 30: [1, 38] },
			{ 41: [1, 39] },
			{ 41: [1, 40] },
			{ 45: [1, 41] },
			{ 48: [1, 42] },
			e(m, [2, 30]),
			{ 18: [1, 43] },
			{ 18: [1, 44] },
			e(p, [2, 23]),
			{ 18: [1, 45] },
			{ 30: [1, 46] },
			e(u, [2, 28]),
			e(u, [2, 35]),
			e(u, [2, 36]),
			e(u, [2, 37]),
			e(u, [2, 38]),
			{ 36: [1, 47] },
			{
				33: 48,
				34: h
			},
			{ 15: [1, 50] },
			e(u, [2, 27]),
			e(m, [2, 33]),
			{ 38: [1, 51] },
			{
				33: 52,
				34: h,
				38: [2, 31]
			},
			{ 31: [2, 15] },
			e(m, [2, 34]),
			{ 38: [2, 32] }
		],
		defaultActions: {
			20: [2, 7],
			23: [2, 14],
			50: [2, 15],
			52: [2, 32]
		},
		parseError: /* @__PURE__ */ A(function(e, t) {
			if (t.recoverable) this.trace(e);
			else {
				var n = Error(e);
				throw n.hash = t, n;
			}
		}, "parseError"),
		parse: /* @__PURE__ */ A(function(e) {
			var t = this, n = [0], r = [], i = [null], a = [], o = this.table, s = "", c = 0, l = 0, u = 2, d = 1, f = a.slice.call(arguments, 1), p = Object.create(this.lexer), m = { yy: {} };
			for (var h in this.yy) Object.prototype.hasOwnProperty.call(this.yy, h) && (m.yy[h] = this.yy[h]);
			p.setInput(e, m.yy), m.yy.lexer = p, m.yy.parser = this, typeof p.yylloc > "u" && (p.yylloc = {});
			var g = p.yylloc;
			a.push(g);
			var _ = p.options && p.options.ranges;
			this.parseError = typeof m.yy.parseError == "function" ? m.yy.parseError : Object.getPrototypeOf(this).parseError;
			function v(e) {
				n.length -= 2 * e, i.length -= e, a.length -= e;
			}
			A(v, "popStack");
			function y() {
				var e;
				return e = r.pop() || p.lex() || d, typeof e != "number" && (e instanceof Array && (r = e, e = r.pop()), e = t.symbols_[e] || e), e;
			}
			A(y, "lex");
			for (var b, x, S, C, w = {}, T, E, D, O;;) {
				if (x = n[n.length - 1], this.defaultActions[x] ? S = this.defaultActions[x] : ((b === null || typeof b > "u") && (b = y()), S = o[x] && o[x][b]), typeof S > "u" || !S.length || !S[0]) {
					var k = "";
					for (T in O = [], o[x]) this.terminals_[T] && T > u && O.push("'" + this.terminals_[T] + "'");
					k = p.showPosition ? "Parse error on line " + (c + 1) + ":\n" + p.showPosition() + "\nExpecting " + O.join(", ") + ", got '" + (this.terminals_[b] || b) + "'" : "Parse error on line " + (c + 1) + ": Unexpected " + (b == d ? "end of input" : "'" + (this.terminals_[b] || b) + "'"), this.parseError(k, {
						text: p.match,
						token: this.terminals_[b] || b,
						line: p.yylineno,
						loc: g,
						expected: O
					});
				}
				if (S[0] instanceof Array && S.length > 1) throw Error("Parse Error: multiple actions possible at state: " + x + ", token: " + b);
				switch (S[0]) {
					case 1:
						n.push(b), i.push(p.yytext), a.push(p.yylloc), n.push(S[1]), b = null, l = p.yyleng, s = p.yytext, c = p.yylineno, g = p.yylloc;
						break;
					case 2:
						if (E = this.productions_[S[1]][1], w.$ = i[i.length - E], w._$ = {
							first_line: a[a.length - (E || 1)].first_line,
							last_line: a[a.length - 1].last_line,
							first_column: a[a.length - (E || 1)].first_column,
							last_column: a[a.length - 1].last_column
						}, _ && (w._$.range = [a[a.length - (E || 1)].range[0], a[a.length - 1].range[1]]), C = this.performAction.apply(w, [
							s,
							l,
							c,
							m.yy,
							S[1],
							i,
							a
						].concat(f)), typeof C < "u") return C;
						E && (n = n.slice(0, -1 * E * 2), i = i.slice(0, -1 * E), a = a.slice(0, -1 * E)), n.push(this.productions_[S[1]][0]), i.push(w.$), a.push(w._$), D = o[n[n.length - 2]][n[n.length - 1]], n.push(D);
						break;
					case 3: return !0;
				}
			}
			return !0;
		}, "parse")
	};
	g.lexer = /* @__PURE__ */ function() {
		return {
			EOF: 1,
			parseError: /* @__PURE__ */ A(function(e, t) {
				if (this.yy.parser) this.yy.parser.parseError(e, t);
				else throw Error(e);
			}, "parseError"),
			setInput: /* @__PURE__ */ A(function(e, t) {
				return this.yy = t || this.yy || {}, this._input = e, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
					first_line: 1,
					first_column: 0,
					last_line: 1,
					last_column: 0
				}, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
			}, "setInput"),
			input: /* @__PURE__ */ A(function() {
				var e = this._input[0];
				return this.yytext += e, this.yyleng++, this.offset++, this.match += e, this.matched += e, e.match(/(?:\r\n?|\n).*/g) ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), e;
			}, "input"),
			unput: /* @__PURE__ */ A(function(e) {
				var t = e.length, n = e.split(/(?:\r\n?|\n)/g);
				this._input = e + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - t), this.offset -= t;
				var r = this.match.split(/(?:\r\n?|\n)/g);
				this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), n.length - 1 && (this.yylineno -= n.length - 1);
				var i = this.yylloc.range;
				return this.yylloc = {
					first_line: this.yylloc.first_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.first_column,
					last_column: n ? (n.length === r.length ? this.yylloc.first_column : 0) + r[r.length - n.length].length - n[0].length : this.yylloc.first_column - t
				}, this.options.ranges && (this.yylloc.range = [i[0], i[0] + this.yyleng - t]), this.yyleng = this.yytext.length, this;
			}, "unput"),
			more: /* @__PURE__ */ A(function() {
				return this._more = !0, this;
			}, "more"),
			reject: /* @__PURE__ */ A(function() {
				if (this.options.backtrack_lexer) this._backtrack = !0;
				else return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
				return this;
			}, "reject"),
			less: /* @__PURE__ */ A(function(e) {
				this.unput(this.match.slice(e));
			}, "less"),
			pastInput: /* @__PURE__ */ A(function() {
				var e = this.matched.substr(0, this.matched.length - this.match.length);
				return (e.length > 20 ? "..." : "") + e.substr(-20).replace(/\n/g, "");
			}, "pastInput"),
			upcomingInput: /* @__PURE__ */ A(function() {
				var e = this.match;
				return e.length < 20 && (e += this._input.substr(0, 20 - e.length)), (e.substr(0, 20) + (e.length > 20 ? "..." : "")).replace(/\n/g, "");
			}, "upcomingInput"),
			showPosition: /* @__PURE__ */ A(function() {
				var e = this.pastInput(), t = Array(e.length + 1).join("-");
				return e + this.upcomingInput() + "\n" + t + "^";
			}, "showPosition"),
			test_match: /* @__PURE__ */ A(function(e, t) {
				var n, r, i;
				if (this.options.backtrack_lexer && (i = {
					yylineno: this.yylineno,
					yylloc: {
						first_line: this.yylloc.first_line,
						last_line: this.last_line,
						first_column: this.yylloc.first_column,
						last_column: this.yylloc.last_column
					},
					yytext: this.yytext,
					match: this.match,
					matches: this.matches,
					matched: this.matched,
					yyleng: this.yyleng,
					offset: this.offset,
					_more: this._more,
					_input: this._input,
					yy: this.yy,
					conditionStack: this.conditionStack.slice(0),
					done: this.done
				}, this.options.ranges && (i.yylloc.range = this.yylloc.range.slice(0))), r = e[0].match(/(?:\r\n?|\n).*/g), r && (this.yylineno += r.length), this.yylloc = {
					first_line: this.yylloc.last_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.last_column,
					last_column: r ? r[r.length - 1].length - r[r.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + e[0].length
				}, this.yytext += e[0], this.match += e[0], this.matches = e, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(e[0].length), this.matched += e[0], n = this.performAction.call(this, this.yy, this, t, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), n) return n;
				if (this._backtrack) {
					for (var a in i) this[a] = i[a];
					return !1;
				}
				return !1;
			}, "test_match"),
			next: /* @__PURE__ */ A(function() {
				if (this.done) return this.EOF;
				this._input || (this.done = !0);
				var e, t, n, r;
				this._more || (this.yytext = "", this.match = "");
				for (var i = this._currentRules(), a = 0; a < i.length; a++) if (n = this._input.match(this.rules[i[a]]), n && (!t || n[0].length > t[0].length)) {
					if (t = n, r = a, this.options.backtrack_lexer) {
						if (e = this.test_match(n, i[a]), e !== !1) return e;
						if (this._backtrack) {
							t = !1;
							continue;
						}
						return !1;
					}
					if (!this.options.flex) break;
				}
				return t ? (e = this.test_match(t, i[r]), e !== !1 && e) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
			}, "next"),
			lex: /* @__PURE__ */ A(function() {
				return this.next() || this.lex();
			}, "lex"),
			begin: /* @__PURE__ */ A(function(e) {
				this.conditionStack.push(e);
			}, "begin"),
			popState: /* @__PURE__ */ A(function() {
				return this.conditionStack.length - 1 > 0 ? this.conditionStack.pop() : this.conditionStack[0];
			}, "popState"),
			_currentRules: /* @__PURE__ */ A(function() {
				return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
			}, "_currentRules"),
			topState: /* @__PURE__ */ A(function(e) {
				return e = this.conditionStack.length - 1 - Math.abs(e || 0), e >= 0 ? this.conditionStack[e] : "INITIAL";
			}, "topState"),
			pushState: /* @__PURE__ */ A(function(e) {
				this.begin(e);
			}, "pushState"),
			stateStackSize: /* @__PURE__ */ A(function() {
				return this.conditionStack.length;
			}, "stateStackSize"),
			options: {},
			performAction: /* @__PURE__ */ A(function(e, t, n, r) {
				switch (n) {
					case 0: return e.getLogger().debug("Found block-beta"), 10;
					case 1: return e.getLogger().debug("Found id-block"), 29;
					case 2: return e.getLogger().debug("Found block"), 10;
					case 3:
						e.getLogger().debug(".", t.yytext);
						break;
					case 4:
						e.getLogger().debug("_", t.yytext);
						break;
					case 5: return 5;
					case 6: return t.yytext = -1, 28;
					case 7: return t.yytext = t.yytext.replace(/columns\s+/, ""), e.getLogger().debug("COLUMNS (LEX)", t.yytext), 28;
					case 8:
						this.pushState("md_string");
						break;
					case 9: return "MD_STR";
					case 10:
						this.popState();
						break;
					case 11:
						this.pushState("string");
						break;
					case 12:
						e.getLogger().debug("LEX: POPPING STR:", t.yytext), this.popState();
						break;
					case 13: return e.getLogger().debug("LEX: STR end:", t.yytext), "STR";
					case 14: return t.yytext = t.yytext.replace(/space\:/, ""), e.getLogger().debug("SPACE NUM (LEX)", t.yytext), 21;
					case 15: return t.yytext = "1", e.getLogger().debug("COLUMNS (LEX)", t.yytext), 21;
					case 16: return 42;
					case 17: return "LINKSTYLE";
					case 18: return "INTERPOLATE";
					case 19: return this.pushState("CLASSDEF"), 39;
					case 20: return this.popState(), this.pushState("CLASSDEFID"), "DEFAULT_CLASSDEF_ID";
					case 21: return this.popState(), this.pushState("CLASSDEFID"), 40;
					case 22: return this.popState(), 41;
					case 23: return this.pushState("CLASS"), 43;
					case 24: return this.popState(), this.pushState("CLASS_STYLE"), 44;
					case 25: return this.popState(), 45;
					case 26: return this.pushState("STYLE_STMNT"), 46;
					case 27: return this.popState(), this.pushState("STYLE_DEFINITION"), 47;
					case 28: return this.popState(), 48;
					case 29: return this.pushState("acc_title"), "acc_title";
					case 30: return this.popState(), "acc_title_value";
					case 31: return this.pushState("acc_descr"), "acc_descr";
					case 32: return this.popState(), "acc_descr_value";
					case 33:
						this.pushState("acc_descr_multiline");
						break;
					case 34:
						this.popState();
						break;
					case 35: return "acc_descr_multiline_value";
					case 36: return 30;
					case 37: return this.popState(), e.getLogger().debug("Lex: (("), "NODE_DEND";
					case 38: return this.popState(), e.getLogger().debug("Lex: (("), "NODE_DEND";
					case 39: return this.popState(), e.getLogger().debug("Lex: ))"), "NODE_DEND";
					case 40: return this.popState(), e.getLogger().debug("Lex: (("), "NODE_DEND";
					case 41: return this.popState(), e.getLogger().debug("Lex: (("), "NODE_DEND";
					case 42: return this.popState(), e.getLogger().debug("Lex: (-"), "NODE_DEND";
					case 43: return this.popState(), e.getLogger().debug("Lex: -)"), "NODE_DEND";
					case 44: return this.popState(), e.getLogger().debug("Lex: (("), "NODE_DEND";
					case 45: return this.popState(), e.getLogger().debug("Lex: ]]"), "NODE_DEND";
					case 46: return this.popState(), e.getLogger().debug("Lex: ("), "NODE_DEND";
					case 47: return this.popState(), e.getLogger().debug("Lex: ])"), "NODE_DEND";
					case 48: return this.popState(), e.getLogger().debug("Lex: /]"), "NODE_DEND";
					case 49: return this.popState(), e.getLogger().debug("Lex: /]"), "NODE_DEND";
					case 50: return this.popState(), e.getLogger().debug("Lex: )]"), "NODE_DEND";
					case 51: return this.popState(), e.getLogger().debug("Lex: )"), "NODE_DEND";
					case 52: return this.popState(), e.getLogger().debug("Lex: ]>"), "NODE_DEND";
					case 53: return this.popState(), e.getLogger().debug("Lex: ]"), "NODE_DEND";
					case 54: return e.getLogger().debug("Lexa: -)"), this.pushState("NODE"), 35;
					case 55: return e.getLogger().debug("Lexa: (-"), this.pushState("NODE"), 35;
					case 56: return e.getLogger().debug("Lexa: ))"), this.pushState("NODE"), 35;
					case 57: return e.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
					case 58: return e.getLogger().debug("Lex: ((("), this.pushState("NODE"), 35;
					case 59: return e.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
					case 60: return e.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
					case 61: return e.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
					case 62: return e.getLogger().debug("Lexc: >"), this.pushState("NODE"), 35;
					case 63: return e.getLogger().debug("Lexa: (["), this.pushState("NODE"), 35;
					case 64: return e.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
					case 65: return this.pushState("NODE"), 35;
					case 66: return this.pushState("NODE"), 35;
					case 67: return this.pushState("NODE"), 35;
					case 68: return this.pushState("NODE"), 35;
					case 69: return this.pushState("NODE"), 35;
					case 70: return this.pushState("NODE"), 35;
					case 71: return this.pushState("NODE"), 35;
					case 72: return e.getLogger().debug("Lexa: ["), this.pushState("NODE"), 35;
					case 73: return this.pushState("BLOCK_ARROW"), e.getLogger().debug("LEX ARR START"), 37;
					case 74: return e.getLogger().debug("Lex: NODE_ID", t.yytext), 31;
					case 75: return e.getLogger().debug("Lex: EOF", t.yytext), 8;
					case 76:
						this.pushState("md_string");
						break;
					case 77:
						this.pushState("md_string");
						break;
					case 78: return "NODE_DESCR";
					case 79:
						this.popState();
						break;
					case 80:
						e.getLogger().debug("Lex: Starting string"), this.pushState("string");
						break;
					case 81:
						e.getLogger().debug("LEX ARR: Starting string"), this.pushState("string");
						break;
					case 82: return e.getLogger().debug("LEX: NODE_DESCR:", t.yytext), "NODE_DESCR";
					case 83:
						e.getLogger().debug("LEX POPPING"), this.popState();
						break;
					case 84:
						e.getLogger().debug("Lex: =>BAE"), this.pushState("ARROW_DIR");
						break;
					case 85: return t.yytext = t.yytext.replace(/^,\s*/, ""), e.getLogger().debug("Lex (right): dir:", t.yytext), "DIR";
					case 86: return t.yytext = t.yytext.replace(/^,\s*/, ""), e.getLogger().debug("Lex (left):", t.yytext), "DIR";
					case 87: return t.yytext = t.yytext.replace(/^,\s*/, ""), e.getLogger().debug("Lex (x):", t.yytext), "DIR";
					case 88: return t.yytext = t.yytext.replace(/^,\s*/, ""), e.getLogger().debug("Lex (y):", t.yytext), "DIR";
					case 89: return t.yytext = t.yytext.replace(/^,\s*/, ""), e.getLogger().debug("Lex (up):", t.yytext), "DIR";
					case 90: return t.yytext = t.yytext.replace(/^,\s*/, ""), e.getLogger().debug("Lex (down):", t.yytext), "DIR";
					case 91: return t.yytext = "]>", e.getLogger().debug("Lex (ARROW_DIR end):", t.yytext), this.popState(), this.popState(), "BLOCK_ARROW_END";
					case 92: return e.getLogger().debug("Lex: LINK", "#" + t.yytext + "#"), 15;
					case 93: return e.getLogger().debug("Lex: LINK", t.yytext), 15;
					case 94: return e.getLogger().debug("Lex: LINK", t.yytext), 15;
					case 95: return e.getLogger().debug("Lex: LINK", t.yytext), 15;
					case 96: return e.getLogger().debug("Lex: START_LINK", t.yytext), this.pushState("LLABEL"), 16;
					case 97: return e.getLogger().debug("Lex: START_LINK", t.yytext), this.pushState("LLABEL"), 16;
					case 98: return e.getLogger().debug("Lex: START_LINK", t.yytext), this.pushState("LLABEL"), 16;
					case 99:
						this.pushState("md_string");
						break;
					case 100: return e.getLogger().debug("Lex: Starting string"), this.pushState("string"), "LINK_LABEL";
					case 101: return this.popState(), e.getLogger().debug("Lex: LINK", "#" + t.yytext + "#"), 15;
					case 102: return this.popState(), e.getLogger().debug("Lex: LINK", t.yytext), 15;
					case 103: return this.popState(), e.getLogger().debug("Lex: LINK", t.yytext), 15;
					case 104: return e.getLogger().debug("Lex: COLON", t.yytext), t.yytext = t.yytext.slice(1), 27;
				}
			}, "anonymous"),
			rules: [
				/^(?:block-beta\b)/,
				/^(?:block:)/,
				/^(?:block\b)/,
				/^(?:[\s]+)/,
				/^(?:[\n]+)/,
				/^(?:((\u000D\u000A)|(\u000A)))/,
				/^(?:columns\s+auto\b)/,
				/^(?:columns\s+[\d]+)/,
				/^(?:["][`])/,
				/^(?:[^`"]+)/,
				/^(?:[`]["])/,
				/^(?:["])/,
				/^(?:["])/,
				/^(?:[^"]*)/,
				/^(?:space[:]\d+)/,
				/^(?:space\b)/,
				/^(?:default\b)/,
				/^(?:linkStyle\b)/,
				/^(?:interpolate\b)/,
				/^(?:classDef\s+)/,
				/^(?:DEFAULT\s+)/,
				/^(?:\w+\s+)/,
				/^(?:[^\n]*)/,
				/^(?:class\s+)/,
				/^(?:(\w+)+((,\s*\w+)*))/,
				/^(?:[^\n]*)/,
				/^(?:style\s+)/,
				/^(?:(\w+)+((,\s*\w+)*))/,
				/^(?:[^\n]*)/,
				/^(?:accTitle\s*:\s*)/,
				/^(?:(?!\n||)*[^\n]*)/,
				/^(?:accDescr\s*:\s*)/,
				/^(?:(?!\n||)*[^\n]*)/,
				/^(?:accDescr\s*\{\s*)/,
				/^(?:[\}])/,
				/^(?:[^\}]*)/,
				/^(?:end\b\s*)/,
				/^(?:\(\(\()/,
				/^(?:\)\)\))/,
				/^(?:[\)]\))/,
				/^(?:\}\})/,
				/^(?:\})/,
				/^(?:\(-)/,
				/^(?:-\))/,
				/^(?:\(\()/,
				/^(?:\]\])/,
				/^(?:\()/,
				/^(?:\]\))/,
				/^(?:\\\])/,
				/^(?:\/\])/,
				/^(?:\)\])/,
				/^(?:[\)])/,
				/^(?:\]>)/,
				/^(?:[\]])/,
				/^(?:-\))/,
				/^(?:\(-)/,
				/^(?:\)\))/,
				/^(?:\))/,
				/^(?:\(\(\()/,
				/^(?:\(\()/,
				/^(?:\{\{)/,
				/^(?:\{)/,
				/^(?:>)/,
				/^(?:\(\[)/,
				/^(?:\()/,
				/^(?:\[\[)/,
				/^(?:\[\|)/,
				/^(?:\[\()/,
				/^(?:\)\)\))/,
				/^(?:\[\\)/,
				/^(?:\[\/)/,
				/^(?:\[\\)/,
				/^(?:\[)/,
				/^(?:<\[)/,
				/^(?:[^\(\[\n\-\)\{\}\s\<\>:=]+)/,
				/^(?:$)/,
				/^(?:["][`])/,
				/^(?:["][`])/,
				/^(?:[^`"]+)/,
				/^(?:[`]["])/,
				/^(?:["])/,
				/^(?:["])/,
				/^(?:[^"]+)/,
				/^(?:["])/,
				/^(?:\]>\s*\()/,
				/^(?:,?\s*right\s*)/,
				/^(?:,?\s*left\s*)/,
				/^(?:,?\s*x\s*)/,
				/^(?:,?\s*y\s*)/,
				/^(?:,?\s*up\s*)/,
				/^(?:,?\s*down\s*)/,
				/^(?:\)\s*)/,
				/^(?:\s*[xo<]?--+[-xo>]\s*)/,
				/^(?:\s*[xo<]?==+[=xo>]\s*)/,
				/^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/,
				/^(?:\s*~~[\~]+\s*)/,
				/^(?:\s*[xo<]?--\s*)/,
				/^(?:\s*[xo<]?==\s*)/,
				/^(?:\s*[xo<]?-\.\s*)/,
				/^(?:["][`])/,
				/^(?:["])/,
				/^(?:\s*[xo<]?--+[-xo>]\s*)/,
				/^(?:\s*[xo<]?==+[=xo>]\s*)/,
				/^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/,
				/^(?::\d+)/
			],
			conditions: {
				STYLE_DEFINITION: {
					rules: [28],
					inclusive: !1
				},
				STYLE_STMNT: {
					rules: [27],
					inclusive: !1
				},
				CLASSDEFID: {
					rules: [22],
					inclusive: !1
				},
				CLASSDEF: {
					rules: [20, 21],
					inclusive: !1
				},
				CLASS_STYLE: {
					rules: [25],
					inclusive: !1
				},
				CLASS: {
					rules: [24],
					inclusive: !1
				},
				LLABEL: {
					rules: [
						99,
						100,
						101,
						102,
						103
					],
					inclusive: !1
				},
				ARROW_DIR: {
					rules: [
						85,
						86,
						87,
						88,
						89,
						90,
						91
					],
					inclusive: !1
				},
				BLOCK_ARROW: {
					rules: [
						76,
						81,
						84
					],
					inclusive: !1
				},
				NODE: {
					rules: [
						37,
						38,
						39,
						40,
						41,
						42,
						43,
						44,
						45,
						46,
						47,
						48,
						49,
						50,
						51,
						52,
						53,
						77,
						80
					],
					inclusive: !1
				},
				md_string: {
					rules: [
						9,
						10,
						78,
						79
					],
					inclusive: !1
				},
				space: {
					rules: [],
					inclusive: !1
				},
				string: {
					rules: [
						12,
						13,
						82,
						83
					],
					inclusive: !1
				},
				acc_descr_multiline: {
					rules: [34, 35],
					inclusive: !1
				},
				acc_descr: {
					rules: [32],
					inclusive: !1
				},
				acc_title: {
					rules: [30],
					inclusive: !1
				},
				INITIAL: {
					rules: [
						0,
						1,
						2,
						3,
						4,
						5,
						6,
						7,
						8,
						11,
						14,
						15,
						16,
						17,
						18,
						19,
						23,
						26,
						29,
						31,
						33,
						36,
						54,
						55,
						56,
						57,
						58,
						59,
						60,
						61,
						62,
						63,
						64,
						65,
						66,
						67,
						68,
						69,
						70,
						71,
						72,
						73,
						74,
						75,
						92,
						93,
						94,
						95,
						96,
						97,
						98,
						104
					],
					inclusive: !0
				}
			}
		};
	}();
	function _() {
		this.yy = {};
	}
	return A(_, "Parser"), _.prototype = g, g.Parser = _, new _();
}();
M.parser = M;
var ye = M, N = /* @__PURE__ */ new Map(), P = [], F = /* @__PURE__ */ new Map(), I = "color", L = "fill", be = "bgFill", R = ",", z = /* @__PURE__ */ new Map(), B = "", xe = /* @__PURE__ */ A((e) => i.sanitizeText(e, y()), "sanitizeText"), Se = /* @__PURE__ */ A(function(e, t = "") {
	let n = z.get(e);
	n || (n = {
		id: e,
		styles: [],
		textStyles: []
	}, z.set(e, n)), t?.split(R).forEach((e) => {
		let t = e.replace(/([^;]*);/, "$1").trim();
		if (RegExp(I).exec(e)) {
			let e = t.replace(L, be).replace(I, L);
			n.textStyles.push(e);
		}
		n.styles.push(t);
	});
}, "addStyleClass"), Ce = /* @__PURE__ */ A(function(e, t = "") {
	let n = N.get(e);
	t != null && (n.styles = t.split(R));
}, "addStyle2Node"), we = /* @__PURE__ */ A(function(e, t) {
	e.split(",").forEach(function(e) {
		let n = N.get(e);
		if (n === void 0) {
			let t = e.trim();
			n = {
				id: t,
				type: "na",
				children: []
			}, N.set(t, n);
		}
		n.classes || (n.classes = []), n.classes.push(t);
	});
}, "setCssClass"), V = /* @__PURE__ */ A((e, t) => {
	let n = e.flat(), r = [], i = n.find((e) => e?.type === "column-setting")?.columns ?? -1;
	for (let e of n) {
		if (typeof i == "number" && i > 0 && e.type !== "column-setting" && typeof e.widthInColumns == "number" && e.widthInColumns > i && S.warn(`Block ${e.id} width ${e.widthInColumns} exceeds configured column width ${i}`), e.label &&= xe(e.label), e.type === "classDef") {
			Se(e.id, e.css);
			continue;
		}
		if (e.type === "applyClass") {
			we(e.id, e?.styleClass ?? "");
			continue;
		}
		if (e.type === "applyStyles") {
			e?.stylesStr && Ce(e.id, e?.stylesStr);
			continue;
		}
		if (e.type === "column-setting") t.columns = e.columns ?? -1;
		else if (e.type === "edge") {
			let t = (F.get(e.id) ?? 0) + 1;
			F.set(e.id, t), e.id = t + "-" + e.id, P.push(e);
		} else {
			e.label ||= e.type === "composite" ? "" : e.id;
			let t = N.get(e.id);
			if (t === void 0 ? N.set(e.id, e) : (e.type !== "na" && (t.type = e.type), e.label !== e.id && (t.label = e.label)), e.children && V(e.children, e), e.type === "space") {
				let t = e.width ?? 1;
				for (let n = 0; n < t; n++) {
					let t = me(e);
					t.id = t.id + "-" + n, N.set(t.id, t), r.push(t);
				}
			} else t === void 0 && r.push(e);
		}
	}
	t.children = r;
}, "populateBlockDatabase"), H = [], U = {
	id: "root",
	type: "composite",
	children: [],
	columns: -1
}, Te = /* @__PURE__ */ A(() => {
	S.debug("Clear called"), r(), U = {
		id: "root",
		type: "composite",
		children: [],
		columns: -1
	}, N = /* @__PURE__ */ new Map([["root", U]]), H = [], z = /* @__PURE__ */ new Map(), P = [], F = /* @__PURE__ */ new Map(), B = "";
}, "clear");
function W(e) {
	switch (S.debug("typeStr2Type", e), e) {
		case "[]": return "square";
		case "()": return S.debug("we have a round"), "round";
		case "(())": return "circle";
		case ">]": return "rect_left_inv_arrow";
		case "{}": return "diamond";
		case "{{}}": return "hexagon";
		case "([])": return "stadium";
		case "[[]]": return "subroutine";
		case "[()]": return "cylinder";
		case "((()))": return "doublecircle";
		case "[//]": return "lean_right";
		case "[\\\\]": return "lean_left";
		case "[/\\]": return "trapezoid";
		case "[\\/]": return "inv_trapezoid";
		case "<[]>": return "block_arrow";
		default: return "na";
	}
}
A(W, "typeStr2Type");
function G(e) {
	return S.debug("typeStr2Type", e), e === "==" ? "thick" : "normal";
}
A(G, "edgeTypeStr2Type");
function K(e) {
	switch (e.trim().slice(-1)) {
		case "x": return "arrow_cross";
		case "o": return "arrow_circle";
		case ">": return "arrow_point";
		default: return "";
	}
}
A(K, "edgeStrToEdgeData");
function Ee(e) {
	switch (e.trim().charAt(0)) {
		case "x": return "arrow_cross";
		case "o": return "arrow_circle";
		case "<": return "arrow_point";
		default: return "arrow_open";
	}
}
A(Ee, "edgeStrToEdgeStartData");
function De(e) {
	return e.includes("==") ? "thick" : "normal";
}
A(De, "edgeStrToThickness");
function Oe(e) {
	return e.includes(".-") ? "dotted" : "solid";
}
A(Oe, "edgeStrToPattern");
var ke = 0, Ae = {
	getConfig: /* @__PURE__ */ A(() => v().block, "getConfig"),
	typeStr2Type: W,
	edgeTypeStr2Type: G,
	edgeStrToEdgeData: K,
	edgeStrToEdgeStartData: Ee,
	edgeStrToThickness: De,
	edgeStrToPattern: Oe,
	getLogger: /* @__PURE__ */ A(() => S, "getLogger"),
	getBlocksFlat: /* @__PURE__ */ A(() => [...N.values()], "getBlocksFlat"),
	getBlocks: /* @__PURE__ */ A(() => H || [], "getBlocks"),
	getEdges: /* @__PURE__ */ A(() => P, "getEdges"),
	setHierarchy: /* @__PURE__ */ A((e) => {
		U.children = e, V(e, U), H = U.children;
	}, "setHierarchy"),
	getBlock: /* @__PURE__ */ A((e) => N.get(e), "getBlock"),
	setBlock: /* @__PURE__ */ A((e) => {
		N.set(e.id, e);
	}, "setBlock"),
	getColumns: /* @__PURE__ */ A((e) => {
		let t = N.get(e);
		return t ? t.columns ? t.columns : t.children ? t.children.length : -1 : -1;
	}, "getColumns"),
	getClasses: /* @__PURE__ */ A(function() {
		return z;
	}, "getClasses"),
	clear: Te,
	generateId: /* @__PURE__ */ A(() => (ke++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + ke), "generateId"),
	setDiagramId: /* @__PURE__ */ A((e) => {
		B = e;
	}, "setDiagramId"),
	getDiagramId: /* @__PURE__ */ A(() => B, "getDiagramId")
}, q = /* @__PURE__ */ A((e, t) => {
	let n = fe, r = n(e, "r"), i = n(e, "g"), a = n(e, "b");
	return se(r, i, a, t);
}, "fade"), je = /* @__PURE__ */ A((e) => `.label {
    font-family: ${e.fontFamily};
    color: ${e.nodeTextColor || e.textColor};
  }
  .cluster-label text {
    fill: ${e.titleColor};
  }
  .cluster-label span {
    color: ${e.titleColor};
  }



  .label text,span {
    fill: ${e.nodeTextColor || e.textColor};
    color: ${e.nodeTextColor || e.textColor};
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon,
  .node path {
    fill: ${e.mainBkg};
    stroke: ${e.nodeBorder};
    stroke-width: 1px;
  }
  .flowchart-label text {
    text-anchor: middle;
  }
  // .flowchart-label .text-outer-tspan {
  //   text-anchor: middle;
  // }
  // .flowchart-label .text-inner-tspan {
  //   text-anchor: start;
  // }

  .node .label {
    text-align: center;
  }
  .node.clickable {
    cursor: pointer;
  }

  .arrowheadPath {
    fill: ${e.arrowheadColor};
  }

  .edgePaths .path {
    stroke: ${e.lineColor};
    stroke-width: 2.0px;
  }

  .flowchart-link {
    stroke: ${e.lineColor};
    fill: none;
  }

  .edgeLabel {
    background-color: ${e.edgeLabelBackground};
    /*
     * This is for backward compatibility with existing code that didn't
     * add a \`<p>\` around edge labels.
     *
     * TODO: We should probably remove this in a future release.
     */
    p {
      margin: 0;
      padding: 0;
      display: inline;
    }
    rect {
      opacity: 0.5;
      background-color: ${e.edgeLabelBackground};
      fill: ${e.edgeLabelBackground};
    }
    text-align: center;
  }

  /* For html labels only */
  .labelBkg {
    background-color: ${e.edgeLabelBackground};
  }

  .node .cluster {
    // fill: ${q(e.mainBkg, .5)};
    fill: ${q(e.clusterBkg, .5)};
    stroke: ${q(e.clusterBorder, .2)};
    box-shadow: rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
    stroke-width: 1px;
  }

  .cluster text {
    fill: ${e.titleColor};
  }

  .cluster span {
    color: ${e.titleColor};
  }
  /* .cluster div {
    color: ${e.titleColor};
  } */

  div.mermaidTooltip {
    position: absolute;
    text-align: center;
    max-width: 200px;
    padding: 2px;
    font-family: ${e.fontFamily};
    font-size: 12px;
    background: ${e.tertiaryColor};
    border: 1px solid ${e.border2};
    border-radius: 2px;
    pointer-events: none;
    z-index: 100;
  }

  .flowchartTitleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${e.textColor};
  }
  ${de()}
`, "getStyles");
function J(e, t) {
	if (e === 0 || !Number.isInteger(e)) throw Error("Columns must be an integer !== 0.");
	if (t < 0 || !Number.isInteger(t)) throw Error("Position must be a non-negative integer." + t);
	return e < 0 ? {
		px: t,
		py: 0
	} : e === 1 ? {
		px: 0,
		py: t
	} : {
		px: t % e,
		py: Math.floor(t / e)
	};
}
A(J, "calculateBlockPosition");
var Me = /* @__PURE__ */ A((e) => {
	let t = 0, n = 0;
	for (let r of e.children) {
		let { width: e, height: i, x: a, y: o } = r.size ?? {
			width: 0,
			height: 0,
			x: 0,
			y: 0
		};
		if (S.debug("getMaxChildSize abc95 child:", r.id, "width:", e, "height:", i, "x:", a, "y:", o, r.type), r.type === "space") continue;
		let s = e / (r.widthInColumns ?? 1);
		s > t && (t = s), i > n && (n = i);
	}
	return {
		width: t,
		height: n
	};
}, "getMaxChildSize");
function Y(e, t, n = 0, r = 0, i = 8) {
	S.debug("setBlockSizes abc95 (start)", e.id, e?.size?.x, "block width =", e?.size, "siblingWidth", n), e?.size?.width || (e.size = {
		width: n,
		height: r,
		x: 0,
		y: 0
	});
	let a = 0, o = 0;
	if (e.children?.length > 0) {
		for (let n of e.children) Y(n, t, 0, 0, i);
		let s = Me(e);
		a = s.width, o = s.height, S.debug("setBlockSizes abc95 maxWidth of", e.id, ":s children is ", a, o);
		for (let t of e.children) t.size && (S.debug(`abc95 Setting size of children of ${e.id} id=${t.id} ${a} ${o} ${JSON.stringify(t.size)}`), t.size.width = a * (t.widthInColumns ?? 1) + i * ((t.widthInColumns ?? 1) - 1), t.size.height = o, t.size.x = 0, t.size.y = 0, S.debug(`abc95 updating size of ${e.id} children child:${t.id} maxWidth:${a} maxHeight:${o}`));
		for (let n of e.children) Y(n, t, a, o, i);
		let c = e.columns ?? -1, l = 0;
		for (let t of e.children) l += t.widthInColumns ?? 1;
		let u = e.children.length;
		c > 0 && c < l && (u = c);
		let d = Math.ceil(l / u), f = u * (a + i) + i, p = d * (o + i) + i;
		if (f < n) {
			S.debug(`Detected to small sibling: abc95 ${e.id} siblingWidth ${n} siblingHeight ${r} width ${f}`), f = n, p = r;
			let t = (n - u * i - i) / u, s = (r - d * i - i) / d;
			S.debug("Size indata abc88", e.id, "childWidth", t, "maxWidth", a), S.debug("Size indata abc88", e.id, "childHeight", s, "maxHeight", o), S.debug("Size indata abc88 xSize", u, "padding", i);
			for (let n of e.children) n.size && (n.size.width = t, n.size.height = s, n.size.x = 0, n.size.y = 0);
		}
		if (S.debug(`abc95 (finale calc) ${e.id} xSize ${u} ySize ${d} columns ${c}${e.children.length} width=${Math.max(f, e.size?.width || 0)}`), f < (e?.size?.width || 0)) {
			f = e?.size?.width || 0;
			let t = c > 0 ? Math.min(e.children.length, c) : e.children.length;
			if (t > 0) {
				let n = (f - t * i - i) / t;
				S.debug("abc95 (growing to fit) width", e.id, f, e.size?.width, n);
				for (let t of e.children) t.size && (t.size.width = n);
			}
		}
		e.size = {
			width: f,
			height: p,
			x: 0,
			y: 0
		};
	}
	S.debug("setBlockSizes abc94 (done)", e.id, e?.size?.x, e?.size?.width, e?.size?.y, e?.size?.height);
}
A(Y, "setBlockSizes");
function X(e, t, n = 8) {
	S.debug(`abc85 layout blocks (=>layoutBlocks) ${e.id} x: ${e?.size?.x} y: ${e?.size?.y} width: ${e?.size?.width}`);
	let r = e.columns ?? -1;
	if (S.debug("layoutBlocks columns abc95", e.id, "=>", r, e), e.children && e.children.length > 0) {
		let i = e?.children[0]?.size?.width ?? 0, a = e.children.length * i + (e.children.length - 1) * n;
		S.debug("widthOfChildren 88", a, "posX");
		let o = /* @__PURE__ */ new Map();
		{
			let t = 0;
			for (let n of e.children) {
				if (!n.size) continue;
				let { py: e } = J(r, t), i = o.get(e) ?? 0;
				n.size.height > i && o.set(e, n.size.height);
				let a = n?.widthInColumns ?? 1;
				r > 0 && (a = Math.min(a, r - t % r)), t += a;
			}
		}
		let s = /* @__PURE__ */ new Map();
		{
			let e = 0, t = [...o.keys()].sort((e, t) => e - t);
			for (let r of t) s.set(r, e), e += (o.get(r) ?? 0) + n;
		}
		let c = 0;
		S.debug("abc91 block?.size?.x", e.id, e?.size?.x);
		let l = e?.size?.x ? e?.size?.x + (-e?.size?.width / 2 || 0) : -n, u = 0;
		for (let i of e.children) {
			let a = e;
			if (!i.size) continue;
			let { width: d, height: f } = i.size, { px: p, py: m } = J(r, c);
			if (m != u && (u = m, l = e?.size?.x ? e?.size?.x + (-e?.size?.width / 2 || 0) : -n, S.debug("New row in layout for block", e.id, " and child ", i.id, u)), S.debug(`abc89 layout blocks (child) id: ${i.id} Pos: ${c} (px, py) ${p},${m} (${a?.size?.x},${a?.size?.y}) parent: ${a.id} width: ${d}${n}`), a.size) {
				let e = d / 2;
				i.size.x = l + n + e, S.debug(`abc91 layout blocks (calc) px, pyid:${i.id} startingPos=X${l} new startingPosX${i.size.x} ${e} padding=${n} width=${d} halfWidth=${e} => x:${i.size.x} y:${i.size.y} ${i.widthInColumns} (width * (child?.w || 1)) / 2 ${d * (i?.widthInColumns ?? 1) / 2}`), l = i.size.x + e;
				let t = s.get(m) ?? 0, r = o.get(m) ?? f;
				i.size.y = a.size.y - a.size.height / 2 + t + r / 2 + n, S.debug(`abc88 layout blocks (calc) px, pyid:${i.id}startingPosX${l}${n}${e}=>x:${i.size.x}y:${i.size.y}${i.widthInColumns}(width * (child?.w || 1)) / 2${d * (i?.widthInColumns ?? 1) / 2}`);
			}
			i.children && X(i, t, n);
			let h = i?.widthInColumns ?? 1;
			r > 0 && (h = Math.min(h, r - c % r)), c += h, S.debug("abc88 columnsPos", i, c);
		}
	}
	S.debug(`layout blocks (<==layoutBlocks) ${e.id} x: ${e?.size?.x} y: ${e?.size?.y} width: ${e?.size?.width}`);
}
A(X, "layoutBlocks");
function Z(e, { minX: t, minY: n, maxX: r, maxY: i } = {
	minX: 0,
	minY: 0,
	maxX: 0,
	maxY: 0
}) {
	if (e.size && e.id !== "root") {
		let { x: a, y: o, width: s, height: c } = e.size;
		a - s / 2 < t && (t = a - s / 2), o - c / 2 < n && (n = o - c / 2), a + s / 2 > r && (r = a + s / 2), o + c / 2 > i && (i = o + c / 2);
	}
	if (e.children) for (let a of e.children) ({minX: t, minY: n, maxX: r, maxY: i} = Z(a, {
		minX: t,
		minY: n,
		maxX: r,
		maxY: i
	}));
	return {
		minX: t,
		minY: n,
		maxX: r,
		maxY: i
	};
}
A(Z, "findBounds");
function Ne(e) {
	let t = e.getBlock("root");
	if (!t) return;
	let n = y()?.block?.padding ?? 8;
	Y(t, e, 0, 0, n), X(t, e, n), S.debug("getBlocks", JSON.stringify(t, null, 2));
	let { minX: r, minY: i, maxX: a, maxY: o } = Z(t), s = o - i;
	return {
		x: r,
		y: i,
		width: a - r,
		height: s
	};
}
A(Ne, "layout");
function Q(e, t, n = !1) {
	let r = e, i = "default";
	(r?.classes?.length || 0) > 0 && (i = (r?.classes ?? []).join(" ")), i += " flowchart-label";
	let a = (r?.classes ?? []).flatMap((e) => t.getClasses().get(e)?.styles ?? []), o = 0, s = "rect", c;
	switch (r.type) {
		case "round":
			o = 5, s = "rect";
			break;
		case "composite":
			o = 0, s = "composite", c = 0;
			break;
		case "square":
			s = "rect";
			break;
		case "diamond":
			s = "question";
			break;
		case "hexagon":
			s = "hexagon";
			break;
		case "block_arrow":
			s = "block_arrow";
			break;
		case "odd":
			s = "rect_left_inv_arrow";
			break;
		case "lean_right":
			s = "lean_right";
			break;
		case "lean_left":
			s = "lean_left";
			break;
		case "trapezoid":
			s = "trapezoid";
			break;
		case "inv_trapezoid":
			s = "inv_trapezoid";
			break;
		case "rect_left_inv_arrow":
			s = "rect_left_inv_arrow";
			break;
		case "circle":
			s = "circle";
			break;
		case "ellipse":
			s = "ellipse";
			break;
		case "stadium":
			s = "stadium";
			break;
		case "subroutine":
			s = "subroutine";
			break;
		case "cylinder":
			s = "cylinder";
			break;
		case "group":
			s = "rect";
			break;
		case "doublecircle":
			s = "doublecircle";
			break;
		default: s = "rect";
	}
	let l = b(r?.styles ?? []), u = r.label, d = r.size ?? {
		width: 0,
		height: 0,
		x: 0,
		y: 0
	}, f = t.getDiagramId();
	return {
		labelStyle: l.labelStyle,
		shape: s,
		label: u,
		labelText: u,
		rx: o,
		ry: o,
		class: i,
		cssClasses: i,
		cssStyles: r?.styles ?? [],
		cssCompiledStyles: a,
		style: l.style,
		id: r.id,
		domId: f ? `${f}-${r.id}` : r.id,
		isGroup: !1,
		directions: r.directions,
		width: d.width || void 0,
		height: d.height || void 0,
		wrappingWidth: d.width || Infinity,
		x: d.x,
		y: d.y,
		positioned: n,
		intersect: void 0,
		padding: c ?? v()?.block?.padding ?? 0,
		widthInColumns: r.widthInColumns ?? 1
	};
}
A(Q, "getNodeFromBlock");
async function Pe(e, t, n) {
	let r = Q(t, n, !1);
	if (t.type === "group") return;
	let i = v(), a = await u(e, r, { config: i }), o = a.node()?.getBBox() ?? {
		width: 0,
		height: 0
	}, s = n.getBlock(r.id);
	s.size = {
		width: o.width,
		height: o.height,
		x: 0,
		y: 0,
		node: a
	}, n.setBlock(s), a.remove();
}
A(Pe, "calculateBlockSize");
async function Fe(e, t, n) {
	let r = Q(t, n, !0);
	if (n.getBlock(r.id).type !== "space") {
		let n = v();
		await u(e, r, { config: n }), t.intersect = r?.intersect, ae(r);
	}
}
A(Fe, "insertBlockPositioned");
async function $(e, t, n, r) {
	for (let i of t) await r(e, i, n), i.children && await $(e, i.children, n, r);
}
A($, "performOperations");
async function Ie(e, t, n) {
	await $(e, t, n, Pe);
}
A(Ie, "calculateBlockSizes");
async function Le(e, t, n) {
	await $(e, t, n, Fe);
}
A(Le, "insertBlocks");
async function Re(e, t, r, i, a) {
	let o = new n({
		multigraph: !0,
		compound: !0
	});
	o.setGraph({
		rankdir: "TB",
		nodesep: 10,
		ranksep: 10,
		marginx: 8,
		marginy: 8
	});
	for (let e of r) e.size && o.setNode(e.id, {
		width: e.size.width,
		height: e.size.height,
		intersect: e.intersect
	});
	for (let n of t) if (n.start && n.end) {
		let t = i.getBlock(n.start), r = i.getBlock(n.end);
		if (t?.size && r?.size) {
			let i = t.size, s = r.size, u = [
				{
					x: i.x,
					y: i.y
				},
				{
					x: i.x + (s.x - i.x) / 2,
					y: i.y + (s.y - i.y) / 2
				},
				{
					x: s.x,
					y: s.y
				}
			], d = a ? `${a}-${n.id}` : n.id, f = `${n.thickness === "thick" ? "edge-thickness-thick" : "edge-thickness-normal"} ${n.pattern === "dotted" ? "edge-pattern-dotted" : "edge-pattern-solid"} flowchart-link LS-a1 LE-b1`;
			c(e, {
				...n,
				id: d,
				arrowTypeEnd: n.arrowTypeEnd,
				arrowTypeStart: n.arrowTypeStart,
				points: u,
				classes: f
			}, {}, "block", o.node(n.start), o.node(n.end), a), n.label && (await l(e, {
				...n,
				label: n.label,
				labelStyle: "stroke: #333; stroke-width: 1.5px;fill:none;",
				arrowTypeEnd: n.arrowTypeEnd,
				arrowTypeStart: n.arrowTypeStart,
				points: u,
				classes: f
			}), ie({
				...n,
				x: u[1].x,
				y: u[1].y
			}, { originalPath: u }));
		}
	}
}
A(Re, "insertEdges");
var ze = {
	parser: ye,
	db: Ae,
	renderer: {
		draw: /* @__PURE__ */ A(async function(t, n, r, i) {
			let { securityLevel: o, block: s } = v(), c = i.db;
			c.setDiagramId(n);
			let l;
			o === "sandbox" && (l = e("#i" + n));
			let u = e(o === "sandbox" ? l.nodes()[0].contentDocument.body : "body"), d = o === "sandbox" ? u.select(`[id="${n}"]`) : e(`[id="${n}"]`);
			w(d, [
				"point",
				"circle",
				"cross"
			], i.type, n);
			let f = c.getBlocks(), p = c.getBlocksFlat(), m = c.getEdges(), h = d.insert("g").attr("class", "block");
			await Ie(h, f, c);
			let g = Ne(c);
			await Le(h, f, c), await Re(h, m, p, c, n);
			let _ = h.node()?.getBBox(), y = _ && Number.isFinite(_.width) && Number.isFinite(_.height) ? _ : g;
			if (y) {
				let e = Math.max(1, Math.round(.125 * (y.width / y.height))), t = y.height + e + 10, n = y.width + 10, { useMaxWidth: r } = s;
				a(d, t, n, !!r), S.debug("Here Bounds", g, y), d.attr("viewBox", `${y.x - 5} ${y.y - 5} ${y.width + 10} ${y.height + 10}`);
			}
		}, "draw"),
		getClasses: /* @__PURE__ */ A(function(e, t) {
			return t.db.getClasses();
		}, "getClasses")
	},
	styles: je
};
//#endregion
export { ze as diagram };

//# sourceMappingURL=blockDiagram-I7D4REHJ-DqPs4wzi-CzKqkFxw.js.map