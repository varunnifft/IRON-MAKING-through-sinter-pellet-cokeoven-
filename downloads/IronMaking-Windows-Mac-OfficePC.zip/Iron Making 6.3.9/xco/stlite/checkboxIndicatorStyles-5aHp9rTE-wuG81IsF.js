import { sa as e } from "./index-B1FrxEMd-BsPMjC5n.js";
//#region ../react/build/checkboxIndicatorStyles-5aHp9rTE.js
function t(e, { isSelected: t, isHovered: n = !1, isDisabled: r = !1 }) {
	return r ? {
		borderColor: e.colors.borderColor,
		backgroundColor: t ? e.colors.fadedText40 : e.colors.lightenedBg05
	} : t ? {
		borderColor: e.colors.primary,
		backgroundColor: e.colors.primary
	} : n ? {
		borderColor: e.colors.borderColor,
		backgroundColor: e.colors.darkenedBgMix15
	} : {
		borderColor: e.colors.borderColor,
		backgroundColor: e.colors.lightenedBg05
	};
}
function n(e) {
	return {
		flexShrink: 0,
		width: e.sizes.checkbox,
		height: e.sizes.checkbox,
		marginTop: `calc((${e.lineHeights.small} * ${e.fontSizes.sm} - ${e.sizes.checkbox}) / 2)`,
		borderRadius: e.radii.sm,
		display: "flex",
		alignItems: "center",
		justifyContent: "center",
		transition: "background-color 100ms ease, border-color 100ms ease"
	};
}
function r(t, { isDisabled: n }) {
	return {
		width: "65%",
		height: "65%",
		fill: "none",
		stroke: n ? e(t) ? t.colors.bgColor : t.colors.bodyText : t.colors.white,
		strokeWidth: "2.5px",
		strokeLinecap: "round",
		strokeLinejoin: "round"
	};
}
//#endregion
export { t as n, r, n as t };

//# sourceMappingURL=checkboxIndicatorStyles-5aHp9rTE-wuG81IsF.js.map