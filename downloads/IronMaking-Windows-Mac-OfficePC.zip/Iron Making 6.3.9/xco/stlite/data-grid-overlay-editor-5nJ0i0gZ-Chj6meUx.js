import { ds as e, ms as t, us as n } from "./index-B1FrxEMd-BsPMjC5n.js";
import { C as r, T as i, b as a, c as o, i as s, m as c, s as l } from "./DataFrame-DRF8lFxD-CzB3xmp7.js";
//#region ../react/build/data-grid-overlay-editor-5nJ0i0gZ.js
var u = /* @__PURE__ */ t(e(), 1), d = /* @__PURE__ */ t(n(), 1), f = /* @__PURE__ */ l("div")({
	name: "DataGridOverlayEditorStyle",
	class: "gdg-d19meir1",
	propsAsIs: !1,
	vars: {
		"d19meir1-0": [(e) => e.targetY, "px"],
		"d19meir1-1": [(e) => e.targetX, "px"],
		"d19meir1-2": [(e) => e.targetWidth, "px"],
		"d19meir1-3": [(e) => e.targetHeight, "px"],
		"d19meir1-4": [(e) => e.targetY + 10, "px"],
		"d19meir1-5": [(e) => Math.max(0, (e.targetHeight - 28) / 2), "px"]
	}
});
function p() {
	let [e, t] = u.useState();
	return [e ?? void 0, t];
}
function m() {
	let [e, t] = p(), [n, r] = u.useState(0), [i, a] = u.useState(!0);
	return u.useLayoutEffect(() => {
		if (e === void 0 || !("IntersectionObserver" in window)) return;
		let t = new IntersectionObserver((e) => {
			e.length !== 0 && a(e[0].isIntersecting);
		}, { threshold: 1 });
		return t.observe(e), () => t.disconnect();
	}, [e]), u.useEffect(() => {
		if (i || e === void 0) return;
		let t, n = () => {
			let { right: i } = e.getBoundingClientRect();
			r((e) => Math.min(e + window.innerWidth - i - 10, 0)), t = requestAnimationFrame(n);
		};
		return t = requestAnimationFrame(n), () => {
			t !== void 0 && cancelAnimationFrame(t);
		};
	}, [e, i]), {
		ref: t,
		style: u.useMemo(() => ({ transform: `translateX(${n}px)` }), [n])
	};
}
var h = (e) => {
	let { target: t, content: n, onFinishEditing: l, forceEditMode: p, initialValue: h, imageEditorOverride: g, markdownDivCreateNode: _, highlight: v, className: y, theme: b, id: x, cell: S, bloom: C, portalElementRef: w, validateCell: T, getCellRenderer: E, provideEditor: D, isOutsideClick: ee, customEventTarget: te, activation: O } = e, [k, A] = u.useState(p ? n : void 0), j = u.useRef(k ?? n);
	j.current = k ?? n;
	let [M, N] = u.useState(() => T === void 0 || !(s(n) && T?.(S, n, j.current) === !1)), P = u.useCallback((e, t) => {
		l(M ? e : void 0, t);
	}, [M, l]), F = u.useCallback((e) => {
		if (T !== void 0 && e !== void 0 && s(e)) {
			let t = T(S, e, j.current);
			t === !1 ? N(!1) : (typeof t == "object" && (e = t), N(!0));
		}
		A(e);
	}, [S, T]), I = u.useRef(!1), L = u.useRef(void 0), R = u.useCallback(() => {
		P(k, [0, 0]), I.current = !0;
	}, [k, P]), z = u.useCallback((e, t) => {
		P(e, t ?? L.current ?? [0, 0]), I.current = !0;
	}, [P]), B = u.useCallback(async (e) => {
		let t = !1;
		e.key === "Escape" ? (e.stopPropagation(), e.preventDefault(), L.current = [0, 0]) : e.key === "Enter" && !e.shiftKey ? (e.stopPropagation(), e.preventDefault(), L.current = [0, 1], t = !0) : e.key === "Tab" && (e.stopPropagation(), e.preventDefault(), L.current = [e.shiftKey ? -1 : 1, 0], t = !0), window.setTimeout(() => {
			!I.current && L.current !== void 0 && (P(t ? k : void 0, L.current), I.current = !0);
		}, 0);
	}, [P, k]), V = k ?? n, [H, U] = u.useMemo(() => {
		if (a(n)) return [];
		let e = {
			...n,
			location: S,
			activation: O
		}, t = D?.(e);
		return t === void 0 ? [E(n)?.provideEditor?.(e), !1] : [t, !1];
	}, [
		S,
		n,
		E,
		D,
		O
	]), { ref: W, style: G } = m(), K = !0, q, J = !0, Y;
	if (H !== void 0) {
		K = H.disablePadding !== !0, J = H.disableStyling !== !0;
		let e = o(H);
		e && (Y = H.styleOverride);
		let n = e ? H.editor : H;
		q = u.createElement(n, {
			portalElementRef: w,
			isHighlighted: v,
			activation: O,
			onChange: F,
			value: V,
			initialValue: h,
			onFinishedEditing: z,
			validatedSelection: s(V) ? V.selectionRange : void 0,
			forceEditMode: p,
			target: t,
			imageEditorOverride: g,
			markdownDivCreateNode: _,
			isValid: M,
			theme: b
		});
	}
	Y = {
		...Y,
		...G
	};
	let X = w?.current ?? document.getElementById("portal");
	if (X === null) return console.error("Cannot open Data Grid overlay editor, because portal not found. Please, either provide a portalElementRef or add `<div id=\"portal\" />` as the last child of your `<body>`."), null;
	let Z = J ? "gdg-style" : "gdg-unstyle";
	M || (Z += " gdg-invalid"), K && (Z += " gdg-pad");
	let Q = C?.[0] ?? 1, $ = C?.[1] ?? 1;
	return (0, d.createPortal)(u.createElement(i.Provider, { value: b }, u.createElement(r, {
		style: c(b),
		className: y,
		onClickOutside: R,
		isOutsideClick: ee,
		customEventTarget: te
	}, u.createElement(f, {
		ref: W,
		id: x,
		className: Z,
		style: Y,
		as: U === !0 ? "label" : void 0,
		targetX: t.x - Q,
		targetY: t.y - $,
		targetWidth: t.width + Q * 2,
		targetHeight: t.height + $ * 2
	}, u.createElement("div", {
		className: "gdg-clip-region",
		onKeyDown: B
	}, q)))), X);
};
//#endregion
export { h as default };

//# sourceMappingURL=data-grid-overlay-editor-5nJ0i0gZ-Chj6meUx.js.map