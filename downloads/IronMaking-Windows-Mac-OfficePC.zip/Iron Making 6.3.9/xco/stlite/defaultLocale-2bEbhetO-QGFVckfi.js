//#region ../react/build/defaultLocale-2bEbhetO.js
function e(e) {
	return Math.abs(e = Math.round(e)) >= 1e21 ? e.toLocaleString("en").replace(/,/g, "") : e.toString(10);
}
function t(e, t) {
	if ((n = (e = t ? e.toExponential(t - 1) : e.toExponential()).indexOf("e")) < 0) return null;
	var n, r = e.slice(0, n);
	return [r.length > 1 ? r[0] + r.slice(2) : r, +e.slice(n + 1)];
}
function n(e) {
	return e = t(Math.abs(e)), e ? e[1] : NaN;
}
function r(e, t) {
	return function(n, r) {
		for (var i = n.length, a = [], o = 0, s = e[0], c = 0; i > 0 && s > 0 && (c + s + 1 > r && (s = Math.max(1, r - c)), a.push(n.substring(i -= s, i + s)), !((c += s + 1) > r));) s = e[o = (o + 1) % e.length];
		return a.reverse().join(t);
	};
}
function i(e) {
	return function(t) {
		return t.replace(/[0-9]/g, function(t) {
			return e[+t];
		});
	};
}
var a = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;
function o(e) {
	if (!(t = a.exec(e))) throw Error("invalid format: " + e);
	var t;
	return new s({
		fill: t[1],
		align: t[2],
		sign: t[3],
		symbol: t[4],
		zero: t[5],
		width: t[6],
		comma: t[7],
		precision: t[8] && t[8].slice(1),
		trim: t[9],
		type: t[10]
	});
}
o.prototype = s.prototype;
function s(e) {
	this.fill = e.fill === void 0 ? " " : e.fill + "", this.align = e.align === void 0 ? ">" : e.align + "", this.sign = e.sign === void 0 ? "-" : e.sign + "", this.symbol = e.symbol === void 0 ? "" : e.symbol + "", this.zero = !!e.zero, this.width = e.width === void 0 ? void 0 : +e.width, this.comma = !!e.comma, this.precision = e.precision === void 0 ? void 0 : +e.precision, this.trim = !!e.trim, this.type = e.type === void 0 ? "" : e.type + "";
}
s.prototype.toString = function() {
	return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (this.width === void 0 ? "" : Math.max(1, this.width | 0)) + (this.comma ? "," : "") + (this.precision === void 0 ? "" : "." + Math.max(0, this.precision | 0)) + (this.trim ? "~" : "") + this.type;
};
function c(e) {
	n: for (var t = e.length, n = 1, r = -1, i; n < t; ++n) switch (e[n]) {
		case ".":
			r = i = n;
			break;
		case "0":
			r === 0 && (r = n), i = n;
			break;
		default:
			if (!+e[n]) break n;
			r > 0 && (r = 0);
	}
	return r > 0 ? e.slice(0, r) + e.slice(i + 1) : e;
}
var l;
function u(e, n) {
	var r = t(e, n);
	if (!r) return e + "";
	var i = r[0], a = r[1], o = a - (l = Math.max(-8, Math.min(8, Math.floor(a / 3))) * 3) + 1, s = i.length;
	return o === s ? i : o > s ? i + Array(o - s + 1).join("0") : o > 0 ? i.slice(0, o) + "." + i.slice(o) : "0." + Array(1 - o).join("0") + t(e, Math.max(0, n + o - 1))[0];
}
function d(e, n) {
	var r = t(e, n);
	if (!r) return e + "";
	var i = r[0], a = r[1];
	return a < 0 ? "0." + Array(-a).join("0") + i : i.length > a + 1 ? i.slice(0, a + 1) + "." + i.slice(a + 1) : i + Array(a - i.length + 2).join("0");
}
var f = {
	"%": (e, t) => (e * 100).toFixed(t),
	b: (e) => Math.round(e).toString(2),
	c: (e) => e + "",
	d: e,
	e: (e, t) => e.toExponential(t),
	f: (e, t) => e.toFixed(t),
	g: (e, t) => e.toPrecision(t),
	o: (e) => Math.round(e).toString(8),
	p: (e, t) => d(e * 100, t),
	r: d,
	s: u,
	X: (e) => Math.round(e).toString(16).toUpperCase(),
	x: (e) => Math.round(e).toString(16)
};
function p(e) {
	return e;
}
var m = Array.prototype.map, h = [
	"y",
	"z",
	"a",
	"f",
	"p",
	"n",
	"µ",
	"m",
	"",
	"k",
	"M",
	"G",
	"T",
	"P",
	"E",
	"Z",
	"Y"
];
function g(e) {
	var t = e.grouping === void 0 || e.thousands === void 0 ? p : r(m.call(e.grouping, Number), e.thousands + ""), a = e.currency === void 0 ? "" : e.currency[0] + "", s = e.currency === void 0 ? "" : e.currency[1] + "", u = e.decimal === void 0 ? "." : e.decimal + "", d = e.numerals === void 0 ? p : i(m.call(e.numerals, String)), g = e.percent === void 0 ? "%" : e.percent + "", _ = e.minus === void 0 ? "−" : e.minus + "", v = e.nan === void 0 ? "NaN" : e.nan + "";
	function y(e) {
		e = o(e);
		var n = e.fill, r = e.align, i = e.sign, p = e.symbol, m = e.zero, y = e.width, b = e.comma, x = e.precision, S = e.trim, C = e.type;
		C === "n" ? (b = !0, C = "g") : f[C] || (x === void 0 && (x = 12), S = !0, C = "g"), (m || n === "0" && r === "=") && (m = !0, n = "0", r = "=");
		var w = p === "$" ? a : p === "#" && /[boxX]/.test(C) ? "0" + C.toLowerCase() : "", T = p === "$" ? s : /[%p]/.test(C) ? g : "", E = f[C], D = /[defgprs%]/.test(C);
		x = x === void 0 ? 6 : /[gprs]/.test(C) ? Math.max(1, Math.min(21, x)) : Math.max(0, Math.min(20, x));
		function O(e) {
			var a = w, o = T, s, f, p;
			if (C === "c") o = E(e) + o, e = "";
			else {
				e = +e;
				var g = e < 0 || 1 / e < 0;
				if (e = isNaN(e) ? v : E(Math.abs(e), x), S && (e = c(e)), g && +e == 0 && i !== "+" && (g = !1), a = (g ? i === "(" ? i : _ : i === "-" || i === "(" ? "" : i) + a, o = (C === "s" ? h[8 + l / 3] : "") + o + (g && i === "(" ? ")" : ""), D) {
					for (s = -1, f = e.length; ++s < f;) if (p = e.charCodeAt(s), 48 > p || p > 57) {
						o = (p === 46 ? u + e.slice(s + 1) : e.slice(s)) + o, e = e.slice(0, s);
						break;
					}
				}
			}
			b && !m && (e = t(e, 1 / 0));
			var O = a.length + e.length + o.length, k = O < y ? Array(y - O + 1).join(n) : "";
			switch (b && m && (e = t(k + e, k.length ? y - o.length : 1 / 0), k = ""), r) {
				case "<":
					e = a + e + o + k;
					break;
				case "=":
					e = a + k + e + o;
					break;
				case "^":
					e = k.slice(0, O = k.length >> 1) + a + e + o + k.slice(O);
					break;
				default: e = k + a + e + o;
			}
			return d(e);
		}
		return O.toString = function() {
			return e + "";
		}, O;
	}
	function b(e, t) {
		var r = y((e = o(e), e.type = "f", e)), i = Math.max(-8, Math.min(8, Math.floor(n(t) / 3))) * 3, a = 10 ** -i, s = h[8 + i / 3];
		return function(e) {
			return r(a * e) + s;
		};
	}
	return {
		format: y,
		formatPrefix: b
	};
}
var _, v, y;
b({
	thousands: ",",
	grouping: [3],
	currency: ["$", ""]
});
function b(e) {
	return _ = g(e), v = _.format, y = _.formatPrefix, _;
}
//#endregion
export { y as i, o as n, v as r, n as t };

//# sourceMappingURL=defaultLocale-2bEbhetO-QGFVckfi.js.map