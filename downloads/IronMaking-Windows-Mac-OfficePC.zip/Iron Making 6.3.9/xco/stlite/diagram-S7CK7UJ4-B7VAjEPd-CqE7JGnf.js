import { M as e, N as t, T as n, a7 as r, ai as i, aj as a, al as o, an as s, ap as c, b6 as l, bB as u, br as d, bw as f, bx as p, by as m, bz as h, c as g } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
import { t as _ } from "./chunk-JWPE2WC7-BuMGiM24-C4YAbtTB.js";
import { i as v } from "./cynefin-OW5HDTMX--IlWkCwH-DhMvmN4k.js";
import { t as y } from "./chunk-2Q5K7J3B-5AANKyYA-BUoajoM4.js";
//#region ../react/build/diagram-S7CK7UJ4-B7VAjEPd.js
var b = /[─━│┃└┗├┣]/, x = /[└┗├┣]/, S = /[─━]/, C = /^[\s│┃]+$/, w = /^\s*(title[\t ]|accTitle[\t ]*:|accDescr[\t ]*[:{])/, T = /^\s*%%/, E = "    ";
function D(e) {
	return e.some((e) => b.test(e));
}
g(D, "isBoxDrawingFormat");
function O(e) {
	for (let t of e) {
		let e = x.exec(t);
		if (e?.index && e.index > 0) return e.index;
	}
	return 4;
}
g(O, "inferSegmentWidth");
function k(e, t) {
	return e.replace(/\bline\s+(\d+)\b/gi, (e, n) => {
		let r = parseInt(n, 10), i = t.get(r);
		return i ? `line ${i}` : e;
	});
}
g(k, "remapErrorLines");
function A(e) {
	let t = e.split("\n"), n = /* @__PURE__ */ new Map(), r = -1;
	for (let [e, n] of t.entries()) if (n.trim() === "treeView-beta") {
		r = e;
		break;
	}
	if (r === -1) return {
		text: e,
		lineMap: n
	};
	let i = [];
	for (let e = r + 1; e < t.length; e++) {
		let n = t[e];
		n.trim() === "" || T.test(n) || w.test(n) || C.test(n) || i.push(n.replace(/\t/g, "    "));
	}
	if (!D(i)) return {
		text: e,
		lineMap: n
	};
	let a = O(i), o = [], s = 0;
	for (let e = 0; e <= r; e++) o.push(t[e]), s++, n.set(s, e + 1);
	for (let e = r + 1; e < t.length; e++) {
		let r = t[e], i = r.trim(), c = e + 1;
		if (i === "") {
			o.push(r), s++, n.set(s, c);
			continue;
		}
		if (T.test(r)) {
			o.push(r), s++, n.set(s, c);
			continue;
		}
		if (w.test(r)) {
			o.push(r), s++, n.set(s, c);
			continue;
		}
		if (C.test(r)) continue;
		let l = r.replace(/\t/g, "    "), u = x.exec(l);
		if (u?.index !== void 0) {
			let e = u.index, t = Math.round(e / a) + 1, r = e + 1;
			for (; r < l.length && S.test(l[r]);) r++;
			for (; r < l.length && l[r] === " ";) r++;
			let i = l.slice(r).trimEnd();
			if (!i) throw Error(`Line ${c}: Empty node — expected a filename or directory name after the box-drawing prefix`);
			let d = E.repeat(t);
			o.push(d + i), s++, n.set(s, c);
		} else {
			if (/^[\s─━│┃└┗├┣]+$/.test(l)) continue;
			if (b.test(l)) o.push(r), s++, n.set(s, c);
			else {
				if (/^\s+/.test(l)) throw Error(`Line ${c}: Unexpected indentation without box-drawing characters. In box-drawing format, use ├── or └── prefixes for indented nodes.`);
				o.push(r), s++, n.set(s, c);
			}
		}
	}
	return {
		text: o.join("\n"),
		lineMap: n
	};
}
g(A, "preprocessBoxDrawing");
var j = new y(() => ({
	cnt: 1,
	stack: [{
		id: 0,
		level: -1,
		name: "/",
		nodeType: "directory",
		children: []
	}]
})), M = /* @__PURE__ */ g(() => {
	j.reset(), t();
}, "clear"), N = /* @__PURE__ */ g(() => j.records.stack[0], "getRoot"), P = /* @__PURE__ */ g(() => j.records.cnt, "getCount"), F = r.treeView, I = {
	clear: M,
	addNode: /* @__PURE__ */ g((e, t, n, r, i, a) => {
		for (; e <= j.records.stack[j.records.stack.length - 1].level;) j.records.stack.pop();
		let o = {
			id: j.records.cnt++,
			level: e,
			name: t,
			nodeType: n,
			icon: i,
			cssClass: r,
			description: a,
			children: []
		};
		j.records.stack[j.records.stack.length - 1].children.push(o), j.records.stack.push(o);
	}, "addNode"),
	getRoot: N,
	getCount: P,
	getConfig: /* @__PURE__ */ g(() => e(F, o().treeView), "getConfig"),
	getAccTitle: a,
	getAccDescription: i,
	getDiagramTitle: s,
	setAccDescription: m,
	setAccTitle: h,
	setDiagramTitle: u
}, L = /* @__PURE__ */ g((e) => {
	_(e, I);
	for (let t of e.nodes) {
		let e = typeof t.indent == "number" ? t.indent : 0, n = t.name, r = n.endsWith("/");
		r && (n = n.slice(0, -1));
		let i = r ? "directory" : "file", a = t.classAnnotation || void 0, s = t.iconAnnotation, c = s === void 0 ? void 0 : s || "none", l = t.descAnnotation || void 0, u = l ? f(l, o()) : void 0;
		I.addNode(e, n, i, a, c, u);
	}
}, "populate"), R = { parse: /* @__PURE__ */ g(async (e) => {
	let { text: t, lineMap: n } = A(e);
	try {
		let e = await v("treeView", t);
		l.debug(e), L(e);
	} catch (e) {
		throw n.size > 0 && e instanceof Error && (e.message = k(e.message, n)), e;
	}
}, "parse") }, z = {
	prefix: "mermaid-treeview",
	height: 24,
	width: 24,
	icons: {
		folder: { body: "<path fill=\"currentColor\" d=\"M10.59 4.59A2 2 0 0 0 9.17 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.17z\"/>" },
		file: { body: "<path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M6 2a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8.83a2 2 0 0 0-.59-1.42l-4.82-4.82A2 2 0 0 0 13.17 2H6Zm7.5 1.9l4.6 4.6h-3.6a1 1 0 0 1-1-1V3.9Z\" clip-rule=\"evenodd\"/>" }
	}
};
function B(e, t) {
	let n = t?.filenameIcons?.[e];
	if (n) return n;
	let r = e.lastIndexOf(".");
	if (r > 0) {
		let n = e.substring(r).toLowerCase(), i = t?.extensionIcons;
		return i?.[n] ?? i?.[n.slice(1)];
	}
}
g(B, "detectIcon");
function V(e, t) {
	return e.includes(":") ? e : e in z.icons || !t ? `${z.prefix}:${e}` : `${t}:${e}`;
}
g(V, "qualifyIcon");
function H(e, t) {
	if (e.icon !== "none") {
		if (e.icon) return V(e.icon, t.defaultIconPack);
		if (t.showIcons) {
			if (e.nodeType === "file") {
				let n = B(e.name, t);
				if (n === "none") return;
				if (n) return V(n, t.defaultIconPack);
			}
			return `${z.prefix}:${e.nodeType === "directory" ? "folder" : "file"}`;
		}
	}
}
g(H, "getNodeIcon"), d([{
	name: z.prefix,
	icons: z
}]);
var U = 14, W = 4, G = 16, K = /* @__PURE__ */ g(async (e, t) => {
	let n = [], r = /* @__PURE__ */ g((e) => {
		let i = H(e, t);
		i && n.push({
			icon: i,
			node: e
		}), e.children.forEach(r);
	}, "collect");
	r(e);
	let i = await Promise.all(n.map(async ({ icon: e, node: t }) => ({
		id: t.id,
		svg: await c(e, {
			height: U,
			width: U
		})
	})));
	return new Map(i.map(({ id: e, svg: t }) => [e, t]));
}, "resolveNodeIcons"), q = /* @__PURE__ */ g((e, t, n, r, i, a) => {
	let o = r.append("g"), s = "treeView-node-label";
	n.nodeType === "directory" && (s += " treeView-node-dir"), n.cssClass && (s += ` ${n.cssClass}`);
	let c = U + W, l = H(n, i), u = l !== void 0;
	l && o.append("g").attr("class", "treeView-node-icon").attr("transform", `translate(${e + i.paddingX}, ${t + i.paddingY})`).html(a.get(n.id) ?? "");
	let d = o.append("text").text(n.name).attr("dominant-baseline", "middle").attr("class", s), { height: f, width: p } = d.node().getBBox(), m = f + i.paddingY * 2, h = e + i.paddingX + (u ? c : 0);
	d.attr("x", h), d.attr("y", t + m / 2);
	let g = h + p;
	return n.BBox = {
		x: e,
		y: t,
		width: p + i.paddingX * 2 + (u ? c : 0),
		height: m
	}, n.cssClass?.split(/\s+/).includes("highlight") && o.insert("rect", ":first-child").attr("x", e).attr("y", t + 1).attr("width", 0).attr("height", m - 2).attr("rx", 3).attr("class", "treeView-highlight-bg"), {
		node: n,
		nodeGroup: o,
		labelRightEdge: g,
		centerY: t + m / 2
	};
}, "positionLabel"), J = /* @__PURE__ */ g((e, t, n, r, i, a) => e.append("line").attr("x1", t).attr("y1", n).attr("x2", r).attr("y2", i).attr("stroke-width", a).attr("class", "treeView-node-line"), "positionLine"), Y = /* @__PURE__ */ g((e, t, n, r) => {
	let i = 0, a = 0, o = [], s = /* @__PURE__ */ g((e, t, n, s) => {
		let c = s * (n.rowIndent + n.paddingX), l = q(c, i, t, e, n, r);
		o.push(l);
		let { height: u, width: d } = t.BBox;
		J(e, c - n.rowIndent, i + u / 2, c, i + u / 2, n.lineThickness), a = Math.max(a, c + d), i += u;
	}, "drawNode"), c = /* @__PURE__ */ g((t, r = 0) => {
		s(e, t, n, r), t.children.forEach((e) => {
			c(e, r + 1);
		});
		let { x: i, y: a, height: o } = t.BBox;
		if (t.children.length) {
			let { y: r, height: s } = t.children[t.children.length - 1].BBox;
			J(e, i + n.paddingX, a + o, i + n.paddingX, r + s / 2 + n.lineThickness / 2, n.lineThickness);
		}
	}, "processNode");
	c(t);
	let l = o.filter((e) => e.node.description);
	if (l.length > 0) {
		let e = Math.max(...o.map((e) => e.labelRightEdge)) + G;
		for (let t of l) {
			let r = t.nodeGroup.append("text").text(t.node.description).attr("dominant-baseline", "middle").attr("class", "treeView-node-description").attr("x", e).attr("y", t.centerY).node().getBBox();
			a = Math.max(a, e + r.width + n.paddingX);
		}
	}
	for (let e of o) if (e.node.cssClass?.split(/\s+/).includes("highlight")) {
		let t = e.nodeGroup.select(".treeView-highlight-bg");
		if (!t.empty()) {
			let n = a - e.node.BBox.x + 8;
			t.attr("width", n), a = Math.max(a, e.node.BBox.x + n + 2);
		}
	}
	return {
		totalHeight: i,
		totalWidth: a
	};
}, "drawTree"), X = { draw: /* @__PURE__ */ g(async (e, t, r, i) => {
	l.debug("Rendering treeView diagram\n" + e);
	let a = i.db, o = a.getRoot(), s = a.getConfig(), c = p(t), u = c.append("g");
	u.attr("class", "tree-view");
	let { totalHeight: d, totalWidth: f } = Y(u, o, s, await K(o, s));
	c.attr("viewBox", `-${s.lineThickness / 2} 0 ${f} ${d}`), n(c, d, f, s.useMaxWidth);
}, "draw") }, Z = {
	labelFontSize: "16px",
	labelColor: "black",
	lineColor: "black",
	iconColor: "#546e7a",
	descriptionColor: "#6a9955",
	highlightBg: "rgba(255, 193, 7, 0.15)",
	highlightStroke: "#ffc107"
}, Q = {
	db: I,
	renderer: X,
	parser: R,
	styles: /* @__PURE__ */ g(({ treeView: t }) => {
		let { labelFontSize: n, labelColor: r, lineColor: i, iconColor: a, descriptionColor: o, highlightBg: s, highlightStroke: c } = e(Z, t);
		return `
    .treeView-node-label {
        font-size: ${n};
        fill: ${r};
        white-space: pre;
    }
    .treeView-node-dir {
        font-weight: bold;
    }
    .treeView-node-line {
        stroke: ${i};
    }
    .treeView-node-icon {
        color: ${a};
    }
    .treeView-node-description {
        font-size: ${n};
        fill: ${o};
        font-style: italic;
        white-space: pre;
    }
    .treeView-highlight-bg {
        fill: ${s};
        stroke: ${c};
        stroke-width: 1;
    }
    `;
	}, "styles")
};
//#endregion
export { Q as diagram };

//# sourceMappingURL=diagram-S7CK7UJ4-B7VAjEPd-CqE7JGnf.js.map