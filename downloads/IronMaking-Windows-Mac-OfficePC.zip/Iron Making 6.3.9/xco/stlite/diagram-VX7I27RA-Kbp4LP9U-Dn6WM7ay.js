import { r as e } from "./defaultLocale-2bEbhetO-QGFVckfi.js";
import { n as t } from "./ordinal-DkyryJlW-DURmPlUH.js";
import { f as n, o as r } from "./index-CtOUUcfI-DNqIEPU5.js";
import { c as i } from "./transform-B2AI7qp--hg0kwf7R.js";
import { M as a, N as o, T as s, a7 as c, aT as l, ai as u, aj as d, al as f, an as p, av as m, b6 as h, bB as g, bM as _, bx as v, by as y, bz as b, c as x } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
import { t as S } from "./chunk-JWPE2WC7-BuMGiM24-C4YAbtTB.js";
import { i as C } from "./cynefin-OW5HDTMX--IlWkCwH-DhMvmN4k.js";
import { t as w } from "./chunk-POPQ4Y6H-DyYSXPbN-CYLHdqjk.js";
//#region ../react/build/diagram-VX7I27RA-Kbp4LP9U.js
var T, E = (T = class {
	constructor() {
		this.nodes = [], this.levels = /* @__PURE__ */ new Map(), this.outerNodes = [], this.classes = /* @__PURE__ */ new Map(), this.setAccTitle = b, this.getAccTitle = d, this.setDiagramTitle = g, this.getDiagramTitle = p, this.getAccDescription = u, this.setAccDescription = y;
	}
	getNodes() {
		return this.nodes;
	}
	getConfig() {
		let e = c, t = f();
		return a({
			...e.treemap,
			...t.treemap ?? {}
		});
	}
	addNode(e, t) {
		this.nodes.push(e), this.levels.set(e, t), t === 0 && (this.outerNodes.push(e), this.root ??= e);
	}
	getRoot() {
		return {
			name: "",
			children: this.outerNodes
		};
	}
	addClass(e, t) {
		let n = this.classes.get(e) ?? {
			id: e,
			styles: [],
			textStyles: []
		}, r = t.replace(/\\,/g, "§§§").replace(/,/g, ";").replace(/§§§/g, ",").split(";");
		r && r.forEach((e) => {
			l(e) && (n?.textStyles ? n.textStyles.push(e) : n.textStyles = [e]), n?.styles ? n.styles.push(e) : n.styles = [e];
		}), this.classes.set(e, n);
	}
	getClasses() {
		return this.classes;
	}
	getStylesForClass(e) {
		return this.classes.get(e)?.styles ?? [];
	}
	clear() {
		o(), this.nodes = [], this.levels = /* @__PURE__ */ new Map(), this.outerNodes = [], this.classes = /* @__PURE__ */ new Map(), this.root = void 0;
	}
}, x(T, "TreeMapDB"), T);
function D(e) {
	if (!e.length) return [];
	let t = [], n = [];
	return e.forEach((e) => {
		let r = {
			name: e.name,
			children: e.type === "Leaf" ? void 0 : []
		};
		for (r.classSelector = e?.classSelector, e?.cssCompiledStyles && (r.cssCompiledStyles = e.cssCompiledStyles), e.type === "Leaf" && e.value !== void 0 && (r.value = e.value); n.length > 0 && n[n.length - 1].level >= e.level;) n.pop();
		if (n.length === 0) t.push(r);
		else {
			let e = n[n.length - 1].node;
			e.children ? e.children.push(r) : e.children = [r];
		}
		e.type !== "Leaf" && n.push({
			node: r,
			level: e.level
		});
	}), t;
}
x(D, "buildHierarchy");
var O = /* @__PURE__ */ x((e, t) => {
	S(e, t);
	let n = [];
	for (let n of e.TreemapRows ?? []) n.$type === "ClassDefStatement" && t.addClass(n.className ?? "", n.styleText ?? "");
	for (let r of e.TreemapRows ?? []) {
		let e = r.item;
		if (!e) continue;
		let i = r.indent ? parseInt(r.indent) : 0, a = k(e), o = e.classSelector ? t.getStylesForClass(e.classSelector) : [], s = o.length > 0 ? o : void 0, c = {
			level: i,
			name: a,
			type: e.$type,
			value: e.value,
			classSelector: e.classSelector,
			cssCompiledStyles: s
		};
		n.push(c);
	}
	let r = D(n), i = /* @__PURE__ */ x((e, n) => {
		for (let r of e) t.addNode(r, n), r.children && r.children.length > 0 && i(r.children, n + 1);
	}, "addNodesRecursively");
	i(r, 0);
}, "populate"), k = /* @__PURE__ */ x((e) => e.name ? String(e.name) : "", "getItemName"), A = {
	parser: { yy: void 0 },
	parse: /* @__PURE__ */ x(async (e) => {
		try {
			let t = await C("treemap", e);
			h.debug("Treemap AST:", t);
			let n = A.parser?.yy;
			if (!(n instanceof E)) throw Error("parser.parser?.yy was not a TreemapDB. This is due to a bug within Mermaid, please report this issue at https://github.com/mermaid-js/mermaid/issues.");
			O(t, n);
		} catch (e) {
			throw h.error("Error parsing treemap:", e), e;
		}
	}, "parse")
}, j = 10, M = 10, N = 25, P = {
	draw: /* @__PURE__ */ x((a, o, c, l) => {
		let u = l.db, d = u.getConfig(), p = d.padding ?? j, m = u.getDiagramTitle(), g = u.getRoot(), { themeVariables: y } = f();
		if (!g) return;
		let b = m ? 30 : 0, S = v(o), C = d.nodeWidth ? d.nodeWidth * M : 960, T = d.nodeHeight ? d.nodeHeight * M : 500, E = C, D = T + b;
		S.attr("viewBox", `0 0 ${E} ${D}`), s(S, D, E, d.useMaxWidth);
		let O;
		try {
			let t = d.valueFormat || ",";
			if (t === "$0,0") O = /* @__PURE__ */ x((t) => "$" + e(",")(t), "valueFormat");
			else if (t.startsWith("$") && t.includes(",")) {
				let n = /\.\d+/.exec(t), r = n ? n[0] : "";
				O = /* @__PURE__ */ x((t) => "$" + e("," + r)(t), "valueFormat");
			} else if (t.startsWith("$")) {
				let n = t.substring(1);
				O = /* @__PURE__ */ x((t) => "$" + e(n || "")(t), "valueFormat");
			} else O = e(t);
		} catch (t) {
			h.error("Error creating format function:", t), O = e(",");
		}
		let k = t().range([
			"transparent",
			y.cScale0,
			y.cScale1,
			y.cScale2,
			y.cScale3,
			y.cScale4,
			y.cScale5,
			y.cScale6,
			y.cScale7,
			y.cScale8,
			y.cScale9,
			y.cScale10,
			y.cScale11
		]), A = t().range([
			"transparent",
			y.cScalePeer0,
			y.cScalePeer1,
			y.cScalePeer2,
			y.cScalePeer3,
			y.cScalePeer4,
			y.cScalePeer5,
			y.cScalePeer6,
			y.cScalePeer7,
			y.cScalePeer8,
			y.cScalePeer9,
			y.cScalePeer10,
			y.cScalePeer11
		]), P = t().range([
			y.cScaleLabel0,
			y.cScaleLabel1,
			y.cScaleLabel2,
			y.cScaleLabel3,
			y.cScaleLabel4,
			y.cScaleLabel5,
			y.cScaleLabel6,
			y.cScaleLabel7,
			y.cScaleLabel8,
			y.cScaleLabel9,
			y.cScaleLabel10,
			y.cScaleLabel11
		]);
		m && S.append("text").attr("x", E / 2).attr("y", b / 2).attr("class", "treemapTitle").attr("text-anchor", "middle").attr("dominant-baseline", "middle").text(m);
		let F = S.append("g").attr("transform", `translate(0, ${b})`).attr("class", "treemapContainer"), I = r(g).sum((e) => e.value ?? 0).sort((e, t) => (t.value ?? 0) - (e.value ?? 0)), L = n().size([C, T]).paddingTop((e) => e.children && e.children.length > 0 ? N + M : 0).paddingInner(p).paddingLeft((e) => e.children && e.children.length > 0 ? M : 0).paddingRight((e) => e.children && e.children.length > 0 ? M : 0).paddingBottom((e) => e.children && e.children.length > 0 ? M : 0).round(!0)(I), R = L.descendants().filter((e) => e.children && e.children.length > 0), z = F.selectAll(".treemapSection").data(R).enter().append("g").attr("class", "treemapSection").attr("transform", (e) => `translate(${e.x0},${e.y0})`);
		z.append("rect").attr("width", (e) => e.x1 - e.x0).attr("height", N).attr("class", "treemapSectionHeader").attr("fill", "none").attr("fill-opacity", .6).attr("stroke-width", .6).attr("style", (e) => e.depth === 0 ? "display: none;" : ""), z.append("clipPath").attr("id", (e, t) => `clip-section-${o}-${t}`).append("rect").attr("width", (e) => Math.max(0, e.x1 - e.x0 - 12)).attr("height", N), z.append("rect").attr("width", (e) => e.x1 - e.x0).attr("height", (e) => e.y1 - e.y0).attr("class", (e, t) => `treemapSection section${t}`).attr("fill", (e) => k(e.data.name)).attr("fill-opacity", .6).attr("stroke", (e) => A(e.data.name)).attr("stroke-width", 2).attr("stroke-opacity", .4).attr("style", (e) => {
			if (e.depth === 0) return "display: none;";
			let t = _({ cssCompiledStyles: e.data.cssCompiledStyles });
			return t.nodeStyles + ";" + t.borderStyles.join(";");
		}), z.append("text").attr("class", "treemapSectionLabel").attr("x", 6).attr("y", N / 2).attr("dominant-baseline", "middle").text((e) => e.depth === 0 ? "" : e.data.name).attr("font-weight", "bold").attr("clip-path", (e, t) => `url(#clip-section-${o}-${t})`).attr("style", (e) => e.depth === 0 ? "display: none;" : "dominant-baseline: middle; font-size: 12px; fill:" + P(e.data.name) + "; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" + _({ cssCompiledStyles: e.data.cssCompiledStyles }).labelStyles.replace("color:", "fill:")).each(function(e) {
			if (e.depth === 0) return;
			let t = i(this), n = e.data.name;
			t.text(n);
			let r = e.x1 - e.x0, a;
			a = d.showValues !== !1 && e.value ? r - 10 - 30 - 10 - 6 : r - 6 - 6;
			let o = Math.max(15, a), s = t.node();
			if (s.getComputedTextLength() > o) {
				let e = n;
				for (; e.length > 0;) {
					if (e = n.substring(0, e.length - 1), e.length === 0) {
						t.text("..."), s.getComputedTextLength() > o && t.text("");
						break;
					}
					if (t.text(e + "..."), s.getComputedTextLength() <= o) break;
				}
			}
		}), d.showValues !== !1 && z.append("text").attr("class", "treemapSectionValue").attr("x", (e) => e.x1 - e.x0 - 10).attr("y", N / 2).attr("text-anchor", "end").attr("dominant-baseline", "middle").text((e) => e.value ? O(e.value) : "").attr("font-style", "italic").attr("style", (e) => e.depth === 0 ? "display: none;" : "text-anchor: end; dominant-baseline: middle; font-size: 10px; fill:" + P(e.data.name) + "; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" + _({ cssCompiledStyles: e.data.cssCompiledStyles }).labelStyles.replace("color:", "fill:"));
		let B = L.leaves(), V = B.length > 20, H = V ? 16 : 38, U = V ? 14 : 28, W = V ? 4 : 8, G = V ? 4 : 6, K = V ? 2 : 4, q = V ? 8 : 10, J = V ? 1 : 2, Y = F.selectAll(".treemapLeafGroup").data(B).enter().append("g").attr("class", (e, t) => `treemapNode treemapLeafGroup leaf${t}${e.data.classSelector ? ` ${e.data.classSelector}` : ""}x`).attr("transform", (e) => `translate(${e.x0},${e.y0})`);
		Y.append("rect").attr("width", (e) => e.x1 - e.x0).attr("height", (e) => e.y1 - e.y0).attr("class", "treemapLeaf").attr("fill", (e) => e.parent ? k(e.parent.data.name) : k(e.data.name)).attr("style", (e) => _({ cssCompiledStyles: e.data.cssCompiledStyles }).nodeStyles).attr("fill-opacity", .3).attr("stroke", (e) => e.parent ? k(e.parent.data.name) : k(e.data.name)).attr("stroke-width", 3), Y.append("clipPath").attr("id", (e, t) => `clip-${o}-${t}`).append("rect").attr("width", (e) => Math.max(0, e.x1 - e.x0 - 4)).attr("height", (e) => Math.max(0, e.y1 - e.y0 - 4)), Y.append("text").attr("class", "treemapLabel").attr("x", (e) => (e.x1 - e.x0) / 2).attr("y", (e) => (e.y1 - e.y0) / 2).attr("style", (e) => `text-anchor: middle; dominant-baseline: middle; font-size: ${H}px;fill:` + P(e.data.name) + ";" + _({ cssCompiledStyles: e.data.cssCompiledStyles }).labelStyles.replace("color:", "fill:")).attr("clip-path", (e, t) => `url(#clip-${o}-${t})`).text((e) => e.data.name).each(function(e) {
			let t = i(this), n = e.x1 - e.x0, r = e.y1 - e.y0, a = t.node(), o = n - 2 * K, s = r - 2 * K;
			if (o < q || s < q) {
				t.style("display", "none");
				return;
			}
			let c = parseInt(t.style("font-size"), 10), l = .6;
			for (; a.getComputedTextLength() > o && c > W;) c--, t.style("font-size", `${c}px`);
			let u = Math.max(G, Math.min(U, Math.round(c * l))), d = c + J + u;
			for (; d > s && c > W && (c--, u = Math.max(G, Math.min(U, Math.round(c * l))), !(u < G && c === W));) t.style("font-size", `${c}px`), d = c + J + u;
			t.style("font-size", `${c}px`), V ? (c < W || s < W) && t.style("display", "none") : (a.getComputedTextLength() > o || c < W || s < c) && t.style("display", "none");
		}), d.showValues !== !1 && Y.append("text").attr("class", "treemapValue").attr("x", (e) => (e.x1 - e.x0) / 2).attr("y", function(e) {
			return (e.y1 - e.y0) / 2;
		}).attr("style", (e) => `text-anchor: middle; dominant-baseline: hanging; font-size: ${U}px;fill:` + P(e.data.name) + ";" + _({ cssCompiledStyles: e.data.cssCompiledStyles }).labelStyles.replace("color:", "fill:")).attr("clip-path", (e, t) => `url(#clip-${o}-${t})`).text((e) => e.value ? O(e.value) : "").each(function(e) {
			let t = i(this), n = this.parentNode;
			if (!n) {
				t.style("display", "none");
				return;
			}
			let r = i(n).select(".treemapLabel");
			if (r.empty() || r.style("display") === "none") {
				t.style("display", "none");
				return;
			}
			let a = parseFloat(r.style("font-size")), o = Math.max(G, Math.min(U, Math.round(a * .6)));
			t.style("font-size", `${o}px`);
			let s = (e.y1 - e.y0) / 2 + a / 2 + J;
			t.attr("y", s);
			let c = e.x1 - e.x0, l = e.y1 - e.y0 - 4, u = c - 2 * K;
			t.node().getComputedTextLength() > u || s + o > l || o < G ? t.style("display", "none") : t.style("display", null);
		});
		let X = d.diagramPadding ?? 8;
		w(S, X, "flowchart", d?.useMaxWidth || !1);
	}, "draw"),
	getClasses: /* @__PURE__ */ x(function(e, t) {
		return t.db.getClasses();
	}, "getClasses")
}, F = {
	sectionStrokeColor: "black",
	sectionStrokeWidth: "1",
	sectionFillColor: "#efefef",
	leafStrokeColor: "black",
	leafStrokeWidth: "1",
	leafFillColor: "#efefef",
	labelFontSize: "12px",
	valueFontSize: "10px",
	titleFontSize: "14px"
}, I = {
	parser: A,
	get db() {
		return new E();
	},
	renderer: P,
	styles: /* @__PURE__ */ x(({ treemap: e } = {}) => {
		let t = m(), n = f(), r = a(t, n.themeVariables), i = a(F, e), o = i.titleColor ?? r.titleColor, s = i.labelColor ?? r.textColor, c = i.valueColor ?? r.textColor;
		return `
  .treemapNode.section {
    stroke: ${i.sectionStrokeColor};
    stroke-width: ${i.sectionStrokeWidth};
    fill: ${i.sectionFillColor};
  }
  .treemapNode.leaf {
    stroke: ${i.leafStrokeColor};
    stroke-width: ${i.leafStrokeWidth};
    fill: ${i.leafFillColor};
  }
  .treemapLabel {
    fill: ${s};
    font-size: ${i.labelFontSize};
  }
  .treemapValue {
    fill: ${c};
    font-size: ${i.valueFontSize};
  }
  .treemapTitle {
    fill: ${o};
    font-size: ${i.titleFontSize};
  }
  `;
	}, "getStyles")
};
//#endregion
export { I as diagram };

//# sourceMappingURL=diagram-VX7I27RA-Kbp4LP9U-Dn6WM7ay.js.map