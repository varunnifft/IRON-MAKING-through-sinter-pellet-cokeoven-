import { c as e, e as t } from "./es6-BxevHr5y-Dmh0kddl.js";
//#region ../react/build/downloader-CZ7qD7NY.js
var { WritableStream: n, TransformStream: r, DOMException: i, Blob: a } = e, { GONE: o } = t, s = /constructor/i.test(window.HTMLElement), c = class {
	constructor(e = "unkown") {
		this.name = e, this.kind = "file";
	}
	async getFile() {
		throw new i(...o);
	}
	async isSameEntry(e) {
		return this === e;
	}
	async createWritable(e = {}) {
		let t = await navigator.serviceWorker?.getRegistration(), i = document.createElement("a"), o = new r(), c = o.writable;
		if (i.download = this.name, s || !t) {
			let e = [];
			o.readable.pipeTo(new n({
				write(t) {
					e.push(new a([t]));
				},
				close() {
					let t = new a(e, { type: "application/octet-stream; charset=utf-8" });
					e = [], i.href = URL.createObjectURL(t), i.click(), setTimeout(() => URL.revokeObjectURL(i.href), 1e4);
				}
			}));
		} else {
			let { writable: i, readablePort: a } = new h(n), s = encodeURIComponent(this.name).replace(/['()]/g, escape).replace(/\*/g, "%2A"), c = {
				"content-disposition": "attachment; filename*=UTF-8''" + s,
				"content-type": "application/octet-stream; charset=utf-8",
				...e.size ? { "content-length": e.size } : {}
			}, l = setTimeout(() => t.active.postMessage(0), 1e4);
			o.readable.pipeThrough(new r({ transform(e, t) {
				if (e instanceof Uint8Array) return t.enqueue(e);
				let n = new Response(e).body.getReader(), r = (e) => n.read().then((e) => e.done ? 0 : r(t.enqueue(e.value)));
				return r();
			} })).pipeTo(i).finally(() => {
				clearInterval(l);
			}), t.active.postMessage({
				url: t.scope + s,
				headers: c,
				readablePort: a
			}, [a]);
			let u = document.createElement("iframe");
			u.hidden = !0, u.src = t.scope + s, document.body.appendChild(u);
		}
		return c.getWriter();
	}
}, l = 0, u = 0, d = 1, f = 1, p = 2, m = class {
	constructor(e) {
		e.onmessage = (e) => this._onMessage(e.data), this._port = e, this._resetReady();
	}
	start(e) {
		return this._controller = e, this._readyPromise;
	}
	write(e) {
		let t = {
			type: l,
			chunk: e
		};
		return this._port.postMessage(t, [e.buffer]), this._resetReady(), this._readyPromise;
	}
	close() {
		this._port.postMessage({ type: p }), this._port.close();
	}
	abort(e) {
		this._port.postMessage({
			type: f,
			reason: e
		}), this._port.close();
	}
	_onMessage(e) {
		e.type === u && this._resolveReady(), e.type === d && this._onError(e.reason);
	}
	_onError(e) {
		this._controller.error(e), this._rejectReady(e), this._port.close();
	}
	_resetReady() {
		this._readyPromise = new Promise((e, t) => {
			this._readyResolve = e, this._readyReject = t;
		}), this._readyPending = !0;
	}
	_resolveReady() {
		this._readyResolve(), this._readyPending = !1;
	}
	_rejectReady(e) {
		this._readyPending || this._resetReady(), this._readyPromise.catch(() => {}), this._readyReject(e), this._readyPending = !1;
	}
}, h = class {
	constructor(e) {
		let t = new MessageChannel();
		this.readablePort = t.port1, this.writable = new e(new m(t.port2));
	}
};
//#endregion
export { c as FileHandle };

//# sourceMappingURL=downloader-CZ7qD7NY-DUsyx4zO.js.map