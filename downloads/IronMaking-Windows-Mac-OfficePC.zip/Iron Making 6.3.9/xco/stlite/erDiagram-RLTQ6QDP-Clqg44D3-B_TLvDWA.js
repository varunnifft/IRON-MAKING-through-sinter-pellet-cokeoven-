import { c as e } from "./transform-B2AI7qp--hg0kwf7R.js";
import { N as t, Q as n, _ as r, ai as i, aj as a, am as o, an as s, ao as c, aq as l, b6 as u, bB as d, bX as f, bs as p, bu as m, by as h, bz as g, c as _ } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
import { t as v } from "./channel-CvOKZlC4-n3NLqOCr.js";
import { t as y } from "./chunk-XXDRQBXY-DcJOot-0-BYhvkPGZ.js";
import { t as b } from "./chunk-POPQ4Y6H-DyYSXPbN-CYLHdqjk.js";
//#region ../react/build/erDiagram-RLTQ6QDP-Clqg44D3.js
var x = function() {
	var e = /* @__PURE__ */ _(function(e, t, n, r) {
		for (n ||= {}, r = e.length; r--; n[e[r]] = t);
		return n;
	}, "o"), t = [
		6,
		9,
		21,
		23,
		25,
		27,
		34,
		37,
		38,
		39,
		40,
		41,
		43,
		46,
		47,
		51,
		53,
		54,
		55
	], n = [2, 2], r = [1, 7], i = [1, 9], a = [1, 10], o = [1, 11], s = [1, 12], c = [1, 30], l = [1, 23], u = [1, 24], d = [1, 25], f = [1, 26], p = [1, 27], m = [1, 19], h = [1, 28], g = [1, 29], v = [1, 20], y = [1, 18], b = [1, 21], x = [1, 22], S = [2, 6], C = [
		6,
		9,
		21,
		23,
		25,
		27,
		33,
		34,
		37,
		38,
		39,
		40,
		41,
		43,
		46,
		47,
		51,
		53,
		54,
		55
	], w = [1, 36], T = [1, 37], E = [1, 38], D = [1, 39], O = [1, 40], k = [
		6,
		9,
		12,
		14,
		16,
		19,
		20,
		21,
		23,
		25,
		27,
		33,
		34,
		37,
		38,
		39,
		40,
		41,
		43,
		46,
		47,
		50,
		51,
		53,
		54,
		55,
		69,
		70,
		71,
		72,
		73
	], A = [1, 46], j = [1, 47], M = [1, 57], N = [
		43,
		51,
		53,
		54,
		55,
		74,
		75
	], P = [1, 70], F = [1, 68], I = [1, 65], L = [1, 69], R = [1, 71], z = [
		6,
		9,
		12,
		16,
		21,
		23,
		25,
		27,
		33,
		34,
		37,
		38,
		39,
		40,
		41,
		43,
		44,
		45,
		46,
		47,
		51,
		52,
		53,
		54,
		55,
		69,
		70,
		71,
		72,
		73
	], B = [1, 78], V = [1, 77], H = [1, 76], U = [
		69,
		70,
		71,
		72,
		73
	], W = [1, 91], G = [
		6,
		9,
		45,
		50
	], K = [
		6,
		9,
		12,
		44,
		45,
		50,
		51,
		52
	], q = [1, 101], J = [1, 100], Y = [1, 99], X = [18, 61], ee = [1, 110], te = [1, 109], ne = [
		20,
		43,
		51,
		53,
		54,
		55
	], Z = [
		18,
		61,
		64,
		66
	], Q = {
		trace: /* @__PURE__ */ _(function() {}, "trace"),
		yy: {},
		symbols_: {
			error: 2,
			start: 3,
			ER_DIAGRAM: 4,
			document: 5,
			EOF: 6,
			line: 7,
			statement: 8,
			NEWLINE: 9,
			entityName: 10,
			relSpec: 11,
			COLON: 12,
			role: 13,
			STYLE_SEPARATOR: 14,
			idList: 15,
			BLOCK_START: 16,
			attributes: 17,
			BLOCK_STOP: 18,
			SQS: 19,
			SQE: 20,
			title: 21,
			title_value: 22,
			acc_title: 23,
			acc_title_value: 24,
			acc_descr: 25,
			acc_descr_value: 26,
			acc_descr_multiline_value: 27,
			direction: 28,
			classDefStatement: 29,
			classStatement: 30,
			styleStatement: 31,
			subgraphHeader: 32,
			END: 33,
			SUBGRAPH: 34,
			separator: 35,
			subgraphTitle: 36,
			direction_tb: 37,
			direction_bt: 38,
			direction_rl: 39,
			direction_lr: 40,
			CLASSDEF: 41,
			stylesOpt: 42,
			UNICODE_TEXT: 43,
			STYLE_TEXT: 44,
			COMMA: 45,
			CLASS: 46,
			STYLE: 47,
			style: 48,
			styleComponent: 49,
			SEMI: 50,
			NUM: 51,
			BRKT: 52,
			ENTITY_NAME: 53,
			DECIMAL_NUM: 54,
			ENTITY_ONE: 55,
			attribute: 56,
			attributeType: 57,
			attributeName: 58,
			attributeKeyTypeList: 59,
			attributeComment: 60,
			ATTRIBUTE_WORD: 61,
			"?": 62,
			attributeKeyType: 63,
			",": 64,
			ATTRIBUTE_KEY: 65,
			COMMENT: 66,
			cardinality: 67,
			relType: 68,
			ZERO_OR_ONE: 69,
			ZERO_OR_MORE: 70,
			ONE_OR_MORE: 71,
			ONLY_ONE: 72,
			MD_PARENT: 73,
			NON_IDENTIFYING: 74,
			IDENTIFYING: 75,
			WORD: 76,
			$accept: 0,
			$end: 1
		},
		terminals_: {
			2: "error",
			4: "ER_DIAGRAM",
			6: "EOF",
			9: "NEWLINE",
			12: "COLON",
			14: "STYLE_SEPARATOR",
			16: "BLOCK_START",
			18: "BLOCK_STOP",
			19: "SQS",
			20: "SQE",
			21: "title",
			22: "title_value",
			23: "acc_title",
			24: "acc_title_value",
			25: "acc_descr",
			26: "acc_descr_value",
			27: "acc_descr_multiline_value",
			33: "END",
			34: "SUBGRAPH",
			37: "direction_tb",
			38: "direction_bt",
			39: "direction_rl",
			40: "direction_lr",
			41: "CLASSDEF",
			43: "UNICODE_TEXT",
			44: "STYLE_TEXT",
			45: "COMMA",
			46: "CLASS",
			47: "STYLE",
			50: "SEMI",
			51: "NUM",
			52: "BRKT",
			53: "ENTITY_NAME",
			54: "DECIMAL_NUM",
			55: "ENTITY_ONE",
			61: "ATTRIBUTE_WORD",
			62: "?",
			64: ",",
			65: "ATTRIBUTE_KEY",
			66: "COMMENT",
			69: "ZERO_OR_ONE",
			70: "ZERO_OR_MORE",
			71: "ONE_OR_MORE",
			72: "ONLY_ONE",
			73: "MD_PARENT",
			74: "NON_IDENTIFYING",
			75: "IDENTIFYING",
			76: "WORD"
		},
		productions_: [
			0,
			[3, 3],
			[5, 0],
			[5, 2],
			[7, 1],
			[7, 1],
			[7, 1],
			[8, 5],
			[8, 9],
			[8, 7],
			[8, 7],
			[8, 4],
			[8, 6],
			[8, 3],
			[8, 5],
			[8, 1],
			[8, 3],
			[8, 7],
			[8, 9],
			[8, 6],
			[8, 8],
			[8, 4],
			[8, 6],
			[8, 2],
			[8, 2],
			[8, 2],
			[8, 1],
			[8, 1],
			[8, 1],
			[8, 1],
			[8, 1],
			[8, 3],
			[32, 3],
			[32, 6],
			[36, 1],
			[36, 2],
			[28, 1],
			[28, 1],
			[28, 1],
			[28, 1],
			[29, 4],
			[15, 1],
			[15, 1],
			[15, 3],
			[15, 3],
			[30, 3],
			[31, 4],
			[42, 1],
			[42, 3],
			[48, 1],
			[48, 2],
			[35, 1],
			[35, 1],
			[35, 1],
			[49, 1],
			[49, 1],
			[49, 1],
			[49, 1],
			[10, 1],
			[10, 1],
			[10, 1],
			[10, 1],
			[10, 1],
			[17, 1],
			[17, 2],
			[56, 2],
			[56, 3],
			[56, 3],
			[56, 4],
			[57, 1],
			[57, 2],
			[58, 1],
			[59, 1],
			[59, 3],
			[63, 1],
			[60, 1],
			[11, 3],
			[67, 1],
			[67, 1],
			[67, 1],
			[67, 1],
			[67, 1],
			[68, 1],
			[68, 1],
			[13, 1],
			[13, 1],
			[13, 1]
		],
		performAction: /* @__PURE__ */ _(function(e, t, n, r, i, a, o) {
			var s = a.length - 1;
			switch (i) {
				case 1: break;
				case 2:
					this.$ = [];
					break;
				case 3:
					this.$ = a[s - 1].concat(a[s]);
					break;
				case 4:
					this.$ = a[s];
					break;
				case 5:
				case 6:
					this.$ = [];
					break;
				case 7:
					r.addEntity(a[s - 4]), r.addEntity(a[s - 2]), r.addRelationship(a[s - 4], a[s], a[s - 2], a[s - 3]), this.$ = [a[s - 4], a[s - 2]];
					break;
				case 8:
					r.addEntity(a[s - 8]), r.addEntity(a[s - 4]), r.addRelationship(a[s - 8], a[s], a[s - 4], a[s - 5]), r.setClass([a[s - 8]], a[s - 6]), r.setClass([a[s - 4]], a[s - 2]), this.$ = [a[s - 8], a[s - 4]];
					break;
				case 9:
					r.addEntity(a[s - 6]), r.addEntity(a[s - 2]), r.addRelationship(a[s - 6], a[s], a[s - 2], a[s - 3]), r.setClass([a[s - 6]], a[s - 4]), this.$ = [a[s - 6], a[s - 2]];
					break;
				case 10:
					r.addEntity(a[s - 6]), r.addEntity(a[s - 4]), r.addRelationship(a[s - 6], a[s], a[s - 4], a[s - 5]), r.setClass([a[s - 4]], a[s - 2]), this.$ = [a[s - 6], a[s - 4]];
					break;
				case 11:
					r.addEntity(a[s - 3]), r.addAttributes(a[s - 3], a[s - 1]), this.$ = [a[s - 3]];
					break;
				case 12:
					r.addEntity(a[s - 5]), r.addAttributes(a[s - 5], a[s - 1]), r.setClass([a[s - 5]], a[s - 3]), this.$ = [a[s - 5]];
					break;
				case 13:
					r.addEntity(a[s - 2]), this.$ = [a[s - 2]];
					break;
				case 14:
					r.addEntity(a[s - 4]), r.setClass([a[s - 4]], a[s - 2]), this.$ = [a[s - 4]];
					break;
				case 15:
					r.addEntity(a[s]), this.$ = [a[s]];
					break;
				case 16:
					r.addEntity(a[s - 2]), r.setClass([a[s - 2]], a[s]), this.$ = [a[s - 2]];
					break;
				case 17:
					r.addEntity(a[s - 6], a[s - 4]), r.addAttributes(a[s - 6], a[s - 1]), this.$ = [a[s - 6]];
					break;
				case 18:
					r.addEntity(a[s - 8], a[s - 6]), r.addAttributes(a[s - 8], a[s - 1]), r.setClass([a[s - 8]], a[s - 3]), this.$ = [a[s - 8]];
					break;
				case 19:
					r.addEntity(a[s - 5], a[s - 3]), this.$ = [a[s - 5]];
					break;
				case 20:
					r.addEntity(a[s - 7], a[s - 5]), r.setClass([a[s - 7]], a[s - 2]), this.$ = [a[s - 7]];
					break;
				case 21:
					r.addEntity(a[s - 3], a[s - 1]);
					break;
				case 22:
					r.addEntity(a[s - 5], a[s - 3]), r.setClass([a[s - 5]], a[s]);
					break;
				case 23:
				case 24:
					this.$ = a[s].trim(), r.setAccTitle(this.$);
					break;
				case 25:
				case 26:
					this.$ = a[s].trim(), r.setAccDescription(this.$);
					break;
				case 27:
					r.subgraphDepth ? this.$ = a[s] : (r.setDirection(a[s].value), this.$ = []);
					break;
				case 31:
					r.subgraphDepth = (r.subgraphDepth || 1) - 1, this.$ = r.addSubGraph({ text: a[s - 2].id }, a[s - 1], { text: a[s - 2].text });
					break;
				case 32:
					r.subgraphDepth = (r.subgraphDepth || 0) + 1, this.$ = {
						id: a[s - 1],
						text: a[s - 1]
					};
					break;
				case 33:
					r.subgraphDepth = (r.subgraphDepth || 0) + 1, this.$ = {
						id: a[s - 4],
						text: a[s - 2]
					};
					break;
				case 34:
				case 59:
				case 60:
				case 61:
				case 62:
				case 86:
					this.$ = a[s];
					break;
				case 35:
					this.$ = a[s - 1] + " " + a[s];
					break;
				case 36:
					this.$ = {
						stmt: "dir",
						value: "TB"
					};
					break;
				case 37:
					this.$ = {
						stmt: "dir",
						value: "BT"
					};
					break;
				case 38:
					this.$ = {
						stmt: "dir",
						value: "RL"
					};
					break;
				case 39:
					this.$ = {
						stmt: "dir",
						value: "LR"
					};
					break;
				case 40:
					this.$ = a[s - 3], r.addClass(a[s - 2], a[s - 1]);
					break;
				case 41:
				case 42:
				case 63:
				case 72:
					this.$ = [a[s]];
					break;
				case 43:
				case 44:
					this.$ = a[s - 2].concat([a[s]]);
					break;
				case 45:
					this.$ = a[s - 2], r.setClass(a[s - 1], a[s]);
					break;
				case 46:
					this.$ = a[s - 3], r.addCssStyles(a[s - 2], a[s - 1]);
					break;
				case 47:
					this.$ = [a[s]];
					break;
				case 48:
					a[s - 2].push(a[s]), this.$ = a[s - 2];
					break;
				case 50:
					this.$ = a[s - 1] + a[s];
					break;
				case 58:
				case 84:
				case 85:
					this.$ = a[s].replace(/"/g, "");
					break;
				case 64:
					a[s].push(a[s - 1]), this.$ = a[s];
					break;
				case 65:
					this.$ = {
						type: a[s - 1],
						name: a[s]
					};
					break;
				case 66:
					this.$ = {
						type: a[s - 2],
						name: a[s - 1],
						keys: a[s]
					};
					break;
				case 67:
					this.$ = {
						type: a[s - 2],
						name: a[s - 1],
						comment: a[s]
					};
					break;
				case 68:
					this.$ = {
						type: a[s - 3],
						name: a[s - 2],
						keys: a[s - 1],
						comment: a[s]
					};
					break;
				case 69:
				case 71:
				case 74:
					this.$ = a[s];
					break;
				case 70:
					this.$ = a[s - 1] + a[s];
					break;
				case 73:
					a[s - 2].push(a[s]), this.$ = a[s - 2];
					break;
				case 75:
					this.$ = a[s].replace(/"/g, "");
					break;
				case 76:
					this.$ = {
						cardA: a[s],
						relType: a[s - 1],
						cardB: a[s - 2]
					};
					break;
				case 77:
					this.$ = r.Cardinality.ZERO_OR_ONE;
					break;
				case 78:
					this.$ = r.Cardinality.ZERO_OR_MORE;
					break;
				case 79:
					this.$ = r.Cardinality.ONE_OR_MORE;
					break;
				case 80:
					this.$ = r.Cardinality.ONLY_ONE;
					break;
				case 81:
					this.$ = r.Cardinality.MD_PARENT;
					break;
				case 82:
					this.$ = r.Identification.NON_IDENTIFYING;
					break;
				case 83: this.$ = r.Identification.IDENTIFYING;
			}
		}, "anonymous"),
		table: [
			{
				3: 1,
				4: [1, 2]
			},
			{ 1: [3] },
			e(t, n, { 5: 3 }),
			{
				6: [1, 4],
				7: 5,
				8: 6,
				9: r,
				10: 8,
				21: i,
				23: a,
				25: o,
				27: s,
				28: 13,
				29: 14,
				30: 15,
				31: 16,
				32: 17,
				34: c,
				37: l,
				38: u,
				39: d,
				40: f,
				41: p,
				43: m,
				46: h,
				47: g,
				51: v,
				53: y,
				54: b,
				55: x
			},
			e(t, S, { 1: [2, 1] }),
			e(C, [2, 3]),
			e(C, [2, 4]),
			e(C, [2, 5]),
			e(C, [2, 15], {
				11: 31,
				67: 35,
				14: [1, 32],
				16: [1, 33],
				19: [1, 34],
				69: w,
				70: T,
				71: E,
				72: D,
				73: O
			}),
			{ 22: [1, 41] },
			{ 24: [1, 42] },
			{ 26: [1, 43] },
			e(C, [2, 26]),
			e(C, [2, 27]),
			e(C, [2, 28]),
			e(C, [2, 29]),
			e(C, [2, 30]),
			e(C, n, { 5: 44 }),
			e(k, [2, 58]),
			e(k, [2, 59]),
			e(k, [2, 60]),
			e(k, [2, 61]),
			e(k, [2, 62]),
			e(C, [2, 36]),
			e(C, [2, 37]),
			e(C, [2, 38]),
			e(C, [2, 39]),
			{
				15: 45,
				43: A,
				44: j
			},
			{
				15: 48,
				43: A,
				44: j
			},
			{
				15: 49,
				43: A,
				44: j
			},
			{
				10: 50,
				43: m,
				51: v,
				53: y,
				54: b,
				55: x
			},
			{
				10: 51,
				43: m,
				51: v,
				53: y,
				54: b,
				55: x
			},
			{
				15: 52,
				43: A,
				44: j
			},
			{
				17: 53,
				18: [1, 54],
				56: 55,
				57: 56,
				61: M
			},
			{
				10: 58,
				43: m,
				51: v,
				53: y,
				54: b,
				55: x
			},
			{
				68: 59,
				74: [1, 60],
				75: [1, 61]
			},
			e(N, [2, 77]),
			e(N, [2, 78]),
			e(N, [2, 79]),
			e(N, [2, 80]),
			e(N, [2, 81]),
			e(C, [2, 23]),
			e(C, [2, 24]),
			e(C, [2, 25]),
			{
				6: [1, 63],
				7: 5,
				8: 6,
				9: r,
				10: 8,
				21: i,
				23: a,
				25: o,
				27: s,
				28: 13,
				29: 14,
				30: 15,
				31: 16,
				32: 17,
				33: [1, 62],
				34: c,
				37: l,
				38: u,
				39: d,
				40: f,
				41: p,
				43: m,
				46: h,
				47: g,
				51: v,
				53: y,
				54: b,
				55: x
			},
			{
				12: P,
				42: 64,
				44: F,
				45: I,
				48: 66,
				49: 67,
				51: L,
				52: R
			},
			e(z, [2, 41]),
			e(z, [2, 42]),
			{
				15: 72,
				43: A,
				44: j,
				45: I
			},
			{
				12: P,
				42: 73,
				44: F,
				45: I,
				48: 66,
				49: 67,
				51: L,
				52: R
			},
			{
				6: B,
				9: V,
				19: [1, 75],
				35: 74,
				50: H
			},
			{
				12: [1, 79],
				14: [1, 80]
			},
			e(C, [2, 16], {
				67: 35,
				11: 81,
				16: [1, 82],
				45: I,
				69: w,
				70: T,
				71: E,
				72: D,
				73: O
			}),
			{ 18: [1, 83] },
			e(C, [2, 13]),
			{
				17: 84,
				18: [2, 63],
				56: 55,
				57: 56,
				61: M
			},
			{
				58: 85,
				61: [1, 86]
			},
			{
				61: [2, 69],
				62: [1, 87]
			},
			{ 20: [1, 88] },
			{
				67: 89,
				69: w,
				70: T,
				71: E,
				72: D,
				73: O
			},
			e(U, [2, 82]),
			e(U, [2, 83]),
			e(C, [2, 31]),
			e(C, S),
			{
				6: B,
				9: V,
				35: 90,
				45: W,
				50: H
			},
			{
				43: [1, 92],
				44: [1, 93]
			},
			e(G, [2, 47], {
				49: 94,
				12: P,
				44: F,
				51: L,
				52: R
			}),
			e(K, [2, 49]),
			e(K, [2, 54]),
			e(K, [2, 55]),
			e(K, [2, 56]),
			e(K, [2, 57]),
			e(C, [2, 45], { 45: I }),
			{
				6: B,
				9: V,
				35: 95,
				45: W,
				50: H
			},
			e(C, [2, 32]),
			{
				10: 97,
				36: 96,
				43: m,
				51: v,
				53: y,
				54: b,
				55: x
			},
			e(C, [2, 51]),
			e(C, [2, 52]),
			e(C, [2, 53]),
			{
				13: 98,
				43: q,
				53: J,
				76: Y
			},
			{
				15: 102,
				43: A,
				44: j
			},
			{
				10: 103,
				43: m,
				51: v,
				53: y,
				54: b,
				55: x
			},
			{
				17: 104,
				18: [1, 105],
				56: 55,
				57: 56,
				61: M
			},
			e(C, [2, 11]),
			{ 18: [2, 64] },
			e(X, [2, 65], {
				59: 106,
				60: 107,
				63: 108,
				65: ee,
				66: te
			}),
			e([
				18,
				61,
				65,
				66
			], [2, 71]),
			{ 61: [2, 70] },
			e(C, [2, 21], {
				14: [1, 112],
				16: [1, 111]
			}),
			e([
				43,
				51,
				53,
				54,
				55
			], [2, 76]),
			e(C, [2, 40]),
			{
				12: P,
				44: F,
				48: 113,
				49: 67,
				51: L,
				52: R
			},
			e(z, [2, 43]),
			e(z, [2, 44]),
			e(K, [2, 50]),
			e(C, [2, 46]),
			{
				10: 115,
				20: [1, 114],
				43: m,
				51: v,
				53: y,
				54: b,
				55: x
			},
			e(ne, [2, 34]),
			e(C, [2, 7]),
			e(C, [2, 84]),
			e(C, [2, 85]),
			e(C, [2, 86]),
			{
				12: [1, 116],
				45: I
			},
			{
				12: [1, 118],
				14: [1, 117]
			},
			{ 18: [1, 119] },
			e(C, [2, 14]),
			e(X, [2, 66], {
				60: 120,
				64: [1, 121],
				66: te
			}),
			e(X, [2, 67]),
			e(Z, [2, 72]),
			e(X, [2, 75]),
			e(Z, [2, 74]),
			{
				17: 122,
				18: [1, 123],
				56: 55,
				57: 56,
				61: M
			},
			{
				15: 124,
				43: A,
				44: j
			},
			e(G, [2, 48], {
				49: 94,
				12: P,
				44: F,
				51: L,
				52: R
			}),
			{
				6: B,
				9: V,
				35: 125,
				50: H
			},
			e(ne, [2, 35]),
			{
				13: 126,
				43: q,
				53: J,
				76: Y
			},
			{
				15: 127,
				43: A,
				44: j
			},
			{
				13: 128,
				43: q,
				53: J,
				76: Y
			},
			e(C, [2, 12]),
			e(X, [2, 68]),
			{
				63: 129,
				65: ee
			},
			{ 18: [1, 130] },
			e(C, [2, 19]),
			e(C, [2, 22], {
				16: [1, 131],
				45: I
			}),
			e(C, [2, 33]),
			e(C, [2, 10]),
			{
				12: [1, 132],
				45: I
			},
			e(C, [2, 9]),
			e(Z, [2, 73]),
			e(C, [2, 17]),
			{
				17: 133,
				18: [1, 134],
				56: 55,
				57: 56,
				61: M
			},
			{
				13: 135,
				43: q,
				53: J,
				76: Y
			},
			{ 18: [1, 136] },
			e(C, [2, 20]),
			e(C, [2, 8]),
			e(C, [2, 18])
		],
		defaultActions: {
			84: [2, 64],
			87: [2, 70]
		},
		parseError: /* @__PURE__ */ _(function(e, t) {
			if (t.recoverable) this.trace(e);
			else {
				var n = Error(e);
				throw n.hash = t, n;
			}
		}, "parseError"),
		parse: /* @__PURE__ */ _(function(e) {
			var t = this, n = [0], r = [], i = [null], a = [], o = this.table, s = "", c = 0, l = 0, u = 2, d = 1, f = a.slice.call(arguments, 1), p = Object.create(this.lexer), m = { yy: {} };
			for (var h in this.yy) Object.prototype.hasOwnProperty.call(this.yy, h) && (m.yy[h] = this.yy[h]);
			p.setInput(e, m.yy), m.yy.lexer = p, m.yy.parser = this, typeof p.yylloc > "u" && (p.yylloc = {});
			var g = p.yylloc;
			a.push(g);
			var v = p.options && p.options.ranges;
			this.parseError = typeof m.yy.parseError == "function" ? m.yy.parseError : Object.getPrototypeOf(this).parseError;
			function y(e) {
				n.length -= 2 * e, i.length -= e, a.length -= e;
			}
			_(y, "popStack");
			function b() {
				var e;
				return e = r.pop() || p.lex() || d, typeof e != "number" && (e instanceof Array && (r = e, e = r.pop()), e = t.symbols_[e] || e), e;
			}
			_(b, "lex");
			for (var x, S, C, w, T = {}, E, D, O, k;;) {
				if (S = n[n.length - 1], this.defaultActions[S] ? C = this.defaultActions[S] : ((x === null || typeof x > "u") && (x = b()), C = o[S] && o[S][x]), typeof C > "u" || !C.length || !C[0]) {
					var A = "";
					for (E in k = [], o[S]) this.terminals_[E] && E > u && k.push("'" + this.terminals_[E] + "'");
					A = p.showPosition ? "Parse error on line " + (c + 1) + ":\n" + p.showPosition() + "\nExpecting " + k.join(", ") + ", got '" + (this.terminals_[x] || x) + "'" : "Parse error on line " + (c + 1) + ": Unexpected " + (x == d ? "end of input" : "'" + (this.terminals_[x] || x) + "'"), this.parseError(A, {
						text: p.match,
						token: this.terminals_[x] || x,
						line: p.yylineno,
						loc: g,
						expected: k
					});
				}
				if (C[0] instanceof Array && C.length > 1) throw Error("Parse Error: multiple actions possible at state: " + S + ", token: " + x);
				switch (C[0]) {
					case 1:
						n.push(x), i.push(p.yytext), a.push(p.yylloc), n.push(C[1]), x = null, l = p.yyleng, s = p.yytext, c = p.yylineno, g = p.yylloc;
						break;
					case 2:
						if (D = this.productions_[C[1]][1], T.$ = i[i.length - D], T._$ = {
							first_line: a[a.length - (D || 1)].first_line,
							last_line: a[a.length - 1].last_line,
							first_column: a[a.length - (D || 1)].first_column,
							last_column: a[a.length - 1].last_column
						}, v && (T._$.range = [a[a.length - (D || 1)].range[0], a[a.length - 1].range[1]]), w = this.performAction.apply(T, [
							s,
							l,
							c,
							m.yy,
							C[1],
							i,
							a
						].concat(f)), typeof w < "u") return w;
						D && (n = n.slice(0, -1 * D * 2), i = i.slice(0, -1 * D), a = a.slice(0, -1 * D)), n.push(this.productions_[C[1]][0]), i.push(T.$), a.push(T._$), O = o[n[n.length - 2]][n[n.length - 1]], n.push(O);
						break;
					case 3: return !0;
				}
			}
			return !0;
		}, "parse")
	};
	Q.lexer = /* @__PURE__ */ function() {
		return {
			EOF: 1,
			parseError: /* @__PURE__ */ _(function(e, t) {
				if (this.yy.parser) this.yy.parser.parseError(e, t);
				else throw Error(e);
			}, "parseError"),
			setInput: /* @__PURE__ */ _(function(e, t) {
				return this.yy = t || this.yy || {}, this._input = e, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
					first_line: 1,
					first_column: 0,
					last_line: 1,
					last_column: 0
				}, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
			}, "setInput"),
			input: /* @__PURE__ */ _(function() {
				var e = this._input[0];
				return this.yytext += e, this.yyleng++, this.offset++, this.match += e, this.matched += e, e.match(/(?:\r\n?|\n).*/g) ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), e;
			}, "input"),
			unput: /* @__PURE__ */ _(function(e) {
				var t = e.length, n = e.split(/(?:\r\n?|\n)/g);
				this._input = e + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - t), this.offset -= t;
				var r = this.match.split(/(?:\r\n?|\n)/g);
				this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), n.length - 1 && (this.yylineno -= n.length - 1);
				var i = this.yylloc.range;
				return this.yylloc = {
					first_line: this.yylloc.first_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.first_column,
					last_column: n ? (n.length === r.length ? this.yylloc.first_column : 0) + r[r.length - n.length].length - n[0].length : this.yylloc.first_column - t
				}, this.options.ranges && (this.yylloc.range = [i[0], i[0] + this.yyleng - t]), this.yyleng = this.yytext.length, this;
			}, "unput"),
			more: /* @__PURE__ */ _(function() {
				return this._more = !0, this;
			}, "more"),
			reject: /* @__PURE__ */ _(function() {
				if (this.options.backtrack_lexer) this._backtrack = !0;
				else return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
				return this;
			}, "reject"),
			less: /* @__PURE__ */ _(function(e) {
				this.unput(this.match.slice(e));
			}, "less"),
			pastInput: /* @__PURE__ */ _(function() {
				var e = this.matched.substr(0, this.matched.length - this.match.length);
				return (e.length > 20 ? "..." : "") + e.substr(-20).replace(/\n/g, "");
			}, "pastInput"),
			upcomingInput: /* @__PURE__ */ _(function() {
				var e = this.match;
				return e.length < 20 && (e += this._input.substr(0, 20 - e.length)), (e.substr(0, 20) + (e.length > 20 ? "..." : "")).replace(/\n/g, "");
			}, "upcomingInput"),
			showPosition: /* @__PURE__ */ _(function() {
				var e = this.pastInput(), t = Array(e.length + 1).join("-");
				return e + this.upcomingInput() + "\n" + t + "^";
			}, "showPosition"),
			test_match: /* @__PURE__ */ _(function(e, t) {
				var n, r, i;
				if (this.options.backtrack_lexer && (i = {
					yylineno: this.yylineno,
					yylloc: {
						first_line: this.yylloc.first_line,
						last_line: this.last_line,
						first_column: this.yylloc.first_column,
						last_column: this.yylloc.last_column
					},
					yytext: this.yytext,
					match: this.match,
					matches: this.matches,
					matched: this.matched,
					yyleng: this.yyleng,
					offset: this.offset,
					_more: this._more,
					_input: this._input,
					yy: this.yy,
					conditionStack: this.conditionStack.slice(0),
					done: this.done
				}, this.options.ranges && (i.yylloc.range = this.yylloc.range.slice(0))), r = e[0].match(/(?:\r\n?|\n).*/g), r && (this.yylineno += r.length), this.yylloc = {
					first_line: this.yylloc.last_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.last_column,
					last_column: r ? r[r.length - 1].length - r[r.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + e[0].length
				}, this.yytext += e[0], this.match += e[0], this.matches = e, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(e[0].length), this.matched += e[0], n = this.performAction.call(this, this.yy, this, t, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), n) return n;
				if (this._backtrack) {
					for (var a in i) this[a] = i[a];
					return !1;
				}
				return !1;
			}, "test_match"),
			next: /* @__PURE__ */ _(function() {
				if (this.done) return this.EOF;
				this._input || (this.done = !0);
				var e, t, n, r;
				this._more || (this.yytext = "", this.match = "");
				for (var i = this._currentRules(), a = 0; a < i.length; a++) if (n = this._input.match(this.rules[i[a]]), n && (!t || n[0].length > t[0].length)) {
					if (t = n, r = a, this.options.backtrack_lexer) {
						if (e = this.test_match(n, i[a]), e !== !1) return e;
						if (this._backtrack) {
							t = !1;
							continue;
						}
						return !1;
					}
					if (!this.options.flex) break;
				}
				return t ? (e = this.test_match(t, i[r]), e !== !1 && e) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
			}, "next"),
			lex: /* @__PURE__ */ _(function() {
				return this.next() || this.lex();
			}, "lex"),
			begin: /* @__PURE__ */ _(function(e) {
				this.conditionStack.push(e);
			}, "begin"),
			popState: /* @__PURE__ */ _(function() {
				return this.conditionStack.length - 1 > 0 ? this.conditionStack.pop() : this.conditionStack[0];
			}, "popState"),
			_currentRules: /* @__PURE__ */ _(function() {
				return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
			}, "_currentRules"),
			topState: /* @__PURE__ */ _(function(e) {
				return e = this.conditionStack.length - 1 - Math.abs(e || 0), e >= 0 ? this.conditionStack[e] : "INITIAL";
			}, "topState"),
			pushState: /* @__PURE__ */ _(function(e) {
				this.begin(e);
			}, "pushState"),
			stateStackSize: /* @__PURE__ */ _(function() {
				return this.conditionStack.length;
			}, "stateStackSize"),
			options: { "case-insensitive": !0 },
			performAction: /* @__PURE__ */ _(function(e, t, n, r) {
				switch (n) {
					case 0: return this.begin("acc_title"), 23;
					case 1: return this.popState(), "acc_title_value";
					case 2: return this.begin("acc_descr"), 25;
					case 3: return this.popState(), "acc_descr_value";
					case 4:
						this.begin("acc_descr_multiline");
						break;
					case 5:
						this.popState();
						break;
					case 6: return "acc_descr_multiline_value";
					case 7: return 37;
					case 8: return 38;
					case 9: return 39;
					case 10: return 40;
					case 11: break;
					case 12: return 9;
					case 13: return 53;
					case 14: return 76;
					case 15: return 4;
					case 16: return this.begin("block"), 16;
					case 17: return 52;
					case 18: return 52;
					case 19: return 45;
					case 20: return 14;
					case 21: return 12;
					case 22: break;
					case 23: return 65;
					case 24: return 61;
					case 25: return 61;
					case 26:
						this.begin("block_bq");
						break;
					case 27: return 61;
					case 28:
						this.popState();
						break;
					case 29: return 66;
					case 30: break;
					case 31: return this.popState(), 18;
					case 32: return t.yytext[0];
					case 33: return 19;
					case 34: return 20;
					case 35: return this.begin("style"), 47;
					case 36: return this.popState(), 9;
					case 37: break;
					case 38: return 12;
					case 39: return 45;
					case 40: return 52;
					case 41: return this.begin("style"), 41;
					case 42: return 46;
					case 43: return 34;
					case 44: return 33;
					case 45: return 69;
					case 46: return 71;
					case 47: return 71;
					case 48: return 71;
					case 49: return 69;
					case 50: return 69;
					case 51: return 70;
					case 52: return 70;
					case 53: return 70;
					case 54: return 70;
					case 55: return 70;
					case 56: return 71;
					case 57: return 70;
					case 58: return 71;
					case 59: return 72;
					case 60: return 72;
					case 61: return 54;
					case 62: return 72;
					case 63: return 72;
					case 64: return 72;
					case 65: return 55;
					case 66: return 51;
					case 67: return 72;
					case 68: return 69;
					case 69: return 70;
					case 70: return 71;
					case 71: return 73;
					case 72: return 74;
					case 73: return 75;
					case 74: return 75;
					case 75: return 74;
					case 76: return 74;
					case 77: return 74;
					case 78: return 44;
					case 79: return 50;
					case 80: return 43;
					case 81: return t.yytext[0];
					case 82: return 6;
				}
			}, "anonymous"),
			rules: [
				/^(?:accTitle\s*:\s*)/i,
				/^(?:(?!\n||)*[^\n]*)/i,
				/^(?:accDescr\s*:\s*)/i,
				/^(?:(?!\n||)*[^\n]*)/i,
				/^(?:accDescr\s*\{\s*)/i,
				/^(?:[\}])/i,
				/^(?:[^\}]*)/i,
				/^(?:.*direction\s+TB[^\n]*)/i,
				/^(?:.*direction\s+BT[^\n]*)/i,
				/^(?:.*direction\s+RL[^\n]*)/i,
				/^(?:.*direction\s+LR[^\n]*)/i,
				/^(?:[ \t\r]+)/i,
				/^(?:[\n]+)/i,
				/^(?:"[^"%\r\n\v\b\\]+")/i,
				/^(?:"[^"]*")/i,
				/^(?:erDiagram\b)/i,
				/^(?:\{)/i,
				/^(?:#)/i,
				/^(?:#)/i,
				/^(?:,)/i,
				/^(?::::)/i,
				/^(?::)/i,
				/^(?:\s+)/i,
				/^(?:\b((?:PK)|(?:FK)|(?:UK))\b)/i,
				/^(?:([^\s]*)[~].*[~]([^\s]*))/i,
				/^(?:([\*A-Za-z_\u00C0-\uFFFF][A-Za-z0-9\-\_\[\]\(\)\.,\u00C0-\uFFFF\*]*))/i,
				/^(?:[`])/i,
				/^(?:[^`]+)/i,
				/^(?:[`])/i,
				/^(?:"[^"]*")/i,
				/^(?:[\n]+)/i,
				/^(?:\})/i,
				/^(?:.)/i,
				/^(?:\[)/i,
				/^(?:\])/i,
				/^(?:style\b)/i,
				/^(?:[\n]+)/i,
				/^(?:\s+)/i,
				/^(?::)/i,
				/^(?:,)/i,
				/^(?:#)/i,
				/^(?:classDef\b)/i,
				/^(?:class\b)/i,
				/^(?:subgraph\b)/i,
				/^(?:end\b\s*)/i,
				/^(?:one or zero\b)/i,
				/^(?:one or more\b)/i,
				/^(?:one or many\b)/i,
				/^(?:1\+)/i,
				/^(?:\|o\b)/i,
				/^(?:zero or one\b)/i,
				/^(?:zero or more\b)/i,
				/^(?:zero or many\b)/i,
				/^(?:0\+)/i,
				/^(?:\}o\b)/i,
				/^(?:many\(0\))/i,
				/^(?:many\(1\))/i,
				/^(?:many\b)/i,
				/^(?:\}\|)/i,
				/^(?:one\b)/i,
				/^(?:only one\b)/i,
				/^(?:[0-9]+\.[0-9]+)/i,
				/^(?:1(?=\s+[A-Za-z_"']))/i,
				/^(?:1(?=\s+[0-9]))/i,
				/^(?:1(?=(--|\.\.|\.-|-\.)))/i,
				/^(?:1\b)/i,
				/^(?:[0-9]+)/i,
				/^(?:\|\|)/i,
				/^(?:o\|)/i,
				/^(?:o\{)/i,
				/^(?:\|\{)/i,
				/^(?:u(?=[\.\-\|]))/i,
				/^(?:\.\.)/i,
				/^(?:--)/i,
				/^(?:to\b)/i,
				/^(?:optionally to\b)/i,
				/^(?:\.-)/i,
				/^(?:-\.)/i,
				/^(?:([^\x00-\x7F]|\w|-|\*)+)/i,
				/^(?:;)/i,
				/^(?:([^\x00-\x7F]|\w|-|\*|\.)+)/i,
				/^(?:.)/i,
				/^(?:$)/i
			],
			conditions: {
				style: {
					rules: [
						36,
						37,
						38,
						39,
						40,
						78,
						79
					],
					inclusive: !1
				},
				acc_descr_multiline: {
					rules: [5, 6],
					inclusive: !1
				},
				acc_descr: {
					rules: [3],
					inclusive: !1
				},
				acc_title: {
					rules: [1],
					inclusive: !1
				},
				block_bq: {
					rules: [27, 28],
					inclusive: !1
				},
				block: {
					rules: [
						22,
						23,
						24,
						25,
						26,
						29,
						30,
						31,
						32
					],
					inclusive: !1
				},
				INITIAL: {
					rules: [
						0,
						2,
						4,
						7,
						8,
						9,
						10,
						11,
						12,
						13,
						14,
						15,
						16,
						17,
						18,
						19,
						20,
						21,
						33,
						34,
						35,
						41,
						42,
						43,
						44,
						45,
						46,
						47,
						48,
						49,
						50,
						51,
						52,
						53,
						54,
						55,
						56,
						57,
						58,
						59,
						60,
						61,
						62,
						63,
						64,
						65,
						66,
						67,
						68,
						69,
						70,
						71,
						72,
						73,
						74,
						75,
						76,
						77,
						80,
						81,
						82
					],
					inclusive: !0
				}
			}
		};
	}();
	function $() {
		this.yy = {};
	}
	return _($, "Parser"), $.prototype = Q, Q.Parser = $, new $();
}();
x.parser = x;
var S = x, C, w = (C = class {
	constructor() {
		this.entities = /* @__PURE__ */ new Map(), this.relationships = [], this.classes = /* @__PURE__ */ new Map(), this.subgraphDepth = 0, this.subGraphs = [], this.subGraphLookup = /* @__PURE__ */ new Map(), this.subCount = 0, this.direction = "TB", this.Cardinality = {
			ZERO_OR_ONE: "ZERO_OR_ONE",
			ZERO_OR_MORE: "ZERO_OR_MORE",
			ONE_OR_MORE: "ONE_OR_MORE",
			ONLY_ONE: "ONLY_ONE",
			MD_PARENT: "MD_PARENT"
		}, this.Identification = {
			NON_IDENTIFYING: "NON_IDENTIFYING",
			IDENTIFYING: "IDENTIFYING"
		}, this.setAccTitle = g, this.getAccTitle = a, this.setAccDescription = h, this.getAccDescription = i, this.setDiagramTitle = d, this.getDiagramTitle = s, this.getConfig = /* @__PURE__ */ _(() => o().er, "getConfig"), this.clear(), this.addEntity = this.addEntity.bind(this), this.addAttributes = this.addAttributes.bind(this), this.addRelationship = this.addRelationship.bind(this), this.setDirection = this.setDirection.bind(this), this.addCssStyles = this.addCssStyles.bind(this), this.addClass = this.addClass.bind(this), this.setClass = this.setClass.bind(this), this.setAccTitle = this.setAccTitle.bind(this), this.setAccDescription = this.setAccDescription.bind(this), this.addSubGraph = this.addSubGraph.bind(this);
	}
	addEntity(e, t = "") {
		return this.entities.has(e) ? !this.entities.get(e)?.alias && t && (this.entities.get(e).alias = t, u.info(`Add alias '${t}' to entity '${e}'`)) : (this.entities.set(e, {
			id: `entity-${e}-${this.entities.size}`,
			label: e,
			attributes: [],
			alias: t,
			shape: "erBox",
			look: o().look ?? "default",
			cssClasses: "default",
			cssStyles: [],
			labelType: "markdown"
		}), u.info("Added new entity :", e)), this.entities.get(e);
	}
	getEntity(e) {
		return this.entities.get(e);
	}
	getEntities() {
		return this.entities;
	}
	getClasses() {
		return this.classes;
	}
	addAttributes(e, t) {
		let n = this.addEntity(e), r;
		for (r = t.length - 1; r >= 0; r--) t[r].keys || (t[r].keys = []), t[r].comment || (t[r].comment = ""), n.attributes.push(t[r]), u.debug("Added attribute ", t[r].name);
	}
	addRelationship(e, t, n, r) {
		let i;
		if (this.subGraphLookup.has(e)) i = e;
		else {
			let t = this.addEntity(e);
			if (!t) return;
			i = t.id;
		}
		let a;
		if (this.subGraphLookup.has(n)) a = n;
		else {
			let e = this.addEntity(n);
			if (!e) return;
			a = e.id;
		}
		let o = {
			entityA: i,
			roleA: t,
			entityB: a,
			relSpec: r
		};
		this.relationships.push(o), u.debug("Added new relationship :", o);
	}
	getRelationships() {
		return this.relationships;
	}
	getDirection() {
		return this.direction;
	}
	setDirection(e) {
		this.direction = e;
	}
	getCompiledStyles(e) {
		let t = [];
		for (let n of e) {
			let e = this.classes.get(n);
			e?.styles && (t = [...t, ...e.styles ?? []].map((e) => e.trim())), e?.textStyles && (t = [...t, ...e.textStyles ?? []].map((e) => e.trim()));
		}
		return t;
	}
	addCssStyles(e, t) {
		for (let n of e) {
			let e = this.entities.get(n), r = this.subGraphLookup.get(n);
			if (t) {
				if (e) for (let n of t) e.cssStyles.push(n);
				if (r) {
					r.cssStyles ||= [];
					for (let e of t) r.cssStyles.push(e);
				}
			}
		}
	}
	addClass(e, t) {
		e.forEach((e) => {
			let n = this.classes.get(e);
			n === void 0 && (n = {
				id: e,
				styles: [],
				textStyles: []
			}, this.classes.set(e, n)), t && t.forEach(function(e) {
				if (/color/.exec(e)) {
					let t = e.replace("fill", "bgFill");
					n.textStyles.push(t);
				}
				n.styles.push(e);
			});
		});
	}
	addSubGraph(e, t, n) {
		let r = e.text.trim(), i = n.text, a = (/* @__PURE__ */ _((e) => {
			let t = /* @__PURE__ */ new Set(), n;
			return {
				nodeList: e.filter((e) => {
					if (e?.stmt) return e.stmt === "dir" && (n = e.value), !1;
					if (typeof e != "string") return !1;
					let r = e.trim();
					return !r || t.has(r) ? !1 : (t.add(r), !0);
				}),
				dir: n
			};
		}, "uniq"))(t.flat()), o = a.nodeList, s = a.dir;
		r ??= "subGraph" + this.subCount, i ||= "", i = this.sanitizeText(i), this.subCount += 1;
		let c = {
			id: r,
			nodes: o,
			title: i.trim(),
			classes: [],
			cssStyles: [],
			dir: s,
			labelType: this.sanitizeNodeLabelType(n?.type)
		};
		return u.info("Adding", c.id, c.nodes, c.dir), c.nodes = this.makeUniq(c, this.subGraphs).nodes, this.subGraphs.push(c), this.subGraphLookup.set(r, c), r;
	}
	getSubGraphs() {
		return this.subGraphs;
	}
	setClass(e, t) {
		for (let n of e) {
			let e = this.entities.get(n);
			if (e) for (let n of t) e.cssClasses += " " + n;
			let r = this.subGraphLookup.get(n);
			if (r) for (let e of t) r.classes.push(e);
		}
	}
	subgraphNodeCache(e) {
		let t = /* @__PURE__ */ new Set();
		for (let n of e) for (let e of n.nodes) t.add(e);
		return t;
	}
	makeUniq(e, t) {
		let n = this.subgraphNodeCache(t), r = [];
		return e.nodes.forEach((t, i) => {
			n.has(t) ? u.warn(`Entity '${t}' already belongs to another subgraph and will be ignored`) : r.push(e.nodes[i]);
		}), { nodes: r };
	}
	sanitizeText(e) {
		return n.sanitizeText(e, o());
	}
	sanitizeNodeLabelType(e) {
		switch (e) {
			case "markdown":
			case "string":
			case "text": return e;
			default: return "markdown";
		}
	}
	clear() {
		this.entities = /* @__PURE__ */ new Map(), this.classes = /* @__PURE__ */ new Map(), this.relationships = [], this.subGraphs = [], this.subGraphLookup = /* @__PURE__ */ new Map(), this.subCount = 0, this.subgraphDepth = 0, t();
	}
	getData() {
		let e = [], t = [], n = o(), r = this.getSubGraphs(), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map();
		for (let e = r.length - 1; e >= 0; e--) {
			let t = r[e];
			t.nodes.length > 0 && a.set(t.id, !0);
			for (let e of t.nodes) i.set(e, t.id);
		}
		for (let t = r.length - 1; t >= 0; t--) {
			let a = r[t];
			e.push({
				id: a.id,
				label: a.title,
				labelStyle: "",
				labelType: a.labelType,
				parentId: i.get(a.id),
				padding: 8,
				cssCompiledStyles: this.getCompiledStyles(a.classes),
				cssStyles: a.cssStyles,
				cssClasses: a.classes.join(" "),
				shape: "rect",
				dir: a.dir,
				isGroup: !0,
				look: n.look
			});
		}
		let s = new Set(r.map((e) => e.id)), l = 0;
		for (let t of this.entities.keys()) {
			if (s.has(t)) continue;
			let n = this.entities.get(t);
			n && (n.cssCompiledStyles = this.getCompiledStyles(n.cssClasses.split(" ")), n.colorIndex = l++, e.push({
				...n,
				parentId: i.get(t),
				isGroup: !1
			}));
		}
		let u = 0;
		for (let e of this.relationships) {
			let r = {
				id: c(e.entityA, e.entityB, {
					prefix: "id",
					counter: u++
				}),
				type: "normal",
				curve: "basis",
				start: e.entityA,
				end: e.entityB,
				label: e.roleA,
				labelpos: "c",
				thickness: "normal",
				classes: "relationshipLine",
				arrowTypeStart: e.relSpec.cardB.toLowerCase(),
				arrowTypeEnd: e.relSpec.cardA.toLowerCase(),
				pattern: e.relSpec.relType == "IDENTIFYING" ? "solid" : "dashed",
				look: n.look,
				labelType: "markdown"
			};
			t.push(r);
		}
		return {
			nodes: e,
			edges: t,
			other: {},
			config: n,
			direction: this.direction
		};
	}
}, _(C, "ErDB"), C), T = {};
r(T, { draw: () => E });
var E = /* @__PURE__ */ _(async function(t, n, r, i) {
	u.info("REF0:"), u.info("Drawing er diagram (unified)", n);
	let { securityLevel: a, er: s, layout: c } = o(), d = i.db.getData(), m = y(n, a);
	d.type = i.type, d.layoutAlgorithm = l(c), d.config.flowchart.nodeSpacing = s?.nodeSpacing || 140, d.config.flowchart.rankSpacing = s?.rankSpacing || 80, d.direction = i.db.getDirection();
	let { config: h } = d, { look: g } = h;
	d.markers = g === "neo" ? [
		"only_one_neo",
		"zero_or_one_neo",
		"one_or_more_neo",
		"zero_or_more_neo"
	] : [
		"only_one",
		"zero_or_one",
		"one_or_more",
		"zero_or_more"
	], d.diagramId = n, await p(d, m), d.layoutAlgorithm === "elk" && m.select(".edges").lower();
	let _ = m.selectAll("[id*=\"-background\"]");
	Array.from(_).length > 0 && _.each(function() {
		let t = e(this), n = t.attr("id").replace("-background", ""), r = m.select(`#${CSS.escape(n)}`);
		if (!r.empty()) {
			let e = r.attr("transform");
			t.attr("transform", e);
		}
	}), f.insertTitle(m, "erDiagramTitleText", s?.titleTopMargin ?? 25, i.db.getDiagramTitle()), b(m, 8, "erDiagram", s?.useMaxWidth ?? !0);
}, "draw"), D = /* @__PURE__ */ _((e, t) => {
	let n = v, r = n(e, "r"), i = n(e, "g"), a = n(e, "b");
	return m(r, i, a, t);
}, "fade"), O = /* @__PURE__ */ new Set(["redux-color", "redux-dark-color"]), k = /* @__PURE__ */ _((e) => {
	let { theme: t, look: n, bkgColorArray: r, borderColorArray: i } = e;
	if (!O.has(t)) return "";
	let a = r?.length > 0, o = "";
	for (let t = 0; t < e.THEME_COLOR_LIMIT; t++) o += `

    [data-look="${n}"][data-color-id="color-${t}"].node path {
    stroke: ${i[t]};
    ${a ? `fill: ${r[t]};` : ""}
    }

    [data-look="${n}"][data-color-id="color-${t}"].node  rect {
    stroke: ${i[t]};
    ${a ? `fill: ${r[t]};` : ""}
     }
    `;
	return o;
}, "genColor"), A = {
	parser: S,
	get db() {
		return new w();
	},
	renderer: T,
	styles: /* @__PURE__ */ _((e) => {
		let { look: t, theme: n, erEdgeLabelBackground: r, strokeWidth: i } = e;
		return `
    ${k(e)}
  .entityBox {
    fill: ${e.mainBkg};
    stroke: ${e.nodeBorder};
  }

  .relationshipLabelBox {
    fill: ${e.tertiaryColor};
    opacity: 0.7;
    background-color: ${e.tertiaryColor};
      rect {
        opacity: 0.5;
      }
  }

  .labelBkg {
    background-color: ${O.has(n) && r ? r : D(e.tertiaryColor, .5)};
  }

  .edgeLabel {
    background-color: ${O.has(n) && r ? r : e.edgeLabelBackground};
  }
  .edgeLabel .label rect {
    fill: ${O.has(n) && r ? r : e.edgeLabelBackground};
  }
  .edgeLabel .label text {
    fill: ${e.textColor};
  }

  .edgeLabel .label {
    fill: ${e.nodeBorder};
    font-size: 14px;
  }

  .label {
    font-family: ${e.fontFamily};
    color: ${e.nodeTextColor || e.textColor};
  }

  .edge-pattern-dashed {
    stroke-dasharray: 8,8;
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon
  {
    fill: ${e.mainBkg};
    stroke: ${e.nodeBorder};
    stroke-width: ${t === "neo" ? i : "1px"};
  }

  .relationshipLine {
    stroke: ${e.lineColor};
    stroke-width: ${t === "neo" ? i : "1px"};
    fill: none;
  }

  .marker {
    fill: none !important;
    stroke: ${e.lineColor} !important;
    stroke-width: 1;
  }
  [data-look=neo].labelBkg {
    background-color: ${D(e.tertiaryColor, .5)};
  }

  .cluster rect {
    fill: ${e.clusterBkg ?? e.mainBkg};
    stroke: ${e.clusterBorder ?? e.nodeBorder};
    stroke-width: 1px;
  }

  .cluster text {
    fill: ${e.titleColor ?? e.textColor};
  }

  .cluster-label text {
    fill: ${e.titleColor ?? e.textColor};
  }
`;
	}, "getStyles")
};
//#endregion
export { A as diagram };

//# sourceMappingURL=erDiagram-RLTQ6QDP-Clqg44D3-B_TLvDWA.js.map