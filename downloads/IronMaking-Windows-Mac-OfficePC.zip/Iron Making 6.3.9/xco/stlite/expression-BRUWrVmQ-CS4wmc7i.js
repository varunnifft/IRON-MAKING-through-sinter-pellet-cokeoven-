//#region ../react/build/expression-BRUWrVmQ.js
function e(t, { operations: n, inputs: r }) {
	switch (t.kind) {
		case "input":
			if (!(t.name in r)) throw Error(`Unknown expression input '${t.name}'`);
			return;
		case "literal":
			if (Array.isArray(t.value)) {
				for (let e of t.value) if (!Number.isFinite(e)) throw Error(`Expression literal array must contain only finite values, got ${e}`);
			} else if (!Number.isFinite(t.value)) throw Error(`Expression literal must be finite, got ${t.value}`);
			return;
		case "call": {
			let i = n[t.op];
			if (!i) throw Error(`Unknown expression op '${t.op}'`);
			if (t.args.length !== i.arity) throw Error(`Expression op '${t.op}' expects ${i.arity} args, got ${t.args.length}`);
			for (let i of t.args) e(i, {
				operations: n,
				inputs: r
			});
			return;
		}
		default: throw Error(`Unsupported expression node ${t.kind}`);
	}
}
function t(t, r) {
	return e(t, r), n(t, r);
}
function n(e, t) {
	switch (e.kind) {
		case "input": {
			let n = t.inputs[e.name];
			return t.laneIndex < n.size ? t.formatInput(e.name) : t.formatOutOfBoundsInput(e.name);
		}
		case "literal": return t.formatLiteral(e.value);
		case "call": {
			let r = t.operations[e.op], i = e.args.map((e) => n(e, t));
			return t.formatCall(r.symbol, i);
		}
		default: throw Error(`Unsupported expression node ${e.kind}`);
	}
}
//#endregion
export { t };

//# sourceMappingURL=expression-BRUWrVmQ-CS4wmc7i.js.map