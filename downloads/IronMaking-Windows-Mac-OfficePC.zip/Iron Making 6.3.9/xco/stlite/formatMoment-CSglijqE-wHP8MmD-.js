import { ps as e } from "./index-B1FrxEMd-BsPMjC5n.js";
//#region ../react/build/formatMoment-CSglijqE.js
var t;
function n() {
	return t.apply(null, arguments);
}
function r(e) {
	t = e;
}
function i(e) {
	return e instanceof Array || Object.prototype.toString.call(e) === "[object Array]";
}
function a(e) {
	return e != null && Object.prototype.toString.call(e) === "[object Object]";
}
function o(e, t) {
	return Object.prototype.hasOwnProperty.call(e, t);
}
function s(e) {
	if (Object.getOwnPropertyNames) return Object.getOwnPropertyNames(e).length === 0;
	for (var t in e) if (o(e, t)) return !1;
	return !0;
}
function c(e) {
	return e === void 0;
}
function l(e) {
	return typeof e == "number" || Object.prototype.toString.call(e) === "[object Number]";
}
function u(e) {
	return e instanceof Date || Object.prototype.toString.call(e) === "[object Date]";
}
function d(e, t) {
	var n = [], r, i = e.length;
	for (r = 0; r < i; ++r) n.push(t(e[r], r));
	return n;
}
function f(e, t) {
	for (var n in t) o(t, n) && (e[n] = t[n]);
	return o(t, "toString") && (e.toString = t.toString), o(t, "valueOf") && (e.valueOf = t.valueOf), e;
}
function p(e, t, n, r) {
	return hr(e, t, n, r, !0).utc();
}
function ee() {
	return {
		empty: !1,
		unusedTokens: [],
		unusedInput: [],
		overflow: -2,
		charsLeftOver: 0,
		nullInput: !1,
		invalidEra: null,
		invalidMonth: null,
		invalidOffset: null,
		invalidFormat: !1,
		userInvalidated: !1,
		iso: !1,
		parsedDateParts: [],
		era: null,
		meridiem: null,
		rfc2822: !1,
		weekdayMismatch: !1
	};
}
function m(e) {
	return e._pf ??= ee(), e._pf;
}
var te = Array.prototype.some ? Array.prototype.some : function(e) {
	var t = Object(this), n = t.length >>> 0, r;
	for (r = 0; r < n; r++) if (r in t && e.call(this, t[r], r, t)) return !0;
	return !1;
};
function ne(e) {
	var t = null, n = !1, r = e._d && !isNaN(e._d.getTime());
	if (r && (t = m(e), n = te.call(t.parsedDateParts, function(e) {
		return e != null;
	}), r = t.overflow < 0 && !t.empty && !t.invalidEra && !t.invalidMonth && !t.invalidOffset && !t.invalidWeekday && !t.weekdayMismatch && !t.nullInput && !t.invalidFormat && !t.userInvalidated && (!t.meridiem || t.meridiem && n), e._strict && (r = r && t.charsLeftOver === 0 && t.unusedTokens.length === 0 && t.bigHour === void 0)), Object.isFrozen == null || !Object.isFrozen(e)) e._isValid = r;
	else return r;
	return e._isValid;
}
function re(e) {
	var t = p(NaN);
	return e == null ? m(t).userInvalidated = !0 : f(m(t), e), t;
}
var ie = n.momentProperties = [], ae = !1;
function oe(e, t) {
	var n, r, i, a = ie.length;
	if (c(t._isAMomentObject) || (e._isAMomentObject = t._isAMomentObject), c(t._i) || (e._i = t._i), c(t._f) || (e._f = t._f), c(t._l) || (e._l = t._l), c(t._strict) || (e._strict = t._strict), c(t._tzm) || (e._tzm = t._tzm), c(t._isUTC) || (e._isUTC = t._isUTC), c(t._offset) || (e._offset = t._offset), c(t._pf) || (e._pf = m(t)), c(t._locale) || (e._locale = t._locale), a > 0) for (n = 0; n < a; n++) r = ie[n], i = t[r], c(i) || (e[r] = i);
	return e;
}
function se(e) {
	oe(this, e), this._d = new Date(e._d == null ? NaN : e._d.getTime()), this.isValid() || (this._d = /* @__PURE__ */ new Date(NaN)), ae === !1 && (ae = !0, n.updateOffset(this), ae = !1);
}
function h(e) {
	return e instanceof se || e != null && e._isAMomentObject != null;
}
function ce(e) {
	n.suppressDeprecationWarnings === !1 && typeof console < "u" && console.warn && console.warn("Deprecation warning: " + e);
}
function g(e, t) {
	var r = !0;
	return f(function() {
		if (n.deprecationHandler != null && n.deprecationHandler(null, e), r) {
			var i = [], a, s, c, l = arguments.length;
			for (s = 0; s < l; s++) {
				if (a = "", typeof arguments[s] == "object") {
					for (c in a += "\n[" + s + "] ", arguments[0]) o(arguments[0], c) && (a += c + ": " + arguments[0][c] + ", ");
					a = a.slice(0, -2);
				} else a = arguments[s];
				i.push(a);
			}
			ce(e + "\nArguments: " + Array.prototype.slice.call(i).join("") + "\n" + (/* @__PURE__ */ Error()).stack), r = !1;
		}
		return t.apply(this, arguments);
	}, t);
}
var le = {};
function ue(e, t) {
	n.deprecationHandler != null && n.deprecationHandler(e, t), le[e] || (ce(t + "\n" + (/* @__PURE__ */ Error()).stack), le[e] = !0);
}
n.suppressDeprecationWarnings = !1, n.deprecationHandler = null;
function _(e) {
	return typeof Function < "u" && e instanceof Function || Object.prototype.toString.call(e) === "[object Function]";
}
var de = {
	D: "date",
	dates: "date",
	date: "date",
	d: "day",
	days: "day",
	day: "day",
	e: "weekday",
	weekdays: "weekday",
	weekday: "weekday",
	E: "isoWeekday",
	isoweekdays: "isoWeekday",
	isoweekday: "isoWeekday",
	DDD: "dayOfYear",
	dayofyears: "dayOfYear",
	dayofyear: "dayOfYear",
	h: "hour",
	hours: "hour",
	hour: "hour",
	ms: "millisecond",
	milliseconds: "millisecond",
	millisecond: "millisecond",
	m: "minute",
	minutes: "minute",
	minute: "minute",
	M: "month",
	months: "month",
	month: "month",
	Q: "quarter",
	quarters: "quarter",
	quarter: "quarter",
	s: "second",
	seconds: "second",
	second: "second",
	gg: "weekYear",
	weekyears: "weekYear",
	weekyear: "weekYear",
	GG: "isoWeekYear",
	isoweekyears: "isoWeekYear",
	isoweekyear: "isoWeekYear",
	w: "week",
	weeks: "week",
	week: "week",
	W: "isoWeek",
	isoweeks: "isoWeek",
	isoweek: "isoWeek",
	y: "year",
	years: "year",
	year: "year"
};
function v(e) {
	return typeof e == "string" ? de[e] || de[e.toLowerCase()] : void 0;
}
function fe(e) {
	var t = {}, n, r;
	for (r in e) o(e, r) && (n = v(r), n && (t[n] = e[r]));
	return t;
}
var pe = {
	date: 9,
	day: 11,
	weekday: 11,
	isoWeekday: 11,
	dayOfYear: 4,
	hour: 13,
	millisecond: 16,
	minute: 14,
	month: 8,
	quarter: 7,
	second: 15,
	weekYear: 1,
	isoWeekYear: 1,
	week: 5,
	isoWeek: 5,
	year: 1
};
function me(e) {
	var t = [], n;
	for (n in e) o(e, n) && t.push({
		unit: n,
		priority: pe[n]
	});
	return t.sort(function(e, t) {
		return e.priority - t.priority;
	}), t;
}
function y(e, t, n) {
	var r = "" + Math.abs(e), i = t - r.length;
	return (e >= 0 ? n ? "+" : "" : "-") + (10 ** Math.max(0, i)).toString().substr(1) + r;
}
var he = /(\[[^\[]*\])|(\\e)|(\\)?(eHHmm|[Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|N{1,5}|YYYYYY|YYYYY|YYYY|YY|y{2,4}|yo?|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g, ge = /(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g, _e = {}, ve = {};
function b(e, t, n, r) {
	var i = r;
	typeof r == "string" && (i = function() {
		return this[r]();
	}), e && (ve[e] = i), t && (ve[t[0]] = function() {
		return y(i.apply(this, arguments), t[1], t[2]);
	}), n && (ve[n] = function() {
		return this.localeData().ordinal(i.apply(this, arguments), e);
	});
}
function ye(e) {
	return e.match(/\[[\s\S]/) ? e.replace(/^\[|\]$/g, "") : e.replace(/\\/g, "");
}
function be(e) {
	var t = e.match(he), n, r;
	for (n = 0, r = t.length; n < r; n++) ve[t[n]] ? t[n] = ve[t[n]] : t[n] = ye(t[n]);
	return function(n) {
		var i = "", a;
		for (a = 0; a < r; a++) i += _(t[a]) ? t[a].call(n, e) : t[a];
		return i;
	};
}
function xe(e, t) {
	if (!e.isValid()) return e.localeData().invalidDate();
	t = Se(t, e.localeData());
	var n = "$" + t;
	return o(_e, n) || (_e[n] = be(t)), _e[n](e);
}
function Se(e, t) {
	var n = 5;
	function r(e) {
		return t.longDateFormat(e) || e;
	}
	for (ge.lastIndex = 0; n >= 0 && ge.test(e);) e = e.replace(ge, r), ge.lastIndex = 0, --n;
	return e;
}
var Ce = /\d/, x = /\d\d/, we = /\d{3}/, Te = /\d{4}/, Ee = /[+-]?\d{6}/, S = /\d\d?/, De = /\d\d\d\d?/, Oe = /\d\d\d\d\d\d?/, ke = /\d{1,3}/, Ae = /\d{1,4}/, je = /[+-]?\d{1,6}/, C = /\d+/, Me = /[+-]?\d+/, Ne = /Z|[+-]\d\d:?\d\d/gi, Pe = /Z|[+-]\d\d(?::?\d\d)?/gi, Fe = /[+-]?\d+(\.\d{1,3})?/, Ie = /[0-9]{0,256}['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFF07\uFF10-\uFFEF]{1,256}|[\u0600-\u06FF\/]{1,256}(\s*?[\u0600-\u06FF]{1,256}){1,2}/i, Le = /^[1-9]\d?/, Re = /^([1-9]\d|\d)/, ze = {};
function w(e, t, n) {
	ze[e] = _(t) ? t : function(e, r) {
		return e && n ? n : t;
	};
}
function Be(e, t) {
	return o(ze, e) ? ze[e](t._strict, t._locale) : new RegExp(Ve(e));
}
function Ve(e) {
	return T(e.replace("\\", "").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g, function(e, t, n, r, i) {
		return t || n || r || i;
	}));
}
function T(e) {
	return e.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
}
function E(e) {
	return e < 0 ? Math.ceil(e) || 0 : Math.floor(e);
}
function D(e) {
	var t = +e, n = 0;
	return t !== 0 && isFinite(t) && (n = E(t)), n;
}
var He = {};
function O(e, t) {
	var n, r = t, i;
	for (typeof e == "string" && (e = [e]), l(t) && (r = function(e, n) {
		n[t] = D(e);
	}), i = e.length, n = 0; n < i; n++) He[e[n]] = r;
}
function k(e, t) {
	O(e, function(e, n, r, i) {
		r._w = r._w || {}, t(e, r._w, r, i);
	});
}
function Ue(e, t, n) {
	t != null && o(He, e) && He[e](t, n._a, n, e);
}
function We(e) {
	return e % 4 == 0 && e % 100 != 0 || e % 400 == 0;
}
var A = 0, j = 1, M = 2, N = 3, P = 4, F = 5, I = 6, Ge = 7, Ke = 8;
b("Y", 0, 0, function() {
	var e = this.year();
	return e <= 9999 ? y(e, 4) : "+" + e;
}), b(0, ["YY", 2], 0, function() {
	return this.year() % 100;
}), b(0, ["YYYY", 4], 0, "year"), b(0, ["YYYYY", 5], 0, "year"), b(0, [
	"YYYYYY",
	6,
	!0
], 0, "year"), w("Y", Me), w("YY", S, x), w("YYYY", Ae, Te), w("YYYYY", je, Ee), w("YYYYYY", je, Ee), O(["YYYYY", "YYYYYY"], A), O("YYYY", function(e, t) {
	t[A] = e.length === 2 ? n.parseTwoDigitYear(e) : D(e);
}), O("YY", function(e, t) {
	t[A] = n.parseTwoDigitYear(e);
}), O("Y", function(e, t) {
	t[A] = parseInt(e, 10);
});
function qe(e) {
	return We(e) ? 366 : 365;
}
n.parseTwoDigitYear = function(e) {
	return D(e) + (D(e) > 68 ? 1900 : 2e3);
};
var Je = Xe("FullYear", !0);
function Ye() {
	return We(this.year());
}
function Xe(e, t) {
	return function(r) {
		return r == null ? Ze(this, e) : (Qe(this, e, r), n.updateOffset(this, t), this);
	};
}
function Ze(e, t) {
	if (!e.isValid()) return NaN;
	var n = e._d, r = e._isUTC;
	switch (t) {
		case "Milliseconds": return r ? n.getUTCMilliseconds() : n.getMilliseconds();
		case "Seconds": return r ? n.getUTCSeconds() : n.getSeconds();
		case "Minutes": return r ? n.getUTCMinutes() : n.getMinutes();
		case "Hours": return r ? n.getUTCHours() : n.getHours();
		case "Date": return r ? n.getUTCDate() : n.getDate();
		case "Day": return r ? n.getUTCDay() : n.getDay();
		case "Month": return r ? n.getUTCMonth() : n.getMonth();
		case "FullYear": return r ? n.getUTCFullYear() : n.getFullYear();
		default: return NaN;
	}
}
function Qe(e, t, n) {
	var r, i, a, o, s;
	if (!(!e.isValid() || isNaN(n))) {
		switch (r = e._d, i = e._isUTC, t) {
			case "Milliseconds":
				i ? r.setUTCMilliseconds(n) : r.setMilliseconds(n);
				return;
			case "Seconds":
				i ? r.setUTCSeconds(n) : r.setSeconds(n);
				return;
			case "Minutes":
				i ? r.setUTCMinutes(n) : r.setMinutes(n);
				return;
			case "Hours":
				i ? r.setUTCHours(n) : r.setHours(n);
				return;
			case "Date":
				i ? r.setUTCDate(n) : r.setDate(n);
				return;
			case "FullYear": break;
			default: return;
		}
		a = n, o = e.month(), s = e.date(), s = s === 29 && o === 1 && !We(a) ? 28 : s, i ? r.setUTCFullYear(a, o, s) : r.setFullYear(a, o, s);
	}
}
function $e(e) {
	return e = v(e), _(this[e]) ? this[e]() : this;
}
function et(e, t) {
	if (typeof e == "object") {
		e = fe(e);
		var n = me(e), r, i = n.length;
		for (r = 0; r < i; r++) this[n[r].unit](e[n[r].unit]);
	} else if (e = v(e), _(this[e])) return this[e](t);
	return this;
}
function tt(e, t) {
	return (e % t + t) % t;
}
var L = Array.prototype.indexOf ? Array.prototype.indexOf : function(e) {
	var t;
	for (t = 0; t < this.length; ++t) if (this[t] === e) return t;
	return -1;
};
function nt(e, t) {
	if (isNaN(e) || isNaN(t)) return NaN;
	var n = tt(t, 12);
	return e += (t - n) / 12, n === 1 ? We(e) ? 29 : 28 : 31 - n % 7 % 2;
}
b("M", ["MM", 2], "Mo", function() {
	return this.month() + 1;
}), b("MMM", 0, 0, function(e) {
	return this.localeData().monthsShort(this, e);
}), b("MMMM", 0, 0, function(e) {
	return this.localeData().months(this, e);
}), w("M", S, Le), w("MM", S, x), w("MMM", function(e, t) {
	return t.monthsShortRegex(e);
}), w("MMMM", function(e, t) {
	return t.monthsRegex(e);
}), O(["M", "MM"], function(e, t) {
	t[j] = D(e) - 1;
}), O(["MMM", "MMMM"], function(e, t, n, r) {
	var i = n._locale.monthsParse(e, r, n._strict);
	i == null ? m(n).invalidMonth = e : t[j] = i;
});
var rt = "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), it = "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"), at = /D[oD]?(\[[^\[\]]*\]|\s)+MMMM?/, ot = Ie, st = Ie, ct = [
	"monthsParse",
	"longMonthsParse",
	"shortMonthsParse",
	"monthsRegex",
	"monthsShortRegex",
	"monthsStrictRegex",
	"monthsShortStrictRegex"
];
function lt(e, t) {
	var n, r;
	for (n = 0; n < ct.length; n++) r = ct[n], o(t, r) || delete e["_" + r];
}
function ut(e, t) {
	return e ? i(this._months) ? this._months[e.month()] : this._months[(this._months.isFormat || at).test(t) ? "format" : "standalone"][e.month()] : i(this._months) ? this._months : this._months.standalone;
}
function dt(e, t) {
	return e ? i(this._monthsShort) ? this._monthsShort[e.month()] : this._monthsShort[at.test(t) ? "format" : "standalone"][e.month()] : i(this._monthsShort) ? this._monthsShort : this._monthsShort.standalone;
}
function ft(e, t, n) {
	var r, i, a, o = e.toLocaleLowerCase();
	if (!this._monthsParse) for (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = [], r = 0; r < 12; ++r) a = p([2e3, r]), this._shortMonthsParse[r] = this.monthsShort(a, "").toLocaleLowerCase(), this._longMonthsParse[r] = this.months(a, "").toLocaleLowerCase();
	return n ? t === "MMM" ? (i = L.call(this._shortMonthsParse, o), i === -1 ? null : i) : (i = L.call(this._longMonthsParse, o), i === -1 ? null : i) : t === "MMM" ? (i = L.call(this._shortMonthsParse, o), i === -1 ? (i = L.call(this._longMonthsParse, o), i === -1 ? null : i) : i) : (i = L.call(this._longMonthsParse, o), i === -1 ? (i = L.call(this._shortMonthsParse, o), i === -1 ? null : i) : i);
}
function pt(e, t, n) {
	var r, i, a;
	if (this._monthsParseExact) return ft.call(this, e, t, n);
	for (this._monthsParse || (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = []), r = 0; r < 12; r++) if (i = p([2e3, r]), n && !this._longMonthsParse[r] && (this._longMonthsParse[r] = RegExp("^" + this.months(i, "").replace(".", "") + "$", "i"), this._shortMonthsParse[r] = RegExp("^" + this.monthsShort(i, "").replace(".", "") + "$", "i")), !n && !this._monthsParse[r] && (a = "^" + this.months(i, "") + "|^" + this.monthsShort(i, ""), this._monthsParse[r] = new RegExp(a.replace(".", ""), "i")), n && t === "MMMM" && this._longMonthsParse[r].test(e) || n && t === "MMM" && this._shortMonthsParse[r].test(e) || !n && this._monthsParse[r].test(e)) return r;
}
function mt(e, t) {
	if (!e.isValid()) return e;
	if (typeof t == "string") {
		if (/^\d+$/.test(t)) t = D(t);
		else if (t = e.localeData().monthsParse(t), !l(t)) return e;
	}
	var n = t, r = e.date();
	return r = r < 29 ? r : Math.min(r, nt(e.year(), n)), e._isUTC ? e._d.setUTCMonth(n, r) : e._d.setMonth(n, r), e;
}
function ht(e) {
	return e == null ? Ze(this, "Month") : (mt(this, e), n.updateOffset(this, !0), this);
}
function gt() {
	return nt(this.year(), this.month());
}
function _t(e) {
	return this._monthsParseExact ? (o(this, "_monthsRegex") || yt.call(this), e ? this._monthsShortStrictRegex : this._monthsShortRegex) : (o(this, "_monthsShortRegex") || (this._monthsShortRegex = ot), this._monthsShortStrictRegex && e ? this._monthsShortStrictRegex : this._monthsShortRegex);
}
function vt(e) {
	return this._monthsParseExact ? (o(this, "_monthsRegex") || yt.call(this), e ? this._monthsStrictRegex : this._monthsRegex) : (o(this, "_monthsRegex") || (this._monthsRegex = st), this._monthsStrictRegex && e ? this._monthsStrictRegex : this._monthsRegex);
}
function yt() {
	function e(e, t) {
		return t.length - e.length;
	}
	var t = [], n = [], r = [], i, a, o, s;
	for (i = 0; i < 12; i++) a = p([2e3, i]), o = T(this.monthsShort(a, "")), s = T(this.months(a, "")), t.push(o), n.push(s), r.push(s), r.push(o);
	t.sort(e), n.sort(e), r.sort(e), this._monthsRegex = RegExp("^(" + r.join("|") + ")", "i"), this._monthsShortRegex = this._monthsRegex, this._monthsStrictRegex = RegExp("^(" + n.join("|") + ")", "i"), this._monthsShortStrictRegex = RegExp("^(" + t.join("|") + ")", "i");
}
b("d", 0, "do", "day"), b("dd", 0, 0, function(e) {
	return this.localeData().weekdaysMin(this, e);
}), b("ddd", 0, 0, function(e) {
	return this.localeData().weekdaysShort(this, e);
}), b("dddd", 0, 0, function(e) {
	return this.localeData().weekdays(this, e);
}), b("e", 0, 0, "weekday"), b("E", 0, 0, "isoWeekday"), b("eHHmm", 0, 0, function() {
	return "" + this.weekday() + y(this.hours(), 2) + y(this.minutes(), 2);
}), w("d", S), w("e", S), w("E", S), w("eHHmm", Oe), w("dd", function(e, t) {
	return t.weekdaysMinRegex(e);
}), w("ddd", function(e, t) {
	return t.weekdaysShortRegex(e);
}), w("dddd", function(e, t) {
	return t.weekdaysRegex(e);
}), k([
	"dd",
	"ddd",
	"dddd"
], function(e, t, n, r) {
	var i = n._locale.weekdaysParse(e, r, n._strict);
	i == null ? m(n).invalidWeekday = e : t.d = i;
}), k([
	"d",
	"e",
	"E"
], function(e, t, n, r) {
	t[r] = D(e);
}), k("eHHmm", function(e, t, n) {
	var r = e.length - 4;
	t.e = D(e.substr(0, r)), n._a[N] = D(e.substr(r, 2)), n._a[P] = D(e.substr(r + 2));
});
function bt(e, t) {
	return typeof e == "string" ? isNaN(e) ? (e = t.weekdaysParse(e), typeof e == "number" ? e : null) : parseInt(e, 10) : e;
}
function xt(e, t) {
	return typeof e == "string" ? t.weekdaysParse(e) % 7 || 7 : isNaN(e) ? null : e;
}
function St(e, t) {
	return e.slice(t, 7).concat(e.slice(0, t));
}
var Ct = "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), wt = "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"), Tt = "Su_Mo_Tu_We_Th_Fr_Sa".split("_"), Et = Ie, Dt = Ie, Ot = Ie, kt = [
	"weekdaysParse",
	"fullWeekdaysParse",
	"shortWeekdaysParse",
	"minWeekdaysParse",
	"weekdaysRegex",
	"weekdaysShortRegex",
	"weekdaysMinRegex",
	"weekdaysStrictRegex",
	"weekdaysShortStrictRegex",
	"weekdaysMinStrictRegex"
];
function At(e, t) {
	var n, r;
	for (n = 0; n < kt.length; n++) r = kt[n], o(t, r) || delete e["_" + r];
}
function jt(e, t) {
	var n = i(this._weekdays) ? this._weekdays : this._weekdays[e && e !== !0 && this._weekdays.isFormat.test(t) ? "format" : "standalone"];
	return e === !0 ? St(n, this._week.dow) : e ? n[e.day()] : n;
}
function Mt(e) {
	return e === !0 ? St(this._weekdaysShort, this._week.dow) : e ? this._weekdaysShort[e.day()] : this._weekdaysShort;
}
function Nt(e) {
	return e === !0 ? St(this._weekdaysMin, this._week.dow) : e ? this._weekdaysMin[e.day()] : this._weekdaysMin;
}
function Pt(e, t, n) {
	var r, i, a, o = e.toLocaleLowerCase();
	if (!this._weekdaysParse) for (this._weekdaysParse = [], this._shortWeekdaysParse = [], this._minWeekdaysParse = [], r = 0; r < 7; ++r) a = p([2e3, 1]).day(r), this._minWeekdaysParse[r] = this.weekdaysMin(a, "").toLocaleLowerCase(), this._shortWeekdaysParse[r] = this.weekdaysShort(a, "").toLocaleLowerCase(), this._weekdaysParse[r] = this.weekdays(a, "").toLocaleLowerCase();
	return n ? t === "dddd" ? (i = L.call(this._weekdaysParse, o), i === -1 ? null : i) : t === "ddd" ? (i = L.call(this._shortWeekdaysParse, o), i === -1 ? null : i) : (i = L.call(this._minWeekdaysParse, o), i === -1 ? null : i) : t === "dddd" ? (i = L.call(this._weekdaysParse, o), i !== -1 || (i = L.call(this._shortWeekdaysParse, o), i !== -1) ? i : (i = L.call(this._minWeekdaysParse, o), i === -1 ? null : i)) : t === "ddd" ? (i = L.call(this._shortWeekdaysParse, o), i !== -1 || (i = L.call(this._weekdaysParse, o), i !== -1) ? i : (i = L.call(this._minWeekdaysParse, o), i === -1 ? null : i)) : (i = L.call(this._minWeekdaysParse, o), i !== -1 || (i = L.call(this._weekdaysParse, o), i !== -1) ? i : (i = L.call(this._shortWeekdaysParse, o), i === -1 ? null : i));
}
function Ft(e, t, n) {
	var r, i, a;
	if (this._weekdaysParseExact) return Pt.call(this, e, t, n);
	for (this._weekdaysParse || (this._weekdaysParse = [], this._minWeekdaysParse = [], this._shortWeekdaysParse = [], this._fullWeekdaysParse = []), r = 0; r < 7; r++) if (i = p([2e3, 1]).day(r), n && !this._fullWeekdaysParse[r] && (this._fullWeekdaysParse[r] = RegExp("^" + this.weekdays(i, "").replace(".", "\\.?") + "$", "i"), this._shortWeekdaysParse[r] = RegExp("^" + this.weekdaysShort(i, "").replace(".", "\\.?") + "$", "i"), this._minWeekdaysParse[r] = RegExp("^" + this.weekdaysMin(i, "").replace(".", "\\.?") + "$", "i")), this._weekdaysParse[r] || (a = "^" + this.weekdays(i, "") + "|^" + this.weekdaysShort(i, "") + "|^" + this.weekdaysMin(i, ""), this._weekdaysParse[r] = new RegExp(a.replace(".", ""), "i")), n && t === "dddd" && this._fullWeekdaysParse[r].test(e) || n && t === "ddd" && this._shortWeekdaysParse[r].test(e) || n && t === "dd" && this._minWeekdaysParse[r].test(e) || !n && this._weekdaysParse[r].test(e)) return r;
}
function It(e) {
	if (!this.isValid()) return e == null ? NaN : this;
	var t = Ze(this, "Day");
	return e == null ? t : (e = bt(e, this.localeData()), this.add(e - t, "d"));
}
function Lt(e) {
	if (!this.isValid()) return e == null ? NaN : this;
	var t = (this.day() + 7 - this.localeData()._week.dow) % 7;
	return e == null ? t : this.add(e - t, "d");
}
function Rt(e) {
	if (!this.isValid()) return e == null ? NaN : this;
	if (e != null) {
		var t = xt(e, this.localeData());
		return this.day(this.day() % 7 ? t : t - 7);
	}
	return this.day() || 7;
}
function zt(e) {
	return this._weekdaysParseExact ? (o(this, "_weekdaysRegex") || Ht.call(this), e ? this._weekdaysStrictRegex : this._weekdaysRegex) : (o(this, "_weekdaysRegex") || (this._weekdaysRegex = Et), this._weekdaysStrictRegex && e ? this._weekdaysStrictRegex : this._weekdaysRegex);
}
function Bt(e) {
	return this._weekdaysParseExact ? (o(this, "_weekdaysRegex") || Ht.call(this), e ? this._weekdaysShortStrictRegex : this._weekdaysShortRegex) : (o(this, "_weekdaysShortRegex") || (this._weekdaysShortRegex = Dt), this._weekdaysShortStrictRegex && e ? this._weekdaysShortStrictRegex : this._weekdaysShortRegex);
}
function Vt(e) {
	return this._weekdaysParseExact ? (o(this, "_weekdaysRegex") || Ht.call(this), e ? this._weekdaysMinStrictRegex : this._weekdaysMinRegex) : (o(this, "_weekdaysMinRegex") || (this._weekdaysMinRegex = Ot), this._weekdaysMinStrictRegex && e ? this._weekdaysMinStrictRegex : this._weekdaysMinRegex);
}
function Ht() {
	function e(e, t) {
		return t.length - e.length;
	}
	var t = [], n = [], r = [], i = [], a, o, s, c, l;
	for (a = 0; a < 7; a++) o = p([2e3, 1]).day(a), s = T(this.weekdaysMin(o, "")), c = T(this.weekdaysShort(o, "")), l = T(this.weekdays(o, "")), t.push(s), n.push(c), r.push(l), i.push(s), i.push(c), i.push(l);
	t.sort(e), n.sort(e), r.sort(e), i.sort(e), this._weekdaysRegex = RegExp("^(" + i.join("|") + ")", "i"), this._weekdaysShortRegex = this._weekdaysRegex, this._weekdaysMinRegex = this._weekdaysRegex, this._weekdaysStrictRegex = RegExp("^(" + r.join("|") + ")", "i"), this._weekdaysShortStrictRegex = RegExp("^(" + n.join("|") + ")", "i"), this._weekdaysMinStrictRegex = RegExp("^(" + t.join("|") + ")", "i");
}
function Ut(e) {
	var t, n;
	for (n in lt(this, e), At(this, e), e) o(e, n) && (t = e[n], _(t) ? this[n] = t : this["_" + n] = t);
	this._config = e, this._dayOfMonthOrdinalParseLenient = RegExp((this._dayOfMonthOrdinalParse.source || this._ordinalParse.source) + "|\\d{1,2}");
}
function Wt(e, t) {
	var n = f({}, e), r;
	for (r in t) o(t, r) && (a(e[r]) && a(t[r]) ? (n[r] = {}, f(n[r], e[r]), f(n[r], t[r])) : t[r] == null ? delete n[r] : n[r] = t[r]);
	for (r in e) o(e, r) && !o(t, r) && a(e[r]) && (n[r] = f({}, n[r]));
	return n;
}
function Gt(e) {
	e != null && this.set(e);
}
var Kt = Object.keys ? Object.keys : function(e) {
	var t, n = [];
	for (t in e) o(e, t) && n.push(t);
	return n;
}, qt = {
	sameDay: "[Today at] LT",
	nextDay: "[Tomorrow at] LT",
	nextWeek: "dddd [at] LT",
	lastDay: "[Yesterday at] LT",
	lastWeek: "[Last] dddd [at] LT",
	sameElse: "L"
};
function Jt(e, t, n) {
	var r = this._calendar[e] || this._calendar.sameElse;
	return _(r) ? r.call(t, n) : r;
}
var Yt = {
	LTS: "h:mm:ss A",
	LT: "h:mm A",
	L: "MM/DD/YYYY",
	LL: "MMMM D, YYYY",
	LLL: "MMMM D, YYYY h:mm A",
	LLLL: "dddd, MMMM D, YYYY h:mm A"
};
function Xt(e) {
	var t = this._longDateFormat[e], n = this._longDateFormat[e.toUpperCase()], r = this._longDateFormatCache;
	return t || !n ? t : r && r[e] && r[e].formatUpper === n ? r[e].format : (t = n.match(he).map(function(e) {
		return e === "MMMM" || e === "MM" || e === "DD" || e === "dddd" ? e.slice(1) : e;
	}).join(""), r ||= this._longDateFormatCache = {}, r[e] = {
		formatUpper: n,
		format: t
	}, t);
}
var Zt = "Invalid date";
function Qt() {
	return this._invalidDate;
}
var $t = "%d", en = /\d{1,2}/;
function tn(e) {
	return this._ordinal.replace("%d", e);
}
var nn = {
	future: "in %s",
	past: "%s ago",
	s: "a few seconds",
	ss: "%d seconds",
	m: "a minute",
	mm: "%d minutes",
	h: "an hour",
	hh: "%d hours",
	d: "a day",
	dd: "%d days",
	w: "a week",
	ww: "%d weeks",
	M: "a month",
	MM: "%d months",
	y: "a year",
	yy: "%d years"
};
function rn(e, t, n, r) {
	var i = this._relativeTime[n];
	return _(i) ? i(e, t, n, r) : i.replace(/%d/i, e);
}
function an(e, t, n, r) {
	return this.postformat(rn.call(this, e, t, n, r));
}
function on(e, t) {
	var n = this._relativeTime[e > 0 ? "future" : "past"];
	return _(n) ? n(t) : n.replace(/%s/i, t);
}
function sn(e, t) {
	return this.postformat(on.call(this, e, t));
}
function cn(e, t, n, r, i, a, o) {
	var s;
	return e < 100 && e >= 0 ? (s = new Date(e + 400, t, n, r, i, a, o), isFinite(s.getFullYear()) && s.setFullYear(e)) : s = new Date(e, t, n, r, i, a, o), s;
}
function R(e) {
	var t, n;
	return e < 100 && e >= 0 ? (n = Array.prototype.slice.call(arguments), n[0] = e + 400, t = new Date(Date.UTC.apply(null, n)), isFinite(t.getUTCFullYear()) && t.setUTCFullYear(e)) : t = new Date(Date.UTC.apply(null, arguments)), t;
}
function ln(e, t, n) {
	var r = 7 + t - n;
	return -((7 + R(e, 0, r).getUTCDay() - t) % 7) + r - 1;
}
function un(e, t, n, r, i) {
	var a = (7 + n - r) % 7, o = ln(e, r, i), s = 1 + 7 * (t - 1) + a + o, c, l;
	return s <= 0 ? (c = e - 1, l = qe(c) + s) : s > qe(e) ? (c = e + 1, l = s - qe(e)) : (c = e, l = s), {
		year: c,
		dayOfYear: l
	};
}
function dn(e, t, n, r) {
	var i = ln(e, n, r), a = Math.floor((t - i - 1) / 7) + 1, o, s;
	return a < 1 ? (s = e - 1, o = a + z(s, n, r)) : a > z(e, n, r) ? (o = a - z(e, n, r), s = e + 1) : (s = e, o = a), {
		week: o,
		year: s
	};
}
function fn(e, t, n) {
	return dn(e.year(), e.dayOfYear(), t, n);
}
function pn(e, t, n, r, i) {
	return dn(e, Math.round((R(e, t, n) - R(e, 0, 1)) / 864e5) + 1, r, i);
}
function z(e, t, n) {
	var r = ln(e, t, n), i = ln(e + 1, t, n);
	return (qe(e) - r + i) / 7;
}
b("w", ["ww", 2], "wo", "week"), b("W", ["WW", 2], "Wo", "isoWeek"), w("w", S, Le), w("ww", S, x), w("W", S, Le), w("WW", S, x), k([
	"w",
	"ww",
	"W",
	"WW"
], function(e, t, n, r) {
	t[r.substr(0, 1)] = D(e);
});
function mn(e) {
	return fn(e, this._week.dow, this._week.doy).week;
}
var hn = {
	dow: 0,
	doy: 6
};
function gn() {
	return this._week.dow;
}
function _n() {
	return this._week.doy;
}
function vn(e) {
	var t = this.localeData().week(this);
	return e == null ? t : this.add((e - t) * 7, "d");
}
function yn(e) {
	var t = fn(this, 1, 4).week;
	return e == null ? t : this.add((e - t) * 7, "d");
}
function bn() {
	return this.hours() % 12 || 12;
}
function xn() {
	return this.hours() || 24;
}
b("H", ["HH", 2], 0, "hour"), b("h", ["hh", 2], 0, bn), b("k", ["kk", 2], 0, xn), b("hmm", 0, 0, function() {
	return "" + bn.apply(this) + y(this.minutes(), 2);
}), b("hmmss", 0, 0, function() {
	return "" + bn.apply(this) + y(this.minutes(), 2) + y(this.seconds(), 2);
}), b("Hmm", 0, 0, function() {
	return "" + this.hours() + y(this.minutes(), 2);
}), b("Hmmss", 0, 0, function() {
	return "" + this.hours() + y(this.minutes(), 2) + y(this.seconds(), 2);
});
function Sn(e, t) {
	b(e, 0, 0, function() {
		return this.localeData().meridiem(this.hours(), this.minutes(), t);
	});
}
Sn("a", !0), Sn("A", !1);
function Cn(e, t) {
	return t._meridiemParse;
}
w("a", Cn), w("A", Cn), w("H", S, Re), w("h", S, Le), w("k", S, Le), w("HH", S, x), w("hh", S, x), w("kk", S, x), w("hmm", De), w("hmmss", Oe), w("Hmm", De), w("Hmmss", Oe), O(["H", "HH"], N), O(["k", "kk"], function(e, t, n) {
	var r = D(e);
	t[N] = r === 24 ? 0 : r;
}), O(["a", "A"], function(e, t, n) {
	n._isPm = n._locale.isPM(e), n._meridiem = e;
}), O(["h", "hh"], function(e, t, n) {
	t[N] = D(e), m(n).bigHour = !0;
}), O("hmm", function(e, t, n) {
	var r = e.length - 2;
	t[N] = D(e.substr(0, r)), t[P] = D(e.substr(r)), m(n).bigHour = !0;
}), O("hmmss", function(e, t, n) {
	var r = e.length - 4, i = e.length - 2;
	t[N] = D(e.substr(0, r)), t[P] = D(e.substr(r, 2)), t[F] = D(e.substr(i)), m(n).bigHour = !0;
}), O("Hmm", function(e, t, n) {
	var r = e.length - 2;
	t[N] = D(e.substr(0, r)), t[P] = D(e.substr(r));
}), O("Hmmss", function(e, t, n) {
	var r = e.length - 4, i = e.length - 2;
	t[N] = D(e.substr(0, r)), t[P] = D(e.substr(r, 2)), t[F] = D(e.substr(i));
});
function wn(e) {
	return (e + "").toLowerCase().charAt(0) === "p";
}
var Tn = /[ap]\.?m?\.?/i, En = Xe("Hours", !0);
function Dn(e, t, n) {
	return e > 11 ? n ? "pm" : "PM" : n ? "am" : "AM";
}
var On = {
	calendar: qt,
	longDateFormat: Yt,
	invalidDate: Zt,
	ordinal: $t,
	dayOfMonthOrdinalParse: en,
	relativeTime: nn,
	months: rt,
	monthsShort: it,
	week: hn,
	weekdays: Ct,
	weekdaysMin: Tt,
	weekdaysShort: wt,
	meridiemParse: Tn
}, B = {}, kn = {}, An;
function jn(e, t) {
	var n, r = Math.min(e.length, t.length);
	for (n = 0; n < r; n += 1) if (e[n] !== t[n]) return n;
	return r;
}
function Mn(e) {
	return e && e.toLowerCase().replace("_", "-");
}
function Nn(e) {
	for (var t = 0, n, r, i, a; t < e.length;) {
		for (a = Mn(e[t]).split("-"), n = a.length, r = Mn(e[t + 1]), r = r ? r.split("-") : null; n > 0;) {
			if (i = Fn(a.slice(0, n).join("-")), i) return i;
			if (r && r.length >= n && jn(a, r) >= n - 1) break;
			n--;
		}
		t++;
	}
	return An;
}
function Pn(e) {
	return typeof e == "string" && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(e);
}
function Fn(t) {
	var n = null, r, i;
	if (o(B, t)) return B[t];
	if (i = Mn(t), o(B, i)) return B[i];
	if (typeof module < "u" && module && module.exports && Pn(i)) try {
		n = An._abbr, r = e, r("./locale/" + i), V(n);
	} catch {
		B[i] = null;
	}
	if (o(B, i)) return B[i];
}
function V(e, t) {
	var n;
	return e && (n = c(t) ? H(e) : In(e, t), n ? An = n : typeof console < "u" && console.warn && console.warn("Locale " + e + " not found. Did you forget to load it?")), An._abbr;
}
function In(e, t) {
	if (t !== null) {
		var n, r = On;
		if (t.abbr = e, B[e] != null) ue("defineLocaleOverride", "use moment.updateLocale(localeName, config) to change an existing locale. moment.defineLocale(localeName, config) should only be used for creating a new locale See http://momentjs.com/guides/#/warnings/define-locale/ for more info."), r = B[e]._config;
		else if (t.parentLocale != null) {
			if (B[t.parentLocale] != null) r = B[t.parentLocale]._config;
			else if (n = Fn(t.parentLocale), n != null) r = n._config;
			else return kn[t.parentLocale] || (kn[t.parentLocale] = []), kn[t.parentLocale].push({
				name: e,
				config: t
			}), null;
		}
		return B[e] = new Gt(Wt(r, t)), kn[e] && kn[e].forEach(function(e) {
			In(e.name, e.config);
		}), V(e), B[e];
	}
	return delete B[e], null;
}
function Ln(e, t) {
	var n, r = Fn(e), i = On;
	return r != null && (e = r._abbr), t == null ? B[e] != null && (B[e].parentLocale == null ? B[e] != null && delete B[e] : (B[e] = B[e].parentLocale, e === V() && V(e))) : (B[e] != null && B[e].parentLocale != null ? B[e].set(Wt(B[e]._config, t)) : (r != null && (i = r._config), t = Wt(i, t), r ?? (t.abbr = e), n = new Gt(t), n.parentLocale = B[e], B[e] = n), V(e)), B[e];
}
function H(e) {
	var t;
	if (e && e._locale && e._locale._abbr && (e = e._locale._abbr), !e) return An;
	if (!i(e)) {
		if (t = Fn(e), t) return t;
		e = [e];
	}
	return Nn(e);
}
function Rn() {
	return Kt(B);
}
function zn(e) {
	var t, n = e._a;
	return n && m(e).overflow === -2 && (t = n[j] < 0 || n[j] > 11 ? j : n[M] < 1 || n[M] > nt(n[A], n[j]) ? M : n[N] < 0 || n[N] > 24 || n[N] === 24 && (n[P] !== 0 || n[F] !== 0 || n[I] !== 0) ? N : n[P] < 0 || n[P] > 59 ? P : n[F] < 0 || n[F] > 59 ? F : n[I] < 0 || n[I] > 999 ? I : -1, m(e)._overflowDayOfYear && (t < A || t > M) && (t = M), m(e)._overflowWeeks && t === -1 && (t = Ge), m(e)._overflowWeekday && t === -1 && (t = Ke), m(e).overflow = t), e;
}
var Bn = /^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/, Vn = /^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d|))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/, Hn = /Z|[+-]\d\d(?::?\d\d)?/, Un = [
	["YYYYYY-MM-DD", /[+-]\d{6}-\d\d-\d\d/],
	["YYYY-MM-DD", /\d{4}-\d\d-\d\d/],
	["GGGG-[W]WW-E", /\d{4}-W\d\d-\d/],
	[
		"GGGG-[W]WW",
		/\d{4}-W\d\d/,
		!1
	],
	["YYYY-DDD", /\d{4}-\d{3}/],
	[
		"YYYY-MM",
		/\d{4}-\d\d/,
		!1
	],
	["YYYYYYMMDD", /[+-]\d{10}/],
	["YYYYMMDD", /\d{8}/],
	["GGGG[W]WWE", /\d{4}W\d{3}/],
	[
		"GGGG[W]WW",
		/\d{4}W\d{2}/,
		!1
	],
	["YYYYDDD", /\d{7}/],
	[
		"YYYYMM",
		/\d{6}/,
		!1
	],
	[
		"YYYY",
		/\d{4}/,
		!1
	]
], Wn = [
	["HH:mm:ss.SSSS", /\d\d:\d\d:\d\d\.\d+/],
	["HH:mm:ss,SSSS", /\d\d:\d\d:\d\d,\d+/],
	["HH:mm:ss", /\d\d:\d\d:\d\d/],
	["HH:mm", /\d\d:\d\d/],
	["HHmmss.SSSS", /\d\d\d\d\d\d\.\d+/],
	["HHmmss,SSSS", /\d\d\d\d\d\d,\d+/],
	["HHmmss", /\d\d\d\d\d\d/],
	["HHmm", /\d\d\d\d/],
	["HH", /\d\d/]
], Gn = /^\/?Date\((-?\d+)/i, Kn = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),?\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|([+-]\d{4}))$/, qn = {
	UT: 0,
	GMT: 0,
	EDT: -240,
	EST: -300,
	CDT: -300,
	CST: -360,
	MDT: -360,
	MST: -420,
	PDT: -420,
	PST: -480
};
function Jn(e) {
	var t, n, r = e._i, i = Bn.exec(r) || Vn.exec(r), a, o, s, c, l = Un.length, u = Wn.length;
	if (i) {
		for (m(e).iso = !0, t = 0, n = l; t < n; t++) if (Un[t][1].exec(i[1])) {
			o = Un[t][0], a = Un[t][2] !== !1;
			break;
		}
		if (o == null) {
			e._isValid = !1;
			return;
		}
		if (i[3]) {
			for (t = 0, n = u; t < n; t++) if (Wn[t][1].exec(i[3])) {
				s = (i[2] || " ") + Wn[t][0];
				break;
			}
			if (s == null) {
				e._isValid = !1;
				return;
			}
		}
		if (!a && s != null) {
			e._isValid = !1;
			return;
		}
		if (i[4]) {
			if (Hn.exec(i[4])) c = "Z";
			else {
				e._isValid = !1;
				return;
			}
		}
		e._f = o + (s || "") + (c || ""), cr(e);
	} else e._isValid = !1;
}
function Yn(e, t, n, r, i, a) {
	var o = [
		Xn(e),
		it.indexOf(t),
		parseInt(n, 10),
		parseInt(r, 10),
		parseInt(i, 10)
	];
	return a && o.push(parseInt(a, 10)), o;
}
function Xn(e) {
	var t = parseInt(e, 10);
	return t <= 49 ? 2e3 + t : t <= 999 ? 1900 + t : t;
}
function Zn(e) {
	return e.replace(/\([^()]*\)|[\n\t]/g, " ").replace(/(\s\s+)/g, " ").replace(/^\s\s*/, "").replace(/\s\s*$/, "");
}
function Qn(e, t, n) {
	return e && wt.indexOf(e) !== new Date(t[0], t[1], t[2]).getDay() ? (m(n).weekdayMismatch = !0, n._isValid = !1, !1) : !0;
}
function $n(e, t, n) {
	if (e) return qn[e];
	if (t) return 0;
	var r = parseInt(n, 10), i = r % 100;
	return (r - i) / 100 * 60 + i;
}
function er(e) {
	var t = Kn.exec(Zn(e._i)), n;
	if (t) {
		if (n = Yn(t[4], t[3], t[2], t[5], t[6], t[7]), !Qn(t[1], n, e)) return;
		e._a = n, e._tzm = $n(t[8], t[9], t[10]), e._d = R.apply(null, e._a), e._d.setUTCMinutes(e._d.getUTCMinutes() - e._tzm), m(e).rfc2822 = !0;
	} else e._isValid = !1;
}
function tr(e) {
	var t = Gn.exec(e._i);
	if (t !== null) {
		e._d = /* @__PURE__ */ new Date(+t[1]);
		return;
	}
	if (Jn(e), e._isValid === !1) delete e._isValid;
	else return;
	if (er(e), e._isValid === !1) delete e._isValid;
	else return;
	e._strict ? e._isValid = !1 : n.createFromInputFallback(e);
}
n.createFromInputFallback = g("value provided is not in a recognized RFC2822 or ISO format. moment construction falls back to js Date(), which is not reliable across all browsers and versions. Non RFC2822/ISO date formats are discouraged. Please refer to http://momentjs.com/guides/#/warnings/js-date/ for more info.", function(e) {
	e._d = /* @__PURE__ */ new Date(e._i + (e._useUTC ? " UTC" : ""));
});
function nr(e, t, n) {
	return e ?? t ?? n;
}
function rr(e, t, r) {
	var i = Object.prototype.hasOwnProperty.call(e, "_isDefaultDatePartsForWeek"), a = e._isDefaultDatePartsForWeek;
	e._isDefaultDatePartsForWeek = !!r;
	try {
		return n._getDefaultDateParts(e, t, r);
	} finally {
		i ? e._isDefaultDatePartsForWeek = a : delete e._isDefaultDatePartsForWeek;
	}
}
function ir(e) {
	var t = e._defaultDatePartsNow;
	return t ? (t.hasValue ||= (t.value = n.now(), !0), t.value) : n.now();
}
function ar(e, t, n) {
	var r = n || e._isDefaultDatePartsForWeek, i = r ? U(t) : new Date(t);
	return r ? [
		i.year(),
		i.month(),
		i.date()
	] : e._useUTC ? [
		i.getUTCFullYear(),
		i.getUTCMonth(),
		i.getUTCDate()
	] : [
		i.getFullYear(),
		i.getMonth(),
		i.getDate()
	];
}
n._getDefaultDateParts = ar;
function or(e) {
	var t, n, r = [], i, a, o, s, c;
	if (!e._d) {
		for ((e._a[A] == null || e._a[j] == null || e._a[M] == null) && (i = ir(e), a = rr(e, i)), e._w && e._a[M] == null && e._a[j] == null && sr(e, rr(e, i, !0)), e._dayOfYear != null && (s = e._a[A] == null ? a[A] : e._a[A], (e._dayOfYear > qe(s) || e._dayOfYear === 0) && (m(e)._overflowDayOfYear = !0), n = R(s, 0, e._dayOfYear), e._a[j] = n.getUTCMonth(), e._a[M] = n.getUTCDate()), c = e._a[A] == null || e._a[j] == null || e._a[M] == null, t = 0; t < 3 && e._a[t] == null; ++t) e._a[t] = r[t] = a[t];
		for (; t < 7; t++) e._a[t] = r[t] = e._a[t] == null ? +(t === 2) : e._a[t];
		e._a[N] === 24 && e._a[P] === 0 && e._a[F] === 0 && e._a[I] === 0 && (e._nextDay = !0, e._a[N] = 0), e._d = (e._useUTC ? R : cn).apply(null, r), o = e._useUTC ? e._d.getUTCDay() : e._d.getDay(), e._tzm != null && e._d.setUTCMinutes(e._d.getUTCMinutes() - e._tzm), e._nextDay && (e._a[N] = 24), e._w && typeof e._w.d < "u" && !c && e._w.d !== o && (m(e).weekdayMismatch = !0);
	}
}
function sr(e, t) {
	var n = e._w, r, i, a, o, s, c, l, u;
	n.GG != null || n.W != null || n.E != null ? (o = 1, s = 4, r = nr(n.GG, e._a[A], pn(t[A], t[j], t[M], 1, 4).year), i = nr(n.W, 1), a = nr(n.E, 1), (a < 1 || a > 7) && (l = !0)) : (o = e._locale._week.dow, s = e._locale._week.doy, u = pn(t[A], t[j], t[M], o, s), r = nr(n.gg, e._a[A], u.year), i = nr(n.w, u.week), n.d == null ? n.e == null ? a = o : (a = n.e + o, (n.e < 0 || n.e > 6) && (l = !0)) : (a = n.d, (a < 0 || a > 6) && (l = !0))), i < 1 || i > z(r, o, s) ? m(e)._overflowWeeks = !0 : l == null ? (c = un(r, i, a, o, s), e._a[A] = c.year, e._dayOfYear = c.dayOfYear) : m(e)._overflowWeekday = !0;
}
n.ISO_8601 = function() {}, n.RFC_2822 = function() {};
function cr(e) {
	if (e._f === n.ISO_8601) {
		Jn(e);
		return;
	}
	if (e._f === n.RFC_2822) {
		er(e);
		return;
	}
	e._a = [], m(e).empty = !0;
	var t = "" + e._i, r, i, a, o, s, c = t.length, l = 0, u, d;
	for (a = Se(e._f, e._locale).match(he) || [], d = a.length, r = 0; r < d; r++) o = a[r], i = (t.match(Be(o, e)) || [])[0], i && (s = t.substr(0, t.indexOf(i)), s.length > 0 && m(e).unusedInput.push(s), t = t.slice(t.indexOf(i) + i.length), l += i.length), ve[o] ? (i ? m(e).empty = !1 : m(e).unusedTokens.push(o), Ue(o, i, e)) : e._strict && !i && m(e).unusedTokens.push(o);
	m(e).charsLeftOver = c - l, t.length > 0 && m(e).unusedInput.push(t), e._a[N] <= 12 && m(e).bigHour === !0 && e._a[N] > 0 && (m(e).bigHour = void 0), m(e).parsedDateParts = e._a.slice(0), m(e).meridiem = e._meridiem, e._a[N] = lr(e._locale, e._a[N], e._meridiem), u = m(e).era, u !== null && (e._a[A] = e._locale.erasConvertYear(u, e._a[A])), or(e), zn(e);
}
function lr(e, t, n) {
	var r;
	return n == null ? t : e.meridiemHour == null ? (e.isPM != null && (r = e.isPM(n), r && t < 12 && (t += 12), !r && t === 12 && (t = 0)), t) : e.meridiemHour(t, n);
}
function ur(e) {
	var t, n, r, i, a, o, s = !1, c = {}, l = e._f.length;
	if (l === 0) {
		m(e).invalidFormat = !0, e._d = /* @__PURE__ */ new Date(NaN);
		return;
	}
	for (i = 0; i < l; i++) a = 0, o = !1, t = oe({}, e), e._useUTC != null && (t._useUTC = e._useUTC), t._defaultDatePartsNow = c, t._f = e._f[i], cr(t), ne(t) && (o = !0), a += m(t).charsLeftOver, a += m(t).unusedTokens.length * 10, m(t).score = a, s ? a < r && (r = a, n = t) : (r == null || a < r || o) && (r = a, n = t, o && (s = !0));
	f(e, n || t);
}
function dr(e) {
	if (!e._d) {
		var t = fe(e._i), n = t.day === void 0 ? t.date : t.day;
		e._a = d([
			t.year,
			t.month,
			n,
			t.hour,
			t.minute,
			t.second,
			t.millisecond
		], function(e) {
			return e && parseInt(e, 10);
		}), or(e);
	}
}
function fr(e) {
	var t = new se(zn(pr(e)));
	return t._nextDay &&= (t.add(1, "d"), void 0), t;
}
function pr(e) {
	var t = e._i, n = e._f;
	return e._locale = e._locale || H(e._l), t === null || n === void 0 && t === "" ? re({ nullInput: !0 }) : (typeof t == "string" && (e._i = t = e._locale.preparse(t)), h(t) ? new se(zn(t)) : (u(t) ? e._d = t : i(n) ? ur(e) : n ? cr(e) : mr(e), ne(e) || (e._d = null), e));
}
function mr(e) {
	var t = e._i;
	c(t) ? e._d = new Date(n.now()) : u(t) ? e._d = new Date(t.valueOf()) : typeof t == "string" ? tr(e) : i(t) ? (e._a = d(t.slice(0), function(e) {
		return parseInt(e, 10);
	}), or(e)) : a(t) ? dr(e) : l(t) ? e._d = new Date(t) : n.createFromInputFallback(e);
}
function hr(e, t, n, r, o) {
	var c = {};
	return (t === !0 || t === !1) && (r = t, t = void 0), (n === !0 || n === !1) && (r = n, n = void 0), (a(e) && s(e) || i(e) && e.length === 0) && (e = void 0), c._isAMomentObject = !0, c._useUTC = c._isUTC = o, c._l = n, c._i = e, c._f = t, c._strict = r, fr(c);
}
function U(e, t, n, r) {
	return hr(e, t, n, r, !1);
}
var gr = g("moment().min is deprecated, use moment.max instead. http://momentjs.com/guides/#/warnings/min-max/", function() {
	var e = U.apply(null, arguments);
	return this.isValid() && e.isValid() ? e < this ? this : e : re();
}), _r = g("moment().max is deprecated, use moment.min instead. http://momentjs.com/guides/#/warnings/min-max/", function() {
	var e = U.apply(null, arguments);
	return this.isValid() && e.isValid() ? e > this ? this : e : re();
});
function vr(e, t) {
	var n, r;
	if (t.length === 1 && i(t[0]) && (t = t[0]), !t.length) return U();
	for (r = 0; r < t.length; ++r) if (h(t[r])) {
		n = t[r];
		break;
	}
	if (!n) return re();
	for (++r; r < t.length; ++r) h(t[r]) && (!t[r].isValid() || t[r][e](n)) && (n = t[r]);
	return n;
}
function yr() {
	return vr("isBefore", [].slice.call(arguments, 0));
}
function br() {
	return vr("isAfter", [].slice.call(arguments, 0));
}
var xr = function() {
	return Date.now ? Date.now() : +/* @__PURE__ */ new Date();
}, Sr = [
	"year",
	"quarter",
	"month",
	"week",
	"day",
	"hour",
	"minute",
	"second",
	"millisecond"
];
function Cr(e) {
	var t, n = !1, r, i = Sr.length;
	for (t in e) if (o(e, t) && !(L.call(Sr, t) !== -1 && (e[t] == null || !isNaN(e[t])))) return !1;
	for (r = 0; r < i; ++r) if (e[Sr[r]]) {
		if (n) return !1;
		parseFloat(e[Sr[r]]) !== D(e[Sr[r]]) && (n = !0);
	}
	return !0;
}
function wr() {
	return this._isValid;
}
function Tr() {
	return W(NaN);
}
function Er(e) {
	var t = fe(e), n = t.year || 0, r = t.quarter || 0, i = t.month || 0, a = t.week || t.isoWeek || 0, o = t.day || 0, s = t.hour || 0, c = t.minute || 0, l = t.second || 0, u = t.millisecond || 0;
	this._isValid = Cr(t), this._milliseconds = +u + l * 1e3 + c * 6e4 + s * 1e3 * 60 * 60, this._days = +o + a * 7, this._months = +i + r * 3 + n * 12, this._data = {}, this._locale = H(), this._bubble();
}
function Dr(e) {
	return e instanceof Er;
}
function Or(e) {
	return e < 0 ? Math.round(-1 * e) * -1 : Math.round(e);
}
function kr(e, t, n) {
	var r = Math.min(e.length, t.length), i = Math.abs(e.length - t.length), a = 0, o;
	for (o = 0; o < r; o++) D(e[o]) !== D(t[o]) && a++;
	return a + i;
}
function Ar(e, t) {
	b(e, 0, 0, function() {
		var e = this.utcOffset(), n = "+";
		return e < 0 && (e = -e, n = "-"), n + y(~~(e / 60), 2) + t + y(~~e % 60, 2);
	});
}
Ar("Z", ":"), Ar("ZZ", ""), w("Z", Pe), w("ZZ", Pe), O(["Z", "ZZ"], function(e, t, n) {
	var r = Mr(Pe, e);
	n._useUTC = !0, n._tzm = r, r === null && (m(n).invalidOffset = e);
});
var jr = /([\+\-]|\d\d)/gi;
function Mr(e, t) {
	var n = (t || "").match(e), r, i, a;
	return n === null || (r = n[n.length - 1] || [], i = (r + "").match(jr) || [
		"-",
		0,
		0
	], a = +(i[1] * 60) + D(i[2]), D(i[2]) > 59 || (i[0] === "+" ? a > 840 : a > 720)) ? null : a === 0 ? 0 : i[0] === "+" ? a : -a;
}
function Nr(e, t) {
	var r, i;
	return t._isUTC ? (r = t.clone(), i = (h(e) || u(e) ? e.valueOf() : U(e).valueOf()) - r.valueOf(), r._d.setTime(r._d.valueOf() + i), n.updateOffset(r, !1), r) : U(e).local();
}
function Pr(e) {
	return -Math.round(e._d.getTimezoneOffset());
}
n.updateOffset = function() {};
function Fr(e, t, r) {
	var i = this._offset || 0, a;
	if (!this.isValid()) return e == null ? NaN : this;
	if (e != null) {
		if (typeof e == "string") {
			if (e = Mr(Pe, e), e === null) return this;
		} else Math.abs(e) < 16 && !r && (e *= 60);
		return !this._isUTC && t && (a = Pr(this)), this._offset = e, this._isUTC = !0, a != null && this.add(a, "m"), i !== e && (!t || this._changeInProgress ? Zr(this, W(e - i, "m"), 1, !1) : this._changeInProgress ||= (this._changeInProgress = !0, n.updateOffset(this, !0), null)), this;
	}
	return this._isUTC ? i : Pr(this);
}
function Ir(e, t) {
	return e == null ? -this.utcOffset() : (typeof e != "string" && (e = -e), this.utcOffset(e, t), this);
}
function Lr(e) {
	return this.utcOffset(0, e);
}
function Rr(e) {
	return this._isUTC && (this.utcOffset(0, e), this._isUTC = !1, e && this.subtract(Pr(this), "m")), this;
}
function zr() {
	if (this._tzm != null) this.utcOffset(this._tzm, !1, !0);
	else if (typeof this._i == "string") {
		var e = Mr(Ne, this._i);
		e == null ? this.utcOffset(0, !0) : this.utcOffset(e);
	}
	return this;
}
function Br(e) {
	return this.isValid() ? (e = e ? U(e).utcOffset() : 0, (this.utcOffset() - e) % 60 == 0) : !1;
}
function Vr() {
	return this.utcOffset() > this.clone().month(0).utcOffset() || this.utcOffset() > this.clone().month(5).utcOffset();
}
function Hr() {
	if (!c(this._isDSTShifted)) return this._isDSTShifted;
	var e = {}, t;
	return oe(e, this), e = pr(e), e._a ? (t = e._isUTC ? p(e._a) : U(e._a), this._isDSTShifted = this.isValid() && kr(e._a, t.toArray()) > 0) : this._isDSTShifted = !1, this._isDSTShifted;
}
function Ur() {
	return this.isValid() ? !this._isUTC : !1;
}
function Wr() {
	return this.isValid() ? this._isUTC : !1;
}
function Gr() {
	return this.isValid() ? this._isUTC && this._offset === 0 : !1;
}
var Kr = /^(-|\+)?(?:(\d*)[. ])?(\d+):(\d+)(?::(\d+)(\.\d*)?)?$/, qr = /^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/;
function W(e, t) {
	var n = e, r = null, i, a, s;
	return Dr(e) ? n = {
		ms: e._milliseconds,
		d: e._days,
		M: e._months
	} : l(e) || !isNaN(+e) ? (n = {}, t ? n[t] = +e : n.milliseconds = +e) : (r = Kr.exec(e)) ? (i = r[1] === "-" ? -1 : 1, n = {
		y: 0,
		d: D(r[M]) * i,
		h: D(r[N]) * i,
		m: D(r[P]) * i,
		s: D(r[F]) * i,
		ms: D(Or(r[I] * 1e3)) * i
	}) : (r = qr.exec(e)) ? (i = r[1] === "-" ? -1 : 1, n = {
		y: G(r[2], i),
		M: G(r[3], i),
		w: G(r[4], i),
		d: G(r[5], i),
		h: G(r[6], i),
		m: G(r[7], i),
		s: G(r[8], i)
	}) : n == null ? n = {} : typeof n == "object" && ("from" in n || "to" in n) && (s = Yr(U(n.from), U(n.to)), n = {}, n.ms = s.milliseconds, n.M = s.months), a = new Er(n), Dr(e) && o(e, "_locale") && (a._locale = e._locale), Dr(e) && o(e, "_isValid") && (a._isValid = e._isValid), a;
}
W.fn = Er.prototype, W.invalid = Tr;
function G(e, t) {
	var n = e && parseFloat(e.replace(",", "."));
	return (isNaN(n) ? 0 : n) * t;
}
function Jr(e, t) {
	var n = {};
	return n.months = t.month() - e.month() + (t.year() - e.year()) * 12, e.clone().add(n.months, "M").isAfter(t) && --n.months, n.milliseconds = +t - e.clone().add(n.months, "M"), n;
}
function Yr(e, t) {
	var n;
	return e.isValid() && t.isValid() ? (t = Nr(t, e), e.isBefore(t) ? n = Jr(e, t) : (n = Jr(t, e), n.milliseconds = -n.milliseconds, n.months = -n.months), n) : {
		milliseconds: 0,
		months: 0
	};
}
function Xr(e, t) {
	return function(n, r) {
		var i, a;
		return r !== null && !isNaN(+r) && (ue(t, "moment()." + t + "(period, number) is deprecated. Please use moment()." + t + "(number, period). See http://momentjs.com/guides/#/warnings/add-inverted-param/ for more info."), a = n, n = r, r = a), i = W(n, r), Zr(this, i, e), this;
	};
}
function Zr(e, t, r, i) {
	var a = t._milliseconds, o = Or(t._days), s = Or(t._months);
	e.isValid() && (i ??= !0, s && mt(e, Ze(e, "Month") + s * r), o && Qe(e, "Date", Ze(e, "Date") + o * r), a && e._d.setTime(e._d.valueOf() + a * r), i && n.updateOffset(e, o || s));
}
var Qr = Xr(1, "add"), $r = Xr(-1, "subtract");
function ei(e) {
	return typeof e == "string" || e instanceof String;
}
function ti(e) {
	return h(e) || u(e) || ei(e) || l(e) || ri(e) || ni(e) || e == null;
}
function ni(e) {
	var t = a(e) && !s(e), n = !1, r = [
		"years",
		"year",
		"y",
		"months",
		"month",
		"M",
		"days",
		"day",
		"d",
		"dates",
		"date",
		"D",
		"hours",
		"hour",
		"h",
		"minutes",
		"minute",
		"m",
		"seconds",
		"second",
		"s",
		"milliseconds",
		"millisecond",
		"ms"
	], i, c, l = r.length;
	for (i = 0; i < l; i += 1) c = r[i], n ||= o(e, c);
	return t && n;
}
function ri(e) {
	var t = i(e), n = !1;
	return t && (n = e.filter(function(t) {
		return !l(t) && ei(e);
	}).length === 0), t && n;
}
function ii(e) {
	var t = a(e) && !s(e), n = !1, r = [
		"sameDay",
		"nextDay",
		"lastDay",
		"nextWeek",
		"lastWeek",
		"sameElse"
	], i, c;
	for (i = 0; i < r.length; i += 1) c = r[i], n ||= o(e, c);
	return t && n;
}
function ai(e, t) {
	var n = e.diff(t, "days", !0);
	return n < -6 ? "sameElse" : n < -1 ? "lastWeek" : n < 0 ? "lastDay" : n < 1 ? "sameDay" : n < 2 ? "nextDay" : n < 7 ? "nextWeek" : "sameElse";
}
function oi(e, t) {
	arguments.length === 1 && (arguments[0] ? ti(arguments[0]) ? (e = arguments[0], t = void 0) : ii(arguments[0]) && (t = arguments[0], e = void 0) : (e = void 0, t = void 0));
	var r = e || U(), i = Nr(r, this).startOf("day"), a = n.calendarFormat(this, i) || "sameElse", o = t && (_(t[a]) ? t[a].call(this, r) : t[a]);
	return this.format(o || this.localeData().calendar(a, this, U(r)));
}
function si() {
	return new se(this);
}
function ci(e, t) {
	var n = h(e) ? e : U(e);
	return this.isValid() && n.isValid() ? (t = v(t) || "millisecond", t === "millisecond" ? this.valueOf() > n.valueOf() : n.valueOf() < this.clone().startOf(t).valueOf()) : !1;
}
function li(e, t) {
	var n = h(e) ? e : U(e);
	return this.isValid() && n.isValid() ? (t = v(t) || "millisecond", t === "millisecond" ? this.valueOf() < n.valueOf() : this.clone().endOf(t).valueOf() < n.valueOf()) : !1;
}
function ui(e, t, n, r) {
	var i = h(e) ? e : U(e), a = h(t) ? t : U(t);
	return this.isValid() && i.isValid() && a.isValid() ? (r ||= "()", (r[0] === "(" ? this.isAfter(i, n) : !this.isBefore(i, n)) && (r[1] === ")" ? this.isBefore(a, n) : !this.isAfter(a, n))) : !1;
}
function di(e, t) {
	var n = h(e) ? e : U(e), r;
	return this.isValid() && n.isValid() ? (t = v(t) || "millisecond", t === "millisecond" ? this.valueOf() === n.valueOf() : (r = n.valueOf(), this.clone().startOf(t).valueOf() <= r && r <= this.clone().endOf(t).valueOf())) : !1;
}
function fi(e, t) {
	return this.isSame(e, t) || this.isAfter(e, t);
}
function pi(e, t) {
	return this.isSame(e, t) || this.isBefore(e, t);
}
function mi(e, t, n) {
	var r, i, a;
	if (!this.isValid() || (r = Nr(e, this), !r.isValid())) return NaN;
	switch (i = (r.utcOffset() - this.utcOffset()) * 6e4, t = v(t), t) {
		case "year":
			a = hi(this, r) / 12;
			break;
		case "month":
			a = hi(this, r);
			break;
		case "quarter":
			a = hi(this, r) / 3;
			break;
		case "second":
			a = (this - r) / 1e3;
			break;
		case "minute":
			a = (this - r) / 6e4;
			break;
		case "hour":
			a = (this - r) / 36e5;
			break;
		case "day":
			a = (this - r - i) / 864e5;
			break;
		case "week":
			a = (this - r - i) / 6048e5;
			break;
		default: a = this - r;
	}
	return n ? a : E(a);
}
function hi(e, t) {
	if (e.date() < t.date()) return -hi(t, e);
	var n = (t.year() - e.year()) * 12 + (t.month() - e.month()), r = e.clone().add(n, "months"), i, a;
	return t - r < 0 ? (i = e.clone().add(n - 1, "months"), a = (t - r) / (r - i)) : (i = e.clone().add(n + 1, "months"), a = (t - r) / (i - r)), -(n + a) || 0;
}
n.defaultFormat = "YYYY-MM-DDTHH:mm:ssZ", n.defaultFormatUtc = "YYYY-MM-DDTHH:mm:ss[Z]";
function gi() {
	return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ");
}
function _i(e) {
	if (!this.isValid()) return null;
	var t = e !== !0, n = t ? this.clone().utc() : this;
	return n.year() < 0 || n.year() > 9999 ? xe(n, t ? "YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]" : "YYYYYY-MM-DD[T]HH:mm:ss.SSSZ") : _(Date.prototype.toISOString) ? t ? this.toDate().toISOString() : new Date(this.valueOf() + this.utcOffset() * 60 * 1e3).toISOString().replace("Z", xe(n, "Z")) : xe(n, t ? "YYYY-MM-DD[T]HH:mm:ss.SSS[Z]" : "YYYY-MM-DD[T]HH:mm:ss.SSSZ");
}
function vi() {
	if (!this.isValid()) return "moment.invalid(/* " + this._i + " */)";
	var e = "moment", t = "", n, r, i, a;
	return this.isLocal() || (e = this.utcOffset() === 0 ? "moment.utc" : "moment.parseZone", t = "Z"), n = "[" + e + "(\"]", r = 0 <= this.year() && this.year() <= 9999 ? "YYYY" : "YYYYYY", i = "-MM-DD[T]HH:mm:ss.SSS", a = t + "[\")]", this.format(n + r + i + a);
}
function yi(e) {
	e ||= this.isUtc() ? n.defaultFormatUtc : n.defaultFormat;
	var t = xe(this, e);
	return this.localeData().postformat(t);
}
function bi(e, t) {
	return this.isValid() && (h(e) && e.isValid() || U(e).isValid()) ? W({
		to: this,
		from: e
	}).locale(this.locale()).humanize(!t) : this.localeData().invalidDate();
}
function xi(e) {
	return this.from(U(), e);
}
function Si(e, t) {
	return this.isValid() && (h(e) && e.isValid() || U(e).isValid()) ? W({
		from: this,
		to: e
	}).locale(this.locale()).humanize(!t) : this.localeData().invalidDate();
}
function Ci(e) {
	return this.to(U(), e);
}
function wi(e) {
	var t;
	return e === void 0 ? this._locale._abbr : (t = H(e), t != null && (this._locale = t), this);
}
var Ti = g("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.", function(e) {
	return e === void 0 ? this.localeData() : this.locale(e);
});
function Ei() {
	return this._locale;
}
var Di = 1e3, Oi = 60 * Di, ki = 60 * Oi, Ai = 3506328 * ki;
function ji(e, t) {
	return (e % t + t) % t;
}
function Mi(e, t, n) {
	return e < 100 && e >= 0 ? new Date(e + 400, t, n) - Ai : new Date(e, t, n).valueOf();
}
function Ni(e, t, n) {
	return e < 100 && e >= 0 ? Date.UTC(e + 400, t, n) - Ai : Date.UTC(e, t, n);
}
function Pi(e) {
	var t, r;
	if (e = v(e), e === void 0 || e === "millisecond" || !this.isValid()) return this;
	switch (r = this._isUTC ? Ni : Mi, e) {
		case "year":
			t = r(this.year(), 0, 1);
			break;
		case "quarter":
			t = r(this.year(), this.month() - this.month() % 3, 1);
			break;
		case "month":
			t = r(this.year(), this.month(), 1);
			break;
		case "week":
			t = r(this.year(), this.month(), this.date() - this.weekday());
			break;
		case "isoWeek":
			t = r(this.year(), this.month(), this.date() - (this.isoWeekday() - 1));
			break;
		case "day":
		case "date":
			t = r(this.year(), this.month(), this.date());
			break;
		case "hour":
			t = this._d.valueOf(), t -= ji(t + (this._isUTC ? 0 : this.utcOffset() * Oi), ki);
			break;
		case "minute":
			t = this._d.valueOf(), t -= ji(t, Oi);
			break;
		case "second": t = this._d.valueOf(), t -= ji(t, Di);
	}
	return this._d.setTime(t), n.updateOffset(this, !0), this;
}
function Fi(e) {
	var t, r;
	if (e = v(e), e === void 0 || e === "millisecond" || !this.isValid()) return this;
	switch (r = this._isUTC ? Ni : Mi, e) {
		case "year":
			t = r(this.year() + 1, 0, 1) - 1;
			break;
		case "quarter":
			t = r(this.year(), this.month() - this.month() % 3 + 3, 1) - 1;
			break;
		case "month":
			t = r(this.year(), this.month() + 1, 1) - 1;
			break;
		case "week":
			t = r(this.year(), this.month(), this.date() - this.weekday() + 7) - 1;
			break;
		case "isoWeek":
			t = r(this.year(), this.month(), this.date() - (this.isoWeekday() - 1) + 7) - 1;
			break;
		case "day":
		case "date":
			t = r(this.year(), this.month(), this.date() + 1) - 1;
			break;
		case "hour":
			t = this._d.valueOf(), t += ki - ji(t + (this._isUTC ? 0 : this.utcOffset() * Oi), ki) - 1;
			break;
		case "minute":
			t = this._d.valueOf(), t += Oi - ji(t, Oi) - 1;
			break;
		case "second": t = this._d.valueOf(), t += Di - ji(t, Di) - 1;
	}
	return this._d.setTime(t), n.updateOffset(this, !0), this;
}
function Ii() {
	return this._d.valueOf() - (this._offset || 0) * 6e4;
}
function Li() {
	return Math.floor(this.valueOf() / 1e3);
}
function Ri() {
	return new Date(this.valueOf());
}
function zi() {
	var e = this;
	return [
		e.year(),
		e.month(),
		e.date(),
		e.hour(),
		e.minute(),
		e.second(),
		e.millisecond()
	];
}
function Bi() {
	var e = this;
	return {
		years: e.year(),
		months: e.month(),
		date: e.date(),
		hours: e.hours(),
		minutes: e.minutes(),
		seconds: e.seconds(),
		milliseconds: e.milliseconds()
	};
}
function Vi() {
	return this.isValid() ? this.toISOString() : null;
}
function Hi() {
	return ne(this);
}
function Ui() {
	return f({}, m(this));
}
function Wi() {
	return m(this).overflow;
}
function Gi() {
	return {
		input: this._i,
		format: this._f,
		locale: this._locale,
		isUTC: this._isUTC,
		strict: this._strict
	};
}
b("N", 0, 0, "eraAbbr"), b("NN", 0, 0, "eraAbbr"), b("NNN", 0, 0, "eraAbbr"), b("NNNN", 0, 0, "eraName"), b("NNNNN", 0, 0, "eraNarrow"), b("y", ["y", 1], "yo", "eraYear"), b("y", ["yy", 2], 0, "eraYear"), b("y", ["yyy", 3], 0, "eraYear"), b("y", ["yyyy", 4], 0, "eraYear"), w("N", na), w("NN", na), w("NNN", na), w("NNNN", ra), w("NNNNN", ia), O([
	"N",
	"NN",
	"NNN",
	"NNNN",
	"NNNNN"
], function(e, t, n, r) {
	var i = n._locale.erasParse(e, r, n._strict);
	i ? m(n).era = i : m(n).invalidEra = e;
}), w("y", C), w("yy", C), w("yyy", C), w("yyyy", C), w("yo", aa), O([
	"y",
	"yy",
	"yyy",
	"yyyy"
], A), O(["yo"], function(e, t, n, r) {
	var i;
	n._locale._eraYearOrdinalRegex && (i = e.match(n._locale._eraYearOrdinalRegex)), t[A] = n._locale.eraYearOrdinalParse ? n._locale.eraYearOrdinalParse(e, i) : parseInt(e, 10);
});
function Ki(e, t) {
	var r, i, a, o = this._eras || H("en")._eras;
	for (r = 0, i = o.length; r < i; ++r) switch (typeof o[r].since == "string" && (a = n(o[r].since).startOf("day"), o[r].since = a.valueOf()), typeof o[r].until) {
		case "undefined":
			o[r].until = 1 / 0;
			break;
		case "string": a = n(o[r].until).startOf("day").valueOf(), o[r].until = a.valueOf();
	}
	return o;
}
function qi(e, t, n) {
	var r, i, a = this.eras(), o, s, c;
	for (e = e.toUpperCase(), r = 0, i = a.length; r < i; ++r) if (o = a[r].name.toUpperCase(), s = a[r].abbr.toUpperCase(), c = a[r].narrow.toUpperCase(), n) switch (t) {
		case "N":
		case "NN":
		case "NNN":
			if (s === e) return a[r];
			break;
		case "NNNN":
			if (o === e) return a[r];
			break;
		case "NNNNN": if (c === e) return a[r];
	}
	else if ([
		o,
		s,
		c
	].indexOf(e) >= 0) return a[r];
}
function Ji(e, t) {
	var r = e.since <= e.until ? 1 : -1;
	return t === void 0 ? n(e.since).year() : n(e.since).year() + (t - e.offset) * r;
}
function Yi() {
	var e, t, n, r = this.localeData().eras();
	for (e = 0, t = r.length; e < t; ++e) if (n = this.clone().startOf("day").valueOf(), r[e].since <= n && n <= r[e].until || r[e].until <= n && n <= r[e].since) return r[e].name;
	return "";
}
function Xi() {
	var e, t, n, r = this.localeData().eras();
	for (e = 0, t = r.length; e < t; ++e) if (n = this.clone().startOf("day").valueOf(), r[e].since <= n && n <= r[e].until || r[e].until <= n && n <= r[e].since) return r[e].narrow;
	return "";
}
function Zi() {
	var e, t, n, r = this.localeData().eras();
	for (e = 0, t = r.length; e < t; ++e) if (n = this.clone().startOf("day").valueOf(), r[e].since <= n && n <= r[e].until || r[e].until <= n && n <= r[e].since) return r[e].abbr;
	return "";
}
function Qi() {
	var e, t, r, i, a = this.localeData().eras();
	for (e = 0, t = a.length; e < t; ++e) if (r = a[e].since <= a[e].until ? 1 : -1, i = this.clone().startOf("day").valueOf(), a[e].since <= i && i <= a[e].until || a[e].until <= i && i <= a[e].since) return (this.year() - n(a[e].since).year()) * r + a[e].offset;
	return this.year();
}
function $i(e) {
	return o(this, "_erasNameRegex") || oa.call(this), e ? this._erasNameRegex : this._erasRegex;
}
function ea(e) {
	return o(this, "_erasAbbrRegex") || oa.call(this), e ? this._erasAbbrRegex : this._erasRegex;
}
function ta(e) {
	return o(this, "_erasNarrowRegex") || oa.call(this), e ? this._erasNarrowRegex : this._erasRegex;
}
function na(e, t) {
	return t.erasAbbrRegex(e);
}
function ra(e, t) {
	return t.erasNameRegex(e);
}
function ia(e, t) {
	return t.erasNarrowRegex(e);
}
function aa(e, t) {
	return t._eraYearOrdinalRegex || C;
}
function oa() {
	var e = [], t = [], n = [], r = [], i, a, o, s, c, l = this.eras();
	for (i = 0, a = l.length; i < a; ++i) o = T(l[i].name), s = T(l[i].abbr), c = T(l[i].narrow), t.push(o), e.push(s), n.push(c), r.push(o), r.push(s), r.push(c);
	this._erasRegex = RegExp("^(" + r.join("|") + ")", "i"), this._erasNameRegex = RegExp("^(" + t.join("|") + ")", "i"), this._erasAbbrRegex = RegExp("^(" + e.join("|") + ")", "i"), this._erasNarrowRegex = RegExp("^(" + n.join("|") + ")", "i");
}
b(0, ["gg", 2], 0, function() {
	return this.weekYear() % 100;
}), b(0, ["GG", 2], 0, function() {
	return this.isoWeekYear() % 100;
});
function sa(e, t) {
	b(0, [e, e.length], 0, t);
}
sa("gggg", "weekYear"), sa("ggggg", "weekYear"), sa("GGGG", "isoWeekYear"), sa("GGGGG", "isoWeekYear"), w("G", Me), w("g", Me), w("GG", S, x), w("gg", S, x), w("GGGG", Ae, Te), w("gggg", Ae, Te), w("GGGGG", je, Ee), w("ggggg", je, Ee), k([
	"gggg",
	"ggggg",
	"GGGG",
	"GGGGG"
], function(e, t, n, r) {
	t[r.substr(0, 2)] = D(e);
}), k(["gg", "GG"], function(e, t, r, i) {
	t[i] = n.parseTwoDigitYear(e);
});
function ca(e) {
	return ma.call(this, e, this.week(), this.weekday() + this.localeData()._week.dow, this.localeData()._week.dow, this.localeData()._week.doy);
}
function la(e) {
	return ma.call(this, e, this.isoWeek(), this.isoWeekday(), 1, 4);
}
function ua() {
	return z(this.year(), 1, 4);
}
function da() {
	return z(this.isoWeekYear(), 1, 4);
}
function fa() {
	var e = this.localeData()._week;
	return z(this.year(), e.dow, e.doy);
}
function pa() {
	var e = this.localeData()._week;
	return z(this.weekYear(), e.dow, e.doy);
}
function ma(e, t, n, r, i) {
	var a;
	return e == null ? fn(this, r, i).year : (a = z(e, r, i), t > a && (t = a), ha.call(this, e, t, n, r, i));
}
function ha(e, t, n, r, i) {
	var a = un(e, t, n, r, i), o = R(a.year, 0, a.dayOfYear);
	return this.year(o.getUTCFullYear()), this.month(o.getUTCMonth()), this.date(o.getUTCDate()), this;
}
b("Q", 0, "Qo", "quarter"), w("Q", Ce), O("Q", function(e, t) {
	t[j] = (D(e) - 1) * 3;
});
function ga(e) {
	return e == null ? Math.ceil((this.month() + 1) / 3) : this.month((e - 1) * 3 + this.month() % 3);
}
b("D", ["DD", 2], "Do", "date"), w("D", S, Le), w("DD", S, x), w("Do", function(e, t) {
	return e ? t._dayOfMonthOrdinalParse || t._ordinalParse : t._dayOfMonthOrdinalParseLenient;
}), O(["D", "DD"], M), O("Do", function(e, t) {
	t[M] = D(e.match(S)[0]);
});
var _a = Xe("Date", !0);
b("DDD", ["DDDD", 3], "DDDo", "dayOfYear"), w("DDD", ke), w("DDDD", we), O(["DDD", "DDDD"], function(e, t, n) {
	n._dayOfYear = D(e);
});
function va(e) {
	var t = Math.round((this.clone().startOf("day") - this.clone().startOf("year")) / 864e5) + 1;
	return e == null ? t : this.add(e - t, "d");
}
b("m", ["mm", 2], 0, "minute"), w("m", S, Re), w("mm", S, x), O(["m", "mm"], P);
var ya = Xe("Minutes", !1);
b("s", ["ss", 2], 0, "second"), w("s", S, Re), w("ss", S, x), O(["s", "ss"], F);
var ba = Xe("Seconds", !1);
b("S", 0, 0, function() {
	return ~~(this.millisecond() / 100);
}), b(0, ["SS", 2], 0, function() {
	return ~~(this.millisecond() / 10);
}), b(0, ["SSS", 3], 0, "millisecond"), b(0, ["SSSS", 4], 0, function() {
	return this.millisecond() * 10;
}), b(0, ["SSSSS", 5], 0, function() {
	return this.millisecond() * 100;
}), b(0, ["SSSSSS", 6], 0, function() {
	return this.millisecond() * 1e3;
}), b(0, ["SSSSSSS", 7], 0, function() {
	return this.millisecond() * 1e4;
}), b(0, ["SSSSSSSS", 8], 0, function() {
	return this.millisecond() * 1e5;
}), b(0, ["SSSSSSSSS", 9], 0, function() {
	return this.millisecond() * 1e6;
}), w("S", ke, Ce), w("SS", ke, x), w("SSS", ke, we);
var K, xa;
for (K = "SSSS"; K.length <= 9; K += "S") w(K, C);
function Sa(e, t) {
	t[I] = D(("0." + e) * 1e3);
}
for (K = "S"; K.length <= 9; K += "S") O(K, Sa);
xa = Xe("Milliseconds", !1), b("z", 0, 0, "zoneAbbr"), b("zz", 0, 0, "zoneName");
function Ca() {
	return this._isUTC ? "UTC" : "";
}
function wa() {
	return this._isUTC ? "Coordinated Universal Time" : "";
}
var q = se.prototype;
q.add = Qr, q.calendar = oi, q.clone = si, q.diff = mi, q.endOf = Fi, q.format = yi, q.from = bi, q.fromNow = xi, q.to = Si, q.toNow = Ci, q.get = $e, q.invalidAt = Wi, q.isAfter = ci, q.isBefore = li, q.isBetween = ui, q.isSame = di, q.isSameOrAfter = fi, q.isSameOrBefore = pi, q.isValid = Hi, q.lang = Ti, q.locale = wi, q.localeData = Ei, q.max = _r, q.min = gr, q.parsingFlags = Ui, q.set = et, q.startOf = Pi, q.subtract = $r, q.toArray = zi, q.toObject = Bi, q.toDate = Ri, q.toISOString = _i, q.inspect = vi, typeof Symbol < "u" && Symbol.for != null && (q[/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")] = function() {
	return "Moment<" + this.format() + ">";
}), q.toJSON = Vi, q.toString = gi, q.unix = Li, q.valueOf = Ii, q.creationData = Gi, q.eraName = Yi, q.eraNarrow = Xi, q.eraAbbr = Zi, q.eraYear = Qi, q.year = Je, q.isLeapYear = Ye, q.weekYear = ca, q.isoWeekYear = la, q.quarter = q.quarters = ga, q.month = ht, q.daysInMonth = gt, q.week = q.weeks = vn, q.isoWeek = q.isoWeeks = yn, q.weeksInYear = fa, q.weeksInWeekYear = pa, q.isoWeeksInYear = ua, q.isoWeeksInISOWeekYear = da, q.date = _a, q.day = q.days = It, q.weekday = Lt, q.isoWeekday = Rt, q.dayOfYear = va, q.hour = q.hours = En, q.minute = q.minutes = ya, q.second = q.seconds = ba, q.millisecond = q.milliseconds = xa, q.utcOffset = Fr, q.utc = Lr, q.local = Rr, q.parseZone = zr, q.hasAlignedHourOffset = Br, q.isDST = Vr, q.isLocal = Ur, q.isUtcOffset = Wr, q.isUtc = Gr, q.isUTC = Gr, q.zoneAbbr = Ca, q.zoneName = wa, q.dates = g("dates accessor is deprecated. Use date instead.", _a), q.months = g("months accessor is deprecated. Use month instead", ht), q.years = g("years accessor is deprecated. Use year instead", Je), q.zone = g("moment().zone is deprecated, use moment().utcOffset instead. http://momentjs.com/guides/#/warnings/zone/", Ir), q.isDSTShifted = g("isDSTShifted is deprecated. See http://momentjs.com/guides/#/warnings/dst-shifted/ for more information", Hr);
function Ta(e) {
	return U(e * 1e3);
}
function Ea() {
	return U.apply(null, arguments).parseZone();
}
function Da(e) {
	return e;
}
var J = Gt.prototype;
J.calendar = Jt, J.longDateFormat = Xt, J.invalidDate = Qt, J.ordinal = tn, J.preparse = Da, J.postformat = Da, J.relativeTime = an, J.pastFuture = sn, J.set = Ut, J.eras = Ki, J.erasParse = qi, J.erasConvertYear = Ji, J.erasAbbrRegex = ea, J.erasNameRegex = $i, J.erasNarrowRegex = ta, J.months = ut, J.monthsShort = dt, J.monthsParse = pt, J.monthsRegex = vt, J.monthsShortRegex = _t, J.week = mn, J.firstDayOfYear = _n, J.firstDayOfWeek = gn, J.weekdays = jt, J.weekdaysMin = Nt, J.weekdaysShort = Mt, J.weekdaysParse = Ft, J.weekdaysRegex = zt, J.weekdaysShortRegex = Bt, J.weekdaysMinRegex = Vt, J.isPM = wn, J.meridiem = Dn;
function Oa(e, t, n, r) {
	var i = H(), a = p().set(r, t);
	return i[n](a, e);
}
function ka(e, t, n) {
	if (l(e) && (t = e, e = void 0), e ||= "", t != null) return Oa(e, t, n, "month");
	var r, i = [];
	for (r = 0; r < 12; r++) i[r] = Oa(e, r, n, "month");
	return i;
}
function Aa(e, t, n, r) {
	typeof e == "boolean" ? (l(t) && (n = t, t = void 0), t ||= "") : (t = e, n = t, e = !1, l(t) && (n = t, t = void 0), t ||= "");
	var i = H(), a = e ? i._week.dow : 0, o, s = [];
	if (n != null) return Oa(t, (n + a) % 7, r, "day");
	for (o = 0; o < 7; o++) s[o] = Oa(t, (o + a) % 7, r, "day");
	return s;
}
function ja(e, t) {
	return ka(e, t, "months");
}
function Ma(e, t) {
	return ka(e, t, "monthsShort");
}
function Na(e, t, n) {
	return Aa(e, t, n, "weekdays");
}
function Pa(e, t, n) {
	return Aa(e, t, n, "weekdaysShort");
}
function Fa(e, t, n) {
	return Aa(e, t, n, "weekdaysMin");
}
V("en", {
	eras: [{
		since: "0001-01-01",
		until: 1 / 0,
		offset: 1,
		name: "Anno Domini",
		narrow: "AD",
		abbr: "AD"
	}, {
		since: "0000-12-31",
		until: -1 / 0,
		offset: 1,
		name: "Before Christ",
		narrow: "BC",
		abbr: "BC"
	}],
	dayOfMonthOrdinalParse: /\d{1,2}(th|st|nd|rd)/,
	ordinal: function(e) {
		var t = e % 10;
		return e + (D(e % 100 / 10) === 1 ? "th" : t === 1 ? "st" : t === 2 ? "nd" : t === 3 ? "rd" : "th");
	}
}), n.lang = g("moment.lang is deprecated. Use moment.locale instead.", V), n.langData = g("moment.langData is deprecated. Use moment.localeData instead.", H);
var Y = Math.abs;
function Ia() {
	var e = this._data;
	return this._milliseconds = Y(this._milliseconds), this._days = Y(this._days), this._months = Y(this._months), e.milliseconds = Y(e.milliseconds), e.seconds = Y(e.seconds), e.minutes = Y(e.minutes), e.hours = Y(e.hours), e.months = Y(e.months), e.years = Y(e.years), this;
}
function La(e, t, n, r) {
	var i = W(t, n);
	return e._milliseconds += r * i._milliseconds, e._days += r * i._days, e._months += r * i._months, e._bubble();
}
function Ra(e, t) {
	return La(this, e, t, 1);
}
function za(e, t) {
	return La(this, e, t, -1);
}
function Ba(e) {
	return e < 0 ? Math.floor(e) : Math.ceil(e);
}
function Va() {
	var e = this._milliseconds, t = this._days, n = this._months, r = this._data, i, a, o, s, c;
	return e >= 0 && t >= 0 && n >= 0 || e <= 0 && t <= 0 && n <= 0 || (e += Ba(Ua(n) + t) * 864e5, t = 0, n = 0), r.milliseconds = e % 1e3, i = E(e / 1e3), r.seconds = i % 60, a = E(i / 60), r.minutes = a % 60, o = E(a / 60), r.hours = o % 24, t += E(o / 24), c = E(Ha(t)), n += c, t -= Ba(Ua(c)), s = E(n / 12), n %= 12, r.days = t, r.months = n, r.years = s, this;
}
function Ha(e) {
	return e * 4800 / 146097;
}
function Ua(e) {
	return e * 146097 / 4800;
}
function Wa(e) {
	if (!this.isValid()) return NaN;
	var t, n, r = this._milliseconds;
	if (e = v(e), e === "month" || e === "quarter" || e === "year") switch (t = this._days + r / 864e5, n = this._months + Ha(t), e) {
		case "month": return n;
		case "quarter": return n / 3;
		case "year": return n / 12;
	}
	else switch (t = this._days + Math.round(Ua(this._months)), e) {
		case "week": return t / 7 + r / 6048e5;
		case "day": return t + r / 864e5;
		case "hour": return t * 24 + r / 36e5;
		case "minute": return t * 1440 + r / 6e4;
		case "second": return t * 86400 + r / 1e3;
		case "millisecond": return Math.floor(t * 864e5) + r;
		default: throw Error("Unknown unit " + e);
	}
}
function X(e) {
	return function() {
		return this.as(e);
	};
}
var Ga = X("ms"), Ka = X("s"), qa = X("m"), Ja = X("h"), Ya = X("d"), Xa = X("w"), Za = X("M"), Qa = X("Q"), $a = X("y"), eo = Ga;
function to() {
	return W(this);
}
function no(e) {
	return e = v(e), this.isValid() ? this[e + "s"]() : NaN;
}
function Z(e) {
	return function() {
		return this.isValid() ? this._data[e] : NaN;
	};
}
var ro = Z("milliseconds"), io = Z("seconds"), ao = Z("minutes"), oo = Z("hours"), so = Z("days"), co = Z("months"), lo = Z("years");
function uo() {
	return E(this.days() / 7);
}
var Q = Math.round, fo = {
	ss: 44,
	s: 45,
	m: 45,
	h: 22,
	d: 26,
	w: null,
	M: 11
};
function po(e, t, n, r, i) {
	return rn.call(i, t || 1, !!n, e, r);
}
function mo(e, t, n, r) {
	var i = W(e).abs(), a = Q(i.as("s")), o = Q(i.as("m")), s = Q(i.as("h")), c = Q(i.as("d")), l = Q(i.as("M")), u = Q(i.as("w")), d = Q(i.as("y")), f = a <= n.ss && ["s", a] || a < n.s && ["ss", a] || o <= 1 && ["m"] || o < n.m && ["mm", o] || s <= 1 && ["h"] || s < n.h && ["hh", s] || c <= 1 && ["d"] || c < n.d && ["dd", c];
	return n.w != null && (f = f || u <= 1 && ["w"] || u < n.w && ["ww", u]), f = f || l <= 1 && ["M"] || l < n.M && ["MM", l] || d <= 1 && ["y"] || ["yy", d], f[2] = t, f[3] = +e > 0, f[4] = r, po.apply(null, f);
}
function ho(e) {
	return e === void 0 ? Q : typeof e == "function" && (Q = e, !0);
}
function go(e, t) {
	return fo[e] === void 0 ? !1 : t === void 0 ? fo[e] : (fo[e] = t, e === "s" && (fo.ss = t - 1), !0);
}
function _o(e, t) {
	if (!this.isValid()) return this.localeData().invalidDate();
	var n = !1, r = fo, i, a;
	return typeof e == "object" && (t = e, e = !1), typeof e == "boolean" && (n = e), typeof t == "object" && (r = f(f({}, fo), t || {}), t.s != null && t.ss == null && (r.ss = t.s - 1)), i = this.localeData(), a = mo(this, !n, r, i), n && (a = on.call(i, +this, a)), i.postformat(a);
}
var vo = Math.abs;
function yo(e) {
	return (e > 0) - (e < 0) || +e;
}
function bo() {
	if (!this.isValid()) return this.localeData().invalidDate();
	var e = vo(this._milliseconds) / 1e3, t = vo(this._days), n = vo(this._months), r, i, a, o, s = this.asSeconds(), c, l, u, d;
	return s ? (r = E(e / 60), i = E(r / 60), e %= 60, r %= 60, a = E(n / 12), n %= 12, o = e ? e.toFixed(3).replace(/\.?0+$/, "") : "", c = s < 0 ? "-" : "", l = yo(this._months) === yo(s) ? "" : "-", u = yo(this._days) === yo(s) ? "" : "-", d = yo(this._milliseconds) === yo(s) ? "" : "-", c + "P" + (a ? l + a + "Y" : "") + (n ? l + n + "M" : "") + (t ? u + t + "D" : "") + (i || r || e ? "T" : "") + (i ? d + i + "H" : "") + (r ? d + r + "M" : "") + (e ? d + o + "S" : "")) : "P0D";
}
var $ = Er.prototype;
$.isValid = wr, $.abs = Ia, $.add = Ra, $.subtract = za, $.as = Wa, $.asMilliseconds = Ga, $.asSeconds = Ka, $.asMinutes = qa, $.asHours = Ja, $.asDays = Ya, $.asWeeks = Xa, $.asMonths = Za, $.asQuarters = Qa, $.asYears = $a, $.valueOf = eo, $._bubble = Va, $.clone = to, $.get = no, $.milliseconds = ro, $.seconds = io, $.minutes = ao, $.hours = oo, $.days = so, $.weeks = uo, $.months = co, $.years = lo, $.humanize = _o, $.toISOString = bo, $.toString = bo, $.toJSON = bo, $.locale = wi, $.localeData = Ei, $.toIsoString = g("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)", bo), $.lang = Ti, b("X", 0, 0, "unix"), b("x", 0, 0, "valueOf"), w("x", Me), w("X", Fe), O("X", function(e, t, n) {
	n._d = /* @__PURE__ */ new Date(parseFloat(e) * 1e3);
}), O("x", function(e, t, n) {
	n._d = new Date(D(e));
}), n.version = "2.31.0", r(U), n.fn = q, n.min = yr, n.max = br, n.now = xr, n.utc = p, n.unix = Ta, n.months = ja, n.isDate = u, n.locale = V, n.invalid = re, n.duration = W, n.isMoment = h, n.weekdays = Na, n.parseZone = Ea, n.localeData = H, n.isDuration = Dr, n.monthsShort = Ma, n.weekdaysMin = Fa, n.defineLocale = In, n.updateLocale = Ln, n.locales = Rn, n.weekdaysShort = Pa, n.normalizeUnits = v, n.relativeTimeRounding = ho, n.relativeTimeThreshold = go, n.calendarFormat = ai, n.prototype = q, n.HTML5_FMT = {
	DATETIME_LOCAL: "YYYY-MM-DDTHH:mm",
	DATETIME_LOCAL_SECONDS: "YYYY-MM-DDTHH:mm:ss",
	DATETIME_LOCAL_MS: "YYYY-MM-DDTHH:mm:ss.SSS",
	DATE: "YYYY-MM-DD",
	TIME: "HH:mm",
	TIME_SECONDS: "HH:mm:ss",
	TIME_MS: "HH:mm:ss.SSS",
	WEEK: "GGGG-[W]WW",
	MONTH: "YYYY-MM"
};
var xo = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
	__proto__: null,
	default: n
}, Symbol.toStringTag, { value: "Module" }));
function So(e, t, n = "datetime") {
	if (t === "localized") {
		let t = navigator.languages, r = n === "time" ? void 0 : "medium", i = n === "date" ? void 0 : "medium";
		try {
			return new Intl.DateTimeFormat(t, {
				dateStyle: r,
				timeStyle: i
			}).format(e.toDate());
		} catch (t) {
			if (t instanceof RangeError) return new Intl.DateTimeFormat(void 0, {
				dateStyle: r,
				timeStyle: i
			}).format(e.toDate());
			throw t;
		}
	}
	return t === "distance" ? e.fromNow() : t === "calendar" ? e.calendar() : t === "iso8601" ? n === "date" ? e.format("YYYY-MM-DD") : n === "time" ? e.format("HH:mm:ss.SSS[Z]") : e.toISOString() : e.format(t);
}
//#endregion
export { So as n, n as r, xo as t };

//# sourceMappingURL=formatMoment-CSglijqE-wHP8MmD-.js.map