import { $a as e, Ma as t } from "./index-B1FrxEMd-BsPMjC5n.js";
import { t as n } from "./numbro-CDdPhOTG-vF1UvoJy.js";
import { t as r } from "./sprintfjs-CjmCzARP-HuCjLGam.js";
//#region ../react/build/formatNumber-Q1A8AyDZ.js
function i(e) {
	if (e === 0 || Math.abs(e) >= 1e-4) return 4;
	let t = e.toExponential().split("e");
	return Math.abs(Number.parseInt(t[1], 10));
}
function a(e, t = {}) {
	let n = navigator.languages;
	try {
		return new Intl.NumberFormat(n, t).format(e);
	} catch (n) {
		if (n instanceof RangeError) return new Intl.NumberFormat(void 0, t).format(e);
		throw n;
	}
}
function o(o, s, c) {
	return Number.isNaN(o) || !Number.isFinite(o) ? "" : t(s) || s === "" ? e(c) ? (c === 0 && (o = Math.round(o)), n(o).format({
		thousandSeparated: !1,
		mantissa: c,
		trimMantissa: !1
	})) : n(o).format({
		thousandSeparated: !1,
		mantissa: i(o),
		trimMantissa: !0
	}) : s === "plain" ? n(o).format({
		thousandSeparated: !1,
		mantissa: 20,
		trimMantissa: !0
	}) : s === "localized" ? a(o, {
		minimumFractionDigits: c ?? void 0,
		maximumFractionDigits: c ?? void 0
	}) : s === "percent" ? a(o, {
		style: "percent",
		minimumFractionDigits: e(c) ? Math.max(c - 2, 0) : 0,
		maximumFractionDigits: e(c) ? Math.max(c - 2, 0) : 2
	}) : s === "dollar" ? a(o, {
		style: "currency",
		currency: "USD",
		currencyDisplay: "narrowSymbol",
		minimumFractionDigits: c ?? 2,
		maximumFractionDigits: c ?? 2
	}) : s === "euro" ? a(o, {
		style: "currency",
		currency: "EUR",
		currencyDisplay: "narrowSymbol",
		minimumFractionDigits: c ?? 2,
		maximumFractionDigits: c ?? 2
	}) : s === "yen" ? a(o, {
		style: "currency",
		currency: "JPY",
		currencyDisplay: "narrowSymbol",
		minimumFractionDigits: c ?? 0,
		maximumFractionDigits: c ?? 0
	}) : [
		"compact",
		"scientific",
		"engineering"
	].includes(s) ? a(o, { notation: s }) : s === "accounting" ? n(o).format({
		thousandSeparated: !0,
		negative: "parenthesis",
		mantissa: c ?? 2,
		trimMantissa: !1
	}) : s === "bytes" ? a(o, {
		notation: "compact",
		style: "unit",
		unit: "byte",
		unitDisplay: "narrow",
		maximumFractionDigits: 1
	}).replace("BB", "GB") : r(s, o);
}
function s(e) {
	if (e.trim() === "") return !1;
	let t = Number(e);
	return !Number.isNaN(t) && Number.isFinite(t);
}
//#endregion
export { s as n, o as t };

//# sourceMappingURL=formatNumber-Q1A8AyDZ-C1p6HSP6.js.map