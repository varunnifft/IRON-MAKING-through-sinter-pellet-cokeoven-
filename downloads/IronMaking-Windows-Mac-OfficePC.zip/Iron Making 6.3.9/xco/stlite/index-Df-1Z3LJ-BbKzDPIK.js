//#region ../react/build/index-Df-1Z3LJ.js
var e = {
	html: "http://www.w3.org/1999/xhtml",
	mathml: "http://www.w3.org/1998/Math/MathML",
	svg: "http://www.w3.org/2000/svg",
	xlink: "http://www.w3.org/1999/xlink",
	xml: "http://www.w3.org/XML/1998/namespace",
	xmlns: "http://www.w3.org/2000/xmlns/"
};
//#endregion
export { e as t };

//# sourceMappingURL=index-Df-1Z3LJ-BbKzDPIK.js.map