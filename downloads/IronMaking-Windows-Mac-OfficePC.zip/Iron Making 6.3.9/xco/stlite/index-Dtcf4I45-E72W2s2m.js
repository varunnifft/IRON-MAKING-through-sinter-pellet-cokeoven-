import { Ci as e, gr as t, ls as n } from "./index-B1FrxEMd-BsPMjC5n.js";
import { n as r, t as i } from "./index-fsFmsChH-Dni1dpUL.js";
import { t as a } from "./index-Df-1Z3LJ-BbKzDPIK.js";
//#region ../react/build/index-Dtcf4I45.js
function o(e, t) {
	return s(e, {}) || {
		type: "root",
		children: []
	};
}
function s(e, t) {
	let n = c(e, t);
	return n && t.afterTransform && t.afterTransform(e, n), n;
}
function c(e, t) {
	switch (e.nodeType) {
		case 1: return p(e, t);
		case 3: return d(e);
		case 8: return f(e);
		case 9: return l(e, t);
		case 10: return u();
		case 11: return l(e, t);
		default: return;
	}
}
function l(e, t) {
	return {
		type: "root",
		children: m(e, t)
	};
}
function u() {
	return { type: "doctype" };
}
function d(e) {
	return {
		type: "text",
		value: e.nodeValue || ""
	};
}
function f(e) {
	return {
		type: "comment",
		value: e.nodeValue || ""
	};
}
function p(e, t) {
	let n = e.namespaceURI, o = n === a.svg ? r : i, s = n === a.html ? e.tagName.toLowerCase() : e.tagName, c = n === a.html && s === "template" ? e.content : e, l = e.getAttributeNames(), u = {}, d = -1;
	for (; ++d < l.length;) u[l[d]] = e.getAttribute(l[d]) || "";
	return o(s, u, m(c, t));
}
function m(e, t) {
	let n = e.childNodes, r = [], i = -1;
	for (; ++i < n.length;) {
		let e = s(n[i], t);
		e !== void 0 && r.push(e);
	}
	return r;
}
new DOMParser();
function h(e, t) {
	return o(g(e));
}
function g(e) {
	let t = document.createElement("template");
	return t.innerHTML = e, t.content;
}
var _ = function(t, n, r) {
	let i = e(r);
	if (!t || !t.type || !t.children) throw Error("Expected parent node");
	if (typeof n == "number") {
		if (n < 0 || n === Infinity) throw Error("Expected positive finite number as index");
	} else if (n = t.children.indexOf(n), n < 0) throw Error("Expected child node or index");
	for (; ++n < t.children.length;) if (i(t.children[n], n, t)) return t.children[n];
}, v = function(e) {
	if (e == null) return S;
	if (typeof e == "string") return b(e);
	if (typeof e == "object") return y(e);
	if (typeof e == "function") return x(e);
	throw Error("Expected function, string, or array as `test`");
};
function y(e) {
	let t = [], n = -1;
	for (; ++n < e.length;) t[n] = v(e[n]);
	return x(r);
	function r(...e) {
		let n = -1;
		for (; ++n < t.length;) if (t[n].apply(this, e)) return !0;
		return !1;
	}
}
function b(e) {
	return x(t);
	function t(t) {
		return t.tagName === e;
	}
}
function x(e) {
	return t;
	function t(t, n, r) {
		return !!(C(t) && e.call(this, t, typeof n == "number" ? n : void 0, r || void 0));
	}
}
function S(e) {
	return !!(e && typeof e == "object" && "type" in e && e.type === "element" && "tagName" in e && typeof e.tagName == "string");
}
function C(e) {
	return typeof e == "object" && !!e && "type" in e && "tagName" in e;
}
var ee = /\n/g, te = /[\t ]+/g, w = v("br"), ne = v(he), re = v("p"), ie = v("tr"), ae = v([
	"datalist",
	"head",
	"noembed",
	"noframes",
	"noscript",
	"rp",
	"script",
	"style",
	"template",
	"title",
	me,
	ge
]), oe = v(/* @__PURE__ */ "address.article.aside.blockquote.body.caption.center.dd.dialog.dir.dl.dt.div.figure.figcaption.footer.form,.h1.h2.h3.h4.h5.h6.header.hgroup.hr.html.legend.li.listing.main.menu.nav.ol.p.plaintext.pre.section.ul.xmp".split("."));
function se(e, t) {
	let n = t || {}, r = "children" in e ? e.children : [], i = oe(e), a = pe(e, { whitespace: n.whitespace || "normal" }), o = [];
	(e.type === "text" || e.type === "comment") && o.push(...ue(e, {
		breakBefore: !0,
		breakAfter: !0
	}));
	let s = -1;
	for (; ++s < r.length;) o.push(...ce(r[s], e, {
		whitespace: a,
		breakBefore: s ? void 0 : i,
		breakAfter: s < r.length - 1 ? w(r[s + 1]) : i
	}));
	let c = [], l;
	for (s = -1; ++s < o.length;) {
		let e = o[s];
		typeof e == "number" ? l !== void 0 && e > l && (l = e) : e && (l !== void 0 && l > -1 && c.push("\n".repeat(l) || " "), l = -1, c.push(e));
	}
	return c.join("");
}
function ce(e, t, n) {
	return e.type === "element" ? le(e, t, n) : e.type === "text" ? n.whitespace === "normal" ? ue(e, n) : de(e) : [];
}
function le(e, t, n) {
	let r = pe(e, n), i = e.children || [], a = -1, o = [];
	if (ae(e)) return o;
	let s, c;
	for (w(e) || ie(e) && _(t, e, ie) ? c = "\n" : re(e) ? (s = 2, c = 2) : oe(e) && (s = 1, c = 1); ++a < i.length;) o = o.concat(ce(i[a], e, {
		whitespace: r,
		breakBefore: a ? void 0 : s,
		breakAfter: a < i.length - 1 ? w(i[a + 1]) : c
	}));
	return ne(e) && _(t, e, ne) && o.push("	"), s && o.unshift(s), c && o.push(c), o;
}
function ue(e, t) {
	let n = String(e.value), r = [], i = [], a = 0;
	for (; a <= n.length;) {
		ee.lastIndex = a;
		let e = ee.exec(n), i = e && "index" in e ? e.index : n.length;
		r.push(fe(n.slice(a, i).replace(/[\u061C\u200E\u200F\u202A-\u202E\u2066-\u2069]/g, ""), a !== 0 || t.breakBefore, i !== n.length || t.breakAfter)), a = i + 1;
	}
	let o = -1, s;
	for (; ++o < r.length;) r[o].charCodeAt(r[o].length - 1) === 8203 || o < r.length - 1 && r[o + 1].charCodeAt(0) === 8203 ? (i.push(r[o]), s = void 0) : r[o] ? (typeof s == "number" && i.push(s), i.push(r[o]), s = 0) : (o === 0 || o === r.length - 1) && i.push(0);
	return i;
}
function de(e) {
	return [String(e.value)];
}
function fe(e, t, n) {
	let r = [], i = 0, a;
	for (; i < e.length;) {
		te.lastIndex = i;
		let n = te.exec(e);
		a = n ? n.index : e.length, !i && !a && n && !t && r.push(""), i !== a && r.push(e.slice(i, a)), i = n ? a + n[0].length : a;
	}
	return i !== a && !n && r.push(""), r.join(" ");
}
function pe(e, t) {
	if (e.type === "element") {
		let n = e.properties || {};
		switch (e.tagName) {
			case "listing":
			case "plaintext":
			case "xmp": return "pre";
			case "nobr": return "nowrap";
			case "pre": return n.wrap ? "pre-wrap" : "pre";
			case "td":
			case "th": return n.noWrap ? "nowrap" : t.whitespace;
			case "textarea": return "pre-wrap";
		}
	}
	return t.whitespace;
}
function me(e) {
	return !!(e.properties || {}).hidden;
}
function he(e) {
	return e.tagName === "td" || e.tagName === "th";
}
function ge(e) {
	return e.tagName === "dialog" && !(e.properties || {}).open;
}
var _e = class e {
	constructor(e, t, n) {
		this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = n;
	}
	static range(t, n) {
		return n ? !t || !t.loc || !n.loc || t.loc.lexer !== n.loc.lexer ? null : new e(t.loc.lexer, t.loc.start, n.loc.end) : t && t.loc;
	}
}, ve = class e {
	constructor(e, t) {
		this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
	}
	range(t, n) {
		return new e(n, _e.range(this, t));
	}
}, T = class e {
	constructor(t, n) {
		this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
		var r = "KaTeX parse error: " + t, i, a, o = n && n.loc;
		if (o && o.start <= o.end) {
			var s = o.lexer.input;
			i = o.start, a = o.end, i === s.length ? r += " at end of input: " : r += " at position " + (i + 1) + ": ";
			var c = s.slice(i, a).replace(/[^]/g, "$&̲"), l = i > 15 ? "…" + s.slice(i - 15, i) : s.slice(0, i), u = a + 15 < s.length ? s.slice(a, a + 15) + "…" : s.slice(a);
			r += l + c + u;
		}
		var d = Error(r);
		return d.name = "ParseError", d.__proto__ = e.prototype, d.position = i, i != null && a != null && (d.length = a - i), d.rawMessage = t, d;
	}
};
T.prototype.__proto__ = Error.prototype;
var ye = function(e, t) {
	return e === void 0 ? t : e;
}, be = /([A-Z])/g, xe = function(e) {
	return e.replace(be, "-$1").toLowerCase();
}, Se = {
	"&": "&amp;",
	">": "&gt;",
	"<": "&lt;",
	"\"": "&quot;",
	"'": "&#x27;"
}, Ce = /[&><"']/g;
function we(e) {
	return String(e).replace(Ce, (e) => Se[e]);
}
var Te = function e(t) {
	return t.type === "ordgroup" || t.type === "color" ? t.body.length === 1 ? e(t.body[0]) : t : t.type === "font" ? e(t.body) : t;
}, Ee = function(e) {
	var t = Te(e);
	return t.type === "mathord" || t.type === "textord" || t.type === "atom";
}, De = function(e) {
	if (!e) throw Error("Expected non-null, but got " + String(e));
	return e;
}, E = {
	deflt: ye,
	escape: we,
	hyphenate: xe,
	getBaseElem: Te,
	isCharacterBox: Ee,
	protocolFromUrl: function(e) {
		var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
		return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
	}
}, Oe = {
	displayMode: {
		type: "boolean",
		description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",
		cli: "-d, --display-mode"
	},
	output: {
		type: { enum: [
			"htmlAndMathml",
			"html",
			"mathml"
		] },
		description: "Determines the markup language of the output.",
		cli: "-F, --format <type>"
	},
	leqno: {
		type: "boolean",
		description: "Render display math in leqno style (left-justified tags)."
	},
	fleqn: {
		type: "boolean",
		description: "Render display math flush left."
	},
	throwOnError: {
		type: "boolean",
		default: !0,
		cli: "-t, --no-throw-on-error",
		cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."
	},
	errorColor: {
		type: "string",
		default: "#cc0000",
		cli: "-c, --error-color <color>",
		cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",
		cliProcessor: (e) => "#" + e
	},
	macros: {
		type: "object",
		cli: "-m, --macro <def>",
		cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",
		cliDefault: [],
		cliProcessor: (e, t) => (t.push(e), t)
	},
	minRuleThickness: {
		type: "number",
		description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",
		processor: (e) => Math.max(0, e),
		cli: "--min-rule-thickness <size>",
		cliProcessor: parseFloat
	},
	colorIsTextColor: {
		type: "boolean",
		description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",
		cli: "-b, --color-is-text-color"
	},
	strict: {
		type: [
			{ enum: [
				"warn",
				"ignore",
				"error"
			] },
			"boolean",
			"function"
		],
		description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",
		cli: "-S, --strict",
		cliDefault: !1
	},
	trust: {
		type: ["boolean", "function"],
		description: "Trust the input, enabling all HTML features such as \\url.",
		cli: "-T, --trust"
	},
	maxSize: {
		type: "number",
		default: 1 / 0,
		description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",
		processor: (e) => Math.max(0, e),
		cli: "-s, --max-size <n>",
		cliProcessor: parseInt
	},
	maxExpand: {
		type: "number",
		default: 1e3,
		description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",
		processor: (e) => Math.max(0, e),
		cli: "-e, --max-expand <n>",
		cliProcessor: (e) => e === "Infinity" ? 1 / 0 : parseInt(e)
	},
	globalGroup: {
		type: "boolean",
		cli: !1
	}
};
function ke(e) {
	if (e.default) return e.default;
	var t = e.type, n = Array.isArray(t) ? t[0] : t;
	if (typeof n != "string") return n.enum[0];
	switch (n) {
		case "boolean": return !1;
		case "string": return "";
		case "number": return 0;
		case "object": return {};
	}
}
var Ae = class {
	constructor(e) {
		for (var t in this.displayMode = void 0, this.output = void 0, this.leqno = void 0, this.fleqn = void 0, this.throwOnError = void 0, this.errorColor = void 0, this.macros = void 0, this.minRuleThickness = void 0, this.colorIsTextColor = void 0, this.strict = void 0, this.trust = void 0, this.maxSize = void 0, this.maxExpand = void 0, this.globalGroup = void 0, e ||= {}, Oe) if (Oe.hasOwnProperty(t)) {
			var n = Oe[t];
			this[t] = e[t] === void 0 ? ke(n) : n.processor ? n.processor(e[t]) : e[t];
		}
	}
	reportNonstrict(e, t, n) {
		var r = this.strict;
		if (typeof r == "function" && (r = r(e, t, n)), !(!r || r === "ignore")) {
			if (r === !0 || r === "error") throw new T("LaTeX-incompatible input and strict mode is set to 'error': " + (t + " [" + e + "]"), n);
			r === "warn" ? typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (t + " [" + e + "]")) : typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + r + "': " + t + " [" + e + "]"));
		}
	}
	useStrictBehavior(e, t, n) {
		var r = this.strict;
		if (typeof r == "function") try {
			r = r(e, t, n);
		} catch {
			r = "error";
		}
		return !r || r === "ignore" ? !1 : r === !0 || r === "error" ? !0 : r === "warn" ? (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (t + " [" + e + "]")), !1) : (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + r + "': " + t + " [" + e + "]")), !1);
	}
	isTrusted(e) {
		if (e.url && !e.protocol) {
			var t = E.protocolFromUrl(e.url);
			if (t == null) return !1;
			e.protocol = t;
		}
		return !!(typeof this.trust == "function" ? this.trust(e) : this.trust);
	}
}, je = class {
	constructor(e, t, n) {
		this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = n;
	}
	sup() {
		return Be[Ve[this.id]];
	}
	sub() {
		return Be[He[this.id]];
	}
	fracNum() {
		return Be[Ue[this.id]];
	}
	fracDen() {
		return Be[We[this.id]];
	}
	cramp() {
		return Be[Ge[this.id]];
	}
	text() {
		return Be[Ke[this.id]];
	}
	isTight() {
		return this.size >= 2;
	}
}, Me = 0, Ne = 1, Pe = 2, Fe = 3, Ie = 4, Le = 5, Re = 6, ze = 7, Be = [
	new je(Me, 0, !1),
	new je(Ne, 0, !0),
	new je(Pe, 1, !1),
	new je(Fe, 1, !0),
	new je(Ie, 2, !1),
	new je(Le, 2, !0),
	new je(Re, 3, !1),
	new je(ze, 3, !0)
], Ve = [
	Ie,
	Le,
	Ie,
	Le,
	Re,
	ze,
	Re,
	ze
], He = [
	Le,
	Le,
	Le,
	Le,
	ze,
	ze,
	ze,
	ze
], Ue = [
	Pe,
	Fe,
	Ie,
	Le,
	Re,
	ze,
	Re,
	ze
], We = [
	Fe,
	Fe,
	Le,
	Le,
	ze,
	ze,
	ze,
	ze
], Ge = [
	Ne,
	Ne,
	Fe,
	Fe,
	Le,
	Le,
	ze,
	ze
], Ke = [
	Me,
	Ne,
	Pe,
	Fe,
	Pe,
	Fe,
	Pe,
	Fe
], D = {
	DISPLAY: Be[Me],
	TEXT: Be[Pe],
	SCRIPT: Be[Ie],
	SCRIPTSCRIPT: Be[Re]
}, qe = [
	{
		name: "latin",
		blocks: [[256, 591], [768, 879]]
	},
	{
		name: "cyrillic",
		blocks: [[1024, 1279]]
	},
	{
		name: "armenian",
		blocks: [[1328, 1423]]
	},
	{
		name: "brahmic",
		blocks: [[2304, 4255]]
	},
	{
		name: "georgian",
		blocks: [[4256, 4351]]
	},
	{
		name: "cjk",
		blocks: [
			[12288, 12543],
			[19968, 40879],
			[65280, 65376]
		]
	},
	{
		name: "hangul",
		blocks: [[44032, 55215]]
	}
];
function Je(e) {
	for (var t = 0; t < qe.length; t++) for (var n = qe[t], r = 0; r < n.blocks.length; r++) {
		var i = n.blocks[r];
		if (e >= i[0] && e <= i[1]) return n.name;
	}
	return null;
}
var Ye = [];
qe.forEach((e) => e.blocks.forEach((e) => Ye.push(...e)));
function Xe(e) {
	for (var t = 0; t < Ye.length; t += 2) if (e >= Ye[t] && e <= Ye[t + 1]) return !0;
	return !1;
}
var Ze = 80, Qe = function(e, t) {
	return "M95," + (622 + e + t) + "\nc-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14\nc0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54\nc44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10\ns173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429\nc69,-144,104.5,-217.7,106.5,-221\nl" + e / 2.075 + " -" + e + "\nc5.3,-9.3,12,-14,20,-14\nH400000v" + (40 + e) + "H845.2724\ns-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7\nc-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z\nM" + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, $e = function(e, t) {
	return "M263," + (601 + e + t) + "c0.7,0,18,39.7,52,119\nc34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120\nc340,-704.7,510.7,-1060.3,512,-1067\nl" + e / 2.084 + " -" + e + "\nc4.7,-7.3,11,-11,19,-11\nH40000v" + (40 + e) + "H1012.3\ns-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232\nc-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1\ns-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26\nc-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z\nM" + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, et = function(e, t) {
	return "M983 " + (10 + e + t) + "\nl" + e / 3.13 + " -" + e + "\nc4,-6.7,10,-10,18,-10 H400000v" + (40 + e) + "\nH1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7\ns-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744\nc-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30\nc26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722\nc56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5\nc53.7,-170.3,84.5,-266.8,92.5,-289.5z\nM" + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, tt = function(e, t) {
	return "M424," + (2398 + e + t) + "\nc-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514\nc0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20\ns-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121\ns209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081\nl" + e / 4.223 + " -" + e + "c4,-6.7,10,-10,18,-10 H400000\nv" + (40 + e) + "H1014.6\ns-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185\nc-2,6,-10,9,-24,9\nc-8,0,-12,-0.7,-12,-2z M" + (1001 + e) + " " + t + "\nh400000v" + (40 + e) + "h-400000z";
}, nt = function(e, t) {
	return "M473," + (2713 + e + t) + "\nc339.3,-1799.3,509.3,-2700,510,-2702 l" + e / 5.298 + " -" + e + "\nc3.3,-7.3,9.3,-11,18,-11 H400000v" + (40 + e) + "H1017.7\ns-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9\nc-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200\nc0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26\ns76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,\n606zM" + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, rt = function(e) {
	var t = e / 2;
	return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, it = function(e, t, n) {
	var r = n - 54 - t - e;
	return "M702 " + (e + t) + "H400000" + (40 + e) + "\nH742v" + r + "l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1\nh-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170\nc-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667\n219 661 l218 661zM702 " + t + "H400000v" + (40 + e) + "H742z";
}, at = function(e, t, n) {
	t = 1e3 * t;
	var r = "";
	switch (e) {
		case "sqrtMain":
			r = Qe(t, Ze);
			break;
		case "sqrtSize1":
			r = $e(t, Ze);
			break;
		case "sqrtSize2":
			r = et(t, Ze);
			break;
		case "sqrtSize3":
			r = tt(t, Ze);
			break;
		case "sqrtSize4":
			r = nt(t, Ze);
			break;
		case "sqrtTall": r = it(t, Ze, n);
	}
	return r;
}, ot = function(e, t) {
	switch (e) {
		case "⎜": return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
		case "∣": return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
		case "∥": return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
		case "⎟": return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
		case "⎢": return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
		case "⎥": return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
		case "⎪": return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
		case "⏐": return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
		case "‖": return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
		default: return "";
	}
}, st = {
	doubleleftarrow: "M262 157\nl10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3\n 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28\n 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5\nc2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5\n 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87\n-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7\n-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z\nm8 0v40h399730v-40zm0 194v40h399730v-40z",
	doublerightarrow: "M399738 392l\n-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5\n 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88\n-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68\n-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18\n-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782\nc-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3\n-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z",
	leftarrow: "M400000 241H110l3-3c68.7-52.7 113.7-120\n 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8\n-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247\nc-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208\n 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3\n 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202\n l-3-3h399890zM100 241v40h399900v-40z",
	leftbrace: "M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117\n-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7\n 5-6 9-10 13-.7 1-7.3 1-20 1H6z",
	leftbraceunder: "M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13\n 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688\n 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7\n-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z",
	leftgroup: "M400000 80\nH435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0\n 435 0h399565z",
	leftgroupunder: "M400000 262\nH435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219\n 435 219h399565z",
	leftharpoon: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3\n-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5\n-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7\n-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z",
	leftharpoonplus: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5\n 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3\n-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7\n-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z\nm0 0v40h400000v-40z",
	leftharpoondown: "M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333\n 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5\n 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667\n-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z",
	leftharpoondownplus: "M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12\n 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7\n-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0\nv40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z",
	lefthook: "M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5\n-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3\n-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21\n 71.5 23h399859zM103 281v-40h399897v40z",
	leftlinesegment: "M40 281 V428 H0 V94 H40 V241 H400000 v40z\nM40 281 V428 H0 V94 H40 V241 H400000 v40z",
	leftmapsto: "M40 281 V448H0V74H40V241H400000v40z\nM40 281 V448H0V74H40V241H400000v40z",
	leftToFrom: "M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23\n-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8\nc28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3\n 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z",
	longequal: "M0 50 h400000 v40H0z m0 194h40000v40H0z\nM0 50 h400000 v40H0z m0 194h40000v40H0z",
	midbrace: "M200428 334\nc-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14\n-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7\n 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11\n 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z",
	midbraceunder: "M199572 214\nc100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14\n 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3\n 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0\n-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z",
	oiintSize1: "M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6\n-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z\nm368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8\n60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z",
	oiintSize2: "M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8\n-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z\nm502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2\nc0 110 84 276 504 276s502.4-166 502.4-276z",
	oiiintSize1: "M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6\n-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z\nm525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0\n85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z",
	oiiintSize2: "M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8\n-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z\nm770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1\nc0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z",
	rightarrow: "M0 241v40h399891c-47.3 35.3-84 78-110 128\n-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20\n 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7\n 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85\n-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n 151.7 139 205zm0 0v40h399900v-40z",
	rightbrace: "M400000 542l\n-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5\ns-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1\nc124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z",
	rightbraceunder: "M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3\n 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237\n-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z",
	rightgroup: "M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0\n 3-1 3-3v-38c-76-158-257-219-435-219H0z",
	rightgroupunder: "M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18\n 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z",
	rightharpoon: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3\n-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2\n-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58\n 69.2 92 94.5zm0 0v40h399900v-40z",
	rightharpoonplus: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11\n-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7\n 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z\nm0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z",
	rightharpoondown: "M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8\n 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5\n-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95\n-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z",
	rightharpoondownplus: "M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8\n 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3\n 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3\n-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z\nm0-194v40h400000v-40zm0 0v40h400000v-40z",
	righthook: "M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3\n 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0\n-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21\n 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z",
	rightlinesegment: "M399960 241 V94 h40 V428 h-40 V281 H0 v-40z\nM399960 241 V94 h40 V428 h-40 V281 H0 v-40z",
	rightToFrom: "M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23\n 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32\n-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142\n-167z M100 147v40h399900v-40zM0 341v40h399900v-40z",
	twoheadleftarrow: "M0 167c68 40\n 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69\n-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3\n-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19\n-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101\n 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z",
	twoheadrightarrow: "M400000 167\nc-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3\n 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42\n 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333\n-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70\n 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z",
	tilde1: "M200 55.538c-77 0-168 73.953-177 73.953-3 0-7\n-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0\n 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0\n 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128\n-68.267.847-113-73.952-191-73.952z",
	tilde2: "M344 55.266c-142 0-300.638 81.316-311.5 86.418\n-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9\n 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114\nc1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751\n 181.476 676 181.476c-149 0-189-126.21-332-126.21z",
	tilde3: "M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457\n-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0\n 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697\n 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696\n -338 0-409-156.573-744-156.573z",
	tilde4: "M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345\n-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409\n 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9\n 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409\n -175.236-744-175.236z",
	vec: "M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5\n3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11\n10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63\n-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1\n-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59\nH213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359\nc-16-25.333-24-45-24-59z",
	widehat1: "M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22\nc-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z",
	widehat2: "M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
	widehat3: "M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
	widehat4: "M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
	widecheck1: "M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,\n-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z",
	widecheck2: "M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
	widecheck3: "M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
	widecheck4: "M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
	baraboveleftarrow: "M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202\nc4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5\nc-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130\ns-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47\n121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6\ns2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11\nc0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z\nM100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z",
	rightarrowabovebar: "M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32\n-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0\n13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39\n-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5\n-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z",
	baraboveshortleftharpoon: "M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17\nc2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21\nc-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40\nc-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z\nM0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z",
	rightharpoonaboveshortbar: "M0,241 l0,40c399126,0,399993,0,399993,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z",
	shortbaraboveleftharpoon: "M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,\n1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,\n-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z\nM93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z",
	shortrightharpoonabovebar: "M53,241l0,40c398570,0,399437,0,399437,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z"
}, ct = function(e, t) {
	switch (e) {
		case "lbrack": return "M403 1759 V84 H666 V0 H319 V1759 v" + t + " v1759 h347 v-84\nH403z M403 1759 V0 H319 V1759 v" + t + " v1759 h84z";
		case "rbrack": return "M347 1759 V0 H0 V84 H263 V1759 v" + t + " v1759 H0 v84 H347z\nM347 1759 V0 H263 V1759 v" + t + " v1759 h84z";
		case "vert": return "M145 15 v585 v" + t + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -t + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M188 15 H145 v585 v" + t + " v585 h43z";
		case "doublevert": return "M145 15 v585 v" + t + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -t + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M188 15 H145 v585 v" + t + " v585 h43z\nM367 15 v585 v" + t + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -t + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M410 15 H367 v585 v" + t + " v585 h43z";
		case "lfloor": return "M319 602 V0 H403 V602 v" + t + " v1715 h263 v84 H319z\nMM319 602 V0 H403 V602 v" + t + " v1715 H319z";
		case "rfloor": return "M319 602 V0 H403 V602 v" + t + " v1799 H0 v-84 H319z\nMM319 602 V0 H403 V602 v" + t + " v1715 H319z";
		case "lceil": return "M403 1759 V84 H666 V0 H319 V1759 v" + t + " v602 h84z\nM403 1759 V0 H319 V1759 v" + t + " v602 h84z";
		case "rceil": return "M347 1759 V0 H0 V84 H263 V1759 v" + t + " v602 h84z\nM347 1759 V0 h-84 V1759 v" + t + " v602 h84z";
		case "lparen": return "M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1\nc-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,\n-36,557 l0," + (t + 84) + "c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,\n949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9\nc0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,\n-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189\nl0,-" + (t + 92) + "c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,\n-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z";
		case "rparen": return "M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,\n63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5\nc11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0," + (t + 9) + "\nc-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664\nc-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11\nc0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17\nc242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558\nl0,-" + (t + 144) + "c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,\n-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z";
		default: throw Error("Unknown stretchy delimiter.");
	}
}, lt = class {
	constructor(e) {
		this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++) e.appendChild(this.children[t].toNode());
		return e;
	}
	toMarkup() {
		for (var e = "", t = 0; t < this.children.length; t++) e += this.children[t].toMarkup();
		return e;
	}
	toText() {
		return this.children.map((e) => e.toText()).join("");
	}
}, ut = {
	"AMS-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		65: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		66: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		67: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		68: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		69: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		70: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		71: [
			0,
			.68889,
			0,
			0,
			.77778
		],
		72: [
			0,
			.68889,
			0,
			0,
			.77778
		],
		73: [
			0,
			.68889,
			0,
			0,
			.38889
		],
		74: [
			.16667,
			.68889,
			0,
			0,
			.5
		],
		75: [
			0,
			.68889,
			0,
			0,
			.77778
		],
		76: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		77: [
			0,
			.68889,
			0,
			0,
			.94445
		],
		78: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		79: [
			.16667,
			.68889,
			0,
			0,
			.77778
		],
		80: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		81: [
			.16667,
			.68889,
			0,
			0,
			.77778
		],
		82: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		83: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		84: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		85: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		86: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		87: [
			0,
			.68889,
			0,
			0,
			1
		],
		88: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		89: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		90: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		107: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		165: [
			0,
			.675,
			.025,
			0,
			.75
		],
		174: [
			.15559,
			.69224,
			0,
			0,
			.94666
		],
		240: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		295: [
			0,
			.68889,
			0,
			0,
			.54028
		],
		710: [
			0,
			.825,
			0,
			0,
			2.33334
		],
		732: [
			0,
			.9,
			0,
			0,
			2.33334
		],
		770: [
			0,
			.825,
			0,
			0,
			2.33334
		],
		771: [
			0,
			.9,
			0,
			0,
			2.33334
		],
		989: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		1008: [
			0,
			.43056,
			.04028,
			0,
			.66667
		],
		8245: [
			0,
			.54986,
			0,
			0,
			.275
		],
		8463: [
			0,
			.68889,
			0,
			0,
			.54028
		],
		8487: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		8498: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		8502: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		8503: [
			0,
			.68889,
			0,
			0,
			.44445
		],
		8504: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		8513: [
			0,
			.68889,
			0,
			0,
			.63889
		],
		8592: [
			-.03598,
			.46402,
			0,
			0,
			.5
		],
		8594: [
			-.03598,
			.46402,
			0,
			0,
			.5
		],
		8602: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8603: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8606: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8608: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8610: [
			.01354,
			.52239,
			0,
			0,
			1.11111
		],
		8611: [
			.01354,
			.52239,
			0,
			0,
			1.11111
		],
		8619: [
			0,
			.54986,
			0,
			0,
			1
		],
		8620: [
			0,
			.54986,
			0,
			0,
			1
		],
		8621: [
			-.13313,
			.37788,
			0,
			0,
			1.38889
		],
		8622: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8624: [
			0,
			.69224,
			0,
			0,
			.5
		],
		8625: [
			0,
			.69224,
			0,
			0,
			.5
		],
		8630: [
			0,
			.43056,
			0,
			0,
			1
		],
		8631: [
			0,
			.43056,
			0,
			0,
			1
		],
		8634: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8635: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8638: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8639: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8642: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8643: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8644: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8646: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8647: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8648: [
			.19444,
			.69224,
			0,
			0,
			.83334
		],
		8649: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8650: [
			.19444,
			.69224,
			0,
			0,
			.83334
		],
		8651: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8652: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8653: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8654: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8655: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8666: [
			.13667,
			.63667,
			0,
			0,
			1
		],
		8667: [
			.13667,
			.63667,
			0,
			0,
			1
		],
		8669: [
			-.13313,
			.37788,
			0,
			0,
			1
		],
		8672: [
			-.064,
			.437,
			0,
			0,
			1.334
		],
		8674: [
			-.064,
			.437,
			0,
			0,
			1.334
		],
		8705: [
			0,
			.825,
			0,
			0,
			.5
		],
		8708: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		8709: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8717: [
			0,
			.43056,
			0,
			0,
			.42917
		],
		8722: [
			-.03598,
			.46402,
			0,
			0,
			.5
		],
		8724: [
			.08198,
			.69224,
			0,
			0,
			.77778
		],
		8726: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8733: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8736: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8737: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8738: [
			.03517,
			.52239,
			0,
			0,
			.72222
		],
		8739: [
			.08167,
			.58167,
			0,
			0,
			.22222
		],
		8740: [
			.25142,
			.74111,
			0,
			0,
			.27778
		],
		8741: [
			.08167,
			.58167,
			0,
			0,
			.38889
		],
		8742: [
			.25142,
			.74111,
			0,
			0,
			.5
		],
		8756: [
			0,
			.69224,
			0,
			0,
			.66667
		],
		8757: [
			0,
			.69224,
			0,
			0,
			.66667
		],
		8764: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		8765: [
			-.13313,
			.37788,
			0,
			0,
			.77778
		],
		8769: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		8770: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8774: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8776: [
			-.01688,
			.48312,
			0,
			0,
			.77778
		],
		8778: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8782: [
			.06062,
			.54986,
			0,
			0,
			.77778
		],
		8783: [
			.06062,
			.54986,
			0,
			0,
			.77778
		],
		8785: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8786: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8787: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8790: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8791: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8796: [
			.08198,
			.91667,
			0,
			0,
			.77778
		],
		8806: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		8807: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		8808: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		8809: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		8812: [
			.25583,
			.75583,
			0,
			0,
			.5
		],
		8814: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8815: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8816: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8817: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8818: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8819: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8822: [
			.1808,
			.675,
			0,
			0,
			.77778
		],
		8823: [
			.1808,
			.675,
			0,
			0,
			.77778
		],
		8828: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8829: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8830: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8831: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8832: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8833: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8840: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8841: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8842: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8843: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8847: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8848: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8858: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8859: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8861: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8862: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8863: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8864: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8865: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8872: [
			0,
			.69224,
			0,
			0,
			.61111
		],
		8873: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8874: [
			0,
			.69224,
			0,
			0,
			.88889
		],
		8876: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		8877: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		8878: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		8879: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		8882: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8883: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8884: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8885: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8888: [
			0,
			.54986,
			0,
			0,
			1.11111
		],
		8890: [
			.19444,
			.43056,
			0,
			0,
			.55556
		],
		8891: [
			.19444,
			.69224,
			0,
			0,
			.61111
		],
		8892: [
			.19444,
			.69224,
			0,
			0,
			.61111
		],
		8901: [
			0,
			.54986,
			0,
			0,
			.27778
		],
		8903: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8905: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8906: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8907: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8908: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8909: [
			-.03598,
			.46402,
			0,
			0,
			.77778
		],
		8910: [
			0,
			.54986,
			0,
			0,
			.76042
		],
		8911: [
			0,
			.54986,
			0,
			0,
			.76042
		],
		8912: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8913: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8914: [
			0,
			.54986,
			0,
			0,
			.66667
		],
		8915: [
			0,
			.54986,
			0,
			0,
			.66667
		],
		8916: [
			0,
			.69224,
			0,
			0,
			.66667
		],
		8918: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8919: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8920: [
			.03517,
			.54986,
			0,
			0,
			1.33334
		],
		8921: [
			.03517,
			.54986,
			0,
			0,
			1.33334
		],
		8922: [
			.38569,
			.88569,
			0,
			0,
			.77778
		],
		8923: [
			.38569,
			.88569,
			0,
			0,
			.77778
		],
		8926: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8927: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8928: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8929: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8934: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8935: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8936: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8937: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8938: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8939: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8940: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8941: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8994: [
			.19444,
			.69224,
			0,
			0,
			.77778
		],
		8995: [
			.19444,
			.69224,
			0,
			0,
			.77778
		],
		9416: [
			.15559,
			.69224,
			0,
			0,
			.90222
		],
		9484: [
			0,
			.69224,
			0,
			0,
			.5
		],
		9488: [
			0,
			.69224,
			0,
			0,
			.5
		],
		9492: [
			0,
			.37788,
			0,
			0,
			.5
		],
		9496: [
			0,
			.37788,
			0,
			0,
			.5
		],
		9585: [
			.19444,
			.68889,
			0,
			0,
			.88889
		],
		9586: [
			.19444,
			.74111,
			0,
			0,
			.88889
		],
		9632: [
			0,
			.675,
			0,
			0,
			.77778
		],
		9633: [
			0,
			.675,
			0,
			0,
			.77778
		],
		9650: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9651: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9654: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		9660: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9661: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9664: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		9674: [
			.11111,
			.69224,
			0,
			0,
			.66667
		],
		9733: [
			.19444,
			.69224,
			0,
			0,
			.94445
		],
		10003: [
			0,
			.69224,
			0,
			0,
			.83334
		],
		10016: [
			0,
			.69224,
			0,
			0,
			.83334
		],
		10731: [
			.11111,
			.69224,
			0,
			0,
			.66667
		],
		10846: [
			.19444,
			.75583,
			0,
			0,
			.61111
		],
		10877: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10878: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10885: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10886: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10887: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		10888: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		10889: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10890: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10891: [
			.48256,
			.98256,
			0,
			0,
			.77778
		],
		10892: [
			.48256,
			.98256,
			0,
			0,
			.77778
		],
		10901: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10902: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10933: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		10934: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		10935: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10936: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10937: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10938: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10949: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10950: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10955: [
			.28481,
			.79383,
			0,
			0,
			.77778
		],
		10956: [
			.28481,
			.79383,
			0,
			0,
			.77778
		],
		57350: [
			.08167,
			.58167,
			0,
			0,
			.22222
		],
		57351: [
			.08167,
			.58167,
			0,
			0,
			.38889
		],
		57352: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		57353: [
			0,
			.43056,
			.04028,
			0,
			.66667
		],
		57356: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57357: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57358: [
			.41951,
			.91951,
			0,
			0,
			.77778
		],
		57359: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		57360: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		57361: [
			.41951,
			.91951,
			0,
			0,
			.77778
		],
		57366: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57367: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57368: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57369: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57370: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		57371: [
			.13597,
			.63597,
			0,
			0,
			.77778
		]
	},
	"Caligraphic-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		65: [
			0,
			.68333,
			0,
			.19445,
			.79847
		],
		66: [
			0,
			.68333,
			.03041,
			.13889,
			.65681
		],
		67: [
			0,
			.68333,
			.05834,
			.13889,
			.52653
		],
		68: [
			0,
			.68333,
			.02778,
			.08334,
			.77139
		],
		69: [
			0,
			.68333,
			.08944,
			.11111,
			.52778
		],
		70: [
			0,
			.68333,
			.09931,
			.11111,
			.71875
		],
		71: [
			.09722,
			.68333,
			.0593,
			.11111,
			.59487
		],
		72: [
			0,
			.68333,
			.00965,
			.11111,
			.84452
		],
		73: [
			0,
			.68333,
			.07382,
			0,
			.54452
		],
		74: [
			.09722,
			.68333,
			.18472,
			.16667,
			.67778
		],
		75: [
			0,
			.68333,
			.01445,
			.05556,
			.76195
		],
		76: [
			0,
			.68333,
			0,
			.13889,
			.68972
		],
		77: [
			0,
			.68333,
			0,
			.13889,
			1.2009
		],
		78: [
			0,
			.68333,
			.14736,
			.08334,
			.82049
		],
		79: [
			0,
			.68333,
			.02778,
			.11111,
			.79611
		],
		80: [
			0,
			.68333,
			.08222,
			.08334,
			.69556
		],
		81: [
			.09722,
			.68333,
			0,
			.11111,
			.81667
		],
		82: [
			0,
			.68333,
			0,
			.08334,
			.8475
		],
		83: [
			0,
			.68333,
			.075,
			.13889,
			.60556
		],
		84: [
			0,
			.68333,
			.25417,
			0,
			.54464
		],
		85: [
			0,
			.68333,
			.09931,
			.08334,
			.62583
		],
		86: [
			0,
			.68333,
			.08222,
			0,
			.61278
		],
		87: [
			0,
			.68333,
			.08222,
			.08334,
			.98778
		],
		88: [
			0,
			.68333,
			.14643,
			.13889,
			.7133
		],
		89: [
			.09722,
			.68333,
			.08222,
			.08334,
			.66834
		],
		90: [
			0,
			.68333,
			.07944,
			.13889,
			.72473
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		]
	},
	"Fraktur-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69141,
			0,
			0,
			.29574
		],
		34: [
			0,
			.69141,
			0,
			0,
			.21471
		],
		38: [
			0,
			.69141,
			0,
			0,
			.73786
		],
		39: [
			0,
			.69141,
			0,
			0,
			.21201
		],
		40: [
			.24982,
			.74947,
			0,
			0,
			.38865
		],
		41: [
			.24982,
			.74947,
			0,
			0,
			.38865
		],
		42: [
			0,
			.62119,
			0,
			0,
			.27764
		],
		43: [
			.08319,
			.58283,
			0,
			0,
			.75623
		],
		44: [
			0,
			.10803,
			0,
			0,
			.27764
		],
		45: [
			.08319,
			.58283,
			0,
			0,
			.75623
		],
		46: [
			0,
			.10803,
			0,
			0,
			.27764
		],
		47: [
			.24982,
			.74947,
			0,
			0,
			.50181
		],
		48: [
			0,
			.47534,
			0,
			0,
			.50181
		],
		49: [
			0,
			.47534,
			0,
			0,
			.50181
		],
		50: [
			0,
			.47534,
			0,
			0,
			.50181
		],
		51: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		52: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		53: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		54: [
			0,
			.69141,
			0,
			0,
			.50181
		],
		55: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		56: [
			0,
			.69141,
			0,
			0,
			.50181
		],
		57: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		58: [
			0,
			.47534,
			0,
			0,
			.21606
		],
		59: [
			.12604,
			.47534,
			0,
			0,
			.21606
		],
		61: [
			-.13099,
			.36866,
			0,
			0,
			.75623
		],
		63: [
			0,
			.69141,
			0,
			0,
			.36245
		],
		65: [
			0,
			.69141,
			0,
			0,
			.7176
		],
		66: [
			0,
			.69141,
			0,
			0,
			.88397
		],
		67: [
			0,
			.69141,
			0,
			0,
			.61254
		],
		68: [
			0,
			.69141,
			0,
			0,
			.83158
		],
		69: [
			0,
			.69141,
			0,
			0,
			.66278
		],
		70: [
			.12604,
			.69141,
			0,
			0,
			.61119
		],
		71: [
			0,
			.69141,
			0,
			0,
			.78539
		],
		72: [
			.06302,
			.69141,
			0,
			0,
			.7203
		],
		73: [
			0,
			.69141,
			0,
			0,
			.55448
		],
		74: [
			.12604,
			.69141,
			0,
			0,
			.55231
		],
		75: [
			0,
			.69141,
			0,
			0,
			.66845
		],
		76: [
			0,
			.69141,
			0,
			0,
			.66602
		],
		77: [
			0,
			.69141,
			0,
			0,
			1.04953
		],
		78: [
			0,
			.69141,
			0,
			0,
			.83212
		],
		79: [
			0,
			.69141,
			0,
			0,
			.82699
		],
		80: [
			.18906,
			.69141,
			0,
			0,
			.82753
		],
		81: [
			.03781,
			.69141,
			0,
			0,
			.82699
		],
		82: [
			0,
			.69141,
			0,
			0,
			.82807
		],
		83: [
			0,
			.69141,
			0,
			0,
			.82861
		],
		84: [
			0,
			.69141,
			0,
			0,
			.66899
		],
		85: [
			0,
			.69141,
			0,
			0,
			.64576
		],
		86: [
			0,
			.69141,
			0,
			0,
			.83131
		],
		87: [
			0,
			.69141,
			0,
			0,
			1.04602
		],
		88: [
			0,
			.69141,
			0,
			0,
			.71922
		],
		89: [
			.18906,
			.69141,
			0,
			0,
			.83293
		],
		90: [
			.12604,
			.69141,
			0,
			0,
			.60201
		],
		91: [
			.24982,
			.74947,
			0,
			0,
			.27764
		],
		93: [
			.24982,
			.74947,
			0,
			0,
			.27764
		],
		94: [
			0,
			.69141,
			0,
			0,
			.49965
		],
		97: [
			0,
			.47534,
			0,
			0,
			.50046
		],
		98: [
			0,
			.69141,
			0,
			0,
			.51315
		],
		99: [
			0,
			.47534,
			0,
			0,
			.38946
		],
		100: [
			0,
			.62119,
			0,
			0,
			.49857
		],
		101: [
			0,
			.47534,
			0,
			0,
			.40053
		],
		102: [
			.18906,
			.69141,
			0,
			0,
			.32626
		],
		103: [
			.18906,
			.47534,
			0,
			0,
			.5037
		],
		104: [
			.18906,
			.69141,
			0,
			0,
			.52126
		],
		105: [
			0,
			.69141,
			0,
			0,
			.27899
		],
		106: [
			0,
			.69141,
			0,
			0,
			.28088
		],
		107: [
			0,
			.69141,
			0,
			0,
			.38946
		],
		108: [
			0,
			.69141,
			0,
			0,
			.27953
		],
		109: [
			0,
			.47534,
			0,
			0,
			.76676
		],
		110: [
			0,
			.47534,
			0,
			0,
			.52666
		],
		111: [
			0,
			.47534,
			0,
			0,
			.48885
		],
		112: [
			.18906,
			.52396,
			0,
			0,
			.50046
		],
		113: [
			.18906,
			.47534,
			0,
			0,
			.48912
		],
		114: [
			0,
			.47534,
			0,
			0,
			.38919
		],
		115: [
			0,
			.47534,
			0,
			0,
			.44266
		],
		116: [
			0,
			.62119,
			0,
			0,
			.33301
		],
		117: [
			0,
			.47534,
			0,
			0,
			.5172
		],
		118: [
			0,
			.52396,
			0,
			0,
			.5118
		],
		119: [
			0,
			.52396,
			0,
			0,
			.77351
		],
		120: [
			.18906,
			.47534,
			0,
			0,
			.38865
		],
		121: [
			.18906,
			.47534,
			0,
			0,
			.49884
		],
		122: [
			.18906,
			.47534,
			0,
			0,
			.39054
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		8216: [
			0,
			.69141,
			0,
			0,
			.21471
		],
		8217: [
			0,
			.69141,
			0,
			0,
			.21471
		],
		58112: [
			0,
			.62119,
			0,
			0,
			.49749
		],
		58113: [
			0,
			.62119,
			0,
			0,
			.4983
		],
		58114: [
			.18906,
			.69141,
			0,
			0,
			.33328
		],
		58115: [
			.18906,
			.69141,
			0,
			0,
			.32923
		],
		58116: [
			.18906,
			.47534,
			0,
			0,
			.50343
		],
		58117: [
			0,
			.69141,
			0,
			0,
			.33301
		],
		58118: [
			0,
			.62119,
			0,
			0,
			.33409
		],
		58119: [
			0,
			.47534,
			0,
			0,
			.50073
		]
	},
	"Main-Bold": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.35
		],
		34: [
			0,
			.69444,
			0,
			0,
			.60278
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.95833
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.575
		],
		37: [
			.05556,
			.75,
			0,
			0,
			.95833
		],
		38: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		39: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		40: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		41: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		42: [
			0,
			.75,
			0,
			0,
			.575
		],
		43: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		44: [
			.19444,
			.15556,
			0,
			0,
			.31944
		],
		45: [
			0,
			.44444,
			0,
			0,
			.38333
		],
		46: [
			0,
			.15556,
			0,
			0,
			.31944
		],
		47: [
			.25,
			.75,
			0,
			0,
			.575
		],
		48: [
			0,
			.64444,
			0,
			0,
			.575
		],
		49: [
			0,
			.64444,
			0,
			0,
			.575
		],
		50: [
			0,
			.64444,
			0,
			0,
			.575
		],
		51: [
			0,
			.64444,
			0,
			0,
			.575
		],
		52: [
			0,
			.64444,
			0,
			0,
			.575
		],
		53: [
			0,
			.64444,
			0,
			0,
			.575
		],
		54: [
			0,
			.64444,
			0,
			0,
			.575
		],
		55: [
			0,
			.64444,
			0,
			0,
			.575
		],
		56: [
			0,
			.64444,
			0,
			0,
			.575
		],
		57: [
			0,
			.64444,
			0,
			0,
			.575
		],
		58: [
			0,
			.44444,
			0,
			0,
			.31944
		],
		59: [
			.19444,
			.44444,
			0,
			0,
			.31944
		],
		60: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		61: [
			-.10889,
			.39111,
			0,
			0,
			.89444
		],
		62: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		63: [
			0,
			.69444,
			0,
			0,
			.54305
		],
		64: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		65: [
			0,
			.68611,
			0,
			0,
			.86944
		],
		66: [
			0,
			.68611,
			0,
			0,
			.81805
		],
		67: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		68: [
			0,
			.68611,
			0,
			0,
			.88194
		],
		69: [
			0,
			.68611,
			0,
			0,
			.75555
		],
		70: [
			0,
			.68611,
			0,
			0,
			.72361
		],
		71: [
			0,
			.68611,
			0,
			0,
			.90416
		],
		72: [
			0,
			.68611,
			0,
			0,
			.9
		],
		73: [
			0,
			.68611,
			0,
			0,
			.43611
		],
		74: [
			0,
			.68611,
			0,
			0,
			.59444
		],
		75: [
			0,
			.68611,
			0,
			0,
			.90138
		],
		76: [
			0,
			.68611,
			0,
			0,
			.69166
		],
		77: [
			0,
			.68611,
			0,
			0,
			1.09166
		],
		78: [
			0,
			.68611,
			0,
			0,
			.9
		],
		79: [
			0,
			.68611,
			0,
			0,
			.86388
		],
		80: [
			0,
			.68611,
			0,
			0,
			.78611
		],
		81: [
			.19444,
			.68611,
			0,
			0,
			.86388
		],
		82: [
			0,
			.68611,
			0,
			0,
			.8625
		],
		83: [
			0,
			.68611,
			0,
			0,
			.63889
		],
		84: [
			0,
			.68611,
			0,
			0,
			.8
		],
		85: [
			0,
			.68611,
			0,
			0,
			.88472
		],
		86: [
			0,
			.68611,
			.01597,
			0,
			.86944
		],
		87: [
			0,
			.68611,
			.01597,
			0,
			1.18888
		],
		88: [
			0,
			.68611,
			0,
			0,
			.86944
		],
		89: [
			0,
			.68611,
			.02875,
			0,
			.86944
		],
		90: [
			0,
			.68611,
			0,
			0,
			.70277
		],
		91: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		92: [
			.25,
			.75,
			0,
			0,
			.575
		],
		93: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		94: [
			0,
			.69444,
			0,
			0,
			.575
		],
		95: [
			.31,
			.13444,
			.03194,
			0,
			.575
		],
		97: [
			0,
			.44444,
			0,
			0,
			.55902
		],
		98: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		99: [
			0,
			.44444,
			0,
			0,
			.51111
		],
		100: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		101: [
			0,
			.44444,
			0,
			0,
			.52708
		],
		102: [
			0,
			.69444,
			.10903,
			0,
			.35139
		],
		103: [
			.19444,
			.44444,
			.01597,
			0,
			.575
		],
		104: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		105: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		106: [
			.19444,
			.69444,
			0,
			0,
			.35139
		],
		107: [
			0,
			.69444,
			0,
			0,
			.60694
		],
		108: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		109: [
			0,
			.44444,
			0,
			0,
			.95833
		],
		110: [
			0,
			.44444,
			0,
			0,
			.63889
		],
		111: [
			0,
			.44444,
			0,
			0,
			.575
		],
		112: [
			.19444,
			.44444,
			0,
			0,
			.63889
		],
		113: [
			.19444,
			.44444,
			0,
			0,
			.60694
		],
		114: [
			0,
			.44444,
			0,
			0,
			.47361
		],
		115: [
			0,
			.44444,
			0,
			0,
			.45361
		],
		116: [
			0,
			.63492,
			0,
			0,
			.44722
		],
		117: [
			0,
			.44444,
			0,
			0,
			.63889
		],
		118: [
			0,
			.44444,
			.01597,
			0,
			.60694
		],
		119: [
			0,
			.44444,
			.01597,
			0,
			.83055
		],
		120: [
			0,
			.44444,
			0,
			0,
			.60694
		],
		121: [
			.19444,
			.44444,
			.01597,
			0,
			.60694
		],
		122: [
			0,
			.44444,
			0,
			0,
			.51111
		],
		123: [
			.25,
			.75,
			0,
			0,
			.575
		],
		124: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		125: [
			.25,
			.75,
			0,
			0,
			.575
		],
		126: [
			.35,
			.34444,
			0,
			0,
			.575
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		163: [
			0,
			.69444,
			0,
			0,
			.86853
		],
		168: [
			0,
			.69444,
			0,
			0,
			.575
		],
		172: [
			0,
			.44444,
			0,
			0,
			.76666
		],
		176: [
			0,
			.69444,
			0,
			0,
			.86944
		],
		177: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		184: [
			.17014,
			0,
			0,
			0,
			.51111
		],
		198: [
			0,
			.68611,
			0,
			0,
			1.04166
		],
		215: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		216: [
			.04861,
			.73472,
			0,
			0,
			.89444
		],
		223: [
			0,
			.69444,
			0,
			0,
			.59722
		],
		230: [
			0,
			.44444,
			0,
			0,
			.83055
		],
		247: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		248: [
			.09722,
			.54167,
			0,
			0,
			.575
		],
		305: [
			0,
			.44444,
			0,
			0,
			.31944
		],
		338: [
			0,
			.68611,
			0,
			0,
			1.16944
		],
		339: [
			0,
			.44444,
			0,
			0,
			.89444
		],
		567: [
			.19444,
			.44444,
			0,
			0,
			.35139
		],
		710: [
			0,
			.69444,
			0,
			0,
			.575
		],
		711: [
			0,
			.63194,
			0,
			0,
			.575
		],
		713: [
			0,
			.59611,
			0,
			0,
			.575
		],
		714: [
			0,
			.69444,
			0,
			0,
			.575
		],
		715: [
			0,
			.69444,
			0,
			0,
			.575
		],
		728: [
			0,
			.69444,
			0,
			0,
			.575
		],
		729: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		730: [
			0,
			.69444,
			0,
			0,
			.86944
		],
		732: [
			0,
			.69444,
			0,
			0,
			.575
		],
		733: [
			0,
			.69444,
			0,
			0,
			.575
		],
		915: [
			0,
			.68611,
			0,
			0,
			.69166
		],
		916: [
			0,
			.68611,
			0,
			0,
			.95833
		],
		920: [
			0,
			.68611,
			0,
			0,
			.89444
		],
		923: [
			0,
			.68611,
			0,
			0,
			.80555
		],
		926: [
			0,
			.68611,
			0,
			0,
			.76666
		],
		928: [
			0,
			.68611,
			0,
			0,
			.9
		],
		931: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		933: [
			0,
			.68611,
			0,
			0,
			.89444
		],
		934: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		936: [
			0,
			.68611,
			0,
			0,
			.89444
		],
		937: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		8211: [
			0,
			.44444,
			.03194,
			0,
			.575
		],
		8212: [
			0,
			.44444,
			.03194,
			0,
			1.14999
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.60278
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.60278
		],
		8224: [
			.19444,
			.69444,
			0,
			0,
			.51111
		],
		8225: [
			.19444,
			.69444,
			0,
			0,
			.51111
		],
		8242: [
			0,
			.55556,
			0,
			0,
			.34444
		],
		8407: [
			0,
			.72444,
			.15486,
			0,
			.575
		],
		8463: [
			0,
			.69444,
			0,
			0,
			.66759
		],
		8465: [
			0,
			.69444,
			0,
			0,
			.83055
		],
		8467: [
			0,
			.69444,
			0,
			0,
			.47361
		],
		8472: [
			.19444,
			.44444,
			0,
			0,
			.74027
		],
		8476: [
			0,
			.69444,
			0,
			0,
			.83055
		],
		8501: [
			0,
			.69444,
			0,
			0,
			.70277
		],
		8592: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8593: [
			.19444,
			.69444,
			0,
			0,
			.575
		],
		8594: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8595: [
			.19444,
			.69444,
			0,
			0,
			.575
		],
		8596: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8597: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8598: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8599: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8600: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8601: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8636: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8637: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8640: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8641: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8656: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8657: [
			.19444,
			.69444,
			0,
			0,
			.70277
		],
		8658: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8659: [
			.19444,
			.69444,
			0,
			0,
			.70277
		],
		8660: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8661: [
			.25,
			.75,
			0,
			0,
			.70277
		],
		8704: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		8706: [
			0,
			.69444,
			.06389,
			0,
			.62847
		],
		8707: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		8709: [
			.05556,
			.75,
			0,
			0,
			.575
		],
		8711: [
			0,
			.68611,
			0,
			0,
			.95833
		],
		8712: [
			.08556,
			.58556,
			0,
			0,
			.76666
		],
		8715: [
			.08556,
			.58556,
			0,
			0,
			.76666
		],
		8722: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8723: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8725: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8726: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8727: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		8728: [
			-.02639,
			.47361,
			0,
			0,
			.575
		],
		8729: [
			-.02639,
			.47361,
			0,
			0,
			.575
		],
		8730: [
			.18,
			.82,
			0,
			0,
			.95833
		],
		8733: [
			0,
			.44444,
			0,
			0,
			.89444
		],
		8734: [
			0,
			.44444,
			0,
			0,
			1.14999
		],
		8736: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8739: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		8741: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8743: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8744: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8745: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8746: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8747: [
			.19444,
			.69444,
			.12778,
			0,
			.56875
		],
		8764: [
			-.10889,
			.39111,
			0,
			0,
			.89444
		],
		8768: [
			.19444,
			.69444,
			0,
			0,
			.31944
		],
		8771: [
			.00222,
			.50222,
			0,
			0,
			.89444
		],
		8773: [
			.027,
			.638,
			0,
			0,
			.894
		],
		8776: [
			.02444,
			.52444,
			0,
			0,
			.89444
		],
		8781: [
			.00222,
			.50222,
			0,
			0,
			.89444
		],
		8801: [
			.00222,
			.50222,
			0,
			0,
			.89444
		],
		8804: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8805: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8810: [
			.08556,
			.58556,
			0,
			0,
			1.14999
		],
		8811: [
			.08556,
			.58556,
			0,
			0,
			1.14999
		],
		8826: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8827: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8834: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8835: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8838: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8839: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8846: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8849: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8850: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8851: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8852: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8853: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8854: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8855: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8856: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8857: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8866: [
			0,
			.69444,
			0,
			0,
			.70277
		],
		8867: [
			0,
			.69444,
			0,
			0,
			.70277
		],
		8868: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		8869: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		8900: [
			-.02639,
			.47361,
			0,
			0,
			.575
		],
		8901: [
			-.02639,
			.47361,
			0,
			0,
			.31944
		],
		8902: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		8968: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8969: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8970: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8971: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8994: [
			-.13889,
			.36111,
			0,
			0,
			1.14999
		],
		8995: [
			-.13889,
			.36111,
			0,
			0,
			1.14999
		],
		9651: [
			.19444,
			.69444,
			0,
			0,
			1.02222
		],
		9657: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		9661: [
			.19444,
			.69444,
			0,
			0,
			1.02222
		],
		9667: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		9711: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		9824: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9825: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9826: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9827: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9837: [
			0,
			.75,
			0,
			0,
			.44722
		],
		9838: [
			.19444,
			.69444,
			0,
			0,
			.44722
		],
		9839: [
			.19444,
			.69444,
			0,
			0,
			.44722
		],
		10216: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		10217: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		10815: [
			0,
			.68611,
			0,
			0,
			.9
		],
		10927: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		10928: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		57376: [
			.19444,
			.69444,
			0,
			0,
			0
		]
	},
	"Main-BoldItalic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			.11417,
			0,
			.38611
		],
		34: [
			0,
			.69444,
			.07939,
			0,
			.62055
		],
		35: [
			.19444,
			.69444,
			.06833,
			0,
			.94444
		],
		37: [
			.05556,
			.75,
			.12861,
			0,
			.94444
		],
		38: [
			0,
			.69444,
			.08528,
			0,
			.88555
		],
		39: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		40: [
			.25,
			.75,
			.15806,
			0,
			.47333
		],
		41: [
			.25,
			.75,
			.03306,
			0,
			.47333
		],
		42: [
			0,
			.75,
			.14333,
			0,
			.59111
		],
		43: [
			.10333,
			.60333,
			.03306,
			0,
			.88555
		],
		44: [
			.19444,
			.14722,
			0,
			0,
			.35555
		],
		45: [
			0,
			.44444,
			.02611,
			0,
			.41444
		],
		46: [
			0,
			.14722,
			0,
			0,
			.35555
		],
		47: [
			.25,
			.75,
			.15806,
			0,
			.59111
		],
		48: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		49: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		50: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		51: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		52: [
			.19444,
			.64444,
			.13167,
			0,
			.59111
		],
		53: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		54: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		55: [
			.19444,
			.64444,
			.13167,
			0,
			.59111
		],
		56: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		57: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		58: [
			0,
			.44444,
			.06695,
			0,
			.35555
		],
		59: [
			.19444,
			.44444,
			.06695,
			0,
			.35555
		],
		61: [
			-.10889,
			.39111,
			.06833,
			0,
			.88555
		],
		63: [
			0,
			.69444,
			.11472,
			0,
			.59111
		],
		64: [
			0,
			.69444,
			.09208,
			0,
			.88555
		],
		65: [
			0,
			.68611,
			0,
			0,
			.86555
		],
		66: [
			0,
			.68611,
			.0992,
			0,
			.81666
		],
		67: [
			0,
			.68611,
			.14208,
			0,
			.82666
		],
		68: [
			0,
			.68611,
			.09062,
			0,
			.87555
		],
		69: [
			0,
			.68611,
			.11431,
			0,
			.75666
		],
		70: [
			0,
			.68611,
			.12903,
			0,
			.72722
		],
		71: [
			0,
			.68611,
			.07347,
			0,
			.89527
		],
		72: [
			0,
			.68611,
			.17208,
			0,
			.8961
		],
		73: [
			0,
			.68611,
			.15681,
			0,
			.47166
		],
		74: [
			0,
			.68611,
			.145,
			0,
			.61055
		],
		75: [
			0,
			.68611,
			.14208,
			0,
			.89499
		],
		76: [
			0,
			.68611,
			0,
			0,
			.69777
		],
		77: [
			0,
			.68611,
			.17208,
			0,
			1.07277
		],
		78: [
			0,
			.68611,
			.17208,
			0,
			.8961
		],
		79: [
			0,
			.68611,
			.09062,
			0,
			.85499
		],
		80: [
			0,
			.68611,
			.0992,
			0,
			.78721
		],
		81: [
			.19444,
			.68611,
			.09062,
			0,
			.85499
		],
		82: [
			0,
			.68611,
			.02559,
			0,
			.85944
		],
		83: [
			0,
			.68611,
			.11264,
			0,
			.64999
		],
		84: [
			0,
			.68611,
			.12903,
			0,
			.7961
		],
		85: [
			0,
			.68611,
			.17208,
			0,
			.88083
		],
		86: [
			0,
			.68611,
			.18625,
			0,
			.86555
		],
		87: [
			0,
			.68611,
			.18625,
			0,
			1.15999
		],
		88: [
			0,
			.68611,
			.15681,
			0,
			.86555
		],
		89: [
			0,
			.68611,
			.19803,
			0,
			.86555
		],
		90: [
			0,
			.68611,
			.14208,
			0,
			.70888
		],
		91: [
			.25,
			.75,
			.1875,
			0,
			.35611
		],
		93: [
			.25,
			.75,
			.09972,
			0,
			.35611
		],
		94: [
			0,
			.69444,
			.06709,
			0,
			.59111
		],
		95: [
			.31,
			.13444,
			.09811,
			0,
			.59111
		],
		97: [
			0,
			.44444,
			.09426,
			0,
			.59111
		],
		98: [
			0,
			.69444,
			.07861,
			0,
			.53222
		],
		99: [
			0,
			.44444,
			.05222,
			0,
			.53222
		],
		100: [
			0,
			.69444,
			.10861,
			0,
			.59111
		],
		101: [
			0,
			.44444,
			.085,
			0,
			.53222
		],
		102: [
			.19444,
			.69444,
			.21778,
			0,
			.4
		],
		103: [
			.19444,
			.44444,
			.105,
			0,
			.53222
		],
		104: [
			0,
			.69444,
			.09426,
			0,
			.59111
		],
		105: [
			0,
			.69326,
			.11387,
			0,
			.35555
		],
		106: [
			.19444,
			.69326,
			.1672,
			0,
			.35555
		],
		107: [
			0,
			.69444,
			.11111,
			0,
			.53222
		],
		108: [
			0,
			.69444,
			.10861,
			0,
			.29666
		],
		109: [
			0,
			.44444,
			.09426,
			0,
			.94444
		],
		110: [
			0,
			.44444,
			.09426,
			0,
			.64999
		],
		111: [
			0,
			.44444,
			.07861,
			0,
			.59111
		],
		112: [
			.19444,
			.44444,
			.07861,
			0,
			.59111
		],
		113: [
			.19444,
			.44444,
			.105,
			0,
			.53222
		],
		114: [
			0,
			.44444,
			.11111,
			0,
			.50167
		],
		115: [
			0,
			.44444,
			.08167,
			0,
			.48694
		],
		116: [
			0,
			.63492,
			.09639,
			0,
			.385
		],
		117: [
			0,
			.44444,
			.09426,
			0,
			.62055
		],
		118: [
			0,
			.44444,
			.11111,
			0,
			.53222
		],
		119: [
			0,
			.44444,
			.11111,
			0,
			.76777
		],
		120: [
			0,
			.44444,
			.12583,
			0,
			.56055
		],
		121: [
			.19444,
			.44444,
			.105,
			0,
			.56166
		],
		122: [
			0,
			.44444,
			.13889,
			0,
			.49055
		],
		126: [
			.35,
			.34444,
			.11472,
			0,
			.59111
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.69444,
			.11473,
			0,
			.59111
		],
		176: [
			0,
			.69444,
			0,
			0,
			.94888
		],
		184: [
			.17014,
			0,
			0,
			0,
			.53222
		],
		198: [
			0,
			.68611,
			.11431,
			0,
			1.02277
		],
		216: [
			.04861,
			.73472,
			.09062,
			0,
			.88555
		],
		223: [
			.19444,
			.69444,
			.09736,
			0,
			.665
		],
		230: [
			0,
			.44444,
			.085,
			0,
			.82666
		],
		248: [
			.09722,
			.54167,
			.09458,
			0,
			.59111
		],
		305: [
			0,
			.44444,
			.09426,
			0,
			.35555
		],
		338: [
			0,
			.68611,
			.11431,
			0,
			1.14054
		],
		339: [
			0,
			.44444,
			.085,
			0,
			.82666
		],
		567: [
			.19444,
			.44444,
			.04611,
			0,
			.385
		],
		710: [
			0,
			.69444,
			.06709,
			0,
			.59111
		],
		711: [
			0,
			.63194,
			.08271,
			0,
			.59111
		],
		713: [
			0,
			.59444,
			.10444,
			0,
			.59111
		],
		714: [
			0,
			.69444,
			.08528,
			0,
			.59111
		],
		715: [
			0,
			.69444,
			0,
			0,
			.59111
		],
		728: [
			0,
			.69444,
			.10333,
			0,
			.59111
		],
		729: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		730: [
			0,
			.69444,
			0,
			0,
			.94888
		],
		732: [
			0,
			.69444,
			.11472,
			0,
			.59111
		],
		733: [
			0,
			.69444,
			.11472,
			0,
			.59111
		],
		915: [
			0,
			.68611,
			.12903,
			0,
			.69777
		],
		916: [
			0,
			.68611,
			0,
			0,
			.94444
		],
		920: [
			0,
			.68611,
			.09062,
			0,
			.88555
		],
		923: [
			0,
			.68611,
			0,
			0,
			.80666
		],
		926: [
			0,
			.68611,
			.15092,
			0,
			.76777
		],
		928: [
			0,
			.68611,
			.17208,
			0,
			.8961
		],
		931: [
			0,
			.68611,
			.11431,
			0,
			.82666
		],
		933: [
			0,
			.68611,
			.10778,
			0,
			.88555
		],
		934: [
			0,
			.68611,
			.05632,
			0,
			.82666
		],
		936: [
			0,
			.68611,
			.10778,
			0,
			.88555
		],
		937: [
			0,
			.68611,
			.0992,
			0,
			.82666
		],
		8211: [
			0,
			.44444,
			.09811,
			0,
			.59111
		],
		8212: [
			0,
			.44444,
			.09811,
			0,
			1.18221
		],
		8216: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		8217: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		8220: [
			0,
			.69444,
			.16772,
			0,
			.62055
		],
		8221: [
			0,
			.69444,
			.07939,
			0,
			.62055
		]
	},
	"Main-Italic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		34: [
			0,
			.69444,
			.06961,
			0,
			.51444
		],
		35: [
			.19444,
			.69444,
			.06616,
			0,
			.81777
		],
		37: [
			.05556,
			.75,
			.13639,
			0,
			.81777
		],
		38: [
			0,
			.69444,
			.09694,
			0,
			.76666
		],
		39: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		40: [
			.25,
			.75,
			.16194,
			0,
			.40889
		],
		41: [
			.25,
			.75,
			.03694,
			0,
			.40889
		],
		42: [
			0,
			.75,
			.14917,
			0,
			.51111
		],
		43: [
			.05667,
			.56167,
			.03694,
			0,
			.76666
		],
		44: [
			.19444,
			.10556,
			0,
			0,
			.30667
		],
		45: [
			0,
			.43056,
			.02826,
			0,
			.35778
		],
		46: [
			0,
			.10556,
			0,
			0,
			.30667
		],
		47: [
			.25,
			.75,
			.16194,
			0,
			.51111
		],
		48: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		49: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		50: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		51: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		52: [
			.19444,
			.64444,
			.13556,
			0,
			.51111
		],
		53: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		54: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		55: [
			.19444,
			.64444,
			.13556,
			0,
			.51111
		],
		56: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		57: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		58: [
			0,
			.43056,
			.0582,
			0,
			.30667
		],
		59: [
			.19444,
			.43056,
			.0582,
			0,
			.30667
		],
		61: [
			-.13313,
			.36687,
			.06616,
			0,
			.76666
		],
		63: [
			0,
			.69444,
			.1225,
			0,
			.51111
		],
		64: [
			0,
			.69444,
			.09597,
			0,
			.76666
		],
		65: [
			0,
			.68333,
			0,
			0,
			.74333
		],
		66: [
			0,
			.68333,
			.10257,
			0,
			.70389
		],
		67: [
			0,
			.68333,
			.14528,
			0,
			.71555
		],
		68: [
			0,
			.68333,
			.09403,
			0,
			.755
		],
		69: [
			0,
			.68333,
			.12028,
			0,
			.67833
		],
		70: [
			0,
			.68333,
			.13305,
			0,
			.65277
		],
		71: [
			0,
			.68333,
			.08722,
			0,
			.77361
		],
		72: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		73: [
			0,
			.68333,
			.15806,
			0,
			.38555
		],
		74: [
			0,
			.68333,
			.14028,
			0,
			.525
		],
		75: [
			0,
			.68333,
			.14528,
			0,
			.76888
		],
		76: [
			0,
			.68333,
			0,
			0,
			.62722
		],
		77: [
			0,
			.68333,
			.16389,
			0,
			.89666
		],
		78: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		79: [
			0,
			.68333,
			.09403,
			0,
			.76666
		],
		80: [
			0,
			.68333,
			.10257,
			0,
			.67833
		],
		81: [
			.19444,
			.68333,
			.09403,
			0,
			.76666
		],
		82: [
			0,
			.68333,
			.03868,
			0,
			.72944
		],
		83: [
			0,
			.68333,
			.11972,
			0,
			.56222
		],
		84: [
			0,
			.68333,
			.13305,
			0,
			.71555
		],
		85: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		86: [
			0,
			.68333,
			.18361,
			0,
			.74333
		],
		87: [
			0,
			.68333,
			.18361,
			0,
			.99888
		],
		88: [
			0,
			.68333,
			.15806,
			0,
			.74333
		],
		89: [
			0,
			.68333,
			.19383,
			0,
			.74333
		],
		90: [
			0,
			.68333,
			.14528,
			0,
			.61333
		],
		91: [
			.25,
			.75,
			.1875,
			0,
			.30667
		],
		93: [
			.25,
			.75,
			.10528,
			0,
			.30667
		],
		94: [
			0,
			.69444,
			.06646,
			0,
			.51111
		],
		95: [
			.31,
			.12056,
			.09208,
			0,
			.51111
		],
		97: [
			0,
			.43056,
			.07671,
			0,
			.51111
		],
		98: [
			0,
			.69444,
			.06312,
			0,
			.46
		],
		99: [
			0,
			.43056,
			.05653,
			0,
			.46
		],
		100: [
			0,
			.69444,
			.10333,
			0,
			.51111
		],
		101: [
			0,
			.43056,
			.07514,
			0,
			.46
		],
		102: [
			.19444,
			.69444,
			.21194,
			0,
			.30667
		],
		103: [
			.19444,
			.43056,
			.08847,
			0,
			.46
		],
		104: [
			0,
			.69444,
			.07671,
			0,
			.51111
		],
		105: [
			0,
			.65536,
			.1019,
			0,
			.30667
		],
		106: [
			.19444,
			.65536,
			.14467,
			0,
			.30667
		],
		107: [
			0,
			.69444,
			.10764,
			0,
			.46
		],
		108: [
			0,
			.69444,
			.10333,
			0,
			.25555
		],
		109: [
			0,
			.43056,
			.07671,
			0,
			.81777
		],
		110: [
			0,
			.43056,
			.07671,
			0,
			.56222
		],
		111: [
			0,
			.43056,
			.06312,
			0,
			.51111
		],
		112: [
			.19444,
			.43056,
			.06312,
			0,
			.51111
		],
		113: [
			.19444,
			.43056,
			.08847,
			0,
			.46
		],
		114: [
			0,
			.43056,
			.10764,
			0,
			.42166
		],
		115: [
			0,
			.43056,
			.08208,
			0,
			.40889
		],
		116: [
			0,
			.61508,
			.09486,
			0,
			.33222
		],
		117: [
			0,
			.43056,
			.07671,
			0,
			.53666
		],
		118: [
			0,
			.43056,
			.10764,
			0,
			.46
		],
		119: [
			0,
			.43056,
			.10764,
			0,
			.66444
		],
		120: [
			0,
			.43056,
			.12042,
			0,
			.46389
		],
		121: [
			.19444,
			.43056,
			.08847,
			0,
			.48555
		],
		122: [
			0,
			.43056,
			.12292,
			0,
			.40889
		],
		126: [
			.35,
			.31786,
			.11585,
			0,
			.51111
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.66786,
			.10474,
			0,
			.51111
		],
		176: [
			0,
			.69444,
			0,
			0,
			.83129
		],
		184: [
			.17014,
			0,
			0,
			0,
			.46
		],
		198: [
			0,
			.68333,
			.12028,
			0,
			.88277
		],
		216: [
			.04861,
			.73194,
			.09403,
			0,
			.76666
		],
		223: [
			.19444,
			.69444,
			.10514,
			0,
			.53666
		],
		230: [
			0,
			.43056,
			.07514,
			0,
			.71555
		],
		248: [
			.09722,
			.52778,
			.09194,
			0,
			.51111
		],
		338: [
			0,
			.68333,
			.12028,
			0,
			.98499
		],
		339: [
			0,
			.43056,
			.07514,
			0,
			.71555
		],
		710: [
			0,
			.69444,
			.06646,
			0,
			.51111
		],
		711: [
			0,
			.62847,
			.08295,
			0,
			.51111
		],
		713: [
			0,
			.56167,
			.10333,
			0,
			.51111
		],
		714: [
			0,
			.69444,
			.09694,
			0,
			.51111
		],
		715: [
			0,
			.69444,
			0,
			0,
			.51111
		],
		728: [
			0,
			.69444,
			.10806,
			0,
			.51111
		],
		729: [
			0,
			.66786,
			.11752,
			0,
			.30667
		],
		730: [
			0,
			.69444,
			0,
			0,
			.83129
		],
		732: [
			0,
			.66786,
			.11585,
			0,
			.51111
		],
		733: [
			0,
			.69444,
			.1225,
			0,
			.51111
		],
		915: [
			0,
			.68333,
			.13305,
			0,
			.62722
		],
		916: [
			0,
			.68333,
			0,
			0,
			.81777
		],
		920: [
			0,
			.68333,
			.09403,
			0,
			.76666
		],
		923: [
			0,
			.68333,
			0,
			0,
			.69222
		],
		926: [
			0,
			.68333,
			.15294,
			0,
			.66444
		],
		928: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		931: [
			0,
			.68333,
			.12028,
			0,
			.71555
		],
		933: [
			0,
			.68333,
			.11111,
			0,
			.76666
		],
		934: [
			0,
			.68333,
			.05986,
			0,
			.71555
		],
		936: [
			0,
			.68333,
			.11111,
			0,
			.76666
		],
		937: [
			0,
			.68333,
			.10257,
			0,
			.71555
		],
		8211: [
			0,
			.43056,
			.09208,
			0,
			.51111
		],
		8212: [
			0,
			.43056,
			.09208,
			0,
			1.02222
		],
		8216: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		8217: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		8220: [
			0,
			.69444,
			.1685,
			0,
			.51444
		],
		8221: [
			0,
			.69444,
			.06961,
			0,
			.51444
		],
		8463: [
			0,
			.68889,
			0,
			0,
			.54028
		]
	},
	"Main-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		34: [
			0,
			.69444,
			0,
			0,
			.5
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.83334
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.5
		],
		37: [
			.05556,
			.75,
			0,
			0,
			.83334
		],
		38: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		39: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		40: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		41: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		42: [
			0,
			.75,
			0,
			0,
			.5
		],
		43: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		44: [
			.19444,
			.10556,
			0,
			0,
			.27778
		],
		45: [
			0,
			.43056,
			0,
			0,
			.33333
		],
		46: [
			0,
			.10556,
			0,
			0,
			.27778
		],
		47: [
			.25,
			.75,
			0,
			0,
			.5
		],
		48: [
			0,
			.64444,
			0,
			0,
			.5
		],
		49: [
			0,
			.64444,
			0,
			0,
			.5
		],
		50: [
			0,
			.64444,
			0,
			0,
			.5
		],
		51: [
			0,
			.64444,
			0,
			0,
			.5
		],
		52: [
			0,
			.64444,
			0,
			0,
			.5
		],
		53: [
			0,
			.64444,
			0,
			0,
			.5
		],
		54: [
			0,
			.64444,
			0,
			0,
			.5
		],
		55: [
			0,
			.64444,
			0,
			0,
			.5
		],
		56: [
			0,
			.64444,
			0,
			0,
			.5
		],
		57: [
			0,
			.64444,
			0,
			0,
			.5
		],
		58: [
			0,
			.43056,
			0,
			0,
			.27778
		],
		59: [
			.19444,
			.43056,
			0,
			0,
			.27778
		],
		60: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		61: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		62: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		63: [
			0,
			.69444,
			0,
			0,
			.47222
		],
		64: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		65: [
			0,
			.68333,
			0,
			0,
			.75
		],
		66: [
			0,
			.68333,
			0,
			0,
			.70834
		],
		67: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		68: [
			0,
			.68333,
			0,
			0,
			.76389
		],
		69: [
			0,
			.68333,
			0,
			0,
			.68056
		],
		70: [
			0,
			.68333,
			0,
			0,
			.65278
		],
		71: [
			0,
			.68333,
			0,
			0,
			.78472
		],
		72: [
			0,
			.68333,
			0,
			0,
			.75
		],
		73: [
			0,
			.68333,
			0,
			0,
			.36111
		],
		74: [
			0,
			.68333,
			0,
			0,
			.51389
		],
		75: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		76: [
			0,
			.68333,
			0,
			0,
			.625
		],
		77: [
			0,
			.68333,
			0,
			0,
			.91667
		],
		78: [
			0,
			.68333,
			0,
			0,
			.75
		],
		79: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		80: [
			0,
			.68333,
			0,
			0,
			.68056
		],
		81: [
			.19444,
			.68333,
			0,
			0,
			.77778
		],
		82: [
			0,
			.68333,
			0,
			0,
			.73611
		],
		83: [
			0,
			.68333,
			0,
			0,
			.55556
		],
		84: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		85: [
			0,
			.68333,
			0,
			0,
			.75
		],
		86: [
			0,
			.68333,
			.01389,
			0,
			.75
		],
		87: [
			0,
			.68333,
			.01389,
			0,
			1.02778
		],
		88: [
			0,
			.68333,
			0,
			0,
			.75
		],
		89: [
			0,
			.68333,
			.025,
			0,
			.75
		],
		90: [
			0,
			.68333,
			0,
			0,
			.61111
		],
		91: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		92: [
			.25,
			.75,
			0,
			0,
			.5
		],
		93: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		94: [
			0,
			.69444,
			0,
			0,
			.5
		],
		95: [
			.31,
			.12056,
			.02778,
			0,
			.5
		],
		97: [
			0,
			.43056,
			0,
			0,
			.5
		],
		98: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		99: [
			0,
			.43056,
			0,
			0,
			.44445
		],
		100: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		101: [
			0,
			.43056,
			0,
			0,
			.44445
		],
		102: [
			0,
			.69444,
			.07778,
			0,
			.30556
		],
		103: [
			.19444,
			.43056,
			.01389,
			0,
			.5
		],
		104: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		105: [
			0,
			.66786,
			0,
			0,
			.27778
		],
		106: [
			.19444,
			.66786,
			0,
			0,
			.30556
		],
		107: [
			0,
			.69444,
			0,
			0,
			.52778
		],
		108: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		109: [
			0,
			.43056,
			0,
			0,
			.83334
		],
		110: [
			0,
			.43056,
			0,
			0,
			.55556
		],
		111: [
			0,
			.43056,
			0,
			0,
			.5
		],
		112: [
			.19444,
			.43056,
			0,
			0,
			.55556
		],
		113: [
			.19444,
			.43056,
			0,
			0,
			.52778
		],
		114: [
			0,
			.43056,
			0,
			0,
			.39167
		],
		115: [
			0,
			.43056,
			0,
			0,
			.39445
		],
		116: [
			0,
			.61508,
			0,
			0,
			.38889
		],
		117: [
			0,
			.43056,
			0,
			0,
			.55556
		],
		118: [
			0,
			.43056,
			.01389,
			0,
			.52778
		],
		119: [
			0,
			.43056,
			.01389,
			0,
			.72222
		],
		120: [
			0,
			.43056,
			0,
			0,
			.52778
		],
		121: [
			.19444,
			.43056,
			.01389,
			0,
			.52778
		],
		122: [
			0,
			.43056,
			0,
			0,
			.44445
		],
		123: [
			.25,
			.75,
			0,
			0,
			.5
		],
		124: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		125: [
			.25,
			.75,
			0,
			0,
			.5
		],
		126: [
			.35,
			.31786,
			0,
			0,
			.5
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		163: [
			0,
			.69444,
			0,
			0,
			.76909
		],
		167: [
			.19444,
			.69444,
			0,
			0,
			.44445
		],
		168: [
			0,
			.66786,
			0,
			0,
			.5
		],
		172: [
			0,
			.43056,
			0,
			0,
			.66667
		],
		176: [
			0,
			.69444,
			0,
			0,
			.75
		],
		177: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		182: [
			.19444,
			.69444,
			0,
			0,
			.61111
		],
		184: [
			.17014,
			0,
			0,
			0,
			.44445
		],
		198: [
			0,
			.68333,
			0,
			0,
			.90278
		],
		215: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		216: [
			.04861,
			.73194,
			0,
			0,
			.77778
		],
		223: [
			0,
			.69444,
			0,
			0,
			.5
		],
		230: [
			0,
			.43056,
			0,
			0,
			.72222
		],
		247: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		248: [
			.09722,
			.52778,
			0,
			0,
			.5
		],
		305: [
			0,
			.43056,
			0,
			0,
			.27778
		],
		338: [
			0,
			.68333,
			0,
			0,
			1.01389
		],
		339: [
			0,
			.43056,
			0,
			0,
			.77778
		],
		567: [
			.19444,
			.43056,
			0,
			0,
			.30556
		],
		710: [
			0,
			.69444,
			0,
			0,
			.5
		],
		711: [
			0,
			.62847,
			0,
			0,
			.5
		],
		713: [
			0,
			.56778,
			0,
			0,
			.5
		],
		714: [
			0,
			.69444,
			0,
			0,
			.5
		],
		715: [
			0,
			.69444,
			0,
			0,
			.5
		],
		728: [
			0,
			.69444,
			0,
			0,
			.5
		],
		729: [
			0,
			.66786,
			0,
			0,
			.27778
		],
		730: [
			0,
			.69444,
			0,
			0,
			.75
		],
		732: [
			0,
			.66786,
			0,
			0,
			.5
		],
		733: [
			0,
			.69444,
			0,
			0,
			.5
		],
		915: [
			0,
			.68333,
			0,
			0,
			.625
		],
		916: [
			0,
			.68333,
			0,
			0,
			.83334
		],
		920: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		923: [
			0,
			.68333,
			0,
			0,
			.69445
		],
		926: [
			0,
			.68333,
			0,
			0,
			.66667
		],
		928: [
			0,
			.68333,
			0,
			0,
			.75
		],
		931: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		933: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		934: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		936: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		937: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		8211: [
			0,
			.43056,
			.02778,
			0,
			.5
		],
		8212: [
			0,
			.43056,
			.02778,
			0,
			1
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.5
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.5
		],
		8224: [
			.19444,
			.69444,
			0,
			0,
			.44445
		],
		8225: [
			.19444,
			.69444,
			0,
			0,
			.44445
		],
		8230: [
			0,
			.123,
			0,
			0,
			1.172
		],
		8242: [
			0,
			.55556,
			0,
			0,
			.275
		],
		8407: [
			0,
			.71444,
			.15382,
			0,
			.5
		],
		8463: [
			0,
			.68889,
			0,
			0,
			.54028
		],
		8465: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		8467: [
			0,
			.69444,
			0,
			.11111,
			.41667
		],
		8472: [
			.19444,
			.43056,
			0,
			.11111,
			.63646
		],
		8476: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		8501: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		8592: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8593: [
			.19444,
			.69444,
			0,
			0,
			.5
		],
		8594: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8595: [
			.19444,
			.69444,
			0,
			0,
			.5
		],
		8596: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8597: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8598: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8599: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8600: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8601: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8614: [
			.011,
			.511,
			0,
			0,
			1
		],
		8617: [
			.011,
			.511,
			0,
			0,
			1.126
		],
		8618: [
			.011,
			.511,
			0,
			0,
			1.126
		],
		8636: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8637: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8640: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8641: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8652: [
			.011,
			.671,
			0,
			0,
			1
		],
		8656: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8657: [
			.19444,
			.69444,
			0,
			0,
			.61111
		],
		8658: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8659: [
			.19444,
			.69444,
			0,
			0,
			.61111
		],
		8660: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8661: [
			.25,
			.75,
			0,
			0,
			.61111
		],
		8704: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		8706: [
			0,
			.69444,
			.05556,
			.08334,
			.5309
		],
		8707: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		8709: [
			.05556,
			.75,
			0,
			0,
			.5
		],
		8711: [
			0,
			.68333,
			0,
			0,
			.83334
		],
		8712: [
			.0391,
			.5391,
			0,
			0,
			.66667
		],
		8715: [
			.0391,
			.5391,
			0,
			0,
			.66667
		],
		8722: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8723: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8725: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8726: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8727: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		8728: [
			-.05555,
			.44445,
			0,
			0,
			.5
		],
		8729: [
			-.05555,
			.44445,
			0,
			0,
			.5
		],
		8730: [
			.2,
			.8,
			0,
			0,
			.83334
		],
		8733: [
			0,
			.43056,
			0,
			0,
			.77778
		],
		8734: [
			0,
			.43056,
			0,
			0,
			1
		],
		8736: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8739: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		8741: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8743: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8744: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8745: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8746: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8747: [
			.19444,
			.69444,
			.11111,
			0,
			.41667
		],
		8764: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		8768: [
			.19444,
			.69444,
			0,
			0,
			.27778
		],
		8771: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8773: [
			-.022,
			.589,
			0,
			0,
			.778
		],
		8776: [
			-.01688,
			.48312,
			0,
			0,
			.77778
		],
		8781: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8784: [
			-.133,
			.673,
			0,
			0,
			.778
		],
		8801: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8804: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8805: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8810: [
			.0391,
			.5391,
			0,
			0,
			1
		],
		8811: [
			.0391,
			.5391,
			0,
			0,
			1
		],
		8826: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8827: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8834: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8835: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8838: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8839: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8846: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8849: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8850: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8851: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8852: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8853: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8854: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8855: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8856: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8857: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8866: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		8867: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		8868: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		8869: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		8872: [
			.249,
			.75,
			0,
			0,
			.867
		],
		8900: [
			-.05555,
			.44445,
			0,
			0,
			.5
		],
		8901: [
			-.05555,
			.44445,
			0,
			0,
			.27778
		],
		8902: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		8904: [
			.005,
			.505,
			0,
			0,
			.9
		],
		8942: [
			.03,
			.903,
			0,
			0,
			.278
		],
		8943: [
			-.19,
			.313,
			0,
			0,
			1.172
		],
		8945: [
			-.1,
			.823,
			0,
			0,
			1.282
		],
		8968: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8969: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8970: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8971: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8994: [
			-.14236,
			.35764,
			0,
			0,
			1
		],
		8995: [
			-.14236,
			.35764,
			0,
			0,
			1
		],
		9136: [
			.244,
			.744,
			0,
			0,
			.412
		],
		9137: [
			.244,
			.745,
			0,
			0,
			.412
		],
		9651: [
			.19444,
			.69444,
			0,
			0,
			.88889
		],
		9657: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		9661: [
			.19444,
			.69444,
			0,
			0,
			.88889
		],
		9667: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		9711: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		9824: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9825: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9826: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9827: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9837: [
			0,
			.75,
			0,
			0,
			.38889
		],
		9838: [
			.19444,
			.69444,
			0,
			0,
			.38889
		],
		9839: [
			.19444,
			.69444,
			0,
			0,
			.38889
		],
		10216: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		10217: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		10222: [
			.244,
			.744,
			0,
			0,
			.412
		],
		10223: [
			.244,
			.745,
			0,
			0,
			.412
		],
		10229: [
			.011,
			.511,
			0,
			0,
			1.609
		],
		10230: [
			.011,
			.511,
			0,
			0,
			1.638
		],
		10231: [
			.011,
			.511,
			0,
			0,
			1.859
		],
		10232: [
			.024,
			.525,
			0,
			0,
			1.609
		],
		10233: [
			.024,
			.525,
			0,
			0,
			1.638
		],
		10234: [
			.024,
			.525,
			0,
			0,
			1.858
		],
		10236: [
			.011,
			.511,
			0,
			0,
			1.638
		],
		10815: [
			0,
			.68333,
			0,
			0,
			.75
		],
		10927: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		10928: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		57376: [
			.19444,
			.69444,
			0,
			0,
			0
		]
	},
	"Math-BoldItalic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		48: [
			0,
			.44444,
			0,
			0,
			.575
		],
		49: [
			0,
			.44444,
			0,
			0,
			.575
		],
		50: [
			0,
			.44444,
			0,
			0,
			.575
		],
		51: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		52: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		53: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		54: [
			0,
			.64444,
			0,
			0,
			.575
		],
		55: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		56: [
			0,
			.64444,
			0,
			0,
			.575
		],
		57: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		65: [
			0,
			.68611,
			0,
			0,
			.86944
		],
		66: [
			0,
			.68611,
			.04835,
			0,
			.8664
		],
		67: [
			0,
			.68611,
			.06979,
			0,
			.81694
		],
		68: [
			0,
			.68611,
			.03194,
			0,
			.93812
		],
		69: [
			0,
			.68611,
			.05451,
			0,
			.81007
		],
		70: [
			0,
			.68611,
			.15972,
			0,
			.68889
		],
		71: [
			0,
			.68611,
			0,
			0,
			.88673
		],
		72: [
			0,
			.68611,
			.08229,
			0,
			.98229
		],
		73: [
			0,
			.68611,
			.07778,
			0,
			.51111
		],
		74: [
			0,
			.68611,
			.10069,
			0,
			.63125
		],
		75: [
			0,
			.68611,
			.06979,
			0,
			.97118
		],
		76: [
			0,
			.68611,
			0,
			0,
			.75555
		],
		77: [
			0,
			.68611,
			.11424,
			0,
			1.14201
		],
		78: [
			0,
			.68611,
			.11424,
			0,
			.95034
		],
		79: [
			0,
			.68611,
			.03194,
			0,
			.83666
		],
		80: [
			0,
			.68611,
			.15972,
			0,
			.72309
		],
		81: [
			.19444,
			.68611,
			0,
			0,
			.86861
		],
		82: [
			0,
			.68611,
			.00421,
			0,
			.87235
		],
		83: [
			0,
			.68611,
			.05382,
			0,
			.69271
		],
		84: [
			0,
			.68611,
			.15972,
			0,
			.63663
		],
		85: [
			0,
			.68611,
			.11424,
			0,
			.80027
		],
		86: [
			0,
			.68611,
			.25555,
			0,
			.67778
		],
		87: [
			0,
			.68611,
			.15972,
			0,
			1.09305
		],
		88: [
			0,
			.68611,
			.07778,
			0,
			.94722
		],
		89: [
			0,
			.68611,
			.25555,
			0,
			.67458
		],
		90: [
			0,
			.68611,
			.06979,
			0,
			.77257
		],
		97: [
			0,
			.44444,
			0,
			0,
			.63287
		],
		98: [
			0,
			.69444,
			0,
			0,
			.52083
		],
		99: [
			0,
			.44444,
			0,
			0,
			.51342
		],
		100: [
			0,
			.69444,
			0,
			0,
			.60972
		],
		101: [
			0,
			.44444,
			0,
			0,
			.55361
		],
		102: [
			.19444,
			.69444,
			.11042,
			0,
			.56806
		],
		103: [
			.19444,
			.44444,
			.03704,
			0,
			.5449
		],
		104: [
			0,
			.69444,
			0,
			0,
			.66759
		],
		105: [
			0,
			.69326,
			0,
			0,
			.4048
		],
		106: [
			.19444,
			.69326,
			.0622,
			0,
			.47083
		],
		107: [
			0,
			.69444,
			.01852,
			0,
			.6037
		],
		108: [
			0,
			.69444,
			.0088,
			0,
			.34815
		],
		109: [
			0,
			.44444,
			0,
			0,
			1.0324
		],
		110: [
			0,
			.44444,
			0,
			0,
			.71296
		],
		111: [
			0,
			.44444,
			0,
			0,
			.58472
		],
		112: [
			.19444,
			.44444,
			0,
			0,
			.60092
		],
		113: [
			.19444,
			.44444,
			.03704,
			0,
			.54213
		],
		114: [
			0,
			.44444,
			.03194,
			0,
			.5287
		],
		115: [
			0,
			.44444,
			0,
			0,
			.53125
		],
		116: [
			0,
			.63492,
			0,
			0,
			.41528
		],
		117: [
			0,
			.44444,
			0,
			0,
			.68102
		],
		118: [
			0,
			.44444,
			.03704,
			0,
			.56666
		],
		119: [
			0,
			.44444,
			.02778,
			0,
			.83148
		],
		120: [
			0,
			.44444,
			0,
			0,
			.65903
		],
		121: [
			.19444,
			.44444,
			.03704,
			0,
			.59028
		],
		122: [
			0,
			.44444,
			.04213,
			0,
			.55509
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		915: [
			0,
			.68611,
			.15972,
			0,
			.65694
		],
		916: [
			0,
			.68611,
			0,
			0,
			.95833
		],
		920: [
			0,
			.68611,
			.03194,
			0,
			.86722
		],
		923: [
			0,
			.68611,
			0,
			0,
			.80555
		],
		926: [
			0,
			.68611,
			.07458,
			0,
			.84125
		],
		928: [
			0,
			.68611,
			.08229,
			0,
			.98229
		],
		931: [
			0,
			.68611,
			.05451,
			0,
			.88507
		],
		933: [
			0,
			.68611,
			.15972,
			0,
			.67083
		],
		934: [
			0,
			.68611,
			0,
			0,
			.76666
		],
		936: [
			0,
			.68611,
			.11653,
			0,
			.71402
		],
		937: [
			0,
			.68611,
			.04835,
			0,
			.8789
		],
		945: [
			0,
			.44444,
			0,
			0,
			.76064
		],
		946: [
			.19444,
			.69444,
			.03403,
			0,
			.65972
		],
		947: [
			.19444,
			.44444,
			.06389,
			0,
			.59003
		],
		948: [
			0,
			.69444,
			.03819,
			0,
			.52222
		],
		949: [
			0,
			.44444,
			0,
			0,
			.52882
		],
		950: [
			.19444,
			.69444,
			.06215,
			0,
			.50833
		],
		951: [
			.19444,
			.44444,
			.03704,
			0,
			.6
		],
		952: [
			0,
			.69444,
			.03194,
			0,
			.5618
		],
		953: [
			0,
			.44444,
			0,
			0,
			.41204
		],
		954: [
			0,
			.44444,
			0,
			0,
			.66759
		],
		955: [
			0,
			.69444,
			0,
			0,
			.67083
		],
		956: [
			.19444,
			.44444,
			0,
			0,
			.70787
		],
		957: [
			0,
			.44444,
			.06898,
			0,
			.57685
		],
		958: [
			.19444,
			.69444,
			.03021,
			0,
			.50833
		],
		959: [
			0,
			.44444,
			0,
			0,
			.58472
		],
		960: [
			0,
			.44444,
			.03704,
			0,
			.68241
		],
		961: [
			.19444,
			.44444,
			0,
			0,
			.6118
		],
		962: [
			.09722,
			.44444,
			.07917,
			0,
			.42361
		],
		963: [
			0,
			.44444,
			.03704,
			0,
			.68588
		],
		964: [
			0,
			.44444,
			.13472,
			0,
			.52083
		],
		965: [
			0,
			.44444,
			.03704,
			0,
			.63055
		],
		966: [
			.19444,
			.44444,
			0,
			0,
			.74722
		],
		967: [
			.19444,
			.44444,
			0,
			0,
			.71805
		],
		968: [
			.19444,
			.69444,
			.03704,
			0,
			.75833
		],
		969: [
			0,
			.44444,
			.03704,
			0,
			.71782
		],
		977: [
			0,
			.69444,
			0,
			0,
			.69155
		],
		981: [
			.19444,
			.69444,
			0,
			0,
			.7125
		],
		982: [
			0,
			.44444,
			.03194,
			0,
			.975
		],
		1009: [
			.19444,
			.44444,
			0,
			0,
			.6118
		],
		1013: [
			0,
			.44444,
			0,
			0,
			.48333
		],
		57649: [
			0,
			.44444,
			0,
			0,
			.39352
		],
		57911: [
			.19444,
			.44444,
			0,
			0,
			.43889
		]
	},
	"Math-Italic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		48: [
			0,
			.43056,
			0,
			0,
			.5
		],
		49: [
			0,
			.43056,
			0,
			0,
			.5
		],
		50: [
			0,
			.43056,
			0,
			0,
			.5
		],
		51: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		52: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		53: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		54: [
			0,
			.64444,
			0,
			0,
			.5
		],
		55: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		56: [
			0,
			.64444,
			0,
			0,
			.5
		],
		57: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		65: [
			0,
			.68333,
			0,
			.13889,
			.75
		],
		66: [
			0,
			.68333,
			.05017,
			.08334,
			.75851
		],
		67: [
			0,
			.68333,
			.07153,
			.08334,
			.71472
		],
		68: [
			0,
			.68333,
			.02778,
			.05556,
			.82792
		],
		69: [
			0,
			.68333,
			.05764,
			.08334,
			.7382
		],
		70: [
			0,
			.68333,
			.13889,
			.08334,
			.64306
		],
		71: [
			0,
			.68333,
			0,
			.08334,
			.78625
		],
		72: [
			0,
			.68333,
			.08125,
			.05556,
			.83125
		],
		73: [
			0,
			.68333,
			.07847,
			.11111,
			.43958
		],
		74: [
			0,
			.68333,
			.09618,
			.16667,
			.55451
		],
		75: [
			0,
			.68333,
			.07153,
			.05556,
			.84931
		],
		76: [
			0,
			.68333,
			0,
			.02778,
			.68056
		],
		77: [
			0,
			.68333,
			.10903,
			.08334,
			.97014
		],
		78: [
			0,
			.68333,
			.10903,
			.08334,
			.80347
		],
		79: [
			0,
			.68333,
			.02778,
			.08334,
			.76278
		],
		80: [
			0,
			.68333,
			.13889,
			.08334,
			.64201
		],
		81: [
			.19444,
			.68333,
			0,
			.08334,
			.79056
		],
		82: [
			0,
			.68333,
			.00773,
			.08334,
			.75929
		],
		83: [
			0,
			.68333,
			.05764,
			.08334,
			.6132
		],
		84: [
			0,
			.68333,
			.13889,
			.08334,
			.58438
		],
		85: [
			0,
			.68333,
			.10903,
			.02778,
			.68278
		],
		86: [
			0,
			.68333,
			.22222,
			0,
			.58333
		],
		87: [
			0,
			.68333,
			.13889,
			0,
			.94445
		],
		88: [
			0,
			.68333,
			.07847,
			.08334,
			.82847
		],
		89: [
			0,
			.68333,
			.22222,
			0,
			.58056
		],
		90: [
			0,
			.68333,
			.07153,
			.08334,
			.68264
		],
		97: [
			0,
			.43056,
			0,
			0,
			.52859
		],
		98: [
			0,
			.69444,
			0,
			0,
			.42917
		],
		99: [
			0,
			.43056,
			0,
			.05556,
			.43276
		],
		100: [
			0,
			.69444,
			0,
			.16667,
			.52049
		],
		101: [
			0,
			.43056,
			0,
			.05556,
			.46563
		],
		102: [
			.19444,
			.69444,
			.10764,
			.16667,
			.48959
		],
		103: [
			.19444,
			.43056,
			.03588,
			.02778,
			.47697
		],
		104: [
			0,
			.69444,
			0,
			0,
			.57616
		],
		105: [
			0,
			.65952,
			0,
			0,
			.34451
		],
		106: [
			.19444,
			.65952,
			.05724,
			0,
			.41181
		],
		107: [
			0,
			.69444,
			.03148,
			0,
			.5206
		],
		108: [
			0,
			.69444,
			.01968,
			.08334,
			.29838
		],
		109: [
			0,
			.43056,
			0,
			0,
			.87801
		],
		110: [
			0,
			.43056,
			0,
			0,
			.60023
		],
		111: [
			0,
			.43056,
			0,
			.05556,
			.48472
		],
		112: [
			.19444,
			.43056,
			0,
			.08334,
			.50313
		],
		113: [
			.19444,
			.43056,
			.03588,
			.08334,
			.44641
		],
		114: [
			0,
			.43056,
			.02778,
			.05556,
			.45116
		],
		115: [
			0,
			.43056,
			0,
			.05556,
			.46875
		],
		116: [
			0,
			.61508,
			0,
			.08334,
			.36111
		],
		117: [
			0,
			.43056,
			0,
			.02778,
			.57246
		],
		118: [
			0,
			.43056,
			.03588,
			.02778,
			.48472
		],
		119: [
			0,
			.43056,
			.02691,
			.08334,
			.71592
		],
		120: [
			0,
			.43056,
			0,
			.02778,
			.57153
		],
		121: [
			.19444,
			.43056,
			.03588,
			.05556,
			.49028
		],
		122: [
			0,
			.43056,
			.04398,
			.05556,
			.46505
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		915: [
			0,
			.68333,
			.13889,
			.08334,
			.61528
		],
		916: [
			0,
			.68333,
			0,
			.16667,
			.83334
		],
		920: [
			0,
			.68333,
			.02778,
			.08334,
			.76278
		],
		923: [
			0,
			.68333,
			0,
			.16667,
			.69445
		],
		926: [
			0,
			.68333,
			.07569,
			.08334,
			.74236
		],
		928: [
			0,
			.68333,
			.08125,
			.05556,
			.83125
		],
		931: [
			0,
			.68333,
			.05764,
			.08334,
			.77986
		],
		933: [
			0,
			.68333,
			.13889,
			.05556,
			.58333
		],
		934: [
			0,
			.68333,
			0,
			.08334,
			.66667
		],
		936: [
			0,
			.68333,
			.11,
			.05556,
			.61222
		],
		937: [
			0,
			.68333,
			.05017,
			.08334,
			.7724
		],
		945: [
			0,
			.43056,
			.0037,
			.02778,
			.6397
		],
		946: [
			.19444,
			.69444,
			.05278,
			.08334,
			.56563
		],
		947: [
			.19444,
			.43056,
			.05556,
			0,
			.51773
		],
		948: [
			0,
			.69444,
			.03785,
			.05556,
			.44444
		],
		949: [
			0,
			.43056,
			0,
			.08334,
			.46632
		],
		950: [
			.19444,
			.69444,
			.07378,
			.08334,
			.4375
		],
		951: [
			.19444,
			.43056,
			.03588,
			.05556,
			.49653
		],
		952: [
			0,
			.69444,
			.02778,
			.08334,
			.46944
		],
		953: [
			0,
			.43056,
			0,
			.05556,
			.35394
		],
		954: [
			0,
			.43056,
			0,
			0,
			.57616
		],
		955: [
			0,
			.69444,
			0,
			0,
			.58334
		],
		956: [
			.19444,
			.43056,
			0,
			.02778,
			.60255
		],
		957: [
			0,
			.43056,
			.06366,
			.02778,
			.49398
		],
		958: [
			.19444,
			.69444,
			.04601,
			.11111,
			.4375
		],
		959: [
			0,
			.43056,
			0,
			.05556,
			.48472
		],
		960: [
			0,
			.43056,
			.03588,
			0,
			.57003
		],
		961: [
			.19444,
			.43056,
			0,
			.08334,
			.51702
		],
		962: [
			.09722,
			.43056,
			.07986,
			.08334,
			.36285
		],
		963: [
			0,
			.43056,
			.03588,
			0,
			.57141
		],
		964: [
			0,
			.43056,
			.1132,
			.02778,
			.43715
		],
		965: [
			0,
			.43056,
			.03588,
			.02778,
			.54028
		],
		966: [
			.19444,
			.43056,
			0,
			.08334,
			.65417
		],
		967: [
			.19444,
			.43056,
			0,
			.05556,
			.62569
		],
		968: [
			.19444,
			.69444,
			.03588,
			.11111,
			.65139
		],
		969: [
			0,
			.43056,
			.03588,
			0,
			.62245
		],
		977: [
			0,
			.69444,
			0,
			.08334,
			.59144
		],
		981: [
			.19444,
			.69444,
			0,
			.08334,
			.59583
		],
		982: [
			0,
			.43056,
			.02778,
			0,
			.82813
		],
		1009: [
			.19444,
			.43056,
			0,
			.08334,
			.51702
		],
		1013: [
			0,
			.43056,
			0,
			.05556,
			.4059
		],
		57649: [
			0,
			.43056,
			0,
			.02778,
			.32246
		],
		57911: [
			.19444,
			.43056,
			0,
			.08334,
			.38403
		]
	},
	"SansSerif-Bold": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.36667
		],
		34: [
			0,
			.69444,
			0,
			0,
			.55834
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.91667
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.55
		],
		37: [
			.05556,
			.75,
			0,
			0,
			1.02912
		],
		38: [
			0,
			.69444,
			0,
			0,
			.83056
		],
		39: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		40: [
			.25,
			.75,
			0,
			0,
			.42778
		],
		41: [
			.25,
			.75,
			0,
			0,
			.42778
		],
		42: [
			0,
			.75,
			0,
			0,
			.55
		],
		43: [
			.11667,
			.61667,
			0,
			0,
			.85556
		],
		44: [
			.10556,
			.13056,
			0,
			0,
			.30556
		],
		45: [
			0,
			.45833,
			0,
			0,
			.36667
		],
		46: [
			0,
			.13056,
			0,
			0,
			.30556
		],
		47: [
			.25,
			.75,
			0,
			0,
			.55
		],
		48: [
			0,
			.69444,
			0,
			0,
			.55
		],
		49: [
			0,
			.69444,
			0,
			0,
			.55
		],
		50: [
			0,
			.69444,
			0,
			0,
			.55
		],
		51: [
			0,
			.69444,
			0,
			0,
			.55
		],
		52: [
			0,
			.69444,
			0,
			0,
			.55
		],
		53: [
			0,
			.69444,
			0,
			0,
			.55
		],
		54: [
			0,
			.69444,
			0,
			0,
			.55
		],
		55: [
			0,
			.69444,
			0,
			0,
			.55
		],
		56: [
			0,
			.69444,
			0,
			0,
			.55
		],
		57: [
			0,
			.69444,
			0,
			0,
			.55
		],
		58: [
			0,
			.45833,
			0,
			0,
			.30556
		],
		59: [
			.10556,
			.45833,
			0,
			0,
			.30556
		],
		61: [
			-.09375,
			.40625,
			0,
			0,
			.85556
		],
		63: [
			0,
			.69444,
			0,
			0,
			.51945
		],
		64: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		65: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		66: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		67: [
			0,
			.69444,
			0,
			0,
			.70278
		],
		68: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		69: [
			0,
			.69444,
			0,
			0,
			.64167
		],
		70: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		71: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		72: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		73: [
			0,
			.69444,
			0,
			0,
			.33056
		],
		74: [
			0,
			.69444,
			0,
			0,
			.51945
		],
		75: [
			0,
			.69444,
			0,
			0,
			.76389
		],
		76: [
			0,
			.69444,
			0,
			0,
			.58056
		],
		77: [
			0,
			.69444,
			0,
			0,
			.97778
		],
		78: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		79: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		80: [
			0,
			.69444,
			0,
			0,
			.70278
		],
		81: [
			.10556,
			.69444,
			0,
			0,
			.79445
		],
		82: [
			0,
			.69444,
			0,
			0,
			.70278
		],
		83: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		84: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		85: [
			0,
			.69444,
			0,
			0,
			.76389
		],
		86: [
			0,
			.69444,
			.01528,
			0,
			.73334
		],
		87: [
			0,
			.69444,
			.01528,
			0,
			1.03889
		],
		88: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		89: [
			0,
			.69444,
			.0275,
			0,
			.73334
		],
		90: [
			0,
			.69444,
			0,
			0,
			.67223
		],
		91: [
			.25,
			.75,
			0,
			0,
			.34306
		],
		93: [
			.25,
			.75,
			0,
			0,
			.34306
		],
		94: [
			0,
			.69444,
			0,
			0,
			.55
		],
		95: [
			.35,
			.10833,
			.03056,
			0,
			.55
		],
		97: [
			0,
			.45833,
			0,
			0,
			.525
		],
		98: [
			0,
			.69444,
			0,
			0,
			.56111
		],
		99: [
			0,
			.45833,
			0,
			0,
			.48889
		],
		100: [
			0,
			.69444,
			0,
			0,
			.56111
		],
		101: [
			0,
			.45833,
			0,
			0,
			.51111
		],
		102: [
			0,
			.69444,
			.07639,
			0,
			.33611
		],
		103: [
			.19444,
			.45833,
			.01528,
			0,
			.55
		],
		104: [
			0,
			.69444,
			0,
			0,
			.56111
		],
		105: [
			0,
			.69444,
			0,
			0,
			.25556
		],
		106: [
			.19444,
			.69444,
			0,
			0,
			.28611
		],
		107: [
			0,
			.69444,
			0,
			0,
			.53056
		],
		108: [
			0,
			.69444,
			0,
			0,
			.25556
		],
		109: [
			0,
			.45833,
			0,
			0,
			.86667
		],
		110: [
			0,
			.45833,
			0,
			0,
			.56111
		],
		111: [
			0,
			.45833,
			0,
			0,
			.55
		],
		112: [
			.19444,
			.45833,
			0,
			0,
			.56111
		],
		113: [
			.19444,
			.45833,
			0,
			0,
			.56111
		],
		114: [
			0,
			.45833,
			.01528,
			0,
			.37222
		],
		115: [
			0,
			.45833,
			0,
			0,
			.42167
		],
		116: [
			0,
			.58929,
			0,
			0,
			.40417
		],
		117: [
			0,
			.45833,
			0,
			0,
			.56111
		],
		118: [
			0,
			.45833,
			.01528,
			0,
			.5
		],
		119: [
			0,
			.45833,
			.01528,
			0,
			.74445
		],
		120: [
			0,
			.45833,
			0,
			0,
			.5
		],
		121: [
			.19444,
			.45833,
			.01528,
			0,
			.5
		],
		122: [
			0,
			.45833,
			0,
			0,
			.47639
		],
		126: [
			.35,
			.34444,
			0,
			0,
			.55
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.69444,
			0,
			0,
			.55
		],
		176: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		180: [
			0,
			.69444,
			0,
			0,
			.55
		],
		184: [
			.17014,
			0,
			0,
			0,
			.48889
		],
		305: [
			0,
			.45833,
			0,
			0,
			.25556
		],
		567: [
			.19444,
			.45833,
			0,
			0,
			.28611
		],
		710: [
			0,
			.69444,
			0,
			0,
			.55
		],
		711: [
			0,
			.63542,
			0,
			0,
			.55
		],
		713: [
			0,
			.63778,
			0,
			0,
			.55
		],
		728: [
			0,
			.69444,
			0,
			0,
			.55
		],
		729: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		730: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		732: [
			0,
			.69444,
			0,
			0,
			.55
		],
		733: [
			0,
			.69444,
			0,
			0,
			.55
		],
		915: [
			0,
			.69444,
			0,
			0,
			.58056
		],
		916: [
			0,
			.69444,
			0,
			0,
			.91667
		],
		920: [
			0,
			.69444,
			0,
			0,
			.85556
		],
		923: [
			0,
			.69444,
			0,
			0,
			.67223
		],
		926: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		928: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		931: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		933: [
			0,
			.69444,
			0,
			0,
			.85556
		],
		934: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		936: [
			0,
			.69444,
			0,
			0,
			.85556
		],
		937: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		8211: [
			0,
			.45833,
			.03056,
			0,
			.55
		],
		8212: [
			0,
			.45833,
			.03056,
			0,
			1.10001
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.55834
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.55834
		]
	},
	"SansSerif-Italic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			.05733,
			0,
			.31945
		],
		34: [
			0,
			.69444,
			.00316,
			0,
			.5
		],
		35: [
			.19444,
			.69444,
			.05087,
			0,
			.83334
		],
		36: [
			.05556,
			.75,
			.11156,
			0,
			.5
		],
		37: [
			.05556,
			.75,
			.03126,
			0,
			.83334
		],
		38: [
			0,
			.69444,
			.03058,
			0,
			.75834
		],
		39: [
			0,
			.69444,
			.07816,
			0,
			.27778
		],
		40: [
			.25,
			.75,
			.13164,
			0,
			.38889
		],
		41: [
			.25,
			.75,
			.02536,
			0,
			.38889
		],
		42: [
			0,
			.75,
			.11775,
			0,
			.5
		],
		43: [
			.08333,
			.58333,
			.02536,
			0,
			.77778
		],
		44: [
			.125,
			.08333,
			0,
			0,
			.27778
		],
		45: [
			0,
			.44444,
			.01946,
			0,
			.33333
		],
		46: [
			0,
			.08333,
			0,
			0,
			.27778
		],
		47: [
			.25,
			.75,
			.13164,
			0,
			.5
		],
		48: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		49: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		50: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		51: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		52: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		53: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		54: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		55: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		56: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		57: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		58: [
			0,
			.44444,
			.02502,
			0,
			.27778
		],
		59: [
			.125,
			.44444,
			.02502,
			0,
			.27778
		],
		61: [
			-.13,
			.37,
			.05087,
			0,
			.77778
		],
		63: [
			0,
			.69444,
			.11809,
			0,
			.47222
		],
		64: [
			0,
			.69444,
			.07555,
			0,
			.66667
		],
		65: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		66: [
			0,
			.69444,
			.08293,
			0,
			.66667
		],
		67: [
			0,
			.69444,
			.11983,
			0,
			.63889
		],
		68: [
			0,
			.69444,
			.07555,
			0,
			.72223
		],
		69: [
			0,
			.69444,
			.11983,
			0,
			.59722
		],
		70: [
			0,
			.69444,
			.13372,
			0,
			.56945
		],
		71: [
			0,
			.69444,
			.11983,
			0,
			.66667
		],
		72: [
			0,
			.69444,
			.08094,
			0,
			.70834
		],
		73: [
			0,
			.69444,
			.13372,
			0,
			.27778
		],
		74: [
			0,
			.69444,
			.08094,
			0,
			.47222
		],
		75: [
			0,
			.69444,
			.11983,
			0,
			.69445
		],
		76: [
			0,
			.69444,
			0,
			0,
			.54167
		],
		77: [
			0,
			.69444,
			.08094,
			0,
			.875
		],
		78: [
			0,
			.69444,
			.08094,
			0,
			.70834
		],
		79: [
			0,
			.69444,
			.07555,
			0,
			.73611
		],
		80: [
			0,
			.69444,
			.08293,
			0,
			.63889
		],
		81: [
			.125,
			.69444,
			.07555,
			0,
			.73611
		],
		82: [
			0,
			.69444,
			.08293,
			0,
			.64584
		],
		83: [
			0,
			.69444,
			.09205,
			0,
			.55556
		],
		84: [
			0,
			.69444,
			.13372,
			0,
			.68056
		],
		85: [
			0,
			.69444,
			.08094,
			0,
			.6875
		],
		86: [
			0,
			.69444,
			.1615,
			0,
			.66667
		],
		87: [
			0,
			.69444,
			.1615,
			0,
			.94445
		],
		88: [
			0,
			.69444,
			.13372,
			0,
			.66667
		],
		89: [
			0,
			.69444,
			.17261,
			0,
			.66667
		],
		90: [
			0,
			.69444,
			.11983,
			0,
			.61111
		],
		91: [
			.25,
			.75,
			.15942,
			0,
			.28889
		],
		93: [
			.25,
			.75,
			.08719,
			0,
			.28889
		],
		94: [
			0,
			.69444,
			.0799,
			0,
			.5
		],
		95: [
			.35,
			.09444,
			.08616,
			0,
			.5
		],
		97: [
			0,
			.44444,
			.00981,
			0,
			.48056
		],
		98: [
			0,
			.69444,
			.03057,
			0,
			.51667
		],
		99: [
			0,
			.44444,
			.08336,
			0,
			.44445
		],
		100: [
			0,
			.69444,
			.09483,
			0,
			.51667
		],
		101: [
			0,
			.44444,
			.06778,
			0,
			.44445
		],
		102: [
			0,
			.69444,
			.21705,
			0,
			.30556
		],
		103: [
			.19444,
			.44444,
			.10836,
			0,
			.5
		],
		104: [
			0,
			.69444,
			.01778,
			0,
			.51667
		],
		105: [
			0,
			.67937,
			.09718,
			0,
			.23889
		],
		106: [
			.19444,
			.67937,
			.09162,
			0,
			.26667
		],
		107: [
			0,
			.69444,
			.08336,
			0,
			.48889
		],
		108: [
			0,
			.69444,
			.09483,
			0,
			.23889
		],
		109: [
			0,
			.44444,
			.01778,
			0,
			.79445
		],
		110: [
			0,
			.44444,
			.01778,
			0,
			.51667
		],
		111: [
			0,
			.44444,
			.06613,
			0,
			.5
		],
		112: [
			.19444,
			.44444,
			.0389,
			0,
			.51667
		],
		113: [
			.19444,
			.44444,
			.04169,
			0,
			.51667
		],
		114: [
			0,
			.44444,
			.10836,
			0,
			.34167
		],
		115: [
			0,
			.44444,
			.0778,
			0,
			.38333
		],
		116: [
			0,
			.57143,
			.07225,
			0,
			.36111
		],
		117: [
			0,
			.44444,
			.04169,
			0,
			.51667
		],
		118: [
			0,
			.44444,
			.10836,
			0,
			.46111
		],
		119: [
			0,
			.44444,
			.10836,
			0,
			.68334
		],
		120: [
			0,
			.44444,
			.09169,
			0,
			.46111
		],
		121: [
			.19444,
			.44444,
			.10836,
			0,
			.46111
		],
		122: [
			0,
			.44444,
			.08752,
			0,
			.43472
		],
		126: [
			.35,
			.32659,
			.08826,
			0,
			.5
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.67937,
			.06385,
			0,
			.5
		],
		176: [
			0,
			.69444,
			0,
			0,
			.73752
		],
		184: [
			.17014,
			0,
			0,
			0,
			.44445
		],
		305: [
			0,
			.44444,
			.04169,
			0,
			.23889
		],
		567: [
			.19444,
			.44444,
			.04169,
			0,
			.26667
		],
		710: [
			0,
			.69444,
			.0799,
			0,
			.5
		],
		711: [
			0,
			.63194,
			.08432,
			0,
			.5
		],
		713: [
			0,
			.60889,
			.08776,
			0,
			.5
		],
		714: [
			0,
			.69444,
			.09205,
			0,
			.5
		],
		715: [
			0,
			.69444,
			0,
			0,
			.5
		],
		728: [
			0,
			.69444,
			.09483,
			0,
			.5
		],
		729: [
			0,
			.67937,
			.07774,
			0,
			.27778
		],
		730: [
			0,
			.69444,
			0,
			0,
			.73752
		],
		732: [
			0,
			.67659,
			.08826,
			0,
			.5
		],
		733: [
			0,
			.69444,
			.09205,
			0,
			.5
		],
		915: [
			0,
			.69444,
			.13372,
			0,
			.54167
		],
		916: [
			0,
			.69444,
			0,
			0,
			.83334
		],
		920: [
			0,
			.69444,
			.07555,
			0,
			.77778
		],
		923: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		926: [
			0,
			.69444,
			.12816,
			0,
			.66667
		],
		928: [
			0,
			.69444,
			.08094,
			0,
			.70834
		],
		931: [
			0,
			.69444,
			.11983,
			0,
			.72222
		],
		933: [
			0,
			.69444,
			.09031,
			0,
			.77778
		],
		934: [
			0,
			.69444,
			.04603,
			0,
			.72222
		],
		936: [
			0,
			.69444,
			.09031,
			0,
			.77778
		],
		937: [
			0,
			.69444,
			.08293,
			0,
			.72222
		],
		8211: [
			0,
			.44444,
			.08616,
			0,
			.5
		],
		8212: [
			0,
			.44444,
			.08616,
			0,
			1
		],
		8216: [
			0,
			.69444,
			.07816,
			0,
			.27778
		],
		8217: [
			0,
			.69444,
			.07816,
			0,
			.27778
		],
		8220: [
			0,
			.69444,
			.14205,
			0,
			.5
		],
		8221: [
			0,
			.69444,
			.00316,
			0,
			.5
		]
	},
	"SansSerif-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.31945
		],
		34: [
			0,
			.69444,
			0,
			0,
			.5
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.83334
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.5
		],
		37: [
			.05556,
			.75,
			0,
			0,
			.83334
		],
		38: [
			0,
			.69444,
			0,
			0,
			.75834
		],
		39: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		40: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		41: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		42: [
			0,
			.75,
			0,
			0,
			.5
		],
		43: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		44: [
			.125,
			.08333,
			0,
			0,
			.27778
		],
		45: [
			0,
			.44444,
			0,
			0,
			.33333
		],
		46: [
			0,
			.08333,
			0,
			0,
			.27778
		],
		47: [
			.25,
			.75,
			0,
			0,
			.5
		],
		48: [
			0,
			.65556,
			0,
			0,
			.5
		],
		49: [
			0,
			.65556,
			0,
			0,
			.5
		],
		50: [
			0,
			.65556,
			0,
			0,
			.5
		],
		51: [
			0,
			.65556,
			0,
			0,
			.5
		],
		52: [
			0,
			.65556,
			0,
			0,
			.5
		],
		53: [
			0,
			.65556,
			0,
			0,
			.5
		],
		54: [
			0,
			.65556,
			0,
			0,
			.5
		],
		55: [
			0,
			.65556,
			0,
			0,
			.5
		],
		56: [
			0,
			.65556,
			0,
			0,
			.5
		],
		57: [
			0,
			.65556,
			0,
			0,
			.5
		],
		58: [
			0,
			.44444,
			0,
			0,
			.27778
		],
		59: [
			.125,
			.44444,
			0,
			0,
			.27778
		],
		61: [
			-.13,
			.37,
			0,
			0,
			.77778
		],
		63: [
			0,
			.69444,
			0,
			0,
			.47222
		],
		64: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		65: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		66: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		67: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		68: [
			0,
			.69444,
			0,
			0,
			.72223
		],
		69: [
			0,
			.69444,
			0,
			0,
			.59722
		],
		70: [
			0,
			.69444,
			0,
			0,
			.56945
		],
		71: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		72: [
			0,
			.69444,
			0,
			0,
			.70834
		],
		73: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		74: [
			0,
			.69444,
			0,
			0,
			.47222
		],
		75: [
			0,
			.69444,
			0,
			0,
			.69445
		],
		76: [
			0,
			.69444,
			0,
			0,
			.54167
		],
		77: [
			0,
			.69444,
			0,
			0,
			.875
		],
		78: [
			0,
			.69444,
			0,
			0,
			.70834
		],
		79: [
			0,
			.69444,
			0,
			0,
			.73611
		],
		80: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		81: [
			.125,
			.69444,
			0,
			0,
			.73611
		],
		82: [
			0,
			.69444,
			0,
			0,
			.64584
		],
		83: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		84: [
			0,
			.69444,
			0,
			0,
			.68056
		],
		85: [
			0,
			.69444,
			0,
			0,
			.6875
		],
		86: [
			0,
			.69444,
			.01389,
			0,
			.66667
		],
		87: [
			0,
			.69444,
			.01389,
			0,
			.94445
		],
		88: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		89: [
			0,
			.69444,
			.025,
			0,
			.66667
		],
		90: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		91: [
			.25,
			.75,
			0,
			0,
			.28889
		],
		93: [
			.25,
			.75,
			0,
			0,
			.28889
		],
		94: [
			0,
			.69444,
			0,
			0,
			.5
		],
		95: [
			.35,
			.09444,
			.02778,
			0,
			.5
		],
		97: [
			0,
			.44444,
			0,
			0,
			.48056
		],
		98: [
			0,
			.69444,
			0,
			0,
			.51667
		],
		99: [
			0,
			.44444,
			0,
			0,
			.44445
		],
		100: [
			0,
			.69444,
			0,
			0,
			.51667
		],
		101: [
			0,
			.44444,
			0,
			0,
			.44445
		],
		102: [
			0,
			.69444,
			.06944,
			0,
			.30556
		],
		103: [
			.19444,
			.44444,
			.01389,
			0,
			.5
		],
		104: [
			0,
			.69444,
			0,
			0,
			.51667
		],
		105: [
			0,
			.67937,
			0,
			0,
			.23889
		],
		106: [
			.19444,
			.67937,
			0,
			0,
			.26667
		],
		107: [
			0,
			.69444,
			0,
			0,
			.48889
		],
		108: [
			0,
			.69444,
			0,
			0,
			.23889
		],
		109: [
			0,
			.44444,
			0,
			0,
			.79445
		],
		110: [
			0,
			.44444,
			0,
			0,
			.51667
		],
		111: [
			0,
			.44444,
			0,
			0,
			.5
		],
		112: [
			.19444,
			.44444,
			0,
			0,
			.51667
		],
		113: [
			.19444,
			.44444,
			0,
			0,
			.51667
		],
		114: [
			0,
			.44444,
			.01389,
			0,
			.34167
		],
		115: [
			0,
			.44444,
			0,
			0,
			.38333
		],
		116: [
			0,
			.57143,
			0,
			0,
			.36111
		],
		117: [
			0,
			.44444,
			0,
			0,
			.51667
		],
		118: [
			0,
			.44444,
			.01389,
			0,
			.46111
		],
		119: [
			0,
			.44444,
			.01389,
			0,
			.68334
		],
		120: [
			0,
			.44444,
			0,
			0,
			.46111
		],
		121: [
			.19444,
			.44444,
			.01389,
			0,
			.46111
		],
		122: [
			0,
			.44444,
			0,
			0,
			.43472
		],
		126: [
			.35,
			.32659,
			0,
			0,
			.5
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.67937,
			0,
			0,
			.5
		],
		176: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		184: [
			.17014,
			0,
			0,
			0,
			.44445
		],
		305: [
			0,
			.44444,
			0,
			0,
			.23889
		],
		567: [
			.19444,
			.44444,
			0,
			0,
			.26667
		],
		710: [
			0,
			.69444,
			0,
			0,
			.5
		],
		711: [
			0,
			.63194,
			0,
			0,
			.5
		],
		713: [
			0,
			.60889,
			0,
			0,
			.5
		],
		714: [
			0,
			.69444,
			0,
			0,
			.5
		],
		715: [
			0,
			.69444,
			0,
			0,
			.5
		],
		728: [
			0,
			.69444,
			0,
			0,
			.5
		],
		729: [
			0,
			.67937,
			0,
			0,
			.27778
		],
		730: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		732: [
			0,
			.67659,
			0,
			0,
			.5
		],
		733: [
			0,
			.69444,
			0,
			0,
			.5
		],
		915: [
			0,
			.69444,
			0,
			0,
			.54167
		],
		916: [
			0,
			.69444,
			0,
			0,
			.83334
		],
		920: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		923: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		926: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		928: [
			0,
			.69444,
			0,
			0,
			.70834
		],
		931: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		933: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		934: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		936: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		937: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		8211: [
			0,
			.44444,
			.02778,
			0,
			.5
		],
		8212: [
			0,
			.44444,
			.02778,
			0,
			1
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.5
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.5
		]
	},
	"Script-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		65: [
			0,
			.7,
			.22925,
			0,
			.80253
		],
		66: [
			0,
			.7,
			.04087,
			0,
			.90757
		],
		67: [
			0,
			.7,
			.1689,
			0,
			.66619
		],
		68: [
			0,
			.7,
			.09371,
			0,
			.77443
		],
		69: [
			0,
			.7,
			.18583,
			0,
			.56162
		],
		70: [
			0,
			.7,
			.13634,
			0,
			.89544
		],
		71: [
			0,
			.7,
			.17322,
			0,
			.60961
		],
		72: [
			0,
			.7,
			.29694,
			0,
			.96919
		],
		73: [
			0,
			.7,
			.19189,
			0,
			.80907
		],
		74: [
			.27778,
			.7,
			.19189,
			0,
			1.05159
		],
		75: [
			0,
			.7,
			.31259,
			0,
			.91364
		],
		76: [
			0,
			.7,
			.19189,
			0,
			.87373
		],
		77: [
			0,
			.7,
			.15981,
			0,
			1.08031
		],
		78: [
			0,
			.7,
			.3525,
			0,
			.9015
		],
		79: [
			0,
			.7,
			.08078,
			0,
			.73787
		],
		80: [
			0,
			.7,
			.08078,
			0,
			1.01262
		],
		81: [
			0,
			.7,
			.03305,
			0,
			.88282
		],
		82: [
			0,
			.7,
			.06259,
			0,
			.85
		],
		83: [
			0,
			.7,
			.19189,
			0,
			.86767
		],
		84: [
			0,
			.7,
			.29087,
			0,
			.74697
		],
		85: [
			0,
			.7,
			.25815,
			0,
			.79996
		],
		86: [
			0,
			.7,
			.27523,
			0,
			.62204
		],
		87: [
			0,
			.7,
			.27523,
			0,
			.80532
		],
		88: [
			0,
			.7,
			.26006,
			0,
			.94445
		],
		89: [
			0,
			.7,
			.2939,
			0,
			.70961
		],
		90: [
			0,
			.7,
			.24037,
			0,
			.8212
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		]
	},
	"Size1-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			.35001,
			.85,
			0,
			0,
			.45834
		],
		41: [
			.35001,
			.85,
			0,
			0,
			.45834
		],
		47: [
			.35001,
			.85,
			0,
			0,
			.57778
		],
		91: [
			.35001,
			.85,
			0,
			0,
			.41667
		],
		92: [
			.35001,
			.85,
			0,
			0,
			.57778
		],
		93: [
			.35001,
			.85,
			0,
			0,
			.41667
		],
		123: [
			.35001,
			.85,
			0,
			0,
			.58334
		],
		125: [
			.35001,
			.85,
			0,
			0,
			.58334
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		732: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		770: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		771: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		8214: [
			-99e-5,
			.601,
			0,
			0,
			.77778
		],
		8593: [
			1e-5,
			.6,
			0,
			0,
			.66667
		],
		8595: [
			1e-5,
			.6,
			0,
			0,
			.66667
		],
		8657: [
			1e-5,
			.6,
			0,
			0,
			.77778
		],
		8659: [
			1e-5,
			.6,
			0,
			0,
			.77778
		],
		8719: [
			.25001,
			.75,
			0,
			0,
			.94445
		],
		8720: [
			.25001,
			.75,
			0,
			0,
			.94445
		],
		8721: [
			.25001,
			.75,
			0,
			0,
			1.05556
		],
		8730: [
			.35001,
			.85,
			0,
			0,
			1
		],
		8739: [
			-.00599,
			.606,
			0,
			0,
			.33333
		],
		8741: [
			-.00599,
			.606,
			0,
			0,
			.55556
		],
		8747: [
			.30612,
			.805,
			.19445,
			0,
			.47222
		],
		8748: [
			.306,
			.805,
			.19445,
			0,
			.47222
		],
		8749: [
			.306,
			.805,
			.19445,
			0,
			.47222
		],
		8750: [
			.30612,
			.805,
			.19445,
			0,
			.47222
		],
		8896: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8897: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8898: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8899: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8968: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		8969: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		8970: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		8971: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		9168: [
			-99e-5,
			.601,
			0,
			0,
			.66667
		],
		10216: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		10217: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		10752: [
			.25001,
			.75,
			0,
			0,
			1.11111
		],
		10753: [
			.25001,
			.75,
			0,
			0,
			1.11111
		],
		10754: [
			.25001,
			.75,
			0,
			0,
			1.11111
		],
		10756: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		10758: [
			.25001,
			.75,
			0,
			0,
			.83334
		]
	},
	"Size2-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			.65002,
			1.15,
			0,
			0,
			.59722
		],
		41: [
			.65002,
			1.15,
			0,
			0,
			.59722
		],
		47: [
			.65002,
			1.15,
			0,
			0,
			.81111
		],
		91: [
			.65002,
			1.15,
			0,
			0,
			.47222
		],
		92: [
			.65002,
			1.15,
			0,
			0,
			.81111
		],
		93: [
			.65002,
			1.15,
			0,
			0,
			.47222
		],
		123: [
			.65002,
			1.15,
			0,
			0,
			.66667
		],
		125: [
			.65002,
			1.15,
			0,
			0,
			.66667
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.75,
			0,
			0,
			1
		],
		732: [
			0,
			.75,
			0,
			0,
			1
		],
		770: [
			0,
			.75,
			0,
			0,
			1
		],
		771: [
			0,
			.75,
			0,
			0,
			1
		],
		8719: [
			.55001,
			1.05,
			0,
			0,
			1.27778
		],
		8720: [
			.55001,
			1.05,
			0,
			0,
			1.27778
		],
		8721: [
			.55001,
			1.05,
			0,
			0,
			1.44445
		],
		8730: [
			.65002,
			1.15,
			0,
			0,
			1
		],
		8747: [
			.86225,
			1.36,
			.44445,
			0,
			.55556
		],
		8748: [
			.862,
			1.36,
			.44445,
			0,
			.55556
		],
		8749: [
			.862,
			1.36,
			.44445,
			0,
			.55556
		],
		8750: [
			.86225,
			1.36,
			.44445,
			0,
			.55556
		],
		8896: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8897: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8898: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8899: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8968: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		8969: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		8970: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		8971: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		10216: [
			.65002,
			1.15,
			0,
			0,
			.61111
		],
		10217: [
			.65002,
			1.15,
			0,
			0,
			.61111
		],
		10752: [
			.55001,
			1.05,
			0,
			0,
			1.51112
		],
		10753: [
			.55001,
			1.05,
			0,
			0,
			1.51112
		],
		10754: [
			.55001,
			1.05,
			0,
			0,
			1.51112
		],
		10756: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		10758: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		]
	},
	"Size3-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			.95003,
			1.45,
			0,
			0,
			.73611
		],
		41: [
			.95003,
			1.45,
			0,
			0,
			.73611
		],
		47: [
			.95003,
			1.45,
			0,
			0,
			1.04445
		],
		91: [
			.95003,
			1.45,
			0,
			0,
			.52778
		],
		92: [
			.95003,
			1.45,
			0,
			0,
			1.04445
		],
		93: [
			.95003,
			1.45,
			0,
			0,
			.52778
		],
		123: [
			.95003,
			1.45,
			0,
			0,
			.75
		],
		125: [
			.95003,
			1.45,
			0,
			0,
			.75
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		732: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		770: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		771: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		8730: [
			.95003,
			1.45,
			0,
			0,
			1
		],
		8968: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		8969: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		8970: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		8971: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		10216: [
			.95003,
			1.45,
			0,
			0,
			.75
		],
		10217: [
			.95003,
			1.45,
			0,
			0,
			.75
		]
	},
	"Size4-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			1.25003,
			1.75,
			0,
			0,
			.79167
		],
		41: [
			1.25003,
			1.75,
			0,
			0,
			.79167
		],
		47: [
			1.25003,
			1.75,
			0,
			0,
			1.27778
		],
		91: [
			1.25003,
			1.75,
			0,
			0,
			.58334
		],
		92: [
			1.25003,
			1.75,
			0,
			0,
			1.27778
		],
		93: [
			1.25003,
			1.75,
			0,
			0,
			.58334
		],
		123: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		125: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		732: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		770: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		771: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		8730: [
			1.25003,
			1.75,
			0,
			0,
			1
		],
		8968: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		8969: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		8970: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		8971: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		9115: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9116: [
			1e-5,
			.6,
			0,
			0,
			.875
		],
		9117: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9118: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9119: [
			1e-5,
			.6,
			0,
			0,
			.875
		],
		9120: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9121: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9122: [
			-99e-5,
			.601,
			0,
			0,
			.66667
		],
		9123: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9124: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9125: [
			-99e-5,
			.601,
			0,
			0,
			.66667
		],
		9126: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9127: [
			1e-5,
			.9,
			0,
			0,
			.88889
		],
		9128: [
			.65002,
			1.15,
			0,
			0,
			.88889
		],
		9129: [
			.90001,
			0,
			0,
			0,
			.88889
		],
		9130: [
			0,
			.3,
			0,
			0,
			.88889
		],
		9131: [
			1e-5,
			.9,
			0,
			0,
			.88889
		],
		9132: [
			.65002,
			1.15,
			0,
			0,
			.88889
		],
		9133: [
			.90001,
			0,
			0,
			0,
			.88889
		],
		9143: [
			.88502,
			.915,
			0,
			0,
			1.05556
		],
		10216: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		10217: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		57344: [
			-.00499,
			.605,
			0,
			0,
			1.05556
		],
		57345: [
			-.00499,
			.605,
			0,
			0,
			1.05556
		],
		57680: [
			0,
			.12,
			0,
			0,
			.45
		],
		57681: [
			0,
			.12,
			0,
			0,
			.45
		],
		57682: [
			0,
			.12,
			0,
			0,
			.45
		],
		57683: [
			0,
			.12,
			0,
			0,
			.45
		]
	},
	"Typewriter-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.525
		],
		33: [
			0,
			.61111,
			0,
			0,
			.525
		],
		34: [
			0,
			.61111,
			0,
			0,
			.525
		],
		35: [
			0,
			.61111,
			0,
			0,
			.525
		],
		36: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		37: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		38: [
			0,
			.61111,
			0,
			0,
			.525
		],
		39: [
			0,
			.61111,
			0,
			0,
			.525
		],
		40: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		41: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		42: [
			0,
			.52083,
			0,
			0,
			.525
		],
		43: [
			-.08056,
			.53055,
			0,
			0,
			.525
		],
		44: [
			.13889,
			.125,
			0,
			0,
			.525
		],
		45: [
			-.08056,
			.53055,
			0,
			0,
			.525
		],
		46: [
			0,
			.125,
			0,
			0,
			.525
		],
		47: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		48: [
			0,
			.61111,
			0,
			0,
			.525
		],
		49: [
			0,
			.61111,
			0,
			0,
			.525
		],
		50: [
			0,
			.61111,
			0,
			0,
			.525
		],
		51: [
			0,
			.61111,
			0,
			0,
			.525
		],
		52: [
			0,
			.61111,
			0,
			0,
			.525
		],
		53: [
			0,
			.61111,
			0,
			0,
			.525
		],
		54: [
			0,
			.61111,
			0,
			0,
			.525
		],
		55: [
			0,
			.61111,
			0,
			0,
			.525
		],
		56: [
			0,
			.61111,
			0,
			0,
			.525
		],
		57: [
			0,
			.61111,
			0,
			0,
			.525
		],
		58: [
			0,
			.43056,
			0,
			0,
			.525
		],
		59: [
			.13889,
			.43056,
			0,
			0,
			.525
		],
		60: [
			-.05556,
			.55556,
			0,
			0,
			.525
		],
		61: [
			-.19549,
			.41562,
			0,
			0,
			.525
		],
		62: [
			-.05556,
			.55556,
			0,
			0,
			.525
		],
		63: [
			0,
			.61111,
			0,
			0,
			.525
		],
		64: [
			0,
			.61111,
			0,
			0,
			.525
		],
		65: [
			0,
			.61111,
			0,
			0,
			.525
		],
		66: [
			0,
			.61111,
			0,
			0,
			.525
		],
		67: [
			0,
			.61111,
			0,
			0,
			.525
		],
		68: [
			0,
			.61111,
			0,
			0,
			.525
		],
		69: [
			0,
			.61111,
			0,
			0,
			.525
		],
		70: [
			0,
			.61111,
			0,
			0,
			.525
		],
		71: [
			0,
			.61111,
			0,
			0,
			.525
		],
		72: [
			0,
			.61111,
			0,
			0,
			.525
		],
		73: [
			0,
			.61111,
			0,
			0,
			.525
		],
		74: [
			0,
			.61111,
			0,
			0,
			.525
		],
		75: [
			0,
			.61111,
			0,
			0,
			.525
		],
		76: [
			0,
			.61111,
			0,
			0,
			.525
		],
		77: [
			0,
			.61111,
			0,
			0,
			.525
		],
		78: [
			0,
			.61111,
			0,
			0,
			.525
		],
		79: [
			0,
			.61111,
			0,
			0,
			.525
		],
		80: [
			0,
			.61111,
			0,
			0,
			.525
		],
		81: [
			.13889,
			.61111,
			0,
			0,
			.525
		],
		82: [
			0,
			.61111,
			0,
			0,
			.525
		],
		83: [
			0,
			.61111,
			0,
			0,
			.525
		],
		84: [
			0,
			.61111,
			0,
			0,
			.525
		],
		85: [
			0,
			.61111,
			0,
			0,
			.525
		],
		86: [
			0,
			.61111,
			0,
			0,
			.525
		],
		87: [
			0,
			.61111,
			0,
			0,
			.525
		],
		88: [
			0,
			.61111,
			0,
			0,
			.525
		],
		89: [
			0,
			.61111,
			0,
			0,
			.525
		],
		90: [
			0,
			.61111,
			0,
			0,
			.525
		],
		91: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		92: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		93: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		94: [
			0,
			.61111,
			0,
			0,
			.525
		],
		95: [
			.09514,
			0,
			0,
			0,
			.525
		],
		96: [
			0,
			.61111,
			0,
			0,
			.525
		],
		97: [
			0,
			.43056,
			0,
			0,
			.525
		],
		98: [
			0,
			.61111,
			0,
			0,
			.525
		],
		99: [
			0,
			.43056,
			0,
			0,
			.525
		],
		100: [
			0,
			.61111,
			0,
			0,
			.525
		],
		101: [
			0,
			.43056,
			0,
			0,
			.525
		],
		102: [
			0,
			.61111,
			0,
			0,
			.525
		],
		103: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		104: [
			0,
			.61111,
			0,
			0,
			.525
		],
		105: [
			0,
			.61111,
			0,
			0,
			.525
		],
		106: [
			.22222,
			.61111,
			0,
			0,
			.525
		],
		107: [
			0,
			.61111,
			0,
			0,
			.525
		],
		108: [
			0,
			.61111,
			0,
			0,
			.525
		],
		109: [
			0,
			.43056,
			0,
			0,
			.525
		],
		110: [
			0,
			.43056,
			0,
			0,
			.525
		],
		111: [
			0,
			.43056,
			0,
			0,
			.525
		],
		112: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		113: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		114: [
			0,
			.43056,
			0,
			0,
			.525
		],
		115: [
			0,
			.43056,
			0,
			0,
			.525
		],
		116: [
			0,
			.55358,
			0,
			0,
			.525
		],
		117: [
			0,
			.43056,
			0,
			0,
			.525
		],
		118: [
			0,
			.43056,
			0,
			0,
			.525
		],
		119: [
			0,
			.43056,
			0,
			0,
			.525
		],
		120: [
			0,
			.43056,
			0,
			0,
			.525
		],
		121: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		122: [
			0,
			.43056,
			0,
			0,
			.525
		],
		123: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		124: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		125: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		126: [
			0,
			.61111,
			0,
			0,
			.525
		],
		127: [
			0,
			.61111,
			0,
			0,
			.525
		],
		160: [
			0,
			0,
			0,
			0,
			.525
		],
		176: [
			0,
			.61111,
			0,
			0,
			.525
		],
		184: [
			.19445,
			0,
			0,
			0,
			.525
		],
		305: [
			0,
			.43056,
			0,
			0,
			.525
		],
		567: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		711: [
			0,
			.56597,
			0,
			0,
			.525
		],
		713: [
			0,
			.56555,
			0,
			0,
			.525
		],
		714: [
			0,
			.61111,
			0,
			0,
			.525
		],
		715: [
			0,
			.61111,
			0,
			0,
			.525
		],
		728: [
			0,
			.61111,
			0,
			0,
			.525
		],
		730: [
			0,
			.61111,
			0,
			0,
			.525
		],
		770: [
			0,
			.61111,
			0,
			0,
			.525
		],
		771: [
			0,
			.61111,
			0,
			0,
			.525
		],
		776: [
			0,
			.61111,
			0,
			0,
			.525
		],
		915: [
			0,
			.61111,
			0,
			0,
			.525
		],
		916: [
			0,
			.61111,
			0,
			0,
			.525
		],
		920: [
			0,
			.61111,
			0,
			0,
			.525
		],
		923: [
			0,
			.61111,
			0,
			0,
			.525
		],
		926: [
			0,
			.61111,
			0,
			0,
			.525
		],
		928: [
			0,
			.61111,
			0,
			0,
			.525
		],
		931: [
			0,
			.61111,
			0,
			0,
			.525
		],
		933: [
			0,
			.61111,
			0,
			0,
			.525
		],
		934: [
			0,
			.61111,
			0,
			0,
			.525
		],
		936: [
			0,
			.61111,
			0,
			0,
			.525
		],
		937: [
			0,
			.61111,
			0,
			0,
			.525
		],
		8216: [
			0,
			.61111,
			0,
			0,
			.525
		],
		8217: [
			0,
			.61111,
			0,
			0,
			.525
		],
		8242: [
			0,
			.61111,
			0,
			0,
			.525
		],
		9251: [
			.11111,
			.21944,
			0,
			0,
			.525
		]
	}
}, dt = {
	slant: [
		.25,
		.25,
		.25
	],
	space: [
		0,
		0,
		0
	],
	stretch: [
		0,
		0,
		0
	],
	shrink: [
		0,
		0,
		0
	],
	xHeight: [
		.431,
		.431,
		.431
	],
	quad: [
		1,
		1.171,
		1.472
	],
	extraSpace: [
		0,
		0,
		0
	],
	num1: [
		.677,
		.732,
		.925
	],
	num2: [
		.394,
		.384,
		.387
	],
	num3: [
		.444,
		.471,
		.504
	],
	denom1: [
		.686,
		.752,
		1.025
	],
	denom2: [
		.345,
		.344,
		.532
	],
	sup1: [
		.413,
		.503,
		.504
	],
	sup2: [
		.363,
		.431,
		.404
	],
	sup3: [
		.289,
		.286,
		.294
	],
	sub1: [
		.15,
		.143,
		.2
	],
	sub2: [
		.247,
		.286,
		.4
	],
	supDrop: [
		.386,
		.353,
		.494
	],
	subDrop: [
		.05,
		.071,
		.1
	],
	delim1: [
		2.39,
		1.7,
		1.98
	],
	delim2: [
		1.01,
		1.157,
		1.42
	],
	axisHeight: [
		.25,
		.25,
		.25
	],
	defaultRuleThickness: [
		.04,
		.049,
		.049
	],
	bigOpSpacing1: [
		.111,
		.111,
		.111
	],
	bigOpSpacing2: [
		.166,
		.166,
		.166
	],
	bigOpSpacing3: [
		.2,
		.2,
		.2
	],
	bigOpSpacing4: [
		.6,
		.611,
		.611
	],
	bigOpSpacing5: [
		.1,
		.143,
		.143
	],
	sqrtRuleThickness: [
		.04,
		.04,
		.04
	],
	ptPerEm: [
		10,
		10,
		10
	],
	doubleRuleSep: [
		.2,
		.2,
		.2
	],
	arrayRuleWidth: [
		.04,
		.04,
		.04
	],
	fboxsep: [
		.3,
		.3,
		.3
	],
	fboxrule: [
		.04,
		.04,
		.04
	]
}, ft = {
	Å: "A",
	Ð: "D",
	Þ: "o",
	å: "a",
	ð: "d",
	þ: "o",
	А: "A",
	Б: "B",
	В: "B",
	Г: "F",
	Д: "A",
	Е: "E",
	Ж: "K",
	З: "3",
	И: "N",
	Й: "N",
	К: "K",
	Л: "N",
	М: "M",
	Н: "H",
	О: "O",
	П: "N",
	Р: "P",
	С: "C",
	Т: "T",
	У: "y",
	Ф: "O",
	Х: "X",
	Ц: "U",
	Ч: "h",
	Ш: "W",
	Щ: "W",
	Ъ: "B",
	Ы: "X",
	Ь: "B",
	Э: "3",
	Ю: "X",
	Я: "R",
	а: "a",
	б: "b",
	в: "a",
	г: "r",
	д: "y",
	е: "e",
	ж: "m",
	з: "e",
	и: "n",
	й: "n",
	к: "n",
	л: "n",
	м: "m",
	н: "n",
	о: "o",
	п: "n",
	р: "p",
	с: "c",
	т: "o",
	у: "y",
	ф: "b",
	х: "x",
	ц: "n",
	ч: "n",
	ш: "w",
	щ: "w",
	ъ: "a",
	ы: "m",
	ь: "a",
	э: "e",
	ю: "m",
	я: "r"
};
function pt(e, t) {
	ut[e] = t;
}
function mt(e, t, n) {
	if (!ut[t]) throw Error("Font metrics not found for font: " + t + ".");
	var r = e.charCodeAt(0), i = ut[t][r];
	if (!i && e[0] in ft && (r = ft[e[0]].charCodeAt(0), i = ut[t][r]), !i && n === "text" && Xe(r) && (i = ut[t][77]), i) return {
		depth: i[0],
		height: i[1],
		italic: i[2],
		skew: i[3],
		width: i[4]
	};
}
var ht = {};
function gt(e) {
	var t;
	if (t = e >= 5 ? 0 : e >= 3 ? 1 : 2, !ht[t]) {
		var n = ht[t] = { cssEmPerMu: dt.quad[t] / 18 };
		for (var r in dt) dt.hasOwnProperty(r) && (n[r] = dt[r][t]);
	}
	return ht[t];
}
var _t = [
	[
		1,
		1,
		1
	],
	[
		2,
		1,
		1
	],
	[
		3,
		1,
		1
	],
	[
		4,
		2,
		1
	],
	[
		5,
		2,
		1
	],
	[
		6,
		3,
		1
	],
	[
		7,
		4,
		2
	],
	[
		8,
		6,
		3
	],
	[
		9,
		7,
		6
	],
	[
		10,
		8,
		7
	],
	[
		11,
		10,
		9
	]
], vt = [
	.5,
	.6,
	.7,
	.8,
	.9,
	1,
	1.2,
	1.44,
	1.728,
	2.074,
	2.488
], yt = function(e, t) {
	return t.size < 2 ? e : _t[e - 1][t.size - 1];
}, bt = class e {
	constructor(t) {
		this.style = void 0, this.color = void 0, this.size = void 0, this.textSize = void 0, this.phantom = void 0, this.font = void 0, this.fontFamily = void 0, this.fontWeight = void 0, this.fontShape = void 0, this.sizeMultiplier = void 0, this.maxSize = void 0, this.minRuleThickness = void 0, this._fontMetrics = void 0, this.style = t.style, this.color = t.color, this.size = t.size || e.BASESIZE, this.textSize = t.textSize || this.size, this.phantom = !!t.phantom, this.font = t.font || "", this.fontFamily = t.fontFamily || "", this.fontWeight = t.fontWeight || "", this.fontShape = t.fontShape || "", this.sizeMultiplier = vt[this.size - 1], this.maxSize = t.maxSize, this.minRuleThickness = t.minRuleThickness, this._fontMetrics = void 0;
	}
	extend(t) {
		var n = {
			style: this.style,
			size: this.size,
			textSize: this.textSize,
			color: this.color,
			phantom: this.phantom,
			font: this.font,
			fontFamily: this.fontFamily,
			fontWeight: this.fontWeight,
			fontShape: this.fontShape,
			maxSize: this.maxSize,
			minRuleThickness: this.minRuleThickness
		};
		for (var r in t) t.hasOwnProperty(r) && (n[r] = t[r]);
		return new e(n);
	}
	havingStyle(e) {
		return this.style === e ? this : this.extend({
			style: e,
			size: yt(this.textSize, e)
		});
	}
	havingCrampedStyle() {
		return this.havingStyle(this.style.cramp());
	}
	havingSize(e) {
		return this.size === e && this.textSize === e ? this : this.extend({
			style: this.style.text(),
			size: e,
			textSize: e,
			sizeMultiplier: vt[e - 1]
		});
	}
	havingBaseStyle(t) {
		t ||= this.style.text();
		var n = yt(e.BASESIZE, t);
		return this.size === n && this.textSize === e.BASESIZE && this.style === t ? this : this.extend({
			style: t,
			size: n
		});
	}
	havingBaseSizing() {
		var e;
		switch (this.style.id) {
			case 4:
			case 5:
				e = 3;
				break;
			case 6:
			case 7:
				e = 1;
				break;
			default: e = 6;
		}
		return this.extend({
			style: this.style.text(),
			size: e
		});
	}
	withColor(e) {
		return this.extend({ color: e });
	}
	withPhantom() {
		return this.extend({ phantom: !0 });
	}
	withFont(e) {
		return this.extend({ font: e });
	}
	withTextFontFamily(e) {
		return this.extend({
			fontFamily: e,
			font: ""
		});
	}
	withTextFontWeight(e) {
		return this.extend({
			fontWeight: e,
			font: ""
		});
	}
	withTextFontShape(e) {
		return this.extend({
			fontShape: e,
			font: ""
		});
	}
	sizingClasses(e) {
		return e.size === this.size ? [] : [
			"sizing",
			"reset-size" + e.size,
			"size" + this.size
		];
	}
	baseSizingClasses() {
		return this.size === e.BASESIZE ? [] : [
			"sizing",
			"reset-size" + this.size,
			"size" + e.BASESIZE
		];
	}
	fontMetrics() {
		return this._fontMetrics ||= gt(this.size), this._fontMetrics;
	}
	getColor() {
		return this.phantom ? "transparent" : this.color;
	}
};
bt.BASESIZE = 6;
var xt = {
	pt: 1,
	mm: 7227 / 2540,
	cm: 7227 / 254,
	in: 72.27,
	bp: 803 / 800,
	pc: 12,
	dd: 1238 / 1157,
	cc: 14856 / 1157,
	nd: 685 / 642,
	nc: 1370 / 107,
	sp: 1 / 65536,
	px: 803 / 800
}, St = {
	ex: !0,
	em: !0,
	mu: !0
}, Ct = function(e) {
	return typeof e != "string" && (e = e.unit), e in xt || e in St || e === "ex";
}, O = function(e, t) {
	var n;
	if (e.unit in xt) n = xt[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
	else if (e.unit === "mu") n = t.fontMetrics().cssEmPerMu;
	else {
		var r;
		if (r = t.style.isTight() ? t.havingStyle(t.style.text()) : t, e.unit === "ex") n = r.fontMetrics().xHeight;
		else if (e.unit === "em") n = r.fontMetrics().quad;
		else throw new T("Invalid unit: '" + e.unit + "'");
		r !== t && (n *= r.sizeMultiplier / t.sizeMultiplier);
	}
	return Math.min(e.number * n, t.maxSize);
}, k = function(e) {
	return +e.toFixed(4) + "em";
}, wt = function(e) {
	return e.filter((e) => e).join(" ");
}, Tt = function(e, t, n) {
	if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = n || {}, t) {
		t.style.isTight() && this.classes.push("mtight");
		var r = t.getColor();
		r && (this.style.color = r);
	}
}, Et = function(e) {
	var t = document.createElement(e);
	for (var n in t.className = wt(this.classes), this.style) this.style.hasOwnProperty(n) && (t.style[n] = this.style[n]);
	for (var r in this.attributes) this.attributes.hasOwnProperty(r) && t.setAttribute(r, this.attributes[r]);
	for (var i = 0; i < this.children.length; i++) t.appendChild(this.children[i].toNode());
	return t;
}, Dt = /[\s"'>/=\x00-\x1f]/, Ot = function(e) {
	var t = "<" + e;
	this.classes.length && (t += " class=\"" + E.escape(wt(this.classes)) + "\"");
	var n = "";
	for (var r in this.style) this.style.hasOwnProperty(r) && (n += E.hyphenate(r) + ":" + this.style[r] + ";");
	for (var i in n && (t += " style=\"" + E.escape(n) + "\""), this.attributes) if (this.attributes.hasOwnProperty(i)) {
		if (Dt.test(i)) throw new T("Invalid attribute name '" + i + "'");
		t += " " + i + "=\"" + E.escape(this.attributes[i]) + "\"";
	}
	t += ">";
	for (var a = 0; a < this.children.length; a++) t += this.children[a].toMarkup();
	return t += "</" + e + ">", t;
}, kt = class {
	constructor(e, t, n, r) {
		this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, Tt.call(this, e, n, r), this.children = t || [];
	}
	setAttribute(e, t) {
		this.attributes[e] = t;
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		return Et.call(this, "span");
	}
	toMarkup() {
		return Ot.call(this, "span");
	}
}, At = class {
	constructor(e, t, n, r) {
		this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, Tt.call(this, t, r), this.children = n || [], this.setAttribute("href", e);
	}
	setAttribute(e, t) {
		this.attributes[e] = t;
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		return Et.call(this, "a");
	}
	toMarkup() {
		return Ot.call(this, "a");
	}
}, jt = class {
	constructor(e, t, n) {
		this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.style = n;
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		var e = document.createElement("img");
		for (var t in e.src = this.src, e.alt = this.alt, e.className = "mord", this.style) this.style.hasOwnProperty(t) && (e.style[t] = this.style[t]);
		return e;
	}
	toMarkup() {
		var e = "<img src=\"" + E.escape(this.src) + "\"" + (" alt=\"" + E.escape(this.alt) + "\""), t = "";
		for (var n in this.style) this.style.hasOwnProperty(n) && (t += E.hyphenate(n) + ":" + this.style[n] + ";");
		return t && (e += " style=\"" + E.escape(t) + "\""), e += "'/>", e;
	}
}, Mt = {
	î: "ı̂",
	ï: "ı̈",
	í: "ı́",
	ì: "ı̀"
}, Nt = class {
	constructor(e, t, n, r, i, a, o, s) {
		this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = n || 0, this.italic = r || 0, this.skew = i || 0, this.width = a || 0, this.classes = o || [], this.style = s || {}, this.maxFontSize = 0;
		var c = Je(this.text.charCodeAt(0));
		c && this.classes.push(c + "_fallback"), /[îïíì]/.test(this.text) && (this.text = Mt[this.text]);
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		var e = document.createTextNode(this.text), t = null;
		for (var n in this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = k(this.italic)), this.classes.length > 0 && (t ||= document.createElement("span"), t.className = wt(this.classes)), this.style) this.style.hasOwnProperty(n) && (t ||= document.createElement("span"), t.style[n] = this.style[n]);
		return t ? (t.appendChild(e), t) : e;
	}
	toMarkup() {
		var e = !1, t = "<span";
		this.classes.length && (e = !0, t += " class=\"", t += E.escape(wt(this.classes)), t += "\"");
		var n = "";
		for (var r in this.italic > 0 && (n += "margin-right:" + this.italic + "em;"), this.style) this.style.hasOwnProperty(r) && (n += E.hyphenate(r) + ":" + this.style[r] + ";");
		n && (e = !0, t += " style=\"" + E.escape(n) + "\"");
		var i = E.escape(this.text);
		return e ? (t += ">", t += i, t += "</span>", t) : i;
	}
}, Pt = class {
	constructor(e, t) {
		this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/2000/svg", "svg");
		for (var t in this.attributes) Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
		for (var n = 0; n < this.children.length; n++) e.appendChild(this.children[n].toNode());
		return e;
	}
	toMarkup() {
		var e = "<svg xmlns=\"http://www.w3.org/2000/svg\"";
		for (var t in this.attributes) Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + "=\"" + E.escape(this.attributes[t]) + "\"");
		e += ">";
		for (var n = 0; n < this.children.length; n++) e += this.children[n].toMarkup();
		return e += "</svg>", e;
	}
}, Ft = class {
	constructor(e, t) {
		this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/2000/svg", "path");
		return this.alternate ? e.setAttribute("d", this.alternate) : e.setAttribute("d", st[this.pathName]), e;
	}
	toMarkup() {
		return this.alternate ? "<path d=\"" + E.escape(this.alternate) + "\"/>" : "<path d=\"" + E.escape(st[this.pathName]) + "\"/>";
	}
}, It = class {
	constructor(e) {
		this.attributes = void 0, this.attributes = e || {};
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/2000/svg", "line");
		for (var t in this.attributes) Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
		return e;
	}
	toMarkup() {
		var e = "<line";
		for (var t in this.attributes) Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + "=\"" + E.escape(this.attributes[t]) + "\"");
		return e += "/>", e;
	}
};
function Lt(e) {
	if (e instanceof Nt) return e;
	throw Error("Expected symbolNode but got " + String(e) + ".");
}
function Rt(e) {
	if (e instanceof kt) return e;
	throw Error("Expected span<HtmlDomNode> but got " + String(e) + ".");
}
var zt = {
	bin: 1,
	close: 1,
	inner: 1,
	open: 1,
	punct: 1,
	rel: 1
}, Bt = {
	"accent-token": 1,
	mathord: 1,
	"op-token": 1,
	spacing: 1,
	textord: 1
}, A = {
	math: {},
	text: {}
};
function j(e, t, n, r, i, a) {
	A[e][i] = {
		font: t,
		group: n,
		replace: r
	}, a && r && (A[e][r] = A[e][i]);
}
var M = "math", N = "text", P = "main", F = "ams", I = "accent-token", L = "bin", Vt = "close", Ht = "inner", R = "mathord", z = "op-token", Ut = "open", Wt = "punct", B = "rel", Gt = "spacing", V = "textord";
j(M, P, B, "≡", "\\equiv", !0), j(M, P, B, "≺", "\\prec", !0), j(M, P, B, "≻", "\\succ", !0), j(M, P, B, "∼", "\\sim", !0), j(M, P, B, "⊥", "\\perp"), j(M, P, B, "⪯", "\\preceq", !0), j(M, P, B, "⪰", "\\succeq", !0), j(M, P, B, "≃", "\\simeq", !0), j(M, P, B, "∣", "\\mid", !0), j(M, P, B, "≪", "\\ll", !0), j(M, P, B, "≫", "\\gg", !0), j(M, P, B, "≍", "\\asymp", !0), j(M, P, B, "∥", "\\parallel"), j(M, P, B, "⋈", "\\bowtie", !0), j(M, P, B, "⌣", "\\smile", !0), j(M, P, B, "⊑", "\\sqsubseteq", !0), j(M, P, B, "⊒", "\\sqsupseteq", !0), j(M, P, B, "≐", "\\doteq", !0), j(M, P, B, "⌢", "\\frown", !0), j(M, P, B, "∋", "\\ni", !0), j(M, P, B, "∝", "\\propto", !0), j(M, P, B, "⊢", "\\vdash", !0), j(M, P, B, "⊣", "\\dashv", !0), j(M, P, B, "∋", "\\owns"), j(M, P, Wt, ".", "\\ldotp"), j(M, P, Wt, "⋅", "\\cdotp"), j(M, P, V, "#", "\\#"), j(N, P, V, "#", "\\#"), j(M, P, V, "&", "\\&"), j(N, P, V, "&", "\\&"), j(M, P, V, "ℵ", "\\aleph", !0), j(M, P, V, "∀", "\\forall", !0), j(M, P, V, "ℏ", "\\hbar", !0), j(M, P, V, "∃", "\\exists", !0), j(M, P, V, "∇", "\\nabla", !0), j(M, P, V, "♭", "\\flat", !0), j(M, P, V, "ℓ", "\\ell", !0), j(M, P, V, "♮", "\\natural", !0), j(M, P, V, "♣", "\\clubsuit", !0), j(M, P, V, "℘", "\\wp", !0), j(M, P, V, "♯", "\\sharp", !0), j(M, P, V, "♢", "\\diamondsuit", !0), j(M, P, V, "ℜ", "\\Re", !0), j(M, P, V, "♡", "\\heartsuit", !0), j(M, P, V, "ℑ", "\\Im", !0), j(M, P, V, "♠", "\\spadesuit", !0), j(M, P, V, "§", "\\S", !0), j(N, P, V, "§", "\\S"), j(M, P, V, "¶", "\\P", !0), j(N, P, V, "¶", "\\P"), j(M, P, V, "†", "\\dag"), j(N, P, V, "†", "\\dag"), j(N, P, V, "†", "\\textdagger"), j(M, P, V, "‡", "\\ddag"), j(N, P, V, "‡", "\\ddag"), j(N, P, V, "‡", "\\textdaggerdbl"), j(M, P, Vt, "⎱", "\\rmoustache", !0), j(M, P, Ut, "⎰", "\\lmoustache", !0), j(M, P, Vt, "⟯", "\\rgroup", !0), j(M, P, Ut, "⟮", "\\lgroup", !0), j(M, P, L, "∓", "\\mp", !0), j(M, P, L, "⊖", "\\ominus", !0), j(M, P, L, "⊎", "\\uplus", !0), j(M, P, L, "⊓", "\\sqcap", !0), j(M, P, L, "∗", "\\ast"), j(M, P, L, "⊔", "\\sqcup", !0), j(M, P, L, "◯", "\\bigcirc", !0), j(M, P, L, "∙", "\\bullet", !0), j(M, P, L, "‡", "\\ddagger"), j(M, P, L, "≀", "\\wr", !0), j(M, P, L, "⨿", "\\amalg"), j(M, P, L, "&", "\\And"), j(M, P, B, "⟵", "\\longleftarrow", !0), j(M, P, B, "⇐", "\\Leftarrow", !0), j(M, P, B, "⟸", "\\Longleftarrow", !0), j(M, P, B, "⟶", "\\longrightarrow", !0), j(M, P, B, "⇒", "\\Rightarrow", !0), j(M, P, B, "⟹", "\\Longrightarrow", !0), j(M, P, B, "↔", "\\leftrightarrow", !0), j(M, P, B, "⟷", "\\longleftrightarrow", !0), j(M, P, B, "⇔", "\\Leftrightarrow", !0), j(M, P, B, "⟺", "\\Longleftrightarrow", !0), j(M, P, B, "↦", "\\mapsto", !0), j(M, P, B, "⟼", "\\longmapsto", !0), j(M, P, B, "↗", "\\nearrow", !0), j(M, P, B, "↩", "\\hookleftarrow", !0), j(M, P, B, "↪", "\\hookrightarrow", !0), j(M, P, B, "↘", "\\searrow", !0), j(M, P, B, "↼", "\\leftharpoonup", !0), j(M, P, B, "⇀", "\\rightharpoonup", !0), j(M, P, B, "↙", "\\swarrow", !0), j(M, P, B, "↽", "\\leftharpoondown", !0), j(M, P, B, "⇁", "\\rightharpoondown", !0), j(M, P, B, "↖", "\\nwarrow", !0), j(M, P, B, "⇌", "\\rightleftharpoons", !0), j(M, F, B, "≮", "\\nless", !0), j(M, F, B, "", "\\@nleqslant"), j(M, F, B, "", "\\@nleqq"), j(M, F, B, "⪇", "\\lneq", !0), j(M, F, B, "≨", "\\lneqq", !0), j(M, F, B, "", "\\@lvertneqq"), j(M, F, B, "⋦", "\\lnsim", !0), j(M, F, B, "⪉", "\\lnapprox", !0), j(M, F, B, "⊀", "\\nprec", !0), j(M, F, B, "⋠", "\\npreceq", !0), j(M, F, B, "⋨", "\\precnsim", !0), j(M, F, B, "⪹", "\\precnapprox", !0), j(M, F, B, "≁", "\\nsim", !0), j(M, F, B, "", "\\@nshortmid"), j(M, F, B, "∤", "\\nmid", !0), j(M, F, B, "⊬", "\\nvdash", !0), j(M, F, B, "⊭", "\\nvDash", !0), j(M, F, B, "⋪", "\\ntriangleleft"), j(M, F, B, "⋬", "\\ntrianglelefteq", !0), j(M, F, B, "⊊", "\\subsetneq", !0), j(M, F, B, "", "\\@varsubsetneq"), j(M, F, B, "⫋", "\\subsetneqq", !0), j(M, F, B, "", "\\@varsubsetneqq"), j(M, F, B, "≯", "\\ngtr", !0), j(M, F, B, "", "\\@ngeqslant"), j(M, F, B, "", "\\@ngeqq"), j(M, F, B, "⪈", "\\gneq", !0), j(M, F, B, "≩", "\\gneqq", !0), j(M, F, B, "", "\\@gvertneqq"), j(M, F, B, "⋧", "\\gnsim", !0), j(M, F, B, "⪊", "\\gnapprox", !0), j(M, F, B, "⊁", "\\nsucc", !0), j(M, F, B, "⋡", "\\nsucceq", !0), j(M, F, B, "⋩", "\\succnsim", !0), j(M, F, B, "⪺", "\\succnapprox", !0), j(M, F, B, "≆", "\\ncong", !0), j(M, F, B, "", "\\@nshortparallel"), j(M, F, B, "∦", "\\nparallel", !0), j(M, F, B, "⊯", "\\nVDash", !0), j(M, F, B, "⋫", "\\ntriangleright"), j(M, F, B, "⋭", "\\ntrianglerighteq", !0), j(M, F, B, "", "\\@nsupseteqq"), j(M, F, B, "⊋", "\\supsetneq", !0), j(M, F, B, "", "\\@varsupsetneq"), j(M, F, B, "⫌", "\\supsetneqq", !0), j(M, F, B, "", "\\@varsupsetneqq"), j(M, F, B, "⊮", "\\nVdash", !0), j(M, F, B, "⪵", "\\precneqq", !0), j(M, F, B, "⪶", "\\succneqq", !0), j(M, F, B, "", "\\@nsubseteqq"), j(M, F, L, "⊴", "\\unlhd"), j(M, F, L, "⊵", "\\unrhd"), j(M, F, B, "↚", "\\nleftarrow", !0), j(M, F, B, "↛", "\\nrightarrow", !0), j(M, F, B, "⇍", "\\nLeftarrow", !0), j(M, F, B, "⇏", "\\nRightarrow", !0), j(M, F, B, "↮", "\\nleftrightarrow", !0), j(M, F, B, "⇎", "\\nLeftrightarrow", !0), j(M, F, B, "△", "\\vartriangle"), j(M, F, V, "ℏ", "\\hslash"), j(M, F, V, "▽", "\\triangledown"), j(M, F, V, "◊", "\\lozenge"), j(M, F, V, "Ⓢ", "\\circledS"), j(M, F, V, "®", "\\circledR"), j(N, F, V, "®", "\\circledR"), j(M, F, V, "∡", "\\measuredangle", !0), j(M, F, V, "∄", "\\nexists"), j(M, F, V, "℧", "\\mho"), j(M, F, V, "Ⅎ", "\\Finv", !0), j(M, F, V, "⅁", "\\Game", !0), j(M, F, V, "‵", "\\backprime"), j(M, F, V, "▲", "\\blacktriangle"), j(M, F, V, "▼", "\\blacktriangledown"), j(M, F, V, "■", "\\blacksquare"), j(M, F, V, "⧫", "\\blacklozenge"), j(M, F, V, "★", "\\bigstar"), j(M, F, V, "∢", "\\sphericalangle", !0), j(M, F, V, "∁", "\\complement", !0), j(M, F, V, "ð", "\\eth", !0), j(N, P, V, "ð", "ð"), j(M, F, V, "╱", "\\diagup"), j(M, F, V, "╲", "\\diagdown"), j(M, F, V, "□", "\\square"), j(M, F, V, "□", "\\Box"), j(M, F, V, "◊", "\\Diamond"), j(M, F, V, "¥", "\\yen", !0), j(N, F, V, "¥", "\\yen", !0), j(M, F, V, "✓", "\\checkmark", !0), j(N, F, V, "✓", "\\checkmark"), j(M, F, V, "ℶ", "\\beth", !0), j(M, F, V, "ℸ", "\\daleth", !0), j(M, F, V, "ℷ", "\\gimel", !0), j(M, F, V, "ϝ", "\\digamma", !0), j(M, F, V, "ϰ", "\\varkappa"), j(M, F, Ut, "┌", "\\@ulcorner", !0), j(M, F, Vt, "┐", "\\@urcorner", !0), j(M, F, Ut, "└", "\\@llcorner", !0), j(M, F, Vt, "┘", "\\@lrcorner", !0), j(M, F, B, "≦", "\\leqq", !0), j(M, F, B, "⩽", "\\leqslant", !0), j(M, F, B, "⪕", "\\eqslantless", !0), j(M, F, B, "≲", "\\lesssim", !0), j(M, F, B, "⪅", "\\lessapprox", !0), j(M, F, B, "≊", "\\approxeq", !0), j(M, F, L, "⋖", "\\lessdot"), j(M, F, B, "⋘", "\\lll", !0), j(M, F, B, "≶", "\\lessgtr", !0), j(M, F, B, "⋚", "\\lesseqgtr", !0), j(M, F, B, "⪋", "\\lesseqqgtr", !0), j(M, F, B, "≑", "\\doteqdot"), j(M, F, B, "≓", "\\risingdotseq", !0), j(M, F, B, "≒", "\\fallingdotseq", !0), j(M, F, B, "∽", "\\backsim", !0), j(M, F, B, "⋍", "\\backsimeq", !0), j(M, F, B, "⫅", "\\subseteqq", !0), j(M, F, B, "⋐", "\\Subset", !0), j(M, F, B, "⊏", "\\sqsubset", !0), j(M, F, B, "≼", "\\preccurlyeq", !0), j(M, F, B, "⋞", "\\curlyeqprec", !0), j(M, F, B, "≾", "\\precsim", !0), j(M, F, B, "⪷", "\\precapprox", !0), j(M, F, B, "⊲", "\\vartriangleleft"), j(M, F, B, "⊴", "\\trianglelefteq"), j(M, F, B, "⊨", "\\vDash", !0), j(M, F, B, "⊪", "\\Vvdash", !0), j(M, F, B, "⌣", "\\smallsmile"), j(M, F, B, "⌢", "\\smallfrown"), j(M, F, B, "≏", "\\bumpeq", !0), j(M, F, B, "≎", "\\Bumpeq", !0), j(M, F, B, "≧", "\\geqq", !0), j(M, F, B, "⩾", "\\geqslant", !0), j(M, F, B, "⪖", "\\eqslantgtr", !0), j(M, F, B, "≳", "\\gtrsim", !0), j(M, F, B, "⪆", "\\gtrapprox", !0), j(M, F, L, "⋗", "\\gtrdot"), j(M, F, B, "⋙", "\\ggg", !0), j(M, F, B, "≷", "\\gtrless", !0), j(M, F, B, "⋛", "\\gtreqless", !0), j(M, F, B, "⪌", "\\gtreqqless", !0), j(M, F, B, "≖", "\\eqcirc", !0), j(M, F, B, "≗", "\\circeq", !0), j(M, F, B, "≜", "\\triangleq", !0), j(M, F, B, "∼", "\\thicksim"), j(M, F, B, "≈", "\\thickapprox"), j(M, F, B, "⫆", "\\supseteqq", !0), j(M, F, B, "⋑", "\\Supset", !0), j(M, F, B, "⊐", "\\sqsupset", !0), j(M, F, B, "≽", "\\succcurlyeq", !0), j(M, F, B, "⋟", "\\curlyeqsucc", !0), j(M, F, B, "≿", "\\succsim", !0), j(M, F, B, "⪸", "\\succapprox", !0), j(M, F, B, "⊳", "\\vartriangleright"), j(M, F, B, "⊵", "\\trianglerighteq"), j(M, F, B, "⊩", "\\Vdash", !0), j(M, F, B, "∣", "\\shortmid"), j(M, F, B, "∥", "\\shortparallel"), j(M, F, B, "≬", "\\between", !0), j(M, F, B, "⋔", "\\pitchfork", !0), j(M, F, B, "∝", "\\varpropto"), j(M, F, B, "◀", "\\blacktriangleleft"), j(M, F, B, "∴", "\\therefore", !0), j(M, F, B, "∍", "\\backepsilon"), j(M, F, B, "▶", "\\blacktriangleright"), j(M, F, B, "∵", "\\because", !0), j(M, F, B, "⋘", "\\llless"), j(M, F, B, "⋙", "\\gggtr"), j(M, F, L, "⊲", "\\lhd"), j(M, F, L, "⊳", "\\rhd"), j(M, F, B, "≂", "\\eqsim", !0), j(M, P, B, "⋈", "\\Join"), j(M, F, B, "≑", "\\Doteq", !0), j(M, F, L, "∔", "\\dotplus", !0), j(M, F, L, "∖", "\\smallsetminus"), j(M, F, L, "⋒", "\\Cap", !0), j(M, F, L, "⋓", "\\Cup", !0), j(M, F, L, "⩞", "\\doublebarwedge", !0), j(M, F, L, "⊟", "\\boxminus", !0), j(M, F, L, "⊞", "\\boxplus", !0), j(M, F, L, "⋇", "\\divideontimes", !0), j(M, F, L, "⋉", "\\ltimes", !0), j(M, F, L, "⋊", "\\rtimes", !0), j(M, F, L, "⋋", "\\leftthreetimes", !0), j(M, F, L, "⋌", "\\rightthreetimes", !0), j(M, F, L, "⋏", "\\curlywedge", !0), j(M, F, L, "⋎", "\\curlyvee", !0), j(M, F, L, "⊝", "\\circleddash", !0), j(M, F, L, "⊛", "\\circledast", !0), j(M, F, L, "⋅", "\\centerdot"), j(M, F, L, "⊺", "\\intercal", !0), j(M, F, L, "⋒", "\\doublecap"), j(M, F, L, "⋓", "\\doublecup"), j(M, F, L, "⊠", "\\boxtimes", !0), j(M, F, B, "⇢", "\\dashrightarrow", !0), j(M, F, B, "⇠", "\\dashleftarrow", !0), j(M, F, B, "⇇", "\\leftleftarrows", !0), j(M, F, B, "⇆", "\\leftrightarrows", !0), j(M, F, B, "⇚", "\\Lleftarrow", !0), j(M, F, B, "↞", "\\twoheadleftarrow", !0), j(M, F, B, "↢", "\\leftarrowtail", !0), j(M, F, B, "↫", "\\looparrowleft", !0), j(M, F, B, "⇋", "\\leftrightharpoons", !0), j(M, F, B, "↶", "\\curvearrowleft", !0), j(M, F, B, "↺", "\\circlearrowleft", !0), j(M, F, B, "↰", "\\Lsh", !0), j(M, F, B, "⇈", "\\upuparrows", !0), j(M, F, B, "↿", "\\upharpoonleft", !0), j(M, F, B, "⇃", "\\downharpoonleft", !0), j(M, P, B, "⊶", "\\origof", !0), j(M, P, B, "⊷", "\\imageof", !0), j(M, F, B, "⊸", "\\multimap", !0), j(M, F, B, "↭", "\\leftrightsquigarrow", !0), j(M, F, B, "⇉", "\\rightrightarrows", !0), j(M, F, B, "⇄", "\\rightleftarrows", !0), j(M, F, B, "↠", "\\twoheadrightarrow", !0), j(M, F, B, "↣", "\\rightarrowtail", !0), j(M, F, B, "↬", "\\looparrowright", !0), j(M, F, B, "↷", "\\curvearrowright", !0), j(M, F, B, "↻", "\\circlearrowright", !0), j(M, F, B, "↱", "\\Rsh", !0), j(M, F, B, "⇊", "\\downdownarrows", !0), j(M, F, B, "↾", "\\upharpoonright", !0), j(M, F, B, "⇂", "\\downharpoonright", !0), j(M, F, B, "⇝", "\\rightsquigarrow", !0), j(M, F, B, "⇝", "\\leadsto"), j(M, F, B, "⇛", "\\Rrightarrow", !0), j(M, F, B, "↾", "\\restriction"), j(M, P, V, "‘", "`"), j(M, P, V, "$", "\\$"), j(N, P, V, "$", "\\$"), j(N, P, V, "$", "\\textdollar"), j(M, P, V, "%", "\\%"), j(N, P, V, "%", "\\%"), j(M, P, V, "_", "\\_"), j(N, P, V, "_", "\\_"), j(N, P, V, "_", "\\textunderscore"), j(M, P, V, "∠", "\\angle", !0), j(M, P, V, "∞", "\\infty", !0), j(M, P, V, "′", "\\prime"), j(M, P, V, "△", "\\triangle"), j(M, P, V, "Γ", "\\Gamma", !0), j(M, P, V, "Δ", "\\Delta", !0), j(M, P, V, "Θ", "\\Theta", !0), j(M, P, V, "Λ", "\\Lambda", !0), j(M, P, V, "Ξ", "\\Xi", !0), j(M, P, V, "Π", "\\Pi", !0), j(M, P, V, "Σ", "\\Sigma", !0), j(M, P, V, "Υ", "\\Upsilon", !0), j(M, P, V, "Φ", "\\Phi", !0), j(M, P, V, "Ψ", "\\Psi", !0), j(M, P, V, "Ω", "\\Omega", !0), j(M, P, V, "A", "Α"), j(M, P, V, "B", "Β"), j(M, P, V, "E", "Ε"), j(M, P, V, "Z", "Ζ"), j(M, P, V, "H", "Η"), j(M, P, V, "I", "Ι"), j(M, P, V, "K", "Κ"), j(M, P, V, "M", "Μ"), j(M, P, V, "N", "Ν"), j(M, P, V, "O", "Ο"), j(M, P, V, "P", "Ρ"), j(M, P, V, "T", "Τ"), j(M, P, V, "X", "Χ"), j(M, P, V, "¬", "\\neg", !0), j(M, P, V, "¬", "\\lnot"), j(M, P, V, "⊤", "\\top"), j(M, P, V, "⊥", "\\bot"), j(M, P, V, "∅", "\\emptyset"), j(M, F, V, "∅", "\\varnothing"), j(M, P, R, "α", "\\alpha", !0), j(M, P, R, "β", "\\beta", !0), j(M, P, R, "γ", "\\gamma", !0), j(M, P, R, "δ", "\\delta", !0), j(M, P, R, "ϵ", "\\epsilon", !0), j(M, P, R, "ζ", "\\zeta", !0), j(M, P, R, "η", "\\eta", !0), j(M, P, R, "θ", "\\theta", !0), j(M, P, R, "ι", "\\iota", !0), j(M, P, R, "κ", "\\kappa", !0), j(M, P, R, "λ", "\\lambda", !0), j(M, P, R, "μ", "\\mu", !0), j(M, P, R, "ν", "\\nu", !0), j(M, P, R, "ξ", "\\xi", !0), j(M, P, R, "ο", "\\omicron", !0), j(M, P, R, "π", "\\pi", !0), j(M, P, R, "ρ", "\\rho", !0), j(M, P, R, "σ", "\\sigma", !0), j(M, P, R, "τ", "\\tau", !0), j(M, P, R, "υ", "\\upsilon", !0), j(M, P, R, "ϕ", "\\phi", !0), j(M, P, R, "χ", "\\chi", !0), j(M, P, R, "ψ", "\\psi", !0), j(M, P, R, "ω", "\\omega", !0), j(M, P, R, "ε", "\\varepsilon", !0), j(M, P, R, "ϑ", "\\vartheta", !0), j(M, P, R, "ϖ", "\\varpi", !0), j(M, P, R, "ϱ", "\\varrho", !0), j(M, P, R, "ς", "\\varsigma", !0), j(M, P, R, "φ", "\\varphi", !0), j(M, P, L, "∗", "*", !0), j(M, P, L, "+", "+"), j(M, P, L, "−", "-", !0), j(M, P, L, "⋅", "\\cdot", !0), j(M, P, L, "∘", "\\circ", !0), j(M, P, L, "÷", "\\div", !0), j(M, P, L, "±", "\\pm", !0), j(M, P, L, "×", "\\times", !0), j(M, P, L, "∩", "\\cap", !0), j(M, P, L, "∪", "\\cup", !0), j(M, P, L, "∖", "\\setminus", !0), j(M, P, L, "∧", "\\land"), j(M, P, L, "∨", "\\lor"), j(M, P, L, "∧", "\\wedge", !0), j(M, P, L, "∨", "\\vee", !0), j(M, P, V, "√", "\\surd"), j(M, P, Ut, "⟨", "\\langle", !0), j(M, P, Ut, "∣", "\\lvert"), j(M, P, Ut, "∥", "\\lVert"), j(M, P, Vt, "?", "?"), j(M, P, Vt, "!", "!"), j(M, P, Vt, "⟩", "\\rangle", !0), j(M, P, Vt, "∣", "\\rvert"), j(M, P, Vt, "∥", "\\rVert"), j(M, P, B, "=", "="), j(M, P, B, ":", ":"), j(M, P, B, "≈", "\\approx", !0), j(M, P, B, "≅", "\\cong", !0), j(M, P, B, "≥", "\\ge"), j(M, P, B, "≥", "\\geq", !0), j(M, P, B, "←", "\\gets"), j(M, P, B, ">", "\\gt", !0), j(M, P, B, "∈", "\\in", !0), j(M, P, B, "", "\\@not"), j(M, P, B, "⊂", "\\subset", !0), j(M, P, B, "⊃", "\\supset", !0), j(M, P, B, "⊆", "\\subseteq", !0), j(M, P, B, "⊇", "\\supseteq", !0), j(M, F, B, "⊈", "\\nsubseteq", !0), j(M, F, B, "⊉", "\\nsupseteq", !0), j(M, P, B, "⊨", "\\models"), j(M, P, B, "←", "\\leftarrow", !0), j(M, P, B, "≤", "\\le"), j(M, P, B, "≤", "\\leq", !0), j(M, P, B, "<", "\\lt", !0), j(M, P, B, "→", "\\rightarrow", !0), j(M, P, B, "→", "\\to"), j(M, F, B, "≱", "\\ngeq", !0), j(M, F, B, "≰", "\\nleq", !0), j(M, P, Gt, "\xA0", "\\ "), j(M, P, Gt, "\xA0", "\\space"), j(M, P, Gt, "\xA0", "\\nobreakspace"), j(N, P, Gt, "\xA0", "\\ "), j(N, P, Gt, "\xA0", " "), j(N, P, Gt, "\xA0", "\\space"), j(N, P, Gt, "\xA0", "\\nobreakspace"), j(M, P, Gt, null, "\\nobreak"), j(M, P, Gt, null, "\\allowbreak"), j(M, P, Wt, ",", ","), j(M, P, Wt, ";", ";"), j(M, F, L, "⊼", "\\barwedge", !0), j(M, F, L, "⊻", "\\veebar", !0), j(M, P, L, "⊙", "\\odot", !0), j(M, P, L, "⊕", "\\oplus", !0), j(M, P, L, "⊗", "\\otimes", !0), j(M, P, V, "∂", "\\partial", !0), j(M, P, L, "⊘", "\\oslash", !0), j(M, F, L, "⊚", "\\circledcirc", !0), j(M, F, L, "⊡", "\\boxdot", !0), j(M, P, L, "△", "\\bigtriangleup"), j(M, P, L, "▽", "\\bigtriangledown"), j(M, P, L, "†", "\\dagger"), j(M, P, L, "⋄", "\\diamond"), j(M, P, L, "⋆", "\\star"), j(M, P, L, "◃", "\\triangleleft"), j(M, P, L, "▹", "\\triangleright"), j(M, P, Ut, "{", "\\{"), j(N, P, V, "{", "\\{"), j(N, P, V, "{", "\\textbraceleft"), j(M, P, Vt, "}", "\\}"), j(N, P, V, "}", "\\}"), j(N, P, V, "}", "\\textbraceright"), j(M, P, Ut, "{", "\\lbrace"), j(M, P, Vt, "}", "\\rbrace"), j(M, P, Ut, "[", "\\lbrack", !0), j(N, P, V, "[", "\\lbrack", !0), j(M, P, Vt, "]", "\\rbrack", !0), j(N, P, V, "]", "\\rbrack", !0), j(M, P, Ut, "(", "\\lparen", !0), j(M, P, Vt, ")", "\\rparen", !0), j(N, P, V, "<", "\\textless", !0), j(N, P, V, ">", "\\textgreater", !0), j(M, P, Ut, "⌊", "\\lfloor", !0), j(M, P, Vt, "⌋", "\\rfloor", !0), j(M, P, Ut, "⌈", "\\lceil", !0), j(M, P, Vt, "⌉", "\\rceil", !0), j(M, P, V, "\\", "\\backslash"), j(M, P, V, "∣", "|"), j(M, P, V, "∣", "\\vert"), j(N, P, V, "|", "\\textbar", !0), j(M, P, V, "∥", "\\|"), j(M, P, V, "∥", "\\Vert"), j(N, P, V, "∥", "\\textbardbl"), j(N, P, V, "~", "\\textasciitilde"), j(N, P, V, "\\", "\\textbackslash"), j(N, P, V, "^", "\\textasciicircum"), j(M, P, B, "↑", "\\uparrow", !0), j(M, P, B, "⇑", "\\Uparrow", !0), j(M, P, B, "↓", "\\downarrow", !0), j(M, P, B, "⇓", "\\Downarrow", !0), j(M, P, B, "↕", "\\updownarrow", !0), j(M, P, B, "⇕", "\\Updownarrow", !0), j(M, P, z, "∐", "\\coprod"), j(M, P, z, "⋁", "\\bigvee"), j(M, P, z, "⋀", "\\bigwedge"), j(M, P, z, "⨄", "\\biguplus"), j(M, P, z, "⋂", "\\bigcap"), j(M, P, z, "⋃", "\\bigcup"), j(M, P, z, "∫", "\\int"), j(M, P, z, "∫", "\\intop"), j(M, P, z, "∬", "\\iint"), j(M, P, z, "∭", "\\iiint"), j(M, P, z, "∏", "\\prod"), j(M, P, z, "∑", "\\sum"), j(M, P, z, "⨂", "\\bigotimes"), j(M, P, z, "⨁", "\\bigoplus"), j(M, P, z, "⨀", "\\bigodot"), j(M, P, z, "∮", "\\oint"), j(M, P, z, "∯", "\\oiint"), j(M, P, z, "∰", "\\oiiint"), j(M, P, z, "⨆", "\\bigsqcup"), j(M, P, z, "∫", "\\smallint"), j(N, P, Ht, "…", "\\textellipsis"), j(M, P, Ht, "…", "\\mathellipsis"), j(N, P, Ht, "…", "\\ldots", !0), j(M, P, Ht, "…", "\\ldots", !0), j(M, P, Ht, "⋯", "\\@cdots", !0), j(M, P, Ht, "⋱", "\\ddots", !0), j(M, P, V, "⋮", "\\varvdots"), j(N, P, V, "⋮", "\\varvdots"), j(M, P, I, "ˊ", "\\acute"), j(M, P, I, "ˋ", "\\grave"), j(M, P, I, "¨", "\\ddot"), j(M, P, I, "~", "\\tilde"), j(M, P, I, "ˉ", "\\bar"), j(M, P, I, "˘", "\\breve"), j(M, P, I, "ˇ", "\\check"), j(M, P, I, "^", "\\hat"), j(M, P, I, "⃗", "\\vec"), j(M, P, I, "˙", "\\dot"), j(M, P, I, "˚", "\\mathring"), j(M, P, R, "", "\\@imath"), j(M, P, R, "", "\\@jmath"), j(M, P, V, "ı", "ı"), j(M, P, V, "ȷ", "ȷ"), j(N, P, V, "ı", "\\i", !0), j(N, P, V, "ȷ", "\\j", !0), j(N, P, V, "ß", "\\ss", !0), j(N, P, V, "æ", "\\ae", !0), j(N, P, V, "œ", "\\oe", !0), j(N, P, V, "ø", "\\o", !0), j(N, P, V, "Æ", "\\AE", !0), j(N, P, V, "Œ", "\\OE", !0), j(N, P, V, "Ø", "\\O", !0), j(N, P, I, "ˊ", "\\'"), j(N, P, I, "ˋ", "\\`"), j(N, P, I, "ˆ", "\\^"), j(N, P, I, "˜", "\\~"), j(N, P, I, "ˉ", "\\="), j(N, P, I, "˘", "\\u"), j(N, P, I, "˙", "\\."), j(N, P, I, "¸", "\\c"), j(N, P, I, "˚", "\\r"), j(N, P, I, "ˇ", "\\v"), j(N, P, I, "¨", "\\\""), j(N, P, I, "˝", "\\H"), j(N, P, I, "◯", "\\textcircled");
var Kt = {
	"--": !0,
	"---": !0,
	"``": !0,
	"''": !0
};
j(N, P, V, "–", "--", !0), j(N, P, V, "–", "\\textendash"), j(N, P, V, "—", "---", !0), j(N, P, V, "—", "\\textemdash"), j(N, P, V, "‘", "`", !0), j(N, P, V, "‘", "\\textquoteleft"), j(N, P, V, "’", "'", !0), j(N, P, V, "’", "\\textquoteright"), j(N, P, V, "“", "``", !0), j(N, P, V, "“", "\\textquotedblleft"), j(N, P, V, "”", "''", !0), j(N, P, V, "”", "\\textquotedblright"), j(M, P, V, "°", "\\degree", !0), j(N, P, V, "°", "\\degree"), j(N, P, V, "°", "\\textdegree", !0), j(M, P, V, "£", "\\pounds"), j(M, P, V, "£", "\\mathsterling", !0), j(N, P, V, "£", "\\pounds"), j(N, P, V, "£", "\\textsterling", !0), j(M, F, V, "✠", "\\maltese"), j(N, F, V, "✠", "\\maltese");
for (var qt = "0123456789/@.\"", Jt = 0; Jt < qt.length; Jt++) {
	var Yt = qt.charAt(Jt);
	j(M, P, V, Yt, Yt);
}
for (var Xt = "0123456789!@*()-=+\";:?/.,", Zt = 0; Zt < Xt.length; Zt++) {
	var Qt = Xt.charAt(Zt);
	j(N, P, V, Qt, Qt);
}
for (var $t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", en = 0; en < $t.length; en++) {
	var tn = $t.charAt(en);
	j(M, P, R, tn, tn), j(N, P, V, tn, tn);
}
j(M, F, V, "C", "ℂ"), j(N, F, V, "C", "ℂ"), j(M, F, V, "H", "ℍ"), j(N, F, V, "H", "ℍ"), j(M, F, V, "N", "ℕ"), j(N, F, V, "N", "ℕ"), j(M, F, V, "P", "ℙ"), j(N, F, V, "P", "ℙ"), j(M, F, V, "Q", "ℚ"), j(N, F, V, "Q", "ℚ"), j(M, F, V, "R", "ℝ"), j(N, F, V, "R", "ℝ"), j(M, F, V, "Z", "ℤ"), j(N, F, V, "Z", "ℤ"), j(M, P, R, "h", "ℎ"), j(N, P, R, "h", "ℎ");
for (var H = "", nn = 0; nn < $t.length; nn++) {
	var U = $t.charAt(nn);
	H = String.fromCharCode(55349, 56320 + nn), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56372 + nn), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56424 + nn), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56580 + nn), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56684 + nn), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56736 + nn), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56788 + nn), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56840 + nn), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56944 + nn), j(M, P, R, U, H), j(N, P, V, U, H), nn < 26 && (H = String.fromCharCode(55349, 56632 + nn), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56476 + nn), j(M, P, R, U, H), j(N, P, V, U, H));
}
H = "𝕜", j(M, P, R, "k", H), j(N, P, V, "k", H);
for (var rn = 0; rn < 10; rn++) {
	var an = rn.toString();
	H = String.fromCharCode(55349, 57294 + rn), j(M, P, R, an, H), j(N, P, V, an, H), H = String.fromCharCode(55349, 57314 + rn), j(M, P, R, an, H), j(N, P, V, an, H), H = String.fromCharCode(55349, 57324 + rn), j(M, P, R, an, H), j(N, P, V, an, H), H = String.fromCharCode(55349, 57334 + rn), j(M, P, R, an, H), j(N, P, V, an, H);
}
for (var on = "ÐÞþ", sn = 0; sn < on.length; sn++) {
	var cn = on.charAt(sn);
	j(M, P, R, cn, cn), j(N, P, V, cn, cn);
}
var ln = [
	[
		"mathbf",
		"textbf",
		"Main-Bold"
	],
	[
		"mathbf",
		"textbf",
		"Main-Bold"
	],
	[
		"mathnormal",
		"textit",
		"Math-Italic"
	],
	[
		"mathnormal",
		"textit",
		"Math-Italic"
	],
	[
		"boldsymbol",
		"boldsymbol",
		"Main-BoldItalic"
	],
	[
		"boldsymbol",
		"boldsymbol",
		"Main-BoldItalic"
	],
	[
		"mathscr",
		"textscr",
		"Script-Regular"
	],
	[
		"",
		"",
		""
	],
	[
		"",
		"",
		""
	],
	[
		"",
		"",
		""
	],
	[
		"mathfrak",
		"textfrak",
		"Fraktur-Regular"
	],
	[
		"mathfrak",
		"textfrak",
		"Fraktur-Regular"
	],
	[
		"mathbb",
		"textbb",
		"AMS-Regular"
	],
	[
		"mathbb",
		"textbb",
		"AMS-Regular"
	],
	[
		"mathboldfrak",
		"textboldfrak",
		"Fraktur-Regular"
	],
	[
		"mathboldfrak",
		"textboldfrak",
		"Fraktur-Regular"
	],
	[
		"mathsf",
		"textsf",
		"SansSerif-Regular"
	],
	[
		"mathsf",
		"textsf",
		"SansSerif-Regular"
	],
	[
		"mathboldsf",
		"textboldsf",
		"SansSerif-Bold"
	],
	[
		"mathboldsf",
		"textboldsf",
		"SansSerif-Bold"
	],
	[
		"mathitsf",
		"textitsf",
		"SansSerif-Italic"
	],
	[
		"mathitsf",
		"textitsf",
		"SansSerif-Italic"
	],
	[
		"",
		"",
		""
	],
	[
		"",
		"",
		""
	],
	[
		"mathtt",
		"texttt",
		"Typewriter-Regular"
	],
	[
		"mathtt",
		"texttt",
		"Typewriter-Regular"
	]
], un = [
	[
		"mathbf",
		"textbf",
		"Main-Bold"
	],
	[
		"",
		"",
		""
	],
	[
		"mathsf",
		"textsf",
		"SansSerif-Regular"
	],
	[
		"mathboldsf",
		"textboldsf",
		"SansSerif-Bold"
	],
	[
		"mathtt",
		"texttt",
		"Typewriter-Regular"
	]
], dn = function(e, t) {
	var n = e.charCodeAt(0), r = e.charCodeAt(1), i = (n - 55296) * 1024 + (r - 56320) + 65536, a = t === "math" ? 0 : 1;
	if (119808 <= i && i < 120484) {
		var o = Math.floor((i - 119808) / 26);
		return [ln[o][2], ln[o][a]];
	}
	if (120782 <= i && i <= 120831) {
		var s = Math.floor((i - 120782) / 10);
		return [un[s][2], un[s][a]];
	}
	if (i === 120485 || i === 120486) return [ln[0][2], ln[0][a]];
	if (120486 < i && i < 120782) return ["", ""];
	throw new T("Unsupported character: " + e);
}, fn = function(e, t, n) {
	return A[n][e] && A[n][e].replace && (e = A[n][e].replace), {
		value: e,
		metrics: mt(e, t, n)
	};
}, pn = function(e, t, n, r, i) {
	var a = fn(e, t, n), o = a.metrics;
	e = a.value;
	var s;
	if (o) {
		var c = o.italic;
		(n === "text" || r && r.font === "mathit") && (c = 0), s = new Nt(e, o.height, o.depth, c, o.skew, o.width, i);
	} else typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + n + "'")), s = new Nt(e, 0, 0, 0, 0, 0, i);
	if (r) {
		s.maxFontSize = r.sizeMultiplier, r.style.isTight() && s.classes.push("mtight");
		var l = r.getColor();
		l && (s.style.color = l);
	}
	return s;
}, mn = function(e, t, n, r) {
	return r === void 0 && (r = []), n.font === "boldsymbol" && fn(e, "Main-Bold", t).metrics ? pn(e, "Main-Bold", t, n, r.concat(["mathbf"])) : e === "\\" || A[t][e].font === "main" ? pn(e, "Main-Regular", t, n, r) : pn(e, "AMS-Regular", t, n, r.concat(["amsrm"]));
}, hn = function(e, t, n, r, i) {
	return i !== "textord" && fn(e, "Math-BoldItalic", t).metrics ? {
		fontName: "Math-BoldItalic",
		fontClass: "boldsymbol"
	} : {
		fontName: "Main-Bold",
		fontClass: "mathbf"
	};
}, gn = function(e, t, n) {
	var r = e.mode, i = e.text, a = ["mord"], o = r === "math" || r === "text" && t.font, s = o ? t.font : t.fontFamily, c = "", l = "";
	if (i.charCodeAt(0) === 55349 && ([c, l] = dn(i, r)), c.length > 0) return pn(i, c, r, t, a.concat(l));
	if (s) {
		var u, d;
		if (s === "boldsymbol") {
			var f = hn(i, r, t, a, n);
			u = f.fontName, d = [f.fontClass];
		} else o ? (u = An[s].fontName, d = [s]) : (u = kn(s, t.fontWeight, t.fontShape), d = [
			s,
			t.fontWeight,
			t.fontShape
		]);
		if (fn(i, u, r).metrics) return pn(i, u, r, t, a.concat(d));
		if (Kt.hasOwnProperty(i) && u.slice(0, 10) === "Typewriter") {
			for (var p = [], m = 0; m < i.length; m++) p.push(pn(i[m], u, r, t, a.concat(d)));
			return wn(p);
		}
	}
	if (n === "mathord") return pn(i, "Math-Italic", r, t, a.concat(["mathnormal"]));
	if (n === "textord") {
		var h = A[r][i] && A[r][i].font;
		if (h === "ams") return pn(i, kn("amsrm", t.fontWeight, t.fontShape), r, t, a.concat("amsrm", t.fontWeight, t.fontShape));
		if (h === "main" || !h) return pn(i, kn("textrm", t.fontWeight, t.fontShape), r, t, a.concat(t.fontWeight, t.fontShape));
		var g = kn(h, t.fontWeight, t.fontShape);
		return pn(i, g, r, t, a.concat(g, t.fontWeight, t.fontShape));
	}
	throw Error("unexpected type: " + n + " in makeOrd");
}, _n = (e, t) => {
	if (wt(e.classes) !== wt(t.classes) || e.skew !== t.skew || e.maxFontSize !== t.maxFontSize) return !1;
	if (e.classes.length === 1) {
		var n = e.classes[0];
		if (n === "mbin" || n === "mord") return !1;
	}
	for (var r in e.style) if (e.style.hasOwnProperty(r) && e.style[r] !== t.style[r]) return !1;
	for (var i in t.style) if (t.style.hasOwnProperty(i) && e.style[i] !== t.style[i]) return !1;
	return !0;
}, vn = (e) => {
	for (var t = 0; t < e.length - 1; t++) {
		var n = e[t], r = e[t + 1];
		n instanceof Nt && r instanceof Nt && _n(n, r) && (n.text += r.text, n.height = Math.max(n.height, r.height), n.depth = Math.max(n.depth, r.depth), n.italic = r.italic, e.splice(t + 1, 1), t--);
	}
	return e;
}, yn = function(e) {
	for (var t = 0, n = 0, r = 0, i = 0; i < e.children.length; i++) {
		var a = e.children[i];
		a.height > t && (t = a.height), a.depth > n && (n = a.depth), a.maxFontSize > r && (r = a.maxFontSize);
	}
	e.height = t, e.depth = n, e.maxFontSize = r;
}, bn = function(e, t, n, r) {
	var i = new kt(e, t, n, r);
	return yn(i), i;
}, xn = (e, t, n, r) => new kt(e, t, n, r), Sn = function(e, t, n) {
	var r = bn([e], [], t);
	return r.height = Math.max(n || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), r.style.borderBottomWidth = k(r.height), r.maxFontSize = 1, r;
}, Cn = function(e, t, n, r) {
	var i = new At(e, t, n, r);
	return yn(i), i;
}, wn = function(e) {
	var t = new lt(e);
	return yn(t), t;
}, Tn = function(e, t) {
	return e instanceof lt ? bn([], [e], t) : e;
}, En = function(e) {
	if (e.positionType === "individualShift") {
		for (var t = e.children, n = [t[0]], r = -t[0].shift - t[0].elem.depth, i = r, a = 1; a < t.length; a++) {
			var o = -t[a].shift - i - t[a].elem.depth, s = o - (t[a - 1].elem.height + t[a - 1].elem.depth);
			i += o, n.push({
				type: "kern",
				size: s
			}), n.push(t[a]);
		}
		return {
			children: n,
			depth: r
		};
	}
	var c;
	if (e.positionType === "top") {
		for (var l = e.positionData, u = 0; u < e.children.length; u++) {
			var d = e.children[u];
			l -= d.type === "kern" ? d.size : d.elem.height + d.elem.depth;
		}
		c = l;
	} else if (e.positionType === "bottom") c = -e.positionData;
	else {
		var f = e.children[0];
		if (f.type !== "elem") throw Error("First child must have type \"elem\".");
		if (e.positionType === "shift") c = -f.elem.depth - e.positionData;
		else if (e.positionType === "firstBaseline") c = -f.elem.depth;
		else throw Error("Invalid positionType " + e.positionType + ".");
	}
	return {
		children: e.children,
		depth: c
	};
}, Dn = function(e, t) {
	for (var { children: n, depth: r } = En(e), i = 0, a = 0; a < n.length; a++) {
		var o = n[a];
		if (o.type === "elem") {
			var s = o.elem;
			i = Math.max(i, s.maxFontSize, s.height);
		}
	}
	i += 2;
	var c = bn(["pstrut"], []);
	c.style.height = k(i);
	for (var l = [], u = r, d = r, f = r, p = 0; p < n.length; p++) {
		var m = n[p];
		if (m.type === "kern") f += m.size;
		else {
			var h = m.elem, g = m.wrapperClasses || [], _ = m.wrapperStyle || {}, v = bn(g, [c, h], void 0, _);
			v.style.top = k(-i - f - h.depth), m.marginLeft && (v.style.marginLeft = m.marginLeft), m.marginRight && (v.style.marginRight = m.marginRight), l.push(v), f += h.height + h.depth;
		}
		u = Math.min(u, f), d = Math.max(d, f);
	}
	var y = bn(["vlist"], l);
	y.style.height = k(d);
	var b;
	if (u < 0) {
		var x = bn(["vlist"], [bn([], [])]);
		x.style.height = k(-u), b = [bn(["vlist-r"], [y, bn(["vlist-s"], [new Nt("​")])]), bn(["vlist-r"], [x])];
	} else b = [bn(["vlist-r"], [y])];
	var S = bn(["vlist-t"], b);
	return b.length === 2 && S.classes.push("vlist-t2"), S.height = d, S.depth = -u, S;
}, On = (e, t) => {
	var n = bn(["mspace"], [], t), r = O(e, t);
	return n.style.marginRight = k(r), n;
}, kn = function(e, t, n) {
	var r = "";
	switch (e) {
		case "amsrm":
			r = "AMS";
			break;
		case "textrm":
			r = "Main";
			break;
		case "textsf":
			r = "SansSerif";
			break;
		case "texttt":
			r = "Typewriter";
			break;
		default: r = e;
	}
	var i;
	return i = t === "textbf" && n === "textit" ? "BoldItalic" : t === "textbf" ? "Bold" : t === "textit" ? "Italic" : "Regular", r + "-" + i;
}, An = {
	mathbf: {
		variant: "bold",
		fontName: "Main-Bold"
	},
	mathrm: {
		variant: "normal",
		fontName: "Main-Regular"
	},
	textit: {
		variant: "italic",
		fontName: "Main-Italic"
	},
	mathit: {
		variant: "italic",
		fontName: "Main-Italic"
	},
	mathnormal: {
		variant: "italic",
		fontName: "Math-Italic"
	},
	mathsfit: {
		variant: "sans-serif-italic",
		fontName: "SansSerif-Italic"
	},
	mathbb: {
		variant: "double-struck",
		fontName: "AMS-Regular"
	},
	mathcal: {
		variant: "script",
		fontName: "Caligraphic-Regular"
	},
	mathfrak: {
		variant: "fraktur",
		fontName: "Fraktur-Regular"
	},
	mathscr: {
		variant: "script",
		fontName: "Script-Regular"
	},
	mathsf: {
		variant: "sans-serif",
		fontName: "SansSerif-Regular"
	},
	mathtt: {
		variant: "monospace",
		fontName: "Typewriter-Regular"
	}
}, jn = {
	vec: [
		"vec",
		.471,
		.714
	],
	oiintSize1: [
		"oiintSize1",
		.957,
		.499
	],
	oiintSize2: [
		"oiintSize2",
		1.472,
		.659
	],
	oiiintSize1: [
		"oiiintSize1",
		1.304,
		.499
	],
	oiiintSize2: [
		"oiiintSize2",
		1.98,
		.659
	]
}, W = {
	fontMap: An,
	makeSymbol: pn,
	mathsym: mn,
	makeSpan: bn,
	makeSvgSpan: xn,
	makeLineSpan: Sn,
	makeAnchor: Cn,
	makeFragment: wn,
	wrapFragment: Tn,
	makeVList: Dn,
	makeOrd: gn,
	makeGlue: On,
	staticSvg: function(e, t) {
		var [n, r, i] = jn[e], a = xn(["overlay"], [new Pt([new Ft(n)], {
			width: k(r),
			height: k(i),
			style: "width:" + k(r),
			viewBox: "0 0 " + 1e3 * r + " " + 1e3 * i,
			preserveAspectRatio: "xMinYMin"
		})], t);
		return a.height = i, a.style.height = k(i), a.style.width = k(r), a;
	},
	svgData: jn,
	tryCombineChars: vn
}, G = {
	number: 3,
	unit: "mu"
}, Mn = {
	number: 4,
	unit: "mu"
}, Nn = {
	number: 5,
	unit: "mu"
}, Pn = {
	mord: {
		mop: G,
		mbin: Mn,
		mrel: Nn,
		minner: G
	},
	mop: {
		mord: G,
		mop: G,
		mrel: Nn,
		minner: G
	},
	mbin: {
		mord: Mn,
		mop: Mn,
		mopen: Mn,
		minner: Mn
	},
	mrel: {
		mord: Nn,
		mop: Nn,
		mopen: Nn,
		minner: Nn
	},
	mopen: {},
	mclose: {
		mop: G,
		mbin: Mn,
		mrel: Nn,
		minner: G
	},
	mpunct: {
		mord: G,
		mop: G,
		mrel: Nn,
		mopen: G,
		mclose: G,
		mpunct: G,
		minner: G
	},
	minner: {
		mord: G,
		mop: G,
		mbin: Mn,
		mrel: Nn,
		mopen: G,
		mpunct: G,
		minner: G
	}
}, Fn = {
	mord: { mop: G },
	mop: {
		mord: G,
		mop: G
	},
	mbin: {},
	mrel: {},
	mopen: {},
	mclose: { mop: G },
	mpunct: {},
	minner: { mop: G }
}, In = {}, Ln = {}, Rn = {};
function K(e) {
	for (var { type: t, names: n, props: r, handler: i, htmlBuilder: a, mathmlBuilder: o } = e, s = {
		type: t,
		numArgs: r.numArgs,
		argTypes: r.argTypes,
		allowedInArgument: !!r.allowedInArgument,
		allowedInText: !!r.allowedInText,
		allowedInMath: r.allowedInMath === void 0 || r.allowedInMath,
		numOptionalArgs: r.numOptionalArgs || 0,
		infix: !!r.infix,
		primitive: !!r.primitive,
		handler: i
	}, c = 0; c < n.length; ++c) In[n[c]] = s;
	t && (a && (Ln[t] = a), o && (Rn[t] = o));
}
function zn(e) {
	var { type: t, htmlBuilder: n, mathmlBuilder: r } = e;
	K({
		type: t,
		names: [],
		props: { numArgs: 0 },
		handler() {
			throw Error("Should never be called.");
		},
		htmlBuilder: n,
		mathmlBuilder: r
	});
}
var Bn = function(e) {
	return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, q = function(e) {
	return e.type === "ordgroup" ? e.body : [e];
}, Vn = W.makeSpan, Hn = [
	"leftmost",
	"mbin",
	"mopen",
	"mrel",
	"mop",
	"mpunct"
], Un = [
	"rightmost",
	"mrel",
	"mclose",
	"mpunct"
], Wn = {
	display: D.DISPLAY,
	text: D.TEXT,
	script: D.SCRIPT,
	scriptscript: D.SCRIPTSCRIPT
}, Gn = {
	mord: "mord",
	mop: "mop",
	mbin: "mbin",
	mrel: "mrel",
	mopen: "mopen",
	mclose: "mclose",
	mpunct: "mpunct",
	minner: "minner"
}, J = function(e, t, n, r) {
	r === void 0 && (r = [null, null]);
	for (var i = [], a = 0; a < e.length; a++) {
		var o = Y(e[a], t);
		if (o instanceof lt) {
			var s = o.children;
			i.push(...s);
		} else i.push(o);
	}
	if (W.tryCombineChars(i), !n) return i;
	var c = t;
	if (e.length === 1) {
		var l = e[0];
		l.type === "sizing" ? c = t.havingSize(l.size) : l.type === "styling" && (c = t.havingStyle(Wn[l.style]));
	}
	var u = Vn([r[0] || "leftmost"], [], t), d = Vn([r[1] || "rightmost"], [], t), f = n === "root";
	return Kn(i, (e, t) => {
		var n = t.classes[0], r = e.classes[0];
		n === "mbin" && Un.includes(r) ? t.classes[0] = "mord" : r === "mbin" && Hn.includes(n) && (e.classes[0] = "mord");
	}, { node: u }, d, f), Kn(i, (e, t) => {
		var n = Yn(t), r = Yn(e), i = n && r ? e.hasClass("mtight") ? Fn[n][r] : Pn[n][r] : null;
		if (i) return W.makeGlue(i, c);
	}, { node: u }, d, f), i;
}, Kn = function e(t, n, r, i, a) {
	i && t.push(i);
	for (var o = 0; o < t.length; o++) {
		var s = t[o], c = qn(s);
		if (c) {
			e(c.children, n, r, null, a);
			continue;
		}
		var l = !s.hasClass("mspace");
		if (l) {
			var u = n(s, r.node);
			u && (r.insertAfter ? r.insertAfter(u) : (t.unshift(u), o++));
		}
		l ? r.node = s : a && s.hasClass("newline") && (r.node = Vn(["leftmost"])), r.insertAfter = /* @__PURE__ */ ((e) => (n) => {
			t.splice(e + 1, 0, n), o++;
		})(o);
	}
	i && t.pop();
}, qn = function(e) {
	return e instanceof lt || e instanceof At || e instanceof kt && e.hasClass("enclosing") ? e : null;
}, Jn = function e(t, n) {
	var r = qn(t);
	if (r) {
		var i = r.children;
		if (i.length) {
			if (n === "right") return e(i[i.length - 1], "right");
			if (n === "left") return e(i[0], "left");
		}
	}
	return t;
}, Yn = function(e, t) {
	return e ? (t && (e = Jn(e, t)), Gn[e.classes[0]] || null) : null;
}, Xn = function(e, t) {
	var n = ["nulldelimiter"].concat(e.baseSizingClasses());
	return Vn(t.concat(n));
}, Y = function(e, t, n) {
	if (!e) return Vn();
	if (Ln[e.type]) {
		var r = Ln[e.type](e, t);
		if (n && t.size !== n.size) {
			r = Vn(t.sizingClasses(n), [r], t);
			var i = t.sizeMultiplier / n.sizeMultiplier;
			r.height *= i, r.depth *= i;
		}
		return r;
	}
	throw new T("Got group of unknown type: '" + e.type + "'");
};
function Zn(e, t) {
	var n = Vn(["base"], e, t), r = Vn(["strut"]);
	return r.style.height = k(n.height + n.depth), n.depth && (r.style.verticalAlign = k(-n.depth)), n.children.unshift(r), n;
}
function Qn(e, t) {
	var n = null;
	e.length === 1 && e[0].type === "tag" && (n = e[0].tag, e = e[0].body);
	var r = J(e, t, "root"), i;
	r.length === 2 && r[1].hasClass("tag") && (i = r.pop());
	for (var a = [], o = [], s = 0; s < r.length; s++) if (o.push(r[s]), r[s].hasClass("mbin") || r[s].hasClass("mrel") || r[s].hasClass("allowbreak")) {
		for (var c = !1; s < r.length - 1 && r[s + 1].hasClass("mspace") && !r[s + 1].hasClass("newline");) s++, o.push(r[s]), r[s].hasClass("nobreak") && (c = !0);
		c || (a.push(Zn(o, t)), o = []);
	} else r[s].hasClass("newline") && (o.pop(), o.length > 0 && (a.push(Zn(o, t)), o = []), a.push(r[s]));
	o.length > 0 && a.push(Zn(o, t));
	var l;
	n ? (l = Zn(J(n, t, !0)), l.classes = ["tag"], a.push(l)) : i && a.push(i);
	var u = Vn(["katex-html"], a);
	if (u.setAttribute("aria-hidden", "true"), l) {
		var d = l.children[0];
		d.style.height = k(u.height + u.depth), u.depth && (d.style.verticalAlign = k(-u.depth));
	}
	return u;
}
function $n(e) {
	return new lt(e);
}
var er = class {
	constructor(e, t, n) {
		this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = n || [];
	}
	setAttribute(e, t) {
		this.attributes[e] = t;
	}
	getAttribute(e) {
		return this.attributes[e];
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
		for (var t in this.attributes) Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
		this.classes.length > 0 && (e.className = wt(this.classes));
		for (var n = 0; n < this.children.length; n++) if (this.children[n] instanceof tr && this.children[n + 1] instanceof tr) {
			for (var r = this.children[n].toText() + this.children[++n].toText(); this.children[n + 1] instanceof tr;) r += this.children[++n].toText();
			e.appendChild(new tr(r).toNode());
		} else e.appendChild(this.children[n].toNode());
		return e;
	}
	toMarkup() {
		var e = "<" + this.type;
		for (var t in this.attributes) Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + "=\"", e += E.escape(this.attributes[t]), e += "\"");
		this.classes.length > 0 && (e += " class =\"" + E.escape(wt(this.classes)) + "\""), e += ">";
		for (var n = 0; n < this.children.length; n++) e += this.children[n].toMarkup();
		return e += "</" + this.type + ">", e;
	}
	toText() {
		return this.children.map((e) => e.toText()).join("");
	}
}, tr = class {
	constructor(e) {
		this.text = void 0, this.text = e;
	}
	toNode() {
		return document.createTextNode(this.text);
	}
	toMarkup() {
		return E.escape(this.toText());
	}
	toText() {
		return this.text;
	}
}, X = {
	MathNode: er,
	TextNode: tr,
	SpaceNode: class {
		constructor(e) {
			this.width = void 0, this.character = void 0, this.width = e, this.character = e >= .05555 && e <= .05556 ? " " : e >= .1666 && e <= .1667 ? " " : e >= .2222 && e <= .2223 ? " " : e >= .2777 && e <= .2778 ? "  " : e >= -.05556 && e <= -.05555 ? " ⁣" : e >= -.1667 && e <= -.1666 ? " ⁣" : e >= -.2223 && e <= -.2222 ? " ⁣" : e >= -.2778 && e <= -.2777 ? " ⁣" : null;
		}
		toNode() {
			if (this.character) return document.createTextNode(this.character);
			var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
			return e.setAttribute("width", k(this.width)), e;
		}
		toMarkup() {
			return this.character ? "<mtext>" + this.character + "</mtext>" : "<mspace width=\"" + k(this.width) + "\"/>";
		}
		toText() {
			return this.character ? this.character : " ";
		}
	},
	newDocumentFragment: $n
}, nr = function(e, t, n) {
	return A[t][e] && A[t][e].replace && e.charCodeAt(0) !== 55349 && !(Kt.hasOwnProperty(e) && n && (n.fontFamily && n.fontFamily.slice(4, 6) === "tt" || n.font && n.font.slice(4, 6) === "tt")) && (e = A[t][e].replace), new X.TextNode(e);
}, rr = function(e) {
	return e.length === 1 ? e[0] : new X.MathNode("mrow", e);
}, ir = function(e, t) {
	if (t.fontFamily === "texttt") return "monospace";
	if (t.fontFamily === "textsf") return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
	if (t.fontShape === "textit" && t.fontWeight === "textbf") return "bold-italic";
	if (t.fontShape === "textit") return "italic";
	if (t.fontWeight === "textbf") return "bold";
	var n = t.font;
	if (!n || n === "mathnormal") return null;
	var r = e.mode;
	if (n === "mathit") return "italic";
	if (n === "boldsymbol") return e.type === "textord" ? "bold" : "bold-italic";
	if (n === "mathbf") return "bold";
	if (n === "mathbb") return "double-struck";
	if (n === "mathsfit") return "sans-serif-italic";
	if (n === "mathfrak") return "fraktur";
	if (n === "mathscr" || n === "mathcal") return "script";
	if (n === "mathsf") return "sans-serif";
	if (n === "mathtt") return "monospace";
	var i = e.text;
	if (["\\imath", "\\jmath"].includes(i)) return null;
	A[r][i] && A[r][i].replace && (i = A[r][i].replace);
	var a = W.fontMap[n].fontName;
	return mt(i, a, r) ? W.fontMap[n].variant : null;
};
function ar(e) {
	if (!e) return !1;
	if (e.type === "mi" && e.children.length === 1) {
		var t = e.children[0];
		return t instanceof tr && t.text === ".";
	}
	if (e.type === "mo" && e.children.length === 1 && e.getAttribute("separator") === "true" && e.getAttribute("lspace") === "0em" && e.getAttribute("rspace") === "0em") {
		var n = e.children[0];
		return n instanceof tr && n.text === ",";
	}
	return !1;
}
var or = function(e, t, n) {
	if (e.length === 1) {
		var r = Z(e[0], t);
		return n && r instanceof er && r.type === "mo" && (r.setAttribute("lspace", "0em"), r.setAttribute("rspace", "0em")), [r];
	}
	for (var i = [], a, o = 0; o < e.length; o++) {
		var s = Z(e[o], t);
		if (s instanceof er && a instanceof er) {
			if (s.type === "mtext" && a.type === "mtext" && s.getAttribute("mathvariant") === a.getAttribute("mathvariant")) {
				a.children.push(...s.children);
				continue;
			}
			if (s.type === "mn" && a.type === "mn") {
				a.children.push(...s.children);
				continue;
			}
			if (ar(s) && a.type === "mn") {
				a.children.push(...s.children);
				continue;
			}
			if (s.type === "mn" && ar(a)) s.children = [...a.children, ...s.children], i.pop();
			else if ((s.type === "msup" || s.type === "msub") && s.children.length >= 1 && (a.type === "mn" || ar(a))) {
				var c = s.children[0];
				c instanceof er && c.type === "mn" && (c.children = [...a.children, ...c.children], i.pop());
			} else if (a.type === "mi" && a.children.length === 1) {
				var l = a.children[0];
				if (l instanceof tr && l.text === "̸" && (s.type === "mo" || s.type === "mi" || s.type === "mn")) {
					var u = s.children[0];
					u instanceof tr && u.text.length > 0 && (u.text = u.text.slice(0, 1) + "̸" + u.text.slice(1), i.pop());
				}
			}
		}
		i.push(s), a = s;
	}
	return i;
}, sr = function(e, t, n) {
	return rr(or(e, t, n));
}, Z = function(e, t) {
	if (!e) return new X.MathNode("mrow");
	if (Rn[e.type]) return Rn[e.type](e, t);
	throw new T("Got group of unknown type: '" + e.type + "'");
};
function cr(e, t, n, r, i) {
	var a = or(e, n), o = a.length === 1 && a[0] instanceof er && ["mrow", "mtable"].includes(a[0].type) ? a[0] : new X.MathNode("mrow", a), s = new X.MathNode("annotation", [new X.TextNode(t)]);
	s.setAttribute("encoding", "application/x-tex");
	var c = new X.MathNode("semantics", [o, s]), l = new X.MathNode("math", [c]);
	l.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML"), r && l.setAttribute("display", "block");
	var u = i ? "katex" : "katex-mathml";
	return W.makeSpan([u], [l]);
}
var lr = function(e) {
	return new bt({
		style: e.displayMode ? D.DISPLAY : D.TEXT,
		maxSize: e.maxSize,
		minRuleThickness: e.minRuleThickness
	});
}, ur = function(e, t) {
	if (t.displayMode) {
		var n = ["katex-display"];
		t.leqno && n.push("leqno"), t.fleqn && n.push("fleqn"), e = W.makeSpan(n, [e]);
	}
	return e;
}, dr = function(e, t, n) {
	var r = lr(n), i;
	if (n.output === "mathml") return cr(e, t, r, n.displayMode, !0);
	if (n.output === "html") {
		var a = Qn(e, r);
		i = W.makeSpan(["katex"], [a]);
	} else {
		var o = cr(e, t, r, n.displayMode, !1), s = Qn(e, r);
		i = W.makeSpan(["katex"], [o, s]);
	}
	return ur(i, n);
}, fr = function(e, t, n) {
	var r = Qn(e, lr(n));
	return ur(W.makeSpan(["katex"], [r]), n);
}, pr = {
	widehat: "^",
	widecheck: "ˇ",
	widetilde: "~",
	utilde: "~",
	overleftarrow: "←",
	underleftarrow: "←",
	xleftarrow: "←",
	overrightarrow: "→",
	underrightarrow: "→",
	xrightarrow: "→",
	underbrace: "⏟",
	overbrace: "⏞",
	overgroup: "⏠",
	undergroup: "⏡",
	overleftrightarrow: "↔",
	underleftrightarrow: "↔",
	xleftrightarrow: "↔",
	Overrightarrow: "⇒",
	xRightarrow: "⇒",
	overleftharpoon: "↼",
	xleftharpoonup: "↼",
	overrightharpoon: "⇀",
	xrightharpoonup: "⇀",
	xLeftarrow: "⇐",
	xLeftrightarrow: "⇔",
	xhookleftarrow: "↩",
	xhookrightarrow: "↪",
	xmapsto: "↦",
	xrightharpoondown: "⇁",
	xleftharpoondown: "↽",
	xrightleftharpoons: "⇌",
	xleftrightharpoons: "⇋",
	xtwoheadleftarrow: "↞",
	xtwoheadrightarrow: "↠",
	xlongequal: "=",
	xtofrom: "⇄",
	xrightleftarrows: "⇄",
	xrightequilibrium: "⇌",
	xleftequilibrium: "⇋",
	"\\cdrightarrow": "→",
	"\\cdleftarrow": "←",
	"\\cdlongequal": "="
}, mr = function(e) {
	var t = new X.MathNode("mo", [new X.TextNode(pr[e.replace(/^\\/, "")])]);
	return t.setAttribute("stretchy", "true"), t;
}, hr = {
	overrightarrow: [
		["rightarrow"],
		.888,
		522,
		"xMaxYMin"
	],
	overleftarrow: [
		["leftarrow"],
		.888,
		522,
		"xMinYMin"
	],
	underrightarrow: [
		["rightarrow"],
		.888,
		522,
		"xMaxYMin"
	],
	underleftarrow: [
		["leftarrow"],
		.888,
		522,
		"xMinYMin"
	],
	xrightarrow: [
		["rightarrow"],
		1.469,
		522,
		"xMaxYMin"
	],
	"\\cdrightarrow": [
		["rightarrow"],
		3,
		522,
		"xMaxYMin"
	],
	xleftarrow: [
		["leftarrow"],
		1.469,
		522,
		"xMinYMin"
	],
	"\\cdleftarrow": [
		["leftarrow"],
		3,
		522,
		"xMinYMin"
	],
	Overrightarrow: [
		["doublerightarrow"],
		.888,
		560,
		"xMaxYMin"
	],
	xRightarrow: [
		["doublerightarrow"],
		1.526,
		560,
		"xMaxYMin"
	],
	xLeftarrow: [
		["doubleleftarrow"],
		1.526,
		560,
		"xMinYMin"
	],
	overleftharpoon: [
		["leftharpoon"],
		.888,
		522,
		"xMinYMin"
	],
	xleftharpoonup: [
		["leftharpoon"],
		.888,
		522,
		"xMinYMin"
	],
	xleftharpoondown: [
		["leftharpoondown"],
		.888,
		522,
		"xMinYMin"
	],
	overrightharpoon: [
		["rightharpoon"],
		.888,
		522,
		"xMaxYMin"
	],
	xrightharpoonup: [
		["rightharpoon"],
		.888,
		522,
		"xMaxYMin"
	],
	xrightharpoondown: [
		["rightharpoondown"],
		.888,
		522,
		"xMaxYMin"
	],
	xlongequal: [
		["longequal"],
		.888,
		334,
		"xMinYMin"
	],
	"\\cdlongequal": [
		["longequal"],
		3,
		334,
		"xMinYMin"
	],
	xtwoheadleftarrow: [
		["twoheadleftarrow"],
		.888,
		334,
		"xMinYMin"
	],
	xtwoheadrightarrow: [
		["twoheadrightarrow"],
		.888,
		334,
		"xMaxYMin"
	],
	overleftrightarrow: [
		["leftarrow", "rightarrow"],
		.888,
		522
	],
	overbrace: [
		[
			"leftbrace",
			"midbrace",
			"rightbrace"
		],
		1.6,
		548
	],
	underbrace: [
		[
			"leftbraceunder",
			"midbraceunder",
			"rightbraceunder"
		],
		1.6,
		548
	],
	underleftrightarrow: [
		["leftarrow", "rightarrow"],
		.888,
		522
	],
	xleftrightarrow: [
		["leftarrow", "rightarrow"],
		1.75,
		522
	],
	xLeftrightarrow: [
		["doubleleftarrow", "doublerightarrow"],
		1.75,
		560
	],
	xrightleftharpoons: [
		["leftharpoondownplus", "rightharpoonplus"],
		1.75,
		716
	],
	xleftrightharpoons: [
		["leftharpoonplus", "rightharpoondownplus"],
		1.75,
		716
	],
	xhookleftarrow: [
		["leftarrow", "righthook"],
		1.08,
		522
	],
	xhookrightarrow: [
		["lefthook", "rightarrow"],
		1.08,
		522
	],
	overlinesegment: [
		["leftlinesegment", "rightlinesegment"],
		.888,
		522
	],
	underlinesegment: [
		["leftlinesegment", "rightlinesegment"],
		.888,
		522
	],
	overgroup: [
		["leftgroup", "rightgroup"],
		.888,
		342
	],
	undergroup: [
		["leftgroupunder", "rightgroupunder"],
		.888,
		342
	],
	xmapsto: [
		["leftmapsto", "rightarrow"],
		1.5,
		522
	],
	xtofrom: [
		["leftToFrom", "rightToFrom"],
		1.75,
		528
	],
	xrightleftarrows: [
		["baraboveleftarrow", "rightarrowabovebar"],
		1.75,
		901
	],
	xrightequilibrium: [
		["baraboveshortleftharpoon", "rightharpoonaboveshortbar"],
		1.75,
		716
	],
	xleftequilibrium: [
		["shortbaraboveleftharpoon", "shortrightharpoonabovebar"],
		1.75,
		716
	]
}, gr = function(e) {
	return e.type === "ordgroup" ? e.body.length : 1;
}, _r = {
	encloseSpan: function(e, t, n, r, i) {
		var a, o = e.height + e.depth + n + r;
		if (/fbox|color|angl/.test(t)) {
			if (a = W.makeSpan(["stretchy", t], [], i), t === "fbox") {
				var s = i.color && i.getColor();
				s && (a.style.borderColor = s);
			}
		} else {
			var c = [];
			/^[bx]cancel$/.test(t) && c.push(new It({
				x1: "0",
				y1: "0",
				x2: "100%",
				y2: "100%",
				"stroke-width": "0.046em"
			})), /^x?cancel$/.test(t) && c.push(new It({
				x1: "0",
				y1: "100%",
				x2: "100%",
				y2: "0",
				"stroke-width": "0.046em"
			}));
			var l = new Pt(c, {
				width: "100%",
				height: k(o)
			});
			a = W.makeSvgSpan([], [l], i);
		}
		return a.height = o, a.style.height = k(o), a;
	},
	mathMLnode: mr,
	svgSpan: function(e, t) {
		function n() {
			var n = 4e5, r = e.label.slice(1);
			if ([
				"widehat",
				"widecheck",
				"widetilde",
				"utilde"
			].includes(r)) {
				var i = gr(e.base), a, o, s;
				if (i > 5) r === "widehat" || r === "widecheck" ? (a = 420, n = 2364, s = .42, o = r + "4") : (a = 312, n = 2340, s = .34, o = "tilde4");
				else {
					var c = [
						1,
						1,
						2,
						2,
						3,
						3
					][i];
					r === "widehat" || r === "widecheck" ? (n = [
						0,
						1062,
						2364,
						2364,
						2364
					][c], a = [
						0,
						239,
						300,
						360,
						420
					][c], s = [
						0,
						.24,
						.3,
						.3,
						.36,
						.42
					][c], o = r + c) : (n = [
						0,
						600,
						1033,
						2339,
						2340
					][c], a = [
						0,
						260,
						286,
						306,
						312
					][c], s = [
						0,
						.26,
						.286,
						.3,
						.306,
						.34
					][c], o = "tilde" + c);
				}
				var l = new Pt([new Ft(o)], {
					width: "100%",
					height: k(s),
					viewBox: "0 0 " + n + " " + a,
					preserveAspectRatio: "none"
				});
				return {
					span: W.makeSvgSpan([], [l], t),
					minWidth: 0,
					height: s
				};
			}
			var u = [], d = hr[r], [f, p, m] = d, h = m / 1e3, g = f.length, _, v;
			if (g === 1) {
				var y = d[3];
				_ = ["hide-tail"], v = [y];
			} else if (g === 2) _ = ["halfarrow-left", "halfarrow-right"], v = ["xMinYMin", "xMaxYMin"];
			else if (g === 3) _ = [
				"brace-left",
				"brace-center",
				"brace-right"
			], v = [
				"xMinYMin",
				"xMidYMin",
				"xMaxYMin"
			];
			else throw Error("Correct katexImagesData or update code here to support\n                    " + g + " children.");
			for (var b = 0; b < g; b++) {
				var x = new Pt([new Ft(f[b])], {
					width: "400em",
					height: k(h),
					viewBox: "0 0 " + n + " " + m,
					preserveAspectRatio: v[b] + " slice"
				}), S = W.makeSvgSpan([_[b]], [x], t);
				if (g === 1) return {
					span: S,
					minWidth: p,
					height: h
				};
				S.style.height = k(h), u.push(S);
			}
			return {
				span: W.makeSpan(["stretchy"], u, t),
				minWidth: p,
				height: h
			};
		}
		var { span: r, minWidth: i, height: a } = n();
		return r.height = a, r.style.height = k(a), i > 0 && (r.style.minWidth = k(i)), r;
	}
};
function Q(e, t) {
	if (!e || e.type !== t) throw Error("Expected node of type " + t + ", but got " + (e ? "node of type " + e.type : String(e)));
	return e;
}
function vr(e) {
	var t = yr(e);
	if (!t) throw Error("Expected node of symbol group type, but got " + (e ? "node of type " + e.type : String(e)));
	return t;
}
function yr(e) {
	return e && (e.type === "atom" || Bt.hasOwnProperty(e.type)) ? e : null;
}
var br = (e, t) => {
	var n, r, i;
	e && e.type === "supsub" ? (r = Q(e.base, "accent"), n = r.base, e.base = n, i = Rt(Y(e, t)), e.base = r) : (r = Q(e, "accent"), n = r.base);
	var a = Y(n, t.havingCrampedStyle()), o = r.isShifty && E.isCharacterBox(n), s = 0;
	o && (s = Lt(Y(E.getBaseElem(n), t.havingCrampedStyle())).skew);
	var c = r.label === "\\c", l = c ? a.height + a.depth : Math.min(a.height, t.fontMetrics().xHeight), u;
	if (r.isStretchy) u = _r.svgSpan(r, t), u = W.makeVList({
		positionType: "firstBaseline",
		children: [{
			type: "elem",
			elem: a
		}, {
			type: "elem",
			elem: u,
			wrapperClasses: ["svg-align"],
			wrapperStyle: s > 0 ? {
				width: "calc(100% - " + k(2 * s) + ")",
				marginLeft: k(2 * s)
			} : void 0
		}]
	}, t);
	else {
		var d, f;
		r.label === "\\vec" ? (d = W.staticSvg("vec", t), f = W.svgData.vec[1]) : (d = W.makeOrd({
			mode: r.mode,
			text: r.label
		}, t, "textord"), d = Lt(d), d.italic = 0, f = d.width, c && (l += d.depth)), u = W.makeSpan(["accent-body"], [d]);
		var p = r.label === "\\textcircled";
		p && (u.classes.push("accent-full"), l = a.height);
		var m = s;
		p || (m -= f / 2), u.style.left = k(m), r.label === "\\textcircled" && (u.style.top = ".2em"), u = W.makeVList({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: a
				},
				{
					type: "kern",
					size: -l
				},
				{
					type: "elem",
					elem: u
				}
			]
		}, t);
	}
	var h = W.makeSpan(["mord", "accent"], [u], t);
	return i ? (i.children[0] = h, i.height = Math.max(h.height, i.height), i.classes[0] = "mord", i) : h;
}, xr = (e, t) => {
	var n = e.isStretchy ? _r.mathMLnode(e.label) : new X.MathNode("mo", [nr(e.label, e.mode)]), r = new X.MathNode("mover", [Z(e.base, t), n]);
	return r.setAttribute("accent", "true"), r;
}, Sr = new RegExp([
	"\\acute",
	"\\grave",
	"\\ddot",
	"\\tilde",
	"\\bar",
	"\\breve",
	"\\check",
	"\\hat",
	"\\vec",
	"\\dot",
	"\\mathring"
].map((e) => "\\" + e).join("|"));
K({
	type: "accent",
	names: [
		"\\acute",
		"\\grave",
		"\\ddot",
		"\\tilde",
		"\\bar",
		"\\breve",
		"\\check",
		"\\hat",
		"\\vec",
		"\\dot",
		"\\mathring",
		"\\widecheck",
		"\\widehat",
		"\\widetilde",
		"\\overrightarrow",
		"\\overleftarrow",
		"\\Overrightarrow",
		"\\overleftrightarrow",
		"\\overgroup",
		"\\overlinesegment",
		"\\overleftharpoon",
		"\\overrightharpoon"
	],
	props: { numArgs: 1 },
	handler: (e, t) => {
		var n = Bn(t[0]), r = !Sr.test(e.funcName), i = !r || e.funcName === "\\widehat" || e.funcName === "\\widetilde" || e.funcName === "\\widecheck";
		return {
			type: "accent",
			mode: e.parser.mode,
			label: e.funcName,
			isStretchy: r,
			isShifty: i,
			base: n
		};
	},
	htmlBuilder: br,
	mathmlBuilder: xr
}), K({
	type: "accent",
	names: [
		"\\'",
		"\\`",
		"\\^",
		"\\~",
		"\\=",
		"\\u",
		"\\.",
		"\\\"",
		"\\c",
		"\\r",
		"\\H",
		"\\v",
		"\\textcircled"
	],
	props: {
		numArgs: 1,
		allowedInText: !0,
		allowedInMath: !0,
		argTypes: ["primitive"]
	},
	handler: (e, t) => {
		var n = t[0], r = e.parser.mode;
		return r === "math" && (e.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + e.funcName + " works only in text mode"), r = "text"), {
			type: "accent",
			mode: r,
			label: e.funcName,
			isStretchy: !1,
			isShifty: !0,
			base: n
		};
	},
	htmlBuilder: br,
	mathmlBuilder: xr
}), K({
	type: "accentUnder",
	names: [
		"\\underleftarrow",
		"\\underrightarrow",
		"\\underleftrightarrow",
		"\\undergroup",
		"\\underlinesegment",
		"\\utilde"
	],
	props: { numArgs: 1 },
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "accentUnder",
			mode: n.mode,
			label: r,
			base: i
		};
	},
	htmlBuilder: (e, t) => {
		var n = Y(e.base, t), r = _r.svgSpan(e, t), i = e.label === "\\utilde" ? .12 : 0, a = W.makeVList({
			positionType: "top",
			positionData: n.height,
			children: [
				{
					type: "elem",
					elem: r,
					wrapperClasses: ["svg-align"]
				},
				{
					type: "kern",
					size: i
				},
				{
					type: "elem",
					elem: n
				}
			]
		}, t);
		return W.makeSpan(["mord", "accentunder"], [a], t);
	},
	mathmlBuilder: (e, t) => {
		var n = _r.mathMLnode(e.label), r = new X.MathNode("munder", [Z(e.base, t), n]);
		return r.setAttribute("accentunder", "true"), r;
	}
});
var Cr = (e) => {
	var t = new X.MathNode("mpadded", e ? [e] : []);
	return t.setAttribute("width", "+0.6em"), t.setAttribute("lspace", "0.3em"), t;
};
K({
	type: "xArrow",
	names: [
		"\\xleftarrow",
		"\\xrightarrow",
		"\\xLeftarrow",
		"\\xRightarrow",
		"\\xleftrightarrow",
		"\\xLeftrightarrow",
		"\\xhookleftarrow",
		"\\xhookrightarrow",
		"\\xmapsto",
		"\\xrightharpoondown",
		"\\xrightharpoonup",
		"\\xleftharpoondown",
		"\\xleftharpoonup",
		"\\xrightleftharpoons",
		"\\xleftrightharpoons",
		"\\xlongequal",
		"\\xtwoheadrightarrow",
		"\\xtwoheadleftarrow",
		"\\xtofrom",
		"\\xrightleftarrows",
		"\\xrightequilibrium",
		"\\xleftequilibrium",
		"\\\\cdrightarrow",
		"\\\\cdleftarrow",
		"\\\\cdlongequal"
	],
	props: {
		numArgs: 1,
		numOptionalArgs: 1
	},
	handler(e, t, n) {
		var { parser: r, funcName: i } = e;
		return {
			type: "xArrow",
			mode: r.mode,
			label: i,
			body: t[0],
			below: n[0]
		};
	},
	htmlBuilder(e, t) {
		var n = t.style, r = t.havingStyle(n.sup()), i = W.wrapFragment(Y(e.body, r, t), t), a = e.label.slice(0, 2) === "\\x" ? "x" : "cd";
		i.classes.push(a + "-arrow-pad");
		var o;
		e.below && (r = t.havingStyle(n.sub()), o = W.wrapFragment(Y(e.below, r, t), t), o.classes.push(a + "-arrow-pad"));
		var s = _r.svgSpan(e, t), c = -t.fontMetrics().axisHeight + .5 * s.height, l = -t.fontMetrics().axisHeight - .5 * s.height - .111;
		(i.depth > .25 || e.label === "\\xleftequilibrium") && (l -= i.depth);
		var u;
		if (o) {
			var d = -t.fontMetrics().axisHeight + o.height + .5 * s.height + .111;
			u = W.makeVList({
				positionType: "individualShift",
				children: [
					{
						type: "elem",
						elem: i,
						shift: l
					},
					{
						type: "elem",
						elem: s,
						shift: c
					},
					{
						type: "elem",
						elem: o,
						shift: d
					}
				]
			}, t);
		} else u = W.makeVList({
			positionType: "individualShift",
			children: [{
				type: "elem",
				elem: i,
				shift: l
			}, {
				type: "elem",
				elem: s,
				shift: c
			}]
		}, t);
		return u.children[0].children[0].children[1].classes.push("svg-align"), W.makeSpan(["mrel", "x-arrow"], [u], t);
	},
	mathmlBuilder(e, t) {
		var n = _r.mathMLnode(e.label);
		n.setAttribute("minsize", e.label.charAt(0) === "x" ? "1.75em" : "3.0em");
		var r;
		if (e.body) {
			var i = Cr(Z(e.body, t));
			if (e.below) {
				var a = Cr(Z(e.below, t));
				r = new X.MathNode("munderover", [
					n,
					a,
					i
				]);
			} else r = new X.MathNode("mover", [n, i]);
		} else if (e.below) {
			var o = Cr(Z(e.below, t));
			r = new X.MathNode("munder", [n, o]);
		} else r = Cr(), r = new X.MathNode("mover", [n, r]);
		return r;
	}
});
var wr = W.makeSpan;
function Tr(e, t) {
	var n = J(e.body, t, !0);
	return wr([e.mclass], n, t);
}
function Er(e, t) {
	var n, r = or(e.body, t);
	return e.mclass === "minner" ? n = new X.MathNode("mpadded", r) : e.mclass === "mord" ? e.isCharacterBox ? (n = r[0], n.type = "mi") : n = new X.MathNode("mi", r) : (e.isCharacterBox ? (n = r[0], n.type = "mo") : n = new X.MathNode("mo", r), e.mclass === "mbin" ? (n.attributes.lspace = "0.22em", n.attributes.rspace = "0.22em") : e.mclass === "mpunct" ? (n.attributes.lspace = "0em", n.attributes.rspace = "0.17em") : e.mclass === "mopen" || e.mclass === "mclose" ? (n.attributes.lspace = "0em", n.attributes.rspace = "0em") : e.mclass === "minner" && (n.attributes.lspace = "0.0556em", n.attributes.width = "+0.1111em")), n;
}
K({
	type: "mclass",
	names: [
		"\\mathord",
		"\\mathbin",
		"\\mathrel",
		"\\mathopen",
		"\\mathclose",
		"\\mathpunct",
		"\\mathinner"
	],
	props: {
		numArgs: 1,
		primitive: !0
	},
	handler(e, t) {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "mclass",
			mode: n.mode,
			mclass: "m" + r.slice(5),
			body: q(i),
			isCharacterBox: E.isCharacterBox(i)
		};
	},
	htmlBuilder: Tr,
	mathmlBuilder: Er
});
var Dr = (e) => {
	var t = e.type === "ordgroup" && e.body.length ? e.body[0] : e;
	return t.type === "atom" && (t.family === "bin" || t.family === "rel") ? "m" + t.family : "mord";
};
K({
	type: "mclass",
	names: ["\\@binrel"],
	props: { numArgs: 2 },
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "mclass",
			mode: n.mode,
			mclass: Dr(t[0]),
			body: q(t[1]),
			isCharacterBox: E.isCharacterBox(t[1])
		};
	}
}), K({
	type: "mclass",
	names: [
		"\\stackrel",
		"\\overset",
		"\\underset"
	],
	props: { numArgs: 2 },
	handler(e, t) {
		var { parser: n, funcName: r } = e, i = t[1], a = t[0], o = r === "\\stackrel" ? "mrel" : Dr(i), s = {
			type: "op",
			mode: i.mode,
			limits: !0,
			alwaysHandleSupSub: !0,
			parentIsSupSub: !1,
			symbol: !1,
			suppressBaseShift: r !== "\\stackrel",
			body: q(i)
		}, c = {
			type: "supsub",
			mode: a.mode,
			base: s,
			sup: r === "\\underset" ? null : a,
			sub: r === "\\underset" ? a : null
		};
		return {
			type: "mclass",
			mode: n.mode,
			mclass: o,
			body: [c],
			isCharacterBox: E.isCharacterBox(c)
		};
	},
	htmlBuilder: Tr,
	mathmlBuilder: Er
}), K({
	type: "pmb",
	names: ["\\pmb"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "pmb",
			mode: n.mode,
			mclass: Dr(t[0]),
			body: q(t[0])
		};
	},
	htmlBuilder(e, t) {
		var n = J(e.body, t, !0), r = W.makeSpan([e.mclass], n, t);
		return r.style.textShadow = "0.02em 0.01em 0.04px", r;
	},
	mathmlBuilder(e, t) {
		var n = or(e.body, t), r = new X.MathNode("mstyle", n);
		return r.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), r;
	}
});
var Or = {
	">": "\\\\cdrightarrow",
	"<": "\\\\cdleftarrow",
	"=": "\\\\cdlongequal",
	A: "\\uparrow",
	V: "\\downarrow",
	"|": "\\Vert",
	".": "no arrow"
}, kr = () => ({
	type: "styling",
	body: [],
	mode: "math",
	style: "display"
}), Ar = (e) => e.type === "textord" && e.text === "@", jr = (e, t) => (e.type === "mathord" || e.type === "atom") && e.text === t;
function Mr(e, t, n) {
	var r = Or[e];
	switch (r) {
		case "\\\\cdrightarrow":
		case "\\\\cdleftarrow": return n.callFunction(r, [t[0]], [t[1]]);
		case "\\uparrow":
		case "\\downarrow":
			var i = n.callFunction("\\\\cdleft", [t[0]], []), a = {
				type: "atom",
				text: r,
				mode: "math",
				family: "rel"
			}, o = {
				type: "ordgroup",
				mode: "math",
				body: [
					i,
					n.callFunction("\\Big", [a], []),
					n.callFunction("\\\\cdright", [t[1]], [])
				]
			};
			return n.callFunction("\\\\cdparent", [o], []);
		case "\\\\cdlongequal": return n.callFunction("\\\\cdlongequal", [], []);
		case "\\Vert": return n.callFunction("\\Big", [{
			type: "textord",
			text: "\\Vert",
			mode: "math"
		}], []);
		default: return {
			type: "textord",
			text: " ",
			mode: "math"
		};
	}
}
function Nr(e) {
	var t = [];
	for (e.gullet.beginGroup(), e.gullet.macros.set("\\cr", "\\\\\\relax"), e.gullet.beginGroup();;) {
		t.push(e.parseExpression(!1, "\\\\")), e.gullet.endGroup(), e.gullet.beginGroup();
		var n = e.fetch().text;
		if (n === "&" || n === "\\\\") e.consume();
		else if (n === "\\end") {
			t[t.length - 1].length === 0 && t.pop();
			break;
		} else throw new T("Expected \\\\ or \\cr or \\end", e.nextToken);
	}
	for (var r = [], i = [r], a = 0; a < t.length; a++) {
		for (var o = t[a], s = kr(), c = 0; c < o.length; c++) if (!Ar(o[c])) s.body.push(o[c]);
		else {
			r.push(s), c += 1;
			var l = vr(o[c]).text, u = [, ,];
			if (u[0] = {
				type: "ordgroup",
				mode: "math",
				body: []
			}, u[1] = {
				type: "ordgroup",
				mode: "math",
				body: []
			}, !("=|.".indexOf(l) > -1)) {
				if ("<>AV".indexOf(l) > -1) for (var d = 0; d < 2; d++) {
					for (var f = !0, p = c + 1; p < o.length; p++) {
						if (jr(o[p], l)) {
							f = !1, c = p;
							break;
						}
						if (Ar(o[p])) throw new T("Missing a " + l + " character to complete a CD arrow.", o[p]);
						u[d].body.push(o[p]);
					}
					if (f) throw new T("Missing a " + l + " character to complete a CD arrow.", o[c]);
				}
				else throw new T("Expected one of \"<>AV=|.\" after @", o[c]);
			}
			var m = {
				type: "styling",
				body: [Mr(l, u, e)],
				mode: "math",
				style: "display"
			};
			r.push(m), s = kr();
		}
		a % 2 == 0 ? r.push(s) : r.shift(), r = [], i.push(r);
	}
	return e.gullet.endGroup(), e.gullet.endGroup(), {
		type: "array",
		mode: "math",
		body: i,
		arraystretch: 1,
		addJot: !0,
		rowGaps: [null],
		cols: Array(i[0].length).fill({
			type: "align",
			align: "c",
			pregap: .25,
			postgap: .25
		}),
		colSeparationType: "CD",
		hLinesBeforeRow: Array(i.length + 1).fill([])
	};
}
K({
	type: "cdlabel",
	names: ["\\\\cdleft", "\\\\cdright"],
	props: { numArgs: 1 },
	handler(e, t) {
		var { parser: n, funcName: r } = e;
		return {
			type: "cdlabel",
			mode: n.mode,
			side: r.slice(4),
			label: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = t.havingStyle(t.style.sup()), r = W.wrapFragment(Y(e.label, n, t), t);
		return r.classes.push("cd-label-" + e.side), r.style.bottom = k(.8 - r.depth), r.height = 0, r.depth = 0, r;
	},
	mathmlBuilder(e, t) {
		var n = new X.MathNode("mrow", [Z(e.label, t)]);
		return n = new X.MathNode("mpadded", [n]), n.setAttribute("width", "0"), e.side === "left" && n.setAttribute("lspace", "-1width"), n.setAttribute("voffset", "0.7em"), n = new X.MathNode("mstyle", [n]), n.setAttribute("displaystyle", "false"), n.setAttribute("scriptlevel", "1"), n;
	}
}), K({
	type: "cdlabelparent",
	names: ["\\\\cdparent"],
	props: { numArgs: 1 },
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "cdlabelparent",
			mode: n.mode,
			fragment: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = W.wrapFragment(Y(e.fragment, t), t);
		return n.classes.push("cd-vert-arrow"), n;
	},
	mathmlBuilder(e, t) {
		return new X.MathNode("mrow", [Z(e.fragment, t)]);
	}
}), K({
	type: "textord",
	names: ["\\@char"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler(e, t) {
		for (var { parser: n } = e, r = Q(t[0], "ordgroup").body, i = "", a = 0; a < r.length; a++) {
			var o = Q(r[a], "textord");
			i += o.text;
		}
		var s = parseInt(i), c;
		if (isNaN(s)) throw new T("\\@char has non-numeric argument " + i);
		if (s < 0 || s >= 1114111) throw new T("\\@char with invalid code point " + i);
		return s <= 65535 ? c = String.fromCharCode(s) : (s -= 65536, c = String.fromCharCode((s >> 10) + 55296, (s & 1023) + 56320)), {
			type: "textord",
			mode: n.mode,
			text: c
		};
	}
});
var Pr = (e, t) => {
	var n = J(e.body, t.withColor(e.color), !1);
	return W.makeFragment(n);
}, Fr = (e, t) => {
	var n = or(e.body, t.withColor(e.color)), r = new X.MathNode("mstyle", n);
	return r.setAttribute("mathcolor", e.color), r;
};
K({
	type: "color",
	names: ["\\textcolor"],
	props: {
		numArgs: 2,
		allowedInText: !0,
		argTypes: ["color", "original"]
	},
	handler(e, t) {
		var { parser: n } = e, r = Q(t[0], "color-token").color, i = t[1];
		return {
			type: "color",
			mode: n.mode,
			color: r,
			body: q(i)
		};
	},
	htmlBuilder: Pr,
	mathmlBuilder: Fr
}), K({
	type: "color",
	names: ["\\color"],
	props: {
		numArgs: 1,
		allowedInText: !0,
		argTypes: ["color"]
	},
	handler(e, t) {
		var { parser: n, breakOnTokenText: r } = e, i = Q(t[0], "color-token").color;
		n.gullet.macros.set("\\current@color", i);
		var a = n.parseExpression(!0, r);
		return {
			type: "color",
			mode: n.mode,
			color: i,
			body: a
		};
	},
	htmlBuilder: Pr,
	mathmlBuilder: Fr
}), K({
	type: "cr",
	names: ["\\\\"],
	props: {
		numArgs: 0,
		numOptionalArgs: 0,
		allowedInText: !0
	},
	handler(e, t, n) {
		var { parser: r } = e, i = r.gullet.future().text === "[" ? r.parseSizeGroup(!0) : null, a = !r.settings.displayMode || !r.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
		return {
			type: "cr",
			mode: r.mode,
			newLine: a,
			size: i && Q(i, "size").value
		};
	},
	htmlBuilder(e, t) {
		var n = W.makeSpan(["mspace"], [], t);
		return e.newLine && (n.classes.push("newline"), e.size && (n.style.marginTop = k(O(e.size, t)))), n;
	},
	mathmlBuilder(e, t) {
		var n = new X.MathNode("mspace");
		return e.newLine && (n.setAttribute("linebreak", "newline"), e.size && n.setAttribute("height", k(O(e.size, t)))), n;
	}
});
var Ir = {
	"\\global": "\\global",
	"\\long": "\\\\globallong",
	"\\\\globallong": "\\\\globallong",
	"\\def": "\\gdef",
	"\\gdef": "\\gdef",
	"\\edef": "\\xdef",
	"\\xdef": "\\xdef",
	"\\let": "\\\\globallet",
	"\\futurelet": "\\\\globalfuture"
}, Lr = (e) => {
	var t = e.text;
	if (/^(?:[\\{}$&#^_]|EOF)$/.test(t)) throw new T("Expected a control sequence", e);
	return t;
}, Rr = (e) => {
	var t = e.gullet.popToken();
	return t.text === "=" && (t = e.gullet.popToken(), t.text === " " && (t = e.gullet.popToken())), t;
}, zr = (e, t, n, r) => {
	var i = e.gullet.macros.get(n.text);
	i ??= (n.noexpand = !0, {
		tokens: [n],
		numArgs: 0,
		unexpandable: !e.gullet.isExpandable(n.text)
	}), e.gullet.macros.set(t, i, r);
};
K({
	type: "internal",
	names: [
		"\\global",
		"\\long",
		"\\\\globallong"
	],
	props: {
		numArgs: 0,
		allowedInText: !0
	},
	handler(e) {
		var { parser: t, funcName: n } = e;
		t.consumeSpaces();
		var r = t.fetch();
		if (Ir[r.text]) return (n === "\\global" || n === "\\\\globallong") && (r.text = Ir[r.text]), Q(t.parseFunction(), "internal");
		throw new T("Invalid token after macro prefix", r);
	}
}), K({
	type: "internal",
	names: [
		"\\def",
		"\\gdef",
		"\\edef",
		"\\xdef"
	],
	props: {
		numArgs: 0,
		allowedInText: !0,
		primitive: !0
	},
	handler(e) {
		var { parser: t, funcName: n } = e, r = t.gullet.popToken(), i = r.text;
		if (/^(?:[\\{}$&#^_]|EOF)$/.test(i)) throw new T("Expected a control sequence", r);
		for (var a = 0, o, s = [[]]; t.gullet.future().text !== "{";) if (r = t.gullet.popToken(), r.text === "#") {
			if (t.gullet.future().text === "{") {
				o = t.gullet.future(), s[a].push("{");
				break;
			}
			if (r = t.gullet.popToken(), !/^[1-9]$/.test(r.text)) throw new T("Invalid argument number \"" + r.text + "\"");
			if (parseInt(r.text) !== a + 1) throw new T("Argument number \"" + r.text + "\" out of order");
			a++, s.push([]);
		} else {
			if (r.text === "EOF") throw new T("Expected a macro definition");
			s[a].push(r.text);
		}
		var { tokens: c } = t.gullet.consumeArg();
		return o && c.unshift(o), (n === "\\edef" || n === "\\xdef") && (c = t.gullet.expandTokens(c), c.reverse()), t.gullet.macros.set(i, {
			tokens: c,
			numArgs: a,
			delimiters: s
		}, n === Ir[n]), {
			type: "internal",
			mode: t.mode
		};
	}
}), K({
	type: "internal",
	names: ["\\let", "\\\\globallet"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		primitive: !0
	},
	handler(e) {
		var { parser: t, funcName: n } = e, r = Lr(t.gullet.popToken());
		return t.gullet.consumeSpaces(), zr(t, r, Rr(t), n === "\\\\globallet"), {
			type: "internal",
			mode: t.mode
		};
	}
}), K({
	type: "internal",
	names: ["\\futurelet", "\\\\globalfuture"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		primitive: !0
	},
	handler(e) {
		var { parser: t, funcName: n } = e, r = Lr(t.gullet.popToken()), i = t.gullet.popToken(), a = t.gullet.popToken();
		return zr(t, r, a, n === "\\\\globalfuture"), t.gullet.pushToken(a), t.gullet.pushToken(i), {
			type: "internal",
			mode: t.mode
		};
	}
});
var Br = function(e, t, n) {
	var r = mt(A.math[e] && A.math[e].replace || e, t, n);
	if (!r) throw Error("Unsupported symbol " + e + " and font size " + t + ".");
	return r;
}, Vr = function(e, t, n, r) {
	var i = n.havingBaseStyle(t), a = W.makeSpan(r.concat(i.sizingClasses(n)), [e], n), o = i.sizeMultiplier / n.sizeMultiplier;
	return a.height *= o, a.depth *= o, a.maxFontSize = i.sizeMultiplier, a;
}, Hr = function(e, t, n) {
	var r = t.havingBaseStyle(n), i = (1 - t.sizeMultiplier / r.sizeMultiplier) * t.fontMetrics().axisHeight;
	e.classes.push("delimcenter"), e.style.top = k(i), e.height -= i, e.depth += i;
}, Ur = function(e, t, n, r, i, a) {
	var o = Vr(W.makeSymbol(e, "Main-Regular", i, r), t, r, a);
	return n && Hr(o, r, t), o;
}, Wr = function(e, t, n, r) {
	return W.makeSymbol(e, "Size" + t + "-Regular", n, r);
}, Gr = function(e, t, n, r, i, a) {
	var o = Wr(e, t, i, r), s = Vr(W.makeSpan(["delimsizing", "size" + t], [o], r), D.TEXT, r, a);
	return n && Hr(s, r, D.TEXT), s;
}, Kr = function(e, t, n) {
	var r = t === "Size1-Regular" ? "delim-size1" : "delim-size4";
	return {
		type: "elem",
		elem: W.makeSpan(["delimsizinginner", r], [W.makeSpan([], [W.makeSymbol(e, t, n)])])
	};
}, qr = function(e, t, n) {
	var r = ut["Size4-Regular"][e.charCodeAt(0)] ? ut["Size4-Regular"][e.charCodeAt(0)][4] : ut["Size1-Regular"][e.charCodeAt(0)][4], i = new Pt([new Ft("inner", ot(e, Math.round(1e3 * t)))], {
		width: k(r),
		height: k(t),
		style: "width:" + k(r),
		viewBox: "0 0 " + 1e3 * r + " " + Math.round(1e3 * t),
		preserveAspectRatio: "xMinYMin"
	}), a = W.makeSvgSpan([], [i], n);
	return a.height = t, a.style.height = k(t), a.style.width = k(r), {
		type: "elem",
		elem: a
	};
}, Jr = .008, Yr = {
	type: "kern",
	size: -1 * Jr
}, Xr = [
	"|",
	"\\lvert",
	"\\rvert",
	"\\vert"
], Zr = [
	"\\|",
	"\\lVert",
	"\\rVert",
	"\\Vert"
], Qr = function(e, t, n, r, i, a) {
	var o, s, c, l, u = "", d = 0;
	o = c = l = e, s = null;
	var f = "Size1-Regular";
	e === "\\uparrow" ? c = l = "⏐" : e === "\\Uparrow" ? c = l = "‖" : e === "\\downarrow" ? o = c = "⏐" : e === "\\Downarrow" ? o = c = "‖" : e === "\\updownarrow" ? (o = "\\uparrow", c = "⏐", l = "\\downarrow") : e === "\\Updownarrow" ? (o = "\\Uparrow", c = "‖", l = "\\Downarrow") : Xr.includes(e) ? (c = "∣", u = "vert", d = 333) : Zr.includes(e) ? (c = "∥", u = "doublevert", d = 556) : e === "[" || e === "\\lbrack" ? (o = "⎡", c = "⎢", l = "⎣", f = "Size4-Regular", u = "lbrack", d = 667) : e === "]" || e === "\\rbrack" ? (o = "⎤", c = "⎥", l = "⎦", f = "Size4-Regular", u = "rbrack", d = 667) : e === "\\lfloor" || e === "⌊" ? (c = o = "⎢", l = "⎣", f = "Size4-Regular", u = "lfloor", d = 667) : e === "\\lceil" || e === "⌈" ? (o = "⎡", c = l = "⎢", f = "Size4-Regular", u = "lceil", d = 667) : e === "\\rfloor" || e === "⌋" ? (c = o = "⎥", l = "⎦", f = "Size4-Regular", u = "rfloor", d = 667) : e === "\\rceil" || e === "⌉" ? (o = "⎤", c = l = "⎥", f = "Size4-Regular", u = "rceil", d = 667) : e === "(" || e === "\\lparen" ? (o = "⎛", c = "⎜", l = "⎝", f = "Size4-Regular", u = "lparen", d = 875) : e === ")" || e === "\\rparen" ? (o = "⎞", c = "⎟", l = "⎠", f = "Size4-Regular", u = "rparen", d = 875) : e === "\\{" || e === "\\lbrace" ? (o = "⎧", s = "⎨", l = "⎩", c = "⎪", f = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (o = "⎫", s = "⎬", l = "⎭", c = "⎪", f = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (o = "⎧", l = "⎩", c = "⎪", f = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (o = "⎫", l = "⎭", c = "⎪", f = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (o = "⎧", l = "⎭", c = "⎪", f = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (o = "⎫", l = "⎩", c = "⎪", f = "Size4-Regular");
	var p = Br(o, f, i), m = p.height + p.depth, h = Br(c, f, i), g = h.height + h.depth, _ = Br(l, f, i), v = _.height + _.depth, y = 0, b = 1;
	if (s !== null) {
		var x = Br(s, f, i);
		y = x.height + x.depth, b = 2;
	}
	var S = m + v + y, C = S + Math.max(0, Math.ceil((t - S) / (b * g))) * b * g, ee = r.fontMetrics().axisHeight;
	n && (ee *= r.sizeMultiplier);
	var te = C / 2 - ee, w = [];
	if (u.length > 0) {
		var ne = C - m - v, re = Math.round(C * 1e3), ie = ct(u, Math.round(ne * 1e3)), ae = new Ft(u, ie), oe = (d / 1e3).toFixed(3) + "em", se = (re / 1e3).toFixed(3) + "em", ce = new Pt([ae], {
			width: oe,
			height: se,
			viewBox: "0 0 " + d + " " + re
		}), le = W.makeSvgSpan([], [ce], r);
		le.height = re / 1e3, le.style.width = oe, le.style.height = se, w.push({
			type: "elem",
			elem: le
		});
	} else {
		if (w.push(Kr(l, f, i)), w.push(Yr), s === null) {
			var ue = C - m - v + 2 * Jr;
			w.push(qr(c, ue, r));
		} else {
			var de = (C - m - v - y) / 2 + 2 * Jr;
			w.push(qr(c, de, r)), w.push(Yr), w.push(Kr(s, f, i)), w.push(Yr), w.push(qr(c, de, r));
		}
		w.push(Yr), w.push(Kr(o, f, i));
	}
	var fe = r.havingBaseStyle(D.TEXT), pe = W.makeVList({
		positionType: "bottom",
		positionData: te,
		children: w
	}, fe);
	return Vr(W.makeSpan(["delimsizing", "mult"], [pe], fe), D.TEXT, r, a);
}, $r = 80, ei = .08, ti = function(e, t, n, r, i) {
	var a = new Pt([new Ft(e, at(e, r, n))], {
		width: "400em",
		height: k(t),
		viewBox: "0 0 400000 " + n,
		preserveAspectRatio: "xMinYMin slice"
	});
	return W.makeSvgSpan(["hide-tail"], [a], i);
}, ni = function(e, t) {
	var n = t.havingBaseSizing(), r = fi("\\surd", e * n.sizeMultiplier, ui, n), i = n.sizeMultiplier, a = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), o, s = 0, c = 0, l = 0, u;
	return r.type === "small" ? (l = 1e3 + 1e3 * a + $r, e < 1 ? i = 1 : e < 1.4 && (i = .7), s = (1 + a + ei) / i, c = (1 + a) / i, o = ti("sqrtMain", s, l, a, t), o.style.minWidth = "0.853em", u = .833 / i) : r.type === "large" ? (l = (1e3 + $r) * oi[r.size], c = (oi[r.size] + a) / i, s = (oi[r.size] + a + ei) / i, o = ti("sqrtSize" + r.size, s, l, a, t), o.style.minWidth = "1.02em", u = 1 / i) : (s = e + a + ei, c = e + a, l = Math.floor(1e3 * e + a) + $r, o = ti("sqrtTall", s, l, a, t), o.style.minWidth = "0.742em", u = 1.056), o.height = c, o.style.height = k(s), {
		span: o,
		advanceWidth: u,
		ruleWidth: (t.fontMetrics().sqrtRuleThickness + a) * i
	};
}, ri = [
	"(",
	"\\lparen",
	")",
	"\\rparen",
	"[",
	"\\lbrack",
	"]",
	"\\rbrack",
	"\\{",
	"\\lbrace",
	"\\}",
	"\\rbrace",
	"\\lfloor",
	"\\rfloor",
	"⌊",
	"⌋",
	"\\lceil",
	"\\rceil",
	"⌈",
	"⌉",
	"\\surd"
], ii = [
	"\\uparrow",
	"\\downarrow",
	"\\updownarrow",
	"\\Uparrow",
	"\\Downarrow",
	"\\Updownarrow",
	"|",
	"\\|",
	"\\vert",
	"\\Vert",
	"\\lvert",
	"\\rvert",
	"\\lVert",
	"\\rVert",
	"\\lgroup",
	"\\rgroup",
	"⟮",
	"⟯",
	"\\lmoustache",
	"\\rmoustache",
	"⎰",
	"⎱"
], ai = [
	"<",
	">",
	"\\langle",
	"\\rangle",
	"/",
	"\\backslash",
	"\\lt",
	"\\gt"
], oi = [
	0,
	1.2,
	1.8,
	2.4,
	3
], si = function(e, t, n, r, i) {
	if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), ri.includes(e) || ai.includes(e)) return Gr(e, t, !1, n, r, i);
	if (ii.includes(e)) return Qr(e, oi[t], !1, n, r, i);
	throw new T("Illegal delimiter: '" + e + "'");
}, ci = [
	{
		type: "small",
		style: D.SCRIPTSCRIPT
	},
	{
		type: "small",
		style: D.SCRIPT
	},
	{
		type: "small",
		style: D.TEXT
	},
	{
		type: "large",
		size: 1
	},
	{
		type: "large",
		size: 2
	},
	{
		type: "large",
		size: 3
	},
	{
		type: "large",
		size: 4
	}
], li = [
	{
		type: "small",
		style: D.SCRIPTSCRIPT
	},
	{
		type: "small",
		style: D.SCRIPT
	},
	{
		type: "small",
		style: D.TEXT
	},
	{ type: "stack" }
], ui = [
	{
		type: "small",
		style: D.SCRIPTSCRIPT
	},
	{
		type: "small",
		style: D.SCRIPT
	},
	{
		type: "small",
		style: D.TEXT
	},
	{
		type: "large",
		size: 1
	},
	{
		type: "large",
		size: 2
	},
	{
		type: "large",
		size: 3
	},
	{
		type: "large",
		size: 4
	},
	{ type: "stack" }
], di = function(e) {
	if (e.type === "small") return "Main-Regular";
	if (e.type === "large") return "Size" + e.size + "-Regular";
	if (e.type === "stack") return "Size4-Regular";
	throw Error("Add support for delim type '" + e.type + "' here.");
}, fi = function(e, t, n, r) {
	for (var i = Math.min(2, 3 - r.style.size); i < n.length && n[i].type !== "stack"; i++) {
		var a = Br(e, di(n[i]), "math"), o = a.height + a.depth;
		if (n[i].type === "small") {
			var s = r.havingBaseStyle(n[i].style);
			o *= s.sizeMultiplier;
		}
		if (o > t) return n[i];
	}
	return n[n.length - 1];
}, pi = function(e, t, n, r, i, a) {
	e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
	var o = ai.includes(e) ? ci : ri.includes(e) ? ui : li, s = fi(e, t, o, r);
	return s.type === "small" ? Ur(e, s.style, n, r, i, a) : s.type === "large" ? Gr(e, s.size, n, r, i, a) : Qr(e, t, n, r, i, a);
}, mi = {
	sqrtImage: ni,
	sizedDelim: si,
	sizeToMaxHeight: oi,
	customSizedDelim: pi,
	leftRightDelim: function(e, t, n, r, i, a) {
		var o = r.fontMetrics().axisHeight * r.sizeMultiplier, s = 901, c = 5 / r.fontMetrics().ptPerEm, l = Math.max(t - o, n + o);
		return pi(e, Math.max(l / 500 * s, 2 * l - c), !0, r, i, a);
	}
}, hi = {
	"\\bigl": {
		mclass: "mopen",
		size: 1
	},
	"\\Bigl": {
		mclass: "mopen",
		size: 2
	},
	"\\biggl": {
		mclass: "mopen",
		size: 3
	},
	"\\Biggl": {
		mclass: "mopen",
		size: 4
	},
	"\\bigr": {
		mclass: "mclose",
		size: 1
	},
	"\\Bigr": {
		mclass: "mclose",
		size: 2
	},
	"\\biggr": {
		mclass: "mclose",
		size: 3
	},
	"\\Biggr": {
		mclass: "mclose",
		size: 4
	},
	"\\bigm": {
		mclass: "mrel",
		size: 1
	},
	"\\Bigm": {
		mclass: "mrel",
		size: 2
	},
	"\\biggm": {
		mclass: "mrel",
		size: 3
	},
	"\\Biggm": {
		mclass: "mrel",
		size: 4
	},
	"\\big": {
		mclass: "mord",
		size: 1
	},
	"\\Big": {
		mclass: "mord",
		size: 2
	},
	"\\bigg": {
		mclass: "mord",
		size: 3
	},
	"\\Bigg": {
		mclass: "mord",
		size: 4
	}
}, gi = /* @__PURE__ */ "(,\\lparen,),\\rparen,[,\\lbrack,],\\rbrack,\\{,\\lbrace,\\},\\rbrace,\\lfloor,\\rfloor,⌊,⌋,\\lceil,\\rceil,⌈,⌉,<,>,\\langle,⟨,\\rangle,⟩,\\lt,\\gt,\\lvert,\\rvert,\\lVert,\\rVert,\\lgroup,\\rgroup,⟮,⟯,\\lmoustache,\\rmoustache,⎰,⎱,/,\\backslash,|,\\vert,\\|,\\Vert,\\uparrow,\\Uparrow,\\downarrow,\\Downarrow,\\updownarrow,\\Updownarrow,.".split(",");
function _i(e, t) {
	var n = yr(e);
	if (n && gi.includes(n.text)) return n;
	throw n ? new T("Invalid delimiter '" + n.text + "' after '" + t.funcName + "'", e) : new T("Invalid delimiter type '" + e.type + "'", e);
}
K({
	type: "delimsizing",
	names: [
		"\\bigl",
		"\\Bigl",
		"\\biggl",
		"\\Biggl",
		"\\bigr",
		"\\Bigr",
		"\\biggr",
		"\\Biggr",
		"\\bigm",
		"\\Bigm",
		"\\biggm",
		"\\Biggm",
		"\\big",
		"\\Big",
		"\\bigg",
		"\\Bigg"
	],
	props: {
		numArgs: 1,
		argTypes: ["primitive"]
	},
	handler: (e, t) => {
		var n = _i(t[0], e);
		return {
			type: "delimsizing",
			mode: e.parser.mode,
			size: hi[e.funcName].size,
			mclass: hi[e.funcName].mclass,
			delim: n.text
		};
	},
	htmlBuilder: (e, t) => e.delim === "." ? W.makeSpan([e.mclass]) : mi.sizedDelim(e.delim, e.size, t, e.mode, [e.mclass]),
	mathmlBuilder: (e) => {
		var t = [];
		e.delim !== "." && t.push(nr(e.delim, e.mode));
		var n = new X.MathNode("mo", t);
		e.mclass === "mopen" || e.mclass === "mclose" ? n.setAttribute("fence", "true") : n.setAttribute("fence", "false"), n.setAttribute("stretchy", "true");
		var r = k(mi.sizeToMaxHeight[e.size]);
		return n.setAttribute("minsize", r), n.setAttribute("maxsize", r), n;
	}
});
function vi(e) {
	if (!e.body) throw Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
K({
	type: "leftright-right",
	names: ["\\right"],
	props: {
		numArgs: 1,
		primitive: !0
	},
	handler: (e, t) => {
		var n = e.parser.gullet.macros.get("\\current@color");
		if (n && typeof n != "string") throw new T("\\current@color set to non-string in \\right");
		return {
			type: "leftright-right",
			mode: e.parser.mode,
			delim: _i(t[0], e).text,
			color: n
		};
	}
}), K({
	type: "leftright",
	names: ["\\left"],
	props: {
		numArgs: 1,
		primitive: !0
	},
	handler: (e, t) => {
		var n = _i(t[0], e), r = e.parser;
		++r.leftrightDepth;
		var i = r.parseExpression(!1);
		--r.leftrightDepth, r.expect("\\right", !1);
		var a = Q(r.parseFunction(), "leftright-right");
		return {
			type: "leftright",
			mode: r.mode,
			body: i,
			left: n.text,
			right: a.delim,
			rightColor: a.color
		};
	},
	htmlBuilder: (e, t) => {
		vi(e);
		for (var n = J(e.body, t, !0, ["mopen", "mclose"]), r = 0, i = 0, a = !1, o = 0; o < n.length; o++) n[o].isMiddle ? a = !0 : (r = Math.max(n[o].height, r), i = Math.max(n[o].depth, i));
		r *= t.sizeMultiplier, i *= t.sizeMultiplier;
		var s;
		if (s = e.left === "." ? Xn(t, ["mopen"]) : mi.leftRightDelim(e.left, r, i, t, e.mode, ["mopen"]), n.unshift(s), a) for (var c = 1; c < n.length; c++) {
			var l = n[c].isMiddle;
			l && (n[c] = mi.leftRightDelim(l.delim, r, i, l.options, e.mode, []));
		}
		var u;
		if (e.right === ".") u = Xn(t, ["mclose"]);
		else {
			var d = e.rightColor ? t.withColor(e.rightColor) : t;
			u = mi.leftRightDelim(e.right, r, i, d, e.mode, ["mclose"]);
		}
		return n.push(u), W.makeSpan(["minner"], n, t);
	},
	mathmlBuilder: (e, t) => {
		vi(e);
		var n = or(e.body, t);
		if (e.left !== ".") {
			var r = new X.MathNode("mo", [nr(e.left, e.mode)]);
			r.setAttribute("fence", "true"), n.unshift(r);
		}
		if (e.right !== ".") {
			var i = new X.MathNode("mo", [nr(e.right, e.mode)]);
			i.setAttribute("fence", "true"), e.rightColor && i.setAttribute("mathcolor", e.rightColor), n.push(i);
		}
		return rr(n);
	}
}), K({
	type: "middle",
	names: ["\\middle"],
	props: {
		numArgs: 1,
		primitive: !0
	},
	handler: (e, t) => {
		var n = _i(t[0], e);
		if (!e.parser.leftrightDepth) throw new T("\\middle without preceding \\left", n);
		return {
			type: "middle",
			mode: e.parser.mode,
			delim: n.text
		};
	},
	htmlBuilder: (e, t) => {
		var n;
		if (e.delim === ".") n = Xn(t, []);
		else {
			n = mi.sizedDelim(e.delim, 1, t, e.mode, []);
			var r = {
				delim: e.delim,
				options: t
			};
			n.isMiddle = r;
		}
		return n;
	},
	mathmlBuilder: (e, t) => {
		var n = e.delim === "\\vert" || e.delim === "|" ? nr("|", "text") : nr(e.delim, e.mode), r = new X.MathNode("mo", [n]);
		return r.setAttribute("fence", "true"), r.setAttribute("lspace", "0.05em"), r.setAttribute("rspace", "0.05em"), r;
	}
});
var yi = (e, t) => {
	var n = W.wrapFragment(Y(e.body, t), t), r = e.label.slice(1), i = t.sizeMultiplier, a, o = 0, s = E.isCharacterBox(e.body);
	if (r === "sout") a = W.makeSpan(["stretchy", "sout"]), a.height = t.fontMetrics().defaultRuleThickness / i, o = -.5 * t.fontMetrics().xHeight;
	else if (r === "phase") {
		var c = O({
			number: .6,
			unit: "pt"
		}, t), l = O({
			number: .35,
			unit: "ex"
		}, t), u = t.havingBaseSizing();
		i /= u.sizeMultiplier;
		var d = n.height + n.depth + c + l;
		n.style.paddingLeft = k(d / 2 + c);
		var f = Math.floor(1e3 * d * i), p = new Pt([new Ft("phase", rt(f))], {
			width: "400em",
			height: k(f / 1e3),
			viewBox: "0 0 400000 " + f,
			preserveAspectRatio: "xMinYMin slice"
		});
		a = W.makeSvgSpan(["hide-tail"], [p], t), a.style.height = k(d), o = n.depth + c + l;
	} else {
		/cancel/.test(r) ? s || n.classes.push("cancel-pad") : r === "angl" ? n.classes.push("anglpad") : n.classes.push("boxpad");
		var m = 0, h = 0, g = 0;
		/box/.test(r) ? (g = Math.max(t.fontMetrics().fboxrule, t.minRuleThickness), m = t.fontMetrics().fboxsep + (r === "colorbox" ? 0 : g), h = m) : r === "angl" ? (g = Math.max(t.fontMetrics().defaultRuleThickness, t.minRuleThickness), m = 4 * g, h = Math.max(0, .25 - n.depth)) : (m = s ? .2 : 0, h = m), a = _r.encloseSpan(n, r, m, h, t), /fbox|boxed|fcolorbox/.test(r) ? (a.style.borderStyle = "solid", a.style.borderWidth = k(g)) : r === "angl" && g !== .049 && (a.style.borderTopWidth = k(g), a.style.borderRightWidth = k(g)), o = n.depth + h, e.backgroundColor && (a.style.backgroundColor = e.backgroundColor, e.borderColor && (a.style.borderColor = e.borderColor));
	}
	var _;
	if (e.backgroundColor) _ = W.makeVList({
		positionType: "individualShift",
		children: [{
			type: "elem",
			elem: a,
			shift: o
		}, {
			type: "elem",
			elem: n,
			shift: 0
		}]
	}, t);
	else {
		var v = /cancel|phase/.test(r) ? ["svg-align"] : [];
		_ = W.makeVList({
			positionType: "individualShift",
			children: [{
				type: "elem",
				elem: n,
				shift: 0
			}, {
				type: "elem",
				elem: a,
				shift: o,
				wrapperClasses: v
			}]
		}, t);
	}
	return /cancel/.test(r) && (_.height = n.height, _.depth = n.depth), /cancel/.test(r) && !s ? W.makeSpan(["mord", "cancel-lap"], [_], t) : W.makeSpan(["mord"], [_], t);
}, bi = (e, t) => {
	var n = 0, r = new X.MathNode(e.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [Z(e.body, t)]);
	switch (e.label) {
		case "\\cancel":
			r.setAttribute("notation", "updiagonalstrike");
			break;
		case "\\bcancel":
			r.setAttribute("notation", "downdiagonalstrike");
			break;
		case "\\phase":
			r.setAttribute("notation", "phasorangle");
			break;
		case "\\sout":
			r.setAttribute("notation", "horizontalstrike");
			break;
		case "\\fbox":
			r.setAttribute("notation", "box");
			break;
		case "\\angl":
			r.setAttribute("notation", "actuarial");
			break;
		case "\\fcolorbox":
		case "\\colorbox":
			if (n = t.fontMetrics().fboxsep * t.fontMetrics().ptPerEm, r.setAttribute("width", "+" + 2 * n + "pt"), r.setAttribute("height", "+" + 2 * n + "pt"), r.setAttribute("lspace", n + "pt"), r.setAttribute("voffset", n + "pt"), e.label === "\\fcolorbox") {
				var i = Math.max(t.fontMetrics().fboxrule, t.minRuleThickness);
				r.setAttribute("style", "border: " + i + "em solid " + String(e.borderColor));
			}
			break;
		case "\\xcancel": r.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
	}
	return e.backgroundColor && r.setAttribute("mathbackground", e.backgroundColor), r;
};
K({
	type: "enclose",
	names: ["\\colorbox"],
	props: {
		numArgs: 2,
		allowedInText: !0,
		argTypes: ["color", "text"]
	},
	handler(e, t, n) {
		var { parser: r, funcName: i } = e, a = Q(t[0], "color-token").color, o = t[1];
		return {
			type: "enclose",
			mode: r.mode,
			label: i,
			backgroundColor: a,
			body: o
		};
	},
	htmlBuilder: yi,
	mathmlBuilder: bi
}), K({
	type: "enclose",
	names: ["\\fcolorbox"],
	props: {
		numArgs: 3,
		allowedInText: !0,
		argTypes: [
			"color",
			"color",
			"text"
		]
	},
	handler(e, t, n) {
		var { parser: r, funcName: i } = e, a = Q(t[0], "color-token").color, o = Q(t[1], "color-token").color, s = t[2];
		return {
			type: "enclose",
			mode: r.mode,
			label: i,
			backgroundColor: o,
			borderColor: a,
			body: s
		};
	},
	htmlBuilder: yi,
	mathmlBuilder: bi
}), K({
	type: "enclose",
	names: ["\\fbox"],
	props: {
		numArgs: 1,
		argTypes: ["hbox"],
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "enclose",
			mode: n.mode,
			label: "\\fbox",
			body: t[0]
		};
	}
}), K({
	type: "enclose",
	names: [
		"\\cancel",
		"\\bcancel",
		"\\xcancel",
		"\\sout",
		"\\phase"
	],
	props: { numArgs: 1 },
	handler(e, t) {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "enclose",
			mode: n.mode,
			label: r,
			body: i
		};
	},
	htmlBuilder: yi,
	mathmlBuilder: bi
}), K({
	type: "enclose",
	names: ["\\angl"],
	props: {
		numArgs: 1,
		argTypes: ["hbox"],
		allowedInText: !1
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "enclose",
			mode: n.mode,
			label: "\\angl",
			body: t[0]
		};
	}
});
var xi = {};
function Si(e) {
	for (var { type: t, names: n, props: r, handler: i, htmlBuilder: a, mathmlBuilder: o } = e, s = {
		type: t,
		numArgs: r.numArgs || 0,
		allowedInText: !1,
		numOptionalArgs: 0,
		handler: i
	}, c = 0; c < n.length; ++c) xi[n[c]] = s;
	a && (Ln[t] = a), o && (Rn[t] = o);
}
var Ci = {};
function $(e, t) {
	Ci[e] = t;
}
function wi(e) {
	var t = [];
	e.consumeSpaces();
	var n = e.fetch().text;
	for (n === "\\relax" && (e.consume(), e.consumeSpaces(), n = e.fetch().text); n === "\\hline" || n === "\\hdashline";) e.consume(), t.push(n === "\\hdashline"), e.consumeSpaces(), n = e.fetch().text;
	return t;
}
var Ti = (e) => {
	if (!e.parser.settings.displayMode) throw new T("{" + e.envName + "} can be used only in display mode.");
};
function Ei(e) {
	if (e.indexOf("ed") === -1) return e.indexOf("*") === -1;
}
function Di(e, t, n) {
	var { hskipBeforeAndAfter: r, addJot: i, cols: a, arraystretch: o, colSeparationType: s, autoTag: c, singleRow: l, emptySingleRow: u, maxNumCols: d, leqno: f } = t;
	if (e.gullet.beginGroup(), l || e.gullet.macros.set("\\cr", "\\\\\\relax"), !o) {
		var p = e.gullet.expandMacroAsText("\\arraystretch");
		if (p == null) o = 1;
		else if (o = parseFloat(p), !o || o < 0) throw new T("Invalid \\arraystretch: " + p);
	}
	e.gullet.beginGroup();
	var m = [], h = [m], g = [], _ = [], v = c == null ? void 0 : [];
	function y() {
		c && e.gullet.macros.set("\\@eqnsw", "1", !0);
	}
	function b() {
		v && (e.gullet.macros.get("\\df@tag") ? (v.push(e.subparse([new ve("\\df@tag")])), e.gullet.macros.set("\\df@tag", void 0, !0)) : v.push(!!c && e.gullet.macros.get("\\@eqnsw") === "1"));
	}
	for (y(), _.push(wi(e));;) {
		var x = e.parseExpression(!1, l ? "\\end" : "\\\\");
		e.gullet.endGroup(), e.gullet.beginGroup(), x = {
			type: "ordgroup",
			mode: e.mode,
			body: x
		}, n && (x = {
			type: "styling",
			mode: e.mode,
			style: n,
			body: [x]
		}), m.push(x);
		var S = e.fetch().text;
		if (S === "&") {
			if (d && m.length === d) {
				if (l || s) throw new T("Too many tab characters: &", e.nextToken);
				e.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
			}
			e.consume();
		} else if (S === "\\end") {
			b(), m.length === 1 && x.type === "styling" && x.body[0].body.length === 0 && (h.length > 1 || !u) && h.pop(), _.length < h.length + 1 && _.push([]);
			break;
		} else if (S === "\\\\") {
			e.consume();
			var C = void 0;
			e.gullet.future().text !== " " && (C = e.parseSizeGroup(!0)), g.push(C ? C.value : null), b(), _.push(wi(e)), m = [], h.push(m), y();
		} else throw new T("Expected & or \\\\ or \\cr or \\end", e.nextToken);
	}
	return e.gullet.endGroup(), e.gullet.endGroup(), {
		type: "array",
		mode: e.mode,
		addJot: i,
		arraystretch: o,
		body: h,
		cols: a,
		rowGaps: g,
		hskipBeforeAndAfter: r,
		hLinesBeforeRow: _,
		colSeparationType: s,
		tags: v,
		leqno: f
	};
}
function Oi(e) {
	return e.slice(0, 1) === "d" ? "display" : "text";
}
var ki = function(e, t) {
	var n, r, i = e.body.length, a = e.hLinesBeforeRow, o = 0, s = Array(i), c = [], l = Math.max(t.fontMetrics().arrayRuleWidth, t.minRuleThickness), u = 1 / t.fontMetrics().ptPerEm, d = 5 * u;
	e.colSeparationType && e.colSeparationType === "small" && (d = .2778 * (t.havingStyle(D.SCRIPT).sizeMultiplier / t.sizeMultiplier));
	var f = e.colSeparationType === "CD" ? O({
		number: 3,
		unit: "ex"
	}, t) : 12 * u, p = 3 * u, m = e.arraystretch * f, h = .7 * m, g = .3 * m, _ = 0;
	function v(e) {
		for (var t = 0; t < e.length; ++t) t > 0 && (_ += .25), c.push({
			pos: _,
			isDashed: e[t]
		});
	}
	for (v(a[0]), n = 0; n < e.body.length; ++n) {
		var y = e.body[n], b = h, x = g;
		o < y.length && (o = y.length);
		var S = Array(y.length);
		for (r = 0; r < y.length; ++r) {
			var C = Y(y[r], t);
			x < C.depth && (x = C.depth), b < C.height && (b = C.height), S[r] = C;
		}
		var ee = e.rowGaps[n], te = 0;
		ee && (te = O(ee, t), te > 0 && (te += g, x < te && (x = te), te = 0)), e.addJot && (x += p), S.height = b, S.depth = x, _ += b, S.pos = _, _ += x + te, s[n] = S, v(a[n + 1]);
	}
	var w = _ / 2 + t.fontMetrics().axisHeight, ne = e.cols || [], re = [], ie, ae, oe = [];
	if (e.tags && e.tags.some((e) => e)) for (n = 0; n < i; ++n) {
		var se = s[n], ce = se.pos - w, le = e.tags[n], ue = void 0;
		ue = le === !0 ? W.makeSpan(["eqn-num"], [], t) : le === !1 ? W.makeSpan([], [], t) : W.makeSpan([], J(le, t, !0), t), ue.depth = se.depth, ue.height = se.height, oe.push({
			type: "elem",
			elem: ue,
			shift: ce
		});
	}
	for (r = 0, ae = 0; r < o || ae < ne.length; ++r, ++ae) {
		for (var de = ne[ae] || {}, fe = !0; de.type === "separator";) {
			if (fe || (ie = W.makeSpan(["arraycolsep"], []), ie.style.width = k(t.fontMetrics().doubleRuleSep), re.push(ie)), de.separator === "|" || de.separator === ":") {
				var pe = de.separator === "|" ? "solid" : "dashed", me = W.makeSpan(["vertical-separator"], [], t);
				me.style.height = k(_), me.style.borderRightWidth = k(l), me.style.borderRightStyle = pe, me.style.margin = "0 " + k(-l / 2);
				var he = _ - w;
				he && (me.style.verticalAlign = k(-he)), re.push(me);
			} else throw new T("Invalid separator type: " + de.separator);
			ae++, de = ne[ae] || {}, fe = !1;
		}
		if (!(r >= o)) {
			var ge = void 0;
			(r > 0 || e.hskipBeforeAndAfter) && (ge = E.deflt(de.pregap, d), ge !== 0 && (ie = W.makeSpan(["arraycolsep"], []), ie.style.width = k(ge), re.push(ie)));
			var _e = [];
			for (n = 0; n < i; ++n) {
				var ve = s[n], ye = ve[r];
				if (ye) {
					var be = ve.pos - w;
					ye.depth = ve.depth, ye.height = ve.height, _e.push({
						type: "elem",
						elem: ye,
						shift: be
					});
				}
			}
			_e = W.makeVList({
				positionType: "individualShift",
				children: _e
			}, t), _e = W.makeSpan(["col-align-" + (de.align || "c")], [_e]), re.push(_e), (r < o - 1 || e.hskipBeforeAndAfter) && (ge = E.deflt(de.postgap, d), ge !== 0 && (ie = W.makeSpan(["arraycolsep"], []), ie.style.width = k(ge), re.push(ie)));
		}
	}
	if (s = W.makeSpan(["mtable"], re), c.length > 0) {
		for (var xe = W.makeLineSpan("hline", t, l), Se = W.makeLineSpan("hdashline", t, l), Ce = [{
			type: "elem",
			elem: s,
			shift: 0
		}]; c.length > 0;) {
			var we = c.pop(), Te = we.pos - w;
			we.isDashed ? Ce.push({
				type: "elem",
				elem: Se,
				shift: Te
			}) : Ce.push({
				type: "elem",
				elem: xe,
				shift: Te
			});
		}
		s = W.makeVList({
			positionType: "individualShift",
			children: Ce
		}, t);
	}
	if (oe.length === 0) return W.makeSpan(["mord"], [s], t);
	var Ee = W.makeVList({
		positionType: "individualShift",
		children: oe
	}, t);
	return Ee = W.makeSpan(["tag"], [Ee], t), W.makeFragment([s, Ee]);
}, Ai = {
	c: "center ",
	l: "left ",
	r: "right "
}, ji = function(e, t) {
	for (var n = [], r = new X.MathNode("mtd", [], ["mtr-glue"]), i = new X.MathNode("mtd", [], ["mml-eqn-num"]), a = 0; a < e.body.length; a++) {
		for (var o = e.body[a], s = [], c = 0; c < o.length; c++) s.push(new X.MathNode("mtd", [Z(o[c], t)]));
		e.tags && e.tags[a] && (s.unshift(r), s.push(r), e.leqno ? s.unshift(i) : s.push(i)), n.push(new X.MathNode("mtr", s));
	}
	var l = new X.MathNode("mtable", n), u = e.arraystretch === .5 ? .1 : .16 + e.arraystretch - 1 + (e.addJot ? .09 : 0);
	l.setAttribute("rowspacing", k(u));
	var d = "", f = "";
	if (e.cols && e.cols.length > 0) {
		var p = e.cols, m = "", h = !1, g = 0, _ = p.length;
		p[0].type === "separator" && (d += "top ", g = 1), p[p.length - 1].type === "separator" && (d += "bottom ", --_);
		for (var v = g; v < _; v++) p[v].type === "align" ? (f += Ai[p[v].align], h && (m += "none "), h = !0) : p[v].type === "separator" && h && (m += p[v].separator === "|" ? "solid " : "dashed ", h = !1);
		l.setAttribute("columnalign", f.trim()), /[sd]/.test(m) && l.setAttribute("columnlines", m.trim());
	}
	if (e.colSeparationType === "align") {
		for (var y = e.cols || [], b = "", x = 1; x < y.length; x++) b += x % 2 ? "0em " : "1em ";
		l.setAttribute("columnspacing", b.trim());
	} else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? l.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? l.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? l.setAttribute("columnspacing", "0.5em") : l.setAttribute("columnspacing", "1em");
	var S = "", C = e.hLinesBeforeRow;
	d += C[0].length > 0 ? "left " : "", d += C[C.length - 1].length > 0 ? "right " : "";
	for (var ee = 1; ee < C.length - 1; ee++) S += C[ee].length === 0 ? "none " : C[ee][0] ? "dashed " : "solid ";
	return /[sd]/.test(S) && l.setAttribute("rowlines", S.trim()), d !== "" && (l = new X.MathNode("menclose", [l]), l.setAttribute("notation", d.trim())), e.arraystretch && e.arraystretch < 1 && (l = new X.MathNode("mstyle", [l]), l.setAttribute("scriptlevel", "1")), l;
}, Mi = function(e, t) {
	e.envName.indexOf("ed") === -1 && Ti(e);
	var n = [], r = e.envName.indexOf("at") > -1 ? "alignat" : "align", i = e.envName === "split", a = Di(e.parser, {
		cols: n,
		addJot: !0,
		autoTag: i ? void 0 : Ei(e.envName),
		emptySingleRow: !0,
		colSeparationType: r,
		maxNumCols: i ? 2 : void 0,
		leqno: e.parser.settings.leqno
	}, "display"), o, s = 0, c = {
		type: "ordgroup",
		mode: e.mode,
		body: []
	};
	if (t[0] && t[0].type === "ordgroup") {
		for (var l = "", u = 0; u < t[0].body.length; u++) {
			var d = Q(t[0].body[u], "textord");
			l += d.text;
		}
		o = Number(l), s = o * 2;
	}
	var f = !s;
	a.body.forEach(function(e) {
		for (var t = 1; t < e.length; t += 2) Q(Q(e[t], "styling").body[0], "ordgroup").body.unshift(c);
		if (f) s < e.length && (s = e.length);
		else {
			var n = e.length / 2;
			if (o < n) throw new T("Too many math in a row: " + ("expected " + o + ", but got " + n), e[0]);
		}
	});
	for (var p = 0; p < s; ++p) {
		var m = "r", h = 0;
		p % 2 == 1 ? m = "l" : p > 0 && f && (h = 1), n[p] = {
			type: "align",
			align: m,
			pregap: h,
			postgap: 0
		};
	}
	return a.colSeparationType = f ? "align" : "alignat", a;
};
Si({
	type: "array",
	names: ["array", "darray"],
	props: { numArgs: 1 },
	handler(e, t) {
		var n = (yr(t[0]) ? [t[0]] : Q(t[0], "ordgroup").body).map(function(e) {
			var t = vr(e).text;
			if ("lcr".indexOf(t) !== -1) return {
				type: "align",
				align: t
			};
			if (t === "|") return {
				type: "separator",
				separator: "|"
			};
			if (t === ":") return {
				type: "separator",
				separator: ":"
			};
			throw new T("Unknown column alignment: " + t, e);
		}), r = {
			cols: n,
			hskipBeforeAndAfter: !0,
			maxNumCols: n.length
		};
		return Di(e.parser, r, Oi(e.envName));
	},
	htmlBuilder: ki,
	mathmlBuilder: ji
}), Si({
	type: "array",
	names: [
		"matrix",
		"pmatrix",
		"bmatrix",
		"Bmatrix",
		"vmatrix",
		"Vmatrix",
		"matrix*",
		"pmatrix*",
		"bmatrix*",
		"Bmatrix*",
		"vmatrix*",
		"Vmatrix*"
	],
	props: { numArgs: 0 },
	handler(e) {
		var t = {
			matrix: null,
			pmatrix: ["(", ")"],
			bmatrix: ["[", "]"],
			Bmatrix: ["\\{", "\\}"],
			vmatrix: ["|", "|"],
			Vmatrix: ["\\Vert", "\\Vert"]
		}[e.envName.replace("*", "")], n = "c", r = {
			hskipBeforeAndAfter: !1,
			cols: [{
				type: "align",
				align: n
			}]
		};
		if (e.envName.charAt(e.envName.length - 1) === "*") {
			var i = e.parser;
			if (i.consumeSpaces(), i.fetch().text === "[") {
				if (i.consume(), i.consumeSpaces(), n = i.fetch().text, "lcr".indexOf(n) === -1) throw new T("Expected l or c or r", i.nextToken);
				i.consume(), i.consumeSpaces(), i.expect("]"), i.consume(), r.cols = [{
					type: "align",
					align: n
				}];
			}
		}
		var a = Di(e.parser, r, Oi(e.envName)), o = Math.max(0, ...a.body.map((e) => e.length));
		return a.cols = Array(o).fill({
			type: "align",
			align: n
		}), t ? {
			type: "leftright",
			mode: e.mode,
			body: [a],
			left: t[0],
			right: t[1],
			rightColor: void 0
		} : a;
	},
	htmlBuilder: ki,
	mathmlBuilder: ji
}), Si({
	type: "array",
	names: ["smallmatrix"],
	props: { numArgs: 0 },
	handler(e) {
		var t = Di(e.parser, { arraystretch: .5 }, "script");
		return t.colSeparationType = "small", t;
	},
	htmlBuilder: ki,
	mathmlBuilder: ji
}), Si({
	type: "array",
	names: ["subarray"],
	props: { numArgs: 1 },
	handler(e, t) {
		var n = (yr(t[0]) ? [t[0]] : Q(t[0], "ordgroup").body).map(function(e) {
			var t = vr(e).text;
			if ("lc".indexOf(t) !== -1) return {
				type: "align",
				align: t
			};
			throw new T("Unknown column alignment: " + t, e);
		});
		if (n.length > 1) throw new T("{subarray} can contain only one column");
		var r = {
			cols: n,
			hskipBeforeAndAfter: !1,
			arraystretch: .5
		};
		if (r = Di(e.parser, r, "script"), r.body.length > 0 && r.body[0].length > 1) throw new T("{subarray} can contain only one column");
		return r;
	},
	htmlBuilder: ki,
	mathmlBuilder: ji
}), Si({
	type: "array",
	names: [
		"cases",
		"dcases",
		"rcases",
		"drcases"
	],
	props: { numArgs: 0 },
	handler(e) {
		var t = Di(e.parser, {
			arraystretch: 1.2,
			cols: [{
				type: "align",
				align: "l",
				pregap: 0,
				postgap: 1
			}, {
				type: "align",
				align: "l",
				pregap: 0,
				postgap: 0
			}]
		}, Oi(e.envName));
		return {
			type: "leftright",
			mode: e.mode,
			body: [t],
			left: e.envName.indexOf("r") > -1 ? "." : "\\{",
			right: e.envName.indexOf("r") > -1 ? "\\}" : ".",
			rightColor: void 0
		};
	},
	htmlBuilder: ki,
	mathmlBuilder: ji
}), Si({
	type: "array",
	names: [
		"align",
		"align*",
		"aligned",
		"split"
	],
	props: { numArgs: 0 },
	handler: Mi,
	htmlBuilder: ki,
	mathmlBuilder: ji
}), Si({
	type: "array",
	names: [
		"gathered",
		"gather",
		"gather*"
	],
	props: { numArgs: 0 },
	handler(e) {
		["gather", "gather*"].includes(e.envName) && Ti(e);
		var t = {
			cols: [{
				type: "align",
				align: "c"
			}],
			addJot: !0,
			colSeparationType: "gather",
			autoTag: Ei(e.envName),
			emptySingleRow: !0,
			leqno: e.parser.settings.leqno
		};
		return Di(e.parser, t, "display");
	},
	htmlBuilder: ki,
	mathmlBuilder: ji
}), Si({
	type: "array",
	names: [
		"alignat",
		"alignat*",
		"alignedat"
	],
	props: { numArgs: 1 },
	handler: Mi,
	htmlBuilder: ki,
	mathmlBuilder: ji
}), Si({
	type: "array",
	names: ["equation", "equation*"],
	props: { numArgs: 0 },
	handler(e) {
		Ti(e);
		var t = {
			autoTag: Ei(e.envName),
			emptySingleRow: !0,
			singleRow: !0,
			maxNumCols: 1,
			leqno: e.parser.settings.leqno
		};
		return Di(e.parser, t, "display");
	},
	htmlBuilder: ki,
	mathmlBuilder: ji
}), Si({
	type: "array",
	names: ["CD"],
	props: { numArgs: 0 },
	handler(e) {
		return Ti(e), Nr(e.parser);
	},
	htmlBuilder: ki,
	mathmlBuilder: ji
}), $("\\nonumber", "\\gdef\\@eqnsw{0}"), $("\\notag", "\\nonumber"), K({
	type: "text",
	names: ["\\hline", "\\hdashline"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		allowedInMath: !0
	},
	handler(e, t) {
		throw new T(e.funcName + " valid only within array environment");
	}
});
var Ni = xi;
K({
	type: "environment",
	names: ["\\begin", "\\end"],
	props: {
		numArgs: 1,
		argTypes: ["text"]
	},
	handler(e, t) {
		var { parser: n, funcName: r } = e, i = t[0];
		if (i.type !== "ordgroup") throw new T("Invalid environment name", i);
		for (var a = "", o = 0; o < i.body.length; ++o) a += Q(i.body[o], "textord").text;
		if (r === "\\begin") {
			if (!Ni.hasOwnProperty(a)) throw new T("No such environment: " + a, i);
			var s = Ni[a], { args: c, optArgs: l } = n.parseArguments("\\begin{" + a + "}", s), u = {
				mode: n.mode,
				envName: a,
				parser: n
			}, d = s.handler(u, c, l);
			n.expect("\\end", !1);
			var f = n.nextToken, p = Q(n.parseFunction(), "environment");
			if (p.name !== a) throw new T("Mismatch: \\begin{" + a + "} matched by \\end{" + p.name + "}", f);
			return d;
		}
		return {
			type: "environment",
			mode: n.mode,
			name: a,
			nameGroup: i
		};
	}
});
var Pi = (e, t) => {
	var n = e.font, r = t.withFont(n);
	return Y(e.body, r);
}, Fi = (e, t) => {
	var n = e.font, r = t.withFont(n);
	return Z(e.body, r);
}, Ii = {
	"\\Bbb": "\\mathbb",
	"\\bold": "\\mathbf",
	"\\frak": "\\mathfrak",
	"\\bm": "\\boldsymbol"
};
K({
	type: "font",
	names: [
		"\\mathrm",
		"\\mathit",
		"\\mathbf",
		"\\mathnormal",
		"\\mathsfit",
		"\\mathbb",
		"\\mathcal",
		"\\mathfrak",
		"\\mathscr",
		"\\mathsf",
		"\\mathtt",
		"\\Bbb",
		"\\bold",
		"\\frak"
	],
	props: {
		numArgs: 1,
		allowedInArgument: !0
	},
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = Bn(t[0]), a = r;
		return a in Ii && (a = Ii[a]), {
			type: "font",
			mode: n.mode,
			font: a.slice(1),
			body: i
		};
	},
	htmlBuilder: Pi,
	mathmlBuilder: Fi
}), K({
	type: "mclass",
	names: ["\\boldsymbol", "\\bm"],
	props: { numArgs: 1 },
	handler: (e, t) => {
		var { parser: n } = e, r = t[0], i = E.isCharacterBox(r);
		return {
			type: "mclass",
			mode: n.mode,
			mclass: Dr(r),
			body: [{
				type: "font",
				mode: n.mode,
				font: "boldsymbol",
				body: r
			}],
			isCharacterBox: i
		};
	}
}), K({
	type: "font",
	names: [
		"\\rm",
		"\\sf",
		"\\tt",
		"\\bf",
		"\\it",
		"\\cal"
	],
	props: {
		numArgs: 0,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n, funcName: r, breakOnTokenText: i } = e, { mode: a } = n, o = n.parseExpression(!0, i);
		return {
			type: "font",
			mode: a,
			font: "math" + r.slice(1),
			body: {
				type: "ordgroup",
				mode: n.mode,
				body: o
			}
		};
	},
	htmlBuilder: Pi,
	mathmlBuilder: Fi
});
var Li = (e, t) => {
	var n = t;
	return e === "display" ? n = n.id >= D.SCRIPT.id ? n.text() : D.DISPLAY : e === "text" && n.size === D.DISPLAY.size ? n = D.TEXT : e === "script" ? n = D.SCRIPT : e === "scriptscript" && (n = D.SCRIPTSCRIPT), n;
}, Ri = (e, t) => {
	var n = Li(e.size, t.style), r = n.fracNum(), i = n.fracDen(), a = t.havingStyle(r), o = Y(e.numer, a, t);
	if (e.continued) {
		var s = 8.5 / t.fontMetrics().ptPerEm, c = 3.5 / t.fontMetrics().ptPerEm;
		o.height = o.height < s ? s : o.height, o.depth = o.depth < c ? c : o.depth;
	}
	a = t.havingStyle(i);
	var l = Y(e.denom, a, t), u, d, f;
	e.hasBarLine ? (e.barSize ? (d = O(e.barSize, t), u = W.makeLineSpan("frac-line", t, d)) : u = W.makeLineSpan("frac-line", t), d = u.height, f = u.height) : (u = null, d = 0, f = t.fontMetrics().defaultRuleThickness);
	var p, m, h;
	n.size === D.DISPLAY.size || e.size === "display" ? (p = t.fontMetrics().num1, m = d > 0 ? 3 * f : 7 * f, h = t.fontMetrics().denom1) : (d > 0 ? (p = t.fontMetrics().num2, m = f) : (p = t.fontMetrics().num3, m = 3 * f), h = t.fontMetrics().denom2);
	var g;
	if (u) {
		var _ = t.fontMetrics().axisHeight;
		p - o.depth - (_ + .5 * d) < m && (p += m - (p - o.depth - (_ + .5 * d))), _ - .5 * d - (l.height - h) < m && (h += m - (_ - .5 * d - (l.height - h)));
		var v = -(_ - .5 * d);
		g = W.makeVList({
			positionType: "individualShift",
			children: [
				{
					type: "elem",
					elem: l,
					shift: h
				},
				{
					type: "elem",
					elem: u,
					shift: v
				},
				{
					type: "elem",
					elem: o,
					shift: -p
				}
			]
		}, t);
	} else {
		var y = p - o.depth - (l.height - h);
		y < m && (p += .5 * (m - y), h += .5 * (m - y)), g = W.makeVList({
			positionType: "individualShift",
			children: [{
				type: "elem",
				elem: l,
				shift: h
			}, {
				type: "elem",
				elem: o,
				shift: -p
			}]
		}, t);
	}
	a = t.havingStyle(n), g.height *= a.sizeMultiplier / t.sizeMultiplier, g.depth *= a.sizeMultiplier / t.sizeMultiplier;
	var b = n.size === D.DISPLAY.size ? t.fontMetrics().delim1 : n.size === D.SCRIPTSCRIPT.size ? t.havingStyle(D.SCRIPT).fontMetrics().delim2 : t.fontMetrics().delim2, x, S;
	return x = e.leftDelim == null ? Xn(t, ["mopen"]) : mi.customSizedDelim(e.leftDelim, b, !0, t.havingStyle(n), e.mode, ["mopen"]), S = e.continued ? W.makeSpan([]) : e.rightDelim == null ? Xn(t, ["mclose"]) : mi.customSizedDelim(e.rightDelim, b, !0, t.havingStyle(n), e.mode, ["mclose"]), W.makeSpan(["mord"].concat(a.sizingClasses(t)), [
		x,
		W.makeSpan(["mfrac"], [g]),
		S
	], t);
}, zi = (e, t) => {
	var n = new X.MathNode("mfrac", [Z(e.numer, t), Z(e.denom, t)]);
	if (!e.hasBarLine) n.setAttribute("linethickness", "0px");
	else if (e.barSize) {
		var r = O(e.barSize, t);
		n.setAttribute("linethickness", k(r));
	}
	var i = Li(e.size, t.style);
	if (i.size !== t.style.size) {
		n = new X.MathNode("mstyle", [n]);
		var a = i.size === D.DISPLAY.size ? "true" : "false";
		n.setAttribute("displaystyle", a), n.setAttribute("scriptlevel", "0");
	}
	if (e.leftDelim != null || e.rightDelim != null) {
		var o = [];
		if (e.leftDelim != null) {
			var s = new X.MathNode("mo", [new X.TextNode(e.leftDelim.replace("\\", ""))]);
			s.setAttribute("fence", "true"), o.push(s);
		}
		if (o.push(n), e.rightDelim != null) {
			var c = new X.MathNode("mo", [new X.TextNode(e.rightDelim.replace("\\", ""))]);
			c.setAttribute("fence", "true"), o.push(c);
		}
		return rr(o);
	}
	return n;
};
K({
	type: "genfrac",
	names: [
		"\\dfrac",
		"\\frac",
		"\\tfrac",
		"\\dbinom",
		"\\binom",
		"\\tbinom",
		"\\\\atopfrac",
		"\\\\bracefrac",
		"\\\\brackfrac"
	],
	props: {
		numArgs: 2,
		allowedInArgument: !0
	},
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = t[0], a = t[1], o, s = null, c = null, l = "auto";
		switch (r) {
			case "\\dfrac":
			case "\\frac":
			case "\\tfrac":
				o = !0;
				break;
			case "\\\\atopfrac":
				o = !1;
				break;
			case "\\dbinom":
			case "\\binom":
			case "\\tbinom":
				o = !1, s = "(", c = ")";
				break;
			case "\\\\bracefrac":
				o = !1, s = "\\{", c = "\\}";
				break;
			case "\\\\brackfrac":
				o = !1, s = "[", c = "]";
				break;
			default: throw Error("Unrecognized genfrac command");
		}
		switch (r) {
			case "\\dfrac":
			case "\\dbinom":
				l = "display";
				break;
			case "\\tfrac":
			case "\\tbinom": l = "text";
		}
		return {
			type: "genfrac",
			mode: n.mode,
			continued: !1,
			numer: i,
			denom: a,
			hasBarLine: o,
			leftDelim: s,
			rightDelim: c,
			size: l,
			barSize: null
		};
	},
	htmlBuilder: Ri,
	mathmlBuilder: zi
}), K({
	type: "genfrac",
	names: ["\\cfrac"],
	props: { numArgs: 2 },
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = t[0], a = t[1];
		return {
			type: "genfrac",
			mode: n.mode,
			continued: !0,
			numer: i,
			denom: a,
			hasBarLine: !0,
			leftDelim: null,
			rightDelim: null,
			size: "display",
			barSize: null
		};
	}
}), K({
	type: "infix",
	names: [
		"\\over",
		"\\choose",
		"\\atop",
		"\\brace",
		"\\brack"
	],
	props: {
		numArgs: 0,
		infix: !0
	},
	handler(e) {
		var { parser: t, funcName: n, token: r } = e, i;
		switch (n) {
			case "\\over":
				i = "\\frac";
				break;
			case "\\choose":
				i = "\\binom";
				break;
			case "\\atop":
				i = "\\\\atopfrac";
				break;
			case "\\brace":
				i = "\\\\bracefrac";
				break;
			case "\\brack":
				i = "\\\\brackfrac";
				break;
			default: throw Error("Unrecognized infix genfrac command");
		}
		return {
			type: "infix",
			mode: t.mode,
			replaceWith: i,
			token: r
		};
	}
});
var Bi = [
	"display",
	"text",
	"script",
	"scriptscript"
], Vi = function(e) {
	var t = null;
	return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
K({
	type: "genfrac",
	names: ["\\genfrac"],
	props: {
		numArgs: 6,
		allowedInArgument: !0,
		argTypes: [
			"math",
			"math",
			"size",
			"text",
			"math",
			"math"
		]
	},
	handler(e, t) {
		var { parser: n } = e, r = t[4], i = t[5], a = Bn(t[0]), o = a.type === "atom" && a.family === "open" ? Vi(a.text) : null, s = Bn(t[1]), c = s.type === "atom" && s.family === "close" ? Vi(s.text) : null, l = Q(t[2], "size"), u, d = null;
		l.isBlank ? u = !0 : (d = l.value, u = d.number > 0);
		var f = "auto", p = t[3];
		if (p.type === "ordgroup") {
			if (p.body.length > 0) {
				var m = Q(p.body[0], "textord");
				f = Bi[Number(m.text)];
			}
		} else p = Q(p, "textord"), f = Bi[Number(p.text)];
		return {
			type: "genfrac",
			mode: n.mode,
			numer: r,
			denom: i,
			continued: !1,
			hasBarLine: u,
			barSize: d,
			leftDelim: o,
			rightDelim: c,
			size: f
		};
	},
	htmlBuilder: Ri,
	mathmlBuilder: zi
}), K({
	type: "infix",
	names: ["\\above"],
	props: {
		numArgs: 1,
		argTypes: ["size"],
		infix: !0
	},
	handler(e, t) {
		var { parser: n, funcName: r, token: i } = e;
		return {
			type: "infix",
			mode: n.mode,
			replaceWith: "\\\\abovefrac",
			size: Q(t[0], "size").value,
			token: i
		};
	}
}), K({
	type: "genfrac",
	names: ["\\\\abovefrac"],
	props: {
		numArgs: 3,
		argTypes: [
			"math",
			"size",
			"math"
		]
	},
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = t[0], a = De(Q(t[1], "infix").size), o = t[2], s = a.number > 0;
		return {
			type: "genfrac",
			mode: n.mode,
			numer: i,
			denom: o,
			continued: !1,
			hasBarLine: s,
			barSize: a,
			leftDelim: null,
			rightDelim: null,
			size: "auto"
		};
	},
	htmlBuilder: Ri,
	mathmlBuilder: zi
});
var Hi = (e, t) => {
	var n = t.style, r, i;
	e.type === "supsub" ? (r = e.sup ? Y(e.sup, t.havingStyle(n.sup()), t) : Y(e.sub, t.havingStyle(n.sub()), t), i = Q(e.base, "horizBrace")) : i = Q(e, "horizBrace");
	var a = Y(i.base, t.havingBaseStyle(D.DISPLAY)), o = _r.svgSpan(i, t), s;
	if (i.isOver ? (s = W.makeVList({
		positionType: "firstBaseline",
		children: [
			{
				type: "elem",
				elem: a
			},
			{
				type: "kern",
				size: .1
			},
			{
				type: "elem",
				elem: o
			}
		]
	}, t), s.children[0].children[0].children[1].classes.push("svg-align")) : (s = W.makeVList({
		positionType: "bottom",
		positionData: a.depth + .1 + o.height,
		children: [
			{
				type: "elem",
				elem: o
			},
			{
				type: "kern",
				size: .1
			},
			{
				type: "elem",
				elem: a
			}
		]
	}, t), s.children[0].children[0].children[0].classes.push("svg-align")), r) {
		var c = W.makeSpan(["mord", i.isOver ? "mover" : "munder"], [s], t);
		s = i.isOver ? W.makeVList({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: c
				},
				{
					type: "kern",
					size: .2
				},
				{
					type: "elem",
					elem: r
				}
			]
		}, t) : W.makeVList({
			positionType: "bottom",
			positionData: c.depth + .2 + r.height + r.depth,
			children: [
				{
					type: "elem",
					elem: r
				},
				{
					type: "kern",
					size: .2
				},
				{
					type: "elem",
					elem: c
				}
			]
		}, t);
	}
	return W.makeSpan(["mord", i.isOver ? "mover" : "munder"], [s], t);
};
K({
	type: "horizBrace",
	names: ["\\overbrace", "\\underbrace"],
	props: { numArgs: 1 },
	handler(e, t) {
		var { parser: n, funcName: r } = e;
		return {
			type: "horizBrace",
			mode: n.mode,
			label: r,
			isOver: /^\\over/.test(r),
			base: t[0]
		};
	},
	htmlBuilder: Hi,
	mathmlBuilder: (e, t) => {
		var n = _r.mathMLnode(e.label);
		return new X.MathNode(e.isOver ? "mover" : "munder", [Z(e.base, t), n]);
	}
}), K({
	type: "href",
	names: ["\\href"],
	props: {
		numArgs: 2,
		argTypes: ["url", "original"],
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n } = e, r = t[1], i = Q(t[0], "url").url;
		return n.settings.isTrusted({
			command: "\\href",
			url: i
		}) ? {
			type: "href",
			mode: n.mode,
			href: i,
			body: q(r)
		} : n.formatUnsupportedCmd("\\href");
	},
	htmlBuilder: (e, t) => {
		var n = J(e.body, t, !1);
		return W.makeAnchor(e.href, [], n, t);
	},
	mathmlBuilder: (e, t) => {
		var n = sr(e.body, t);
		return n instanceof er || (n = new er("mrow", [n])), n.setAttribute("href", e.href), n;
	}
}), K({
	type: "href",
	names: ["\\url"],
	props: {
		numArgs: 1,
		argTypes: ["url"],
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n } = e, r = Q(t[0], "url").url;
		if (!n.settings.isTrusted({
			command: "\\url",
			url: r
		})) return n.formatUnsupportedCmd("\\url");
		for (var i = [], a = 0; a < r.length; a++) {
			var o = r[a];
			o === "~" && (o = "\\textasciitilde"), i.push({
				type: "textord",
				mode: "text",
				text: o
			});
		}
		var s = {
			type: "text",
			mode: n.mode,
			font: "\\texttt",
			body: i
		};
		return {
			type: "href",
			mode: n.mode,
			href: r,
			body: q(s)
		};
	}
}), K({
	type: "hbox",
	names: ["\\hbox"],
	props: {
		numArgs: 1,
		argTypes: ["text"],
		allowedInText: !0,
		primitive: !0
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "hbox",
			mode: n.mode,
			body: q(t[0])
		};
	},
	htmlBuilder(e, t) {
		var n = J(e.body, t, !1);
		return W.makeFragment(n);
	},
	mathmlBuilder(e, t) {
		return new X.MathNode("mrow", or(e.body, t));
	}
}), K({
	type: "html",
	names: [
		"\\htmlClass",
		"\\htmlId",
		"\\htmlStyle",
		"\\htmlData"
	],
	props: {
		numArgs: 2,
		argTypes: ["raw", "original"],
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n, funcName: r, token: i } = e, a = Q(t[0], "raw").string, o = t[1];
		n.settings.strict && n.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
		var s, c = {};
		switch (r) {
			case "\\htmlClass":
				c.class = a, s = {
					command: "\\htmlClass",
					class: a
				};
				break;
			case "\\htmlId":
				c.id = a, s = {
					command: "\\htmlId",
					id: a
				};
				break;
			case "\\htmlStyle":
				c.style = a, s = {
					command: "\\htmlStyle",
					style: a
				};
				break;
			case "\\htmlData":
				for (var l = a.split(","), u = 0; u < l.length; u++) {
					var d = l[u].split("=");
					if (d.length !== 2) throw new T("Error parsing key-value for \\htmlData");
					c["data-" + d[0].trim()] = d[1].trim();
				}
				s = {
					command: "\\htmlData",
					attributes: c
				};
				break;
			default: throw Error("Unrecognized html command");
		}
		return n.settings.isTrusted(s) ? {
			type: "html",
			mode: n.mode,
			attributes: c,
			body: q(o)
		} : n.formatUnsupportedCmd(r);
	},
	htmlBuilder: (e, t) => {
		var n = J(e.body, t, !1), r = ["enclosing"];
		e.attributes.class && r.push(...e.attributes.class.trim().split(/\s+/));
		var i = W.makeSpan(r, n, t);
		for (var a in e.attributes) a !== "class" && e.attributes.hasOwnProperty(a) && i.setAttribute(a, e.attributes[a]);
		return i;
	},
	mathmlBuilder: (e, t) => sr(e.body, t)
}), K({
	type: "htmlmathml",
	names: ["\\html@mathml"],
	props: {
		numArgs: 2,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n } = e;
		return {
			type: "htmlmathml",
			mode: n.mode,
			html: q(t[0]),
			mathml: q(t[1])
		};
	},
	htmlBuilder: (e, t) => {
		var n = J(e.html, t, !1);
		return W.makeFragment(n);
	},
	mathmlBuilder: (e, t) => sr(e.mathml, t)
});
var Ui = function(e) {
	if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e)) return {
		number: +e,
		unit: "bp"
	};
	var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
	if (!t) throw new T("Invalid size: '" + e + "' in \\includegraphics");
	var n = {
		number: +(t[1] + t[2]),
		unit: t[3]
	};
	if (!Ct(n)) throw new T("Invalid unit: '" + n.unit + "' in \\includegraphics.");
	return n;
};
K({
	type: "includegraphics",
	names: ["\\includegraphics"],
	props: {
		numArgs: 1,
		numOptionalArgs: 1,
		argTypes: ["raw", "url"],
		allowedInText: !1
	},
	handler: (e, t, n) => {
		var { parser: r } = e, i = {
			number: 0,
			unit: "em"
		}, a = {
			number: .9,
			unit: "em"
		}, o = {
			number: 0,
			unit: "em"
		}, s = "";
		if (n[0]) for (var c = Q(n[0], "raw").string, l = c.split(","), u = 0; u < l.length; u++) {
			var d = l[u].split("=");
			if (d.length === 2) {
				var f = d[1].trim();
				switch (d[0].trim()) {
					case "alt":
						s = f;
						break;
					case "width":
						i = Ui(f);
						break;
					case "height":
						a = Ui(f);
						break;
					case "totalheight":
						o = Ui(f);
						break;
					default: throw new T("Invalid key: '" + d[0] + "' in \\includegraphics.");
				}
			}
		}
		var p = Q(t[0], "url").url;
		return s === "" && (s = p, s = s.replace(/^.*[\\/]/, ""), s = s.substring(0, s.lastIndexOf("."))), r.settings.isTrusted({
			command: "\\includegraphics",
			url: p
		}) ? {
			type: "includegraphics",
			mode: r.mode,
			alt: s,
			width: i,
			height: a,
			totalheight: o,
			src: p
		} : r.formatUnsupportedCmd("\\includegraphics");
	},
	htmlBuilder: (e, t) => {
		var n = O(e.height, t), r = 0;
		e.totalheight.number > 0 && (r = O(e.totalheight, t) - n);
		var i = 0;
		e.width.number > 0 && (i = O(e.width, t));
		var a = { height: k(n + r) };
		i > 0 && (a.width = k(i)), r > 0 && (a.verticalAlign = k(-r));
		var o = new jt(e.src, e.alt, a);
		return o.height = n, o.depth = r, o;
	},
	mathmlBuilder: (e, t) => {
		var n = new X.MathNode("mglyph", []);
		n.setAttribute("alt", e.alt);
		var r = O(e.height, t), i = 0;
		if (e.totalheight.number > 0 && (i = O(e.totalheight, t) - r, n.setAttribute("valign", k(-i))), n.setAttribute("height", k(r + i)), e.width.number > 0) {
			var a = O(e.width, t);
			n.setAttribute("width", k(a));
		}
		return n.setAttribute("src", e.src), n;
	}
}), K({
	type: "kern",
	names: [
		"\\kern",
		"\\mkern",
		"\\hskip",
		"\\mskip"
	],
	props: {
		numArgs: 1,
		argTypes: ["size"],
		primitive: !0,
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n, funcName: r } = e, i = Q(t[0], "size");
		if (n.settings.strict) {
			var a = r[1] === "m", o = i.value.unit === "mu";
			a ? (o || n.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " supports only mu units, " + ("not " + i.value.unit + " units")), n.mode !== "math" && n.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " works only in math mode")) : o && n.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " doesn't support mu units");
		}
		return {
			type: "kern",
			mode: n.mode,
			dimension: i.value
		};
	},
	htmlBuilder(e, t) {
		return W.makeGlue(e.dimension, t);
	},
	mathmlBuilder(e, t) {
		var n = O(e.dimension, t);
		return new X.SpaceNode(n);
	}
}), K({
	type: "lap",
	names: [
		"\\mathllap",
		"\\mathrlap",
		"\\mathclap"
	],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "lap",
			mode: n.mode,
			alignment: r.slice(5),
			body: i
		};
	},
	htmlBuilder: (e, t) => {
		var n;
		e.alignment === "clap" ? (n = W.makeSpan([], [Y(e.body, t)]), n = W.makeSpan(["inner"], [n], t)) : n = W.makeSpan(["inner"], [Y(e.body, t)]);
		var r = W.makeSpan(["fix"], []), i = W.makeSpan([e.alignment], [n, r], t), a = W.makeSpan(["strut"]);
		return a.style.height = k(i.height + i.depth), i.depth && (a.style.verticalAlign = k(-i.depth)), i.children.unshift(a), i = W.makeSpan(["thinbox"], [i], t), W.makeSpan(["mord", "vbox"], [i], t);
	},
	mathmlBuilder: (e, t) => {
		var n = new X.MathNode("mpadded", [Z(e.body, t)]);
		if (e.alignment !== "rlap") {
			var r = e.alignment === "llap" ? "-1" : "-0.5";
			n.setAttribute("lspace", r + "width");
		}
		return n.setAttribute("width", "0px"), n;
	}
}), K({
	type: "styling",
	names: ["\\(", "$"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		allowedInMath: !1
	},
	handler(e, t) {
		var { funcName: n, parser: r } = e, i = r.mode;
		r.switchMode("math");
		var a = n === "\\(" ? "\\)" : "$", o = r.parseExpression(!1, a);
		return r.expect(a), r.switchMode(i), {
			type: "styling",
			mode: r.mode,
			style: "text",
			body: o
		};
	}
}), K({
	type: "text",
	names: ["\\)", "\\]"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		allowedInMath: !1
	},
	handler(e, t) {
		throw new T("Mismatched " + e.funcName);
	}
});
var Wi = (e, t) => {
	switch (t.style.size) {
		case D.DISPLAY.size: return e.display;
		case D.TEXT.size: return e.text;
		case D.SCRIPT.size: return e.script;
		case D.SCRIPTSCRIPT.size: return e.scriptscript;
		default: return e.text;
	}
};
K({
	type: "mathchoice",
	names: ["\\mathchoice"],
	props: {
		numArgs: 4,
		primitive: !0
	},
	handler: (e, t) => {
		var { parser: n } = e;
		return {
			type: "mathchoice",
			mode: n.mode,
			display: q(t[0]),
			text: q(t[1]),
			script: q(t[2]),
			scriptscript: q(t[3])
		};
	},
	htmlBuilder: (e, t) => {
		var n = J(Wi(e, t), t, !1);
		return W.makeFragment(n);
	},
	mathmlBuilder: (e, t) => sr(Wi(e, t), t)
});
var Gi = (e, t, n, r, i, a, o) => {
	e = W.makeSpan([], [e]);
	var s = n && E.isCharacterBox(n), c, l;
	if (t) {
		var u = Y(t, r.havingStyle(i.sup()), r);
		l = {
			elem: u,
			kern: Math.max(r.fontMetrics().bigOpSpacing1, r.fontMetrics().bigOpSpacing3 - u.depth)
		};
	}
	if (n) {
		var d = Y(n, r.havingStyle(i.sub()), r);
		c = {
			elem: d,
			kern: Math.max(r.fontMetrics().bigOpSpacing2, r.fontMetrics().bigOpSpacing4 - d.height)
		};
	}
	var f;
	if (l && c) {
		var p = r.fontMetrics().bigOpSpacing5 + c.elem.height + c.elem.depth + c.kern + e.depth + o;
		f = W.makeVList({
			positionType: "bottom",
			positionData: p,
			children: [
				{
					type: "kern",
					size: r.fontMetrics().bigOpSpacing5
				},
				{
					type: "elem",
					elem: c.elem,
					marginLeft: k(-a)
				},
				{
					type: "kern",
					size: c.kern
				},
				{
					type: "elem",
					elem: e
				},
				{
					type: "kern",
					size: l.kern
				},
				{
					type: "elem",
					elem: l.elem,
					marginLeft: k(a)
				},
				{
					type: "kern",
					size: r.fontMetrics().bigOpSpacing5
				}
			]
		}, r);
	} else if (c) {
		var m = e.height - o;
		f = W.makeVList({
			positionType: "top",
			positionData: m,
			children: [
				{
					type: "kern",
					size: r.fontMetrics().bigOpSpacing5
				},
				{
					type: "elem",
					elem: c.elem,
					marginLeft: k(-a)
				},
				{
					type: "kern",
					size: c.kern
				},
				{
					type: "elem",
					elem: e
				}
			]
		}, r);
	} else if (l) {
		var h = e.depth + o;
		f = W.makeVList({
			positionType: "bottom",
			positionData: h,
			children: [
				{
					type: "elem",
					elem: e
				},
				{
					type: "kern",
					size: l.kern
				},
				{
					type: "elem",
					elem: l.elem,
					marginLeft: k(a)
				},
				{
					type: "kern",
					size: r.fontMetrics().bigOpSpacing5
				}
			]
		}, r);
	} else return e;
	var g = [f];
	if (c && a !== 0 && !s) {
		var _ = W.makeSpan(["mspace"], [], r);
		_.style.marginRight = k(a), g.unshift(_);
	}
	return W.makeSpan(["mop", "op-limits"], g, r);
}, Ki = ["\\smallint"], qi = (e, t) => {
	var n, r, i = !1, a;
	e.type === "supsub" ? (n = e.sup, r = e.sub, a = Q(e.base, "op"), i = !0) : a = Q(e, "op");
	var o = t.style, s = !1;
	o.size === D.DISPLAY.size && a.symbol && !Ki.includes(a.name) && (s = !0);
	var c;
	if (a.symbol) {
		var l = s ? "Size2-Regular" : "Size1-Regular", u = "";
		if ((a.name === "\\oiint" || a.name === "\\oiiint") && (u = a.name.slice(1), a.name = u === "oiint" ? "\\iint" : "\\iiint"), c = W.makeSymbol(a.name, l, "math", t, [
			"mop",
			"op-symbol",
			s ? "large-op" : "small-op"
		]), u.length > 0) {
			var d = c.italic, f = W.staticSvg(u + "Size" + (s ? "2" : "1"), t);
			c = W.makeVList({
				positionType: "individualShift",
				children: [{
					type: "elem",
					elem: c,
					shift: 0
				}, {
					type: "elem",
					elem: f,
					shift: s ? .08 : 0
				}]
			}, t), a.name = "\\" + u, c.classes.unshift("mop"), c.italic = d;
		}
	} else if (a.body) {
		var p = J(a.body, t, !0);
		p.length === 1 && p[0] instanceof Nt ? (c = p[0], c.classes[0] = "mop") : c = W.makeSpan(["mop"], p, t);
	} else {
		for (var m = [], h = 1; h < a.name.length; h++) m.push(W.mathsym(a.name[h], a.mode, t));
		c = W.makeSpan(["mop"], m, t);
	}
	var g = 0, _ = 0;
	return (c instanceof Nt || a.name === "\\oiint" || a.name === "\\oiiint") && !a.suppressBaseShift && (g = (c.height - c.depth) / 2 - t.fontMetrics().axisHeight, _ = c.italic), i ? Gi(c, n, r, t, o, _, g) : (g && (c.style.position = "relative", c.style.top = k(g)), c);
}, Ji = (e, t) => {
	var n;
	if (e.symbol) n = new er("mo", [nr(e.name, e.mode)]), Ki.includes(e.name) && n.setAttribute("largeop", "false");
	else if (e.body) n = new er("mo", or(e.body, t));
	else {
		n = new er("mi", [new tr(e.name.slice(1))]);
		var r = new er("mo", [nr("⁡", "text")]);
		n = e.parentIsSupSub ? new er("mrow", [n, r]) : $n([n, r]);
	}
	return n;
}, Yi = {
	"∏": "\\prod",
	"∐": "\\coprod",
	"∑": "\\sum",
	"⋀": "\\bigwedge",
	"⋁": "\\bigvee",
	"⋂": "\\bigcap",
	"⋃": "\\bigcup",
	"⨀": "\\bigodot",
	"⨁": "\\bigoplus",
	"⨂": "\\bigotimes",
	"⨄": "\\biguplus",
	"⨆": "\\bigsqcup"
};
K({
	type: "op",
	names: /* @__PURE__ */ "\\coprod.\\bigvee.\\bigwedge.\\biguplus.\\bigcap.\\bigcup.\\intop.\\prod.\\sum.\\bigotimes.\\bigoplus.\\bigodot.\\bigsqcup.\\smallint.∏.∐.∑.⋀.⋁.⋂.⋃.⨀.⨁.⨂.⨄.⨆".split("."),
	props: { numArgs: 0 },
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = r;
		return i.length === 1 && (i = Yi[i]), {
			type: "op",
			mode: n.mode,
			limits: !0,
			parentIsSupSub: !1,
			symbol: !0,
			name: i
		};
	},
	htmlBuilder: qi,
	mathmlBuilder: Ji
}), K({
	type: "op",
	names: ["\\mathop"],
	props: {
		numArgs: 1,
		primitive: !0
	},
	handler: (e, t) => {
		var { parser: n } = e, r = t[0];
		return {
			type: "op",
			mode: n.mode,
			limits: !1,
			parentIsSupSub: !1,
			symbol: !1,
			body: q(r)
		};
	},
	htmlBuilder: qi,
	mathmlBuilder: Ji
});
var Xi = {
	"∫": "\\int",
	"∬": "\\iint",
	"∭": "\\iiint",
	"∮": "\\oint",
	"∯": "\\oiint",
	"∰": "\\oiiint"
};
K({
	type: "op",
	names: /* @__PURE__ */ "\\arcsin.\\arccos.\\arctan.\\arctg.\\arcctg.\\arg.\\ch.\\cos.\\cosec.\\cosh.\\cot.\\cotg.\\coth.\\csc.\\ctg.\\cth.\\deg.\\dim.\\exp.\\hom.\\ker.\\lg.\\ln.\\log.\\sec.\\sin.\\sinh.\\sh.\\tan.\\tanh.\\tg.\\th".split("."),
	props: { numArgs: 0 },
	handler(e) {
		var { parser: t, funcName: n } = e;
		return {
			type: "op",
			mode: t.mode,
			limits: !1,
			parentIsSupSub: !1,
			symbol: !1,
			name: n
		};
	},
	htmlBuilder: qi,
	mathmlBuilder: Ji
}), K({
	type: "op",
	names: [
		"\\det",
		"\\gcd",
		"\\inf",
		"\\lim",
		"\\max",
		"\\min",
		"\\Pr",
		"\\sup"
	],
	props: { numArgs: 0 },
	handler(e) {
		var { parser: t, funcName: n } = e;
		return {
			type: "op",
			mode: t.mode,
			limits: !0,
			parentIsSupSub: !1,
			symbol: !1,
			name: n
		};
	},
	htmlBuilder: qi,
	mathmlBuilder: Ji
}), K({
	type: "op",
	names: [
		"\\int",
		"\\iint",
		"\\iiint",
		"\\oint",
		"\\oiint",
		"\\oiiint",
		"∫",
		"∬",
		"∭",
		"∮",
		"∯",
		"∰"
	],
	props: { numArgs: 0 },
	handler(e) {
		var { parser: t, funcName: n } = e, r = n;
		return r.length === 1 && (r = Xi[r]), {
			type: "op",
			mode: t.mode,
			limits: !1,
			parentIsSupSub: !1,
			symbol: !0,
			name: r
		};
	},
	htmlBuilder: qi,
	mathmlBuilder: Ji
});
var Zi = (e, t) => {
	var n, r, i = !1, a;
	e.type === "supsub" ? (n = e.sup, r = e.sub, a = Q(e.base, "operatorname"), i = !0) : a = Q(e, "operatorname");
	var o;
	if (a.body.length > 0) {
		for (var s = J(a.body.map((e) => {
			var t = e.text;
			return typeof t == "string" ? {
				type: "textord",
				mode: e.mode,
				text: t
			} : e;
		}), t.withFont("mathrm"), !0), c = 0; c < s.length; c++) {
			var l = s[c];
			l instanceof Nt && (l.text = l.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
		}
		o = W.makeSpan(["mop"], s, t);
	} else o = W.makeSpan(["mop"], [], t);
	return i ? Gi(o, n, r, t, t.style, 0, 0) : o;
};
K({
	type: "operatorname",
	names: ["\\operatorname@", "\\operatornamewithlimits"],
	props: { numArgs: 1 },
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "operatorname",
			mode: n.mode,
			body: q(i),
			alwaysHandleSupSub: r === "\\operatornamewithlimits",
			limits: !1,
			parentIsSupSub: !1
		};
	},
	htmlBuilder: Zi,
	mathmlBuilder: (e, t) => {
		for (var n = or(e.body, t.withFont("mathrm")), r = !0, i = 0; i < n.length; i++) {
			var a = n[i];
			if (!(a instanceof X.SpaceNode)) {
				if (a instanceof X.MathNode) switch (a.type) {
					case "mi":
					case "mn":
					case "ms":
					case "mspace":
					case "mtext": break;
					case "mo":
						var o = a.children[0];
						a.children.length === 1 && o instanceof X.TextNode ? o.text = o.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : r = !1;
						break;
					default: r = !1;
				}
				else r = !1;
			}
		}
		if (r) {
			var s = n.map((e) => e.toText()).join("");
			n = [new X.TextNode(s)];
		}
		var c = new X.MathNode("mi", n);
		c.setAttribute("mathvariant", "normal");
		var l = new X.MathNode("mo", [nr("⁡", "text")]);
		return e.parentIsSupSub ? new X.MathNode("mrow", [c, l]) : X.newDocumentFragment([c, l]);
	}
}), $("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@"), zn({
	type: "ordgroup",
	htmlBuilder(e, t) {
		return e.semisimple ? W.makeFragment(J(e.body, t, !1)) : W.makeSpan(["mord"], J(e.body, t, !0), t);
	},
	mathmlBuilder(e, t) {
		return sr(e.body, t, !0);
	}
}), K({
	type: "overline",
	names: ["\\overline"],
	props: { numArgs: 1 },
	handler(e, t) {
		var { parser: n } = e, r = t[0];
		return {
			type: "overline",
			mode: n.mode,
			body: r
		};
	},
	htmlBuilder(e, t) {
		var n = Y(e.body, t.havingCrampedStyle()), r = W.makeLineSpan("overline-line", t), i = t.fontMetrics().defaultRuleThickness, a = W.makeVList({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: n
				},
				{
					type: "kern",
					size: 3 * i
				},
				{
					type: "elem",
					elem: r
				},
				{
					type: "kern",
					size: i
				}
			]
		}, t);
		return W.makeSpan(["mord", "overline"], [a], t);
	},
	mathmlBuilder(e, t) {
		var n = new X.MathNode("mo", [new X.TextNode("‾")]);
		n.setAttribute("stretchy", "true");
		var r = new X.MathNode("mover", [Z(e.body, t), n]);
		return r.setAttribute("accent", "true"), r;
	}
}), K({
	type: "phantom",
	names: ["\\phantom"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n } = e, r = t[0];
		return {
			type: "phantom",
			mode: n.mode,
			body: q(r)
		};
	},
	htmlBuilder: (e, t) => {
		var n = J(e.body, t.withPhantom(), !1);
		return W.makeFragment(n);
	},
	mathmlBuilder: (e, t) => {
		var n = or(e.body, t);
		return new X.MathNode("mphantom", n);
	}
}), K({
	type: "hphantom",
	names: ["\\hphantom"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n } = e, r = t[0];
		return {
			type: "hphantom",
			mode: n.mode,
			body: r
		};
	},
	htmlBuilder: (e, t) => {
		var n = W.makeSpan([], [Y(e.body, t.withPhantom())]);
		if (n.height = 0, n.depth = 0, n.children) for (var r = 0; r < n.children.length; r++) n.children[r].height = 0, n.children[r].depth = 0;
		return n = W.makeVList({
			positionType: "firstBaseline",
			children: [{
				type: "elem",
				elem: n
			}]
		}, t), W.makeSpan(["mord"], [n], t);
	},
	mathmlBuilder: (e, t) => {
		var n = or(q(e.body), t), r = new X.MathNode("mphantom", n), i = new X.MathNode("mpadded", [r]);
		return i.setAttribute("height", "0px"), i.setAttribute("depth", "0px"), i;
	}
}), K({
	type: "vphantom",
	names: ["\\vphantom"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n } = e, r = t[0];
		return {
			type: "vphantom",
			mode: n.mode,
			body: r
		};
	},
	htmlBuilder: (e, t) => {
		var n = W.makeSpan(["inner"], [Y(e.body, t.withPhantom())]), r = W.makeSpan(["fix"], []);
		return W.makeSpan(["mord", "rlap"], [n, r], t);
	},
	mathmlBuilder: (e, t) => {
		var n = or(q(e.body), t), r = new X.MathNode("mphantom", n), i = new X.MathNode("mpadded", [r]);
		return i.setAttribute("width", "0px"), i;
	}
}), K({
	type: "raisebox",
	names: ["\\raisebox"],
	props: {
		numArgs: 2,
		argTypes: ["size", "hbox"],
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n } = e, r = Q(t[0], "size").value, i = t[1];
		return {
			type: "raisebox",
			mode: n.mode,
			dy: r,
			body: i
		};
	},
	htmlBuilder(e, t) {
		var n = Y(e.body, t), r = O(e.dy, t);
		return W.makeVList({
			positionType: "shift",
			positionData: -r,
			children: [{
				type: "elem",
				elem: n
			}]
		}, t);
	},
	mathmlBuilder(e, t) {
		var n = new X.MathNode("mpadded", [Z(e.body, t)]), r = e.dy.number + e.dy.unit;
		return n.setAttribute("voffset", r), n;
	}
}), K({
	type: "internal",
	names: ["\\relax"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		allowedInArgument: !0
	},
	handler(e) {
		var { parser: t } = e;
		return {
			type: "internal",
			mode: t.mode
		};
	}
}), K({
	type: "rule",
	names: ["\\rule"],
	props: {
		numArgs: 2,
		numOptionalArgs: 1,
		allowedInText: !0,
		allowedInMath: !0,
		argTypes: [
			"size",
			"size",
			"size"
		]
	},
	handler(e, t, n) {
		var { parser: r } = e, i = n[0], a = Q(t[0], "size"), o = Q(t[1], "size");
		return {
			type: "rule",
			mode: r.mode,
			shift: i && Q(i, "size").value,
			width: a.value,
			height: o.value
		};
	},
	htmlBuilder(e, t) {
		var n = W.makeSpan(["mord", "rule"], [], t), r = O(e.width, t), i = O(e.height, t), a = e.shift ? O(e.shift, t) : 0;
		return n.style.borderRightWidth = k(r), n.style.borderTopWidth = k(i), n.style.bottom = k(a), n.width = r, n.height = i + a, n.depth = -a, n.maxFontSize = i * 1.125 * t.sizeMultiplier, n;
	},
	mathmlBuilder(e, t) {
		var n = O(e.width, t), r = O(e.height, t), i = e.shift ? O(e.shift, t) : 0, a = t.color && t.getColor() || "black", o = new X.MathNode("mspace");
		o.setAttribute("mathbackground", a), o.setAttribute("width", k(n)), o.setAttribute("height", k(r));
		var s = new X.MathNode("mpadded", [o]);
		return i >= 0 ? s.setAttribute("height", k(i)) : (s.setAttribute("height", k(i)), s.setAttribute("depth", k(-i))), s.setAttribute("voffset", k(i)), s;
	}
});
function Qi(e, t, n) {
	for (var r = J(e, t, !1), i = t.sizeMultiplier / n.sizeMultiplier, a = 0; a < r.length; a++) {
		var o = r[a].classes.indexOf("sizing");
		o < 0 ? Array.prototype.push.apply(r[a].classes, t.sizingClasses(n)) : r[a].classes[o + 1] === "reset-size" + t.size && (r[a].classes[o + 1] = "reset-size" + n.size), r[a].height *= i, r[a].depth *= i;
	}
	return W.makeFragment(r);
}
var $i = [
	"\\tiny",
	"\\sixptsize",
	"\\scriptsize",
	"\\footnotesize",
	"\\small",
	"\\normalsize",
	"\\large",
	"\\Large",
	"\\LARGE",
	"\\huge",
	"\\Huge"
];
K({
	type: "sizing",
	names: $i,
	props: {
		numArgs: 0,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { breakOnTokenText: n, funcName: r, parser: i } = e, a = i.parseExpression(!1, n);
		return {
			type: "sizing",
			mode: i.mode,
			size: $i.indexOf(r) + 1,
			body: a
		};
	},
	htmlBuilder: (e, t) => {
		var n = t.havingSize(e.size);
		return Qi(e.body, n, t);
	},
	mathmlBuilder: (e, t) => {
		var n = t.havingSize(e.size), r = or(e.body, n), i = new X.MathNode("mstyle", r);
		return i.setAttribute("mathsize", k(n.sizeMultiplier)), i;
	}
}), K({
	type: "smash",
	names: ["\\smash"],
	props: {
		numArgs: 1,
		numOptionalArgs: 1,
		allowedInText: !0
	},
	handler: (e, t, n) => {
		var { parser: r } = e, i = !1, a = !1, o = n[0] && Q(n[0], "ordgroup");
		if (o) for (var s = "", c = 0; c < o.body.length; ++c) if (s = o.body[c].text, s === "t") i = !0;
		else if (s === "b") a = !0;
		else {
			i = !1, a = !1;
			break;
		}
		else i = !0, a = !0;
		var l = t[0];
		return {
			type: "smash",
			mode: r.mode,
			body: l,
			smashHeight: i,
			smashDepth: a
		};
	},
	htmlBuilder: (e, t) => {
		var n = W.makeSpan([], [Y(e.body, t)]);
		if (!e.smashHeight && !e.smashDepth) return n;
		if (e.smashHeight && (n.height = 0, n.children)) for (var r = 0; r < n.children.length; r++) n.children[r].height = 0;
		if (e.smashDepth && (n.depth = 0, n.children)) for (var i = 0; i < n.children.length; i++) n.children[i].depth = 0;
		var a = W.makeVList({
			positionType: "firstBaseline",
			children: [{
				type: "elem",
				elem: n
			}]
		}, t);
		return W.makeSpan(["mord"], [a], t);
	},
	mathmlBuilder: (e, t) => {
		var n = new X.MathNode("mpadded", [Z(e.body, t)]);
		return e.smashHeight && n.setAttribute("height", "0px"), e.smashDepth && n.setAttribute("depth", "0px"), n;
	}
}), K({
	type: "sqrt",
	names: ["\\sqrt"],
	props: {
		numArgs: 1,
		numOptionalArgs: 1
	},
	handler(e, t, n) {
		var { parser: r } = e, i = n[0], a = t[0];
		return {
			type: "sqrt",
			mode: r.mode,
			body: a,
			index: i
		};
	},
	htmlBuilder(e, t) {
		var n = Y(e.body, t.havingCrampedStyle());
		n.height === 0 && (n.height = t.fontMetrics().xHeight), n = W.wrapFragment(n, t);
		var r = t.fontMetrics().defaultRuleThickness, i = r;
		t.style.id < D.TEXT.id && (i = t.fontMetrics().xHeight);
		var a = r + i / 4, o = n.height + n.depth + a + r, { span: s, ruleWidth: c, advanceWidth: l } = mi.sqrtImage(o, t), u = s.height - c;
		u > n.height + n.depth + a && (a = (a + u - n.height - n.depth) / 2);
		var d = s.height - n.height - a - c;
		n.style.paddingLeft = k(l);
		var f = W.makeVList({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: n,
					wrapperClasses: ["svg-align"]
				},
				{
					type: "kern",
					size: -(n.height + d)
				},
				{
					type: "elem",
					elem: s
				},
				{
					type: "kern",
					size: c
				}
			]
		}, t);
		if (e.index) {
			var p = t.havingStyle(D.SCRIPTSCRIPT), m = Y(e.index, p, t), h = .6 * (f.height - f.depth), g = W.makeVList({
				positionType: "shift",
				positionData: -h,
				children: [{
					type: "elem",
					elem: m
				}]
			}, t), _ = W.makeSpan(["root"], [g]);
			return W.makeSpan(["mord", "sqrt"], [_, f], t);
		}
		return W.makeSpan(["mord", "sqrt"], [f], t);
	},
	mathmlBuilder(e, t) {
		var { body: n, index: r } = e;
		return r ? new X.MathNode("mroot", [Z(n, t), Z(r, t)]) : new X.MathNode("msqrt", [Z(n, t)]);
	}
});
var ea = {
	display: D.DISPLAY,
	text: D.TEXT,
	script: D.SCRIPT,
	scriptscript: D.SCRIPTSCRIPT
};
K({
	type: "styling",
	names: [
		"\\displaystyle",
		"\\textstyle",
		"\\scriptstyle",
		"\\scriptscriptstyle"
	],
	props: {
		numArgs: 0,
		allowedInText: !0,
		primitive: !0
	},
	handler(e, t) {
		var { breakOnTokenText: n, funcName: r, parser: i } = e, a = i.parseExpression(!0, n), o = r.slice(1, r.length - 5);
		return {
			type: "styling",
			mode: i.mode,
			style: o,
			body: a
		};
	},
	htmlBuilder(e, t) {
		var n = ea[e.style], r = t.havingStyle(n).withFont("");
		return Qi(e.body, r, t);
	},
	mathmlBuilder(e, t) {
		var n = ea[e.style], r = t.havingStyle(n), i = or(e.body, r), a = new X.MathNode("mstyle", i), o = {
			display: ["0", "true"],
			text: ["0", "false"],
			script: ["1", "false"],
			scriptscript: ["2", "false"]
		}[e.style];
		return a.setAttribute("scriptlevel", o[0]), a.setAttribute("displaystyle", o[1]), a;
	}
});
var ta = function(e, t) {
	var n = e.base;
	return n ? n.type === "op" ? n.limits && (t.style.size === D.DISPLAY.size || n.alwaysHandleSupSub) ? qi : null : n.type === "operatorname" ? n.alwaysHandleSupSub && (t.style.size === D.DISPLAY.size || n.limits) ? Zi : null : n.type === "accent" ? E.isCharacterBox(n.base) ? br : null : n.type === "horizBrace" && !e.sub === n.isOver ? Hi : null : null;
};
zn({
	type: "supsub",
	htmlBuilder(e, t) {
		var n = ta(e, t);
		if (n) return n(e, t);
		var { base: r, sup: i, sub: a } = e, o = Y(r, t), s, c, l = t.fontMetrics(), u = 0, d = 0, f = r && E.isCharacterBox(r);
		if (i) {
			var p = t.havingStyle(t.style.sup());
			s = Y(i, p, t), f || (u = o.height - p.fontMetrics().supDrop * p.sizeMultiplier / t.sizeMultiplier);
		}
		if (a) {
			var m = t.havingStyle(t.style.sub());
			c = Y(a, m, t), f || (d = o.depth + m.fontMetrics().subDrop * m.sizeMultiplier / t.sizeMultiplier);
		}
		var h = t.style === D.DISPLAY ? l.sup1 : t.style.cramped ? l.sup3 : l.sup2, g = t.sizeMultiplier, _ = k(.5 / l.ptPerEm / g), v = null;
		if (c) {
			var y = e.base && e.base.type === "op" && e.base.name && (e.base.name === "\\oiint" || e.base.name === "\\oiiint");
			(o instanceof Nt || y) && (v = k(-o.italic));
		}
		var b;
		if (s && c) {
			u = Math.max(u, h, s.depth + .25 * l.xHeight), d = Math.max(d, l.sub2);
			var x = 4 * l.defaultRuleThickness;
			if (u - s.depth - (c.height - d) < x) {
				d = x - (u - s.depth) + c.height;
				var S = .8 * l.xHeight - (u - s.depth);
				S > 0 && (u += S, d -= S);
			}
			var C = [{
				type: "elem",
				elem: c,
				shift: d,
				marginRight: _,
				marginLeft: v
			}, {
				type: "elem",
				elem: s,
				shift: -u,
				marginRight: _
			}];
			b = W.makeVList({
				positionType: "individualShift",
				children: C
			}, t);
		} else if (c) {
			d = Math.max(d, l.sub1, c.height - .8 * l.xHeight);
			var ee = [{
				type: "elem",
				elem: c,
				marginLeft: v,
				marginRight: _
			}];
			b = W.makeVList({
				positionType: "shift",
				positionData: d,
				children: ee
			}, t);
		} else if (s) u = Math.max(u, h, s.depth + .25 * l.xHeight), b = W.makeVList({
			positionType: "shift",
			positionData: -u,
			children: [{
				type: "elem",
				elem: s,
				marginRight: _
			}]
		}, t);
		else throw Error("supsub must have either sup or sub.");
		var te = Yn(o, "right") || "mord";
		return W.makeSpan([te], [o, W.makeSpan(["msupsub"], [b])], t);
	},
	mathmlBuilder(e, t) {
		var n = !1, r, i;
		e.base && e.base.type === "horizBrace" && (i = !!e.sup, i === e.base.isOver && (n = !0, r = e.base.isOver)), e.base && (e.base.type === "op" || e.base.type === "operatorname") && (e.base.parentIsSupSub = !0);
		var a = [Z(e.base, t)];
		e.sub && a.push(Z(e.sub, t)), e.sup && a.push(Z(e.sup, t));
		var o;
		if (n) o = r ? "mover" : "munder";
		else if (e.sub) {
			if (e.sup) {
				var s = e.base;
				o = s && s.type === "op" && s.limits && t.style === D.DISPLAY || s && s.type === "operatorname" && s.alwaysHandleSupSub && (t.style === D.DISPLAY || s.limits) ? "munderover" : "msubsup";
			} else {
				var c = e.base;
				o = c && c.type === "op" && c.limits && (t.style === D.DISPLAY || c.alwaysHandleSupSub) || c && c.type === "operatorname" && c.alwaysHandleSupSub && (c.limits || t.style === D.DISPLAY) ? "munder" : "msub";
			}
		} else {
			var l = e.base;
			o = l && l.type === "op" && l.limits && (t.style === D.DISPLAY || l.alwaysHandleSupSub) || l && l.type === "operatorname" && l.alwaysHandleSupSub && (l.limits || t.style === D.DISPLAY) ? "mover" : "msup";
		}
		return new X.MathNode(o, a);
	}
}), zn({
	type: "atom",
	htmlBuilder(e, t) {
		return W.mathsym(e.text, e.mode, t, ["m" + e.family]);
	},
	mathmlBuilder(e, t) {
		var n = new X.MathNode("mo", [nr(e.text, e.mode)]);
		if (e.family === "bin") {
			var r = ir(e, t);
			r === "bold-italic" && n.setAttribute("mathvariant", r);
		} else e.family === "punct" ? n.setAttribute("separator", "true") : (e.family === "open" || e.family === "close") && n.setAttribute("stretchy", "false");
		return n;
	}
});
var na = {
	mi: "italic",
	mn: "normal",
	mtext: "normal"
};
zn({
	type: "mathord",
	htmlBuilder(e, t) {
		return W.makeOrd(e, t, "mathord");
	},
	mathmlBuilder(e, t) {
		var n = new X.MathNode("mi", [nr(e.text, e.mode, t)]), r = ir(e, t) || "italic";
		return r !== na[n.type] && n.setAttribute("mathvariant", r), n;
	}
}), zn({
	type: "textord",
	htmlBuilder(e, t) {
		return W.makeOrd(e, t, "textord");
	},
	mathmlBuilder(e, t) {
		var n = nr(e.text, e.mode, t), r = ir(e, t) || "normal", i;
		return i = e.mode === "text" ? new X.MathNode("mtext", [n]) : /[0-9]/.test(e.text) ? new X.MathNode("mn", [n]) : e.text === "\\prime" ? new X.MathNode("mo", [n]) : new X.MathNode("mi", [n]), r !== na[i.type] && i.setAttribute("mathvariant", r), i;
	}
});
var ra = {
	"\\nobreak": "nobreak",
	"\\allowbreak": "allowbreak"
}, ia = {
	" ": {},
	"\\ ": {},
	"~": { className: "nobreak" },
	"\\space": {},
	"\\nobreakspace": { className: "nobreak" }
};
zn({
	type: "spacing",
	htmlBuilder(e, t) {
		if (ia.hasOwnProperty(e.text)) {
			var n = ia[e.text].className || "";
			if (e.mode === "text") {
				var r = W.makeOrd(e, t, "textord");
				return r.classes.push(n), r;
			}
			return W.makeSpan(["mspace", n], [W.mathsym(e.text, e.mode, t)], t);
		}
		if (ra.hasOwnProperty(e.text)) return W.makeSpan(["mspace", ra[e.text]], [], t);
		throw new T("Unknown type of space \"" + e.text + "\"");
	},
	mathmlBuilder(e, t) {
		var n;
		if (ia.hasOwnProperty(e.text)) n = new X.MathNode("mtext", [new X.TextNode("\xA0")]);
		else {
			if (ra.hasOwnProperty(e.text)) return new X.MathNode("mspace");
			throw new T("Unknown type of space \"" + e.text + "\"");
		}
		return n;
	}
});
var aa = () => {
	var e = new X.MathNode("mtd", []);
	return e.setAttribute("width", "50%"), e;
};
zn({
	type: "tag",
	mathmlBuilder(e, t) {
		var n = new X.MathNode("mtable", [new X.MathNode("mtr", [
			aa(),
			new X.MathNode("mtd", [sr(e.body, t)]),
			aa(),
			new X.MathNode("mtd", [sr(e.tag, t)])
		])]);
		return n.setAttribute("width", "100%"), n;
	}
});
var oa = {
	"\\text": void 0,
	"\\textrm": "textrm",
	"\\textsf": "textsf",
	"\\texttt": "texttt",
	"\\textnormal": "textrm"
}, sa = {
	"\\textbf": "textbf",
	"\\textmd": "textmd"
}, ca = {
	"\\textit": "textit",
	"\\textup": "textup"
}, la = (e, t) => {
	var n = e.font;
	if (n) {
		if (oa[n]) return t.withTextFontFamily(oa[n]);
		if (sa[n]) return t.withTextFontWeight(sa[n]);
		if (n === "\\emph") return t.fontShape === "textit" ? t.withTextFontShape("textup") : t.withTextFontShape("textit");
	} else return t;
	return t.withTextFontShape(ca[n]);
};
K({
	type: "text",
	names: [
		"\\text",
		"\\textrm",
		"\\textsf",
		"\\texttt",
		"\\textnormal",
		"\\textbf",
		"\\textmd",
		"\\textit",
		"\\textup",
		"\\emph"
	],
	props: {
		numArgs: 1,
		argTypes: ["text"],
		allowedInArgument: !0,
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "text",
			mode: n.mode,
			body: q(i),
			font: r
		};
	},
	htmlBuilder(e, t) {
		var n = la(e, t), r = J(e.body, n, !0);
		return W.makeSpan(["mord", "text"], r, n);
	},
	mathmlBuilder(e, t) {
		var n = la(e, t);
		return sr(e.body, n);
	}
}), K({
	type: "underline",
	names: ["\\underline"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "underline",
			mode: n.mode,
			body: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = Y(e.body, t), r = W.makeLineSpan("underline-line", t), i = t.fontMetrics().defaultRuleThickness, a = W.makeVList({
			positionType: "top",
			positionData: n.height,
			children: [
				{
					type: "kern",
					size: i
				},
				{
					type: "elem",
					elem: r
				},
				{
					type: "kern",
					size: 3 * i
				},
				{
					type: "elem",
					elem: n
				}
			]
		}, t);
		return W.makeSpan(["mord", "underline"], [a], t);
	},
	mathmlBuilder(e, t) {
		var n = new X.MathNode("mo", [new X.TextNode("‾")]);
		n.setAttribute("stretchy", "true");
		var r = new X.MathNode("munder", [Z(e.body, t), n]);
		return r.setAttribute("accentunder", "true"), r;
	}
}), K({
	type: "vcenter",
	names: ["\\vcenter"],
	props: {
		numArgs: 1,
		argTypes: ["original"],
		allowedInText: !1
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "vcenter",
			mode: n.mode,
			body: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = Y(e.body, t), r = t.fontMetrics().axisHeight, i = .5 * (n.height - r - (n.depth + r));
		return W.makeVList({
			positionType: "shift",
			positionData: i,
			children: [{
				type: "elem",
				elem: n
			}]
		}, t);
	},
	mathmlBuilder(e, t) {
		return new X.MathNode("mpadded", [Z(e.body, t)], ["vcenter"]);
	}
}), K({
	type: "verb",
	names: ["\\verb"],
	props: {
		numArgs: 0,
		allowedInText: !0
	},
	handler(e, t, n) {
		throw new T("\\verb ended by end of line instead of matching delimiter");
	},
	htmlBuilder(e, t) {
		for (var n = ua(e), r = [], i = t.havingStyle(t.style.text()), a = 0; a < n.length; a++) {
			var o = n[a];
			o === "~" && (o = "\\textasciitilde"), r.push(W.makeSymbol(o, "Typewriter-Regular", e.mode, i, ["mord", "texttt"]));
		}
		return W.makeSpan(["mord", "text"].concat(i.sizingClasses(t)), W.tryCombineChars(r), i);
	},
	mathmlBuilder(e, t) {
		var n = new X.TextNode(ua(e)), r = new X.MathNode("mtext", [n]);
		return r.setAttribute("mathvariant", "monospace"), r;
	}
});
var ua = (e) => e.body.replace(/ /g, e.star ? "␣" : "\xA0"), da = In, fa = "[ \r\n	]", pa = "\\\\[a-zA-Z@]+", ma = "\\\\[^\ud800-\udfff]", ha = "(" + pa + ")" + fa + "*", ga = "\\\\(\n|[ \r	]+\n?)[ \r	]*", _a = "[̀-ͯ]", va = RegExp(_a + "+$"), ya = "(" + fa + "+)|" + (ga + "|") + "([!-\\[\\]-‧‪-퟿豈-￿]" + (_a + "*") + "|[\ud800-\udbff][\udc00-\udfff]" + (_a + "*") + "|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + ("|" + ha) + ("|" + ma + ")"), ba = class {
	constructor(e, t) {
		this.input = void 0, this.settings = void 0, this.tokenRegex = void 0, this.catcodes = void 0, this.input = e, this.settings = t, this.tokenRegex = new RegExp(ya, "g"), this.catcodes = {
			"%": 14,
			"~": 13
		};
	}
	setCatcode(e, t) {
		this.catcodes[e] = t;
	}
	lex() {
		var e = this.input, t = this.tokenRegex.lastIndex;
		if (t === e.length) return new ve("EOF", new _e(this, t, t));
		var n = this.tokenRegex.exec(e);
		if (n === null || n.index !== t) throw new T("Unexpected character: '" + e[t] + "'", new ve(e[t], new _e(this, t, t + 1)));
		var r = n[6] || n[3] || (n[2] ? "\\ " : " ");
		if (this.catcodes[r] === 14) {
			var i = e.indexOf("\n", this.tokenRegex.lastIndex);
			return i === -1 ? (this.tokenRegex.lastIndex = e.length, this.settings.reportNonstrict("commentAtEnd", "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)")) : this.tokenRegex.lastIndex = i + 1, this.lex();
		}
		return new ve(r, new _e(this, t, this.tokenRegex.lastIndex));
	}
}, xa = class {
	constructor(e, t) {
		e === void 0 && (e = {}), t === void 0 && (t = {}), this.current = void 0, this.builtins = void 0, this.undefStack = void 0, this.current = t, this.builtins = e, this.undefStack = [];
	}
	beginGroup() {
		this.undefStack.push({});
	}
	endGroup() {
		if (this.undefStack.length === 0) throw new T("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
		var e = this.undefStack.pop();
		for (var t in e) e.hasOwnProperty(t) && (e[t] == null ? delete this.current[t] : this.current[t] = e[t]);
	}
	endGroups() {
		for (; this.undefStack.length > 0;) this.endGroup();
	}
	has(e) {
		return this.current.hasOwnProperty(e) || this.builtins.hasOwnProperty(e);
	}
	get(e) {
		return this.current.hasOwnProperty(e) ? this.current[e] : this.builtins[e];
	}
	set(e, t, n) {
		if (n === void 0 && (n = !1), n) {
			for (var r = 0; r < this.undefStack.length; r++) delete this.undefStack[r][e];
			this.undefStack.length > 0 && (this.undefStack[this.undefStack.length - 1][e] = t);
		} else {
			var i = this.undefStack[this.undefStack.length - 1];
			i && !i.hasOwnProperty(e) && (i[e] = this.current[e]);
		}
		t == null ? delete this.current[e] : this.current[e] = t;
	}
}, Sa = Ci;
$("\\noexpand", function(e) {
	var t = e.popToken();
	return e.isExpandable(t.text) && (t.noexpand = !0, t.treatAsRelax = !0), {
		tokens: [t],
		numArgs: 0
	};
}), $("\\expandafter", function(e) {
	var t = e.popToken();
	return e.expandOnce(!0), {
		tokens: [t],
		numArgs: 0
	};
}), $("\\@firstoftwo", function(e) {
	return {
		tokens: e.consumeArgs(2)[0],
		numArgs: 0
	};
}), $("\\@secondoftwo", function(e) {
	return {
		tokens: e.consumeArgs(2)[1],
		numArgs: 0
	};
}), $("\\@ifnextchar", function(e) {
	var t = e.consumeArgs(3);
	e.consumeSpaces();
	var n = e.future();
	return t[0].length === 1 && t[0][0].text === n.text ? {
		tokens: t[1],
		numArgs: 0
	} : {
		tokens: t[2],
		numArgs: 0
	};
}), $("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}"), $("\\TextOrMath", function(e) {
	var t = e.consumeArgs(2);
	return e.mode === "text" ? {
		tokens: t[0],
		numArgs: 0
	} : {
		tokens: t[1],
		numArgs: 0
	};
});
var Ca = {
	0: 0,
	1: 1,
	2: 2,
	3: 3,
	4: 4,
	5: 5,
	6: 6,
	7: 7,
	8: 8,
	9: 9,
	a: 10,
	A: 10,
	b: 11,
	B: 11,
	c: 12,
	C: 12,
	d: 13,
	D: 13,
	e: 14,
	E: 14,
	f: 15,
	F: 15
};
$("\\char", function(e) {
	var t = e.popToken(), n, r = "";
	if (t.text === "'") n = 8, t = e.popToken();
	else if (t.text === "\"") n = 16, t = e.popToken();
	else if (t.text === "`") {
		if (t = e.popToken(), t.text[0] === "\\") r = t.text.charCodeAt(1);
		else {
			if (t.text === "EOF") throw new T("\\char` missing argument");
			r = t.text.charCodeAt(0);
		}
	} else n = 10;
	if (n) {
		if (r = Ca[t.text], r == null || r >= n) throw new T("Invalid base-" + n + " digit " + t.text);
		for (var i; (i = Ca[e.future().text]) != null && i < n;) r *= n, r += i, e.popToken();
	}
	return "\\@char{" + r + "}";
});
var wa = (e, t, n, r) => {
	var i = e.consumeArg().tokens;
	if (i.length !== 1) throw new T("\\newcommand's first argument must be a macro name");
	var a = i[0].text, o = e.isDefined(a);
	if (o && !t) throw new T("\\newcommand{" + a + "} attempting to redefine " + (a + "; use \\renewcommand"));
	if (!o && !n) throw new T("\\renewcommand{" + a + "} when command " + a + " does not yet exist; use \\newcommand");
	var s = 0;
	if (i = e.consumeArg().tokens, i.length === 1 && i[0].text === "[") {
		for (var c = "", l = e.expandNextToken(); l.text !== "]" && l.text !== "EOF";) c += l.text, l = e.expandNextToken();
		if (!c.match(/^\s*[0-9]+\s*$/)) throw new T("Invalid number of arguments: " + c);
		s = parseInt(c), i = e.consumeArg().tokens;
	}
	return o && r || e.macros.set(a, {
		tokens: i,
		numArgs: s
	}), "";
};
$("\\newcommand", (e) => wa(e, !1, !0, !1)), $("\\renewcommand", (e) => wa(e, !0, !1, !1)), $("\\providecommand", (e) => wa(e, !0, !0, !0)), $("\\message", (e) => {
	var t = e.consumeArgs(1)[0];
	return console.log(t.reverse().map((e) => e.text).join("")), "";
}), $("\\errmessage", (e) => {
	var t = e.consumeArgs(1)[0];
	return console.error(t.reverse().map((e) => e.text).join("")), "";
}), $("\\show", (e) => {
	var t = e.popToken(), n = t.text;
	return console.log(t, e.macros.get(n), da[n], A.math[n], A.text[n]), "";
}), $("\\bgroup", "{"), $("\\egroup", "}"), $("~", "\\nobreakspace"), $("\\lq", "`"), $("\\rq", "'"), $("\\aa", "\\r a"), $("\\AA", "\\r A"), $("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}"), $("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}"), $("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}"), $("ℬ", "\\mathscr{B}"), $("ℰ", "\\mathscr{E}"), $("ℱ", "\\mathscr{F}"), $("ℋ", "\\mathscr{H}"), $("ℐ", "\\mathscr{I}"), $("ℒ", "\\mathscr{L}"), $("ℳ", "\\mathscr{M}"), $("ℛ", "\\mathscr{R}"), $("ℭ", "\\mathfrak{C}"), $("ℌ", "\\mathfrak{H}"), $("ℨ", "\\mathfrak{Z}"), $("\\Bbbk", "\\Bbb{k}"), $("·", "\\cdotp"), $("\\llap", "\\mathllap{\\textrm{#1}}"), $("\\rlap", "\\mathrlap{\\textrm{#1}}"), $("\\clap", "\\mathclap{\\textrm{#1}}"), $("\\mathstrut", "\\vphantom{(}"), $("\\underbar", "\\underline{\\text{#1}}"), $("\\not", "\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char\"338}"), $("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}"), $("\\ne", "\\neq"), $("≠", "\\neq"), $("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}"), $("∉", "\\notin"), $("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}"), $("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}"), $("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}"), $("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}"), $("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}"), $("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}"), $("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}"), $("⟂", "\\perp"), $("‼", "\\mathclose{!\\mkern-0.8mu!}"), $("∌", "\\notni"), $("⌜", "\\ulcorner"), $("⌝", "\\urcorner"), $("⌞", "\\llcorner"), $("⌟", "\\lrcorner"), $("©", "\\copyright"), $("®", "\\textregistered"), $("️", "\\textregistered"), $("\\ulcorner", "\\html@mathml{\\@ulcorner}{\\mathop{\\char\"231c}}"), $("\\urcorner", "\\html@mathml{\\@urcorner}{\\mathop{\\char\"231d}}"), $("\\llcorner", "\\html@mathml{\\@llcorner}{\\mathop{\\char\"231e}}"), $("\\lrcorner", "\\html@mathml{\\@lrcorner}{\\mathop{\\char\"231f}}"), $("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}"), $("⋮", "\\vdots"), $("\\varGamma", "\\mathit{\\Gamma}"), $("\\varDelta", "\\mathit{\\Delta}"), $("\\varTheta", "\\mathit{\\Theta}"), $("\\varLambda", "\\mathit{\\Lambda}"), $("\\varXi", "\\mathit{\\Xi}"), $("\\varPi", "\\mathit{\\Pi}"), $("\\varSigma", "\\mathit{\\Sigma}"), $("\\varUpsilon", "\\mathit{\\Upsilon}"), $("\\varPhi", "\\mathit{\\Phi}"), $("\\varPsi", "\\mathit{\\Psi}"), $("\\varOmega", "\\mathit{\\Omega}"), $("\\substack", "\\begin{subarray}{c}#1\\end{subarray}"), $("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax"), $("\\boxed", "\\fbox{$\\displaystyle{#1}$}"), $("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;"), $("\\implies", "\\DOTSB\\;\\Longrightarrow\\;"), $("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;"), $("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}"), $("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
var Ta = {
	",": "\\dotsc",
	"\\not": "\\dotsb",
	"+": "\\dotsb",
	"=": "\\dotsb",
	"<": "\\dotsb",
	">": "\\dotsb",
	"-": "\\dotsb",
	"*": "\\dotsb",
	":": "\\dotsb",
	"\\DOTSB": "\\dotsb",
	"\\coprod": "\\dotsb",
	"\\bigvee": "\\dotsb",
	"\\bigwedge": "\\dotsb",
	"\\biguplus": "\\dotsb",
	"\\bigcap": "\\dotsb",
	"\\bigcup": "\\dotsb",
	"\\prod": "\\dotsb",
	"\\sum": "\\dotsb",
	"\\bigotimes": "\\dotsb",
	"\\bigoplus": "\\dotsb",
	"\\bigodot": "\\dotsb",
	"\\bigsqcup": "\\dotsb",
	"\\And": "\\dotsb",
	"\\longrightarrow": "\\dotsb",
	"\\Longrightarrow": "\\dotsb",
	"\\longleftarrow": "\\dotsb",
	"\\Longleftarrow": "\\dotsb",
	"\\longleftrightarrow": "\\dotsb",
	"\\Longleftrightarrow": "\\dotsb",
	"\\mapsto": "\\dotsb",
	"\\longmapsto": "\\dotsb",
	"\\hookrightarrow": "\\dotsb",
	"\\doteq": "\\dotsb",
	"\\mathbin": "\\dotsb",
	"\\mathrel": "\\dotsb",
	"\\relbar": "\\dotsb",
	"\\Relbar": "\\dotsb",
	"\\xrightarrow": "\\dotsb",
	"\\xleftarrow": "\\dotsb",
	"\\DOTSI": "\\dotsi",
	"\\int": "\\dotsi",
	"\\oint": "\\dotsi",
	"\\iint": "\\dotsi",
	"\\iiint": "\\dotsi",
	"\\iiiint": "\\dotsi",
	"\\idotsint": "\\dotsi",
	"\\DOTSX": "\\dotsx"
};
$("\\dots", function(e) {
	var t = "\\dotso", n = e.expandAfterFuture().text;
	return n in Ta ? t = Ta[n] : (n.slice(0, 4) === "\\not" || n in A.math && ["bin", "rel"].includes(A.math[n].group)) && (t = "\\dotsb"), t;
});
var Ea = {
	")": !0,
	"]": !0,
	"\\rbrack": !0,
	"\\}": !0,
	"\\rbrace": !0,
	"\\rangle": !0,
	"\\rceil": !0,
	"\\rfloor": !0,
	"\\rgroup": !0,
	"\\rmoustache": !0,
	"\\right": !0,
	"\\bigr": !0,
	"\\biggr": !0,
	"\\Bigr": !0,
	"\\Biggr": !0,
	$: !0,
	";": !0,
	".": !0,
	",": !0
};
$("\\dotso", function(e) {
	return e.future().text in Ea ? "\\ldots\\," : "\\ldots";
}), $("\\dotsc", function(e) {
	var t = e.future().text;
	return t in Ea && t !== "," ? "\\ldots\\," : "\\ldots";
}), $("\\cdots", function(e) {
	return e.future().text in Ea ? "\\@cdots\\," : "\\@cdots";
}), $("\\dotsb", "\\cdots"), $("\\dotsm", "\\cdots"), $("\\dotsi", "\\!\\cdots"), $("\\dotsx", "\\ldots\\,"), $("\\DOTSI", "\\relax"), $("\\DOTSB", "\\relax"), $("\\DOTSX", "\\relax"), $("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax"), $("\\,", "\\tmspace+{3mu}{.1667em}"), $("\\thinspace", "\\,"), $("\\>", "\\mskip{4mu}"), $("\\:", "\\tmspace+{4mu}{.2222em}"), $("\\medspace", "\\:"), $("\\;", "\\tmspace+{5mu}{.2777em}"), $("\\thickspace", "\\;"), $("\\!", "\\tmspace-{3mu}{.1667em}"), $("\\negthinspace", "\\!"), $("\\negmedspace", "\\tmspace-{4mu}{.2222em}"), $("\\negthickspace", "\\tmspace-{5mu}{.277em}"), $("\\enspace", "\\kern.5em "), $("\\enskip", "\\hskip.5em\\relax"), $("\\quad", "\\hskip1em\\relax"), $("\\qquad", "\\hskip2em\\relax"), $("\\tag", "\\@ifstar\\tag@literal\\tag@paren"), $("\\tag@paren", "\\tag@literal{({#1})}"), $("\\tag@literal", (e) => {
	if (e.macros.get("\\df@tag")) throw new T("Multiple \\tag");
	return "\\gdef\\df@tag{\\text{#1}}";
}), $("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}"), $("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)"), $("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}"), $("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1"), $("\\newline", "\\\\\\relax"), $("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var Da = k(ut["Main-Regular"][84][1] - .7 * ut["Main-Regular"][65][1]);
$("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + Da + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}"), $("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + Da + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}"), $("\\hspace", "\\@ifstar\\@hspacer\\@hspace"), $("\\@hspace", "\\hskip #1\\relax"), $("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax"), $("\\ordinarycolon", ":"), $("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}"), $("\\dblcolon", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char\"2237}}"), $("\\coloneqq", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char\"2254}}"), $("\\Coloneqq", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char\"2237\\char\"3d}}"), $("\\coloneq", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char\"3a\\char\"2212}}"), $("\\Coloneq", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char\"2237\\char\"2212}}"), $("\\eqqcolon", "\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char\"2255}}"), $("\\Eqqcolon", "\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char\"3d\\char\"2237}}"), $("\\eqcolon", "\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char\"2239}}"), $("\\Eqcolon", "\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char\"2212\\char\"2237}}"), $("\\colonapprox", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char\"3a\\char\"2248}}"), $("\\Colonapprox", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char\"2237\\char\"2248}}"), $("\\colonsim", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char\"3a\\char\"223c}}"), $("\\Colonsim", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char\"2237\\char\"223c}}"), $("∷", "\\dblcolon"), $("∹", "\\eqcolon"), $("≔", "\\coloneqq"), $("≕", "\\eqqcolon"), $("⩴", "\\Coloneqq"), $("\\ratio", "\\vcentcolon"), $("\\coloncolon", "\\dblcolon"), $("\\colonequals", "\\coloneqq"), $("\\coloncolonequals", "\\Coloneqq"), $("\\equalscolon", "\\eqqcolon"), $("\\equalscoloncolon", "\\Eqqcolon"), $("\\colonminus", "\\coloneq"), $("\\coloncolonminus", "\\Coloneq"), $("\\minuscolon", "\\eqcolon"), $("\\minuscoloncolon", "\\Eqcolon"), $("\\coloncolonapprox", "\\Colonapprox"), $("\\coloncolonsim", "\\Colonsim"), $("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}"), $("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}"), $("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}"), $("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}"), $("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}"), $("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}"), $("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}"), $("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}"), $("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}"), $("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}"), $("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}"), $("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}"), $("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}"), $("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}"), $("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}"), $("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}"), $("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}"), $("\\nleqq", "\\html@mathml{\\@nleqq}{≰}"), $("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}"), $("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}"), $("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}"), $("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}"), $("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}"), $("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}"), $("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}"), $("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}"), $("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}"), $("\\imath", "\\html@mathml{\\@imath}{ı}"), $("\\jmath", "\\html@mathml{\\@jmath}{ȷ}"), $("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}"), $("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}"), $("⟦", "\\llbracket"), $("⟧", "\\rrbracket"), $("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}"), $("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}"), $("⦃", "\\lBrace"), $("⦄", "\\rBrace"), $("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}"), $("⦵", "\\minuso"), $("\\darr", "\\downarrow"), $("\\dArr", "\\Downarrow"), $("\\Darr", "\\Downarrow"), $("\\lang", "\\langle"), $("\\rang", "\\rangle"), $("\\uarr", "\\uparrow"), $("\\uArr", "\\Uparrow"), $("\\Uarr", "\\Uparrow"), $("\\N", "\\mathbb{N}"), $("\\R", "\\mathbb{R}"), $("\\Z", "\\mathbb{Z}"), $("\\alef", "\\aleph"), $("\\alefsym", "\\aleph"), $("\\Alpha", "\\mathrm{A}"), $("\\Beta", "\\mathrm{B}"), $("\\bull", "\\bullet"), $("\\Chi", "\\mathrm{X}"), $("\\clubs", "\\clubsuit"), $("\\cnums", "\\mathbb{C}"), $("\\Complex", "\\mathbb{C}"), $("\\Dagger", "\\ddagger"), $("\\diamonds", "\\diamondsuit"), $("\\empty", "\\emptyset"), $("\\Epsilon", "\\mathrm{E}"), $("\\Eta", "\\mathrm{H}"), $("\\exist", "\\exists"), $("\\harr", "\\leftrightarrow"), $("\\hArr", "\\Leftrightarrow"), $("\\Harr", "\\Leftrightarrow"), $("\\hearts", "\\heartsuit"), $("\\image", "\\Im"), $("\\infin", "\\infty"), $("\\Iota", "\\mathrm{I}"), $("\\isin", "\\in"), $("\\Kappa", "\\mathrm{K}"), $("\\larr", "\\leftarrow"), $("\\lArr", "\\Leftarrow"), $("\\Larr", "\\Leftarrow"), $("\\lrarr", "\\leftrightarrow"), $("\\lrArr", "\\Leftrightarrow"), $("\\Lrarr", "\\Leftrightarrow"), $("\\Mu", "\\mathrm{M}"), $("\\natnums", "\\mathbb{N}"), $("\\Nu", "\\mathrm{N}"), $("\\Omicron", "\\mathrm{O}"), $("\\plusmn", "\\pm"), $("\\rarr", "\\rightarrow"), $("\\rArr", "\\Rightarrow"), $("\\Rarr", "\\Rightarrow"), $("\\real", "\\Re"), $("\\reals", "\\mathbb{R}"), $("\\Reals", "\\mathbb{R}"), $("\\Rho", "\\mathrm{P}"), $("\\sdot", "\\cdot"), $("\\sect", "\\S"), $("\\spades", "\\spadesuit"), $("\\sub", "\\subset"), $("\\sube", "\\subseteq"), $("\\supe", "\\supseteq"), $("\\Tau", "\\mathrm{T}"), $("\\thetasym", "\\vartheta"), $("\\weierp", "\\wp"), $("\\Zeta", "\\mathrm{Z}"), $("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}"), $("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}"), $("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits"), $("\\bra", "\\mathinner{\\langle{#1}|}"), $("\\ket", "\\mathinner{|{#1}\\rangle}"), $("\\braket", "\\mathinner{\\langle{#1}\\rangle}"), $("\\Bra", "\\left\\langle#1\\right|"), $("\\Ket", "\\left|#1\\right\\rangle");
var Oa = (e) => (t) => {
	var n = t.consumeArg().tokens, r = t.consumeArg().tokens, i = t.consumeArg().tokens, a = t.consumeArg().tokens, o = t.macros.get("|"), s = t.macros.get("\\|");
	t.macros.beginGroup();
	var c = (t) => (n) => {
		e && (n.macros.set("|", o), i.length && n.macros.set("\\|", s));
		var a = t;
		return !t && i.length && n.future().text === "|" && (n.popToken(), a = !0), {
			tokens: a ? i : r,
			numArgs: 0
		};
	};
	t.macros.set("|", c(!1)), i.length && t.macros.set("\\|", c(!0));
	var l = t.consumeArg().tokens, u = t.expandTokens([
		...a,
		...l,
		...n
	]);
	return t.macros.endGroup(), {
		tokens: u.reverse(),
		numArgs: 0
	};
};
$("\\bra@ket", Oa(!1)), $("\\bra@set", Oa(!0)), $("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}"), $("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}"), $("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}"), $("\\angln", "{\\angl n}"), $("\\blue", "\\textcolor{##6495ed}{#1}"), $("\\orange", "\\textcolor{##ffa500}{#1}"), $("\\pink", "\\textcolor{##ff00af}{#1}"), $("\\red", "\\textcolor{##df0030}{#1}"), $("\\green", "\\textcolor{##28ae7b}{#1}"), $("\\gray", "\\textcolor{gray}{#1}"), $("\\purple", "\\textcolor{##9d38bd}{#1}"), $("\\blueA", "\\textcolor{##ccfaff}{#1}"), $("\\blueB", "\\textcolor{##80f6ff}{#1}"), $("\\blueC", "\\textcolor{##63d9ea}{#1}"), $("\\blueD", "\\textcolor{##11accd}{#1}"), $("\\blueE", "\\textcolor{##0c7f99}{#1}"), $("\\tealA", "\\textcolor{##94fff5}{#1}"), $("\\tealB", "\\textcolor{##26edd5}{#1}"), $("\\tealC", "\\textcolor{##01d1c1}{#1}"), $("\\tealD", "\\textcolor{##01a995}{#1}"), $("\\tealE", "\\textcolor{##208170}{#1}"), $("\\greenA", "\\textcolor{##b6ffb0}{#1}"), $("\\greenB", "\\textcolor{##8af281}{#1}"), $("\\greenC", "\\textcolor{##74cf70}{#1}"), $("\\greenD", "\\textcolor{##1fab54}{#1}"), $("\\greenE", "\\textcolor{##0d923f}{#1}"), $("\\goldA", "\\textcolor{##ffd0a9}{#1}"), $("\\goldB", "\\textcolor{##ffbb71}{#1}"), $("\\goldC", "\\textcolor{##ff9c39}{#1}"), $("\\goldD", "\\textcolor{##e07d10}{#1}"), $("\\goldE", "\\textcolor{##a75a05}{#1}"), $("\\redA", "\\textcolor{##fca9a9}{#1}"), $("\\redB", "\\textcolor{##ff8482}{#1}"), $("\\redC", "\\textcolor{##f9685d}{#1}"), $("\\redD", "\\textcolor{##e84d39}{#1}"), $("\\redE", "\\textcolor{##bc2612}{#1}"), $("\\maroonA", "\\textcolor{##ffbde0}{#1}"), $("\\maroonB", "\\textcolor{##ff92c6}{#1}"), $("\\maroonC", "\\textcolor{##ed5fa6}{#1}"), $("\\maroonD", "\\textcolor{##ca337c}{#1}"), $("\\maroonE", "\\textcolor{##9e034e}{#1}"), $("\\purpleA", "\\textcolor{##ddd7ff}{#1}"), $("\\purpleB", "\\textcolor{##c6b9fc}{#1}"), $("\\purpleC", "\\textcolor{##aa87ff}{#1}"), $("\\purpleD", "\\textcolor{##7854ab}{#1}"), $("\\purpleE", "\\textcolor{##543b78}{#1}"), $("\\mintA", "\\textcolor{##f5f9e8}{#1}"), $("\\mintB", "\\textcolor{##edf2df}{#1}"), $("\\mintC", "\\textcolor{##e0e5cc}{#1}"), $("\\grayA", "\\textcolor{##f6f7f7}{#1}"), $("\\grayB", "\\textcolor{##f0f1f2}{#1}"), $("\\grayC", "\\textcolor{##e3e5e6}{#1}"), $("\\grayD", "\\textcolor{##d6d8da}{#1}"), $("\\grayE", "\\textcolor{##babec2}{#1}"), $("\\grayF", "\\textcolor{##888d93}{#1}"), $("\\grayG", "\\textcolor{##626569}{#1}"), $("\\grayH", "\\textcolor{##3b3e40}{#1}"), $("\\grayI", "\\textcolor{##21242c}{#1}"), $("\\kaBlue", "\\textcolor{##314453}{#1}"), $("\\kaGreen", "\\textcolor{##71B307}{#1}");
var ka = {
	"^": !0,
	_: !0,
	"\\limits": !0,
	"\\nolimits": !0
}, Aa = class {
	constructor(e, t, n) {
		this.settings = void 0, this.expansionCount = void 0, this.lexer = void 0, this.macros = void 0, this.stack = void 0, this.mode = void 0, this.settings = t, this.expansionCount = 0, this.feed(e), this.macros = new xa(Sa, t.macros), this.mode = n, this.stack = [];
	}
	feed(e) {
		this.lexer = new ba(e, this.settings);
	}
	switchMode(e) {
		this.mode = e;
	}
	beginGroup() {
		this.macros.beginGroup();
	}
	endGroup() {
		this.macros.endGroup();
	}
	endGroups() {
		this.macros.endGroups();
	}
	future() {
		return this.stack.length === 0 && this.pushToken(this.lexer.lex()), this.stack[this.stack.length - 1];
	}
	popToken() {
		return this.future(), this.stack.pop();
	}
	pushToken(e) {
		this.stack.push(e);
	}
	pushTokens(e) {
		this.stack.push(...e);
	}
	scanArgument(e) {
		var t, n, r;
		if (e) {
			if (this.consumeSpaces(), this.future().text !== "[") return null;
			t = this.popToken(), {tokens: r, end: n} = this.consumeArg(["]"]);
		} else ({tokens: r, start: t, end: n} = this.consumeArg());
		return this.pushToken(new ve("EOF", n.loc)), this.pushTokens(r), new ve("", _e.range(t, n));
	}
	consumeSpaces() {
		for (; this.future().text === " ";) this.stack.pop();
	}
	consumeArg(e) {
		var t = [], n = e && e.length > 0;
		n || this.consumeSpaces();
		var r = this.future(), i, a = 0, o = 0;
		do {
			if (i = this.popToken(), t.push(i), i.text === "{") ++a;
			else if (i.text === "}") {
				if (--a, a === -1) throw new T("Extra }", i);
			} else if (i.text === "EOF") throw new T("Unexpected end of input in a macro argument, expected '" + (e && n ? e[o] : "}") + "'", i);
			if (e && n) {
				if ((a === 0 || a === 1 && e[o] === "{") && i.text === e[o]) {
					if (++o, o === e.length) {
						t.splice(-o, o);
						break;
					}
				} else o = 0;
			}
		} while (a !== 0 || n);
		return r.text === "{" && t[t.length - 1].text === "}" && (t.pop(), t.shift()), t.reverse(), {
			tokens: t,
			start: r,
			end: i
		};
	}
	consumeArgs(e, t) {
		if (t) {
			if (t.length !== e + 1) throw new T("The length of delimiters doesn't match the number of args!");
			for (var n = t[0], r = 0; r < n.length; r++) {
				var i = this.popToken();
				if (n[r] !== i.text) throw new T("Use of the macro doesn't match its definition", i);
			}
		}
		for (var a = [], o = 0; o < e; o++) a.push(this.consumeArg(t && t[o + 1]).tokens);
		return a;
	}
	countExpansion(e) {
		if (this.expansionCount += e, this.expansionCount > this.settings.maxExpand) throw new T("Too many expansions: infinite loop or need to increase maxExpand setting");
	}
	expandOnce(e) {
		var t = this.popToken(), n = t.text, r = t.noexpand ? null : this._getExpansion(n);
		if (r == null || e && r.unexpandable) {
			if (e && r == null && n[0] === "\\" && !this.isDefined(n)) throw new T("Undefined control sequence: " + n);
			return this.pushToken(t), !1;
		}
		this.countExpansion(1);
		var i = r.tokens, a = this.consumeArgs(r.numArgs, r.delimiters);
		if (r.numArgs) {
			i = i.slice();
			for (var o = i.length - 1; o >= 0; --o) {
				var s = i[o];
				if (s.text === "#") {
					if (o === 0) throw new T("Incomplete placeholder at end of macro body", s);
					if (s = i[--o], s.text === "#") i.splice(o + 1, 1);
					else if (/^[1-9]$/.test(s.text)) i.splice(o, 2, ...a[s.text - 1]);
					else throw new T("Not a valid argument number", s);
				}
			}
		}
		return this.pushTokens(i), i.length;
	}
	expandAfterFuture() {
		return this.expandOnce(), this.future();
	}
	expandNextToken() {
		for (;;) if (this.expandOnce() === !1) {
			var e = this.stack.pop();
			return e.treatAsRelax && (e.text = "\\relax"), e;
		}
		throw Error();
	}
	expandMacro(e) {
		return this.macros.has(e) ? this.expandTokens([new ve(e)]) : void 0;
	}
	expandTokens(e) {
		var t = [], n = this.stack.length;
		for (this.pushTokens(e); this.stack.length > n;) if (this.expandOnce(!0) === !1) {
			var r = this.stack.pop();
			r.treatAsRelax &&= (r.noexpand = !1, !1), t.push(r);
		}
		return this.countExpansion(t.length), t;
	}
	expandMacroAsText(e) {
		var t = this.expandMacro(e);
		return t && t.map((e) => e.text).join("");
	}
	_getExpansion(e) {
		var t = this.macros.get(e);
		if (t == null) return t;
		if (e.length === 1) {
			var n = this.lexer.catcodes[e];
			if (n != null && n !== 13) return;
		}
		var r = typeof t == "function" ? t(this) : t;
		if (typeof r == "string") {
			var i = 0;
			if (r.indexOf("#") !== -1) for (var a = r.replace(/##/g, ""); a.indexOf("#" + (i + 1)) !== -1;) ++i;
			for (var o = new ba(r, this.settings), s = [], c = o.lex(); c.text !== "EOF";) s.push(c), c = o.lex();
			return s.reverse(), {
				tokens: s,
				numArgs: i
			};
		}
		return r;
	}
	isDefined(e) {
		return this.macros.has(e) || da.hasOwnProperty(e) || A.math.hasOwnProperty(e) || A.text.hasOwnProperty(e) || ka.hasOwnProperty(e);
	}
	isExpandable(e) {
		var t = this.macros.get(e);
		return t == null ? da.hasOwnProperty(e) && !da[e].primitive : typeof t == "string" || typeof t == "function" || !t.unexpandable;
	}
}, ja = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/, Ma = Object.freeze({
	"₊": "+",
	"₋": "-",
	"₌": "=",
	"₍": "(",
	"₎": ")",
	"₀": "0",
	"₁": "1",
	"₂": "2",
	"₃": "3",
	"₄": "4",
	"₅": "5",
	"₆": "6",
	"₇": "7",
	"₈": "8",
	"₉": "9",
	ₐ: "a",
	ₑ: "e",
	ₕ: "h",
	ᵢ: "i",
	ⱼ: "j",
	ₖ: "k",
	ₗ: "l",
	ₘ: "m",
	ₙ: "n",
	ₒ: "o",
	ₚ: "p",
	ᵣ: "r",
	ₛ: "s",
	ₜ: "t",
	ᵤ: "u",
	ᵥ: "v",
	ₓ: "x",
	ᵦ: "β",
	ᵧ: "γ",
	ᵨ: "ρ",
	ᵩ: "ϕ",
	ᵪ: "χ",
	"⁺": "+",
	"⁻": "-",
	"⁼": "=",
	"⁽": "(",
	"⁾": ")",
	"⁰": "0",
	"¹": "1",
	"²": "2",
	"³": "3",
	"⁴": "4",
	"⁵": "5",
	"⁶": "6",
	"⁷": "7",
	"⁸": "8",
	"⁹": "9",
	ᴬ: "A",
	ᴮ: "B",
	ᴰ: "D",
	ᴱ: "E",
	ᴳ: "G",
	ᴴ: "H",
	ᴵ: "I",
	ᴶ: "J",
	ᴷ: "K",
	ᴸ: "L",
	ᴹ: "M",
	ᴺ: "N",
	ᴼ: "O",
	ᴾ: "P",
	ᴿ: "R",
	ᵀ: "T",
	ᵁ: "U",
	ⱽ: "V",
	ᵂ: "W",
	ᵃ: "a",
	ᵇ: "b",
	ᶜ: "c",
	ᵈ: "d",
	ᵉ: "e",
	ᶠ: "f",
	ᵍ: "g",
	ʰ: "h",
	ⁱ: "i",
	ʲ: "j",
	ᵏ: "k",
	ˡ: "l",
	ᵐ: "m",
	ⁿ: "n",
	ᵒ: "o",
	ᵖ: "p",
	ʳ: "r",
	ˢ: "s",
	ᵗ: "t",
	ᵘ: "u",
	ᵛ: "v",
	ʷ: "w",
	ˣ: "x",
	ʸ: "y",
	ᶻ: "z",
	ᵝ: "β",
	ᵞ: "γ",
	ᵟ: "δ",
	ᵠ: "ϕ",
	ᵡ: "χ",
	ᶿ: "θ"
}), Na = {
	"́": {
		text: "\\'",
		math: "\\acute"
	},
	"̀": {
		text: "\\`",
		math: "\\grave"
	},
	"̈": {
		text: "\\\"",
		math: "\\ddot"
	},
	"̃": {
		text: "\\~",
		math: "\\tilde"
	},
	"̄": {
		text: "\\=",
		math: "\\bar"
	},
	"̆": {
		text: "\\u",
		math: "\\breve"
	},
	"̌": {
		text: "\\v",
		math: "\\check"
	},
	"̂": {
		text: "\\^",
		math: "\\hat"
	},
	"̇": {
		text: "\\.",
		math: "\\dot"
	},
	"̊": {
		text: "\\r",
		math: "\\mathring"
	},
	"̋": { text: "\\H" },
	"̧": { text: "\\c" }
}, Pa = {
	á: "á",
	à: "à",
	ä: "ä",
	ǟ: "ǟ",
	ã: "ã",
	ā: "ā",
	ă: "ă",
	ắ: "ắ",
	ằ: "ằ",
	ẵ: "ẵ",
	ǎ: "ǎ",
	â: "â",
	ấ: "ấ",
	ầ: "ầ",
	ẫ: "ẫ",
	ȧ: "ȧ",
	ǡ: "ǡ",
	å: "å",
	ǻ: "ǻ",
	ḃ: "ḃ",
	ć: "ć",
	ḉ: "ḉ",
	č: "č",
	ĉ: "ĉ",
	ċ: "ċ",
	ç: "ç",
	ď: "ď",
	ḋ: "ḋ",
	ḑ: "ḑ",
	é: "é",
	è: "è",
	ë: "ë",
	ẽ: "ẽ",
	ē: "ē",
	ḗ: "ḗ",
	ḕ: "ḕ",
	ĕ: "ĕ",
	ḝ: "ḝ",
	ě: "ě",
	ê: "ê",
	ế: "ế",
	ề: "ề",
	ễ: "ễ",
	ė: "ė",
	ȩ: "ȩ",
	ḟ: "ḟ",
	ǵ: "ǵ",
	ḡ: "ḡ",
	ğ: "ğ",
	ǧ: "ǧ",
	ĝ: "ĝ",
	ġ: "ġ",
	ģ: "ģ",
	ḧ: "ḧ",
	ȟ: "ȟ",
	ĥ: "ĥ",
	ḣ: "ḣ",
	ḩ: "ḩ",
	í: "í",
	ì: "ì",
	ï: "ï",
	ḯ: "ḯ",
	ĩ: "ĩ",
	ī: "ī",
	ĭ: "ĭ",
	ǐ: "ǐ",
	î: "î",
	ǰ: "ǰ",
	ĵ: "ĵ",
	ḱ: "ḱ",
	ǩ: "ǩ",
	ķ: "ķ",
	ĺ: "ĺ",
	ľ: "ľ",
	ļ: "ļ",
	ḿ: "ḿ",
	ṁ: "ṁ",
	ń: "ń",
	ǹ: "ǹ",
	ñ: "ñ",
	ň: "ň",
	ṅ: "ṅ",
	ņ: "ņ",
	ó: "ó",
	ò: "ò",
	ö: "ö",
	ȫ: "ȫ",
	õ: "õ",
	ṍ: "ṍ",
	ṏ: "ṏ",
	ȭ: "ȭ",
	ō: "ō",
	ṓ: "ṓ",
	ṑ: "ṑ",
	ŏ: "ŏ",
	ǒ: "ǒ",
	ô: "ô",
	ố: "ố",
	ồ: "ồ",
	ỗ: "ỗ",
	ȯ: "ȯ",
	ȱ: "ȱ",
	ő: "ő",
	ṕ: "ṕ",
	ṗ: "ṗ",
	ŕ: "ŕ",
	ř: "ř",
	ṙ: "ṙ",
	ŗ: "ŗ",
	ś: "ś",
	ṥ: "ṥ",
	š: "š",
	ṧ: "ṧ",
	ŝ: "ŝ",
	ṡ: "ṡ",
	ş: "ş",
	ẗ: "ẗ",
	ť: "ť",
	ṫ: "ṫ",
	ţ: "ţ",
	ú: "ú",
	ù: "ù",
	ü: "ü",
	ǘ: "ǘ",
	ǜ: "ǜ",
	ǖ: "ǖ",
	ǚ: "ǚ",
	ũ: "ũ",
	ṹ: "ṹ",
	ū: "ū",
	ṻ: "ṻ",
	ŭ: "ŭ",
	ǔ: "ǔ",
	û: "û",
	ů: "ů",
	ű: "ű",
	ṽ: "ṽ",
	ẃ: "ẃ",
	ẁ: "ẁ",
	ẅ: "ẅ",
	ŵ: "ŵ",
	ẇ: "ẇ",
	ẘ: "ẘ",
	ẍ: "ẍ",
	ẋ: "ẋ",
	ý: "ý",
	ỳ: "ỳ",
	ÿ: "ÿ",
	ỹ: "ỹ",
	ȳ: "ȳ",
	ŷ: "ŷ",
	ẏ: "ẏ",
	ẙ: "ẙ",
	ź: "ź",
	ž: "ž",
	ẑ: "ẑ",
	ż: "ż",
	Á: "Á",
	À: "À",
	Ä: "Ä",
	Ǟ: "Ǟ",
	Ã: "Ã",
	Ā: "Ā",
	Ă: "Ă",
	Ắ: "Ắ",
	Ằ: "Ằ",
	Ẵ: "Ẵ",
	Ǎ: "Ǎ",
	Â: "Â",
	Ấ: "Ấ",
	Ầ: "Ầ",
	Ẫ: "Ẫ",
	Ȧ: "Ȧ",
	Ǡ: "Ǡ",
	Å: "Å",
	Ǻ: "Ǻ",
	Ḃ: "Ḃ",
	Ć: "Ć",
	Ḉ: "Ḉ",
	Č: "Č",
	Ĉ: "Ĉ",
	Ċ: "Ċ",
	Ç: "Ç",
	Ď: "Ď",
	Ḋ: "Ḋ",
	Ḑ: "Ḑ",
	É: "É",
	È: "È",
	Ë: "Ë",
	Ẽ: "Ẽ",
	Ē: "Ē",
	Ḗ: "Ḗ",
	Ḕ: "Ḕ",
	Ĕ: "Ĕ",
	Ḝ: "Ḝ",
	Ě: "Ě",
	Ê: "Ê",
	Ế: "Ế",
	Ề: "Ề",
	Ễ: "Ễ",
	Ė: "Ė",
	Ȩ: "Ȩ",
	Ḟ: "Ḟ",
	Ǵ: "Ǵ",
	Ḡ: "Ḡ",
	Ğ: "Ğ",
	Ǧ: "Ǧ",
	Ĝ: "Ĝ",
	Ġ: "Ġ",
	Ģ: "Ģ",
	Ḧ: "Ḧ",
	Ȟ: "Ȟ",
	Ĥ: "Ĥ",
	Ḣ: "Ḣ",
	Ḩ: "Ḩ",
	Í: "Í",
	Ì: "Ì",
	Ï: "Ï",
	Ḯ: "Ḯ",
	Ĩ: "Ĩ",
	Ī: "Ī",
	Ĭ: "Ĭ",
	Ǐ: "Ǐ",
	Î: "Î",
	İ: "İ",
	Ĵ: "Ĵ",
	Ḱ: "Ḱ",
	Ǩ: "Ǩ",
	Ķ: "Ķ",
	Ĺ: "Ĺ",
	Ľ: "Ľ",
	Ļ: "Ļ",
	Ḿ: "Ḿ",
	Ṁ: "Ṁ",
	Ń: "Ń",
	Ǹ: "Ǹ",
	Ñ: "Ñ",
	Ň: "Ň",
	Ṅ: "Ṅ",
	Ņ: "Ņ",
	Ó: "Ó",
	Ò: "Ò",
	Ö: "Ö",
	Ȫ: "Ȫ",
	Õ: "Õ",
	Ṍ: "Ṍ",
	Ṏ: "Ṏ",
	Ȭ: "Ȭ",
	Ō: "Ō",
	Ṓ: "Ṓ",
	Ṑ: "Ṑ",
	Ŏ: "Ŏ",
	Ǒ: "Ǒ",
	Ô: "Ô",
	Ố: "Ố",
	Ồ: "Ồ",
	Ỗ: "Ỗ",
	Ȯ: "Ȯ",
	Ȱ: "Ȱ",
	Ő: "Ő",
	Ṕ: "Ṕ",
	Ṗ: "Ṗ",
	Ŕ: "Ŕ",
	Ř: "Ř",
	Ṙ: "Ṙ",
	Ŗ: "Ŗ",
	Ś: "Ś",
	Ṥ: "Ṥ",
	Š: "Š",
	Ṧ: "Ṧ",
	Ŝ: "Ŝ",
	Ṡ: "Ṡ",
	Ş: "Ş",
	Ť: "Ť",
	Ṫ: "Ṫ",
	Ţ: "Ţ",
	Ú: "Ú",
	Ù: "Ù",
	Ü: "Ü",
	Ǘ: "Ǘ",
	Ǜ: "Ǜ",
	Ǖ: "Ǖ",
	Ǚ: "Ǚ",
	Ũ: "Ũ",
	Ṹ: "Ṹ",
	Ū: "Ū",
	Ṻ: "Ṻ",
	Ŭ: "Ŭ",
	Ǔ: "Ǔ",
	Û: "Û",
	Ů: "Ů",
	Ű: "Ű",
	Ṽ: "Ṽ",
	Ẃ: "Ẃ",
	Ẁ: "Ẁ",
	Ẅ: "Ẅ",
	Ŵ: "Ŵ",
	Ẇ: "Ẇ",
	Ẍ: "Ẍ",
	Ẋ: "Ẋ",
	Ý: "Ý",
	Ỳ: "Ỳ",
	Ÿ: "Ÿ",
	Ỹ: "Ỹ",
	Ȳ: "Ȳ",
	Ŷ: "Ŷ",
	Ẏ: "Ẏ",
	Ź: "Ź",
	Ž: "Ž",
	Ẑ: "Ẑ",
	Ż: "Ż",
	ά: "ά",
	ὰ: "ὰ",
	ᾱ: "ᾱ",
	ᾰ: "ᾰ",
	έ: "έ",
	ὲ: "ὲ",
	ή: "ή",
	ὴ: "ὴ",
	ί: "ί",
	ὶ: "ὶ",
	ϊ: "ϊ",
	ΐ: "ΐ",
	ῒ: "ῒ",
	ῑ: "ῑ",
	ῐ: "ῐ",
	ό: "ό",
	ὸ: "ὸ",
	ύ: "ύ",
	ὺ: "ὺ",
	ϋ: "ϋ",
	ΰ: "ΰ",
	ῢ: "ῢ",
	ῡ: "ῡ",
	ῠ: "ῠ",
	ώ: "ώ",
	ὼ: "ὼ",
	Ύ: "Ύ",
	Ὺ: "Ὺ",
	Ϋ: "Ϋ",
	Ῡ: "Ῡ",
	Ῠ: "Ῠ",
	Ώ: "Ώ",
	Ὼ: "Ὼ"
}, Fa = class e {
	constructor(e, t) {
		this.mode = void 0, this.gullet = void 0, this.settings = void 0, this.leftrightDepth = void 0, this.nextToken = void 0, this.mode = "math", this.gullet = new Aa(e, t, this.mode), this.settings = t, this.leftrightDepth = 0;
	}
	expect(e, t) {
		if (t === void 0 && (t = !0), this.fetch().text !== e) throw new T("Expected '" + e + "', got '" + this.fetch().text + "'", this.fetch());
		t && this.consume();
	}
	consume() {
		this.nextToken = null;
	}
	fetch() {
		return this.nextToken ??= this.gullet.expandNextToken(), this.nextToken;
	}
	switchMode(e) {
		this.mode = e, this.gullet.switchMode(e);
	}
	parse() {
		this.settings.globalGroup || this.gullet.beginGroup(), this.settings.colorIsTextColor && this.gullet.macros.set("\\color", "\\textcolor");
		try {
			var e = this.parseExpression(!1);
			return this.expect("EOF"), this.settings.globalGroup || this.gullet.endGroup(), e;
		} finally {
			this.gullet.endGroups();
		}
	}
	subparse(e) {
		var t = this.nextToken;
		this.consume(), this.gullet.pushToken(new ve("}")), this.gullet.pushTokens(e);
		var n = this.parseExpression(!1);
		return this.expect("}"), this.nextToken = t, n;
	}
	parseExpression(t, n) {
		for (var r = [];;) {
			this.mode === "math" && this.consumeSpaces();
			var i = this.fetch();
			if (e.endOfExpression.indexOf(i.text) !== -1 || n && i.text === n || t && da[i.text] && da[i.text].infix) break;
			var a = this.parseAtom(n);
			if (a) {
				if (a.type === "internal") continue;
			} else break;
			r.push(a);
		}
		return this.mode === "text" && this.formLigatures(r), this.handleInfixNodes(r);
	}
	handleInfixNodes(e) {
		for (var t = -1, n, r = 0; r < e.length; r++) if (e[r].type === "infix") {
			if (t !== -1) throw new T("only one infix operator per group", e[r].token);
			t = r, n = e[r].replaceWith;
		}
		if (t !== -1 && n) {
			var i, a, o = e.slice(0, t), s = e.slice(t + 1);
			i = o.length === 1 && o[0].type === "ordgroup" ? o[0] : {
				type: "ordgroup",
				mode: this.mode,
				body: o
			}, a = s.length === 1 && s[0].type === "ordgroup" ? s[0] : {
				type: "ordgroup",
				mode: this.mode,
				body: s
			};
			var c;
			return c = n === "\\\\abovefrac" ? this.callFunction(n, [
				i,
				e[t],
				a
			], []) : this.callFunction(n, [i, a], []), [c];
		}
		return e;
	}
	handleSupSubscript(e) {
		var t = this.fetch(), n = t.text;
		this.consume(), this.consumeSpaces();
		var r;
		do
			r = this.parseGroup(e);
		while (r?.type === "internal");
		if (!r) throw new T("Expected group after '" + n + "'", t);
		return r;
	}
	formatUnsupportedCmd(e) {
		for (var t = [], n = 0; n < e.length; n++) t.push({
			type: "textord",
			mode: "text",
			text: e[n]
		});
		var r = {
			type: "text",
			mode: this.mode,
			body: t
		};
		return {
			type: "color",
			mode: this.mode,
			color: this.settings.errorColor,
			body: [r]
		};
	}
	parseAtom(e) {
		var t = this.parseGroup("atom", e);
		if (t?.type === "internal" || this.mode === "text") return t;
		for (var n, r;;) {
			this.consumeSpaces();
			var i = this.fetch();
			if (i.text === "\\limits" || i.text === "\\nolimits") {
				if (t && t.type === "op") t.limits = i.text === "\\limits", t.alwaysHandleSupSub = !0;
				else if (t && t.type === "operatorname") t.alwaysHandleSupSub && (t.limits = i.text === "\\limits");
				else throw new T("Limit controls must follow a math operator", i);
				this.consume();
			} else if (i.text === "^") {
				if (n) throw new T("Double superscript", i);
				n = this.handleSupSubscript("superscript");
			} else if (i.text === "_") {
				if (r) throw new T("Double subscript", i);
				r = this.handleSupSubscript("subscript");
			} else if (i.text === "'") {
				if (n) throw new T("Double superscript", i);
				var a = {
					type: "textord",
					mode: this.mode,
					text: "\\prime"
				}, o = [a];
				for (this.consume(); this.fetch().text === "'";) o.push(a), this.consume();
				this.fetch().text === "^" && o.push(this.handleSupSubscript("superscript")), n = {
					type: "ordgroup",
					mode: this.mode,
					body: o
				};
			} else if (Ma[i.text]) {
				var s = ja.test(i.text), c = [];
				for (c.push(new ve(Ma[i.text])), this.consume();;) {
					var l = this.fetch().text;
					if (!Ma[l] || ja.test(l) !== s) break;
					c.unshift(new ve(Ma[l])), this.consume();
				}
				var u = this.subparse(c);
				s ? r = {
					type: "ordgroup",
					mode: "math",
					body: u
				} : n = {
					type: "ordgroup",
					mode: "math",
					body: u
				};
			} else break;
		}
		return n || r ? {
			type: "supsub",
			mode: this.mode,
			base: t,
			sup: n,
			sub: r
		} : t;
	}
	parseFunction(e, t) {
		var n = this.fetch(), r = n.text, i = da[r];
		if (!i) return null;
		if (this.consume(), t && t !== "atom" && !i.allowedInArgument) throw new T("Got function '" + r + "' with no arguments" + (t ? " as " + t : ""), n);
		if (this.mode === "text" && !i.allowedInText) throw new T("Can't use function '" + r + "' in text mode", n);
		if (this.mode === "math" && i.allowedInMath === !1) throw new T("Can't use function '" + r + "' in math mode", n);
		var { args: a, optArgs: o } = this.parseArguments(r, i);
		return this.callFunction(r, a, o, n, e);
	}
	callFunction(e, t, n, r, i) {
		var a = {
			funcName: e,
			parser: this,
			token: r,
			breakOnTokenText: i
		}, o = da[e];
		if (o && o.handler) return o.handler(a, t, n);
		throw new T("No function handler for " + e);
	}
	parseArguments(e, t) {
		var n = t.numArgs + t.numOptionalArgs;
		if (n === 0) return {
			args: [],
			optArgs: []
		};
		for (var r = [], i = [], a = 0; a < n; a++) {
			var o = t.argTypes && t.argTypes[a], s = a < t.numOptionalArgs;
			(t.primitive && o == null || t.type === "sqrt" && a === 1 && i[0] == null) && (o = "primitive");
			var c = this.parseGroupOfType("argument to '" + e + "'", o, s);
			if (s) i.push(c);
			else if (c != null) r.push(c);
			else throw new T("Null argument, please report this as a bug");
		}
		return {
			args: r,
			optArgs: i
		};
	}
	parseGroupOfType(e, t, n) {
		switch (t) {
			case "color": return this.parseColorGroup(n);
			case "size": return this.parseSizeGroup(n);
			case "url": return this.parseUrlGroup(n);
			case "math":
			case "text": return this.parseArgumentGroup(n, t);
			case "hbox":
				var r = this.parseArgumentGroup(n, "text");
				return r == null ? null : {
					type: "styling",
					mode: r.mode,
					body: [r],
					style: "text"
				};
			case "raw":
				var i = this.parseStringGroup("raw", n);
				return i == null ? null : {
					type: "raw",
					mode: "text",
					string: i.text
				};
			case "primitive":
				if (n) throw new T("A primitive argument cannot be optional");
				var a = this.parseGroup(e);
				if (a == null) throw new T("Expected group as " + e, this.fetch());
				return a;
			case "original":
			case null:
			case void 0: return this.parseArgumentGroup(n);
			default: throw new T("Unknown group type as " + e, this.fetch());
		}
	}
	consumeSpaces() {
		for (; this.fetch().text === " ";) this.consume();
	}
	parseStringGroup(e, t) {
		var n = this.gullet.scanArgument(t);
		if (n == null) return null;
		for (var r = "", i; (i = this.fetch()).text !== "EOF";) r += i.text, this.consume();
		return this.consume(), n.text = r, n;
	}
	parseRegexGroup(e, t) {
		for (var n = this.fetch(), r = n, i = "", a; (a = this.fetch()).text !== "EOF" && e.test(i + a.text);) r = a, i += r.text, this.consume();
		if (i === "") throw new T("Invalid " + t + ": '" + n.text + "'", n);
		return n.range(r, i);
	}
	parseColorGroup(e) {
		var t = this.parseStringGroup("color", e);
		if (t == null) return null;
		var n = /^(#[a-f0-9]{3,4}|#[a-f0-9]{6}|#[a-f0-9]{8}|[a-f0-9]{6}|[a-z]+)$/i.exec(t.text);
		if (!n) throw new T("Invalid color: '" + t.text + "'", t);
		var r = n[0];
		return /^[0-9a-f]{6}$/i.test(r) && (r = "#" + r), {
			type: "color-token",
			mode: this.mode,
			color: r
		};
	}
	parseSizeGroup(e) {
		var t, n = !1;
		if (this.gullet.consumeSpaces(), t = !e && this.gullet.future().text !== "{" ? this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size") : this.parseStringGroup("size", e), !t) return null;
		!e && t.text.length === 0 && (t.text = "0pt", n = !0);
		var r = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(t.text);
		if (!r) throw new T("Invalid size: '" + t.text + "'", t);
		var i = {
			number: +(r[1] + r[2]),
			unit: r[3]
		};
		if (!Ct(i)) throw new T("Invalid unit: '" + i.unit + "'", t);
		return {
			type: "size",
			mode: this.mode,
			value: i,
			isBlank: n
		};
	}
	parseUrlGroup(e) {
		this.gullet.lexer.setCatcode("%", 13), this.gullet.lexer.setCatcode("~", 12);
		var t = this.parseStringGroup("url", e);
		if (this.gullet.lexer.setCatcode("%", 14), this.gullet.lexer.setCatcode("~", 13), t == null) return null;
		var n = t.text.replace(/\\([#$%&~_^{}])/g, "$1");
		return {
			type: "url",
			mode: this.mode,
			url: n
		};
	}
	parseArgumentGroup(e, t) {
		var n = this.gullet.scanArgument(e);
		if (n == null) return null;
		var r = this.mode;
		t && this.switchMode(t), this.gullet.beginGroup();
		var i = this.parseExpression(!1, "EOF");
		this.expect("EOF"), this.gullet.endGroup();
		var a = {
			type: "ordgroup",
			mode: this.mode,
			loc: n.loc,
			body: i
		};
		return t && this.switchMode(r), a;
	}
	parseGroup(e, t) {
		var n = this.fetch(), r = n.text, i;
		if (r === "{" || r === "\\begingroup") {
			this.consume();
			var a = r === "{" ? "}" : "\\endgroup";
			this.gullet.beginGroup();
			var o = this.parseExpression(!1, a), s = this.fetch();
			this.expect(a), this.gullet.endGroup(), i = {
				type: "ordgroup",
				mode: this.mode,
				loc: _e.range(n, s),
				body: o,
				semisimple: r === "\\begingroup" || void 0
			};
		} else if (i = this.parseFunction(t, e) || this.parseSymbol(), i == null && r[0] === "\\" && !ka.hasOwnProperty(r)) {
			if (this.settings.throwOnError) throw new T("Undefined control sequence: " + r, n);
			i = this.formatUnsupportedCmd(r), this.consume();
		}
		return i;
	}
	formLigatures(e) {
		for (var t = e.length - 1, n = 0; n < t; ++n) {
			var r = e[n], i = r.text;
			i === "-" && e[n + 1].text === "-" && (n + 1 < t && e[n + 2].text === "-" ? (e.splice(n, 3, {
				type: "textord",
				mode: "text",
				loc: _e.range(r, e[n + 2]),
				text: "---"
			}), t -= 2) : (e.splice(n, 2, {
				type: "textord",
				mode: "text",
				loc: _e.range(r, e[n + 1]),
				text: "--"
			}), --t)), (i === "'" || i === "`") && e[n + 1].text === i && (e.splice(n, 2, {
				type: "textord",
				mode: "text",
				loc: _e.range(r, e[n + 1]),
				text: i + i
			}), --t);
		}
	}
	parseSymbol() {
		var e = this.fetch(), t = e.text;
		if (/^\\verb[^a-zA-Z]/.test(t)) {
			this.consume();
			var n = t.slice(5), r = n.charAt(0) === "*";
			if (r && (n = n.slice(1)), n.length < 2 || n.charAt(0) !== n.slice(-1)) throw new T("\\verb assertion failed --\n                    please report what input caused this bug");
			return n = n.slice(1, -1), {
				type: "verb",
				mode: "text",
				body: n,
				star: r
			};
		}
		Pa.hasOwnProperty(t[0]) && !A[this.mode][t[0]] && (this.settings.strict && this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", "Accented Unicode text character \"" + t[0] + "\" used in math mode", e), t = Pa[t[0]] + t.slice(1));
		var i = va.exec(t);
		i && (t = t.substring(0, i.index), t === "i" ? t = "ı" : t === "j" && (t = "ȷ"));
		var a;
		if (A[this.mode][t]) {
			this.settings.strict && this.mode === "math" && on.indexOf(t) >= 0 && this.settings.reportNonstrict("unicodeTextInMathMode", "Latin-1/Unicode text character \"" + t[0] + "\" used in math mode", e);
			var o = A[this.mode][t].group, s = _e.range(e), c;
			if (zt.hasOwnProperty(o)) {
				var l = o;
				c = {
					type: "atom",
					mode: this.mode,
					family: l,
					loc: s,
					text: t
				};
			} else c = {
				type: o,
				mode: this.mode,
				loc: s,
				text: t
			};
			a = c;
		} else if (t.charCodeAt(0) >= 128) this.settings.strict && (Xe(t.charCodeAt(0)) ? this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", "Unicode text character \"" + t[0] + "\" used in math mode", e) : this.settings.reportNonstrict("unknownSymbol", "Unrecognized Unicode character \"" + t[0] + "\"" + (" (" + t.charCodeAt(0) + ")"), e)), a = {
			type: "textord",
			mode: "text",
			loc: _e.range(e),
			text: t
		};
		else return null;
		if (this.consume(), i) for (var u = 0; u < i[0].length; u++) {
			var d = i[0][u];
			if (!Na[d]) throw new T("Unknown accent ' " + d + "'", e);
			var f = Na[d][this.mode] || Na[d].text;
			if (!f) throw new T("Accent " + d + " unsupported in " + this.mode + " mode", e);
			a = {
				type: "accent",
				mode: this.mode,
				loc: _e.range(e),
				label: f,
				isStretchy: !1,
				isShifty: !0,
				base: a
			};
		}
		return a;
	}
};
Fa.endOfExpression = [
	"}",
	"\\endgroup",
	"\\end",
	"\\right",
	"&"
];
var Ia = function(e, t) {
	if (!(typeof e == "string" || e instanceof String)) throw TypeError("KaTeX can only parse string typed expression");
	var n = new Fa(e, t);
	delete n.gullet.macros.current["\\df@tag"];
	var r = n.parse();
	if (delete n.gullet.macros.current["\\current@color"], delete n.gullet.macros.current["\\color"], n.gullet.macros.get("\\df@tag")) {
		if (!t.displayMode) throw new T("\\tag works only in display equations");
		r = [{
			type: "tag",
			mode: "text",
			body: r,
			tag: n.subparse([new ve("\\df@tag")])
		}];
	}
	return r;
}, La = function(e, t, n) {
	t.textContent = "";
	var r = Va(e, n).toNode();
	t.appendChild(r);
};
typeof document < "u" && document.compatMode !== "CSS1Compat" && (typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype."), La = function() {
	throw new T("KaTeX doesn't work in quirks mode.");
});
var Ra = function(e, t) {
	return Va(e, t).toMarkup();
}, za = function(e, t) {
	return Ia(e, new Ae(t));
}, Ba = function(e, t, n) {
	if (n.throwOnError || !(e instanceof T)) throw e;
	var r = W.makeSpan(["katex-error"], [new Nt(t)]);
	return r.setAttribute("title", e.toString()), r.setAttribute("style", "color:" + n.errorColor), r;
}, Va = function(e, t) {
	var n = new Ae(t);
	try {
		return dr(Ia(e, n), e, n);
	} catch (t) {
		return Ba(t, e, n);
	}
}, Ha = {
	version: "0.16.25",
	render: La,
	renderToString: Ra,
	ParseError: T,
	SETTINGS_SCHEMA: Oe,
	__parse: za,
	__renderToDomTree: Va,
	__renderToHTMLTree: function(e, t) {
		var n = new Ae(t);
		try {
			return fr(Ia(e, n), e, n);
		} catch (t) {
			return Ba(t, e, n);
		}
	},
	__setFontMetrics: pt,
	__defineSymbol: j,
	__defineFunction: K,
	__defineMacro: $,
	__domTree: {
		Span: kt,
		Anchor: At,
		SymbolNode: Nt,
		SvgNode: Pt,
		PathNode: Ft,
		LineNode: It
	}
}, Ua = {}, Wa = [];
function Ga(e) {
	let r = e || Ua;
	return function(e, i) {
		n(e, "element", function(e, n) {
			let a = Array.isArray(e.properties.className) ? e.properties.className : Wa, o = a.includes("language-math"), s = a.includes("math-display"), c = a.includes("math-inline"), l = s;
			if (!o && !s && !c) return;
			let u = n[n.length - 1], d = e;
			if (e.tagName === "code" && o && u && u.type === "element" && u.tagName === "pre" && (d = u, u = n[n.length - 2], l = !0), !u) return;
			let f = se(d, { whitespace: "pre" }), p;
			try {
				p = Ha.renderToString(f, {
					...r,
					displayMode: l,
					throwOnError: !0
				});
			} catch (t) {
				let a = t, o = a.name.toLowerCase();
				i.message("Could not render math with KaTeX", {
					ancestors: [...n, e],
					cause: a,
					place: e.position,
					ruleId: o,
					source: "rehype-katex"
				});
				try {
					p = Ha.renderToString(f, {
						...r,
						displayMode: l,
						strict: "ignore",
						throwOnError: !1
					});
				} catch {
					p = [{
						type: "element",
						tagName: "span",
						properties: {
							className: ["katex-error"],
							style: "color:" + (r.errorColor || "#cc0000"),
							title: String(t)
						},
						children: [{
							type: "text",
							value: f
						}]
					}];
				}
			}
			typeof p == "string" && (p = h(p).children);
			let m = u.children.indexOf(d);
			return u.children.splice(m, 1, ...p), t;
		});
	};
}
//#endregion
export { Ga as default };

//# sourceMappingURL=index-Dtcf4I45-E72W2s2m.js.map