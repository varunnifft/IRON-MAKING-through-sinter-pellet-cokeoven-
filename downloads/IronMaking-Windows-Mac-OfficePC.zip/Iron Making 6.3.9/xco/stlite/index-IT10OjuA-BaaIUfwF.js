import { Fi as e } from "./index-B1FrxEMd-BsPMjC5n.js";
import { get as t } from "./index-B5zsQkH1-CuJj9n5q.js";
//#region ../react/build/index-IT10OjuA.js
var n = [
	{
		description: "angry face",
		emoji: "😠",
		emoticons: [
			">:(",
			">:[",
			">:-(",
			">:-[",
			">=(",
			">=[",
			">=-(",
			">=-["
		],
		name: "angry",
		tags: ["mad", "annoyed"]
	},
	{
		description: "smiling face with smiling eyes",
		emoji: "😊",
		emoticons: [
			":\")",
			":\"]",
			":\"D",
			":-\")",
			":-\"]",
			":-\"D",
			"=\")",
			"=\"]",
			"=\"D",
			"=-\")",
			"=-\"]",
			"=-\"D"
		],
		name: "blush",
		tags: ["proud"]
	},
	{
		description: "broken heart",
		emoji: "💔",
		emoticons: ["<\\3", "</3"],
		name: "broken_heart",
		tags: []
	},
	{
		description: "confused face",
		emoji: "😕",
		emoticons: [
			":/",
			":\\",
			":-/",
			":-\\",
			"=/",
			"=\\",
			"=-/",
			"=-\\"
		],
		name: "confused",
		tags: []
	},
	{
		description: "crying face",
		emoji: "😢",
		emoticons: [
			":,(",
			":,[",
			":,|",
			":,-(",
			":,-[",
			":,-|",
			":'(",
			":'[",
			":'|",
			":'-(",
			":'-[",
			":'-|",
			"=,(",
			"=,[",
			"=,|",
			"=,-(",
			"=,-[",
			"=,-|",
			"='(",
			"='[",
			"='|",
			"='-(",
			"='-[",
			"='-|",
			"T-T"
		],
		name: "cry",
		tags: ["sad", "tear"]
	},
	{
		description: "frowning face with open mouth",
		emoji: "😦",
		emoticons: [
			":(",
			":[",
			":-(",
			":-[",
			"=(",
			"=[",
			"=-(",
			"=-["
		],
		name: "frowning",
		tags: []
	},
	{
		description: "red heart",
		emoji: "❤️",
		emoticons: ["<3"],
		name: "heart",
		tags: ["love"]
	},
	{
		description: "angry face with horns",
		emoji: "👿",
		emoticons: [
			"]:(",
			"]:[",
			"]:-(",
			"]:-[",
			"]=(",
			"]=[",
			"]=-(",
			"]=-["
		],
		name: "imp",
		tags: [
			"angry",
			"devil",
			"evil",
			"horns"
		]
	},
	{
		description: "smiling face with halo",
		emoji: "😇",
		emoticons: /* @__PURE__ */ "o:).o:].o:D.o:-).o:-].o:-D.o=).o=].o=D.o=-).o=-].o=-D.O:).O:].O:D.O:-).O:-].O:-D.O=).O=].O=D.O=-).O=-].O=-D.0:).0:].0:D.0:-).0:-].0:-D.0=).0=].0=D.0=-).0=-].0=-D".split("."),
		name: "innocent",
		tags: ["angel"]
	},
	{
		description: "face with tears of joy",
		emoji: "😂",
		emoticons: [
			":,)",
			":,]",
			":,D",
			":,-)",
			":,-]",
			":,-D",
			":')",
			":']",
			":'D",
			":'-)",
			":'-]",
			":'-D",
			"=,)",
			"=,]",
			"=,D",
			"=,-)",
			"=,-]",
			"=,-D",
			"=')",
			"=']",
			"='D",
			"='-)",
			"='-]",
			"='-D"
		],
		name: "joy",
		tags: ["tears"]
	},
	{
		description: "kissing face",
		emoji: "😗",
		emoticons: [
			":*",
			":-*",
			"=*",
			"=-*"
		],
		name: "kissing",
		tags: []
	},
	{
		description: "grinning squinting face",
		emoji: "😆",
		emoticons: [
			"x)",
			"x]",
			"xD",
			"x-)",
			"x-]",
			"x-D",
			"X)",
			"X]",
			"X-)",
			"X-]",
			"X-D"
		],
		name: "laughing",
		tags: ["happy", "haha"]
	},
	{
		description: "man",
		emoji: "👨",
		emoticons: [
			":3",
			":-3",
			"=3",
			"=-3",
			";3",
			";-3",
			"x3",
			"x-3",
			"X3",
			"X-3"
		],
		name: "man",
		tags: [
			"mustache",
			"father",
			"dad"
		]
	},
	{
		description: "neutral face",
		emoji: "😐",
		emoticons: [
			":|",
			":-|",
			"=|",
			"=-|"
		],
		name: "neutral_face",
		tags: ["meh"]
	},
	{
		description: "face without mouth",
		emoji: "😶",
		emoticons: [":-"],
		name: "no_mouth",
		tags: ["mute", "silence"]
	},
	{
		description: "face with open mouth",
		emoji: "😮",
		emoticons: [
			":o",
			":O",
			":0",
			":-o",
			":-O",
			":-0",
			"=o",
			"=O",
			"=0",
			"=-o",
			"=-O",
			"=-0"
		],
		name: "open_mouth",
		tags: [
			"surprise",
			"impressed",
			"wow"
		]
	},
	{
		description: "enraged face",
		emoji: "😡",
		emoticons: [
			":@",
			":-@",
			"=@",
			"=-@"
		],
		name: "rage",
		tags: ["angry"]
	},
	{
		description: "grinning face with smiling eyes",
		emoji: "😄",
		emoticons: [
			":D",
			":-D",
			"=D",
			"=-D"
		],
		name: "smile",
		tags: [
			"happy",
			"joy",
			"laugh",
			"pleased"
		]
	},
	{
		description: "grinning face with big eyes",
		emoji: "😃",
		emoticons: [
			":)",
			":]",
			":-)",
			":-]",
			"=)",
			"=]",
			"=-)",
			"=-]"
		],
		name: "smiley",
		tags: [
			"happy",
			"joy",
			"haha"
		]
	},
	{
		description: "smiling face with horns",
		emoji: "😈",
		emoticons: [
			"]:)",
			"]:]",
			"]:D",
			"]:-)",
			"]:-]",
			"]:-D",
			"]=)",
			"]=]",
			"]=D",
			"]=-)",
			"]=-]",
			"]=-D"
		],
		name: "smiling_imp",
		tags: [
			"devil",
			"evil",
			"horns"
		]
	},
	{
		description: "loudly crying face",
		emoji: "😭",
		emoticons: [
			":,'(",
			":,'[",
			":,'-(",
			":,'-[",
			":',(",
			":',[",
			":',-(",
			":',-[",
			"=,'(",
			"=,'[",
			"=,'-(",
			"=,'-[",
			"=',(",
			"=',[",
			"=',-(",
			"=',-["
		],
		name: "sob",
		tags: [
			"sad",
			"cry",
			"bawling"
		]
	},
	{
		description: "face with tongue",
		emoji: "😛",
		emoticons: [
			":p",
			":P",
			":d",
			":-p",
			":-P",
			":-d",
			"=p",
			"=P",
			"=d",
			"=-p",
			"=-P",
			"=-d"
		],
		name: "stuck_out_tongue",
		tags: []
	},
	{
		description: "squinting face with tongue",
		emoji: "😝",
		emoticons: [
			"xP",
			"x-p",
			"x-P",
			"x-d",
			"Xp",
			"Xd",
			"X-p",
			"X-P",
			"X-d"
		],
		name: "stuck_out_tongue_closed_eyes",
		tags: ["prank"]
	},
	{
		description: "winking face with tongue",
		emoji: "😜",
		emoticons: [
			";p",
			";P",
			";d",
			";-p",
			";-P",
			";-d"
		],
		name: "stuck_out_tongue_winking_eye",
		tags: ["prank", "silly"]
	},
	{
		description: "smiling face with sunglasses",
		emoji: "😎",
		emoticons: [
			"8)",
			"8]",
			"8D",
			"8-)",
			"8-]",
			"8-D",
			"B)",
			"B]",
			"B-)",
			"B-]",
			"B-D"
		],
		name: "sunglasses",
		tags: ["cool"]
	},
	{
		description: "downcast face with sweat",
		emoji: "😓",
		emoticons: [
			",:(",
			",:[",
			",:-(",
			",:-[",
			",=(",
			",=[",
			",=-(",
			",=-[",
			"':(",
			"':[",
			"':-(",
			"':-[",
			"'=(",
			"'=[",
			"'=-(",
			"'=-["
		],
		name: "sweat",
		tags: []
	},
	{
		description: "grinning face with sweat",
		emoji: "😅",
		emoticons: [
			",:)",
			",:]",
			",:D",
			",:-)",
			",:-]",
			",:-D",
			",=)",
			",=]",
			",=D",
			",=-)",
			",=-]",
			",=-D",
			"':)",
			"':]",
			"':D",
			"':-)",
			"':-]",
			"':-D",
			"'=)",
			"'=]",
			"'=D",
			"'=-)",
			"'=-]",
			"'=-D"
		],
		name: "sweat_smile",
		tags: ["hot"]
	},
	{
		description: "unamused face",
		emoji: "😒",
		emoticons: [
			":$",
			":s",
			":z",
			":S",
			":Z",
			":-$",
			":-s",
			":-z",
			":-S",
			":-Z",
			"=$",
			"=s",
			"=z",
			"=S",
			"=Z",
			"=-$",
			"=-s",
			"=-z",
			"=-S",
			"=-Z"
		],
		name: "unamused",
		tags: ["meh"]
	},
	{
		description: "winking face",
		emoji: "😉",
		emoticons: [
			";)",
			";]",
			";D",
			";-)",
			";-]",
			";-D"
		],
		name: "wink",
		tags: ["flirt"]
	}
], r = /:\+1:|:-1:|:[\w-]+:/g, i = /(^|\s)[@$|*'",;.=:\-)([\]\\/<>038BOopPsSdDxXzZ]{2,5}/g, a = /(?:_|-(?!1))/g, o = {
	padSpaceAfter: !1,
	emoticon: !1,
	accessible: !1
}, s = (s) => {
	let c = Object.assign({}, o, s), l = !!c.padSpaceAfter, u = !!c.emoticon, d = !!c.accessible;
	function f(e, t) {
		return {
			type: "text",
			value: e,
			data: {
				hName: "span",
				hProperties: {
					role: "img",
					ariaLabel: t
				},
				hChildren: [{
					type: "text",
					value: e
				}]
			}
		};
	}
	function p(e) {
		let t = n.find((t) => t.emoticons.includes(e)), r = n.find((t) => t.emoticons.includes(e.slice(0, -1))), i = n.find((t) => t.emoticons.includes(e.slice(1))), a = n.find((t) => t.emoticons.includes(e.slice(1, -1))), o = t || r || i || a;
		if (!o) return !1;
		let s = !(t || i) && (a || r) ? e.slice(-1) : "", c = !(t || r) && (a || i) ? e.slice(0, 1) : "", u = l ? " " : "", p = c + o.emoji + u + s;
		return d ? f(p, o.name + " emoticon") : p;
	}
	function m(e) {
		let n = t(e);
		if (typeof n > "u") return !1;
		if (l && (n += " "), d) {
			let t = e.slice(1, -1).replace(a, " ") + " emoji";
			return f(n, t);
		}
		return n;
	}
	let h = [[r, m]];
	u && h.push([i, p]);
	function g(t) {
		e(t, h);
	}
	return g;
};
//#endregion
export { s as default };

//# sourceMappingURL=index-IT10OjuA-BaaIUfwF.js.map