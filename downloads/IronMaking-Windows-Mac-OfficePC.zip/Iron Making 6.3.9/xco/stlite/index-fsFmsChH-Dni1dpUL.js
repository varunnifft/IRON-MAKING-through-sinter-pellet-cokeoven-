import { Pi as e, Qa as t, da as n, jo as r, no as i, to as a } from "./index-B1FrxEMd-BsPMjC5n.js";
//#region ../react/build/index-fsFmsChH.js
var o = /[#.]/g;
function s(e, t) {
	let n = e || "", r = {}, i = 0, a, s;
	for (; i < n.length;) {
		o.lastIndex = i;
		let e = o.exec(n), t = n.slice(i, e ? e.index : n.length);
		t && (a ? a === "#" ? r.id = t : Array.isArray(r.className) ? r.className.push(t) : r.className = [t] : s = t, i += t.length), e && (a = e[0], i++);
	}
	return {
		type: "element",
		tagName: s || t || "div",
		properties: r,
		children: []
	};
}
function c(e, t, n) {
	let r = n ? m(n) : void 0;
	function i(n, i, ...a) {
		let o;
		if (n == null) {
			o = {
				type: "root",
				children: []
			};
			let e = i;
			a.unshift(e);
		} else {
			o = s(n, t);
			let c = o.tagName.toLowerCase(), d = r ? r.get(c) : void 0;
			if (o.tagName = d || c, l(i)) a.unshift(i);
			else for (let [t, n] of Object.entries(i)) u(e, o.properties, t, n);
		}
		for (let e of a) d(o.children, e);
		return o.type === "element" && o.tagName === "template" && (o.content = {
			type: "root",
			children: o.children
		}, o.children = []), o;
	}
	return i;
}
function l(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !0;
	if (typeof e.type != "string") return !1;
	let t = e, n = Object.keys(e);
	for (let e of n) {
		let n = t[e];
		if (n && typeof n == "object") {
			if (!Array.isArray(n)) return !0;
			let e = n;
			for (let t of e) if (typeof t != "number" && typeof t != "string") return !0;
		}
	}
	return !!("children" in e && Array.isArray(e.children));
}
function u(t, n, r, o) {
	let s = e(t, r), c;
	if (o != null) {
		if (typeof o == "number") {
			if (Number.isNaN(o)) return;
			c = o;
		} else c = typeof o == "boolean" ? o : typeof o == "string" ? s.spaceSeparated ? a(o) : s.commaSeparated ? i(o) : s.commaOrSpaceSeparated ? a(i(o).join(" ")) : f(s, s.property, o) : Array.isArray(o) ? [...o] : s.property === "style" ? p(o) : String(o);
		if (Array.isArray(c)) {
			let e = [];
			for (let t of c) e.push(f(s, s.property, t));
			c = e;
		}
		s.property === "className" && Array.isArray(n.className) && (c = n.className.concat(c)), n[s.property] = c;
	}
}
function d(e, t) {
	if (t != null) {
		if (typeof t == "number" || typeof t == "string") e.push({
			type: "text",
			value: String(t)
		});
		else if (Array.isArray(t)) for (let n of t) d(e, n);
		else if (typeof t == "object" && "type" in t) t.type === "root" ? d(e, t.children) : e.push(t);
		else throw Error("Expected node, nodes, or string, got `" + t + "`");
	}
}
function f(e, n, r) {
	if (typeof r == "string") {
		if (e.number && r && !Number.isNaN(Number(r))) return Number(r);
		if ((e.boolean || e.overloadedBoolean) && (r === "" || t(r) === t(n))) return !0;
	}
	return r;
}
function p(e) {
	let t = [];
	for (let [n, r] of Object.entries(e)) t.push([n, r].join(": "));
	return t.join("; ");
}
function m(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.toLowerCase(), n);
	return t;
}
var h = /* @__PURE__ */ "altGlyph.altGlyphDef.altGlyphItem.animateColor.animateMotion.animateTransform.clipPath.feBlend.feColorMatrix.feComponentTransfer.feComposite.feConvolveMatrix.feDiffuseLighting.feDisplacementMap.feDistantLight.feDropShadow.feFlood.feFuncA.feFuncB.feFuncG.feFuncR.feGaussianBlur.feImage.feMerge.feMergeNode.feMorphology.feOffset.fePointLight.feSpecularLighting.feSpotLight.feTile.feTurbulence.foreignObject.glyphRef.linearGradient.radialGradient.solidColor.textArea.textPath".split("."), g = c(n, "div"), _ = c(r, "g", h);
//#endregion
export { _ as n, g as t };

//# sourceMappingURL=index-fsFmsChH-Dni1dpUL.js.map