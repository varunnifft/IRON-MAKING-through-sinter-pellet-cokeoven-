import { N as e, Q as t, T as n, ai as r, aj as i, am as a, an as o, bB as s, bi as c, bx as l, by as u, bz as d, c as f, q as p } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
//#region ../react/build/ishikawaDiagram-5VMMS53U--xj-wijF.js
var m = function() {
	var e = /* @__PURE__ */ f(function(e, t, n, r) {
		for (n ||= {}, r = e.length; r--; n[e[r]] = t);
		return n;
	}, "o"), t = [1, 4], n = [1, 14], r = [1, 12], i = [1, 13], a = [
		6,
		7,
		8
	], o = [1, 20], s = [1, 18], c = [1, 19], l = [
		6,
		7,
		11
	], u = [
		1,
		6,
		13,
		14
	], d = [1, 23], p = [1, 24], m = [
		1,
		6,
		7,
		11,
		13,
		14
	], h = {
		trace: /* @__PURE__ */ f(function() {}, "trace"),
		yy: {},
		symbols_: {
			error: 2,
			start: 3,
			ishikawa: 4,
			spaceLines: 5,
			SPACELINE: 6,
			NL: 7,
			ISHIKAWA: 8,
			document: 9,
			stop: 10,
			EOF: 11,
			statement: 12,
			SPACELIST: 13,
			TEXT: 14,
			$accept: 0,
			$end: 1
		},
		terminals_: {
			2: "error",
			6: "SPACELINE",
			7: "NL",
			8: "ISHIKAWA",
			11: "EOF",
			13: "SPACELIST",
			14: "TEXT"
		},
		productions_: [
			0,
			[3, 1],
			[3, 2],
			[5, 1],
			[5, 2],
			[5, 2],
			[4, 2],
			[4, 3],
			[10, 1],
			[10, 1],
			[10, 1],
			[10, 2],
			[10, 2],
			[9, 3],
			[9, 2],
			[12, 2],
			[12, 1],
			[12, 1],
			[12, 1]
		],
		performAction: /* @__PURE__ */ f(function(e, t, n, r, i, a, o) {
			var s = a.length - 1;
			switch (i) {
				case 6:
				case 7: return r;
				case 15:
					r.addNode(a[s - 1].length, a[s].trim());
					break;
				case 16: r.addNode(0, a[s].trim());
			}
		}, "anonymous"),
		table: [
			{
				3: 1,
				4: 2,
				5: 3,
				6: [1, 5],
				8: t
			},
			{ 1: [3] },
			{ 1: [2, 1] },
			{
				4: 6,
				6: [1, 7],
				7: [1, 8],
				8: t
			},
			{
				6: n,
				7: [1, 10],
				9: 9,
				12: 11,
				13: r,
				14: i
			},
			e(a, [2, 3]),
			{ 1: [2, 2] },
			e(a, [2, 4]),
			e(a, [2, 5]),
			{
				1: [2, 6],
				6: n,
				12: 15,
				13: r,
				14: i
			},
			{
				6: n,
				9: 16,
				12: 11,
				13: r,
				14: i
			},
			{
				6: o,
				7: s,
				10: 17,
				11: c
			},
			e(l, [2, 18], { 14: [1, 21] }),
			e(l, [2, 16]),
			e(l, [2, 17]),
			{
				6: o,
				7: s,
				10: 22,
				11: c
			},
			{
				1: [2, 7],
				6: n,
				12: 15,
				13: r,
				14: i
			},
			e(u, [2, 14], {
				7: d,
				11: p
			}),
			e(m, [2, 8]),
			e(m, [2, 9]),
			e(m, [2, 10]),
			e(l, [2, 15]),
			e(u, [2, 13], {
				7: d,
				11: p
			}),
			e(m, [2, 11]),
			e(m, [2, 12])
		],
		defaultActions: {
			2: [2, 1],
			6: [2, 2]
		},
		parseError: /* @__PURE__ */ f(function(e, t) {
			if (t.recoverable) this.trace(e);
			else {
				var n = Error(e);
				throw n.hash = t, n;
			}
		}, "parseError"),
		parse: /* @__PURE__ */ f(function(e) {
			var t = this, n = [0], r = [], i = [null], a = [], o = this.table, s = "", c = 0, l = 0, u = 2, d = 1, p = a.slice.call(arguments, 1), m = Object.create(this.lexer), h = { yy: {} };
			for (var g in this.yy) Object.prototype.hasOwnProperty.call(this.yy, g) && (h.yy[g] = this.yy[g]);
			m.setInput(e, h.yy), h.yy.lexer = m, h.yy.parser = this, typeof m.yylloc > "u" && (m.yylloc = {});
			var _ = m.yylloc;
			a.push(_);
			var v = m.options && m.options.ranges;
			this.parseError = typeof h.yy.parseError == "function" ? h.yy.parseError : Object.getPrototypeOf(this).parseError;
			function y(e) {
				n.length -= 2 * e, i.length -= e, a.length -= e;
			}
			f(y, "popStack");
			function b() {
				var e;
				return e = r.pop() || m.lex() || d, typeof e != "number" && (e instanceof Array && (r = e, e = r.pop()), e = t.symbols_[e] || e), e;
			}
			f(b, "lex");
			for (var x, S, C, w, T = {}, E, D, O, k;;) {
				if (S = n[n.length - 1], this.defaultActions[S] ? C = this.defaultActions[S] : ((x === null || typeof x > "u") && (x = b()), C = o[S] && o[S][x]), typeof C > "u" || !C.length || !C[0]) {
					var A = "";
					for (E in k = [], o[S]) this.terminals_[E] && E > u && k.push("'" + this.terminals_[E] + "'");
					A = m.showPosition ? "Parse error on line " + (c + 1) + ":\n" + m.showPosition() + "\nExpecting " + k.join(", ") + ", got '" + (this.terminals_[x] || x) + "'" : "Parse error on line " + (c + 1) + ": Unexpected " + (x == d ? "end of input" : "'" + (this.terminals_[x] || x) + "'"), this.parseError(A, {
						text: m.match,
						token: this.terminals_[x] || x,
						line: m.yylineno,
						loc: _,
						expected: k
					});
				}
				if (C[0] instanceof Array && C.length > 1) throw Error("Parse Error: multiple actions possible at state: " + S + ", token: " + x);
				switch (C[0]) {
					case 1:
						n.push(x), i.push(m.yytext), a.push(m.yylloc), n.push(C[1]), x = null, l = m.yyleng, s = m.yytext, c = m.yylineno, _ = m.yylloc;
						break;
					case 2:
						if (D = this.productions_[C[1]][1], T.$ = i[i.length - D], T._$ = {
							first_line: a[a.length - (D || 1)].first_line,
							last_line: a[a.length - 1].last_line,
							first_column: a[a.length - (D || 1)].first_column,
							last_column: a[a.length - 1].last_column
						}, v && (T._$.range = [a[a.length - (D || 1)].range[0], a[a.length - 1].range[1]]), w = this.performAction.apply(T, [
							s,
							l,
							c,
							h.yy,
							C[1],
							i,
							a
						].concat(p)), typeof w < "u") return w;
						D && (n = n.slice(0, -1 * D * 2), i = i.slice(0, -1 * D), a = a.slice(0, -1 * D)), n.push(this.productions_[C[1]][0]), i.push(T.$), a.push(T._$), O = o[n[n.length - 2]][n[n.length - 1]], n.push(O);
						break;
					case 3: return !0;
				}
			}
			return !0;
		}, "parse")
	};
	h.lexer = /* @__PURE__ */ function() {
		return {
			EOF: 1,
			parseError: /* @__PURE__ */ f(function(e, t) {
				if (this.yy.parser) this.yy.parser.parseError(e, t);
				else throw Error(e);
			}, "parseError"),
			setInput: /* @__PURE__ */ f(function(e, t) {
				return this.yy = t || this.yy || {}, this._input = e, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
					first_line: 1,
					first_column: 0,
					last_line: 1,
					last_column: 0
				}, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
			}, "setInput"),
			input: /* @__PURE__ */ f(function() {
				var e = this._input[0];
				return this.yytext += e, this.yyleng++, this.offset++, this.match += e, this.matched += e, e.match(/(?:\r\n?|\n).*/g) ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), e;
			}, "input"),
			unput: /* @__PURE__ */ f(function(e) {
				var t = e.length, n = e.split(/(?:\r\n?|\n)/g);
				this._input = e + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - t), this.offset -= t;
				var r = this.match.split(/(?:\r\n?|\n)/g);
				this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), n.length - 1 && (this.yylineno -= n.length - 1);
				var i = this.yylloc.range;
				return this.yylloc = {
					first_line: this.yylloc.first_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.first_column,
					last_column: n ? (n.length === r.length ? this.yylloc.first_column : 0) + r[r.length - n.length].length - n[0].length : this.yylloc.first_column - t
				}, this.options.ranges && (this.yylloc.range = [i[0], i[0] + this.yyleng - t]), this.yyleng = this.yytext.length, this;
			}, "unput"),
			more: /* @__PURE__ */ f(function() {
				return this._more = !0, this;
			}, "more"),
			reject: /* @__PURE__ */ f(function() {
				if (this.options.backtrack_lexer) this._backtrack = !0;
				else return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
				return this;
			}, "reject"),
			less: /* @__PURE__ */ f(function(e) {
				this.unput(this.match.slice(e));
			}, "less"),
			pastInput: /* @__PURE__ */ f(function() {
				var e = this.matched.substr(0, this.matched.length - this.match.length);
				return (e.length > 20 ? "..." : "") + e.substr(-20).replace(/\n/g, "");
			}, "pastInput"),
			upcomingInput: /* @__PURE__ */ f(function() {
				var e = this.match;
				return e.length < 20 && (e += this._input.substr(0, 20 - e.length)), (e.substr(0, 20) + (e.length > 20 ? "..." : "")).replace(/\n/g, "");
			}, "upcomingInput"),
			showPosition: /* @__PURE__ */ f(function() {
				var e = this.pastInput(), t = Array(e.length + 1).join("-");
				return e + this.upcomingInput() + "\n" + t + "^";
			}, "showPosition"),
			test_match: /* @__PURE__ */ f(function(e, t) {
				var n, r, i;
				if (this.options.backtrack_lexer && (i = {
					yylineno: this.yylineno,
					yylloc: {
						first_line: this.yylloc.first_line,
						last_line: this.last_line,
						first_column: this.yylloc.first_column,
						last_column: this.yylloc.last_column
					},
					yytext: this.yytext,
					match: this.match,
					matches: this.matches,
					matched: this.matched,
					yyleng: this.yyleng,
					offset: this.offset,
					_more: this._more,
					_input: this._input,
					yy: this.yy,
					conditionStack: this.conditionStack.slice(0),
					done: this.done
				}, this.options.ranges && (i.yylloc.range = this.yylloc.range.slice(0))), r = e[0].match(/(?:\r\n?|\n).*/g), r && (this.yylineno += r.length), this.yylloc = {
					first_line: this.yylloc.last_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.last_column,
					last_column: r ? r[r.length - 1].length - r[r.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + e[0].length
				}, this.yytext += e[0], this.match += e[0], this.matches = e, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(e[0].length), this.matched += e[0], n = this.performAction.call(this, this.yy, this, t, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), n) return n;
				if (this._backtrack) {
					for (var a in i) this[a] = i[a];
					return !1;
				}
				return !1;
			}, "test_match"),
			next: /* @__PURE__ */ f(function() {
				if (this.done) return this.EOF;
				this._input || (this.done = !0);
				var e, t, n, r;
				this._more || (this.yytext = "", this.match = "");
				for (var i = this._currentRules(), a = 0; a < i.length; a++) if (n = this._input.match(this.rules[i[a]]), n && (!t || n[0].length > t[0].length)) {
					if (t = n, r = a, this.options.backtrack_lexer) {
						if (e = this.test_match(n, i[a]), e !== !1) return e;
						if (this._backtrack) {
							t = !1;
							continue;
						}
						return !1;
					}
					if (!this.options.flex) break;
				}
				return t ? (e = this.test_match(t, i[r]), e !== !1 && e) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
			}, "next"),
			lex: /* @__PURE__ */ f(function() {
				return this.next() || this.lex();
			}, "lex"),
			begin: /* @__PURE__ */ f(function(e) {
				this.conditionStack.push(e);
			}, "begin"),
			popState: /* @__PURE__ */ f(function() {
				return this.conditionStack.length - 1 > 0 ? this.conditionStack.pop() : this.conditionStack[0];
			}, "popState"),
			_currentRules: /* @__PURE__ */ f(function() {
				return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
			}, "_currentRules"),
			topState: /* @__PURE__ */ f(function(e) {
				return e = this.conditionStack.length - 1 - Math.abs(e || 0), e >= 0 ? this.conditionStack[e] : "INITIAL";
			}, "topState"),
			pushState: /* @__PURE__ */ f(function(e) {
				this.begin(e);
			}, "pushState"),
			stateStackSize: /* @__PURE__ */ f(function() {
				return this.conditionStack.length;
			}, "stateStackSize"),
			options: { "case-insensitive": !0 },
			performAction: /* @__PURE__ */ f(function(e, t, n, r) {
				switch (n) {
					case 0: return 6;
					case 1: return 8;
					case 2: return 8;
					case 3: return 6;
					case 4: return 7;
					case 5: return 13;
					case 6: return 14;
					case 7: return 11;
				}
			}, "anonymous"),
			rules: [
				/^(?:\s*%%.*)/i,
				/^(?:ishikawa-beta\b)/i,
				/^(?:ishikawa\b)/i,
				/^(?:[\s]+[\n])/i,
				/^(?:[\n]+)/i,
				/^(?:[\s]+)/i,
				/^(?:[^\n]+)/i,
				/^(?:$)/i
			],
			conditions: { INITIAL: {
				rules: [
					0,
					1,
					2,
					3,
					4,
					5,
					6,
					7
				],
				inclusive: !0
			} }
		};
	}();
	function g() {
		this.yy = {};
	}
	return f(g, "Parser"), g.prototype = h, h.Parser = g, new g();
}();
m.parser = m;
var h = m, g, _ = (g = class {
	constructor() {
		this.stack = [], this.clear = this.clear.bind(this), this.addNode = this.addNode.bind(this), this.getRoot = this.getRoot.bind(this);
	}
	clear() {
		this.root = void 0, this.stack = [], this.baseLevel = void 0, e();
	}
	getRoot() {
		return this.root;
	}
	addNode(e, n) {
		let r = t.sanitizeText(n, a());
		if (!this.root) {
			this.root = {
				text: r,
				children: []
			}, this.stack = [{
				level: 0,
				node: this.root
			}], s(r);
			return;
		}
		this.baseLevel ??= e;
		let i = e - this.baseLevel + 1;
		for (i <= 0 && (i = 1); this.stack.length > 1 && this.stack[this.stack.length - 1].level >= i;) this.stack.pop();
		let o = this.stack[this.stack.length - 1].node, c = {
			text: r,
			children: []
		};
		o.children.push(c), this.stack.push({
			level: i,
			node: c
		});
	}
	getAccTitle() {
		return i();
	}
	setAccTitle(e) {
		d(e);
	}
	getAccDescription() {
		return r();
	}
	setAccDescription(e) {
		u(e);
	}
	getDiagramTitle() {
		return o();
	}
	setDiagramTitle(e) {
		s(e);
	}
}, f(g, "IshikawaDB"), g), v = 14, y = 250, b = 30, x = 60, S = 5, C = 82 * Math.PI / 180, w = Math.cos(C), T = Math.sin(C), E = /* @__PURE__ */ f((e, t, r) => {
	let i = e.node().getBBox(), a = i.width + t * 2, o = i.height + t * 2;
	n(e, o, a, r), e.attr("viewBox", `${i.x - t} ${i.y - t} ${a} ${o}`);
}, "applyPaddedViewBox"), D = /* @__PURE__ */ f((e, t, n, r) => {
	let i = r.db.getRoot();
	if (!i) return;
	let o = a(), { look: s, handDrawnSeed: u, themeVariables: d } = o, f = c(o.fontSize)[0] ?? v, m = s === "handDrawn", h = i.children ?? [], g = o.ishikawa?.diagramPadding ?? 20, _ = o.ishikawa?.useMaxWidth ?? !1, b = l(t), x = b.append("g").attr("class", "ishikawa"), S = m ? p.svg(b.node()) : void 0, C = S ? {
		roughSvg: S,
		seed: u ?? 0,
		lineColor: d?.lineColor ?? "#333",
		fillColor: d?.mainBkg ?? "#fff"
	} : void 0, w = `ishikawa-arrow-${t}`;
	m || x.append("defs").append("marker").attr("id", w).attr("viewBox", "0 0 10 10").attr("refX", 0).attr("refY", 5).attr("markerWidth", 6).attr("markerHeight", 6).attr("orient", "auto").append("path").attr("d", "M 10 0 L 0 5 L 10 10 Z").attr("class", "ishikawa-arrow");
	let T = 0, D = y, A = m ? void 0 : R(x, T, D, T, D, "ishikawa-spine");
	if (k(x, T, D, i.text, f, C), !h.length) {
		m && R(x, T, D, T, D, "ishikawa-spine", C), E(b, g, _);
		return;
	}
	T -= 20;
	let j = h.filter((e, t) => t % 2 == 0), M = h.filter((e, t) => t % 2 == 1), P = O(j), F = O(M), I = P.total + F.total, L = y, z = y;
	if (I > 0) {
		let e = y * 2, t = y * .3;
		L = Math.max(t, e * (P.total / I)), z = Math.max(t, e * (F.total / I));
	}
	let B = f * 2;
	L = Math.max(L, P.max * B), z = Math.max(z, F.max * B), D = Math.max(L, y), A && A.attr("y1", D).attr("y2", D), x.select(".ishikawa-head-group").attr("transform", `translate(0,${D})`);
	let V = Math.ceil(h.length / 2);
	for (let e = 0; e < V; e++) {
		let t = x.append("g").attr("class", "ishikawa-pair");
		for (let [n, r, i] of [[
			h[e * 2],
			-1,
			L
		], [
			h[e * 2 + 1],
			1,
			z
		]]) n && N(t, n, T, D, r, i, f, C);
		T = t.selectAll("text").nodes().reduce((e, t) => Math.min(e, t.getBBox().x), 1 / 0);
	}
	if (m) R(x, T, D, 0, D, "ishikawa-spine", C);
	else {
		A.attr("x1", T);
		let e = `url(#${w})`;
		x.selectAll("line.ishikawa-branch, line.ishikawa-sub-branch").attr("marker-start", e);
	}
	E(b, g, _);
}, "draw"), O = /* @__PURE__ */ f((e) => {
	let t = /* @__PURE__ */ f((e) => e.children.reduce((e, n) => e + 1 + t(n), 0), "countDescendants");
	return e.reduce((e, n) => {
		let r = t(n);
		return e.total += r, e.max = Math.max(e.max, r), e;
	}, {
		total: 0,
		max: 0
	});
}, "sideStats"), k = /* @__PURE__ */ f((e, t, n, r, i, a) => {
	let o = Math.max(6, Math.floor(110 / (i * .6))), s = e.append("g").attr("class", "ishikawa-head-group").attr("transform", `translate(${t},${n})`), c = I(s, F(r, o), 0, 0, "ishikawa-head-label", "start", i), l = c.node().getBBox(), u = Math.max(60, l.width + 6), d = Math.max(40, l.height * 2 + 40), f = `M 0 ${-d / 2} L 0 ${d / 2} Q ${u * 2.4} 0 0 ${-d / 2} Z`;
	if (a) {
		let e = a.roughSvg.path(f, {
			roughness: 1.5,
			seed: a.seed,
			fill: a.fillColor,
			fillStyle: "hachure",
			fillWeight: 2.5,
			hachureGap: 5,
			stroke: a.lineColor,
			strokeWidth: 2
		});
		s.insert(() => e, ":first-child").attr("class", "ishikawa-head");
	} else s.insert("path", ":first-child").attr("class", "ishikawa-head").attr("d", f);
	c.attr("transform", `translate(${(u - l.width) / 2 - l.x + 3},${-l.y - l.height / 2})`);
}, "drawHead"), A = /* @__PURE__ */ f((e, t) => {
	let n = [], r = [], i = /* @__PURE__ */ f((e, a, o) => {
		let s = t === -1 ? [...e].reverse() : e;
		for (let e of s) {
			let t = n.length, s = e.children ?? [];
			n.push({
				depth: o,
				text: F(e.text, 15),
				parentIndex: a,
				childCount: s.length
			}), o % 2 == 0 ? (r.push(t), s.length && i(s, t, o + 1)) : (s.length && i(s, t, o + 1), r.push(t));
		}
	}, "walk");
	return i(e, -1, 2), {
		entries: n,
		yOrder: r
	};
}, "flattenTree"), j = /* @__PURE__ */ f((e, t, n, r, i, a, o) => {
	let s = e.append("g").attr("class", "ishikawa-label-group"), c = I(s, t, n, r + 11 * i, "ishikawa-label cause", "middle", a).node().getBBox();
	if (o) {
		let e = o.roughSvg.rectangle(c.x - 20, c.y - 2, c.width + 40, c.height + 4, {
			roughness: 1.5,
			seed: o.seed,
			fill: o.fillColor,
			fillStyle: "hachure",
			fillWeight: 2.5,
			hachureGap: 5,
			stroke: o.lineColor,
			strokeWidth: 2
		});
		s.insert(() => e, ":first-child").attr("class", "ishikawa-label-box");
	} else s.insert("rect", ":first-child").attr("class", "ishikawa-label-box").attr("x", c.x - 20).attr("y", c.y - 2).attr("width", c.width + 40).attr("height", c.height + 4);
}, "drawCauseLabel"), M = /* @__PURE__ */ f((e, t, n, r, i, a) => {
	let o = Math.sqrt(r * r + i * i);
	if (o === 0) return;
	let s = r / o, c = i / o, l = -c * 6, u = s * 6, d = t, f = n, p = `M ${d} ${f} L ${d - s * 6 * 2 + l} ${f - c * 6 * 2 + u} L ${d - s * 6 * 2 - l} ${f - c * 6 * 2 - u} Z`, m = a.roughSvg.path(p, {
		roughness: 1,
		seed: a.seed,
		fill: a.lineColor,
		fillStyle: "solid",
		stroke: a.lineColor,
		strokeWidth: 1
	});
	e.append(() => m);
}, "drawArrowMarker"), N = /* @__PURE__ */ f((e, t, n, r, i, a, o, s) => {
	let c = t.children ?? [], l = a * (c.length ? 1 : .2), u = -w * l, d = T * l * i, f = n + u, p = r + d;
	if (R(e, n, r, f, p, "ishikawa-branch", s), s && M(e, n, r, n - f, r - p, s), j(e, t.text, f, p, i, o, s), !c.length) return;
	let { entries: m, yOrder: h } = A(c, i), g = m.length, _ = Array(g);
	for (let [e, t] of h.entries()) _[t] = r + d * ((e + 1) / (g + 1));
	let v = /* @__PURE__ */ new Map();
	v.set(-1, {
		x0: n,
		y0: r,
		x1: f,
		y1: p,
		childCount: c.length,
		childrenDrawn: 0
	});
	let y = -w, C = T * i, E = i < 0 ? "ishikawa-label up" : "ishikawa-label down";
	for (let [t, n] of m.entries()) {
		let r = _[t], i = v.get(n.parentIndex), a = e.append("g").attr("class", "ishikawa-sub-group"), c = 0, l = 0, u = 0;
		if (n.depth % 2 == 0) {
			let e = i.y1 - i.y0;
			c = L(i.x0, i.x1, e ? (r - i.y0) / e : .5), l = r, u = c - (n.childCount > 0 ? x + n.childCount * S : b), R(a, c, r, u, r, "ishikawa-sub-branch", s), s && M(a, c, r, 1, 0, s), I(a, n.text, u, r, "ishikawa-label align", "end", o);
		} else {
			let e = i.childrenDrawn++;
			c = L(i.x0, i.x1, (i.childCount - e) / (i.childCount + 1)), l = i.y0, u = c + y * ((r - l) / C), R(a, c, l, u, r, "ishikawa-sub-branch", s), s && M(a, c, l, c - u, l - r, s), I(a, n.text, u, r, E, "end", o);
		}
		n.childCount > 0 && v.set(t, {
			x0: c,
			y0: l,
			x1: u,
			y1: r,
			childCount: n.childCount,
			childrenDrawn: 0
		});
	}
}, "drawBranch"), P = /* @__PURE__ */ f((e) => e.split(/<br\s*\/?>|\n/), "splitLines"), F = /* @__PURE__ */ f((e, t) => {
	if (e.length <= t) return e;
	let n = [];
	for (let r of e.split(/\s+/)) {
		let e = n.length - 1;
		e >= 0 && n[e].length + 1 + r.length <= t ? n[e] += " " + r : n.push(r);
	}
	return n.join("\n");
}, "wrapText"), I = /* @__PURE__ */ f((e, t, n, r, i, a, o) => {
	let s = P(t), c = o * 1.05, l = e.append("text").attr("class", i).attr("text-anchor", a).attr("x", n).attr("y", r - (s.length - 1) * c / 2);
	for (let [e, t] of s.entries()) l.append("tspan").attr("x", n).attr("dy", e === 0 ? 0 : c).text(t);
	return l;
}, "drawMultilineText"), L = /* @__PURE__ */ f((e, t, n) => e + (t - e) * n, "lerp"), R = /* @__PURE__ */ f((e, t, n, r, i, a, o) => {
	if (o) {
		let s = o.roughSvg.line(t, n, r, i, {
			roughness: 1.5,
			seed: o.seed,
			stroke: o.lineColor,
			strokeWidth: 2
		});
		e.append(() => s).attr("class", a);
		return;
	}
	return e.append("line").attr("class", a).attr("x1", t).attr("y1", n).attr("x2", r).attr("y2", i);
}, "drawLine"), z = {
	parser: h,
	get db() {
		return new _();
	},
	renderer: { draw: D },
	styles: /* @__PURE__ */ f((e) => `
.ishikawa .ishikawa-spine,
.ishikawa .ishikawa-branch,
.ishikawa .ishikawa-sub-branch {
  stroke: ${e.lineColor};
  stroke-width: 2;
  fill: none;
}

.ishikawa .ishikawa-sub-branch {
  stroke-width: 1;
}

.ishikawa .ishikawa-arrow {
  fill: ${e.lineColor};
}

.ishikawa .ishikawa-head {
  fill: ${e.mainBkg};
  stroke: ${e.lineColor};
  stroke-width: 2;
}

.ishikawa .ishikawa-label-box {
  fill: ${e.mainBkg};
  stroke: ${e.lineColor};
  stroke-width: 2;
}

.ishikawa text {
  font-family: ${e.fontFamily};
  font-size: ${e.fontSize};
  fill: ${e.textColor};
}

.ishikawa .ishikawa-head-label {
  font-weight: 600;
  text-anchor: middle;
  dominant-baseline: middle;
  font-size: 14px;
}

.ishikawa .ishikawa-label {
  text-anchor: end;
}

.ishikawa .ishikawa-label.cause {
  text-anchor: middle;
  dominant-baseline: middle;
}

.ishikawa .ishikawa-label.align {
  text-anchor: end;
  dominant-baseline: middle;
}

.ishikawa .ishikawa-label.up {
  dominant-baseline: baseline;
}

.ishikawa .ishikawa-label.down {
  dominant-baseline: hanging;
}
`, "getStyles")
};
//#endregion
export { z as diagram };

//# sourceMappingURL=ishikawaDiagram-5VMMS53U--xj-wijF-D9Y36u9e.js.map