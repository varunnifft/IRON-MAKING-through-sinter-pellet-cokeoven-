//#region ../react/build/katex-DoRnZ_sp.js
var e = class e extends Error {
	constructor(t, n) {
		var r = "KaTeX parse error: " + t, i, a, o = n && n.loc;
		if (o && o.start <= o.end) {
			var s = o.lexer.input;
			i = o.start, a = o.end, i === s.length ? r += " at end of input: " : r += " at position " + (i + 1) + ": ";
			var c = s.slice(i, a).replace(/[^]/g, "$&̲"), l = i > 15 ? "…" + s.slice(i - 15, i) : s.slice(0, i), u = a + 15 < s.length ? s.slice(a, a + 15) + "…" : s.slice(a);
			r += l + c + u;
		}
		super(r), this.name = "ParseError", this.position = void 0, this.length = void 0, this.rawMessage = void 0, Object.setPrototypeOf(this, e.prototype), this.position = i, i != null && a != null && (this.length = a - i), this.rawMessage = t;
	}
}, t = /([A-Z])/g, n = (e) => e.replace(t, "-$1").toLowerCase(), r = {
	"&": "&amp;",
	">": "&gt;",
	"<": "&lt;",
	"\"": "&quot;",
	"'": "&#x27;"
}, i = /[&><"']/g, a = (e) => String(e).replace(i, (e) => r[e]), o = (e) => e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? o(e.body[0]) : e : e.type === "font" ? o(e.body) : e, s = /* @__PURE__ */ new Set([
	"mathord",
	"textord",
	"atom"
]), c = (e) => s.has(o(e).type), l = (e) => {
	var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
	return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
}, u = {
	displayMode: {
		type: "boolean",
		description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",
		cli: "-d, --display-mode"
	},
	output: {
		type: { enum: [
			"htmlAndMathml",
			"html",
			"mathml"
		] },
		description: "Determines the markup language of the output.",
		cli: "-F, --format <type>"
	},
	leqno: {
		type: "boolean",
		description: "Render display math in leqno style (left-justified tags)."
	},
	fleqn: {
		type: "boolean",
		description: "Render display math flush left."
	},
	throwOnError: {
		type: "boolean",
		default: !0,
		cli: "-t, --no-throw-on-error",
		cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."
	},
	errorColor: {
		type: "string",
		default: "#cc0000",
		cli: "-c, --error-color <color>",
		cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",
		cliProcessor: (e) => "#" + e
	},
	macros: {
		type: "object",
		cli: "-m, --macro <def>",
		cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",
		cliDefault: [],
		cliProcessor: (e, t) => (t.push(e), t)
	},
	minRuleThickness: {
		type: "number",
		description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",
		processor: (e) => Math.max(0, e),
		cli: "--min-rule-thickness <size>",
		cliProcessor: parseFloat
	},
	colorIsTextColor: {
		type: "boolean",
		description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",
		cli: "-b, --color-is-text-color"
	},
	strict: {
		type: [
			{ enum: [
				"warn",
				"ignore",
				"error"
			] },
			"boolean",
			"function"
		],
		description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",
		cli: "-S, --strict",
		cliDefault: !1
	},
	trust: {
		type: ["boolean", "function"],
		description: "Trust the input, enabling all HTML features such as \\url.",
		cli: "-T, --trust"
	},
	maxSize: {
		type: "number",
		default: 1 / 0,
		description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",
		processor: (e) => Math.max(0, e),
		cli: "-s, --max-size <n>",
		cliProcessor: parseInt
	},
	maxExpand: {
		type: "number",
		default: 1e3,
		description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",
		processor: (e) => Math.max(0, e),
		cli: "-e, --max-expand <n>",
		cliProcessor: (e) => e === "Infinity" ? 1 / 0 : parseInt(e)
	},
	globalGroup: {
		type: "boolean",
		cli: !1
	}
};
function d(e) {
	if (typeof e != "string") return e.enum[0];
	switch (e) {
		case "boolean": return !1;
		case "string": return "";
		case "number": return 0;
		case "object": return {};
		default: throw Error("Unexpected schema type; settings must declare an explicit default.");
	}
}
function f(e) {
	return e.default === void 0 ? d(Array.isArray(e.type) ? e.type[0] : e.type) : e.default;
}
function p(e, t, n, r) {
	var i = n[t];
	e[t] = i === void 0 ? f(r) : r.processor ? r.processor(i) : i;
}
var m = class {
	constructor(e) {
		e === void 0 && (e = {}), this.displayMode = void 0, this.output = void 0, this.leqno = void 0, this.fleqn = void 0, this.throwOnError = void 0, this.errorColor = void 0, this.macros = void 0, this.minRuleThickness = void 0, this.colorIsTextColor = void 0, this.strict = void 0, this.trust = void 0, this.maxSize = void 0, this.maxExpand = void 0, this.globalGroup = void 0, e ||= {};
		for (var t of Object.keys(u)) {
			var n = u[t];
			n && p(this, t, e, n);
		}
	}
	reportNonstrict(t, n, r) {
		var i = this.strict;
		if (typeof i == "function" && (i = i(t, n, r)), !(!i || i === "ignore")) {
			if (i === !0 || i === "error") throw new e("LaTeX-incompatible input and strict mode is set to 'error': " + (n + " [" + t + "]"), r);
			i === "warn" ? typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (n + " [" + t + "]")) : typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + i + "': " + n + " [" + t + "]"));
		}
	}
	useStrictBehavior(e, t, n) {
		var r = this.strict;
		if (typeof r == "function") try {
			r = r(e, t, n);
		} catch {
			r = "error";
		}
		return !r || r === "ignore" ? !1 : r === !0 || r === "error" ? !0 : r === "warn" ? (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (t + " [" + e + "]")), !1) : (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + r + "': " + t + " [" + e + "]")), !1);
	}
	isTrusted(e) {
		if ("url" in e && e.url && !e.protocol) {
			var t = l(e.url);
			if (t == null) return !1;
			e.protocol = t;
		}
		return !!(typeof this.trust == "function" ? this.trust(e) : this.trust);
	}
}, h = class {
	constructor(e, t, n) {
		this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = n;
	}
	sup() {
		return w[ee[this.id]];
	}
	sub() {
		return w[T[this.id]];
	}
	fracNum() {
		return w[te[this.id]];
	}
	fracDen() {
		return w[ne[this.id]];
	}
	cramp() {
		return w[re[this.id]];
	}
	text() {
		return w[ie[this.id]];
	}
	isTight() {
		return this.size >= 2;
	}
}, g = 0, _ = 1, v = 2, y = 3, b = 4, x = 5, S = 6, C = 7, w = [
	new h(g, 0, !1),
	new h(_, 0, !0),
	new h(v, 1, !1),
	new h(y, 1, !0),
	new h(b, 2, !1),
	new h(x, 2, !0),
	new h(S, 3, !1),
	new h(C, 3, !0)
], ee = [
	b,
	x,
	b,
	x,
	S,
	C,
	S,
	C
], T = [
	x,
	x,
	x,
	x,
	C,
	C,
	C,
	C
], te = [
	v,
	y,
	b,
	x,
	S,
	C,
	S,
	C
], ne = [
	y,
	y,
	x,
	x,
	C,
	C,
	C,
	C
], re = [
	_,
	_,
	y,
	y,
	x,
	x,
	C,
	C
], ie = [
	g,
	_,
	v,
	y,
	v,
	y,
	v,
	y
], E = {
	DISPLAY: w[g],
	TEXT: w[v],
	SCRIPT: w[b],
	SCRIPTSCRIPT: w[S]
}, ae = [
	{
		name: "latin",
		blocks: [[256, 591], [768, 879]]
	},
	{
		name: "cyrillic",
		blocks: [[1024, 1279]]
	},
	{
		name: "armenian",
		blocks: [[1328, 1423]]
	},
	{
		name: "brahmic",
		blocks: [[2304, 4255]]
	},
	{
		name: "georgian",
		blocks: [[4256, 4351]]
	},
	{
		name: "cjk",
		blocks: [
			[12288, 12543],
			[19968, 40879],
			[65280, 65376]
		]
	},
	{
		name: "hangul",
		blocks: [[44032, 55215]]
	}
];
function oe(e) {
	for (var t = 0; t < ae.length; t++) for (var n = ae[t], r = 0; r < n.blocks.length; r++) {
		var i = n.blocks[r];
		if (e >= i[0] && e <= i[1]) return n.name;
	}
	return null;
}
var se = [];
ae.forEach((e) => e.blocks.forEach((e) => se.push(...e)));
function ce(e) {
	for (var t = 0; t < se.length; t += 2) if (e >= se[t] && e <= se[t + 1]) return !0;
	return !1;
}
var D = (e) => e + " " + e, le = 80, ue = function(e, t) {
	return "M95," + (622 + e + t) + "\nc-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14\nc0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54\nc44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10\ns173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429\nc69,-144,104.5,-217.7,106.5,-221\nl" + e / 2.075 + " -" + e + "\nc5.3,-9.3,12,-14,20,-14\nH400000v" + (40 + e) + "H845.2724\ns-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7\nc-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z\nM" + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, de = function(e, t) {
	return "M263," + (601 + e + t) + "c0.7,0,18,39.7,52,119\nc34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120\nc340,-704.7,510.7,-1060.3,512,-1067\nl" + e / 2.084 + " -" + e + "\nc4.7,-7.3,11,-11,19,-11\nH40000v" + (40 + e) + "H1012.3\ns-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232\nc-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1\ns-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26\nc-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z\nM" + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, fe = function(e, t) {
	return "M983 " + (10 + e + t) + "\nl" + e / 3.13 + " -" + e + "\nc4,-6.7,10,-10,18,-10 H400000v" + (40 + e) + "\nH1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7\ns-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744\nc-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30\nc26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722\nc56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5\nc53.7,-170.3,84.5,-266.8,92.5,-289.5z\nM" + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, pe = function(e, t) {
	return "M424," + (2398 + e + t) + "\nc-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514\nc0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20\ns-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121\ns209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081\nl" + e / 4.223 + " -" + e + "c4,-6.7,10,-10,18,-10 H400000\nv" + (40 + e) + "H1014.6\ns-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185\nc-2,6,-10,9,-24,9\nc-8,0,-12,-0.7,-12,-2z M" + (1001 + e) + " " + t + "\nh400000v" + (40 + e) + "h-400000z";
}, me = function(e, t) {
	return "M473," + (2713 + e + t) + "\nc339.3,-1799.3,509.3,-2700,510,-2702 l" + e / 5.298 + " -" + e + "\nc3.3,-7.3,9.3,-11,18,-11 H400000v" + (40 + e) + "H1017.7\ns-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9\nc-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200\nc0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26\ns76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,\n606zM" + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, he = function(e) {
	var t = e / 2;
	return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, ge = function(e, t, n) {
	var r = n - 54 - t - e;
	return "M702 " + (e + t) + "H400000" + (40 + e) + "\nH742v" + r + "l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1\nh-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170\nc-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667\n219 661 l218 661zM702 " + t + "H400000v" + (40 + e) + "H742z";
}, _e = function(e, t, n) {
	t = 1e3 * t;
	var r = "";
	switch (e) {
		case "sqrtMain":
			r = ue(t, le);
			break;
		case "sqrtSize1":
			r = de(t, le);
			break;
		case "sqrtSize2":
			r = fe(t, le);
			break;
		case "sqrtSize3":
			r = pe(t, le);
			break;
		case "sqrtSize4":
			r = me(t, le);
			break;
		case "sqrtTall": r = ge(t, le, n);
	}
	return r;
}, ve = function(e, t) {
	switch (e) {
		case "⎜": return D("M291 0 H417 V" + t + " H291z");
		case "∣": return D("M145 0 H188 V" + t + " H145z");
		case "∥": return D("M145 0 H188 V" + t + " H145z") + D("M367 0 H410 V" + t + " H367z");
		case "⎟": return D("M457 0 H583 V" + t + " H457z");
		case "⎢": return D("M319 0 H403 V" + t + " H319z");
		case "⎥": return D("M263 0 H347 V" + t + " H263z");
		case "⎪": return D("M384 0 H504 V" + t + " H384z");
		case "⏐": return D("M312 0 H355 V" + t + " H312z");
		case "‖": return D("M257 0 H300 V" + t + " H257z") + D("M478 0 H521 V" + t + " H478z");
		default: return "";
	}
}, ye = {
	doubleleftarrow: "M262 157\nl10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3\n 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28\n 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5\nc2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5\n 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87\n-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7\n-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z\nm8 0v40h399730v-40zm0 194v40h399730v-40z",
	doublerightarrow: "M399738 392l\n-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5\n 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88\n-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68\n-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18\n-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782\nc-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3\n-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z",
	leftarrow: "M400000 241H110l3-3c68.7-52.7 113.7-120\n 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8\n-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247\nc-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208\n 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3\n 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202\n l-3-3h399890zM100 241v40h399900v-40z",
	leftbrace: "M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117\n-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7\n 5-6 9-10 13-.7 1-7.3 1-20 1H6z",
	leftbraceunder: "M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13\n 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688\n 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7\n-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z",
	leftgroup: "M400000 80\nH435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0\n 435 0h399565z",
	leftgroupunder: "M400000 262\nH435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219\n 435 219h399565z",
	leftharpoon: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3\n-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5\n-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7\n-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z",
	leftharpoonplus: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5\n 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3\n-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7\n-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z\nm0 0v40h400000v-40z",
	leftharpoondown: "M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333\n 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5\n 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667\n-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z",
	leftharpoondownplus: "M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12\n 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7\n-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0\nv40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z",
	lefthook: "M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5\n-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3\n-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21\n 71.5 23h399859zM103 281v-40h399897v40z",
	leftlinesegment: D("M40 281 V428 H0 V94 H40 V241 H400000 v40z"),
	leftbracketunder: D("M0 0 h120 V290 H399995 v120 H0z"),
	leftbracketover: D("M0 440 h120 V150 H399995 v-120 H0z"),
	leftmapsto: D("M40 281 V448H0V74H40V241H400000v40z"),
	leftToFrom: "M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23\n-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8\nc28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3\n 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z",
	longequal: D("M0 50 h400000 v40H0z m0 194h40000v40H0z"),
	midbrace: "M200428 334\nc-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14\n-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7\n 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11\n 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z",
	midbraceunder: "M199572 214\nc100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14\n 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3\n 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0\n-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z",
	oiintSize1: "M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6\n-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z\nm368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8\n60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z",
	oiintSize2: "M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8\n-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z\nm502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2\nc0 110 84 276 504 276s502.4-166 502.4-276z",
	oiiintSize1: "M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6\n-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z\nm525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0\n85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z",
	oiiintSize2: "M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8\n-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z\nm770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1\nc0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z",
	rightarrow: "M0 241v40h399891c-47.3 35.3-84 78-110 128\n-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20\n 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7\n 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85\n-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n 151.7 139 205zm0 0v40h399900v-40z",
	rightbrace: "M400000 542l\n-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5\ns-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1\nc124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z",
	rightbraceunder: "M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3\n 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237\n-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z",
	rightgroup: "M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0\n 3-1 3-3v-38c-76-158-257-219-435-219H0z",
	rightgroupunder: "M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18\n 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z",
	rightharpoon: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3\n-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2\n-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58\n 69.2 92 94.5zm0 0v40h399900v-40z",
	rightharpoonplus: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11\n-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7\n 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z\nm0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z",
	rightharpoondown: "M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8\n 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5\n-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95\n-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z",
	rightharpoondownplus: "M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8\n 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3\n 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3\n-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z\nm0-194v40h400000v-40zm0 0v40h400000v-40z",
	righthook: "M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3\n 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0\n-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21\n 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z",
	rightlinesegment: D("M399960 241 V94 h40 V428 h-40 V281 H0 v-40z"),
	rightbracketunder: D("M399995 0 h-120 V290 H0 v120 H400000z"),
	rightbracketover: D("M399995 440 h-120 V150 H0 v-120 H399995z"),
	rightToFrom: "M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23\n 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32\n-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142\n-167z M100 147v40h399900v-40zM0 341v40h399900v-40z",
	twoheadleftarrow: "M0 167c68 40\n 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69\n-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3\n-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19\n-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101\n 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z",
	twoheadrightarrow: "M400000 167\nc-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3\n 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42\n 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333\n-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70\n 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z",
	tilde1: "M200 55.538c-77 0-168 73.953-177 73.953-3 0-7\n-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0\n 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0\n 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128\n-68.267.847-113-73.952-191-73.952z",
	tilde2: "M344 55.266c-142 0-300.638 81.316-311.5 86.418\n-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9\n 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114\nc1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751\n 181.476 676 181.476c-149 0-189-126.21-332-126.21z",
	tilde3: "M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457\n-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0\n 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697\n 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696\n -338 0-409-156.573-744-156.573z",
	tilde4: "M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345\n-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409\n 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9\n 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409\n -175.236-744-175.236z",
	vec: "M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5\n3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11\n10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63\n-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1\n-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59\nH213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359\nc-16-25.333-24-45-24-59z",
	widehat1: "M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22\nc-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z",
	widehat2: "M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
	widehat3: "M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
	widehat4: "M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
	widecheck1: "M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,\n-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z",
	widecheck2: "M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
	widecheck3: "M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
	widecheck4: "M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
	baraboveleftarrow: "M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202\nc4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5\nc-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130\ns-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47\n121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6\ns2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11\nc0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z\nM100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z",
	rightarrowabovebar: "M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32\n-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0\n13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39\n-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5\n-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z",
	baraboveshortleftharpoon: "M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17\nc2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21\nc-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40\nc-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z\nM0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z",
	rightharpoonaboveshortbar: "M0,241 l0,40c399126,0,399993,0,399993,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z",
	shortbaraboveleftharpoon: "M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,\n1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,\n-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z\nM93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z",
	shortrightharpoonabovebar: "M53,241l0,40c398570,0,399437,0,399437,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z"
}, be = function(e, t) {
	switch (e) {
		case "lbrack": return "M403 1759 V84 H666 V0 H319 V1759 v" + t + " v1759 v84 h347 v-84\nH403z M403 1759 V0 H319 V1759 v" + t + " v1759 v84 h84z";
		case "rbrack": return "M347 1759 V0 H0 V84 H263 V1759 v" + t + " v1759 H0 v84 H347z\nM347 1759 V0 H263 V1759 v" + t + " v1759 h84z";
		case "vert": return "M145 15 v585 v" + t + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -t + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M188 15 H145 v585 v" + t + " v585 h43z";
		case "doublevert": return "M145 15 v585 v" + t + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -t + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M188 15 H145 v585 v" + t + " v585 h43z\nM367 15 v585 v" + t + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -t + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M410 15 H367 v585 v" + t + " v585 h43z";
		case "lfloor": return "M319 602 V0 H403 V602 v" + t + " v1715 h263 v84 H319z\nMM319 602 V0 H403 V602 v" + t + " v1715 H319z";
		case "rfloor": return "M319 602 V0 H403 V602 v" + t + " v1799 H0 v-84 H319z\nMM319 602 V0 H403 V602 v" + t + " v1715 H319z";
		case "lceil": return "M403 1759 V84 H666 V0 H319 V1759 v" + t + " v602 h84z\nM403 1759 V0 H319 V1759 v" + t + " v602 h84z";
		case "rceil": return "M347 1759 V0 H0 V84 H263 V1759 v" + t + " v602 h84z\nM347 1759 V0 h-84 V1759 v" + t + " v602 h84z";
		case "lparen": return "M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1\nc-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,\n-36,557 l0," + (t + 84) + "c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,\n949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9\nc0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,\n-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189\nl0,-" + (t + 92) + "c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,\n-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z";
		case "rparen": return "M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,\n63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5\nc11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0," + (t + 9) + "\nc-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664\nc-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11\nc0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17\nc242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558\nl0,-" + (t + 144) + "c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,\n-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z";
		default: throw Error("Unknown stretchy delimiter.");
	}
};
function xe(e) {
	return "toText" in e;
}
var Se = class {
	constructor(e) {
		this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++) e.appendChild(this.children[t].toNode());
		return e;
	}
	toMarkup() {
		for (var e = "", t = 0; t < this.children.length; t++) e += this.children[t].toMarkup();
		return e;
	}
	toText() {
		return this.children.map((e) => {
			if (xe(e)) return e.toText();
			throw Error("Expected MathDomNode with toText, got " + e.constructor.name);
		}).join("");
	}
}, Ce = {
	pt: 1,
	mm: 7227 / 2540,
	cm: 7227 / 254,
	in: 72.27,
	bp: 803 / 800,
	pc: 12,
	dd: 1238 / 1157,
	cc: 14856 / 1157,
	nd: 685 / 642,
	nc: 1370 / 107,
	sp: 1 / 65536,
	px: 803 / 800
}, we = {
	ex: !0,
	em: !0,
	mu: !0
}, Te = function(e) {
	return typeof e != "string" && (e = e.unit), e in Ce || e in we || e === "ex";
}, O = function(t, n) {
	var r;
	if (t.unit in Ce) r = Ce[t.unit] / n.fontMetrics().ptPerEm / n.sizeMultiplier;
	else if (t.unit === "mu") r = n.fontMetrics().cssEmPerMu;
	else {
		var i;
		if (i = n.style.isTight() ? n.havingStyle(n.style.text()) : n, t.unit === "ex") r = i.fontMetrics().xHeight;
		else if (t.unit === "em") r = i.fontMetrics().quad;
		else throw new e("Invalid unit: '" + t.unit + "'");
		i !== n && (r *= i.sizeMultiplier / n.sizeMultiplier);
	}
	return Math.min(t.number * r, n.maxSize);
}, k = function(e) {
	return +e.toFixed(4) + "em";
}, Ee = function(e) {
	return e.filter((e) => e).join(" ");
}, De = function(e) {
	var t = "";
	for (var r of Object.keys(e)) {
		var i = e[r];
		i !== void 0 && (t += n(r) + ":" + i + ";");
	}
	return t;
}, Oe = function(e, t, n) {
	if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = n || {}, t) {
		t.style.isTight() && this.classes.push("mtight");
		var r = t.getColor();
		r && (this.style.color = r);
	}
}, ke = function(e) {
	var t = document.createElement(e);
	t.className = Ee(this.classes), Object.assign(t.style, this.style);
	for (var n of Object.keys(this.attributes)) t.setAttribute(n, this.attributes[n]);
	for (var r = 0; r < this.children.length; r++) t.appendChild(this.children[r].toNode());
	return t;
}, Ae = /[\s"'>/=\x00-\x1f]/, je = function(t) {
	var n = "<" + t;
	this.classes.length && (n += " class=\"" + a(Ee(this.classes)) + "\"");
	var r = De(this.style);
	r && (n += " style=\"" + a(r) + "\"");
	for (var i of Object.keys(this.attributes)) {
		if (Ae.test(i)) throw new e("Invalid attribute name '" + i + "'");
		n += " " + i + "=\"" + a(this.attributes[i]) + "\"";
	}
	n += ">";
	for (var o = 0; o < this.children.length; o++) n += this.children[o].toMarkup();
	return n += "</" + t + ">", n;
}, Me = class {
	constructor(e, t, n, r) {
		this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, this.italic = void 0, Oe.call(this, e, n, r), this.children = t || [];
	}
	setAttribute(e, t) {
		this.attributes[e] = t;
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		return ke.call(this, "span");
	}
	toMarkup() {
		return je.call(this, "span");
	}
}, Ne = class {
	constructor(e, t, n, r) {
		this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, Oe.call(this, t, r), this.children = n || [], this.setAttribute("href", e);
	}
	setAttribute(e, t) {
		this.attributes[e] = t;
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		return ke.call(this, "a");
	}
	toMarkup() {
		return je.call(this, "a");
	}
}, Pe = class {
	constructor(e, t, n) {
		this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = n;
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		var e = document.createElement("img");
		return e.src = this.src, e.alt = this.alt, e.className = "mord", Object.assign(e.style, this.style), e;
	}
	toMarkup() {
		var e = "<img src=\"" + a(this.src) + "\"" + (" alt=\"" + a(this.alt) + "\""), t = De(this.style);
		return t && (e += " style=\"" + a(t) + "\""), e += "'/>", e;
	}
}, Fe = {
	î: "ı̂",
	ï: "ı̈",
	í: "ı́",
	ì: "ı̀"
}, Ie = class {
	constructor(e, t, n, r, i, a, o, s) {
		this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = n || 0, this.italic = r || 0, this.skew = i || 0, this.width = a || 0, this.classes = o || [], this.style = s || {}, this.maxFontSize = 0;
		var c = oe(this.text.charCodeAt(0));
		c && this.classes.push(c + "_fallback"), /[îïíì]/.test(this.text) && (this.text = Fe[this.text]);
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		var e = document.createTextNode(this.text), t = null;
		return this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = k(this.italic)), this.classes.length > 0 && (t ||= document.createElement("span"), t.className = Ee(this.classes)), Object.keys(this.style).length > 0 && (t ||= document.createElement("span"), Object.assign(t.style, this.style)), t ? (t.appendChild(e), t) : e;
	}
	toMarkup() {
		var e = !1, t = "<span";
		this.classes.length && (e = !0, t += " class=\"", t += a(Ee(this.classes)), t += "\"");
		var n = "";
		this.italic > 0 && (n += "margin-right:" + k(this.italic) + ";"), n += De(this.style), n && (e = !0, t += " style=\"" + a(n) + "\"");
		var r = a(this.text);
		return e ? (t += ">", t += r, t += "</span>", t) : r;
	}
}, Le = class {
	constructor(e, t) {
		this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/2000/svg", "svg");
		for (var t of Object.keys(this.attributes)) e.setAttribute(t, this.attributes[t]);
		for (var n = 0; n < this.children.length; n++) e.appendChild(this.children[n].toNode());
		return e;
	}
	toMarkup() {
		var e = "<svg xmlns=\"http://www.w3.org/2000/svg\"";
		for (var t of Object.keys(this.attributes)) e += " " + t + "=\"" + a(this.attributes[t]) + "\"";
		e += ">";
		for (var n = 0; n < this.children.length; n++) e += this.children[n].toMarkup();
		return e += "</svg>", e;
	}
}, Re = class {
	constructor(e, t) {
		this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/2000/svg", "path");
		return this.alternate ? e.setAttribute("d", this.alternate) : e.setAttribute("d", ye[this.pathName]), e;
	}
	toMarkup() {
		return this.alternate ? "<path d=\"" + a(this.alternate) + "\"/>" : "<path d=\"" + a(ye[this.pathName]) + "\"/>";
	}
}, ze = class {
	constructor(e) {
		this.attributes = void 0, this.attributes = e || {};
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/2000/svg", "line");
		for (var t of Object.keys(this.attributes)) e.setAttribute(t, this.attributes[t]);
		return e;
	}
	toMarkup() {
		var e = "<line";
		for (var t of Object.keys(this.attributes)) e += " " + t + "=\"" + a(this.attributes[t]) + "\"";
		return e += "/>", e;
	}
};
function Be(e) {
	if (e instanceof Ie) return e;
	throw Error("Expected symbolNode but got " + String(e) + ".");
}
function Ve(e) {
	if (e instanceof Me) return e;
	throw Error("Expected span<HtmlDomNode> but got " + String(e) + ".");
}
var He = (e) => e instanceof Me || e instanceof Ne || e instanceof Se, Ue = {
	"AMS-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		65: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		66: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		67: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		68: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		69: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		70: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		71: [
			0,
			.68889,
			0,
			0,
			.77778
		],
		72: [
			0,
			.68889,
			0,
			0,
			.77778
		],
		73: [
			0,
			.68889,
			0,
			0,
			.38889
		],
		74: [
			.16667,
			.68889,
			0,
			0,
			.5
		],
		75: [
			0,
			.68889,
			0,
			0,
			.77778
		],
		76: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		77: [
			0,
			.68889,
			0,
			0,
			.94445
		],
		78: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		79: [
			.16667,
			.68889,
			0,
			0,
			.77778
		],
		80: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		81: [
			.16667,
			.68889,
			0,
			0,
			.77778
		],
		82: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		83: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		84: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		85: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		86: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		87: [
			0,
			.68889,
			0,
			0,
			1
		],
		88: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		89: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		90: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		107: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		165: [
			0,
			.675,
			.025,
			0,
			.75
		],
		174: [
			.15559,
			.69224,
			0,
			0,
			.94666
		],
		240: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		295: [
			0,
			.68889,
			0,
			0,
			.54028
		],
		710: [
			0,
			.825,
			0,
			0,
			2.33334
		],
		732: [
			0,
			.9,
			0,
			0,
			2.33334
		],
		770: [
			0,
			.825,
			0,
			0,
			2.33334
		],
		771: [
			0,
			.9,
			0,
			0,
			2.33334
		],
		989: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		1008: [
			0,
			.43056,
			.04028,
			0,
			.66667
		],
		8245: [
			0,
			.54986,
			0,
			0,
			.275
		],
		8463: [
			0,
			.68889,
			0,
			0,
			.54028
		],
		8487: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		8498: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		8502: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		8503: [
			0,
			.68889,
			0,
			0,
			.44445
		],
		8504: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		8513: [
			0,
			.68889,
			0,
			0,
			.63889
		],
		8592: [
			-.03598,
			.46402,
			0,
			0,
			.5
		],
		8594: [
			-.03598,
			.46402,
			0,
			0,
			.5
		],
		8602: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8603: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8606: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8608: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8610: [
			.01354,
			.52239,
			0,
			0,
			1.11111
		],
		8611: [
			.01354,
			.52239,
			0,
			0,
			1.11111
		],
		8619: [
			0,
			.54986,
			0,
			0,
			1
		],
		8620: [
			0,
			.54986,
			0,
			0,
			1
		],
		8621: [
			-.13313,
			.37788,
			0,
			0,
			1.38889
		],
		8622: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8624: [
			0,
			.69224,
			0,
			0,
			.5
		],
		8625: [
			0,
			.69224,
			0,
			0,
			.5
		],
		8630: [
			0,
			.43056,
			0,
			0,
			1
		],
		8631: [
			0,
			.43056,
			0,
			0,
			1
		],
		8634: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8635: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8638: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8639: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8642: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8643: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8644: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8646: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8647: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8648: [
			.19444,
			.69224,
			0,
			0,
			.83334
		],
		8649: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8650: [
			.19444,
			.69224,
			0,
			0,
			.83334
		],
		8651: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8652: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8653: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8654: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8655: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8666: [
			.13667,
			.63667,
			0,
			0,
			1
		],
		8667: [
			.13667,
			.63667,
			0,
			0,
			1
		],
		8669: [
			-.13313,
			.37788,
			0,
			0,
			1
		],
		8672: [
			-.064,
			.437,
			0,
			0,
			1.334
		],
		8674: [
			-.064,
			.437,
			0,
			0,
			1.334
		],
		8705: [
			0,
			.825,
			0,
			0,
			.5
		],
		8708: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		8709: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8717: [
			0,
			.43056,
			0,
			0,
			.42917
		],
		8722: [
			-.03598,
			.46402,
			0,
			0,
			.5
		],
		8724: [
			.08198,
			.69224,
			0,
			0,
			.77778
		],
		8726: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8733: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8736: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8737: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8738: [
			.03517,
			.52239,
			0,
			0,
			.72222
		],
		8739: [
			.08167,
			.58167,
			0,
			0,
			.22222
		],
		8740: [
			.25142,
			.74111,
			0,
			0,
			.27778
		],
		8741: [
			.08167,
			.58167,
			0,
			0,
			.38889
		],
		8742: [
			.25142,
			.74111,
			0,
			0,
			.5
		],
		8756: [
			0,
			.69224,
			0,
			0,
			.66667
		],
		8757: [
			0,
			.69224,
			0,
			0,
			.66667
		],
		8764: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		8765: [
			-.13313,
			.37788,
			0,
			0,
			.77778
		],
		8769: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		8770: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8774: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8776: [
			-.01688,
			.48312,
			0,
			0,
			.77778
		],
		8778: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8782: [
			.06062,
			.54986,
			0,
			0,
			.77778
		],
		8783: [
			.06062,
			.54986,
			0,
			0,
			.77778
		],
		8785: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8786: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8787: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8790: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8791: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8796: [
			.08198,
			.91667,
			0,
			0,
			.77778
		],
		8806: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		8807: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		8808: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		8809: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		8812: [
			.25583,
			.75583,
			0,
			0,
			.5
		],
		8814: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8815: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8816: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8817: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8818: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8819: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8822: [
			.1808,
			.675,
			0,
			0,
			.77778
		],
		8823: [
			.1808,
			.675,
			0,
			0,
			.77778
		],
		8828: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8829: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8830: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8831: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8832: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8833: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8840: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8841: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8842: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8843: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8847: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8848: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8858: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8859: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8861: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8862: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8863: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8864: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8865: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8872: [
			0,
			.69224,
			0,
			0,
			.61111
		],
		8873: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8874: [
			0,
			.69224,
			0,
			0,
			.88889
		],
		8876: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		8877: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		8878: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		8879: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		8882: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8883: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8884: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8885: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8888: [
			0,
			.54986,
			0,
			0,
			1.11111
		],
		8890: [
			.19444,
			.43056,
			0,
			0,
			.55556
		],
		8891: [
			.19444,
			.69224,
			0,
			0,
			.61111
		],
		8892: [
			.19444,
			.69224,
			0,
			0,
			.61111
		],
		8901: [
			0,
			.54986,
			0,
			0,
			.27778
		],
		8903: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8905: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8906: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8907: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8908: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8909: [
			-.03598,
			.46402,
			0,
			0,
			.77778
		],
		8910: [
			0,
			.54986,
			0,
			0,
			.76042
		],
		8911: [
			0,
			.54986,
			0,
			0,
			.76042
		],
		8912: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8913: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8914: [
			0,
			.54986,
			0,
			0,
			.66667
		],
		8915: [
			0,
			.54986,
			0,
			0,
			.66667
		],
		8916: [
			0,
			.69224,
			0,
			0,
			.66667
		],
		8918: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8919: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8920: [
			.03517,
			.54986,
			0,
			0,
			1.33334
		],
		8921: [
			.03517,
			.54986,
			0,
			0,
			1.33334
		],
		8922: [
			.38569,
			.88569,
			0,
			0,
			.77778
		],
		8923: [
			.38569,
			.88569,
			0,
			0,
			.77778
		],
		8926: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8927: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8928: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8929: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8934: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8935: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8936: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8937: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8938: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8939: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8940: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8941: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8994: [
			.19444,
			.69224,
			0,
			0,
			.77778
		],
		8995: [
			.19444,
			.69224,
			0,
			0,
			.77778
		],
		9416: [
			.15559,
			.69224,
			0,
			0,
			.90222
		],
		9484: [
			0,
			.69224,
			0,
			0,
			.5
		],
		9488: [
			0,
			.69224,
			0,
			0,
			.5
		],
		9492: [
			0,
			.37788,
			0,
			0,
			.5
		],
		9496: [
			0,
			.37788,
			0,
			0,
			.5
		],
		9585: [
			.19444,
			.68889,
			0,
			0,
			.88889
		],
		9586: [
			.19444,
			.74111,
			0,
			0,
			.88889
		],
		9632: [
			0,
			.675,
			0,
			0,
			.77778
		],
		9633: [
			0,
			.675,
			0,
			0,
			.77778
		],
		9650: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9651: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9654: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		9660: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9661: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9664: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		9674: [
			.11111,
			.69224,
			0,
			0,
			.66667
		],
		9733: [
			.19444,
			.69224,
			0,
			0,
			.94445
		],
		10003: [
			0,
			.69224,
			0,
			0,
			.83334
		],
		10016: [
			0,
			.69224,
			0,
			0,
			.83334
		],
		10731: [
			.11111,
			.69224,
			0,
			0,
			.66667
		],
		10846: [
			.19444,
			.75583,
			0,
			0,
			.61111
		],
		10877: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10878: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10885: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10886: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10887: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		10888: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		10889: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10890: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10891: [
			.48256,
			.98256,
			0,
			0,
			.77778
		],
		10892: [
			.48256,
			.98256,
			0,
			0,
			.77778
		],
		10901: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10902: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10933: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		10934: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		10935: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10936: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10937: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10938: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10949: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10950: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10955: [
			.28481,
			.79383,
			0,
			0,
			.77778
		],
		10956: [
			.28481,
			.79383,
			0,
			0,
			.77778
		],
		57350: [
			.08167,
			.58167,
			0,
			0,
			.22222
		],
		57351: [
			.08167,
			.58167,
			0,
			0,
			.38889
		],
		57352: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		57353: [
			0,
			.43056,
			.04028,
			0,
			.66667
		],
		57356: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57357: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57358: [
			.41951,
			.91951,
			0,
			0,
			.77778
		],
		57359: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		57360: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		57361: [
			.41951,
			.91951,
			0,
			0,
			.77778
		],
		57366: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57367: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57368: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57369: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57370: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		57371: [
			.13597,
			.63597,
			0,
			0,
			.77778
		]
	},
	"Caligraphic-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		65: [
			0,
			.68333,
			0,
			.19445,
			.79847
		],
		66: [
			0,
			.68333,
			.03041,
			.13889,
			.65681
		],
		67: [
			0,
			.68333,
			.05834,
			.13889,
			.52653
		],
		68: [
			0,
			.68333,
			.02778,
			.08334,
			.77139
		],
		69: [
			0,
			.68333,
			.08944,
			.11111,
			.52778
		],
		70: [
			0,
			.68333,
			.09931,
			.11111,
			.71875
		],
		71: [
			.09722,
			.68333,
			.0593,
			.11111,
			.59487
		],
		72: [
			0,
			.68333,
			.00965,
			.11111,
			.84452
		],
		73: [
			0,
			.68333,
			.07382,
			0,
			.54452
		],
		74: [
			.09722,
			.68333,
			.18472,
			.16667,
			.67778
		],
		75: [
			0,
			.68333,
			.01445,
			.05556,
			.76195
		],
		76: [
			0,
			.68333,
			0,
			.13889,
			.68972
		],
		77: [
			0,
			.68333,
			0,
			.13889,
			1.2009
		],
		78: [
			0,
			.68333,
			.14736,
			.08334,
			.82049
		],
		79: [
			0,
			.68333,
			.02778,
			.11111,
			.79611
		],
		80: [
			0,
			.68333,
			.08222,
			.08334,
			.69556
		],
		81: [
			.09722,
			.68333,
			0,
			.11111,
			.81667
		],
		82: [
			0,
			.68333,
			0,
			.08334,
			.8475
		],
		83: [
			0,
			.68333,
			.075,
			.13889,
			.60556
		],
		84: [
			0,
			.68333,
			.25417,
			0,
			.54464
		],
		85: [
			0,
			.68333,
			.09931,
			.08334,
			.62583
		],
		86: [
			0,
			.68333,
			.08222,
			0,
			.61278
		],
		87: [
			0,
			.68333,
			.08222,
			.08334,
			.98778
		],
		88: [
			0,
			.68333,
			.14643,
			.13889,
			.7133
		],
		89: [
			.09722,
			.68333,
			.08222,
			.08334,
			.66834
		],
		90: [
			0,
			.68333,
			.07944,
			.13889,
			.72473
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		]
	},
	"Fraktur-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69141,
			0,
			0,
			.29574
		],
		34: [
			0,
			.69141,
			0,
			0,
			.21471
		],
		38: [
			0,
			.69141,
			0,
			0,
			.73786
		],
		39: [
			0,
			.69141,
			0,
			0,
			.21201
		],
		40: [
			.24982,
			.74947,
			0,
			0,
			.38865
		],
		41: [
			.24982,
			.74947,
			0,
			0,
			.38865
		],
		42: [
			0,
			.62119,
			0,
			0,
			.27764
		],
		43: [
			.08319,
			.58283,
			0,
			0,
			.75623
		],
		44: [
			0,
			.10803,
			0,
			0,
			.27764
		],
		45: [
			.08319,
			.58283,
			0,
			0,
			.75623
		],
		46: [
			0,
			.10803,
			0,
			0,
			.27764
		],
		47: [
			.24982,
			.74947,
			0,
			0,
			.50181
		],
		48: [
			0,
			.47534,
			0,
			0,
			.50181
		],
		49: [
			0,
			.47534,
			0,
			0,
			.50181
		],
		50: [
			0,
			.47534,
			0,
			0,
			.50181
		],
		51: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		52: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		53: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		54: [
			0,
			.69141,
			0,
			0,
			.50181
		],
		55: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		56: [
			0,
			.69141,
			0,
			0,
			.50181
		],
		57: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		58: [
			0,
			.47534,
			0,
			0,
			.21606
		],
		59: [
			.12604,
			.47534,
			0,
			0,
			.21606
		],
		61: [
			-.13099,
			.36866,
			0,
			0,
			.75623
		],
		63: [
			0,
			.69141,
			0,
			0,
			.36245
		],
		65: [
			0,
			.69141,
			0,
			0,
			.7176
		],
		66: [
			0,
			.69141,
			0,
			0,
			.88397
		],
		67: [
			0,
			.69141,
			0,
			0,
			.61254
		],
		68: [
			0,
			.69141,
			0,
			0,
			.83158
		],
		69: [
			0,
			.69141,
			0,
			0,
			.66278
		],
		70: [
			.12604,
			.69141,
			0,
			0,
			.61119
		],
		71: [
			0,
			.69141,
			0,
			0,
			.78539
		],
		72: [
			.06302,
			.69141,
			0,
			0,
			.7203
		],
		73: [
			0,
			.69141,
			0,
			0,
			.55448
		],
		74: [
			.12604,
			.69141,
			0,
			0,
			.55231
		],
		75: [
			0,
			.69141,
			0,
			0,
			.66845
		],
		76: [
			0,
			.69141,
			0,
			0,
			.66602
		],
		77: [
			0,
			.69141,
			0,
			0,
			1.04953
		],
		78: [
			0,
			.69141,
			0,
			0,
			.83212
		],
		79: [
			0,
			.69141,
			0,
			0,
			.82699
		],
		80: [
			.18906,
			.69141,
			0,
			0,
			.82753
		],
		81: [
			.03781,
			.69141,
			0,
			0,
			.82699
		],
		82: [
			0,
			.69141,
			0,
			0,
			.82807
		],
		83: [
			0,
			.69141,
			0,
			0,
			.82861
		],
		84: [
			0,
			.69141,
			0,
			0,
			.66899
		],
		85: [
			0,
			.69141,
			0,
			0,
			.64576
		],
		86: [
			0,
			.69141,
			0,
			0,
			.83131
		],
		87: [
			0,
			.69141,
			0,
			0,
			1.04602
		],
		88: [
			0,
			.69141,
			0,
			0,
			.71922
		],
		89: [
			.18906,
			.69141,
			0,
			0,
			.83293
		],
		90: [
			.12604,
			.69141,
			0,
			0,
			.60201
		],
		91: [
			.24982,
			.74947,
			0,
			0,
			.27764
		],
		93: [
			.24982,
			.74947,
			0,
			0,
			.27764
		],
		94: [
			0,
			.69141,
			0,
			0,
			.49965
		],
		97: [
			0,
			.47534,
			0,
			0,
			.50046
		],
		98: [
			0,
			.69141,
			0,
			0,
			.51315
		],
		99: [
			0,
			.47534,
			0,
			0,
			.38946
		],
		100: [
			0,
			.62119,
			0,
			0,
			.49857
		],
		101: [
			0,
			.47534,
			0,
			0,
			.40053
		],
		102: [
			.18906,
			.69141,
			0,
			0,
			.32626
		],
		103: [
			.18906,
			.47534,
			0,
			0,
			.5037
		],
		104: [
			.18906,
			.69141,
			0,
			0,
			.52126
		],
		105: [
			0,
			.69141,
			0,
			0,
			.27899
		],
		106: [
			0,
			.69141,
			0,
			0,
			.28088
		],
		107: [
			0,
			.69141,
			0,
			0,
			.38946
		],
		108: [
			0,
			.69141,
			0,
			0,
			.27953
		],
		109: [
			0,
			.47534,
			0,
			0,
			.76676
		],
		110: [
			0,
			.47534,
			0,
			0,
			.52666
		],
		111: [
			0,
			.47534,
			0,
			0,
			.48885
		],
		112: [
			.18906,
			.52396,
			0,
			0,
			.50046
		],
		113: [
			.18906,
			.47534,
			0,
			0,
			.48912
		],
		114: [
			0,
			.47534,
			0,
			0,
			.38919
		],
		115: [
			0,
			.47534,
			0,
			0,
			.44266
		],
		116: [
			0,
			.62119,
			0,
			0,
			.33301
		],
		117: [
			0,
			.47534,
			0,
			0,
			.5172
		],
		118: [
			0,
			.52396,
			0,
			0,
			.5118
		],
		119: [
			0,
			.52396,
			0,
			0,
			.77351
		],
		120: [
			.18906,
			.47534,
			0,
			0,
			.38865
		],
		121: [
			.18906,
			.47534,
			0,
			0,
			.49884
		],
		122: [
			.18906,
			.47534,
			0,
			0,
			.39054
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		8216: [
			0,
			.69141,
			0,
			0,
			.21471
		],
		8217: [
			0,
			.69141,
			0,
			0,
			.21471
		],
		58112: [
			0,
			.62119,
			0,
			0,
			.49749
		],
		58113: [
			0,
			.62119,
			0,
			0,
			.4983
		],
		58114: [
			.18906,
			.69141,
			0,
			0,
			.33328
		],
		58115: [
			.18906,
			.69141,
			0,
			0,
			.32923
		],
		58116: [
			.18906,
			.47534,
			0,
			0,
			.50343
		],
		58117: [
			0,
			.69141,
			0,
			0,
			.33301
		],
		58118: [
			0,
			.62119,
			0,
			0,
			.33409
		],
		58119: [
			0,
			.47534,
			0,
			0,
			.50073
		]
	},
	"Main-Bold": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.35
		],
		34: [
			0,
			.69444,
			0,
			0,
			.60278
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.95833
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.575
		],
		37: [
			.05556,
			.75,
			0,
			0,
			.95833
		],
		38: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		39: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		40: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		41: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		42: [
			0,
			.75,
			0,
			0,
			.575
		],
		43: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		44: [
			.19444,
			.15556,
			0,
			0,
			.31944
		],
		45: [
			0,
			.44444,
			0,
			0,
			.38333
		],
		46: [
			0,
			.15556,
			0,
			0,
			.31944
		],
		47: [
			.25,
			.75,
			0,
			0,
			.575
		],
		48: [
			0,
			.64444,
			0,
			0,
			.575
		],
		49: [
			0,
			.64444,
			0,
			0,
			.575
		],
		50: [
			0,
			.64444,
			0,
			0,
			.575
		],
		51: [
			0,
			.64444,
			0,
			0,
			.575
		],
		52: [
			0,
			.64444,
			0,
			0,
			.575
		],
		53: [
			0,
			.64444,
			0,
			0,
			.575
		],
		54: [
			0,
			.64444,
			0,
			0,
			.575
		],
		55: [
			0,
			.64444,
			0,
			0,
			.575
		],
		56: [
			0,
			.64444,
			0,
			0,
			.575
		],
		57: [
			0,
			.64444,
			0,
			0,
			.575
		],
		58: [
			0,
			.44444,
			0,
			0,
			.31944
		],
		59: [
			.19444,
			.44444,
			0,
			0,
			.31944
		],
		60: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		61: [
			-.10889,
			.39111,
			0,
			0,
			.89444
		],
		62: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		63: [
			0,
			.69444,
			0,
			0,
			.54305
		],
		64: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		65: [
			0,
			.68611,
			0,
			0,
			.86944
		],
		66: [
			0,
			.68611,
			0,
			0,
			.81805
		],
		67: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		68: [
			0,
			.68611,
			0,
			0,
			.88194
		],
		69: [
			0,
			.68611,
			0,
			0,
			.75555
		],
		70: [
			0,
			.68611,
			0,
			0,
			.72361
		],
		71: [
			0,
			.68611,
			0,
			0,
			.90416
		],
		72: [
			0,
			.68611,
			0,
			0,
			.9
		],
		73: [
			0,
			.68611,
			0,
			0,
			.43611
		],
		74: [
			0,
			.68611,
			0,
			0,
			.59444
		],
		75: [
			0,
			.68611,
			0,
			0,
			.90138
		],
		76: [
			0,
			.68611,
			0,
			0,
			.69166
		],
		77: [
			0,
			.68611,
			0,
			0,
			1.09166
		],
		78: [
			0,
			.68611,
			0,
			0,
			.9
		],
		79: [
			0,
			.68611,
			0,
			0,
			.86388
		],
		80: [
			0,
			.68611,
			0,
			0,
			.78611
		],
		81: [
			.19444,
			.68611,
			0,
			0,
			.86388
		],
		82: [
			0,
			.68611,
			0,
			0,
			.8625
		],
		83: [
			0,
			.68611,
			0,
			0,
			.63889
		],
		84: [
			0,
			.68611,
			0,
			0,
			.8
		],
		85: [
			0,
			.68611,
			0,
			0,
			.88472
		],
		86: [
			0,
			.68611,
			.01597,
			0,
			.86944
		],
		87: [
			0,
			.68611,
			.01597,
			0,
			1.18888
		],
		88: [
			0,
			.68611,
			0,
			0,
			.86944
		],
		89: [
			0,
			.68611,
			.02875,
			0,
			.86944
		],
		90: [
			0,
			.68611,
			0,
			0,
			.70277
		],
		91: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		92: [
			.25,
			.75,
			0,
			0,
			.575
		],
		93: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		94: [
			0,
			.69444,
			0,
			0,
			.575
		],
		95: [
			.31,
			.13444,
			.03194,
			0,
			.575
		],
		97: [
			0,
			.44444,
			0,
			0,
			.55902
		],
		98: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		99: [
			0,
			.44444,
			0,
			0,
			.51111
		],
		100: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		101: [
			0,
			.44444,
			0,
			0,
			.52708
		],
		102: [
			0,
			.69444,
			.10903,
			0,
			.35139
		],
		103: [
			.19444,
			.44444,
			.01597,
			0,
			.575
		],
		104: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		105: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		106: [
			.19444,
			.69444,
			0,
			0,
			.35139
		],
		107: [
			0,
			.69444,
			0,
			0,
			.60694
		],
		108: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		109: [
			0,
			.44444,
			0,
			0,
			.95833
		],
		110: [
			0,
			.44444,
			0,
			0,
			.63889
		],
		111: [
			0,
			.44444,
			0,
			0,
			.575
		],
		112: [
			.19444,
			.44444,
			0,
			0,
			.63889
		],
		113: [
			.19444,
			.44444,
			0,
			0,
			.60694
		],
		114: [
			0,
			.44444,
			0,
			0,
			.47361
		],
		115: [
			0,
			.44444,
			0,
			0,
			.45361
		],
		116: [
			0,
			.63492,
			0,
			0,
			.44722
		],
		117: [
			0,
			.44444,
			0,
			0,
			.63889
		],
		118: [
			0,
			.44444,
			.01597,
			0,
			.60694
		],
		119: [
			0,
			.44444,
			.01597,
			0,
			.83055
		],
		120: [
			0,
			.44444,
			0,
			0,
			.60694
		],
		121: [
			.19444,
			.44444,
			.01597,
			0,
			.60694
		],
		122: [
			0,
			.44444,
			0,
			0,
			.51111
		],
		123: [
			.25,
			.75,
			0,
			0,
			.575
		],
		124: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		125: [
			.25,
			.75,
			0,
			0,
			.575
		],
		126: [
			.35,
			.34444,
			0,
			0,
			.575
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		163: [
			0,
			.69444,
			0,
			0,
			.86853
		],
		168: [
			0,
			.69444,
			0,
			0,
			.575
		],
		172: [
			0,
			.44444,
			0,
			0,
			.76666
		],
		176: [
			0,
			.69444,
			0,
			0,
			.86944
		],
		177: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		184: [
			.17014,
			0,
			0,
			0,
			.51111
		],
		198: [
			0,
			.68611,
			0,
			0,
			1.04166
		],
		215: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		216: [
			.04861,
			.73472,
			0,
			0,
			.89444
		],
		223: [
			0,
			.69444,
			0,
			0,
			.59722
		],
		230: [
			0,
			.44444,
			0,
			0,
			.83055
		],
		247: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		248: [
			.09722,
			.54167,
			0,
			0,
			.575
		],
		305: [
			0,
			.44444,
			0,
			0,
			.31944
		],
		338: [
			0,
			.68611,
			0,
			0,
			1.16944
		],
		339: [
			0,
			.44444,
			0,
			0,
			.89444
		],
		567: [
			.19444,
			.44444,
			0,
			0,
			.35139
		],
		710: [
			0,
			.69444,
			0,
			0,
			.575
		],
		711: [
			0,
			.63194,
			0,
			0,
			.575
		],
		713: [
			0,
			.59611,
			0,
			0,
			.575
		],
		714: [
			0,
			.69444,
			0,
			0,
			.575
		],
		715: [
			0,
			.69444,
			0,
			0,
			.575
		],
		728: [
			0,
			.69444,
			0,
			0,
			.575
		],
		729: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		730: [
			0,
			.69444,
			0,
			0,
			.86944
		],
		732: [
			0,
			.69444,
			0,
			0,
			.575
		],
		733: [
			0,
			.69444,
			0,
			0,
			.575
		],
		915: [
			0,
			.68611,
			0,
			0,
			.69166
		],
		916: [
			0,
			.68611,
			0,
			0,
			.95833
		],
		920: [
			0,
			.68611,
			0,
			0,
			.89444
		],
		923: [
			0,
			.68611,
			0,
			0,
			.80555
		],
		926: [
			0,
			.68611,
			0,
			0,
			.76666
		],
		928: [
			0,
			.68611,
			0,
			0,
			.9
		],
		931: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		933: [
			0,
			.68611,
			0,
			0,
			.89444
		],
		934: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		936: [
			0,
			.68611,
			0,
			0,
			.89444
		],
		937: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		8211: [
			0,
			.44444,
			.03194,
			0,
			.575
		],
		8212: [
			0,
			.44444,
			.03194,
			0,
			1.14999
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.60278
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.60278
		],
		8224: [
			.19444,
			.69444,
			0,
			0,
			.51111
		],
		8225: [
			.19444,
			.69444,
			0,
			0,
			.51111
		],
		8242: [
			0,
			.55556,
			0,
			0,
			.34444
		],
		8407: [
			0,
			.72444,
			.15486,
			0,
			.575
		],
		8463: [
			0,
			.69444,
			0,
			0,
			.66759
		],
		8465: [
			0,
			.69444,
			0,
			0,
			.83055
		],
		8467: [
			0,
			.69444,
			0,
			0,
			.47361
		],
		8472: [
			.19444,
			.44444,
			0,
			0,
			.74027
		],
		8476: [
			0,
			.69444,
			0,
			0,
			.83055
		],
		8501: [
			0,
			.69444,
			0,
			0,
			.70277
		],
		8592: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8593: [
			.19444,
			.69444,
			0,
			0,
			.575
		],
		8594: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8595: [
			.19444,
			.69444,
			0,
			0,
			.575
		],
		8596: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8597: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8598: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8599: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8600: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8601: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8636: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8637: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8640: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8641: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8656: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8657: [
			.19444,
			.69444,
			0,
			0,
			.70277
		],
		8658: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8659: [
			.19444,
			.69444,
			0,
			0,
			.70277
		],
		8660: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8661: [
			.25,
			.75,
			0,
			0,
			.70277
		],
		8704: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		8706: [
			0,
			.69444,
			.06389,
			0,
			.62847
		],
		8707: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		8709: [
			.05556,
			.75,
			0,
			0,
			.575
		],
		8711: [
			0,
			.68611,
			0,
			0,
			.95833
		],
		8712: [
			.08556,
			.58556,
			0,
			0,
			.76666
		],
		8715: [
			.08556,
			.58556,
			0,
			0,
			.76666
		],
		8722: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8723: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8725: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8726: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8727: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		8728: [
			-.02639,
			.47361,
			0,
			0,
			.575
		],
		8729: [
			-.02639,
			.47361,
			0,
			0,
			.575
		],
		8730: [
			.18,
			.82,
			0,
			0,
			.95833
		],
		8733: [
			0,
			.44444,
			0,
			0,
			.89444
		],
		8734: [
			0,
			.44444,
			0,
			0,
			1.14999
		],
		8736: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8739: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		8741: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8743: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8744: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8745: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8746: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8747: [
			.19444,
			.69444,
			.12778,
			0,
			.56875
		],
		8764: [
			-.10889,
			.39111,
			0,
			0,
			.89444
		],
		8768: [
			.19444,
			.69444,
			0,
			0,
			.31944
		],
		8771: [
			.00222,
			.50222,
			0,
			0,
			.89444
		],
		8773: [
			.027,
			.638,
			0,
			0,
			.894
		],
		8776: [
			.02444,
			.52444,
			0,
			0,
			.89444
		],
		8781: [
			.00222,
			.50222,
			0,
			0,
			.89444
		],
		8801: [
			.00222,
			.50222,
			0,
			0,
			.89444
		],
		8804: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8805: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8810: [
			.08556,
			.58556,
			0,
			0,
			1.14999
		],
		8811: [
			.08556,
			.58556,
			0,
			0,
			1.14999
		],
		8826: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8827: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8834: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8835: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8838: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8839: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8846: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8849: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8850: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8851: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8852: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8853: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8854: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8855: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8856: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8857: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8866: [
			0,
			.69444,
			0,
			0,
			.70277
		],
		8867: [
			0,
			.69444,
			0,
			0,
			.70277
		],
		8868: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		8869: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		8900: [
			-.02639,
			.47361,
			0,
			0,
			.575
		],
		8901: [
			-.02639,
			.47361,
			0,
			0,
			.31944
		],
		8902: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		8968: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8969: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8970: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8971: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8994: [
			-.13889,
			.36111,
			0,
			0,
			1.14999
		],
		8995: [
			-.13889,
			.36111,
			0,
			0,
			1.14999
		],
		9651: [
			.19444,
			.69444,
			0,
			0,
			1.02222
		],
		9657: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		9661: [
			.19444,
			.69444,
			0,
			0,
			1.02222
		],
		9667: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		9711: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		9824: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9825: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9826: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9827: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9837: [
			0,
			.75,
			0,
			0,
			.44722
		],
		9838: [
			.19444,
			.69444,
			0,
			0,
			.44722
		],
		9839: [
			.19444,
			.69444,
			0,
			0,
			.44722
		],
		10216: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		10217: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		10815: [
			0,
			.68611,
			0,
			0,
			.9
		],
		10927: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		10928: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		57376: [
			.19444,
			.69444,
			0,
			0,
			0
		]
	},
	"Main-BoldItalic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			.11417,
			0,
			.38611
		],
		34: [
			0,
			.69444,
			.07939,
			0,
			.62055
		],
		35: [
			.19444,
			.69444,
			.06833,
			0,
			.94444
		],
		37: [
			.05556,
			.75,
			.12861,
			0,
			.94444
		],
		38: [
			0,
			.69444,
			.08528,
			0,
			.88555
		],
		39: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		40: [
			.25,
			.75,
			.15806,
			0,
			.47333
		],
		41: [
			.25,
			.75,
			.03306,
			0,
			.47333
		],
		42: [
			0,
			.75,
			.14333,
			0,
			.59111
		],
		43: [
			.10333,
			.60333,
			.03306,
			0,
			.88555
		],
		44: [
			.19444,
			.14722,
			0,
			0,
			.35555
		],
		45: [
			0,
			.44444,
			.02611,
			0,
			.41444
		],
		46: [
			0,
			.14722,
			0,
			0,
			.35555
		],
		47: [
			.25,
			.75,
			.15806,
			0,
			.59111
		],
		48: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		49: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		50: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		51: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		52: [
			.19444,
			.64444,
			.13167,
			0,
			.59111
		],
		53: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		54: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		55: [
			.19444,
			.64444,
			.13167,
			0,
			.59111
		],
		56: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		57: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		58: [
			0,
			.44444,
			.06695,
			0,
			.35555
		],
		59: [
			.19444,
			.44444,
			.06695,
			0,
			.35555
		],
		61: [
			-.10889,
			.39111,
			.06833,
			0,
			.88555
		],
		63: [
			0,
			.69444,
			.11472,
			0,
			.59111
		],
		64: [
			0,
			.69444,
			.09208,
			0,
			.88555
		],
		65: [
			0,
			.68611,
			0,
			0,
			.86555
		],
		66: [
			0,
			.68611,
			.0992,
			0,
			.81666
		],
		67: [
			0,
			.68611,
			.14208,
			0,
			.82666
		],
		68: [
			0,
			.68611,
			.09062,
			0,
			.87555
		],
		69: [
			0,
			.68611,
			.11431,
			0,
			.75666
		],
		70: [
			0,
			.68611,
			.12903,
			0,
			.72722
		],
		71: [
			0,
			.68611,
			.07347,
			0,
			.89527
		],
		72: [
			0,
			.68611,
			.17208,
			0,
			.8961
		],
		73: [
			0,
			.68611,
			.15681,
			0,
			.47166
		],
		74: [
			0,
			.68611,
			.145,
			0,
			.61055
		],
		75: [
			0,
			.68611,
			.14208,
			0,
			.89499
		],
		76: [
			0,
			.68611,
			0,
			0,
			.69777
		],
		77: [
			0,
			.68611,
			.17208,
			0,
			1.07277
		],
		78: [
			0,
			.68611,
			.17208,
			0,
			.8961
		],
		79: [
			0,
			.68611,
			.09062,
			0,
			.85499
		],
		80: [
			0,
			.68611,
			.0992,
			0,
			.78721
		],
		81: [
			.19444,
			.68611,
			.09062,
			0,
			.85499
		],
		82: [
			0,
			.68611,
			.02559,
			0,
			.85944
		],
		83: [
			0,
			.68611,
			.11264,
			0,
			.64999
		],
		84: [
			0,
			.68611,
			.12903,
			0,
			.7961
		],
		85: [
			0,
			.68611,
			.17208,
			0,
			.88083
		],
		86: [
			0,
			.68611,
			.18625,
			0,
			.86555
		],
		87: [
			0,
			.68611,
			.18625,
			0,
			1.15999
		],
		88: [
			0,
			.68611,
			.15681,
			0,
			.86555
		],
		89: [
			0,
			.68611,
			.19803,
			0,
			.86555
		],
		90: [
			0,
			.68611,
			.14208,
			0,
			.70888
		],
		91: [
			.25,
			.75,
			.1875,
			0,
			.35611
		],
		93: [
			.25,
			.75,
			.09972,
			0,
			.35611
		],
		94: [
			0,
			.69444,
			.06709,
			0,
			.59111
		],
		95: [
			.31,
			.13444,
			.09811,
			0,
			.59111
		],
		97: [
			0,
			.44444,
			.09426,
			0,
			.59111
		],
		98: [
			0,
			.69444,
			.07861,
			0,
			.53222
		],
		99: [
			0,
			.44444,
			.05222,
			0,
			.53222
		],
		100: [
			0,
			.69444,
			.10861,
			0,
			.59111
		],
		101: [
			0,
			.44444,
			.085,
			0,
			.53222
		],
		102: [
			.19444,
			.69444,
			.21778,
			0,
			.4
		],
		103: [
			.19444,
			.44444,
			.105,
			0,
			.53222
		],
		104: [
			0,
			.69444,
			.09426,
			0,
			.59111
		],
		105: [
			0,
			.69326,
			.11387,
			0,
			.35555
		],
		106: [
			.19444,
			.69326,
			.1672,
			0,
			.35555
		],
		107: [
			0,
			.69444,
			.11111,
			0,
			.53222
		],
		108: [
			0,
			.69444,
			.10861,
			0,
			.29666
		],
		109: [
			0,
			.44444,
			.09426,
			0,
			.94444
		],
		110: [
			0,
			.44444,
			.09426,
			0,
			.64999
		],
		111: [
			0,
			.44444,
			.07861,
			0,
			.59111
		],
		112: [
			.19444,
			.44444,
			.07861,
			0,
			.59111
		],
		113: [
			.19444,
			.44444,
			.105,
			0,
			.53222
		],
		114: [
			0,
			.44444,
			.11111,
			0,
			.50167
		],
		115: [
			0,
			.44444,
			.08167,
			0,
			.48694
		],
		116: [
			0,
			.63492,
			.09639,
			0,
			.385
		],
		117: [
			0,
			.44444,
			.09426,
			0,
			.62055
		],
		118: [
			0,
			.44444,
			.11111,
			0,
			.53222
		],
		119: [
			0,
			.44444,
			.11111,
			0,
			.76777
		],
		120: [
			0,
			.44444,
			.12583,
			0,
			.56055
		],
		121: [
			.19444,
			.44444,
			.105,
			0,
			.56166
		],
		122: [
			0,
			.44444,
			.13889,
			0,
			.49055
		],
		126: [
			.35,
			.34444,
			.11472,
			0,
			.59111
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.69444,
			.11473,
			0,
			.59111
		],
		176: [
			0,
			.69444,
			0,
			0,
			.94888
		],
		184: [
			.17014,
			0,
			0,
			0,
			.53222
		],
		198: [
			0,
			.68611,
			.11431,
			0,
			1.02277
		],
		216: [
			.04861,
			.73472,
			.09062,
			0,
			.88555
		],
		223: [
			.19444,
			.69444,
			.09736,
			0,
			.665
		],
		230: [
			0,
			.44444,
			.085,
			0,
			.82666
		],
		248: [
			.09722,
			.54167,
			.09458,
			0,
			.59111
		],
		305: [
			0,
			.44444,
			.09426,
			0,
			.35555
		],
		338: [
			0,
			.68611,
			.11431,
			0,
			1.14054
		],
		339: [
			0,
			.44444,
			.085,
			0,
			.82666
		],
		567: [
			.19444,
			.44444,
			.04611,
			0,
			.385
		],
		710: [
			0,
			.69444,
			.06709,
			0,
			.59111
		],
		711: [
			0,
			.63194,
			.08271,
			0,
			.59111
		],
		713: [
			0,
			.59444,
			.10444,
			0,
			.59111
		],
		714: [
			0,
			.69444,
			.08528,
			0,
			.59111
		],
		715: [
			0,
			.69444,
			0,
			0,
			.59111
		],
		728: [
			0,
			.69444,
			.10333,
			0,
			.59111
		],
		729: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		730: [
			0,
			.69444,
			0,
			0,
			.94888
		],
		732: [
			0,
			.69444,
			.11472,
			0,
			.59111
		],
		733: [
			0,
			.69444,
			.11472,
			0,
			.59111
		],
		915: [
			0,
			.68611,
			.12903,
			0,
			.69777
		],
		916: [
			0,
			.68611,
			0,
			0,
			.94444
		],
		920: [
			0,
			.68611,
			.09062,
			0,
			.88555
		],
		923: [
			0,
			.68611,
			0,
			0,
			.80666
		],
		926: [
			0,
			.68611,
			.15092,
			0,
			.76777
		],
		928: [
			0,
			.68611,
			.17208,
			0,
			.8961
		],
		931: [
			0,
			.68611,
			.11431,
			0,
			.82666
		],
		933: [
			0,
			.68611,
			.10778,
			0,
			.88555
		],
		934: [
			0,
			.68611,
			.05632,
			0,
			.82666
		],
		936: [
			0,
			.68611,
			.10778,
			0,
			.88555
		],
		937: [
			0,
			.68611,
			.0992,
			0,
			.82666
		],
		8211: [
			0,
			.44444,
			.09811,
			0,
			.59111
		],
		8212: [
			0,
			.44444,
			.09811,
			0,
			1.18221
		],
		8216: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		8217: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		8220: [
			0,
			.69444,
			.16772,
			0,
			.62055
		],
		8221: [
			0,
			.69444,
			.07939,
			0,
			.62055
		]
	},
	"Main-Italic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		34: [
			0,
			.69444,
			.06961,
			0,
			.51444
		],
		35: [
			.19444,
			.69444,
			.06616,
			0,
			.81777
		],
		37: [
			.05556,
			.75,
			.13639,
			0,
			.81777
		],
		38: [
			0,
			.69444,
			.09694,
			0,
			.76666
		],
		39: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		40: [
			.25,
			.75,
			.16194,
			0,
			.40889
		],
		41: [
			.25,
			.75,
			.03694,
			0,
			.40889
		],
		42: [
			0,
			.75,
			.14917,
			0,
			.51111
		],
		43: [
			.05667,
			.56167,
			.03694,
			0,
			.76666
		],
		44: [
			.19444,
			.10556,
			0,
			0,
			.30667
		],
		45: [
			0,
			.43056,
			.02826,
			0,
			.35778
		],
		46: [
			0,
			.10556,
			0,
			0,
			.30667
		],
		47: [
			.25,
			.75,
			.16194,
			0,
			.51111
		],
		48: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		49: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		50: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		51: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		52: [
			.19444,
			.64444,
			.13556,
			0,
			.51111
		],
		53: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		54: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		55: [
			.19444,
			.64444,
			.13556,
			0,
			.51111
		],
		56: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		57: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		58: [
			0,
			.43056,
			.0582,
			0,
			.30667
		],
		59: [
			.19444,
			.43056,
			.0582,
			0,
			.30667
		],
		61: [
			-.13313,
			.36687,
			.06616,
			0,
			.76666
		],
		63: [
			0,
			.69444,
			.1225,
			0,
			.51111
		],
		64: [
			0,
			.69444,
			.09597,
			0,
			.76666
		],
		65: [
			0,
			.68333,
			0,
			0,
			.74333
		],
		66: [
			0,
			.68333,
			.10257,
			0,
			.70389
		],
		67: [
			0,
			.68333,
			.14528,
			0,
			.71555
		],
		68: [
			0,
			.68333,
			.09403,
			0,
			.755
		],
		69: [
			0,
			.68333,
			.12028,
			0,
			.67833
		],
		70: [
			0,
			.68333,
			.13305,
			0,
			.65277
		],
		71: [
			0,
			.68333,
			.08722,
			0,
			.77361
		],
		72: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		73: [
			0,
			.68333,
			.15806,
			0,
			.38555
		],
		74: [
			0,
			.68333,
			.14028,
			0,
			.525
		],
		75: [
			0,
			.68333,
			.14528,
			0,
			.76888
		],
		76: [
			0,
			.68333,
			0,
			0,
			.62722
		],
		77: [
			0,
			.68333,
			.16389,
			0,
			.89666
		],
		78: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		79: [
			0,
			.68333,
			.09403,
			0,
			.76666
		],
		80: [
			0,
			.68333,
			.10257,
			0,
			.67833
		],
		81: [
			.19444,
			.68333,
			.09403,
			0,
			.76666
		],
		82: [
			0,
			.68333,
			.03868,
			0,
			.72944
		],
		83: [
			0,
			.68333,
			.11972,
			0,
			.56222
		],
		84: [
			0,
			.68333,
			.13305,
			0,
			.71555
		],
		85: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		86: [
			0,
			.68333,
			.18361,
			0,
			.74333
		],
		87: [
			0,
			.68333,
			.18361,
			0,
			.99888
		],
		88: [
			0,
			.68333,
			.15806,
			0,
			.74333
		],
		89: [
			0,
			.68333,
			.19383,
			0,
			.74333
		],
		90: [
			0,
			.68333,
			.14528,
			0,
			.61333
		],
		91: [
			.25,
			.75,
			.1875,
			0,
			.30667
		],
		93: [
			.25,
			.75,
			.10528,
			0,
			.30667
		],
		94: [
			0,
			.69444,
			.06646,
			0,
			.51111
		],
		95: [
			.31,
			.12056,
			.09208,
			0,
			.51111
		],
		97: [
			0,
			.43056,
			.07671,
			0,
			.51111
		],
		98: [
			0,
			.69444,
			.06312,
			0,
			.46
		],
		99: [
			0,
			.43056,
			.05653,
			0,
			.46
		],
		100: [
			0,
			.69444,
			.10333,
			0,
			.51111
		],
		101: [
			0,
			.43056,
			.07514,
			0,
			.46
		],
		102: [
			.19444,
			.69444,
			.21194,
			0,
			.30667
		],
		103: [
			.19444,
			.43056,
			.08847,
			0,
			.46
		],
		104: [
			0,
			.69444,
			.07671,
			0,
			.51111
		],
		105: [
			0,
			.65536,
			.1019,
			0,
			.30667
		],
		106: [
			.19444,
			.65536,
			.14467,
			0,
			.30667
		],
		107: [
			0,
			.69444,
			.10764,
			0,
			.46
		],
		108: [
			0,
			.69444,
			.10333,
			0,
			.25555
		],
		109: [
			0,
			.43056,
			.07671,
			0,
			.81777
		],
		110: [
			0,
			.43056,
			.07671,
			0,
			.56222
		],
		111: [
			0,
			.43056,
			.06312,
			0,
			.51111
		],
		112: [
			.19444,
			.43056,
			.06312,
			0,
			.51111
		],
		113: [
			.19444,
			.43056,
			.08847,
			0,
			.46
		],
		114: [
			0,
			.43056,
			.10764,
			0,
			.42166
		],
		115: [
			0,
			.43056,
			.08208,
			0,
			.40889
		],
		116: [
			0,
			.61508,
			.09486,
			0,
			.33222
		],
		117: [
			0,
			.43056,
			.07671,
			0,
			.53666
		],
		118: [
			0,
			.43056,
			.10764,
			0,
			.46
		],
		119: [
			0,
			.43056,
			.10764,
			0,
			.66444
		],
		120: [
			0,
			.43056,
			.12042,
			0,
			.46389
		],
		121: [
			.19444,
			.43056,
			.08847,
			0,
			.48555
		],
		122: [
			0,
			.43056,
			.12292,
			0,
			.40889
		],
		126: [
			.35,
			.31786,
			.11585,
			0,
			.51111
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.66786,
			.10474,
			0,
			.51111
		],
		176: [
			0,
			.69444,
			0,
			0,
			.83129
		],
		184: [
			.17014,
			0,
			0,
			0,
			.46
		],
		198: [
			0,
			.68333,
			.12028,
			0,
			.88277
		],
		216: [
			.04861,
			.73194,
			.09403,
			0,
			.76666
		],
		223: [
			.19444,
			.69444,
			.10514,
			0,
			.53666
		],
		230: [
			0,
			.43056,
			.07514,
			0,
			.71555
		],
		248: [
			.09722,
			.52778,
			.09194,
			0,
			.51111
		],
		338: [
			0,
			.68333,
			.12028,
			0,
			.98499
		],
		339: [
			0,
			.43056,
			.07514,
			0,
			.71555
		],
		710: [
			0,
			.69444,
			.06646,
			0,
			.51111
		],
		711: [
			0,
			.62847,
			.08295,
			0,
			.51111
		],
		713: [
			0,
			.56167,
			.10333,
			0,
			.51111
		],
		714: [
			0,
			.69444,
			.09694,
			0,
			.51111
		],
		715: [
			0,
			.69444,
			0,
			0,
			.51111
		],
		728: [
			0,
			.69444,
			.10806,
			0,
			.51111
		],
		729: [
			0,
			.66786,
			.11752,
			0,
			.30667
		],
		730: [
			0,
			.69444,
			0,
			0,
			.83129
		],
		732: [
			0,
			.66786,
			.11585,
			0,
			.51111
		],
		733: [
			0,
			.69444,
			.1225,
			0,
			.51111
		],
		915: [
			0,
			.68333,
			.13305,
			0,
			.62722
		],
		916: [
			0,
			.68333,
			0,
			0,
			.81777
		],
		920: [
			0,
			.68333,
			.09403,
			0,
			.76666
		],
		923: [
			0,
			.68333,
			0,
			0,
			.69222
		],
		926: [
			0,
			.68333,
			.15294,
			0,
			.66444
		],
		928: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		931: [
			0,
			.68333,
			.12028,
			0,
			.71555
		],
		933: [
			0,
			.68333,
			.11111,
			0,
			.76666
		],
		934: [
			0,
			.68333,
			.05986,
			0,
			.71555
		],
		936: [
			0,
			.68333,
			.11111,
			0,
			.76666
		],
		937: [
			0,
			.68333,
			.10257,
			0,
			.71555
		],
		8211: [
			0,
			.43056,
			.09208,
			0,
			.51111
		],
		8212: [
			0,
			.43056,
			.09208,
			0,
			1.02222
		],
		8216: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		8217: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		8220: [
			0,
			.69444,
			.1685,
			0,
			.51444
		],
		8221: [
			0,
			.69444,
			.06961,
			0,
			.51444
		],
		8463: [
			0,
			.68889,
			0,
			0,
			.54028
		]
	},
	"Main-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		34: [
			0,
			.69444,
			0,
			0,
			.5
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.83334
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.5
		],
		37: [
			.05556,
			.75,
			0,
			0,
			.83334
		],
		38: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		39: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		40: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		41: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		42: [
			0,
			.75,
			0,
			0,
			.5
		],
		43: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		44: [
			.19444,
			.10556,
			0,
			0,
			.27778
		],
		45: [
			0,
			.43056,
			0,
			0,
			.33333
		],
		46: [
			0,
			.10556,
			0,
			0,
			.27778
		],
		47: [
			.25,
			.75,
			0,
			0,
			.5
		],
		48: [
			0,
			.64444,
			0,
			0,
			.5
		],
		49: [
			0,
			.64444,
			0,
			0,
			.5
		],
		50: [
			0,
			.64444,
			0,
			0,
			.5
		],
		51: [
			0,
			.64444,
			0,
			0,
			.5
		],
		52: [
			0,
			.64444,
			0,
			0,
			.5
		],
		53: [
			0,
			.64444,
			0,
			0,
			.5
		],
		54: [
			0,
			.64444,
			0,
			0,
			.5
		],
		55: [
			0,
			.64444,
			0,
			0,
			.5
		],
		56: [
			0,
			.64444,
			0,
			0,
			.5
		],
		57: [
			0,
			.64444,
			0,
			0,
			.5
		],
		58: [
			0,
			.43056,
			0,
			0,
			.27778
		],
		59: [
			.19444,
			.43056,
			0,
			0,
			.27778
		],
		60: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		61: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		62: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		63: [
			0,
			.69444,
			0,
			0,
			.47222
		],
		64: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		65: [
			0,
			.68333,
			0,
			0,
			.75
		],
		66: [
			0,
			.68333,
			0,
			0,
			.70834
		],
		67: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		68: [
			0,
			.68333,
			0,
			0,
			.76389
		],
		69: [
			0,
			.68333,
			0,
			0,
			.68056
		],
		70: [
			0,
			.68333,
			0,
			0,
			.65278
		],
		71: [
			0,
			.68333,
			0,
			0,
			.78472
		],
		72: [
			0,
			.68333,
			0,
			0,
			.75
		],
		73: [
			0,
			.68333,
			0,
			0,
			.36111
		],
		74: [
			0,
			.68333,
			0,
			0,
			.51389
		],
		75: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		76: [
			0,
			.68333,
			0,
			0,
			.625
		],
		77: [
			0,
			.68333,
			0,
			0,
			.91667
		],
		78: [
			0,
			.68333,
			0,
			0,
			.75
		],
		79: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		80: [
			0,
			.68333,
			0,
			0,
			.68056
		],
		81: [
			.19444,
			.68333,
			0,
			0,
			.77778
		],
		82: [
			0,
			.68333,
			0,
			0,
			.73611
		],
		83: [
			0,
			.68333,
			0,
			0,
			.55556
		],
		84: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		85: [
			0,
			.68333,
			0,
			0,
			.75
		],
		86: [
			0,
			.68333,
			.01389,
			0,
			.75
		],
		87: [
			0,
			.68333,
			.01389,
			0,
			1.02778
		],
		88: [
			0,
			.68333,
			0,
			0,
			.75
		],
		89: [
			0,
			.68333,
			.025,
			0,
			.75
		],
		90: [
			0,
			.68333,
			0,
			0,
			.61111
		],
		91: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		92: [
			.25,
			.75,
			0,
			0,
			.5
		],
		93: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		94: [
			0,
			.69444,
			0,
			0,
			.5
		],
		95: [
			.31,
			.12056,
			.02778,
			0,
			.5
		],
		97: [
			0,
			.43056,
			0,
			0,
			.5
		],
		98: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		99: [
			0,
			.43056,
			0,
			0,
			.44445
		],
		100: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		101: [
			0,
			.43056,
			0,
			0,
			.44445
		],
		102: [
			0,
			.69444,
			.07778,
			0,
			.30556
		],
		103: [
			.19444,
			.43056,
			.01389,
			0,
			.5
		],
		104: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		105: [
			0,
			.66786,
			0,
			0,
			.27778
		],
		106: [
			.19444,
			.66786,
			0,
			0,
			.30556
		],
		107: [
			0,
			.69444,
			0,
			0,
			.52778
		],
		108: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		109: [
			0,
			.43056,
			0,
			0,
			.83334
		],
		110: [
			0,
			.43056,
			0,
			0,
			.55556
		],
		111: [
			0,
			.43056,
			0,
			0,
			.5
		],
		112: [
			.19444,
			.43056,
			0,
			0,
			.55556
		],
		113: [
			.19444,
			.43056,
			0,
			0,
			.52778
		],
		114: [
			0,
			.43056,
			0,
			0,
			.39167
		],
		115: [
			0,
			.43056,
			0,
			0,
			.39445
		],
		116: [
			0,
			.61508,
			0,
			0,
			.38889
		],
		117: [
			0,
			.43056,
			0,
			0,
			.55556
		],
		118: [
			0,
			.43056,
			.01389,
			0,
			.52778
		],
		119: [
			0,
			.43056,
			.01389,
			0,
			.72222
		],
		120: [
			0,
			.43056,
			0,
			0,
			.52778
		],
		121: [
			.19444,
			.43056,
			.01389,
			0,
			.52778
		],
		122: [
			0,
			.43056,
			0,
			0,
			.44445
		],
		123: [
			.25,
			.75,
			0,
			0,
			.5
		],
		124: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		125: [
			.25,
			.75,
			0,
			0,
			.5
		],
		126: [
			.35,
			.31786,
			0,
			0,
			.5
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		163: [
			0,
			.69444,
			0,
			0,
			.76909
		],
		167: [
			.19444,
			.69444,
			0,
			0,
			.44445
		],
		168: [
			0,
			.66786,
			0,
			0,
			.5
		],
		172: [
			0,
			.43056,
			0,
			0,
			.66667
		],
		176: [
			0,
			.69444,
			0,
			0,
			.75
		],
		177: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		182: [
			.19444,
			.69444,
			0,
			0,
			.61111
		],
		184: [
			.17014,
			0,
			0,
			0,
			.44445
		],
		198: [
			0,
			.68333,
			0,
			0,
			.90278
		],
		215: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		216: [
			.04861,
			.73194,
			0,
			0,
			.77778
		],
		223: [
			0,
			.69444,
			0,
			0,
			.5
		],
		230: [
			0,
			.43056,
			0,
			0,
			.72222
		],
		247: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		248: [
			.09722,
			.52778,
			0,
			0,
			.5
		],
		305: [
			0,
			.43056,
			0,
			0,
			.27778
		],
		338: [
			0,
			.68333,
			0,
			0,
			1.01389
		],
		339: [
			0,
			.43056,
			0,
			0,
			.77778
		],
		567: [
			.19444,
			.43056,
			0,
			0,
			.30556
		],
		710: [
			0,
			.69444,
			0,
			0,
			.5
		],
		711: [
			0,
			.62847,
			0,
			0,
			.5
		],
		713: [
			0,
			.56778,
			0,
			0,
			.5
		],
		714: [
			0,
			.69444,
			0,
			0,
			.5
		],
		715: [
			0,
			.69444,
			0,
			0,
			.5
		],
		728: [
			0,
			.69444,
			0,
			0,
			.5
		],
		729: [
			0,
			.66786,
			0,
			0,
			.27778
		],
		730: [
			0,
			.69444,
			0,
			0,
			.75
		],
		732: [
			0,
			.66786,
			0,
			0,
			.5
		],
		733: [
			0,
			.69444,
			0,
			0,
			.5
		],
		915: [
			0,
			.68333,
			0,
			0,
			.625
		],
		916: [
			0,
			.68333,
			0,
			0,
			.83334
		],
		920: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		923: [
			0,
			.68333,
			0,
			0,
			.69445
		],
		926: [
			0,
			.68333,
			0,
			0,
			.66667
		],
		928: [
			0,
			.68333,
			0,
			0,
			.75
		],
		931: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		933: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		934: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		936: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		937: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		8211: [
			0,
			.43056,
			.02778,
			0,
			.5
		],
		8212: [
			0,
			.43056,
			.02778,
			0,
			1
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.5
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.5
		],
		8224: [
			.19444,
			.69444,
			0,
			0,
			.44445
		],
		8225: [
			.19444,
			.69444,
			0,
			0,
			.44445
		],
		8230: [
			0,
			.123,
			0,
			0,
			1.172
		],
		8242: [
			0,
			.55556,
			0,
			0,
			.275
		],
		8407: [
			0,
			.71444,
			.15382,
			0,
			.5
		],
		8463: [
			0,
			.68889,
			0,
			0,
			.54028
		],
		8465: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		8467: [
			0,
			.69444,
			0,
			.11111,
			.41667
		],
		8472: [
			.19444,
			.43056,
			0,
			.11111,
			.63646
		],
		8476: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		8501: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		8592: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8593: [
			.19444,
			.69444,
			0,
			0,
			.5
		],
		8594: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8595: [
			.19444,
			.69444,
			0,
			0,
			.5
		],
		8596: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8597: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8598: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8599: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8600: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8601: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8614: [
			.011,
			.511,
			0,
			0,
			1
		],
		8617: [
			.011,
			.511,
			0,
			0,
			1.126
		],
		8618: [
			.011,
			.511,
			0,
			0,
			1.126
		],
		8636: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8637: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8640: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8641: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8652: [
			.011,
			.671,
			0,
			0,
			1
		],
		8656: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8657: [
			.19444,
			.69444,
			0,
			0,
			.61111
		],
		8658: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8659: [
			.19444,
			.69444,
			0,
			0,
			.61111
		],
		8660: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8661: [
			.25,
			.75,
			0,
			0,
			.61111
		],
		8704: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		8706: [
			0,
			.69444,
			.05556,
			.08334,
			.5309
		],
		8707: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		8709: [
			.05556,
			.75,
			0,
			0,
			.5
		],
		8711: [
			0,
			.68333,
			0,
			0,
			.83334
		],
		8712: [
			.0391,
			.5391,
			0,
			0,
			.66667
		],
		8715: [
			.0391,
			.5391,
			0,
			0,
			.66667
		],
		8722: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8723: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8725: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8726: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8727: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		8728: [
			-.05555,
			.44445,
			0,
			0,
			.5
		],
		8729: [
			-.05555,
			.44445,
			0,
			0,
			.5
		],
		8730: [
			.2,
			.8,
			0,
			0,
			.83334
		],
		8733: [
			0,
			.43056,
			0,
			0,
			.77778
		],
		8734: [
			0,
			.43056,
			0,
			0,
			1
		],
		8736: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8739: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		8741: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8743: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8744: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8745: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8746: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8747: [
			.19444,
			.69444,
			.11111,
			0,
			.41667
		],
		8764: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		8768: [
			.19444,
			.69444,
			0,
			0,
			.27778
		],
		8771: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8773: [
			-.022,
			.589,
			0,
			0,
			.778
		],
		8776: [
			-.01688,
			.48312,
			0,
			0,
			.77778
		],
		8781: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8784: [
			-.133,
			.673,
			0,
			0,
			.778
		],
		8801: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8804: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8805: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8810: [
			.0391,
			.5391,
			0,
			0,
			1
		],
		8811: [
			.0391,
			.5391,
			0,
			0,
			1
		],
		8826: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8827: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8834: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8835: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8838: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8839: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8846: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8849: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8850: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8851: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8852: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8853: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8854: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8855: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8856: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8857: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8866: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		8867: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		8868: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		8869: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		8872: [
			.249,
			.75,
			0,
			0,
			.867
		],
		8900: [
			-.05555,
			.44445,
			0,
			0,
			.5
		],
		8901: [
			-.05555,
			.44445,
			0,
			0,
			.27778
		],
		8902: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		8904: [
			.005,
			.505,
			0,
			0,
			.9
		],
		8942: [
			.03,
			.903,
			0,
			0,
			.278
		],
		8943: [
			-.19,
			.313,
			0,
			0,
			1.172
		],
		8945: [
			-.1,
			.823,
			0,
			0,
			1.282
		],
		8968: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8969: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8970: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8971: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8994: [
			-.14236,
			.35764,
			0,
			0,
			1
		],
		8995: [
			-.14236,
			.35764,
			0,
			0,
			1
		],
		9136: [
			.244,
			.744,
			0,
			0,
			.412
		],
		9137: [
			.244,
			.745,
			0,
			0,
			.412
		],
		9651: [
			.19444,
			.69444,
			0,
			0,
			.88889
		],
		9657: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		9661: [
			.19444,
			.69444,
			0,
			0,
			.88889
		],
		9667: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		9711: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		9824: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9825: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9826: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9827: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9837: [
			0,
			.75,
			0,
			0,
			.38889
		],
		9838: [
			.19444,
			.69444,
			0,
			0,
			.38889
		],
		9839: [
			.19444,
			.69444,
			0,
			0,
			.38889
		],
		10216: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		10217: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		10222: [
			.244,
			.744,
			0,
			0,
			.412
		],
		10223: [
			.244,
			.745,
			0,
			0,
			.412
		],
		10229: [
			.011,
			.511,
			0,
			0,
			1.609
		],
		10230: [
			.011,
			.511,
			0,
			0,
			1.638
		],
		10231: [
			.011,
			.511,
			0,
			0,
			1.859
		],
		10232: [
			.024,
			.525,
			0,
			0,
			1.609
		],
		10233: [
			.024,
			.525,
			0,
			0,
			1.638
		],
		10234: [
			.024,
			.525,
			0,
			0,
			1.858
		],
		10236: [
			.011,
			.511,
			0,
			0,
			1.638
		],
		10815: [
			0,
			.68333,
			0,
			0,
			.75
		],
		10927: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		10928: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		57376: [
			.19444,
			.69444,
			0,
			0,
			0
		]
	},
	"Math-BoldItalic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		48: [
			0,
			.44444,
			0,
			0,
			.575
		],
		49: [
			0,
			.44444,
			0,
			0,
			.575
		],
		50: [
			0,
			.44444,
			0,
			0,
			.575
		],
		51: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		52: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		53: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		54: [
			0,
			.64444,
			0,
			0,
			.575
		],
		55: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		56: [
			0,
			.64444,
			0,
			0,
			.575
		],
		57: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		65: [
			0,
			.68611,
			0,
			0,
			.86944
		],
		66: [
			0,
			.68611,
			.04835,
			0,
			.8664
		],
		67: [
			0,
			.68611,
			.06979,
			0,
			.81694
		],
		68: [
			0,
			.68611,
			.03194,
			0,
			.93812
		],
		69: [
			0,
			.68611,
			.05451,
			0,
			.81007
		],
		70: [
			0,
			.68611,
			.15972,
			0,
			.68889
		],
		71: [
			0,
			.68611,
			0,
			0,
			.88673
		],
		72: [
			0,
			.68611,
			.08229,
			0,
			.98229
		],
		73: [
			0,
			.68611,
			.07778,
			0,
			.51111
		],
		74: [
			0,
			.68611,
			.10069,
			0,
			.63125
		],
		75: [
			0,
			.68611,
			.06979,
			0,
			.97118
		],
		76: [
			0,
			.68611,
			0,
			0,
			.75555
		],
		77: [
			0,
			.68611,
			.11424,
			0,
			1.14201
		],
		78: [
			0,
			.68611,
			.11424,
			0,
			.95034
		],
		79: [
			0,
			.68611,
			.03194,
			0,
			.83666
		],
		80: [
			0,
			.68611,
			.15972,
			0,
			.72309
		],
		81: [
			.19444,
			.68611,
			0,
			0,
			.86861
		],
		82: [
			0,
			.68611,
			.00421,
			0,
			.87235
		],
		83: [
			0,
			.68611,
			.05382,
			0,
			.69271
		],
		84: [
			0,
			.68611,
			.15972,
			0,
			.63663
		],
		85: [
			0,
			.68611,
			.11424,
			0,
			.80027
		],
		86: [
			0,
			.68611,
			.25555,
			0,
			.67778
		],
		87: [
			0,
			.68611,
			.15972,
			0,
			1.09305
		],
		88: [
			0,
			.68611,
			.07778,
			0,
			.94722
		],
		89: [
			0,
			.68611,
			.25555,
			0,
			.67458
		],
		90: [
			0,
			.68611,
			.06979,
			0,
			.77257
		],
		97: [
			0,
			.44444,
			0,
			0,
			.63287
		],
		98: [
			0,
			.69444,
			0,
			0,
			.52083
		],
		99: [
			0,
			.44444,
			0,
			0,
			.51342
		],
		100: [
			0,
			.69444,
			0,
			0,
			.60972
		],
		101: [
			0,
			.44444,
			0,
			0,
			.55361
		],
		102: [
			.19444,
			.69444,
			.11042,
			0,
			.56806
		],
		103: [
			.19444,
			.44444,
			.03704,
			0,
			.5449
		],
		104: [
			0,
			.69444,
			0,
			0,
			.66759
		],
		105: [
			0,
			.69326,
			0,
			0,
			.4048
		],
		106: [
			.19444,
			.69326,
			.0622,
			0,
			.47083
		],
		107: [
			0,
			.69444,
			.01852,
			0,
			.6037
		],
		108: [
			0,
			.69444,
			.0088,
			0,
			.34815
		],
		109: [
			0,
			.44444,
			0,
			0,
			1.0324
		],
		110: [
			0,
			.44444,
			0,
			0,
			.71296
		],
		111: [
			0,
			.44444,
			0,
			0,
			.58472
		],
		112: [
			.19444,
			.44444,
			0,
			0,
			.60092
		],
		113: [
			.19444,
			.44444,
			.03704,
			0,
			.54213
		],
		114: [
			0,
			.44444,
			.03194,
			0,
			.5287
		],
		115: [
			0,
			.44444,
			0,
			0,
			.53125
		],
		116: [
			0,
			.63492,
			0,
			0,
			.41528
		],
		117: [
			0,
			.44444,
			0,
			0,
			.68102
		],
		118: [
			0,
			.44444,
			.03704,
			0,
			.56666
		],
		119: [
			0,
			.44444,
			.02778,
			0,
			.83148
		],
		120: [
			0,
			.44444,
			0,
			0,
			.65903
		],
		121: [
			.19444,
			.44444,
			.03704,
			0,
			.59028
		],
		122: [
			0,
			.44444,
			.04213,
			0,
			.55509
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		915: [
			0,
			.68611,
			.15972,
			0,
			.65694
		],
		916: [
			0,
			.68611,
			0,
			0,
			.95833
		],
		920: [
			0,
			.68611,
			.03194,
			0,
			.86722
		],
		923: [
			0,
			.68611,
			0,
			0,
			.80555
		],
		926: [
			0,
			.68611,
			.07458,
			0,
			.84125
		],
		928: [
			0,
			.68611,
			.08229,
			0,
			.98229
		],
		931: [
			0,
			.68611,
			.05451,
			0,
			.88507
		],
		933: [
			0,
			.68611,
			.15972,
			0,
			.67083
		],
		934: [
			0,
			.68611,
			0,
			0,
			.76666
		],
		936: [
			0,
			.68611,
			.11653,
			0,
			.71402
		],
		937: [
			0,
			.68611,
			.04835,
			0,
			.8789
		],
		945: [
			0,
			.44444,
			0,
			0,
			.76064
		],
		946: [
			.19444,
			.69444,
			.03403,
			0,
			.65972
		],
		947: [
			.19444,
			.44444,
			.06389,
			0,
			.59003
		],
		948: [
			0,
			.69444,
			.03819,
			0,
			.52222
		],
		949: [
			0,
			.44444,
			0,
			0,
			.52882
		],
		950: [
			.19444,
			.69444,
			.06215,
			0,
			.50833
		],
		951: [
			.19444,
			.44444,
			.03704,
			0,
			.6
		],
		952: [
			0,
			.69444,
			.03194,
			0,
			.5618
		],
		953: [
			0,
			.44444,
			0,
			0,
			.41204
		],
		954: [
			0,
			.44444,
			0,
			0,
			.66759
		],
		955: [
			0,
			.69444,
			0,
			0,
			.67083
		],
		956: [
			.19444,
			.44444,
			0,
			0,
			.70787
		],
		957: [
			0,
			.44444,
			.06898,
			0,
			.57685
		],
		958: [
			.19444,
			.69444,
			.03021,
			0,
			.50833
		],
		959: [
			0,
			.44444,
			0,
			0,
			.58472
		],
		960: [
			0,
			.44444,
			.03704,
			0,
			.68241
		],
		961: [
			.19444,
			.44444,
			0,
			0,
			.6118
		],
		962: [
			.09722,
			.44444,
			.07917,
			0,
			.42361
		],
		963: [
			0,
			.44444,
			.03704,
			0,
			.68588
		],
		964: [
			0,
			.44444,
			.13472,
			0,
			.52083
		],
		965: [
			0,
			.44444,
			.03704,
			0,
			.63055
		],
		966: [
			.19444,
			.44444,
			0,
			0,
			.74722
		],
		967: [
			.19444,
			.44444,
			0,
			0,
			.71805
		],
		968: [
			.19444,
			.69444,
			.03704,
			0,
			.75833
		],
		969: [
			0,
			.44444,
			.03704,
			0,
			.71782
		],
		977: [
			0,
			.69444,
			0,
			0,
			.69155
		],
		981: [
			.19444,
			.69444,
			0,
			0,
			.7125
		],
		982: [
			0,
			.44444,
			.03194,
			0,
			.975
		],
		1009: [
			.19444,
			.44444,
			0,
			0,
			.6118
		],
		1013: [
			0,
			.44444,
			0,
			0,
			.48333
		],
		57649: [
			0,
			.44444,
			0,
			0,
			.39352
		],
		57911: [
			.19444,
			.44444,
			0,
			0,
			.43889
		]
	},
	"Math-Italic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		48: [
			0,
			.43056,
			0,
			0,
			.5
		],
		49: [
			0,
			.43056,
			0,
			0,
			.5
		],
		50: [
			0,
			.43056,
			0,
			0,
			.5
		],
		51: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		52: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		53: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		54: [
			0,
			.64444,
			0,
			0,
			.5
		],
		55: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		56: [
			0,
			.64444,
			0,
			0,
			.5
		],
		57: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		65: [
			0,
			.68333,
			0,
			.13889,
			.75
		],
		66: [
			0,
			.68333,
			.05017,
			.08334,
			.75851
		],
		67: [
			0,
			.68333,
			.07153,
			.08334,
			.71472
		],
		68: [
			0,
			.68333,
			.02778,
			.05556,
			.82792
		],
		69: [
			0,
			.68333,
			.05764,
			.08334,
			.7382
		],
		70: [
			0,
			.68333,
			.13889,
			.08334,
			.64306
		],
		71: [
			0,
			.68333,
			0,
			.08334,
			.78625
		],
		72: [
			0,
			.68333,
			.08125,
			.05556,
			.83125
		],
		73: [
			0,
			.68333,
			.07847,
			.11111,
			.43958
		],
		74: [
			0,
			.68333,
			.09618,
			.16667,
			.55451
		],
		75: [
			0,
			.68333,
			.07153,
			.05556,
			.84931
		],
		76: [
			0,
			.68333,
			0,
			.02778,
			.68056
		],
		77: [
			0,
			.68333,
			.10903,
			.08334,
			.97014
		],
		78: [
			0,
			.68333,
			.10903,
			.08334,
			.80347
		],
		79: [
			0,
			.68333,
			.02778,
			.08334,
			.76278
		],
		80: [
			0,
			.68333,
			.13889,
			.08334,
			.64201
		],
		81: [
			.19444,
			.68333,
			0,
			.08334,
			.79056
		],
		82: [
			0,
			.68333,
			.00773,
			.08334,
			.75929
		],
		83: [
			0,
			.68333,
			.05764,
			.08334,
			.6132
		],
		84: [
			0,
			.68333,
			.13889,
			.08334,
			.58438
		],
		85: [
			0,
			.68333,
			.10903,
			.02778,
			.68278
		],
		86: [
			0,
			.68333,
			.22222,
			0,
			.58333
		],
		87: [
			0,
			.68333,
			.13889,
			0,
			.94445
		],
		88: [
			0,
			.68333,
			.07847,
			.08334,
			.82847
		],
		89: [
			0,
			.68333,
			.22222,
			0,
			.58056
		],
		90: [
			0,
			.68333,
			.07153,
			.08334,
			.68264
		],
		97: [
			0,
			.43056,
			0,
			0,
			.52859
		],
		98: [
			0,
			.69444,
			0,
			0,
			.42917
		],
		99: [
			0,
			.43056,
			0,
			.05556,
			.43276
		],
		100: [
			0,
			.69444,
			0,
			.16667,
			.52049
		],
		101: [
			0,
			.43056,
			0,
			.05556,
			.46563
		],
		102: [
			.19444,
			.69444,
			.10764,
			.16667,
			.48959
		],
		103: [
			.19444,
			.43056,
			.03588,
			.02778,
			.47697
		],
		104: [
			0,
			.69444,
			0,
			0,
			.57616
		],
		105: [
			0,
			.65952,
			0,
			0,
			.34451
		],
		106: [
			.19444,
			.65952,
			.05724,
			0,
			.41181
		],
		107: [
			0,
			.69444,
			.03148,
			0,
			.5206
		],
		108: [
			0,
			.69444,
			.01968,
			.08334,
			.29838
		],
		109: [
			0,
			.43056,
			0,
			0,
			.87801
		],
		110: [
			0,
			.43056,
			0,
			0,
			.60023
		],
		111: [
			0,
			.43056,
			0,
			.05556,
			.48472
		],
		112: [
			.19444,
			.43056,
			0,
			.08334,
			.50313
		],
		113: [
			.19444,
			.43056,
			.03588,
			.08334,
			.44641
		],
		114: [
			0,
			.43056,
			.02778,
			.05556,
			.45116
		],
		115: [
			0,
			.43056,
			0,
			.05556,
			.46875
		],
		116: [
			0,
			.61508,
			0,
			.08334,
			.36111
		],
		117: [
			0,
			.43056,
			0,
			.02778,
			.57246
		],
		118: [
			0,
			.43056,
			.03588,
			.02778,
			.48472
		],
		119: [
			0,
			.43056,
			.02691,
			.08334,
			.71592
		],
		120: [
			0,
			.43056,
			0,
			.02778,
			.57153
		],
		121: [
			.19444,
			.43056,
			.03588,
			.05556,
			.49028
		],
		122: [
			0,
			.43056,
			.04398,
			.05556,
			.46505
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		915: [
			0,
			.68333,
			.13889,
			.08334,
			.61528
		],
		916: [
			0,
			.68333,
			0,
			.16667,
			.83334
		],
		920: [
			0,
			.68333,
			.02778,
			.08334,
			.76278
		],
		923: [
			0,
			.68333,
			0,
			.16667,
			.69445
		],
		926: [
			0,
			.68333,
			.07569,
			.08334,
			.74236
		],
		928: [
			0,
			.68333,
			.08125,
			.05556,
			.83125
		],
		931: [
			0,
			.68333,
			.05764,
			.08334,
			.77986
		],
		933: [
			0,
			.68333,
			.13889,
			.05556,
			.58333
		],
		934: [
			0,
			.68333,
			0,
			.08334,
			.66667
		],
		936: [
			0,
			.68333,
			.11,
			.05556,
			.61222
		],
		937: [
			0,
			.68333,
			.05017,
			.08334,
			.7724
		],
		945: [
			0,
			.43056,
			.0037,
			.02778,
			.6397
		],
		946: [
			.19444,
			.69444,
			.05278,
			.08334,
			.56563
		],
		947: [
			.19444,
			.43056,
			.05556,
			0,
			.51773
		],
		948: [
			0,
			.69444,
			.03785,
			.05556,
			.44444
		],
		949: [
			0,
			.43056,
			0,
			.08334,
			.46632
		],
		950: [
			.19444,
			.69444,
			.07378,
			.08334,
			.4375
		],
		951: [
			.19444,
			.43056,
			.03588,
			.05556,
			.49653
		],
		952: [
			0,
			.69444,
			.02778,
			.08334,
			.46944
		],
		953: [
			0,
			.43056,
			0,
			.05556,
			.35394
		],
		954: [
			0,
			.43056,
			0,
			0,
			.57616
		],
		955: [
			0,
			.69444,
			0,
			0,
			.58334
		],
		956: [
			.19444,
			.43056,
			0,
			.02778,
			.60255
		],
		957: [
			0,
			.43056,
			.06366,
			.02778,
			.49398
		],
		958: [
			.19444,
			.69444,
			.04601,
			.11111,
			.4375
		],
		959: [
			0,
			.43056,
			0,
			.05556,
			.48472
		],
		960: [
			0,
			.43056,
			.03588,
			0,
			.57003
		],
		961: [
			.19444,
			.43056,
			0,
			.08334,
			.51702
		],
		962: [
			.09722,
			.43056,
			.07986,
			.08334,
			.36285
		],
		963: [
			0,
			.43056,
			.03588,
			0,
			.57141
		],
		964: [
			0,
			.43056,
			.1132,
			.02778,
			.43715
		],
		965: [
			0,
			.43056,
			.03588,
			.02778,
			.54028
		],
		966: [
			.19444,
			.43056,
			0,
			.08334,
			.65417
		],
		967: [
			.19444,
			.43056,
			0,
			.05556,
			.62569
		],
		968: [
			.19444,
			.69444,
			.03588,
			.11111,
			.65139
		],
		969: [
			0,
			.43056,
			.03588,
			0,
			.62245
		],
		977: [
			0,
			.69444,
			0,
			.08334,
			.59144
		],
		981: [
			.19444,
			.69444,
			0,
			.08334,
			.59583
		],
		982: [
			0,
			.43056,
			.02778,
			0,
			.82813
		],
		1009: [
			.19444,
			.43056,
			0,
			.08334,
			.51702
		],
		1013: [
			0,
			.43056,
			0,
			.05556,
			.4059
		],
		57649: [
			0,
			.43056,
			0,
			.02778,
			.32246
		],
		57911: [
			.19444,
			.43056,
			0,
			.08334,
			.38403
		]
	},
	"SansSerif-Bold": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.36667
		],
		34: [
			0,
			.69444,
			0,
			0,
			.55834
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.91667
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.55
		],
		37: [
			.05556,
			.75,
			0,
			0,
			1.02912
		],
		38: [
			0,
			.69444,
			0,
			0,
			.83056
		],
		39: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		40: [
			.25,
			.75,
			0,
			0,
			.42778
		],
		41: [
			.25,
			.75,
			0,
			0,
			.42778
		],
		42: [
			0,
			.75,
			0,
			0,
			.55
		],
		43: [
			.11667,
			.61667,
			0,
			0,
			.85556
		],
		44: [
			.10556,
			.13056,
			0,
			0,
			.30556
		],
		45: [
			0,
			.45833,
			0,
			0,
			.36667
		],
		46: [
			0,
			.13056,
			0,
			0,
			.30556
		],
		47: [
			.25,
			.75,
			0,
			0,
			.55
		],
		48: [
			0,
			.69444,
			0,
			0,
			.55
		],
		49: [
			0,
			.69444,
			0,
			0,
			.55
		],
		50: [
			0,
			.69444,
			0,
			0,
			.55
		],
		51: [
			0,
			.69444,
			0,
			0,
			.55
		],
		52: [
			0,
			.69444,
			0,
			0,
			.55
		],
		53: [
			0,
			.69444,
			0,
			0,
			.55
		],
		54: [
			0,
			.69444,
			0,
			0,
			.55
		],
		55: [
			0,
			.69444,
			0,
			0,
			.55
		],
		56: [
			0,
			.69444,
			0,
			0,
			.55
		],
		57: [
			0,
			.69444,
			0,
			0,
			.55
		],
		58: [
			0,
			.45833,
			0,
			0,
			.30556
		],
		59: [
			.10556,
			.45833,
			0,
			0,
			.30556
		],
		61: [
			-.09375,
			.40625,
			0,
			0,
			.85556
		],
		63: [
			0,
			.69444,
			0,
			0,
			.51945
		],
		64: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		65: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		66: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		67: [
			0,
			.69444,
			0,
			0,
			.70278
		],
		68: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		69: [
			0,
			.69444,
			0,
			0,
			.64167
		],
		70: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		71: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		72: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		73: [
			0,
			.69444,
			0,
			0,
			.33056
		],
		74: [
			0,
			.69444,
			0,
			0,
			.51945
		],
		75: [
			0,
			.69444,
			0,
			0,
			.76389
		],
		76: [
			0,
			.69444,
			0,
			0,
			.58056
		],
		77: [
			0,
			.69444,
			0,
			0,
			.97778
		],
		78: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		79: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		80: [
			0,
			.69444,
			0,
			0,
			.70278
		],
		81: [
			.10556,
			.69444,
			0,
			0,
			.79445
		],
		82: [
			0,
			.69444,
			0,
			0,
			.70278
		],
		83: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		84: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		85: [
			0,
			.69444,
			0,
			0,
			.76389
		],
		86: [
			0,
			.69444,
			.01528,
			0,
			.73334
		],
		87: [
			0,
			.69444,
			.01528,
			0,
			1.03889
		],
		88: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		89: [
			0,
			.69444,
			.0275,
			0,
			.73334
		],
		90: [
			0,
			.69444,
			0,
			0,
			.67223
		],
		91: [
			.25,
			.75,
			0,
			0,
			.34306
		],
		93: [
			.25,
			.75,
			0,
			0,
			.34306
		],
		94: [
			0,
			.69444,
			0,
			0,
			.55
		],
		95: [
			.35,
			.10833,
			.03056,
			0,
			.55
		],
		97: [
			0,
			.45833,
			0,
			0,
			.525
		],
		98: [
			0,
			.69444,
			0,
			0,
			.56111
		],
		99: [
			0,
			.45833,
			0,
			0,
			.48889
		],
		100: [
			0,
			.69444,
			0,
			0,
			.56111
		],
		101: [
			0,
			.45833,
			0,
			0,
			.51111
		],
		102: [
			0,
			.69444,
			.07639,
			0,
			.33611
		],
		103: [
			.19444,
			.45833,
			.01528,
			0,
			.55
		],
		104: [
			0,
			.69444,
			0,
			0,
			.56111
		],
		105: [
			0,
			.69444,
			0,
			0,
			.25556
		],
		106: [
			.19444,
			.69444,
			0,
			0,
			.28611
		],
		107: [
			0,
			.69444,
			0,
			0,
			.53056
		],
		108: [
			0,
			.69444,
			0,
			0,
			.25556
		],
		109: [
			0,
			.45833,
			0,
			0,
			.86667
		],
		110: [
			0,
			.45833,
			0,
			0,
			.56111
		],
		111: [
			0,
			.45833,
			0,
			0,
			.55
		],
		112: [
			.19444,
			.45833,
			0,
			0,
			.56111
		],
		113: [
			.19444,
			.45833,
			0,
			0,
			.56111
		],
		114: [
			0,
			.45833,
			.01528,
			0,
			.37222
		],
		115: [
			0,
			.45833,
			0,
			0,
			.42167
		],
		116: [
			0,
			.58929,
			0,
			0,
			.40417
		],
		117: [
			0,
			.45833,
			0,
			0,
			.56111
		],
		118: [
			0,
			.45833,
			.01528,
			0,
			.5
		],
		119: [
			0,
			.45833,
			.01528,
			0,
			.74445
		],
		120: [
			0,
			.45833,
			0,
			0,
			.5
		],
		121: [
			.19444,
			.45833,
			.01528,
			0,
			.5
		],
		122: [
			0,
			.45833,
			0,
			0,
			.47639
		],
		126: [
			.35,
			.34444,
			0,
			0,
			.55
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.69444,
			0,
			0,
			.55
		],
		176: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		180: [
			0,
			.69444,
			0,
			0,
			.55
		],
		184: [
			.17014,
			0,
			0,
			0,
			.48889
		],
		305: [
			0,
			.45833,
			0,
			0,
			.25556
		],
		567: [
			.19444,
			.45833,
			0,
			0,
			.28611
		],
		710: [
			0,
			.69444,
			0,
			0,
			.55
		],
		711: [
			0,
			.63542,
			0,
			0,
			.55
		],
		713: [
			0,
			.63778,
			0,
			0,
			.55
		],
		728: [
			0,
			.69444,
			0,
			0,
			.55
		],
		729: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		730: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		732: [
			0,
			.69444,
			0,
			0,
			.55
		],
		733: [
			0,
			.69444,
			0,
			0,
			.55
		],
		915: [
			0,
			.69444,
			0,
			0,
			.58056
		],
		916: [
			0,
			.69444,
			0,
			0,
			.91667
		],
		920: [
			0,
			.69444,
			0,
			0,
			.85556
		],
		923: [
			0,
			.69444,
			0,
			0,
			.67223
		],
		926: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		928: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		931: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		933: [
			0,
			.69444,
			0,
			0,
			.85556
		],
		934: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		936: [
			0,
			.69444,
			0,
			0,
			.85556
		],
		937: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		8211: [
			0,
			.45833,
			.03056,
			0,
			.55
		],
		8212: [
			0,
			.45833,
			.03056,
			0,
			1.10001
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.55834
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.55834
		]
	},
	"SansSerif-Italic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			.05733,
			0,
			.31945
		],
		34: [
			0,
			.69444,
			.00316,
			0,
			.5
		],
		35: [
			.19444,
			.69444,
			.05087,
			0,
			.83334
		],
		36: [
			.05556,
			.75,
			.11156,
			0,
			.5
		],
		37: [
			.05556,
			.75,
			.03126,
			0,
			.83334
		],
		38: [
			0,
			.69444,
			.03058,
			0,
			.75834
		],
		39: [
			0,
			.69444,
			.07816,
			0,
			.27778
		],
		40: [
			.25,
			.75,
			.13164,
			0,
			.38889
		],
		41: [
			.25,
			.75,
			.02536,
			0,
			.38889
		],
		42: [
			0,
			.75,
			.11775,
			0,
			.5
		],
		43: [
			.08333,
			.58333,
			.02536,
			0,
			.77778
		],
		44: [
			.125,
			.08333,
			0,
			0,
			.27778
		],
		45: [
			0,
			.44444,
			.01946,
			0,
			.33333
		],
		46: [
			0,
			.08333,
			0,
			0,
			.27778
		],
		47: [
			.25,
			.75,
			.13164,
			0,
			.5
		],
		48: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		49: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		50: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		51: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		52: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		53: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		54: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		55: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		56: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		57: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		58: [
			0,
			.44444,
			.02502,
			0,
			.27778
		],
		59: [
			.125,
			.44444,
			.02502,
			0,
			.27778
		],
		61: [
			-.13,
			.37,
			.05087,
			0,
			.77778
		],
		63: [
			0,
			.69444,
			.11809,
			0,
			.47222
		],
		64: [
			0,
			.69444,
			.07555,
			0,
			.66667
		],
		65: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		66: [
			0,
			.69444,
			.08293,
			0,
			.66667
		],
		67: [
			0,
			.69444,
			.11983,
			0,
			.63889
		],
		68: [
			0,
			.69444,
			.07555,
			0,
			.72223
		],
		69: [
			0,
			.69444,
			.11983,
			0,
			.59722
		],
		70: [
			0,
			.69444,
			.13372,
			0,
			.56945
		],
		71: [
			0,
			.69444,
			.11983,
			0,
			.66667
		],
		72: [
			0,
			.69444,
			.08094,
			0,
			.70834
		],
		73: [
			0,
			.69444,
			.13372,
			0,
			.27778
		],
		74: [
			0,
			.69444,
			.08094,
			0,
			.47222
		],
		75: [
			0,
			.69444,
			.11983,
			0,
			.69445
		],
		76: [
			0,
			.69444,
			0,
			0,
			.54167
		],
		77: [
			0,
			.69444,
			.08094,
			0,
			.875
		],
		78: [
			0,
			.69444,
			.08094,
			0,
			.70834
		],
		79: [
			0,
			.69444,
			.07555,
			0,
			.73611
		],
		80: [
			0,
			.69444,
			.08293,
			0,
			.63889
		],
		81: [
			.125,
			.69444,
			.07555,
			0,
			.73611
		],
		82: [
			0,
			.69444,
			.08293,
			0,
			.64584
		],
		83: [
			0,
			.69444,
			.09205,
			0,
			.55556
		],
		84: [
			0,
			.69444,
			.13372,
			0,
			.68056
		],
		85: [
			0,
			.69444,
			.08094,
			0,
			.6875
		],
		86: [
			0,
			.69444,
			.1615,
			0,
			.66667
		],
		87: [
			0,
			.69444,
			.1615,
			0,
			.94445
		],
		88: [
			0,
			.69444,
			.13372,
			0,
			.66667
		],
		89: [
			0,
			.69444,
			.17261,
			0,
			.66667
		],
		90: [
			0,
			.69444,
			.11983,
			0,
			.61111
		],
		91: [
			.25,
			.75,
			.15942,
			0,
			.28889
		],
		93: [
			.25,
			.75,
			.08719,
			0,
			.28889
		],
		94: [
			0,
			.69444,
			.0799,
			0,
			.5
		],
		95: [
			.35,
			.09444,
			.08616,
			0,
			.5
		],
		97: [
			0,
			.44444,
			.00981,
			0,
			.48056
		],
		98: [
			0,
			.69444,
			.03057,
			0,
			.51667
		],
		99: [
			0,
			.44444,
			.08336,
			0,
			.44445
		],
		100: [
			0,
			.69444,
			.09483,
			0,
			.51667
		],
		101: [
			0,
			.44444,
			.06778,
			0,
			.44445
		],
		102: [
			0,
			.69444,
			.21705,
			0,
			.30556
		],
		103: [
			.19444,
			.44444,
			.10836,
			0,
			.5
		],
		104: [
			0,
			.69444,
			.01778,
			0,
			.51667
		],
		105: [
			0,
			.67937,
			.09718,
			0,
			.23889
		],
		106: [
			.19444,
			.67937,
			.09162,
			0,
			.26667
		],
		107: [
			0,
			.69444,
			.08336,
			0,
			.48889
		],
		108: [
			0,
			.69444,
			.09483,
			0,
			.23889
		],
		109: [
			0,
			.44444,
			.01778,
			0,
			.79445
		],
		110: [
			0,
			.44444,
			.01778,
			0,
			.51667
		],
		111: [
			0,
			.44444,
			.06613,
			0,
			.5
		],
		112: [
			.19444,
			.44444,
			.0389,
			0,
			.51667
		],
		113: [
			.19444,
			.44444,
			.04169,
			0,
			.51667
		],
		114: [
			0,
			.44444,
			.10836,
			0,
			.34167
		],
		115: [
			0,
			.44444,
			.0778,
			0,
			.38333
		],
		116: [
			0,
			.57143,
			.07225,
			0,
			.36111
		],
		117: [
			0,
			.44444,
			.04169,
			0,
			.51667
		],
		118: [
			0,
			.44444,
			.10836,
			0,
			.46111
		],
		119: [
			0,
			.44444,
			.10836,
			0,
			.68334
		],
		120: [
			0,
			.44444,
			.09169,
			0,
			.46111
		],
		121: [
			.19444,
			.44444,
			.10836,
			0,
			.46111
		],
		122: [
			0,
			.44444,
			.08752,
			0,
			.43472
		],
		126: [
			.35,
			.32659,
			.08826,
			0,
			.5
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.67937,
			.06385,
			0,
			.5
		],
		176: [
			0,
			.69444,
			0,
			0,
			.73752
		],
		184: [
			.17014,
			0,
			0,
			0,
			.44445
		],
		305: [
			0,
			.44444,
			.04169,
			0,
			.23889
		],
		567: [
			.19444,
			.44444,
			.04169,
			0,
			.26667
		],
		710: [
			0,
			.69444,
			.0799,
			0,
			.5
		],
		711: [
			0,
			.63194,
			.08432,
			0,
			.5
		],
		713: [
			0,
			.60889,
			.08776,
			0,
			.5
		],
		714: [
			0,
			.69444,
			.09205,
			0,
			.5
		],
		715: [
			0,
			.69444,
			0,
			0,
			.5
		],
		728: [
			0,
			.69444,
			.09483,
			0,
			.5
		],
		729: [
			0,
			.67937,
			.07774,
			0,
			.27778
		],
		730: [
			0,
			.69444,
			0,
			0,
			.73752
		],
		732: [
			0,
			.67659,
			.08826,
			0,
			.5
		],
		733: [
			0,
			.69444,
			.09205,
			0,
			.5
		],
		915: [
			0,
			.69444,
			.13372,
			0,
			.54167
		],
		916: [
			0,
			.69444,
			0,
			0,
			.83334
		],
		920: [
			0,
			.69444,
			.07555,
			0,
			.77778
		],
		923: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		926: [
			0,
			.69444,
			.12816,
			0,
			.66667
		],
		928: [
			0,
			.69444,
			.08094,
			0,
			.70834
		],
		931: [
			0,
			.69444,
			.11983,
			0,
			.72222
		],
		933: [
			0,
			.69444,
			.09031,
			0,
			.77778
		],
		934: [
			0,
			.69444,
			.04603,
			0,
			.72222
		],
		936: [
			0,
			.69444,
			.09031,
			0,
			.77778
		],
		937: [
			0,
			.69444,
			.08293,
			0,
			.72222
		],
		8211: [
			0,
			.44444,
			.08616,
			0,
			.5
		],
		8212: [
			0,
			.44444,
			.08616,
			0,
			1
		],
		8216: [
			0,
			.69444,
			.07816,
			0,
			.27778
		],
		8217: [
			0,
			.69444,
			.07816,
			0,
			.27778
		],
		8220: [
			0,
			.69444,
			.14205,
			0,
			.5
		],
		8221: [
			0,
			.69444,
			.00316,
			0,
			.5
		]
	},
	"SansSerif-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.31945
		],
		34: [
			0,
			.69444,
			0,
			0,
			.5
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.83334
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.5
		],
		37: [
			.05556,
			.75,
			0,
			0,
			.83334
		],
		38: [
			0,
			.69444,
			0,
			0,
			.75834
		],
		39: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		40: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		41: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		42: [
			0,
			.75,
			0,
			0,
			.5
		],
		43: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		44: [
			.125,
			.08333,
			0,
			0,
			.27778
		],
		45: [
			0,
			.44444,
			0,
			0,
			.33333
		],
		46: [
			0,
			.08333,
			0,
			0,
			.27778
		],
		47: [
			.25,
			.75,
			0,
			0,
			.5
		],
		48: [
			0,
			.65556,
			0,
			0,
			.5
		],
		49: [
			0,
			.65556,
			0,
			0,
			.5
		],
		50: [
			0,
			.65556,
			0,
			0,
			.5
		],
		51: [
			0,
			.65556,
			0,
			0,
			.5
		],
		52: [
			0,
			.65556,
			0,
			0,
			.5
		],
		53: [
			0,
			.65556,
			0,
			0,
			.5
		],
		54: [
			0,
			.65556,
			0,
			0,
			.5
		],
		55: [
			0,
			.65556,
			0,
			0,
			.5
		],
		56: [
			0,
			.65556,
			0,
			0,
			.5
		],
		57: [
			0,
			.65556,
			0,
			0,
			.5
		],
		58: [
			0,
			.44444,
			0,
			0,
			.27778
		],
		59: [
			.125,
			.44444,
			0,
			0,
			.27778
		],
		61: [
			-.13,
			.37,
			0,
			0,
			.77778
		],
		63: [
			0,
			.69444,
			0,
			0,
			.47222
		],
		64: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		65: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		66: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		67: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		68: [
			0,
			.69444,
			0,
			0,
			.72223
		],
		69: [
			0,
			.69444,
			0,
			0,
			.59722
		],
		70: [
			0,
			.69444,
			0,
			0,
			.56945
		],
		71: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		72: [
			0,
			.69444,
			0,
			0,
			.70834
		],
		73: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		74: [
			0,
			.69444,
			0,
			0,
			.47222
		],
		75: [
			0,
			.69444,
			0,
			0,
			.69445
		],
		76: [
			0,
			.69444,
			0,
			0,
			.54167
		],
		77: [
			0,
			.69444,
			0,
			0,
			.875
		],
		78: [
			0,
			.69444,
			0,
			0,
			.70834
		],
		79: [
			0,
			.69444,
			0,
			0,
			.73611
		],
		80: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		81: [
			.125,
			.69444,
			0,
			0,
			.73611
		],
		82: [
			0,
			.69444,
			0,
			0,
			.64584
		],
		83: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		84: [
			0,
			.69444,
			0,
			0,
			.68056
		],
		85: [
			0,
			.69444,
			0,
			0,
			.6875
		],
		86: [
			0,
			.69444,
			.01389,
			0,
			.66667
		],
		87: [
			0,
			.69444,
			.01389,
			0,
			.94445
		],
		88: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		89: [
			0,
			.69444,
			.025,
			0,
			.66667
		],
		90: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		91: [
			.25,
			.75,
			0,
			0,
			.28889
		],
		93: [
			.25,
			.75,
			0,
			0,
			.28889
		],
		94: [
			0,
			.69444,
			0,
			0,
			.5
		],
		95: [
			.35,
			.09444,
			.02778,
			0,
			.5
		],
		97: [
			0,
			.44444,
			0,
			0,
			.48056
		],
		98: [
			0,
			.69444,
			0,
			0,
			.51667
		],
		99: [
			0,
			.44444,
			0,
			0,
			.44445
		],
		100: [
			0,
			.69444,
			0,
			0,
			.51667
		],
		101: [
			0,
			.44444,
			0,
			0,
			.44445
		],
		102: [
			0,
			.69444,
			.06944,
			0,
			.30556
		],
		103: [
			.19444,
			.44444,
			.01389,
			0,
			.5
		],
		104: [
			0,
			.69444,
			0,
			0,
			.51667
		],
		105: [
			0,
			.67937,
			0,
			0,
			.23889
		],
		106: [
			.19444,
			.67937,
			0,
			0,
			.26667
		],
		107: [
			0,
			.69444,
			0,
			0,
			.48889
		],
		108: [
			0,
			.69444,
			0,
			0,
			.23889
		],
		109: [
			0,
			.44444,
			0,
			0,
			.79445
		],
		110: [
			0,
			.44444,
			0,
			0,
			.51667
		],
		111: [
			0,
			.44444,
			0,
			0,
			.5
		],
		112: [
			.19444,
			.44444,
			0,
			0,
			.51667
		],
		113: [
			.19444,
			.44444,
			0,
			0,
			.51667
		],
		114: [
			0,
			.44444,
			.01389,
			0,
			.34167
		],
		115: [
			0,
			.44444,
			0,
			0,
			.38333
		],
		116: [
			0,
			.57143,
			0,
			0,
			.36111
		],
		117: [
			0,
			.44444,
			0,
			0,
			.51667
		],
		118: [
			0,
			.44444,
			.01389,
			0,
			.46111
		],
		119: [
			0,
			.44444,
			.01389,
			0,
			.68334
		],
		120: [
			0,
			.44444,
			0,
			0,
			.46111
		],
		121: [
			.19444,
			.44444,
			.01389,
			0,
			.46111
		],
		122: [
			0,
			.44444,
			0,
			0,
			.43472
		],
		126: [
			.35,
			.32659,
			0,
			0,
			.5
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.67937,
			0,
			0,
			.5
		],
		176: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		184: [
			.17014,
			0,
			0,
			0,
			.44445
		],
		305: [
			0,
			.44444,
			0,
			0,
			.23889
		],
		567: [
			.19444,
			.44444,
			0,
			0,
			.26667
		],
		710: [
			0,
			.69444,
			0,
			0,
			.5
		],
		711: [
			0,
			.63194,
			0,
			0,
			.5
		],
		713: [
			0,
			.60889,
			0,
			0,
			.5
		],
		714: [
			0,
			.69444,
			0,
			0,
			.5
		],
		715: [
			0,
			.69444,
			0,
			0,
			.5
		],
		728: [
			0,
			.69444,
			0,
			0,
			.5
		],
		729: [
			0,
			.67937,
			0,
			0,
			.27778
		],
		730: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		732: [
			0,
			.67659,
			0,
			0,
			.5
		],
		733: [
			0,
			.69444,
			0,
			0,
			.5
		],
		915: [
			0,
			.69444,
			0,
			0,
			.54167
		],
		916: [
			0,
			.69444,
			0,
			0,
			.83334
		],
		920: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		923: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		926: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		928: [
			0,
			.69444,
			0,
			0,
			.70834
		],
		931: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		933: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		934: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		936: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		937: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		8211: [
			0,
			.44444,
			.02778,
			0,
			.5
		],
		8212: [
			0,
			.44444,
			.02778,
			0,
			1
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.5
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.5
		]
	},
	"Script-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		65: [
			0,
			.7,
			.22925,
			0,
			.80253
		],
		66: [
			0,
			.7,
			.04087,
			0,
			.90757
		],
		67: [
			0,
			.7,
			.1689,
			0,
			.66619
		],
		68: [
			0,
			.7,
			.09371,
			0,
			.77443
		],
		69: [
			0,
			.7,
			.18583,
			0,
			.56162
		],
		70: [
			0,
			.7,
			.13634,
			0,
			.89544
		],
		71: [
			0,
			.7,
			.17322,
			0,
			.60961
		],
		72: [
			0,
			.7,
			.29694,
			0,
			.96919
		],
		73: [
			0,
			.7,
			.19189,
			0,
			.80907
		],
		74: [
			.27778,
			.7,
			.19189,
			0,
			1.05159
		],
		75: [
			0,
			.7,
			.31259,
			0,
			.91364
		],
		76: [
			0,
			.7,
			.19189,
			0,
			.87373
		],
		77: [
			0,
			.7,
			.15981,
			0,
			1.08031
		],
		78: [
			0,
			.7,
			.3525,
			0,
			.9015
		],
		79: [
			0,
			.7,
			.08078,
			0,
			.73787
		],
		80: [
			0,
			.7,
			.08078,
			0,
			1.01262
		],
		81: [
			0,
			.7,
			.03305,
			0,
			.88282
		],
		82: [
			0,
			.7,
			.06259,
			0,
			.85
		],
		83: [
			0,
			.7,
			.19189,
			0,
			.86767
		],
		84: [
			0,
			.7,
			.29087,
			0,
			.74697
		],
		85: [
			0,
			.7,
			.25815,
			0,
			.79996
		],
		86: [
			0,
			.7,
			.27523,
			0,
			.62204
		],
		87: [
			0,
			.7,
			.27523,
			0,
			.80532
		],
		88: [
			0,
			.7,
			.26006,
			0,
			.94445
		],
		89: [
			0,
			.7,
			.2939,
			0,
			.70961
		],
		90: [
			0,
			.7,
			.24037,
			0,
			.8212
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		]
	},
	"Size1-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			.35001,
			.85,
			0,
			0,
			.45834
		],
		41: [
			.35001,
			.85,
			0,
			0,
			.45834
		],
		47: [
			.35001,
			.85,
			0,
			0,
			.57778
		],
		91: [
			.35001,
			.85,
			0,
			0,
			.41667
		],
		92: [
			.35001,
			.85,
			0,
			0,
			.57778
		],
		93: [
			.35001,
			.85,
			0,
			0,
			.41667
		],
		123: [
			.35001,
			.85,
			0,
			0,
			.58334
		],
		125: [
			.35001,
			.85,
			0,
			0,
			.58334
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		732: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		770: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		771: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		8214: [
			-99e-5,
			.601,
			0,
			0,
			.77778
		],
		8593: [
			1e-5,
			.6,
			0,
			0,
			.66667
		],
		8595: [
			1e-5,
			.6,
			0,
			0,
			.66667
		],
		8657: [
			1e-5,
			.6,
			0,
			0,
			.77778
		],
		8659: [
			1e-5,
			.6,
			0,
			0,
			.77778
		],
		8719: [
			.25001,
			.75,
			0,
			0,
			.94445
		],
		8720: [
			.25001,
			.75,
			0,
			0,
			.94445
		],
		8721: [
			.25001,
			.75,
			0,
			0,
			1.05556
		],
		8730: [
			.35001,
			.85,
			0,
			0,
			1
		],
		8739: [
			-.00599,
			.606,
			0,
			0,
			.33333
		],
		8741: [
			-.00599,
			.606,
			0,
			0,
			.55556
		],
		8747: [
			.30612,
			.805,
			.19445,
			0,
			.47222
		],
		8748: [
			.306,
			.805,
			.19445,
			0,
			.47222
		],
		8749: [
			.306,
			.805,
			.19445,
			0,
			.47222
		],
		8750: [
			.30612,
			.805,
			.19445,
			0,
			.47222
		],
		8896: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8897: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8898: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8899: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8968: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		8969: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		8970: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		8971: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		9168: [
			-99e-5,
			.601,
			0,
			0,
			.66667
		],
		10216: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		10217: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		10752: [
			.25001,
			.75,
			0,
			0,
			1.11111
		],
		10753: [
			.25001,
			.75,
			0,
			0,
			1.11111
		],
		10754: [
			.25001,
			.75,
			0,
			0,
			1.11111
		],
		10756: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		10758: [
			.25001,
			.75,
			0,
			0,
			.83334
		]
	},
	"Size2-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			.65002,
			1.15,
			0,
			0,
			.59722
		],
		41: [
			.65002,
			1.15,
			0,
			0,
			.59722
		],
		47: [
			.65002,
			1.15,
			0,
			0,
			.81111
		],
		91: [
			.65002,
			1.15,
			0,
			0,
			.47222
		],
		92: [
			.65002,
			1.15,
			0,
			0,
			.81111
		],
		93: [
			.65002,
			1.15,
			0,
			0,
			.47222
		],
		123: [
			.65002,
			1.15,
			0,
			0,
			.66667
		],
		125: [
			.65002,
			1.15,
			0,
			0,
			.66667
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.75,
			0,
			0,
			1
		],
		732: [
			0,
			.75,
			0,
			0,
			1
		],
		770: [
			0,
			.75,
			0,
			0,
			1
		],
		771: [
			0,
			.75,
			0,
			0,
			1
		],
		8719: [
			.55001,
			1.05,
			0,
			0,
			1.27778
		],
		8720: [
			.55001,
			1.05,
			0,
			0,
			1.27778
		],
		8721: [
			.55001,
			1.05,
			0,
			0,
			1.44445
		],
		8730: [
			.65002,
			1.15,
			0,
			0,
			1
		],
		8747: [
			.86225,
			1.36,
			.44445,
			0,
			.55556
		],
		8748: [
			.862,
			1.36,
			.44445,
			0,
			.55556
		],
		8749: [
			.862,
			1.36,
			.44445,
			0,
			.55556
		],
		8750: [
			.86225,
			1.36,
			.44445,
			0,
			.55556
		],
		8896: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8897: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8898: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8899: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8968: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		8969: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		8970: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		8971: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		10216: [
			.65002,
			1.15,
			0,
			0,
			.61111
		],
		10217: [
			.65002,
			1.15,
			0,
			0,
			.61111
		],
		10752: [
			.55001,
			1.05,
			0,
			0,
			1.51112
		],
		10753: [
			.55001,
			1.05,
			0,
			0,
			1.51112
		],
		10754: [
			.55001,
			1.05,
			0,
			0,
			1.51112
		],
		10756: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		10758: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		]
	},
	"Size3-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			.95003,
			1.45,
			0,
			0,
			.73611
		],
		41: [
			.95003,
			1.45,
			0,
			0,
			.73611
		],
		47: [
			.95003,
			1.45,
			0,
			0,
			1.04445
		],
		91: [
			.95003,
			1.45,
			0,
			0,
			.52778
		],
		92: [
			.95003,
			1.45,
			0,
			0,
			1.04445
		],
		93: [
			.95003,
			1.45,
			0,
			0,
			.52778
		],
		123: [
			.95003,
			1.45,
			0,
			0,
			.75
		],
		125: [
			.95003,
			1.45,
			0,
			0,
			.75
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		732: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		770: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		771: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		8730: [
			.95003,
			1.45,
			0,
			0,
			1
		],
		8968: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		8969: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		8970: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		8971: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		10216: [
			.95003,
			1.45,
			0,
			0,
			.75
		],
		10217: [
			.95003,
			1.45,
			0,
			0,
			.75
		]
	},
	"Size4-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			1.25003,
			1.75,
			0,
			0,
			.79167
		],
		41: [
			1.25003,
			1.75,
			0,
			0,
			.79167
		],
		47: [
			1.25003,
			1.75,
			0,
			0,
			1.27778
		],
		91: [
			1.25003,
			1.75,
			0,
			0,
			.58334
		],
		92: [
			1.25003,
			1.75,
			0,
			0,
			1.27778
		],
		93: [
			1.25003,
			1.75,
			0,
			0,
			.58334
		],
		123: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		125: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		732: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		770: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		771: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		8730: [
			1.25003,
			1.75,
			0,
			0,
			1
		],
		8968: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		8969: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		8970: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		8971: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		9115: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9116: [
			1e-5,
			.6,
			0,
			0,
			.875
		],
		9117: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9118: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9119: [
			1e-5,
			.6,
			0,
			0,
			.875
		],
		9120: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9121: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9122: [
			-99e-5,
			.601,
			0,
			0,
			.66667
		],
		9123: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9124: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9125: [
			-99e-5,
			.601,
			0,
			0,
			.66667
		],
		9126: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9127: [
			1e-5,
			.9,
			0,
			0,
			.88889
		],
		9128: [
			.65002,
			1.15,
			0,
			0,
			.88889
		],
		9129: [
			.90001,
			0,
			0,
			0,
			.88889
		],
		9130: [
			0,
			.3,
			0,
			0,
			.88889
		],
		9131: [
			1e-5,
			.9,
			0,
			0,
			.88889
		],
		9132: [
			.65002,
			1.15,
			0,
			0,
			.88889
		],
		9133: [
			.90001,
			0,
			0,
			0,
			.88889
		],
		9143: [
			.88502,
			.915,
			0,
			0,
			1.05556
		],
		10216: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		10217: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		57344: [
			-.00499,
			.605,
			0,
			0,
			1.05556
		],
		57345: [
			-.00499,
			.605,
			0,
			0,
			1.05556
		],
		57680: [
			0,
			.12,
			0,
			0,
			.45
		],
		57681: [
			0,
			.12,
			0,
			0,
			.45
		],
		57682: [
			0,
			.12,
			0,
			0,
			.45
		],
		57683: [
			0,
			.12,
			0,
			0,
			.45
		]
	},
	"Typewriter-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.525
		],
		33: [
			0,
			.61111,
			0,
			0,
			.525
		],
		34: [
			0,
			.61111,
			0,
			0,
			.525
		],
		35: [
			0,
			.61111,
			0,
			0,
			.525
		],
		36: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		37: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		38: [
			0,
			.61111,
			0,
			0,
			.525
		],
		39: [
			0,
			.61111,
			0,
			0,
			.525
		],
		40: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		41: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		42: [
			0,
			.52083,
			0,
			0,
			.525
		],
		43: [
			-.08056,
			.53055,
			0,
			0,
			.525
		],
		44: [
			.13889,
			.125,
			0,
			0,
			.525
		],
		45: [
			-.08056,
			.53055,
			0,
			0,
			.525
		],
		46: [
			0,
			.125,
			0,
			0,
			.525
		],
		47: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		48: [
			0,
			.61111,
			0,
			0,
			.525
		],
		49: [
			0,
			.61111,
			0,
			0,
			.525
		],
		50: [
			0,
			.61111,
			0,
			0,
			.525
		],
		51: [
			0,
			.61111,
			0,
			0,
			.525
		],
		52: [
			0,
			.61111,
			0,
			0,
			.525
		],
		53: [
			0,
			.61111,
			0,
			0,
			.525
		],
		54: [
			0,
			.61111,
			0,
			0,
			.525
		],
		55: [
			0,
			.61111,
			0,
			0,
			.525
		],
		56: [
			0,
			.61111,
			0,
			0,
			.525
		],
		57: [
			0,
			.61111,
			0,
			0,
			.525
		],
		58: [
			0,
			.43056,
			0,
			0,
			.525
		],
		59: [
			.13889,
			.43056,
			0,
			0,
			.525
		],
		60: [
			-.05556,
			.55556,
			0,
			0,
			.525
		],
		61: [
			-.19549,
			.41562,
			0,
			0,
			.525
		],
		62: [
			-.05556,
			.55556,
			0,
			0,
			.525
		],
		63: [
			0,
			.61111,
			0,
			0,
			.525
		],
		64: [
			0,
			.61111,
			0,
			0,
			.525
		],
		65: [
			0,
			.61111,
			0,
			0,
			.525
		],
		66: [
			0,
			.61111,
			0,
			0,
			.525
		],
		67: [
			0,
			.61111,
			0,
			0,
			.525
		],
		68: [
			0,
			.61111,
			0,
			0,
			.525
		],
		69: [
			0,
			.61111,
			0,
			0,
			.525
		],
		70: [
			0,
			.61111,
			0,
			0,
			.525
		],
		71: [
			0,
			.61111,
			0,
			0,
			.525
		],
		72: [
			0,
			.61111,
			0,
			0,
			.525
		],
		73: [
			0,
			.61111,
			0,
			0,
			.525
		],
		74: [
			0,
			.61111,
			0,
			0,
			.525
		],
		75: [
			0,
			.61111,
			0,
			0,
			.525
		],
		76: [
			0,
			.61111,
			0,
			0,
			.525
		],
		77: [
			0,
			.61111,
			0,
			0,
			.525
		],
		78: [
			0,
			.61111,
			0,
			0,
			.525
		],
		79: [
			0,
			.61111,
			0,
			0,
			.525
		],
		80: [
			0,
			.61111,
			0,
			0,
			.525
		],
		81: [
			.13889,
			.61111,
			0,
			0,
			.525
		],
		82: [
			0,
			.61111,
			0,
			0,
			.525
		],
		83: [
			0,
			.61111,
			0,
			0,
			.525
		],
		84: [
			0,
			.61111,
			0,
			0,
			.525
		],
		85: [
			0,
			.61111,
			0,
			0,
			.525
		],
		86: [
			0,
			.61111,
			0,
			0,
			.525
		],
		87: [
			0,
			.61111,
			0,
			0,
			.525
		],
		88: [
			0,
			.61111,
			0,
			0,
			.525
		],
		89: [
			0,
			.61111,
			0,
			0,
			.525
		],
		90: [
			0,
			.61111,
			0,
			0,
			.525
		],
		91: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		92: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		93: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		94: [
			0,
			.61111,
			0,
			0,
			.525
		],
		95: [
			.09514,
			0,
			0,
			0,
			.525
		],
		96: [
			0,
			.61111,
			0,
			0,
			.525
		],
		97: [
			0,
			.43056,
			0,
			0,
			.525
		],
		98: [
			0,
			.61111,
			0,
			0,
			.525
		],
		99: [
			0,
			.43056,
			0,
			0,
			.525
		],
		100: [
			0,
			.61111,
			0,
			0,
			.525
		],
		101: [
			0,
			.43056,
			0,
			0,
			.525
		],
		102: [
			0,
			.61111,
			0,
			0,
			.525
		],
		103: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		104: [
			0,
			.61111,
			0,
			0,
			.525
		],
		105: [
			0,
			.61111,
			0,
			0,
			.525
		],
		106: [
			.22222,
			.61111,
			0,
			0,
			.525
		],
		107: [
			0,
			.61111,
			0,
			0,
			.525
		],
		108: [
			0,
			.61111,
			0,
			0,
			.525
		],
		109: [
			0,
			.43056,
			0,
			0,
			.525
		],
		110: [
			0,
			.43056,
			0,
			0,
			.525
		],
		111: [
			0,
			.43056,
			0,
			0,
			.525
		],
		112: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		113: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		114: [
			0,
			.43056,
			0,
			0,
			.525
		],
		115: [
			0,
			.43056,
			0,
			0,
			.525
		],
		116: [
			0,
			.55358,
			0,
			0,
			.525
		],
		117: [
			0,
			.43056,
			0,
			0,
			.525
		],
		118: [
			0,
			.43056,
			0,
			0,
			.525
		],
		119: [
			0,
			.43056,
			0,
			0,
			.525
		],
		120: [
			0,
			.43056,
			0,
			0,
			.525
		],
		121: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		122: [
			0,
			.43056,
			0,
			0,
			.525
		],
		123: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		124: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		125: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		126: [
			0,
			.61111,
			0,
			0,
			.525
		],
		127: [
			0,
			.61111,
			0,
			0,
			.525
		],
		160: [
			0,
			0,
			0,
			0,
			.525
		],
		176: [
			0,
			.61111,
			0,
			0,
			.525
		],
		184: [
			.19445,
			0,
			0,
			0,
			.525
		],
		305: [
			0,
			.43056,
			0,
			0,
			.525
		],
		567: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		711: [
			0,
			.56597,
			0,
			0,
			.525
		],
		713: [
			0,
			.56555,
			0,
			0,
			.525
		],
		714: [
			0,
			.61111,
			0,
			0,
			.525
		],
		715: [
			0,
			.61111,
			0,
			0,
			.525
		],
		728: [
			0,
			.61111,
			0,
			0,
			.525
		],
		730: [
			0,
			.61111,
			0,
			0,
			.525
		],
		770: [
			0,
			.61111,
			0,
			0,
			.525
		],
		771: [
			0,
			.61111,
			0,
			0,
			.525
		],
		776: [
			0,
			.61111,
			0,
			0,
			.525
		],
		915: [
			0,
			.61111,
			0,
			0,
			.525
		],
		916: [
			0,
			.61111,
			0,
			0,
			.525
		],
		920: [
			0,
			.61111,
			0,
			0,
			.525
		],
		923: [
			0,
			.61111,
			0,
			0,
			.525
		],
		926: [
			0,
			.61111,
			0,
			0,
			.525
		],
		928: [
			0,
			.61111,
			0,
			0,
			.525
		],
		931: [
			0,
			.61111,
			0,
			0,
			.525
		],
		933: [
			0,
			.61111,
			0,
			0,
			.525
		],
		934: [
			0,
			.61111,
			0,
			0,
			.525
		],
		936: [
			0,
			.61111,
			0,
			0,
			.525
		],
		937: [
			0,
			.61111,
			0,
			0,
			.525
		],
		8216: [
			0,
			.61111,
			0,
			0,
			.525
		],
		8217: [
			0,
			.61111,
			0,
			0,
			.525
		],
		8242: [
			0,
			.61111,
			0,
			0,
			.525
		],
		9251: [
			.11111,
			.21944,
			0,
			0,
			.525
		]
	}
}, We = {
	slant: [
		.25,
		.25,
		.25
	],
	space: [
		0,
		0,
		0
	],
	stretch: [
		0,
		0,
		0
	],
	shrink: [
		0,
		0,
		0
	],
	xHeight: [
		.431,
		.431,
		.431
	],
	quad: [
		1,
		1.171,
		1.472
	],
	extraSpace: [
		0,
		0,
		0
	],
	num1: [
		.677,
		.732,
		.925
	],
	num2: [
		.394,
		.384,
		.387
	],
	num3: [
		.444,
		.471,
		.504
	],
	denom1: [
		.686,
		.752,
		1.025
	],
	denom2: [
		.345,
		.344,
		.532
	],
	sup1: [
		.413,
		.503,
		.504
	],
	sup2: [
		.363,
		.431,
		.404
	],
	sup3: [
		.289,
		.286,
		.294
	],
	sub1: [
		.15,
		.143,
		.2
	],
	sub2: [
		.247,
		.286,
		.4
	],
	supDrop: [
		.386,
		.353,
		.494
	],
	subDrop: [
		.05,
		.071,
		.1
	],
	delim1: [
		2.39,
		1.7,
		1.98
	],
	delim2: [
		1.01,
		1.157,
		1.42
	],
	axisHeight: [
		.25,
		.25,
		.25
	],
	defaultRuleThickness: [
		.04,
		.049,
		.049
	],
	bigOpSpacing1: [
		.111,
		.111,
		.111
	],
	bigOpSpacing2: [
		.166,
		.166,
		.166
	],
	bigOpSpacing3: [
		.2,
		.2,
		.2
	],
	bigOpSpacing4: [
		.6,
		.611,
		.611
	],
	bigOpSpacing5: [
		.1,
		.143,
		.143
	],
	sqrtRuleThickness: [
		.04,
		.04,
		.04
	],
	ptPerEm: [
		10,
		10,
		10
	],
	doubleRuleSep: [
		.2,
		.2,
		.2
	],
	arrayRuleWidth: [
		.04,
		.04,
		.04
	],
	fboxsep: [
		.3,
		.3,
		.3
	],
	fboxrule: [
		.04,
		.04,
		.04
	]
}, Ge = {
	Å: "A",
	Ð: "D",
	Þ: "o",
	å: "a",
	ð: "d",
	þ: "o",
	А: "A",
	Б: "B",
	В: "B",
	Г: "F",
	Д: "A",
	Е: "E",
	Ж: "K",
	З: "3",
	И: "N",
	Й: "N",
	К: "K",
	Л: "N",
	М: "M",
	Н: "H",
	О: "O",
	П: "N",
	Р: "P",
	С: "C",
	Т: "T",
	У: "y",
	Ф: "O",
	Х: "X",
	Ц: "U",
	Ч: "h",
	Ш: "W",
	Щ: "W",
	Ъ: "B",
	Ы: "X",
	Ь: "B",
	Э: "3",
	Ю: "X",
	Я: "R",
	а: "a",
	б: "b",
	в: "a",
	г: "r",
	д: "y",
	е: "e",
	ж: "m",
	з: "e",
	и: "n",
	й: "n",
	к: "n",
	л: "n",
	м: "m",
	н: "n",
	о: "o",
	п: "n",
	р: "p",
	с: "c",
	т: "o",
	у: "y",
	ф: "b",
	х: "x",
	ц: "n",
	ч: "n",
	ш: "w",
	щ: "w",
	ъ: "a",
	ы: "m",
	ь: "a",
	э: "e",
	ю: "m",
	я: "r"
};
function Ke(e, t) {
	Ue[e] = t;
}
function qe(e, t, n) {
	if (!Ue[t]) throw Error("Font metrics not found for font: " + t + ".");
	var r = e.charCodeAt(0), i = Ue[t][r];
	if (!i && e[0] in Ge && (r = Ge[e[0]].charCodeAt(0), i = Ue[t][r]), !i && n === "text" && ce(r) && (i = Ue[t][77]), i) return {
		depth: i[0],
		height: i[1],
		italic: i[2],
		skew: i[3],
		width: i[4]
	};
}
var Je = {};
function Ye(e) {
	var t;
	if (t = e >= 5 ? 0 : e >= 3 ? 1 : 2, !Je[t]) {
		var n = Je[t] = { cssEmPerMu: We.quad[t] / 18 };
		for (var r in We) We.hasOwnProperty(r) && (n[r] = We[r][t]);
	}
	return Je[t];
}
var A = {
	math: {},
	text: {}
};
function j(e, t, n, r, i, a) {
	A[e][i] = {
		font: t,
		group: n,
		replace: r
	}, a && r && (A[e][r] = A[e][i]);
}
var M = "math", N = "text", P = "main", F = "ams", I = "accent-token", L = "bin", Xe = "close", Ze = "inner", R = "mathord", z = "op-token", Qe = "open", $e = "punct", B = "rel", et = "spacing", V = "textord";
j(M, P, B, "≡", "\\equiv", !0), j(M, P, B, "≺", "\\prec", !0), j(M, P, B, "≻", "\\succ", !0), j(M, P, B, "∼", "\\sim", !0), j(M, P, B, "⊥", "\\perp"), j(M, P, B, "⪯", "\\preceq", !0), j(M, P, B, "⪰", "\\succeq", !0), j(M, P, B, "≃", "\\simeq", !0), j(M, P, B, "∣", "\\mid", !0), j(M, P, B, "≪", "\\ll", !0), j(M, P, B, "≫", "\\gg", !0), j(M, P, B, "≍", "\\asymp", !0), j(M, P, B, "∥", "\\parallel"), j(M, P, B, "⋈", "\\bowtie", !0), j(M, P, B, "⌣", "\\smile", !0), j(M, P, B, "⊑", "\\sqsubseteq", !0), j(M, P, B, "⊒", "\\sqsupseteq", !0), j(M, P, B, "≐", "\\doteq", !0), j(M, P, B, "⌢", "\\frown", !0), j(M, P, B, "∋", "\\ni", !0), j(M, P, B, "∝", "\\propto", !0), j(M, P, B, "⊢", "\\vdash", !0), j(M, P, B, "⊣", "\\dashv", !0), j(M, P, B, "∋", "\\owns"), j(M, P, $e, ".", "\\ldotp"), j(M, P, $e, "⋅", "\\cdotp"), j(M, P, $e, "⋅", "·"), j(N, P, V, "⋅", "·"), j(M, P, V, "#", "\\#"), j(N, P, V, "#", "\\#"), j(M, P, V, "&", "\\&"), j(N, P, V, "&", "\\&"), j(M, P, V, "ℵ", "\\aleph", !0), j(M, P, V, "∀", "\\forall", !0), j(M, P, V, "ℏ", "\\hbar", !0), j(M, P, V, "∃", "\\exists", !0), j(M, P, V, "∇", "\\nabla", !0), j(M, P, V, "♭", "\\flat", !0), j(M, P, V, "ℓ", "\\ell", !0), j(M, P, V, "♮", "\\natural", !0), j(M, P, V, "♣", "\\clubsuit", !0), j(M, P, V, "℘", "\\wp", !0), j(M, P, V, "♯", "\\sharp", !0), j(M, P, V, "♢", "\\diamondsuit", !0), j(M, P, V, "ℜ", "\\Re", !0), j(M, P, V, "♡", "\\heartsuit", !0), j(M, P, V, "ℑ", "\\Im", !0), j(M, P, V, "♠", "\\spadesuit", !0), j(M, P, V, "§", "\\S", !0), j(N, P, V, "§", "\\S"), j(M, P, V, "¶", "\\P", !0), j(N, P, V, "¶", "\\P"), j(M, P, V, "†", "\\dag"), j(N, P, V, "†", "\\dag"), j(N, P, V, "†", "\\textdagger"), j(M, P, V, "‡", "\\ddag"), j(N, P, V, "‡", "\\ddag"), j(N, P, V, "‡", "\\textdaggerdbl"), j(M, P, Xe, "⎱", "\\rmoustache", !0), j(M, P, Qe, "⎰", "\\lmoustache", !0), j(M, P, Xe, "⟯", "\\rgroup", !0), j(M, P, Qe, "⟮", "\\lgroup", !0), j(M, P, L, "∓", "\\mp", !0), j(M, P, L, "⊖", "\\ominus", !0), j(M, P, L, "⊎", "\\uplus", !0), j(M, P, L, "⊓", "\\sqcap", !0), j(M, P, L, "∗", "\\ast"), j(M, P, L, "⊔", "\\sqcup", !0), j(M, P, L, "◯", "\\bigcirc", !0), j(M, P, L, "∙", "\\bullet", !0), j(M, P, L, "‡", "\\ddagger"), j(M, P, L, "≀", "\\wr", !0), j(M, P, L, "⨿", "\\amalg"), j(M, P, L, "&", "\\And"), j(M, P, B, "⟵", "\\longleftarrow", !0), j(M, P, B, "⇐", "\\Leftarrow", !0), j(M, P, B, "⟸", "\\Longleftarrow", !0), j(M, P, B, "⟶", "\\longrightarrow", !0), j(M, P, B, "⇒", "\\Rightarrow", !0), j(M, P, B, "⟹", "\\Longrightarrow", !0), j(M, P, B, "↔", "\\leftrightarrow", !0), j(M, P, B, "⟷", "\\longleftrightarrow", !0), j(M, P, B, "⇔", "\\Leftrightarrow", !0), j(M, P, B, "⟺", "\\Longleftrightarrow", !0), j(M, P, B, "↦", "\\mapsto", !0), j(M, P, B, "⟼", "\\longmapsto", !0), j(M, P, B, "↗", "\\nearrow", !0), j(M, P, B, "↩", "\\hookleftarrow", !0), j(M, P, B, "↪", "\\hookrightarrow", !0), j(M, P, B, "↘", "\\searrow", !0), j(M, P, B, "↼", "\\leftharpoonup", !0), j(M, P, B, "⇀", "\\rightharpoonup", !0), j(M, P, B, "↙", "\\swarrow", !0), j(M, P, B, "↽", "\\leftharpoondown", !0), j(M, P, B, "⇁", "\\rightharpoondown", !0), j(M, P, B, "↖", "\\nwarrow", !0), j(M, P, B, "⇌", "\\rightleftharpoons", !0), j(M, F, B, "≮", "\\nless", !0), j(M, F, B, "", "\\@nleqslant"), j(M, F, B, "", "\\@nleqq"), j(M, F, B, "⪇", "\\lneq", !0), j(M, F, B, "≨", "\\lneqq", !0), j(M, F, B, "", "\\@lvertneqq"), j(M, F, B, "⋦", "\\lnsim", !0), j(M, F, B, "⪉", "\\lnapprox", !0), j(M, F, B, "⊀", "\\nprec", !0), j(M, F, B, "⋠", "\\npreceq", !0), j(M, F, B, "⋨", "\\precnsim", !0), j(M, F, B, "⪹", "\\precnapprox", !0), j(M, F, B, "≁", "\\nsim", !0), j(M, F, B, "", "\\@nshortmid"), j(M, F, B, "∤", "\\nmid", !0), j(M, F, B, "⊬", "\\nvdash", !0), j(M, F, B, "⊭", "\\nvDash", !0), j(M, F, B, "⋪", "\\ntriangleleft"), j(M, F, B, "⋬", "\\ntrianglelefteq", !0), j(M, F, B, "⊊", "\\subsetneq", !0), j(M, F, B, "", "\\@varsubsetneq"), j(M, F, B, "⫋", "\\subsetneqq", !0), j(M, F, B, "", "\\@varsubsetneqq"), j(M, F, B, "≯", "\\ngtr", !0), j(M, F, B, "", "\\@ngeqslant"), j(M, F, B, "", "\\@ngeqq"), j(M, F, B, "⪈", "\\gneq", !0), j(M, F, B, "≩", "\\gneqq", !0), j(M, F, B, "", "\\@gvertneqq"), j(M, F, B, "⋧", "\\gnsim", !0), j(M, F, B, "⪊", "\\gnapprox", !0), j(M, F, B, "⊁", "\\nsucc", !0), j(M, F, B, "⋡", "\\nsucceq", !0), j(M, F, B, "⋩", "\\succnsim", !0), j(M, F, B, "⪺", "\\succnapprox", !0), j(M, F, B, "≆", "\\ncong", !0), j(M, F, B, "", "\\@nshortparallel"), j(M, F, B, "∦", "\\nparallel", !0), j(M, F, B, "⊯", "\\nVDash", !0), j(M, F, B, "⋫", "\\ntriangleright"), j(M, F, B, "⋭", "\\ntrianglerighteq", !0), j(M, F, B, "", "\\@nsupseteqq"), j(M, F, B, "⊋", "\\supsetneq", !0), j(M, F, B, "", "\\@varsupsetneq"), j(M, F, B, "⫌", "\\supsetneqq", !0), j(M, F, B, "", "\\@varsupsetneqq"), j(M, F, B, "⊮", "\\nVdash", !0), j(M, F, B, "⪵", "\\precneqq", !0), j(M, F, B, "⪶", "\\succneqq", !0), j(M, F, B, "", "\\@nsubseteqq"), j(M, F, L, "⊴", "\\unlhd"), j(M, F, L, "⊵", "\\unrhd"), j(M, F, B, "↚", "\\nleftarrow", !0), j(M, F, B, "↛", "\\nrightarrow", !0), j(M, F, B, "⇍", "\\nLeftarrow", !0), j(M, F, B, "⇏", "\\nRightarrow", !0), j(M, F, B, "↮", "\\nleftrightarrow", !0), j(M, F, B, "⇎", "\\nLeftrightarrow", !0), j(M, F, B, "△", "\\vartriangle"), j(M, F, V, "ℏ", "\\hslash"), j(M, F, V, "▽", "\\triangledown"), j(M, F, V, "◊", "\\lozenge"), j(M, F, V, "Ⓢ", "\\circledS"), j(M, F, V, "®", "\\circledR"), j(N, F, V, "®", "\\circledR"), j(M, F, V, "∡", "\\measuredangle", !0), j(M, F, V, "∄", "\\nexists"), j(M, F, V, "℧", "\\mho"), j(M, F, V, "Ⅎ", "\\Finv", !0), j(M, F, V, "⅁", "\\Game", !0), j(M, F, V, "‵", "\\backprime"), j(M, F, V, "▲", "\\blacktriangle"), j(M, F, V, "▼", "\\blacktriangledown"), j(M, F, V, "■", "\\blacksquare"), j(M, F, V, "⧫", "\\blacklozenge"), j(M, F, V, "★", "\\bigstar"), j(M, F, V, "∢", "\\sphericalangle", !0), j(M, F, V, "∁", "\\complement", !0), j(M, F, V, "ð", "\\eth", !0), j(N, P, V, "ð", "ð"), j(M, F, V, "╱", "\\diagup"), j(M, F, V, "╲", "\\diagdown"), j(M, F, V, "□", "\\square"), j(M, F, V, "□", "\\Box"), j(M, F, V, "◊", "\\Diamond"), j(M, F, V, "¥", "\\yen", !0), j(N, F, V, "¥", "\\yen", !0), j(M, F, V, "✓", "\\checkmark", !0), j(N, F, V, "✓", "\\checkmark"), j(M, F, V, "ℶ", "\\beth", !0), j(M, F, V, "ℸ", "\\daleth", !0), j(M, F, V, "ℷ", "\\gimel", !0), j(M, F, V, "ϝ", "\\digamma", !0), j(M, F, V, "ϰ", "\\varkappa"), j(M, F, Qe, "┌", "\\@ulcorner", !0), j(M, F, Xe, "┐", "\\@urcorner", !0), j(M, F, Qe, "└", "\\@llcorner", !0), j(M, F, Xe, "┘", "\\@lrcorner", !0), j(M, F, B, "≦", "\\leqq", !0), j(M, F, B, "⩽", "\\leqslant", !0), j(M, F, B, "⪕", "\\eqslantless", !0), j(M, F, B, "≲", "\\lesssim", !0), j(M, F, B, "⪅", "\\lessapprox", !0), j(M, F, B, "≊", "\\approxeq", !0), j(M, F, L, "⋖", "\\lessdot"), j(M, F, B, "⋘", "\\lll", !0), j(M, F, B, "≶", "\\lessgtr", !0), j(M, F, B, "⋚", "\\lesseqgtr", !0), j(M, F, B, "⪋", "\\lesseqqgtr", !0), j(M, F, B, "≑", "\\doteqdot"), j(M, F, B, "≓", "\\risingdotseq", !0), j(M, F, B, "≒", "\\fallingdotseq", !0), j(M, F, B, "∽", "\\backsim", !0), j(M, F, B, "⋍", "\\backsimeq", !0), j(M, F, B, "⫅", "\\subseteqq", !0), j(M, F, B, "⋐", "\\Subset", !0), j(M, F, B, "⊏", "\\sqsubset", !0), j(M, F, B, "≼", "\\preccurlyeq", !0), j(M, F, B, "⋞", "\\curlyeqprec", !0), j(M, F, B, "≾", "\\precsim", !0), j(M, F, B, "⪷", "\\precapprox", !0), j(M, F, B, "⊲", "\\vartriangleleft"), j(M, F, B, "⊴", "\\trianglelefteq"), j(M, F, B, "⊨", "\\vDash", !0), j(M, F, B, "⊪", "\\Vvdash", !0), j(M, F, B, "⌣", "\\smallsmile"), j(M, F, B, "⌢", "\\smallfrown"), j(M, F, B, "≏", "\\bumpeq", !0), j(M, F, B, "≎", "\\Bumpeq", !0), j(M, F, B, "≧", "\\geqq", !0), j(M, F, B, "⩾", "\\geqslant", !0), j(M, F, B, "⪖", "\\eqslantgtr", !0), j(M, F, B, "≳", "\\gtrsim", !0), j(M, F, B, "⪆", "\\gtrapprox", !0), j(M, F, L, "⋗", "\\gtrdot"), j(M, F, B, "⋙", "\\ggg", !0), j(M, F, B, "≷", "\\gtrless", !0), j(M, F, B, "⋛", "\\gtreqless", !0), j(M, F, B, "⪌", "\\gtreqqless", !0), j(M, F, B, "≖", "\\eqcirc", !0), j(M, F, B, "≗", "\\circeq", !0), j(M, F, B, "≜", "\\triangleq", !0), j(M, F, B, "∼", "\\thicksim"), j(M, F, B, "≈", "\\thickapprox"), j(M, F, B, "⫆", "\\supseteqq", !0), j(M, F, B, "⋑", "\\Supset", !0), j(M, F, B, "⊐", "\\sqsupset", !0), j(M, F, B, "≽", "\\succcurlyeq", !0), j(M, F, B, "⋟", "\\curlyeqsucc", !0), j(M, F, B, "≿", "\\succsim", !0), j(M, F, B, "⪸", "\\succapprox", !0), j(M, F, B, "⊳", "\\vartriangleright"), j(M, F, B, "⊵", "\\trianglerighteq"), j(M, F, B, "⊩", "\\Vdash", !0), j(M, F, B, "∣", "\\shortmid"), j(M, F, B, "∥", "\\shortparallel"), j(M, F, B, "≬", "\\between", !0), j(M, F, B, "⋔", "\\pitchfork", !0), j(M, F, B, "∝", "\\varpropto"), j(M, F, B, "◀", "\\blacktriangleleft"), j(M, F, B, "∴", "\\therefore", !0), j(M, F, B, "∍", "\\backepsilon"), j(M, F, B, "▶", "\\blacktriangleright"), j(M, F, B, "∵", "\\because", !0), j(M, F, B, "⋘", "\\llless"), j(M, F, B, "⋙", "\\gggtr"), j(M, F, L, "⊲", "\\lhd"), j(M, F, L, "⊳", "\\rhd"), j(M, F, B, "≂", "\\eqsim", !0), j(M, P, B, "⋈", "\\Join"), j(M, F, B, "≑", "\\Doteq", !0), j(M, F, L, "∔", "\\dotplus", !0), j(M, F, L, "∖", "\\smallsetminus"), j(M, F, L, "⋒", "\\Cap", !0), j(M, F, L, "⋓", "\\Cup", !0), j(M, F, L, "⩞", "\\doublebarwedge", !0), j(M, F, L, "⊟", "\\boxminus", !0), j(M, F, L, "⊞", "\\boxplus", !0), j(M, F, L, "⋇", "\\divideontimes", !0), j(M, F, L, "⋉", "\\ltimes", !0), j(M, F, L, "⋊", "\\rtimes", !0), j(M, F, L, "⋋", "\\leftthreetimes", !0), j(M, F, L, "⋌", "\\rightthreetimes", !0), j(M, F, L, "⋏", "\\curlywedge", !0), j(M, F, L, "⋎", "\\curlyvee", !0), j(M, F, L, "⊝", "\\circleddash", !0), j(M, F, L, "⊛", "\\circledast", !0), j(M, F, L, "⋅", "\\centerdot"), j(M, F, L, "⊺", "\\intercal", !0), j(M, F, L, "⋒", "\\doublecap"), j(M, F, L, "⋓", "\\doublecup"), j(M, F, L, "⊠", "\\boxtimes", !0), j(M, F, B, "⇢", "\\dashrightarrow", !0), j(M, F, B, "⇠", "\\dashleftarrow", !0), j(M, F, B, "⇇", "\\leftleftarrows", !0), j(M, F, B, "⇆", "\\leftrightarrows", !0), j(M, F, B, "⇚", "\\Lleftarrow", !0), j(M, F, B, "↞", "\\twoheadleftarrow", !0), j(M, F, B, "↢", "\\leftarrowtail", !0), j(M, F, B, "↫", "\\looparrowleft", !0), j(M, F, B, "⇋", "\\leftrightharpoons", !0), j(M, F, B, "↶", "\\curvearrowleft", !0), j(M, F, B, "↺", "\\circlearrowleft", !0), j(M, F, B, "↰", "\\Lsh", !0), j(M, F, B, "⇈", "\\upuparrows", !0), j(M, F, B, "↿", "\\upharpoonleft", !0), j(M, F, B, "⇃", "\\downharpoonleft", !0), j(M, P, B, "⊶", "\\origof", !0), j(M, P, B, "⊷", "\\imageof", !0), j(M, F, B, "⊸", "\\multimap", !0), j(M, F, B, "↭", "\\leftrightsquigarrow", !0), j(M, F, B, "⇉", "\\rightrightarrows", !0), j(M, F, B, "⇄", "\\rightleftarrows", !0), j(M, F, B, "↠", "\\twoheadrightarrow", !0), j(M, F, B, "↣", "\\rightarrowtail", !0), j(M, F, B, "↬", "\\looparrowright", !0), j(M, F, B, "↷", "\\curvearrowright", !0), j(M, F, B, "↻", "\\circlearrowright", !0), j(M, F, B, "↱", "\\Rsh", !0), j(M, F, B, "⇊", "\\downdownarrows", !0), j(M, F, B, "↾", "\\upharpoonright", !0), j(M, F, B, "⇂", "\\downharpoonright", !0), j(M, F, B, "⇝", "\\rightsquigarrow", !0), j(M, F, B, "⇝", "\\leadsto"), j(M, F, B, "⇛", "\\Rrightarrow", !0), j(M, F, B, "↾", "\\restriction"), j(M, P, V, "‘", "`"), j(M, P, V, "$", "\\$"), j(N, P, V, "$", "\\$"), j(N, P, V, "$", "\\textdollar"), j(M, P, V, "%", "\\%"), j(N, P, V, "%", "\\%"), j(M, P, V, "_", "\\_"), j(N, P, V, "_", "\\_"), j(N, P, V, "_", "\\textunderscore"), j(M, P, V, "∠", "\\angle", !0), j(M, P, V, "∞", "\\infty", !0), j(M, P, V, "′", "\\prime"), j(M, P, V, "△", "\\triangle"), j(M, P, V, "Γ", "\\Gamma", !0), j(M, P, V, "Δ", "\\Delta", !0), j(M, P, V, "Θ", "\\Theta", !0), j(M, P, V, "Λ", "\\Lambda", !0), j(M, P, V, "Ξ", "\\Xi", !0), j(M, P, V, "Π", "\\Pi", !0), j(M, P, V, "Σ", "\\Sigma", !0), j(M, P, V, "Υ", "\\Upsilon", !0), j(M, P, V, "Φ", "\\Phi", !0), j(M, P, V, "Ψ", "\\Psi", !0), j(M, P, V, "Ω", "\\Omega", !0), j(M, P, V, "A", "Α"), j(M, P, V, "B", "Β"), j(M, P, V, "E", "Ε"), j(M, P, V, "Z", "Ζ"), j(M, P, V, "H", "Η"), j(M, P, V, "I", "Ι"), j(M, P, V, "K", "Κ"), j(M, P, V, "M", "Μ"), j(M, P, V, "N", "Ν"), j(M, P, V, "O", "Ο"), j(M, P, V, "P", "Ρ"), j(M, P, V, "T", "Τ"), j(M, P, V, "X", "Χ"), j(M, P, V, "¬", "\\neg", !0), j(M, P, V, "¬", "\\lnot"), j(M, P, V, "⊤", "\\top"), j(M, P, V, "⊥", "\\bot"), j(M, P, V, "∅", "\\emptyset"), j(M, F, V, "∅", "\\varnothing"), j(M, P, R, "α", "\\alpha", !0), j(M, P, R, "β", "\\beta", !0), j(M, P, R, "γ", "\\gamma", !0), j(M, P, R, "δ", "\\delta", !0), j(M, P, R, "ϵ", "\\epsilon", !0), j(M, P, R, "ζ", "\\zeta", !0), j(M, P, R, "η", "\\eta", !0), j(M, P, R, "θ", "\\theta", !0), j(M, P, R, "ι", "\\iota", !0), j(M, P, R, "κ", "\\kappa", !0), j(M, P, R, "λ", "\\lambda", !0), j(M, P, R, "μ", "\\mu", !0), j(M, P, R, "ν", "\\nu", !0), j(M, P, R, "ξ", "\\xi", !0), j(M, P, R, "ο", "\\omicron", !0), j(M, P, R, "π", "\\pi", !0), j(M, P, R, "ρ", "\\rho", !0), j(M, P, R, "σ", "\\sigma", !0), j(M, P, R, "τ", "\\tau", !0), j(M, P, R, "υ", "\\upsilon", !0), j(M, P, R, "ϕ", "\\phi", !0), j(M, P, R, "χ", "\\chi", !0), j(M, P, R, "ψ", "\\psi", !0), j(M, P, R, "ω", "\\omega", !0), j(M, P, R, "ε", "\\varepsilon", !0), j(M, P, R, "ϑ", "\\vartheta", !0), j(M, P, R, "ϖ", "\\varpi", !0), j(M, P, R, "ϱ", "\\varrho", !0), j(M, P, R, "ς", "\\varsigma", !0), j(M, P, R, "φ", "\\varphi", !0), j(M, P, L, "∗", "*", !0), j(M, P, L, "+", "+"), j(M, P, L, "−", "-", !0), j(M, P, L, "⋅", "\\cdot", !0), j(M, P, L, "∘", "\\circ", !0), j(M, P, L, "÷", "\\div", !0), j(M, P, L, "±", "\\pm", !0), j(M, P, L, "×", "\\times", !0), j(M, P, L, "∩", "\\cap", !0), j(M, P, L, "∪", "\\cup", !0), j(M, P, L, "∖", "\\setminus", !0), j(M, P, L, "∧", "\\land"), j(M, P, L, "∨", "\\lor"), j(M, P, L, "∧", "\\wedge", !0), j(M, P, L, "∨", "\\vee", !0), j(M, P, V, "√", "\\surd"), j(M, P, Qe, "⟨", "\\langle", !0), j(M, P, Qe, "∣", "\\lvert"), j(M, P, Qe, "∥", "\\lVert"), j(M, P, Xe, "?", "?"), j(M, P, Xe, "!", "!"), j(M, P, Xe, "⟩", "\\rangle", !0), j(M, P, Xe, "∣", "\\rvert"), j(M, P, Xe, "∥", "\\rVert"), j(M, P, B, "=", "="), j(M, P, B, ":", ":"), j(M, P, B, "≈", "\\approx", !0), j(M, P, B, "≅", "\\cong", !0), j(M, P, B, "≥", "\\ge"), j(M, P, B, "≥", "\\geq", !0), j(M, P, B, "←", "\\gets"), j(M, P, B, ">", "\\gt", !0), j(M, P, B, "∈", "\\in", !0), j(M, P, B, "", "\\@not"), j(M, P, B, "⊂", "\\subset", !0), j(M, P, B, "⊃", "\\supset", !0), j(M, P, B, "⊆", "\\subseteq", !0), j(M, P, B, "⊇", "\\supseteq", !0), j(M, F, B, "⊈", "\\nsubseteq", !0), j(M, F, B, "⊉", "\\nsupseteq", !0), j(M, P, B, "⊨", "\\models"), j(M, P, B, "←", "\\leftarrow", !0), j(M, P, B, "≤", "\\le"), j(M, P, B, "≤", "\\leq", !0), j(M, P, B, "<", "\\lt", !0), j(M, P, B, "→", "\\rightarrow", !0), j(M, P, B, "→", "\\to"), j(M, F, B, "≱", "\\ngeq", !0), j(M, F, B, "≰", "\\nleq", !0), j(M, P, et, "\xA0", "\\ "), j(M, P, et, "\xA0", "\\space"), j(M, P, et, "\xA0", "\\nobreakspace"), j(N, P, et, "\xA0", "\\ "), j(N, P, et, "\xA0", " "), j(N, P, et, "\xA0", "\\space"), j(N, P, et, "\xA0", "\\nobreakspace"), j(M, P, et, "", "\\nobreak"), j(M, P, et, "", "\\allowbreak"), j(M, P, $e, ",", ","), j(M, P, $e, ";", ";"), j(M, F, L, "⊼", "\\barwedge", !0), j(M, F, L, "⊻", "\\veebar", !0), j(M, P, L, "⊙", "\\odot", !0), j(M, P, L, "⊕", "\\oplus", !0), j(M, P, L, "⊗", "\\otimes", !0), j(M, P, V, "∂", "\\partial", !0), j(M, P, L, "⊘", "\\oslash", !0), j(M, F, L, "⊚", "\\circledcirc", !0), j(M, F, L, "⊡", "\\boxdot", !0), j(M, P, L, "△", "\\bigtriangleup"), j(M, P, L, "▽", "\\bigtriangledown"), j(M, P, L, "†", "\\dagger"), j(M, P, L, "⋄", "\\diamond"), j(M, P, L, "⋆", "\\star"), j(M, P, L, "◃", "\\triangleleft"), j(M, P, L, "▹", "\\triangleright"), j(M, P, Qe, "{", "\\{"), j(N, P, V, "{", "\\{"), j(N, P, V, "{", "\\textbraceleft"), j(M, P, Xe, "}", "\\}"), j(N, P, V, "}", "\\}"), j(N, P, V, "}", "\\textbraceright"), j(M, P, Qe, "{", "\\lbrace"), j(M, P, Xe, "}", "\\rbrace"), j(M, P, Qe, "[", "\\lbrack", !0), j(N, P, V, "[", "\\lbrack", !0), j(M, P, Xe, "]", "\\rbrack", !0), j(N, P, V, "]", "\\rbrack", !0), j(M, P, Qe, "(", "\\lparen", !0), j(M, P, Xe, ")", "\\rparen", !0), j(N, P, V, "<", "\\textless", !0), j(N, P, V, ">", "\\textgreater", !0), j(M, P, Qe, "⌊", "\\lfloor", !0), j(M, P, Xe, "⌋", "\\rfloor", !0), j(M, P, Qe, "⌈", "\\lceil", !0), j(M, P, Xe, "⌉", "\\rceil", !0), j(M, P, V, "\\", "\\backslash"), j(M, P, V, "∣", "|"), j(M, P, V, "∣", "\\vert"), j(N, P, V, "|", "\\textbar", !0), j(M, P, V, "∥", "\\|"), j(M, P, V, "∥", "\\Vert"), j(N, P, V, "∥", "\\textbardbl"), j(N, P, V, "~", "\\textasciitilde"), j(N, P, V, "\\", "\\textbackslash"), j(N, P, V, "^", "\\textasciicircum"), j(M, P, B, "↑", "\\uparrow", !0), j(M, P, B, "⇑", "\\Uparrow", !0), j(M, P, B, "↓", "\\downarrow", !0), j(M, P, B, "⇓", "\\Downarrow", !0), j(M, P, B, "↕", "\\updownarrow", !0), j(M, P, B, "⇕", "\\Updownarrow", !0), j(M, P, z, "∐", "\\coprod"), j(M, P, z, "⋁", "\\bigvee"), j(M, P, z, "⋀", "\\bigwedge"), j(M, P, z, "⨄", "\\biguplus"), j(M, P, z, "⋂", "\\bigcap"), j(M, P, z, "⋃", "\\bigcup"), j(M, P, z, "∫", "\\int"), j(M, P, z, "∫", "\\intop"), j(M, P, z, "∬", "\\iint"), j(M, P, z, "∭", "\\iiint"), j(M, P, z, "∏", "\\prod"), j(M, P, z, "∑", "\\sum"), j(M, P, z, "⨂", "\\bigotimes"), j(M, P, z, "⨁", "\\bigoplus"), j(M, P, z, "⨀", "\\bigodot"), j(M, P, z, "∮", "\\oint"), j(M, P, z, "∯", "\\oiint"), j(M, P, z, "∰", "\\oiiint"), j(M, P, z, "⨆", "\\bigsqcup"), j(M, P, z, "∫", "\\smallint"), j(N, P, Ze, "…", "\\textellipsis"), j(M, P, Ze, "…", "\\mathellipsis"), j(N, P, Ze, "…", "\\ldots", !0), j(M, P, Ze, "…", "\\ldots", !0), j(M, P, Ze, "⋯", "\\@cdots", !0), j(M, P, Ze, "⋱", "\\ddots", !0), j(M, P, V, "⋮", "\\varvdots"), j(N, P, V, "⋮", "\\varvdots"), j(M, P, I, "ˊ", "\\acute"), j(M, P, I, "ˋ", "\\grave"), j(M, P, I, "¨", "\\ddot"), j(M, P, I, "~", "\\tilde"), j(M, P, I, "ˉ", "\\bar"), j(M, P, I, "˘", "\\breve"), j(M, P, I, "ˇ", "\\check"), j(M, P, I, "^", "\\hat"), j(M, P, I, "⃗", "\\vec"), j(M, P, I, "˙", "\\dot"), j(M, P, I, "˚", "\\mathring"), j(M, P, R, "", "\\@imath"), j(M, P, R, "", "\\@jmath"), j(M, P, V, "ı", "ı"), j(M, P, V, "ȷ", "ȷ"), j(N, P, V, "ı", "\\i", !0), j(N, P, V, "ȷ", "\\j", !0), j(N, P, V, "ß", "\\ss", !0), j(N, P, V, "æ", "\\ae", !0), j(N, P, V, "œ", "\\oe", !0), j(N, P, V, "ø", "\\o", !0), j(N, P, V, "Æ", "\\AE", !0), j(N, P, V, "Œ", "\\OE", !0), j(N, P, V, "Ø", "\\O", !0), j(N, P, I, "ˊ", "\\'"), j(N, P, I, "ˋ", "\\`"), j(N, P, I, "ˆ", "\\^"), j(N, P, I, "˜", "\\~"), j(N, P, I, "ˉ", "\\="), j(N, P, I, "˘", "\\u"), j(N, P, I, "˙", "\\."), j(N, P, I, "¸", "\\c"), j(N, P, I, "˚", "\\r"), j(N, P, I, "ˇ", "\\v"), j(N, P, I, "¨", "\\\""), j(N, P, I, "˝", "\\H"), j(N, P, I, "◯", "\\textcircled");
var tt = {
	"--": !0,
	"---": !0,
	"``": !0,
	"''": !0
};
j(N, P, V, "–", "--", !0), j(N, P, V, "–", "\\textendash"), j(N, P, V, "—", "---", !0), j(N, P, V, "—", "\\textemdash"), j(N, P, V, "‘", "`", !0), j(N, P, V, "‘", "\\textquoteleft"), j(N, P, V, "’", "'", !0), j(N, P, V, "’", "\\textquoteright"), j(N, P, V, "“", "``", !0), j(N, P, V, "“", "\\textquotedblleft"), j(N, P, V, "”", "''", !0), j(N, P, V, "”", "\\textquotedblright"), j(M, P, V, "°", "\\degree", !0), j(N, P, V, "°", "\\degree"), j(N, P, V, "°", "\\textdegree", !0), j(M, P, V, "£", "\\pounds"), j(M, P, V, "£", "\\mathsterling", !0), j(N, P, V, "£", "\\pounds"), j(N, P, V, "£", "\\textsterling", !0), j(M, F, V, "✠", "\\maltese"), j(N, F, V, "✠", "\\maltese");
for (var nt = "0123456789/@.\"", rt = 0; rt < nt.length; rt++) {
	var it = nt.charAt(rt);
	j(M, P, V, it, it);
}
for (var at = "0123456789!@*()-=+\";:?/.,", ot = 0; ot < at.length; ot++) {
	var st = at.charAt(ot);
	j(N, P, V, st, st);
}
for (var ct = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", lt = 0; lt < ct.length; lt++) {
	var ut = ct.charAt(lt);
	j(M, P, R, ut, ut), j(N, P, V, ut, ut);
}
j(M, F, V, "C", "ℂ"), j(N, F, V, "C", "ℂ"), j(M, F, V, "H", "ℍ"), j(N, F, V, "H", "ℍ"), j(M, F, V, "N", "ℕ"), j(N, F, V, "N", "ℕ"), j(M, F, V, "P", "ℙ"), j(N, F, V, "P", "ℙ"), j(M, F, V, "Q", "ℚ"), j(N, F, V, "Q", "ℚ"), j(M, F, V, "R", "ℝ"), j(N, F, V, "R", "ℝ"), j(M, F, V, "Z", "ℤ"), j(N, F, V, "Z", "ℤ"), j(M, P, R, "h", "ℎ"), j(N, P, R, "h", "ℎ");
for (var H, dt = 0; dt < ct.length; dt++) {
	var U = ct.charAt(dt);
	H = String.fromCharCode(55349, 56320 + dt), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56372 + dt), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56424 + dt), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56580 + dt), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56684 + dt), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56736 + dt), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56788 + dt), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56840 + dt), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56944 + dt), j(M, P, R, U, H), j(N, P, V, U, H), dt < 26 && (H = String.fromCharCode(55349, 56632 + dt), j(M, P, R, U, H), j(N, P, V, U, H), H = String.fromCharCode(55349, 56476 + dt), j(M, P, R, U, H), j(N, P, V, U, H));
}
H = "𝕜", j(M, P, R, "k", H), j(N, P, V, "k", H);
for (var ft = 0; ft < 10; ft++) {
	var pt = ft.toString();
	H = String.fromCharCode(55349, 57294 + ft), j(M, P, R, pt, H), j(N, P, V, pt, H), H = String.fromCharCode(55349, 57314 + ft), j(M, P, R, pt, H), j(N, P, V, pt, H), H = String.fromCharCode(55349, 57324 + ft), j(M, P, R, pt, H), j(N, P, V, pt, H), H = String.fromCharCode(55349, 57334 + ft), j(M, P, R, pt, H), j(N, P, V, pt, H);
}
for (var mt = "ÐÞþ", ht = 0; ht < mt.length; ht++) {
	var gt = mt.charAt(ht);
	j(M, P, R, gt, gt), j(N, P, V, gt, gt);
}
var _t = {
	mathClass: "mathbf",
	textClass: "textbf",
	font: "Main-Bold"
}, vt = {
	mathClass: "mathnormal",
	textClass: "textit",
	font: "Math-Italic"
}, yt = {
	mathClass: "boldsymbol",
	textClass: "boldsymbol",
	font: "Main-BoldItalic"
}, bt = {
	mathClass: "mathscr",
	textClass: "textscr",
	font: "Script-Regular"
}, xt = {
	mathClass: "",
	textClass: "",
	font: ""
}, St = {
	mathClass: "mathfrak",
	textClass: "textfrak",
	font: "Fraktur-Regular"
}, Ct = {
	mathClass: "mathbb",
	textClass: "textbb",
	font: "AMS-Regular"
}, wt = {
	mathClass: "mathboldfrak",
	textClass: "textboldfrak",
	font: "Fraktur-Regular"
}, Tt = {
	mathClass: "mathsf",
	textClass: "textsf",
	font: "SansSerif-Regular"
}, Et = {
	mathClass: "mathboldsf",
	textClass: "textboldsf",
	font: "SansSerif-Bold"
}, Dt = {
	mathClass: "mathitsf",
	textClass: "textitsf",
	font: "SansSerif-Italic"
}, Ot = {
	mathClass: "mathtt",
	textClass: "texttt",
	font: "Typewriter-Regular"
}, kt = [
	_t,
	_t,
	vt,
	vt,
	yt,
	yt,
	bt,
	xt,
	xt,
	xt,
	St,
	St,
	Ct,
	Ct,
	wt,
	wt,
	Tt,
	Tt,
	Et,
	Et,
	Dt,
	Dt,
	xt,
	xt,
	Ot,
	Ot
], At = [
	_t,
	xt,
	Tt,
	Et,
	Ot
], jt = (t) => {
	var n = t.charCodeAt(0), r = t.charCodeAt(1), i = (n - 55296) * 1024 + (r - 56320) + 65536;
	if (119808 <= i && i < 120484) return kt[Math.floor((i - 119808) / 26)];
	if (120782 <= i && i <= 120831) return At[Math.floor((i - 120782) / 10)];
	if (i === 120485 || i === 120486) return kt[0];
	if (120486 < i && i < 120782) return xt;
	throw new e("Unsupported character: " + t);
}, Mt = function(e, t, n) {
	if (A[n][e]) {
		var r = A[n][e].replace;
		r && (e = r);
	}
	return {
		value: e,
		metrics: qe(e, t, n)
	};
}, Nt = function(e, t, n, r, i) {
	var a = Mt(e, t, n), o = a.metrics;
	e = a.value;
	var s;
	if (o) {
		var c = o.italic;
		(n === "text" || r && r.font === "mathit") && (c = 0), s = new Ie(e, o.height, o.depth, c, o.skew, o.width, i);
	} else typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + n + "'")), s = new Ie(e, 0, 0, 0, 0, 0, i);
	if (r) {
		s.maxFontSize = r.sizeMultiplier, r.style.isTight() && s.classes.push("mtight");
		var l = r.getColor();
		l && (s.style.color = l);
	}
	return s;
}, Pt = function(e, t, n, r) {
	return r === void 0 && (r = []), n.font === "boldsymbol" && Mt(e, "Main-Bold", t).metrics ? Nt(e, "Main-Bold", t, n, r.concat(["mathbf"])) : e === "\\" || A[t][e].font === "main" ? Nt(e, "Main-Regular", t, n, r) : Nt(e, "AMS-Regular", t, n, r.concat(["amsrm"]));
}, Ft = function(e, t, n) {
	return n !== "textord" && Mt(e, "Math-BoldItalic", t).metrics ? {
		fontName: "Math-BoldItalic",
		fontClass: "boldsymbol"
	} : {
		fontName: "Main-Bold",
		fontClass: "mathbf"
	};
}, It = function(e, t, n) {
	var r = e.mode, i = e.text, a = ["mord"], { font: o, fontFamily: s, fontWeight: c, fontShape: l } = t, u = r === "math" || r === "text" && !!o, d = u ? o : s, f = "", p = "";
	if (i.charCodeAt(0) === 55349) {
		var m = jt(i);
		f = m.font, p = m[r + "Class"];
	}
	if (f) return Nt(i, f, r, t, a.concat(p));
	if (d) {
		var h, g;
		if (d === "boldsymbol") {
			var _ = Ft(i, r, n);
			h = _.fontName, g = [_.fontClass];
		} else u ? (h = Jt[o].fontName, g = [o]) : (h = qt(s, c, l), g = [
			s,
			c,
			l
		]);
		if (Mt(i, h, r).metrics) return Nt(i, h, r, t, a.concat(g));
		if (tt.hasOwnProperty(i) && h.slice(0, 10) === "Typewriter") {
			for (var v = [], y = 0; y < i.length; y++) v.push(Nt(i[y], h, r, t, a.concat(g)));
			return Ut(v);
		}
	}
	if (n === "mathord") return Nt(i, "Math-Italic", r, t, a.concat(["mathnormal"]));
	if (n === "textord") {
		var b = A[r][i] && A[r][i].font;
		if (b === "ams") return Nt(i, qt("amsrm", c, l), r, t, a.concat("amsrm", c, l));
		if (b === "main" || !b) return Nt(i, qt("textrm", c, l), r, t, a.concat(c, l));
		var x = qt(b, c, l);
		return Nt(i, x, r, t, a.concat(x, c, l));
	}
	throw Error("unexpected type: " + n + " in makeOrd");
}, Lt = (e, t) => {
	if (Ee(e.classes) !== Ee(t.classes) || e.skew !== t.skew || e.maxFontSize !== t.maxFontSize || e.italic !== 0 && e.hasClass("mathnormal")) return !1;
	if (e.classes.length === 1) {
		var n = e.classes[0];
		if (n === "mbin" || n === "mord") return !1;
	}
	for (var r of Object.keys(e.style)) if (e.style[r] !== t.style[r]) return !1;
	for (var i of Object.keys(t.style)) if (e.style[i] !== t.style[i]) return !1;
	return !0;
}, Rt = (e) => {
	for (var t = 0; t < e.length - 1; t++) {
		var n = e[t], r = e[t + 1];
		n instanceof Ie && r instanceof Ie && Lt(n, r) && (n.text += r.text, n.height = Math.max(n.height, r.height), n.depth = Math.max(n.depth, r.depth), n.italic = r.italic, e.splice(t + 1, 1), t--);
	}
	return e;
}, zt = function(e) {
	for (var t = 0, n = 0, r = 0, i = 0; i < e.children.length; i++) {
		var a = e.children[i];
		a.height > t && (t = a.height), a.depth > n && (n = a.depth), a.maxFontSize > r && (r = a.maxFontSize);
	}
	e.height = t, e.depth = n, e.maxFontSize = r;
}, W = function(e, t, n, r) {
	var i = new Me(e, t, n, r);
	return zt(i), i;
}, Bt = (e, t, n, r) => new Me(e, t, n, r), Vt = function(e, t, n) {
	var r = W([e], [], t);
	return r.height = Math.max(n || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), r.style.borderBottomWidth = k(r.height), r.maxFontSize = 1, r;
}, Ht = function(e, t, n, r) {
	var i = new Ne(e, t, n, r);
	return zt(i), i;
}, Ut = function(e) {
	var t = new Se(e);
	return zt(t), t;
}, Wt = function(e, t) {
	return e instanceof Se ? W([], [e], t) : e;
}, Gt = function(e) {
	if (e.positionType === "individualShift") {
		for (var t = e.children, n = [t[0]], r = -t[0].shift - t[0].elem.depth, i = r, a = 1; a < t.length; a++) {
			var o = -t[a].shift - i - t[a].elem.depth, s = o - (t[a - 1].elem.height + t[a - 1].elem.depth);
			i += o, n.push({
				type: "kern",
				size: s
			}), n.push(t[a]);
		}
		return {
			children: n,
			depth: r
		};
	}
	var c;
	if (e.positionType === "top") {
		for (var l = e.positionData, u = 0; u < e.children.length; u++) {
			var d = e.children[u];
			l -= d.type === "kern" ? d.size : d.elem.height + d.elem.depth;
		}
		c = l;
	} else if (e.positionType === "bottom") c = -e.positionData;
	else {
		var f = e.children[0];
		if (f.type !== "elem") throw Error("First child must have type \"elem\".");
		if (e.positionType === "shift") c = -f.elem.depth - e.positionData;
		else if (e.positionType === "firstBaseline") c = -f.elem.depth;
		else throw Error("Invalid positionType " + e.positionType + ".");
	}
	return {
		children: e.children,
		depth: c
	};
}, G = function(e, t) {
	for (var { children: n, depth: r } = Gt(e), i = 0, a = 0; a < n.length; a++) {
		var o = n[a];
		if (o.type === "elem") {
			var s = o.elem;
			i = Math.max(i, s.maxFontSize, s.height);
		}
	}
	i += 2;
	var c = W(["pstrut"], []);
	c.style.height = k(i);
	for (var l = [], u = r, d = r, f = r, p = 0; p < n.length; p++) {
		var m = n[p];
		if (m.type === "kern") f += m.size;
		else {
			var h = m.elem, g = m.wrapperClasses || [], _ = m.wrapperStyle || {}, v = W(g, [c, h], void 0, _);
			v.style.top = k(-i - f - h.depth), m.marginLeft && (v.style.marginLeft = m.marginLeft), m.marginRight && (v.style.marginRight = m.marginRight), l.push(v), f += h.height + h.depth;
		}
		u = Math.min(u, f), d = Math.max(d, f);
	}
	var y = W(["vlist"], l);
	y.style.height = k(d);
	var b;
	if (u < 0) {
		var x = W(["vlist"], [W([], [])]);
		x.style.height = k(-u), b = [W(["vlist-r"], [y, W(["vlist-s"], [new Ie("​")])]), W(["vlist-r"], [x])];
	} else b = [W(["vlist-r"], [y])];
	var S = W(["vlist-t"], b);
	return b.length === 2 && S.classes.push("vlist-t2"), S.height = d, S.depth = -u, S;
}, Kt = (e, t) => {
	var n = W(["mspace"], [], t), r = O(e, t);
	return n.style.marginRight = k(r), n;
}, qt = (e, t, n) => {
	var r, i;
	switch (e) {
		case "amsrm":
			r = "AMS";
			break;
		case "textrm":
			r = "Main";
			break;
		case "textsf":
			r = "SansSerif";
			break;
		case "texttt":
			r = "Typewriter";
			break;
		default: r = e;
	}
	return i = t === "textbf" && n === "textit" ? "BoldItalic" : t === "textbf" ? "Bold" : n === "textit" ? "Italic" : "Regular", r + "-" + i;
}, Jt = {
	mathbf: {
		variant: "bold",
		fontName: "Main-Bold"
	},
	mathrm: {
		variant: "normal",
		fontName: "Main-Regular"
	},
	textit: {
		variant: "italic",
		fontName: "Main-Italic"
	},
	mathit: {
		variant: "italic",
		fontName: "Main-Italic"
	},
	mathnormal: {
		variant: "italic",
		fontName: "Math-Italic"
	},
	mathsfit: {
		variant: "sans-serif-italic",
		fontName: "SansSerif-Italic"
	},
	mathbb: {
		variant: "double-struck",
		fontName: "AMS-Regular"
	},
	mathcal: {
		variant: "script",
		fontName: "Caligraphic-Regular"
	},
	mathfrak: {
		variant: "fraktur",
		fontName: "Fraktur-Regular"
	},
	mathscr: {
		variant: "script",
		fontName: "Script-Regular"
	},
	mathsf: {
		variant: "sans-serif",
		fontName: "SansSerif-Regular"
	},
	mathtt: {
		variant: "monospace",
		fontName: "Typewriter-Regular"
	}
}, Yt = {
	vec: [
		"vec",
		.471,
		.714
	],
	oiintSize1: [
		"oiintSize1",
		.957,
		.499
	],
	oiintSize2: [
		"oiintSize2",
		1.472,
		.659
	],
	oiiintSize1: [
		"oiiintSize1",
		1.304,
		.499
	],
	oiiintSize2: [
		"oiiintSize2",
		1.98,
		.659
	]
}, Xt = function(e, t) {
	var [n, r, i] = Yt[e], a = Bt(["overlay"], [new Le([new Re(n)], {
		width: k(r),
		height: k(i),
		style: "width:" + k(r),
		viewBox: "0 0 " + 1e3 * r + " " + 1e3 * i,
		preserveAspectRatio: "xMinYMin"
	})], t);
	return a.height = i, a.style.height = k(i), a.style.width = k(r), a;
}, K = {
	number: 3,
	unit: "mu"
}, Zt = {
	number: 4,
	unit: "mu"
}, Qt = {
	number: 5,
	unit: "mu"
}, $t = {
	mord: {
		mop: K,
		mbin: Zt,
		mrel: Qt,
		minner: K
	},
	mop: {
		mord: K,
		mop: K,
		mrel: Qt,
		minner: K
	},
	mbin: {
		mord: Zt,
		mop: Zt,
		mopen: Zt,
		minner: Zt
	},
	mrel: {
		mord: Qt,
		mop: Qt,
		mopen: Qt,
		minner: Qt
	},
	mopen: {},
	mclose: {
		mop: K,
		mbin: Zt,
		mrel: Qt,
		minner: K
	},
	mpunct: {
		mord: K,
		mop: K,
		mrel: Qt,
		mopen: K,
		mclose: K,
		mpunct: K,
		minner: K
	},
	minner: {
		mord: K,
		mop: K,
		mbin: Zt,
		mrel: Qt,
		mopen: K,
		mpunct: K,
		minner: K
	}
}, en = {
	mord: { mop: K },
	mop: {
		mord: K,
		mop: K
	},
	mbin: {},
	mrel: {},
	mopen: {},
	mclose: { mop: K },
	mpunct: {},
	minner: { mop: K }
}, tn = {}, nn = {}, rn = {};
function q(e) {
	for (var { type: t, names: n, props: r, handler: i, htmlBuilder: a, mathmlBuilder: o } = e, s = {
		type: t,
		numArgs: r.numArgs,
		argTypes: r.argTypes,
		allowedInArgument: !!r.allowedInArgument,
		allowedInText: !!r.allowedInText,
		allowedInMath: r.allowedInMath === void 0 || r.allowedInMath,
		numOptionalArgs: r.numOptionalArgs || 0,
		infix: !!r.infix,
		primitive: !!r.primitive,
		handler: i
	}, c = 0; c < n.length; ++c) tn[n[c]] = s;
	t && (a && (nn[t] = a), o && (rn[t] = o));
}
function an(e) {
	var { type: t, htmlBuilder: n, mathmlBuilder: r } = e;
	q({
		type: t,
		names: [],
		props: { numArgs: 0 },
		handler() {
			throw Error("Should never be called.");
		},
		htmlBuilder: n,
		mathmlBuilder: r
	});
}
var on = function(e) {
	return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, J = function(e) {
	return e.type === "ordgroup" ? e.body : [e];
}, sn = /* @__PURE__ */ new Set([
	"leftmost",
	"mbin",
	"mopen",
	"mrel",
	"mop",
	"mpunct"
]), cn = /* @__PURE__ */ new Set([
	"rightmost",
	"mrel",
	"mclose",
	"mpunct"
]), ln = {
	display: E.DISPLAY,
	text: E.TEXT,
	script: E.SCRIPT,
	scriptscript: E.SCRIPTSCRIPT
}, un = {
	mord: "mord",
	mop: "mop",
	mbin: "mbin",
	mrel: "mrel",
	mopen: "mopen",
	mclose: "mclose",
	mpunct: "mpunct",
	minner: "minner"
}, dn = function(e, t, n, r) {
	r === void 0 && (r = [null, null]);
	for (var i = [], a = 0; a < e.length; a++) {
		var o = Y(e[a], t);
		if (o instanceof Se) {
			var s = o.children;
			i.push(...s);
		} else i.push(o);
	}
	if (Rt(i), !n) return i;
	var c = t;
	if (e.length === 1) {
		var l = e[0];
		l.type === "sizing" ? c = t.havingSize(l.size) : l.type === "styling" && (c = t.havingStyle(ln[l.style]));
	}
	var u = W([r[0] || "leftmost"], [], t), d = W([r[1] || "rightmost"], [], t), f = n === "root";
	return fn(i, (e, t) => {
		var n = t.classes[0], r = e.classes[0];
		n === "mbin" && cn.has(r) ? t.classes[0] = "mord" : r === "mbin" && sn.has(n) && (e.classes[0] = "mord");
	}, { node: u }, d, f), fn(i, (e, t) => {
		var n = hn(t), r = hn(e), i = n && r ? e.hasClass("mtight") ? en[n]?.[r] : $t[n]?.[r] : null;
		if (i) return Kt(i, c);
	}, { node: u }, d, f), i;
}, fn = function(e, t, n, r, i) {
	r && e.push(r);
	for (var a = 0; a < e.length; a++) {
		var o = e[a], s = pn(o);
		if (s) {
			fn(s.children, t, n, null, i);
			continue;
		}
		var c = !o.hasClass("mspace");
		if (c) {
			var l = t(o, n.node);
			l && (n.insertAfter ? n.insertAfter(l) : (e.unshift(l), a++));
		}
		c ? n.node = o : i && o.hasClass("newline") && (n.node = W(["leftmost"])), n.insertAfter = /* @__PURE__ */ ((t) => (n) => {
			e.splice(t + 1, 0, n), a++;
		})(a);
	}
	r && e.pop();
}, pn = function(e) {
	return e instanceof Se || e instanceof Ne || e instanceof Me && e.hasClass("enclosing") ? e : null;
}, mn = function(e, t) {
	var n = pn(e);
	if (n) {
		var r = n.children;
		if (r.length) {
			if (t === "right") return mn(r[r.length - 1], "right");
			if (t === "left") return mn(r[0], "left");
		}
	}
	return e;
}, hn = function(e, t) {
	return e ? (t && (e = mn(e, t)), un[e.classes[0]] || null) : null;
}, gn = function(e, t) {
	var n = ["nulldelimiter"].concat(e.baseSizingClasses());
	return W(t.concat(n));
}, Y = function(t, n, r) {
	if (!t) return W();
	if (nn[t.type]) {
		var i = nn[t.type](t, n);
		if (r && n.size !== r.size) {
			i = W(n.sizingClasses(r), [i], n);
			var a = n.sizeMultiplier / r.sizeMultiplier;
			i.height *= a, i.depth *= a;
		}
		return i;
	}
	throw new e("Got group of unknown type: '" + t.type + "'");
};
function _n(e, t) {
	var n = W(["base"], e, t), r = W(["strut"]);
	return r.style.height = k(n.height + n.depth), n.depth && (r.style.verticalAlign = k(-n.depth)), n.children.unshift(r), n;
}
function vn(e, t) {
	var n = null;
	e.length === 1 && e[0].type === "tag" && (n = e[0].tag, e = e[0].body);
	var r = dn(e, t, "root"), i;
	r.length === 2 && r[1].hasClass("tag") && (i = r.pop());
	for (var a = [], o = [], s = 0; s < r.length; s++) if (o.push(r[s]), r[s].hasClass("mbin") || r[s].hasClass("mrel") || r[s].hasClass("allowbreak")) {
		for (var c = !1; s < r.length - 1 && r[s + 1].hasClass("mspace") && !r[s + 1].hasClass("newline");) s++, o.push(r[s]), r[s].hasClass("nobreak") && (c = !0);
		c || (a.push(_n(o, t)), o = []);
	} else r[s].hasClass("newline") && (o.pop(), o.length > 0 && (a.push(_n(o, t)), o = []), a.push(r[s]));
	o.length > 0 && a.push(_n(o, t));
	var l;
	n ? (l = _n(dn(n, t, !0), t), l.classes = ["tag"], a.push(l)) : i && a.push(i);
	var u = W(["katex-html"], a);
	if (u.setAttribute("aria-hidden", "true"), l) {
		var d = l.children[0];
		d.style.height = k(u.height + u.depth), u.depth && (d.style.verticalAlign = k(-u.depth));
	}
	return u;
}
function yn(e) {
	return new Se(e);
}
var X = class {
	constructor(e, t, n) {
		this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = n || [];
	}
	setAttribute(e, t) {
		this.attributes[e] = t;
	}
	getAttribute(e) {
		return this.attributes[e];
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
		for (var t in this.attributes) Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
		this.classes.length > 0 && (e.className = Ee(this.classes));
		for (var n = 0; n < this.children.length; n++) if (this.children[n] instanceof bn && this.children[n + 1] instanceof bn) {
			for (var r = this.children[n].toText() + this.children[++n].toText(); this.children[n + 1] instanceof bn;) r += this.children[++n].toText();
			e.appendChild(new bn(r).toNode());
		} else e.appendChild(this.children[n].toNode());
		return e;
	}
	toMarkup() {
		var e = "<" + this.type;
		for (var t in this.attributes) Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + "=\"", e += a(this.attributes[t]), e += "\"");
		this.classes.length > 0 && (e += " class =\"" + a(Ee(this.classes)) + "\""), e += ">";
		for (var n = 0; n < this.children.length; n++) e += this.children[n].toMarkup();
		return e += "</" + this.type + ">", e;
	}
	toText() {
		return this.children.map((e) => e.toText()).join("");
	}
}, bn = class {
	constructor(e) {
		this.text = void 0, this.text = e;
	}
	toNode() {
		return document.createTextNode(this.text);
	}
	toMarkup() {
		return a(this.toText());
	}
	toText() {
		return this.text;
	}
}, xn = class {
	constructor(e) {
		this.width = void 0, this.character = void 0, this.width = e, this.character = e >= .05555 && e <= .05556 ? " " : e >= .1666 && e <= .1667 ? " " : e >= .2222 && e <= .2223 ? " " : e >= .2777 && e <= .2778 ? "  " : e >= -.05556 && e <= -.05555 ? " ⁣" : e >= -.1667 && e <= -.1666 ? " ⁣" : e >= -.2223 && e <= -.2222 ? " ⁣" : e >= -.2778 && e <= -.2777 ? " ⁣" : null;
	}
	toNode() {
		if (this.character) return document.createTextNode(this.character);
		var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
		return e.setAttribute("width", k(this.width)), e;
	}
	toMarkup() {
		return this.character ? "<mtext>" + this.character + "</mtext>" : "<mspace width=\"" + k(this.width) + "\"/>";
	}
	toText() {
		return this.character ? this.character : " ";
	}
}, Sn = /* @__PURE__ */ new Set(["\\imath", "\\jmath"]), Cn = /* @__PURE__ */ new Set(["mrow", "mtable"]), wn = function(e, t, n) {
	return A[t][e] && A[t][e].replace && e.charCodeAt(0) !== 55349 && !(tt.hasOwnProperty(e) && n && (n.fontFamily && n.fontFamily.slice(4, 6) === "tt" || n.font && n.font.slice(4, 6) === "tt")) && (e = A[t][e].replace), new bn(e);
}, Tn = function(e) {
	return e.length === 1 ? e[0] : new X("mrow", e);
}, En = {
	mathit: "italic",
	boldsymbol: (e) => e.type === "textord" ? "bold" : "bold-italic",
	mathbf: "bold",
	mathbb: "double-struck",
	mathsfit: "sans-serif-italic",
	mathfrak: "fraktur",
	mathscr: "script",
	mathcal: "script",
	mathsf: "sans-serif",
	mathtt: "monospace"
}, Dn = (e, t) => {
	if (e.mode === "text") {
		if (t.fontFamily === "texttt") return "monospace";
		if (t.fontFamily === "textsf") return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
		if (t.fontShape === "textit" && t.fontWeight === "textbf") return "bold-italic";
		if (t.fontShape === "textit") return "italic";
		if (t.fontWeight === "textbf") return "bold";
	}
	var n = t.font;
	if (!n || n === "mathnormal") return null;
	var r = e.mode, i = En[n];
	if (i) return typeof i == "function" ? i(e) : i;
	var a = e.text;
	if (Sn.has(a)) return null;
	if (A[r][a]) {
		var o = A[r][a].replace;
		o && (a = o);
	}
	var s = Jt[n].fontName;
	return qe(a, s, r) ? Jt[n].variant : null;
};
function On(e) {
	if (!e) return !1;
	if (e.type === "mi" && e.children.length === 1) {
		var t = e.children[0];
		return t instanceof bn && t.text === ".";
	}
	if (e.type === "mo" && e.children.length === 1 && e.getAttribute("separator") === "true" && e.getAttribute("lspace") === "0em" && e.getAttribute("rspace") === "0em") {
		var n = e.children[0];
		return n instanceof bn && n.text === ",";
	}
	return !1;
}
var kn = function(e, t, n) {
	if (e.length === 1) {
		var r = Z(e[0], t);
		return n && r instanceof X && r.type === "mo" && (r.setAttribute("lspace", "0em"), r.setAttribute("rspace", "0em")), [r];
	}
	for (var i = [], a, o = 0; o < e.length; o++) {
		var s = Z(e[o], t);
		if (s instanceof X && a instanceof X) {
			if (s.type === "mtext" && a.type === "mtext" && s.getAttribute("mathvariant") === a.getAttribute("mathvariant")) {
				a.children.push(...s.children);
				continue;
			}
			if (s.type === "mn" && a.type === "mn") {
				a.children.push(...s.children);
				continue;
			}
			if (On(s) && a.type === "mn") {
				a.children.push(...s.children);
				continue;
			}
			if (s.type === "mn" && On(a)) s.children = [...a.children, ...s.children], i.pop();
			else if ((s.type === "msup" || s.type === "msub") && s.children.length >= 1 && (a.type === "mn" || On(a))) {
				var c = s.children[0];
				c instanceof X && c.type === "mn" && (c.children = [...a.children, ...c.children], i.pop());
			} else if (a.type === "mi" && a.children.length === 1) {
				var l = a.children[0];
				if (l instanceof bn && l.text === "̸" && (s.type === "mo" || s.type === "mi" || s.type === "mn")) {
					var u = s.children[0];
					u instanceof bn && u.text.length > 0 && (u.text = u.text.slice(0, 1) + "̸" + u.text.slice(1), i.pop());
				}
			}
		}
		i.push(s), a = s;
	}
	return i;
}, An = function(e, t, n) {
	return Tn(kn(e, t, n));
}, Z = function(t, n) {
	if (!t) return new X("mrow");
	if (rn[t.type]) return rn[t.type](t, n);
	throw new e("Got group of unknown type: '" + t.type + "'");
};
function jn(e, t, n, r, i) {
	var a = kn(e, n), o = a.length === 1 && a[0] instanceof X && Cn.has(a[0].type) ? a[0] : new X("mrow", a), s = new X("annotation", [new bn(t)]);
	s.setAttribute("encoding", "application/x-tex");
	var c = new X("math", [new X("semantics", [o, s])]);
	return c.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML"), r && c.setAttribute("display", "block"), W([i ? "katex" : "katex-mathml"], [c]);
}
var Mn = [
	[
		1,
		1,
		1
	],
	[
		2,
		1,
		1
	],
	[
		3,
		1,
		1
	],
	[
		4,
		2,
		1
	],
	[
		5,
		2,
		1
	],
	[
		6,
		3,
		1
	],
	[
		7,
		4,
		2
	],
	[
		8,
		6,
		3
	],
	[
		9,
		7,
		6
	],
	[
		10,
		8,
		7
	],
	[
		11,
		10,
		9
	]
], Nn = [
	.5,
	.6,
	.7,
	.8,
	.9,
	1,
	1.2,
	1.44,
	1.728,
	2.074,
	2.488
], Pn = function(e, t) {
	return t.size < 2 ? e : Mn[e - 1][t.size - 1];
}, Fn = class e {
	constructor(t) {
		this.style = void 0, this.color = void 0, this.size = void 0, this.textSize = void 0, this.phantom = void 0, this.font = void 0, this.fontFamily = void 0, this.fontWeight = void 0, this.fontShape = void 0, this.sizeMultiplier = void 0, this.maxSize = void 0, this.minRuleThickness = void 0, this._fontMetrics = void 0, this.style = t.style, this.color = t.color, this.size = t.size || e.BASESIZE, this.textSize = t.textSize || this.size, this.phantom = !!t.phantom, this.font = t.font || "", this.fontFamily = t.fontFamily || "", this.fontWeight = t.fontWeight || "", this.fontShape = t.fontShape || "", this.sizeMultiplier = Nn[this.size - 1], this.maxSize = t.maxSize, this.minRuleThickness = t.minRuleThickness, this._fontMetrics = void 0;
	}
	extend(t) {
		var n = {
			style: this.style,
			size: this.size,
			textSize: this.textSize,
			color: this.color,
			phantom: this.phantom,
			font: this.font,
			fontFamily: this.fontFamily,
			fontWeight: this.fontWeight,
			fontShape: this.fontShape,
			maxSize: this.maxSize,
			minRuleThickness: this.minRuleThickness
		};
		return Object.assign(n, t), new e(n);
	}
	havingStyle(e) {
		return this.style === e ? this : this.extend({
			style: e,
			size: Pn(this.textSize, e)
		});
	}
	havingCrampedStyle() {
		return this.havingStyle(this.style.cramp());
	}
	havingSize(e) {
		return this.size === e && this.textSize === e ? this : this.extend({
			style: this.style.text(),
			size: e,
			textSize: e,
			sizeMultiplier: Nn[e - 1]
		});
	}
	havingBaseStyle(t) {
		t ||= this.style.text();
		var n = Pn(e.BASESIZE, t);
		return this.size === n && this.textSize === e.BASESIZE && this.style === t ? this : this.extend({
			style: t,
			size: n
		});
	}
	havingBaseSizing() {
		var e;
		switch (this.style.id) {
			case 4:
			case 5:
				e = 3;
				break;
			case 6:
			case 7:
				e = 1;
				break;
			default: e = 6;
		}
		return this.extend({
			style: this.style.text(),
			size: e
		});
	}
	withColor(e) {
		return this.extend({ color: e });
	}
	withPhantom() {
		return this.extend({ phantom: !0 });
	}
	withFont(e) {
		return this.extend({ font: e });
	}
	withTextFontFamily(e) {
		return this.extend({
			fontFamily: e,
			font: ""
		});
	}
	withTextFontWeight(e) {
		return this.extend({
			fontWeight: e,
			font: ""
		});
	}
	withTextFontShape(e) {
		return this.extend({
			fontShape: e,
			font: ""
		});
	}
	sizingClasses(e) {
		return e.size === this.size ? [] : [
			"sizing",
			"reset-size" + e.size,
			"size" + this.size
		];
	}
	baseSizingClasses() {
		return this.size === e.BASESIZE ? [] : [
			"sizing",
			"reset-size" + this.size,
			"size" + e.BASESIZE
		];
	}
	fontMetrics() {
		return this._fontMetrics ||= Ye(this.size), this._fontMetrics;
	}
	getColor() {
		return this.phantom ? "transparent" : this.color;
	}
};
Fn.BASESIZE = 6;
var In = function(e) {
	return new Fn({
		style: e.displayMode ? E.DISPLAY : E.TEXT,
		maxSize: e.maxSize,
		minRuleThickness: e.minRuleThickness
	});
}, Ln = function(e, t) {
	if (t.displayMode) {
		var n = ["katex-display"];
		t.leqno && n.push("leqno"), t.fleqn && n.push("fleqn"), e = W(n, [e]);
	}
	return e;
}, Rn = function(e, t, n) {
	var r = In(n), i;
	return n.output === "mathml" ? jn(e, t, r, n.displayMode, !0) : (i = n.output === "html" ? W(["katex"], [vn(e, r)]) : W(["katex"], [jn(e, t, r, n.displayMode, !1), vn(e, r)]), Ln(i, n));
}, zn = function(e, t, n) {
	return Ln(W(["katex"], [vn(e, In(n))]), n);
}, Bn = {
	widehat: "^",
	widecheck: "ˇ",
	widetilde: "~",
	utilde: "~",
	overleftarrow: "←",
	underleftarrow: "←",
	xleftarrow: "←",
	overrightarrow: "→",
	underrightarrow: "→",
	xrightarrow: "→",
	underbrace: "⏟",
	overbrace: "⏞",
	underbracket: "⎵",
	overbracket: "⎴",
	overgroup: "⏠",
	undergroup: "⏡",
	overleftrightarrow: "↔",
	underleftrightarrow: "↔",
	xleftrightarrow: "↔",
	Overrightarrow: "⇒",
	xRightarrow: "⇒",
	overleftharpoon: "↼",
	xleftharpoonup: "↼",
	overrightharpoon: "⇀",
	xrightharpoonup: "⇀",
	xLeftarrow: "⇐",
	xLeftrightarrow: "⇔",
	xhookleftarrow: "↩",
	xhookrightarrow: "↪",
	xmapsto: "↦",
	xrightharpoondown: "⇁",
	xleftharpoondown: "↽",
	xrightleftharpoons: "⇌",
	xleftrightharpoons: "⇋",
	xtwoheadleftarrow: "↞",
	xtwoheadrightarrow: "↠",
	xlongequal: "=",
	xtofrom: "⇄",
	xrightleftarrows: "⇄",
	xrightequilibrium: "⇌",
	xleftequilibrium: "⇋",
	"\\cdrightarrow": "→",
	"\\cdleftarrow": "←",
	"\\cdlongequal": "="
}, Vn = function(e) {
	var t = new X("mo", [new bn(Bn[e.replace(/^\\/, "")])]);
	return t.setAttribute("stretchy", "true"), t;
}, Hn = {
	overrightarrow: [
		["rightarrow"],
		.888,
		522,
		"xMaxYMin"
	],
	overleftarrow: [
		["leftarrow"],
		.888,
		522,
		"xMinYMin"
	],
	underrightarrow: [
		["rightarrow"],
		.888,
		522,
		"xMaxYMin"
	],
	underleftarrow: [
		["leftarrow"],
		.888,
		522,
		"xMinYMin"
	],
	xrightarrow: [
		["rightarrow"],
		1.469,
		522,
		"xMaxYMin"
	],
	"\\cdrightarrow": [
		["rightarrow"],
		3,
		522,
		"xMaxYMin"
	],
	xleftarrow: [
		["leftarrow"],
		1.469,
		522,
		"xMinYMin"
	],
	"\\cdleftarrow": [
		["leftarrow"],
		3,
		522,
		"xMinYMin"
	],
	Overrightarrow: [
		["doublerightarrow"],
		.888,
		560,
		"xMaxYMin"
	],
	xRightarrow: [
		["doublerightarrow"],
		1.526,
		560,
		"xMaxYMin"
	],
	xLeftarrow: [
		["doubleleftarrow"],
		1.526,
		560,
		"xMinYMin"
	],
	overleftharpoon: [
		["leftharpoon"],
		.888,
		522,
		"xMinYMin"
	],
	xleftharpoonup: [
		["leftharpoon"],
		.888,
		522,
		"xMinYMin"
	],
	xleftharpoondown: [
		["leftharpoondown"],
		.888,
		522,
		"xMinYMin"
	],
	overrightharpoon: [
		["rightharpoon"],
		.888,
		522,
		"xMaxYMin"
	],
	xrightharpoonup: [
		["rightharpoon"],
		.888,
		522,
		"xMaxYMin"
	],
	xrightharpoondown: [
		["rightharpoondown"],
		.888,
		522,
		"xMaxYMin"
	],
	xlongequal: [
		["longequal"],
		.888,
		334,
		"xMinYMin"
	],
	"\\cdlongequal": [
		["longequal"],
		3,
		334,
		"xMinYMin"
	],
	xtwoheadleftarrow: [
		["twoheadleftarrow"],
		.888,
		334,
		"xMinYMin"
	],
	xtwoheadrightarrow: [
		["twoheadrightarrow"],
		.888,
		334,
		"xMaxYMin"
	],
	overleftrightarrow: [
		["leftarrow", "rightarrow"],
		.888,
		522
	],
	overbrace: [
		[
			"leftbrace",
			"midbrace",
			"rightbrace"
		],
		1.6,
		548
	],
	underbrace: [
		[
			"leftbraceunder",
			"midbraceunder",
			"rightbraceunder"
		],
		1.6,
		548
	],
	underleftrightarrow: [
		["leftarrow", "rightarrow"],
		.888,
		522
	],
	xleftrightarrow: [
		["leftarrow", "rightarrow"],
		1.75,
		522
	],
	xLeftrightarrow: [
		["doubleleftarrow", "doublerightarrow"],
		1.75,
		560
	],
	xrightleftharpoons: [
		["leftharpoondownplus", "rightharpoonplus"],
		1.75,
		716
	],
	xleftrightharpoons: [
		["leftharpoonplus", "rightharpoondownplus"],
		1.75,
		716
	],
	xhookleftarrow: [
		["leftarrow", "righthook"],
		1.08,
		522
	],
	xhookrightarrow: [
		["lefthook", "rightarrow"],
		1.08,
		522
	],
	overlinesegment: [
		["leftlinesegment", "rightlinesegment"],
		.888,
		522
	],
	underlinesegment: [
		["leftlinesegment", "rightlinesegment"],
		.888,
		522
	],
	overbracket: [
		["leftbracketover", "rightbracketover"],
		1.6,
		440
	],
	underbracket: [
		["leftbracketunder", "rightbracketunder"],
		1.6,
		410
	],
	overgroup: [
		["leftgroup", "rightgroup"],
		.888,
		342
	],
	undergroup: [
		["leftgroupunder", "rightgroupunder"],
		.888,
		342
	],
	xmapsto: [
		["leftmapsto", "rightarrow"],
		1.5,
		522
	],
	xtofrom: [
		["leftToFrom", "rightToFrom"],
		1.75,
		528
	],
	xrightleftarrows: [
		["baraboveleftarrow", "rightarrowabovebar"],
		1.75,
		901
	],
	xrightequilibrium: [
		["baraboveshortleftharpoon", "rightharpoonaboveshortbar"],
		1.75,
		716
	],
	xleftequilibrium: [
		["shortbaraboveleftharpoon", "shortrightharpoonabovebar"],
		1.75,
		716
	]
}, Un = /* @__PURE__ */ new Set([
	"widehat",
	"widecheck",
	"widetilde",
	"utilde"
]), Wn = function(e, t) {
	function n() {
		var n = 4e5, r = e.label.slice(1);
		if (Un.has(r) && "base" in e) {
			var i = e.base.type === "ordgroup" ? e.base.body.length : 1, a, o, s;
			if (i > 5) r === "widehat" || r === "widecheck" ? (a = 420, n = 2364, s = .42, o = r + "4") : (a = 312, n = 2340, s = .34, o = "tilde4");
			else {
				var c = [
					1,
					1,
					2,
					2,
					3,
					3
				][i];
				r === "widehat" || r === "widecheck" ? (n = [
					0,
					1062,
					2364,
					2364,
					2364
				][c], a = [
					0,
					239,
					300,
					360,
					420
				][c], s = [
					0,
					.24,
					.3,
					.3,
					.36,
					.42
				][c], o = r + c) : (n = [
					0,
					600,
					1033,
					2339,
					2340
				][c], a = [
					0,
					260,
					286,
					306,
					312
				][c], s = [
					0,
					.26,
					.286,
					.3,
					.306,
					.34
				][c], o = "tilde" + c);
			}
			return {
				span: Bt([], [new Le([new Re(o)], {
					width: "100%",
					height: k(s),
					viewBox: "0 0 " + n + " " + a,
					preserveAspectRatio: "none"
				})], t),
				minWidth: 0,
				height: s
			};
		}
		var l = [], u = Hn[r];
		if (!u) throw Error("No SVG data for \"" + r + "\".");
		var [d, f, p] = u, m = p / 1e3, h = d.length, g, _;
		if (h === 1) {
			if (u.length !== 4) throw Error("Expected 4-tuple for single-path SVG data \"" + r + "\".");
			g = ["hide-tail"], _ = [u[3]];
		} else if (h === 2) g = ["halfarrow-left", "halfarrow-right"], _ = ["xMinYMin", "xMaxYMin"];
		else if (h === 3) g = [
			"brace-left",
			"brace-center",
			"brace-right"
		], _ = [
			"xMinYMin",
			"xMidYMin",
			"xMaxYMin"
		];
		else throw Error("Correct katexImagesData or update code here to support\n                    " + h + " children.");
		for (var v = 0; v < h; v++) {
			var y = new Le([new Re(d[v])], {
				width: "400em",
				height: k(m),
				viewBox: "0 0 " + n + " " + p,
				preserveAspectRatio: _[v] + " slice"
			}), b = Bt([g[v]], [y], t);
			if (h === 1) return {
				span: b,
				minWidth: f,
				height: m
			};
			b.style.height = k(m), l.push(b);
		}
		return {
			span: W(["stretchy"], l, t),
			minWidth: f,
			height: m
		};
	}
	var { span: r, minWidth: i, height: a } = n();
	return r.height = a, r.style.height = k(a), i > 0 && (r.style.minWidth = k(i)), r;
}, Gn = function(e, t, n, r, i) {
	var a, o = e.height + e.depth + n + r;
	if (/fbox|color|angl/.test(t)) {
		if (a = W(["stretchy", t], [], i), t === "fbox") {
			var s = i.color && i.getColor();
			s && (a.style.borderColor = s);
		}
	} else {
		var c = [];
		/^[bx]cancel$/.test(t) && c.push(new ze({
			x1: "0",
			y1: "0",
			x2: "100%",
			y2: "100%",
			"stroke-width": "0.046em"
		})), /^x?cancel$/.test(t) && c.push(new ze({
			x1: "0",
			y1: "100%",
			x2: "100%",
			y2: "0",
			"stroke-width": "0.046em"
		})), a = Bt([], [new Le(c, {
			width: "100%",
			height: k(o)
		})], i);
	}
	return a.height = o, a.style.height = k(o), a;
}, Kn = {
	bin: 1,
	close: 1,
	inner: 1,
	open: 1,
	punct: 1,
	rel: 1
}, qn = {
	"accent-token": 1,
	mathord: 1,
	"op-token": 1,
	spacing: 1,
	textord: 1
};
function Jn(e) {
	return e in Kn;
}
function Q(e, t) {
	if (!e || e.type !== t) throw Error("Expected node of type " + t + ", but got " + (e ? "node of type " + e.type : String(e)));
	return e;
}
function Yn(e) {
	var t = Xn(e);
	if (!t) throw Error("Expected node of symbol group type, but got " + (e ? "node of type " + e.type : String(e)));
	return t;
}
function Xn(e) {
	return e && (e.type === "atom" || qn.hasOwnProperty(e.type)) ? e : null;
}
var Zn = (e) => {
	if (e instanceof Ie) return e;
	if (He(e) && e.children.length === 1) return Zn(e.children[0]);
}, Qn = (e, t) => {
	var n, r, i;
	e && e.type === "supsub" ? (r = Q(e.base, "accent"), n = r.base, e.base = n, i = Ve(Y(e, t)), e.base = r) : (r = Q(e, "accent"), n = r.base);
	var a = Y(n, t.havingCrampedStyle()), o = r.isShifty && c(n), s = 0;
	o && (s = Zn(a)?.skew ?? 0);
	var l = r.label === "\\c", u = l ? a.height + a.depth : Math.min(a.height, t.fontMetrics().xHeight), d;
	if (r.isStretchy) d = Wn(r, t), d = G({
		positionType: "firstBaseline",
		children: [{
			type: "elem",
			elem: a
		}, {
			type: "elem",
			elem: d,
			wrapperClasses: ["svg-align"],
			wrapperStyle: s > 0 ? {
				width: "calc(100% - " + k(2 * s) + ")",
				marginLeft: k(2 * s)
			} : void 0
		}]
	});
	else {
		var f, p;
		r.label === "\\vec" ? (f = Xt("vec", t), p = Yt.vec[1]) : (f = It({
			mode: r.mode,
			text: r.label
		}, t, "textord"), f = Be(f), f.italic = 0, p = f.width, l && (u += f.depth)), d = W(["accent-body"], [f]);
		var m = r.label === "\\textcircled";
		m && (d.classes.push("accent-full"), u = a.height);
		var h = s;
		m || (h -= p / 2), d.style.left = k(h), r.label === "\\textcircled" && (d.style.top = ".2em"), d = G({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: a
				},
				{
					type: "kern",
					size: -u
				},
				{
					type: "elem",
					elem: d
				}
			]
		});
	}
	var g = W(["mord", "accent"], [d], t);
	return i ? (i.children[0] = g, i.height = Math.max(g.height, i.height), i.classes[0] = "mord", i) : g;
}, $n = (e, t) => {
	var n = e.isStretchy ? Vn(e.label) : new X("mo", [wn(e.label, e.mode)]), r = new X("mover", [Z(e.base, t), n]);
	return r.setAttribute("accent", "true"), r;
}, er = new RegExp([
	"\\acute",
	"\\grave",
	"\\ddot",
	"\\tilde",
	"\\bar",
	"\\breve",
	"\\check",
	"\\hat",
	"\\vec",
	"\\dot",
	"\\mathring"
].map((e) => "\\" + e).join("|"));
q({
	type: "accent",
	names: [
		"\\acute",
		"\\grave",
		"\\ddot",
		"\\tilde",
		"\\bar",
		"\\breve",
		"\\check",
		"\\hat",
		"\\vec",
		"\\dot",
		"\\mathring",
		"\\widecheck",
		"\\widehat",
		"\\widetilde",
		"\\overrightarrow",
		"\\overleftarrow",
		"\\Overrightarrow",
		"\\overleftrightarrow",
		"\\overgroup",
		"\\overlinesegment",
		"\\overleftharpoon",
		"\\overrightharpoon"
	],
	props: { numArgs: 1 },
	handler: (e, t) => {
		var n = on(t[0]), r = !er.test(e.funcName), i = !r || e.funcName === "\\widehat" || e.funcName === "\\widetilde" || e.funcName === "\\widecheck";
		return {
			type: "accent",
			mode: e.parser.mode,
			label: e.funcName,
			isStretchy: r,
			isShifty: i,
			base: n
		};
	},
	htmlBuilder: Qn,
	mathmlBuilder: $n
}), q({
	type: "accent",
	names: [
		"\\'",
		"\\`",
		"\\^",
		"\\~",
		"\\=",
		"\\u",
		"\\.",
		"\\\"",
		"\\c",
		"\\r",
		"\\H",
		"\\v",
		"\\textcircled"
	],
	props: {
		numArgs: 1,
		allowedInText: !0,
		allowedInMath: !0,
		argTypes: ["primitive"]
	},
	handler: (e, t) => {
		var n = t[0], r = e.parser.mode;
		return r === "math" && (e.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + e.funcName + " works only in text mode"), r = "text"), {
			type: "accent",
			mode: r,
			label: e.funcName,
			isStretchy: !1,
			isShifty: !0,
			base: n
		};
	},
	htmlBuilder: Qn,
	mathmlBuilder: $n
}), q({
	type: "accentUnder",
	names: [
		"\\underleftarrow",
		"\\underrightarrow",
		"\\underleftrightarrow",
		"\\undergroup",
		"\\underlinesegment",
		"\\utilde"
	],
	props: { numArgs: 1 },
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "accentUnder",
			mode: n.mode,
			label: r,
			base: i
		};
	},
	htmlBuilder: (e, t) => {
		var n = Y(e.base, t), r = Wn(e, t), i = e.label === "\\utilde" ? .12 : 0;
		return W(["mord", "accentunder"], [G({
			positionType: "top",
			positionData: n.height,
			children: [
				{
					type: "elem",
					elem: r,
					wrapperClasses: ["svg-align"]
				},
				{
					type: "kern",
					size: i
				},
				{
					type: "elem",
					elem: n
				}
			]
		})], t);
	},
	mathmlBuilder: (e, t) => {
		var n = Vn(e.label), r = new X("munder", [Z(e.base, t), n]);
		return r.setAttribute("accentunder", "true"), r;
	}
});
var tr = (e) => {
	var t = new X("mpadded", e ? [e] : []);
	return t.setAttribute("width", "+0.6em"), t.setAttribute("lspace", "0.3em"), t;
};
q({
	type: "xArrow",
	names: [
		"\\xleftarrow",
		"\\xrightarrow",
		"\\xLeftarrow",
		"\\xRightarrow",
		"\\xleftrightarrow",
		"\\xLeftrightarrow",
		"\\xhookleftarrow",
		"\\xhookrightarrow",
		"\\xmapsto",
		"\\xrightharpoondown",
		"\\xrightharpoonup",
		"\\xleftharpoondown",
		"\\xleftharpoonup",
		"\\xrightleftharpoons",
		"\\xleftrightharpoons",
		"\\xlongequal",
		"\\xtwoheadrightarrow",
		"\\xtwoheadleftarrow",
		"\\xtofrom",
		"\\xrightleftarrows",
		"\\xrightequilibrium",
		"\\xleftequilibrium",
		"\\\\cdrightarrow",
		"\\\\cdleftarrow",
		"\\\\cdlongequal"
	],
	props: {
		numArgs: 1,
		numOptionalArgs: 1
	},
	handler(e, t, n) {
		var { parser: r, funcName: i } = e;
		return {
			type: "xArrow",
			mode: r.mode,
			label: i,
			body: t[0],
			below: n[0]
		};
	},
	htmlBuilder(e, t) {
		var n = t.style, r = t.havingStyle(n.sup()), i = Wt(Y(e.body, r, t), t), a = e.label.slice(0, 2) === "\\x" ? "x" : "cd";
		i.classes.push(a + "-arrow-pad");
		var o;
		e.below && (r = t.havingStyle(n.sub()), o = Wt(Y(e.below, r, t), t), o.classes.push(a + "-arrow-pad"));
		var s = Wn(e, t), c = -t.fontMetrics().axisHeight + .5 * s.height, l = -t.fontMetrics().axisHeight - .5 * s.height - .111;
		(i.depth > .25 || e.label === "\\xleftequilibrium") && (l -= i.depth);
		var u;
		if (o) {
			var d = -t.fontMetrics().axisHeight + o.height + .5 * s.height + .111;
			u = G({
				positionType: "individualShift",
				children: [
					{
						type: "elem",
						elem: i,
						shift: l
					},
					{
						type: "elem",
						elem: s,
						shift: c,
						wrapperClasses: ["svg-align"]
					},
					{
						type: "elem",
						elem: o,
						shift: d
					}
				]
			});
		} else u = G({
			positionType: "individualShift",
			children: [{
				type: "elem",
				elem: i,
				shift: l
			}, {
				type: "elem",
				elem: s,
				shift: c,
				wrapperClasses: ["svg-align"]
			}]
		});
		return W(["mrel", "x-arrow"], [u], t);
	},
	mathmlBuilder(e, t) {
		var n = Vn(e.label);
		n.setAttribute("minsize", e.label.charAt(0) === "x" ? "1.75em" : "3.0em");
		var r;
		if (e.body) {
			var i = tr(Z(e.body, t));
			r = e.below ? new X("munderover", [
				n,
				tr(Z(e.below, t)),
				i
			]) : new X("mover", [n, i]);
		} else e.below ? r = new X("munder", [n, tr(Z(e.below, t))]) : (r = tr(), r = new X("mover", [n, r]));
		return r;
	}
});
function nr(e, t) {
	var n = dn(e.body, t, !0);
	return W([e.mclass], n, t);
}
function rr(e, t) {
	var n, r = kn(e.body, t);
	return e.mclass === "minner" ? n = new X("mpadded", r) : e.mclass === "mord" ? e.isCharacterBox ? (n = r[0], n.type = "mi") : n = new X("mi", r) : (e.isCharacterBox ? (n = r[0], n.type = "mo") : n = new X("mo", r), e.mclass === "mbin" ? (n.attributes.lspace = "0.22em", n.attributes.rspace = "0.22em") : e.mclass === "mpunct" ? (n.attributes.lspace = "0em", n.attributes.rspace = "0.17em") : e.mclass === "mopen" || e.mclass === "mclose" ? (n.attributes.lspace = "0em", n.attributes.rspace = "0em") : e.mclass === "minner" && (n.attributes.lspace = "0.0556em", n.attributes.width = "+0.1111em")), n;
}
q({
	type: "mclass",
	names: [
		"\\mathord",
		"\\mathbin",
		"\\mathrel",
		"\\mathopen",
		"\\mathclose",
		"\\mathpunct",
		"\\mathinner"
	],
	props: {
		numArgs: 1,
		primitive: !0
	},
	handler(e, t) {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "mclass",
			mode: n.mode,
			mclass: "m" + r.slice(5),
			body: J(i),
			isCharacterBox: c(i)
		};
	},
	htmlBuilder: nr,
	mathmlBuilder: rr
});
var ir = (e) => {
	var t = e.type === "ordgroup" && e.body.length ? e.body[0] : e;
	return t.type === "atom" && (t.family === "bin" || t.family === "rel") ? "m" + t.family : "mord";
};
q({
	type: "mclass",
	names: ["\\@binrel"],
	props: { numArgs: 2 },
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "mclass",
			mode: n.mode,
			mclass: ir(t[0]),
			body: J(t[1]),
			isCharacterBox: c(t[1])
		};
	}
}), q({
	type: "mclass",
	names: [
		"\\stackrel",
		"\\overset",
		"\\underset"
	],
	props: { numArgs: 2 },
	handler(e, t) {
		var { parser: n, funcName: r } = e, i = t[1], a = t[0], o = r === "\\stackrel" ? "mrel" : ir(i), s = {
			type: "op",
			mode: i.mode,
			limits: !0,
			alwaysHandleSupSub: !0,
			parentIsSupSub: !1,
			symbol: !1,
			suppressBaseShift: r !== "\\stackrel",
			body: J(i)
		}, l = {
			type: "supsub",
			mode: a.mode,
			base: s,
			sup: r === "\\underset" ? null : a,
			sub: r === "\\underset" ? a : null
		};
		return {
			type: "mclass",
			mode: n.mode,
			mclass: o,
			body: [l],
			isCharacterBox: c(l)
		};
	},
	htmlBuilder: nr,
	mathmlBuilder: rr
}), q({
	type: "pmb",
	names: ["\\pmb"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "pmb",
			mode: n.mode,
			mclass: ir(t[0]),
			body: J(t[0])
		};
	},
	htmlBuilder(e, t) {
		var n = dn(e.body, t, !0), r = W([e.mclass], n, t);
		return r.style.textShadow = "0.02em 0.01em 0.04px", r;
	},
	mathmlBuilder(e, t) {
		var n = new X("mstyle", kn(e.body, t));
		return n.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), n;
	}
});
var ar = {
	">": "\\\\cdrightarrow",
	"<": "\\\\cdleftarrow",
	"=": "\\\\cdlongequal",
	A: "\\uparrow",
	V: "\\downarrow",
	"|": "\\Vert",
	".": "no arrow"
}, or = () => ({
	type: "styling",
	body: [],
	mode: "math",
	style: "display",
	resetFont: !0
}), sr = (e) => e.type === "textord" && e.text === "@", cr = (e, t) => (e.type === "mathord" || e.type === "atom") && e.text === t;
function lr(e, t, n) {
	var r = ar[e];
	switch (r) {
		case "\\\\cdrightarrow":
		case "\\\\cdleftarrow": return n.callFunction(r, [t[0]], [t[1]]);
		case "\\uparrow":
		case "\\downarrow":
			var i = n.callFunction("\\\\cdleft", [t[0]], []), a = {
				type: "atom",
				text: r,
				mode: "math",
				family: "rel"
			}, o = {
				type: "ordgroup",
				mode: "math",
				body: [
					i,
					n.callFunction("\\Big", [a], []),
					n.callFunction("\\\\cdright", [t[1]], [])
				]
			};
			return n.callFunction("\\\\cdparent", [o], []);
		case "\\\\cdlongequal": return n.callFunction("\\\\cdlongequal", [], []);
		case "\\Vert": return n.callFunction("\\Big", [{
			type: "textord",
			text: "\\Vert",
			mode: "math"
		}], []);
		default: return {
			type: "textord",
			text: " ",
			mode: "math"
		};
	}
}
function ur(t) {
	var n = [];
	for (t.gullet.beginGroup(), t.gullet.macros.set("\\cr", "\\\\\\relax"), t.gullet.beginGroup();;) {
		n.push(t.parseExpression(!1, "\\\\")), t.gullet.endGroup(), t.gullet.beginGroup();
		var r = t.fetch().text;
		if (r === "&" || r === "\\\\") t.consume();
		else if (r === "\\end") {
			n[n.length - 1].length === 0 && n.pop();
			break;
		} else throw new e("Expected \\\\ or \\cr or \\end", t.nextToken);
	}
	for (var i = [], a = [i], o = 0; o < n.length; o++) {
		for (var s = n[o], c = or(), l = 0; l < s.length; l++) if (!sr(s[l])) c.body.push(s[l]);
		else {
			i.push(c), l += 1;
			var u = Yn(s[l]).text, d = [, ,];
			if (d[0] = {
				type: "ordgroup",
				mode: "math",
				body: []
			}, d[1] = {
				type: "ordgroup",
				mode: "math",
				body: []
			}, !"=|.".includes(u)) {
				if ("<>AV".includes(u)) for (var f = 0; f < 2; f++) {
					for (var p = !0, m = l + 1; m < s.length; m++) {
						if (cr(s[m], u)) {
							p = !1, l = m;
							break;
						}
						if (sr(s[m])) throw new e("Missing a " + u + " character to complete a CD arrow.", s[m]);
						d[f].body.push(s[m]);
					}
					if (p) throw new e("Missing a " + u + " character to complete a CD arrow.", s[l]);
				}
				else throw new e("Expected one of \"<>AV=|.\" after @", s[l]);
			}
			var h = {
				type: "styling",
				body: [lr(u, d, t)],
				mode: "math",
				style: "display",
				resetFont: !0
			};
			i.push(h), c = or();
		}
		o % 2 == 0 ? i.push(c) : i.shift(), i = [], a.push(i);
	}
	return t.gullet.endGroup(), t.gullet.endGroup(), {
		type: "array",
		mode: "math",
		body: a,
		arraystretch: 1,
		addJot: !0,
		rowGaps: [null],
		cols: Array(a[0].length).fill({
			type: "align",
			align: "c",
			pregap: .25,
			postgap: .25
		}),
		colSeparationType: "CD",
		hLinesBeforeRow: Array(a.length + 1).fill([])
	};
}
q({
	type: "cdlabel",
	names: ["\\\\cdleft", "\\\\cdright"],
	props: { numArgs: 1 },
	handler(e, t) {
		var { parser: n, funcName: r } = e;
		return {
			type: "cdlabel",
			mode: n.mode,
			side: r.slice(4),
			label: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = t.havingStyle(t.style.sup()), r = Wt(Y(e.label, n, t), t);
		return r.classes.push("cd-label-" + e.side), r.style.bottom = k(.8 - r.depth), r.height = 0, r.depth = 0, r;
	},
	mathmlBuilder(e, t) {
		var n = new X("mrow", [Z(e.label, t)]);
		return n = new X("mpadded", [n]), n.setAttribute("width", "0"), e.side === "left" && n.setAttribute("lspace", "-1width"), n.setAttribute("voffset", "0.7em"), n = new X("mstyle", [n]), n.setAttribute("displaystyle", "false"), n.setAttribute("scriptlevel", "1"), n;
	}
}), q({
	type: "cdlabelparent",
	names: ["\\\\cdparent"],
	props: { numArgs: 1 },
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "cdlabelparent",
			mode: n.mode,
			fragment: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = Wt(Y(e.fragment, t), t);
		return n.classes.push("cd-vert-arrow"), n;
	},
	mathmlBuilder(e, t) {
		return new X("mrow", [Z(e.fragment, t)]);
	}
}), q({
	type: "textord",
	names: ["\\@char"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler(t, n) {
		for (var { parser: r } = t, i = Q(n[0], "ordgroup").body, a = "", o = 0; o < i.length; o++) {
			var s = Q(i[o], "textord");
			a += s.text;
		}
		var c = parseInt(a), l;
		if (isNaN(c)) throw new e("\\@char has non-numeric argument " + a);
		if (c < 0 || c >= 1114111) throw new e("\\@char with invalid code point " + a);
		return c <= 65535 ? l = String.fromCharCode(c) : (c -= 65536, l = String.fromCharCode((c >> 10) + 55296, (c & 1023) + 56320)), {
			type: "textord",
			mode: r.mode,
			text: l
		};
	}
});
var dr = (e, t) => Ut(dn(e.body, t.withColor(e.color), !1)), fr = (e, t) => {
	var n = new X("mstyle", kn(e.body, t.withColor(e.color)));
	return n.setAttribute("mathcolor", e.color), n;
};
q({
	type: "color",
	names: ["\\textcolor"],
	props: {
		numArgs: 2,
		allowedInText: !0,
		argTypes: ["color", "original"]
	},
	handler(e, t) {
		var { parser: n } = e, r = Q(t[0], "color-token").color, i = t[1];
		return {
			type: "color",
			mode: n.mode,
			color: r,
			body: J(i)
		};
	},
	htmlBuilder: dr,
	mathmlBuilder: fr
}), q({
	type: "color",
	names: ["\\color"],
	props: {
		numArgs: 1,
		allowedInText: !0,
		argTypes: ["color"]
	},
	handler(e, t) {
		var { parser: n, breakOnTokenText: r } = e, i = Q(t[0], "color-token").color;
		n.gullet.macros.set("\\current@color", i);
		var a = n.parseExpression(!0, r);
		return {
			type: "color",
			mode: n.mode,
			color: i,
			body: a
		};
	},
	htmlBuilder: dr,
	mathmlBuilder: fr
}), q({
	type: "cr",
	names: ["\\\\"],
	props: {
		numArgs: 0,
		numOptionalArgs: 0,
		allowedInText: !0
	},
	handler(e, t, n) {
		var { parser: r } = e, i = r.gullet.future().text === "[" ? r.parseSizeGroup(!0) : null, a = !r.settings.displayMode || !r.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
		return {
			type: "cr",
			mode: r.mode,
			newLine: a,
			size: i && Q(i, "size").value
		};
	},
	htmlBuilder(e, t) {
		var n = W(["mspace"], [], t);
		return e.newLine && (n.classes.push("newline"), e.size && (n.style.marginTop = k(O(e.size, t)))), n;
	},
	mathmlBuilder(e, t) {
		var n = new X("mspace");
		return e.newLine && (n.setAttribute("linebreak", "newline"), e.size && n.setAttribute("height", k(O(e.size, t)))), n;
	}
});
var pr = {
	"\\global": "\\global",
	"\\long": "\\\\globallong",
	"\\\\globallong": "\\\\globallong",
	"\\def": "\\gdef",
	"\\gdef": "\\gdef",
	"\\edef": "\\xdef",
	"\\xdef": "\\xdef",
	"\\let": "\\\\globallet",
	"\\futurelet": "\\\\globalfuture"
}, mr = (t) => {
	var n = t.text;
	if (/^(?:[\\{}$&#^_]|EOF)$/.test(n)) throw new e("Expected a control sequence", t);
	return n;
}, hr = (e) => {
	var t = e.gullet.popToken();
	return t.text === "=" && (t = e.gullet.popToken(), t.text === " " && (t = e.gullet.popToken())), t;
}, gr = (e, t, n, r) => {
	var i = e.gullet.macros.get(n.text);
	i ??= (n.noexpand = !0, {
		tokens: [n],
		numArgs: 0,
		unexpandable: !e.gullet.isExpandable(n.text)
	}), e.gullet.macros.set(t, i, r);
};
q({
	type: "internal",
	names: [
		"\\global",
		"\\long",
		"\\\\globallong"
	],
	props: {
		numArgs: 0,
		allowedInText: !0
	},
	handler(t) {
		var { parser: n, funcName: r } = t;
		n.consumeSpaces();
		var i = n.fetch();
		if (pr[i.text]) return (r === "\\global" || r === "\\\\globallong") && (i.text = pr[i.text]), Q(n.parseFunction(), "internal");
		throw new e("Invalid token after macro prefix", i);
	}
}), q({
	type: "internal",
	names: [
		"\\def",
		"\\gdef",
		"\\edef",
		"\\xdef"
	],
	props: {
		numArgs: 0,
		allowedInText: !0,
		primitive: !0
	},
	handler(t) {
		var { parser: n, funcName: r } = t, i = n.gullet.popToken(), a = i.text;
		if (/^(?:[\\{}$&#^_]|EOF)$/.test(a)) throw new e("Expected a control sequence", i);
		for (var o = 0, s, c = [[]]; n.gullet.future().text !== "{";) if (i = n.gullet.popToken(), i.text === "#") {
			if (n.gullet.future().text === "{") {
				s = n.gullet.future(), c[o].push("{");
				break;
			}
			if (i = n.gullet.popToken(), !/^[1-9]$/.test(i.text)) throw new e("Invalid argument number \"" + i.text + "\"");
			if (parseInt(i.text) !== o + 1) throw new e("Argument number \"" + i.text + "\" out of order");
			o++, c.push([]);
		} else {
			if (i.text === "EOF") throw new e("Expected a macro definition");
			c[o].push(i.text);
		}
		var { tokens: l } = n.gullet.consumeArg();
		return s && l.unshift(s), (r === "\\edef" || r === "\\xdef") && (l = n.gullet.expandTokens(l), l.reverse()), n.gullet.macros.set(a, {
			tokens: l,
			numArgs: o,
			delimiters: c
		}, r === pr[r]), {
			type: "internal",
			mode: n.mode
		};
	}
}), q({
	type: "internal",
	names: ["\\let", "\\\\globallet"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		primitive: !0
	},
	handler(e) {
		var { parser: t, funcName: n } = e, r = mr(t.gullet.popToken());
		return t.gullet.consumeSpaces(), gr(t, r, hr(t), n === "\\\\globallet"), {
			type: "internal",
			mode: t.mode
		};
	}
}), q({
	type: "internal",
	names: ["\\futurelet", "\\\\globalfuture"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		primitive: !0
	},
	handler(e) {
		var { parser: t, funcName: n } = e, r = mr(t.gullet.popToken()), i = t.gullet.popToken(), a = t.gullet.popToken();
		return gr(t, r, a, n === "\\\\globalfuture"), t.gullet.pushToken(a), t.gullet.pushToken(i), {
			type: "internal",
			mode: t.mode
		};
	}
});
var _r = function(e, t, n) {
	var r = qe(A.math[e] && A.math[e].replace || e, t, n);
	if (!r) throw Error("Unsupported symbol " + e + " and font size " + t + ".");
	return r;
}, vr = function(e, t, n, r) {
	var i = n.havingBaseStyle(t), a = W(r.concat(i.sizingClasses(n)), [e], n), o = i.sizeMultiplier / n.sizeMultiplier;
	return a.height *= o, a.depth *= o, a.maxFontSize = i.sizeMultiplier, a;
}, yr = function(e, t, n) {
	var r = t.havingBaseStyle(n), i = (1 - t.sizeMultiplier / r.sizeMultiplier) * t.fontMetrics().axisHeight;
	e.classes.push("delimcenter"), e.style.top = k(i), e.height -= i, e.depth += i;
}, br = function(e, t, n, r, i, a) {
	var o = vr(Nt(e, "Main-Regular", i, r), t, r, a);
	return yr(o, r, t), o;
}, xr = function(e, t, n, r) {
	return Nt(e, "Size" + t + "-Regular", n, r);
}, Sr = function(e, t, n, r, i, a) {
	var o = xr(e, t, i, r), s = vr(W(["delimsizing", "size" + t], [o], r), E.TEXT, r, a);
	return n && yr(s, r, E.TEXT), s;
}, Cr = function(e, t, n) {
	return {
		type: "elem",
		elem: W(["delimsizinginner", t === "Size1-Regular" ? "delim-size1" : "delim-size4"], [W([], [Nt(e, t, n)])])
	};
}, wr = function(e, t, n) {
	var r = Ue["Size4-Regular"][e.charCodeAt(0)] ? Ue["Size4-Regular"][e.charCodeAt(0)][4] : Ue["Size1-Regular"][e.charCodeAt(0)][4], i = Bt([], [new Le([new Re("inner", ve(e, Math.round(1e3 * t)))], {
		width: k(r),
		height: k(t),
		style: "width:" + k(r),
		viewBox: "0 0 " + 1e3 * r + " " + Math.round(1e3 * t),
		preserveAspectRatio: "xMinYMin"
	})], n);
	return i.height = t, i.style.height = k(t), i.style.width = k(r), {
		type: "elem",
		elem: i
	};
}, Tr = .008, Er = {
	type: "kern",
	size: -1 * Tr
}, Dr = /* @__PURE__ */ new Set([
	"|",
	"\\lvert",
	"\\rvert",
	"\\vert"
]), Or = /* @__PURE__ */ new Set([
	"\\|",
	"\\lVert",
	"\\rVert",
	"\\Vert"
]), kr = function(e, t, n, r, i, a) {
	var o, s, c, l, u = "", d = 0;
	o = c = l = e, s = null;
	var f = "Size1-Regular";
	e === "\\uparrow" ? c = l = "⏐" : e === "\\Uparrow" ? c = l = "‖" : e === "\\downarrow" ? o = c = "⏐" : e === "\\Downarrow" ? o = c = "‖" : e === "\\updownarrow" ? (o = "\\uparrow", c = "⏐", l = "\\downarrow") : e === "\\Updownarrow" ? (o = "\\Uparrow", c = "‖", l = "\\Downarrow") : Dr.has(e) ? (c = "∣", u = "vert", d = 333) : Or.has(e) ? (c = "∥", u = "doublevert", d = 556) : e === "[" || e === "\\lbrack" ? (o = "⎡", c = "⎢", l = "⎣", f = "Size4-Regular", u = "lbrack", d = 667) : e === "]" || e === "\\rbrack" ? (o = "⎤", c = "⎥", l = "⎦", f = "Size4-Regular", u = "rbrack", d = 667) : e === "\\lfloor" || e === "⌊" ? (c = o = "⎢", l = "⎣", f = "Size4-Regular", u = "lfloor", d = 667) : e === "\\lceil" || e === "⌈" ? (o = "⎡", c = l = "⎢", f = "Size4-Regular", u = "lceil", d = 667) : e === "\\rfloor" || e === "⌋" ? (c = o = "⎥", l = "⎦", f = "Size4-Regular", u = "rfloor", d = 667) : e === "\\rceil" || e === "⌉" ? (o = "⎤", c = l = "⎥", f = "Size4-Regular", u = "rceil", d = 667) : e === "(" || e === "\\lparen" ? (o = "⎛", c = "⎜", l = "⎝", f = "Size4-Regular", u = "lparen", d = 875) : e === ")" || e === "\\rparen" ? (o = "⎞", c = "⎟", l = "⎠", f = "Size4-Regular", u = "rparen", d = 875) : e === "\\{" || e === "\\lbrace" ? (o = "⎧", s = "⎨", l = "⎩", c = "⎪", f = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (o = "⎫", s = "⎬", l = "⎭", c = "⎪", f = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (o = "⎧", l = "⎩", c = "⎪", f = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (o = "⎫", l = "⎭", c = "⎪", f = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (o = "⎧", l = "⎭", c = "⎪", f = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (o = "⎫", l = "⎩", c = "⎪", f = "Size4-Regular");
	var p = _r(o, f, i), m = p.height + p.depth, h = _r(c, f, i), g = h.height + h.depth, _ = _r(l, f, i), v = _.height + _.depth, y = 0, b = 1;
	if (s !== null) {
		var x = _r(s, f, i);
		y = x.height + x.depth, b = 2;
	}
	var S = m + v + y, C = S + Math.max(0, Math.ceil((t - S) / (b * g))) * b * g, w = r.fontMetrics().axisHeight;
	n && (w *= r.sizeMultiplier);
	var ee = C / 2 - w, T = [];
	if (u.length > 0) {
		var te = C - m - v, ne = Math.round(C * 1e3), re = be(u, Math.round(te * 1e3)), ie = new Re(u, re), ae = k(d / 1e3), oe = k(ne / 1e3), se = Bt([], [new Le([ie], {
			width: ae,
			height: oe,
			viewBox: "0 0 " + d + " " + ne
		})], r);
		se.height = ne / 1e3, se.style.width = ae, se.style.height = oe, T.push({
			type: "elem",
			elem: se
		});
	} else {
		if (T.push(Cr(l, f, i)), T.push(Er), s === null) {
			var ce = C - m - v + 2 * Tr;
			T.push(wr(c, ce, r));
		} else {
			var D = (C - m - v - y) / 2 + 2 * Tr;
			T.push(wr(c, D, r)), T.push(Er), T.push(Cr(s, f, i)), T.push(Er), T.push(wr(c, D, r));
		}
		T.push(Er), T.push(Cr(o, f, i));
	}
	var le = r.havingBaseStyle(E.TEXT);
	return vr(W(["delimsizing", "mult"], [G({
		positionType: "bottom",
		positionData: ee,
		children: T
	})], le), E.TEXT, r, a);
}, Ar = 80, jr = .08, Mr = function(e, t, n, r, i) {
	return Bt(["hide-tail"], [new Le([new Re(e, _e(e, r, n))], {
		width: "400em",
		height: k(t),
		viewBox: "0 0 400000 " + n,
		preserveAspectRatio: "xMinYMin slice"
	})], i);
}, Nr = function(e, t) {
	var n = t.havingBaseSizing(), r = Ur("\\surd", e * n.sizeMultiplier, Vr, n), i = n.sizeMultiplier, a = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), o, s, c, l, u;
	return r.type === "small" ? (l = 1e3 + 1e3 * a + Ar, e < 1 ? i = 1 : e < 1.4 && (i = .7), s = (1 + a + jr) / i, c = (1 + a) / i, o = Mr("sqrtMain", s, l, a, t), o.style.minWidth = "0.853em", u = .833 / i) : r.type === "large" ? (l = (1e3 + Ar) * Lr[r.size], c = (Lr[r.size] + a) / i, s = (Lr[r.size] + a + jr) / i, o = Mr("sqrtSize" + r.size, s, l, a, t), o.style.minWidth = "1.02em", u = 1 / i) : (s = e + a + jr, c = e + a, l = Math.floor(1e3 * e + a) + Ar, o = Mr("sqrtTall", s, l, a, t), o.style.minWidth = "0.742em", u = 1.056), o.height = c, o.style.height = k(s), {
		span: o,
		advanceWidth: u,
		ruleWidth: (t.fontMetrics().sqrtRuleThickness + a) * i
	};
}, Pr = /* @__PURE__ */ new Set([
	"(",
	"\\lparen",
	")",
	"\\rparen",
	"[",
	"\\lbrack",
	"]",
	"\\rbrack",
	"\\{",
	"\\lbrace",
	"\\}",
	"\\rbrace",
	"\\lfloor",
	"\\rfloor",
	"⌊",
	"⌋",
	"\\lceil",
	"\\rceil",
	"⌈",
	"⌉",
	"\\surd"
]), Fr = /* @__PURE__ */ new Set([
	"\\uparrow",
	"\\downarrow",
	"\\updownarrow",
	"\\Uparrow",
	"\\Downarrow",
	"\\Updownarrow",
	"|",
	"\\|",
	"\\vert",
	"\\Vert",
	"\\lvert",
	"\\rvert",
	"\\lVert",
	"\\rVert",
	"\\lgroup",
	"\\rgroup",
	"⟮",
	"⟯",
	"\\lmoustache",
	"\\rmoustache",
	"⎰",
	"⎱"
]), Ir = /* @__PURE__ */ new Set([
	"<",
	">",
	"\\langle",
	"\\rangle",
	"/",
	"\\backslash",
	"\\lt",
	"\\gt"
]), Lr = [
	0,
	1.2,
	1.8,
	2.4,
	3
], Rr = function(t, n, r, i, a) {
	if (t === "<" || t === "\\lt" || t === "⟨" ? t = "\\langle" : (t === ">" || t === "\\gt" || t === "⟩") && (t = "\\rangle"), Pr.has(t) || Ir.has(t)) return Sr(t, n, !1, r, i, a);
	if (Fr.has(t)) return kr(t, Lr[n], !1, r, i, a);
	throw new e("Illegal delimiter: '" + t + "'");
}, zr = [
	{
		type: "small",
		style: E.SCRIPTSCRIPT
	},
	{
		type: "small",
		style: E.SCRIPT
	},
	{
		type: "small",
		style: E.TEXT
	},
	{
		type: "large",
		size: 1
	},
	{
		type: "large",
		size: 2
	},
	{
		type: "large",
		size: 3
	},
	{
		type: "large",
		size: 4
	}
], Br = [
	{
		type: "small",
		style: E.SCRIPTSCRIPT
	},
	{
		type: "small",
		style: E.SCRIPT
	},
	{
		type: "small",
		style: E.TEXT
	},
	{ type: "stack" }
], Vr = [
	{
		type: "small",
		style: E.SCRIPTSCRIPT
	},
	{
		type: "small",
		style: E.SCRIPT
	},
	{
		type: "small",
		style: E.TEXT
	},
	{
		type: "large",
		size: 1
	},
	{
		type: "large",
		size: 2
	},
	{
		type: "large",
		size: 3
	},
	{
		type: "large",
		size: 4
	},
	{ type: "stack" }
], Hr = function(e) {
	if (e.type === "small") return "Main-Regular";
	if (e.type === "large") return "Size" + e.size + "-Regular";
	if (e.type === "stack") return "Size4-Regular";
	var t = e.type;
	throw Error("Add support for delim type '" + t + "' here.");
}, Ur = function(e, t, n, r) {
	for (var i = Math.min(2, 3 - r.style.size); i < n.length; i++) {
		var a = n[i];
		if (a.type === "stack") break;
		var o = _r(e, Hr(a), "math"), s = o.height + o.depth;
		if (a.type === "small") {
			var c = r.havingBaseStyle(a.style);
			s *= c.sizeMultiplier;
		}
		if (s > t) return a;
	}
	return n[n.length - 1];
}, Wr = function(e, t, n, r, i, a) {
	e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
	var o = Ir.has(e) ? zr : Pr.has(e) ? Vr : Br, s = Ur(e, t, o, r);
	return s.type === "small" ? br(e, s.style, n, r, i, a) : s.type === "large" ? Sr(e, s.size, n, r, i, a) : kr(e, t, n, r, i, a);
}, Gr = function(e, t, n, r, i, a) {
	var o = r.fontMetrics().axisHeight * r.sizeMultiplier, s = 901, c = 5 / r.fontMetrics().ptPerEm, l = Math.max(t - o, n + o);
	return Wr(e, Math.max(l / 500 * s, 2 * l - c), !0, r, i, a);
}, Kr = {
	"\\bigl": {
		mclass: "mopen",
		size: 1
	},
	"\\Bigl": {
		mclass: "mopen",
		size: 2
	},
	"\\biggl": {
		mclass: "mopen",
		size: 3
	},
	"\\Biggl": {
		mclass: "mopen",
		size: 4
	},
	"\\bigr": {
		mclass: "mclose",
		size: 1
	},
	"\\Bigr": {
		mclass: "mclose",
		size: 2
	},
	"\\biggr": {
		mclass: "mclose",
		size: 3
	},
	"\\Biggr": {
		mclass: "mclose",
		size: 4
	},
	"\\bigm": {
		mclass: "mrel",
		size: 1
	},
	"\\Bigm": {
		mclass: "mrel",
		size: 2
	},
	"\\biggm": {
		mclass: "mrel",
		size: 3
	},
	"\\Biggm": {
		mclass: "mrel",
		size: 4
	},
	"\\big": {
		mclass: "mord",
		size: 1
	},
	"\\Big": {
		mclass: "mord",
		size: 2
	},
	"\\bigg": {
		mclass: "mord",
		size: 3
	},
	"\\Bigg": {
		mclass: "mord",
		size: 4
	}
}, qr = /* @__PURE__ */ new Set(/* @__PURE__ */ "(,\\lparen,),\\rparen,[,\\lbrack,],\\rbrack,\\{,\\lbrace,\\},\\rbrace,\\lfloor,\\rfloor,⌊,⌋,\\lceil,\\rceil,⌈,⌉,<,>,\\langle,⟨,\\rangle,⟩,\\lt,\\gt,\\lvert,\\rvert,\\lVert,\\rVert,\\lgroup,\\rgroup,⟮,⟯,\\lmoustache,\\rmoustache,⎰,⎱,/,\\backslash,|,\\vert,\\|,\\Vert,\\uparrow,\\Uparrow,\\downarrow,\\Downarrow,\\updownarrow,\\Updownarrow,.".split(","));
function Jr(e) {
	return "isMiddle" in e;
}
function Yr(t, n) {
	var r = Xn(t);
	if (r && qr.has(r.text)) return r;
	throw r ? new e("Invalid delimiter '" + r.text + "' after '" + n.funcName + "'", t) : new e("Invalid delimiter type '" + t.type + "'", t);
}
q({
	type: "delimsizing",
	names: [
		"\\bigl",
		"\\Bigl",
		"\\biggl",
		"\\Biggl",
		"\\bigr",
		"\\Bigr",
		"\\biggr",
		"\\Biggr",
		"\\bigm",
		"\\Bigm",
		"\\biggm",
		"\\Biggm",
		"\\big",
		"\\Big",
		"\\bigg",
		"\\Bigg"
	],
	props: {
		numArgs: 1,
		argTypes: ["primitive"]
	},
	handler: (e, t) => {
		var n = Yr(t[0], e);
		return {
			type: "delimsizing",
			mode: e.parser.mode,
			size: Kr[e.funcName].size,
			mclass: Kr[e.funcName].mclass,
			delim: n.text
		};
	},
	htmlBuilder: (e, t) => e.delim === "." ? W([e.mclass]) : Rr(e.delim, e.size, t, e.mode, [e.mclass]),
	mathmlBuilder: (e) => {
		var t = [];
		e.delim !== "." && t.push(wn(e.delim, e.mode));
		var n = new X("mo", t);
		e.mclass === "mopen" || e.mclass === "mclose" ? n.setAttribute("fence", "true") : n.setAttribute("fence", "false"), n.setAttribute("stretchy", "true");
		var r = k(Lr[e.size]);
		return n.setAttribute("minsize", r), n.setAttribute("maxsize", r), n;
	}
});
function Xr(e) {
	if (!e.body) throw Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
q({
	type: "leftright-right",
	names: ["\\right"],
	props: {
		numArgs: 1,
		primitive: !0
	},
	handler: (t, n) => {
		var r = t.parser.gullet.macros.get("\\current@color");
		if (r && typeof r != "string") throw new e("\\current@color set to non-string in \\right");
		return {
			type: "leftright-right",
			mode: t.parser.mode,
			delim: Yr(n[0], t).text,
			color: r
		};
	}
}), q({
	type: "leftright",
	names: ["\\left"],
	props: {
		numArgs: 1,
		primitive: !0
	},
	handler: (e, t) => {
		var n = Yr(t[0], e), r = e.parser;
		++r.leftrightDepth;
		var i = r.parseExpression(!1);
		--r.leftrightDepth, r.expect("\\right", !1);
		var a = Q(r.parseFunction(), "leftright-right");
		return {
			type: "leftright",
			mode: r.mode,
			body: i,
			left: n.text,
			right: a.delim,
			rightColor: a.color
		};
	},
	htmlBuilder: (e, t) => {
		Xr(e);
		for (var n = dn(e.body, t, !0, ["mopen", "mclose"]), r = 0, i = 0, a = !1, o = 0; o < n.length; o++) {
			var s = n[o];
			Jr(s) ? a = !0 : (r = Math.max(n[o].height, r), i = Math.max(n[o].depth, i));
		}
		r *= t.sizeMultiplier, i *= t.sizeMultiplier;
		var c;
		if (c = e.left === "." ? gn(t, ["mopen"]) : Gr(e.left, r, i, t, e.mode, ["mopen"]), n.unshift(c), a) for (var l = 1; l < n.length; l++) {
			var u = n[l];
			if (Jr(u)) {
				var d = u.isMiddle;
				n[l] = Gr(d.delim, r, i, d.options, e.mode, []);
			}
		}
		var f;
		if (e.right === ".") f = gn(t, ["mclose"]);
		else {
			var p = e.rightColor ? t.withColor(e.rightColor) : t;
			f = Gr(e.right, r, i, p, e.mode, ["mclose"]);
		}
		return n.push(f), W(["minner"], n, t);
	},
	mathmlBuilder: (e, t) => {
		Xr(e);
		var n = kn(e.body, t);
		if (e.left !== ".") {
			var r = new X("mo", [wn(e.left, e.mode)]);
			r.setAttribute("fence", "true"), n.unshift(r);
		}
		if (e.right !== ".") {
			var i = new X("mo", [wn(e.right, e.mode)]);
			i.setAttribute("fence", "true"), e.rightColor && i.setAttribute("mathcolor", e.rightColor), n.push(i);
		}
		return Tn(n);
	}
}), q({
	type: "middle",
	names: ["\\middle"],
	props: {
		numArgs: 1,
		primitive: !0
	},
	handler: (t, n) => {
		var r = Yr(n[0], t);
		if (!t.parser.leftrightDepth) throw new e("\\middle without preceding \\left", r);
		return {
			type: "middle",
			mode: t.parser.mode,
			delim: r.text
		};
	},
	htmlBuilder: (e, t) => {
		var n;
		return e.delim === "." ? n = gn(t, []) : (n = Rr(e.delim, 1, t, e.mode, []), n.isMiddle = {
			delim: e.delim,
			options: t
		}), n;
	},
	mathmlBuilder: (e, t) => {
		var n = new X("mo", [e.delim === "\\vert" || e.delim === "|" ? wn("|", "text") : wn(e.delim, e.mode)]);
		return n.setAttribute("fence", "true"), n.setAttribute("lspace", "0.05em"), n.setAttribute("rspace", "0.05em"), n;
	}
});
var Zr = (e, t) => {
	var n = Wt(Y(e.body, t), t), r = e.label.slice(1), i = t.sizeMultiplier, a, o, s = c(e.body);
	if (r === "sout") a = W(["stretchy", "sout"]), a.height = t.fontMetrics().defaultRuleThickness / i, o = -.5 * t.fontMetrics().xHeight;
	else if (r === "phase") {
		var l = O({
			number: .6,
			unit: "pt"
		}, t), u = O({
			number: .35,
			unit: "ex"
		}, t), d = t.havingBaseSizing();
		i /= d.sizeMultiplier;
		var f = n.height + n.depth + l + u;
		n.style.paddingLeft = k(f / 2 + l);
		var p = Math.floor(1e3 * f * i);
		a = Bt(["hide-tail"], [new Le([new Re("phase", he(p))], {
			width: "400em",
			height: k(p / 1e3),
			viewBox: "0 0 400000 " + p,
			preserveAspectRatio: "xMinYMin slice"
		})], t), a.style.height = k(f), o = n.depth + l + u;
	} else {
		/cancel/.test(r) ? s || n.classes.push("cancel-pad") : r === "angl" ? n.classes.push("anglpad") : n.classes.push("boxpad");
		var m, h, g = 0;
		/box/.test(r) ? (g = Math.max(t.fontMetrics().fboxrule, t.minRuleThickness), m = t.fontMetrics().fboxsep + (r === "colorbox" ? 0 : g), h = m) : r === "angl" ? (g = Math.max(t.fontMetrics().defaultRuleThickness, t.minRuleThickness), m = 4 * g, h = Math.max(0, .25 - n.depth)) : (m = s ? .2 : 0, h = m), a = Gn(n, r, m, h, t), /fbox|boxed|fcolorbox/.test(r) ? (a.style.borderStyle = "solid", a.style.borderWidth = k(g)) : r === "angl" && g !== .049 && (a.style.borderTopWidth = k(g), a.style.borderRightWidth = k(g)), o = n.depth + h, e.backgroundColor && (a.style.backgroundColor = e.backgroundColor, e.borderColor && (a.style.borderColor = e.borderColor));
	}
	var _;
	if (e.backgroundColor) _ = G({
		positionType: "individualShift",
		children: [{
			type: "elem",
			elem: a,
			shift: o
		}, {
			type: "elem",
			elem: n,
			shift: 0
		}]
	});
	else {
		var v = /cancel|phase/.test(r) ? ["svg-align"] : [];
		_ = G({
			positionType: "individualShift",
			children: [{
				type: "elem",
				elem: n,
				shift: 0
			}, {
				type: "elem",
				elem: a,
				shift: o,
				wrapperClasses: v
			}]
		});
	}
	return /cancel/.test(r) && (_.height = n.height, _.depth = n.depth), /cancel/.test(r) && !s ? W(["mord", "cancel-lap"], [_], t) : W(["mord"], [_], t);
}, Qr = (e, t) => {
	var n, r = new X(e.label.includes("colorbox") ? "mpadded" : "menclose", [Z(e.body, t)]);
	switch (e.label) {
		case "\\cancel":
			r.setAttribute("notation", "updiagonalstrike");
			break;
		case "\\bcancel":
			r.setAttribute("notation", "downdiagonalstrike");
			break;
		case "\\phase":
			r.setAttribute("notation", "phasorangle");
			break;
		case "\\sout":
			r.setAttribute("notation", "horizontalstrike");
			break;
		case "\\fbox":
			r.setAttribute("notation", "box");
			break;
		case "\\angl":
			r.setAttribute("notation", "actuarial");
			break;
		case "\\fcolorbox":
		case "\\colorbox":
			if (n = t.fontMetrics().fboxsep * t.fontMetrics().ptPerEm, r.setAttribute("width", "+" + 2 * n + "pt"), r.setAttribute("height", "+" + 2 * n + "pt"), r.setAttribute("lspace", n + "pt"), r.setAttribute("voffset", n + "pt"), e.label === "\\fcolorbox") {
				var i = Math.max(t.fontMetrics().fboxrule, t.minRuleThickness);
				r.setAttribute("style", "border: " + k(i) + " solid " + e.borderColor);
			}
			break;
		case "\\xcancel": r.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
	}
	return e.backgroundColor && r.setAttribute("mathbackground", e.backgroundColor), r;
};
q({
	type: "enclose",
	names: ["\\colorbox"],
	props: {
		numArgs: 2,
		allowedInText: !0,
		argTypes: ["color", "hbox"]
	},
	handler(e, t, n) {
		var { parser: r, funcName: i } = e, a = Q(t[0], "color-token").color, o = t[1];
		return {
			type: "enclose",
			mode: r.mode,
			label: i,
			backgroundColor: a,
			body: o
		};
	},
	htmlBuilder: Zr,
	mathmlBuilder: Qr
}), q({
	type: "enclose",
	names: ["\\fcolorbox"],
	props: {
		numArgs: 3,
		allowedInText: !0,
		argTypes: [
			"color",
			"color",
			"hbox"
		]
	},
	handler(e, t, n) {
		var { parser: r, funcName: i } = e, a = Q(t[0], "color-token").color, o = Q(t[1], "color-token").color, s = t[2];
		return {
			type: "enclose",
			mode: r.mode,
			label: i,
			backgroundColor: o,
			borderColor: a,
			body: s
		};
	},
	htmlBuilder: Zr,
	mathmlBuilder: Qr
}), q({
	type: "enclose",
	names: ["\\fbox"],
	props: {
		numArgs: 1,
		argTypes: ["hbox"],
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "enclose",
			mode: n.mode,
			label: "\\fbox",
			body: t[0]
		};
	}
}), q({
	type: "enclose",
	names: [
		"\\cancel",
		"\\bcancel",
		"\\xcancel",
		"\\phase"
	],
	props: { numArgs: 1 },
	handler(e, t) {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "enclose",
			mode: n.mode,
			label: r,
			body: i
		};
	},
	htmlBuilder: Zr,
	mathmlBuilder: Qr
}), q({
	type: "enclose",
	names: ["\\sout"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n, funcName: r } = e;
		n.mode === "math" && n.settings.reportNonstrict("mathVsSout", "LaTeX's \\sout works only in text mode");
		var i = t[0];
		return {
			type: "enclose",
			mode: n.mode,
			label: r,
			body: i
		};
	},
	htmlBuilder: Zr,
	mathmlBuilder: Qr
}), q({
	type: "enclose",
	names: ["\\angl"],
	props: {
		numArgs: 1,
		argTypes: ["hbox"],
		allowedInText: !1
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "enclose",
			mode: n.mode,
			label: "\\angl",
			body: t[0]
		};
	}
});
var $r = {};
function ei(e) {
	for (var { type: t, names: n, props: r, handler: i, htmlBuilder: a, mathmlBuilder: o } = e, s = {
		type: t,
		numArgs: r.numArgs || 0,
		allowedInText: !1,
		numOptionalArgs: 0,
		handler: i
	}, c = 0; c < n.length; ++c) $r[n[c]] = s;
	a && (nn[t] = a), o && (rn[t] = o);
}
var ti = {};
function $(e, t) {
	ti[e] = t;
}
var ni = class e {
	constructor(e, t, n) {
		this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = n;
	}
	static range(t, n) {
		return n ? !t || !t.loc || !n.loc || t.loc.lexer !== n.loc.lexer ? null : new e(t.loc.lexer, t.loc.start, n.loc.end) : t && t.loc;
	}
}, ri = class e {
	constructor(e, t) {
		this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
	}
	range(t, n) {
		return new e(n, ni.range(this, t));
	}
};
function ii(e) {
	var t = [];
	e.consumeSpaces();
	var n = e.fetch().text;
	for (n === "\\relax" && (e.consume(), e.consumeSpaces(), n = e.fetch().text); n === "\\hline" || n === "\\hdashline";) e.consume(), t.push(n === "\\hdashline"), e.consumeSpaces(), n = e.fetch().text;
	return t;
}
var ai = (t) => {
	if (!t.parser.settings.displayMode) throw new e("{" + t.envName + "} can be used only in display mode.");
}, oi = /* @__PURE__ */ new Set(["gather", "gather*"]);
function si(e) {
	if (!e.includes("ed")) return !e.includes("*");
}
function ci(t, n, r) {
	var { hskipBeforeAndAfter: i, addJot: a, cols: o, arraystretch: s, colSeparationType: c, autoTag: l, singleRow: u, emptySingleRow: d, maxNumCols: f, leqno: p } = n;
	if (t.gullet.beginGroup(), u || t.gullet.macros.set("\\cr", "\\\\\\relax"), !s) {
		var m = t.gullet.expandMacroAsText("\\arraystretch");
		if (m == null) s = 1;
		else if (s = parseFloat(m), !s || s < 0) throw new e("Invalid \\arraystretch: " + m);
	}
	t.gullet.beginGroup();
	var h = [], g = [h], _ = [], v = [], y = l == null ? void 0 : [];
	function b() {
		l && t.gullet.macros.set("\\@eqnsw", "1", !0);
	}
	function x() {
		y && (t.gullet.macros.get("\\df@tag") ? (y.push(t.subparse([new ri("\\df@tag")])), t.gullet.macros.set("\\df@tag", void 0, !0)) : y.push(!!l && t.gullet.macros.get("\\@eqnsw") === "1"));
	}
	for (b(), v.push(ii(t));;) {
		var S = t.parseExpression(!1, u ? "\\end" : "\\\\");
		t.gullet.endGroup(), t.gullet.beginGroup();
		var C = {
			type: "ordgroup",
			mode: t.mode,
			body: S
		};
		r && (C = {
			type: "styling",
			mode: t.mode,
			style: r,
			resetFont: !0,
			body: [C]
		}), h.push(C);
		var w = t.fetch().text;
		if (w === "&") {
			if (f && h.length === f) {
				if (u || c) throw new e("Too many tab characters: &", t.nextToken);
				t.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
			}
			t.consume();
		} else if (w === "\\end") {
			x(), h.length === 1 && C.type === "styling" && C.body.length === 1 && C.body[0].type === "ordgroup" && C.body[0].body.length === 0 && (g.length > 1 || !d) && g.pop(), v.length < g.length + 1 && v.push([]);
			break;
		} else if (w === "\\\\") {
			t.consume();
			var ee = void 0;
			t.gullet.future().text !== " " && (ee = t.parseSizeGroup(!0)), _.push(ee ? ee.value : null), x(), v.push(ii(t)), h = [], g.push(h), b();
		} else throw new e("Expected & or \\\\ or \\cr or \\end", t.nextToken);
	}
	return t.gullet.endGroup(), t.gullet.endGroup(), {
		type: "array",
		mode: t.mode,
		addJot: a,
		arraystretch: s,
		body: g,
		cols: o,
		rowGaps: _,
		hskipBeforeAndAfter: i,
		hLinesBeforeRow: v,
		colSeparationType: c,
		tags: y,
		leqno: p
	};
}
function li(e) {
	return e.slice(0, 1) === "d" ? "display" : "text";
}
var ui = function(t, n) {
	var r, i, a = t.body.length, o = t.hLinesBeforeRow, s = 0, c = Array(a), l = [], u = Math.max(n.fontMetrics().arrayRuleWidth, n.minRuleThickness), d = 1 / n.fontMetrics().ptPerEm, f = 5 * d;
	t.colSeparationType && t.colSeparationType === "small" && (f = .2778 * (n.havingStyle(E.SCRIPT).sizeMultiplier / n.sizeMultiplier));
	var p = t.colSeparationType === "CD" ? O({
		number: 3,
		unit: "ex"
	}, n) : 12 * d, m = 3 * d, h = t.arraystretch * p, g = .7 * h, _ = .3 * h, v = 0;
	function y(e) {
		for (var t = 0; t < e.length; ++t) t > 0 && (v += .25), l.push({
			pos: v,
			isDashed: e[t]
		});
	}
	for (y(o[0]), r = 0; r < t.body.length; ++r) {
		var b = t.body[r], x = g, S = _;
		s < b.length && (s = b.length);
		var C = {
			cells: Array(b.length),
			height: 0,
			depth: 0,
			pos: 0
		};
		for (i = 0; i < b.length; ++i) {
			var w = Y(b[i], n);
			S < w.depth && (S = w.depth), x < w.height && (x = w.height), C.cells[i] = w;
		}
		var ee = t.rowGaps[r], T = 0;
		ee && (T = O(ee, n), T > 0 && (T += _, S < T && (S = T), T = 0)), t.addJot && r < t.body.length - 1 && (S += m), C.height = x, C.depth = S, v += x, C.pos = v, v += S + T, c[r] = C, y(o[r + 1]);
	}
	var te = v / 2 + n.fontMetrics().axisHeight, ne = t.cols || [], re = [], ie, ae, oe = [];
	if (t.tags && t.tags.some((e) => e)) for (r = 0; r < a; ++r) {
		var se = c[r], ce = se.pos - te, D = t.tags[r], le = void 0;
		le = D === !0 ? W(["eqn-num"], [], n) : D === !1 ? W([], [], n) : W([], dn(D, n, !0), n), le.depth = se.depth, le.height = se.height, oe.push({
			type: "elem",
			elem: le,
			shift: ce
		});
	}
	for (i = 0, ae = 0; i < s || ae < ne.length; ++i, ++ae) {
		for (var ue = ne[ae], de = !0; (fe = ue)?.type === "separator";) {
			var fe;
			if (de || (ie = W(["arraycolsep"], []), ie.style.width = k(n.fontMetrics().doubleRuleSep), re.push(ie)), ue.separator === "|" || ue.separator === ":") {
				var pe = ue.separator === "|" ? "solid" : "dashed", me = W(["vertical-separator"], [], n);
				me.style.height = k(v), me.style.borderRightWidth = k(u), me.style.borderRightStyle = pe, me.style.margin = "0 " + k(-u / 2);
				var he = v - te;
				he && (me.style.verticalAlign = k(-he)), re.push(me);
			} else throw new e("Invalid separator type: " + ue.separator);
			ae++, ue = ne[ae], de = !1;
		}
		if (!(i >= s)) {
			var ge = void 0;
			(i > 0 || t.hskipBeforeAndAfter) && (ge = ue?.pregap ?? f, ge !== 0 && (ie = W(["arraycolsep"], []), ie.style.width = k(ge), re.push(ie)));
			var _e = [];
			for (r = 0; r < a; ++r) {
				var ve = c[r], ye = ve.cells[i];
				if (ye) {
					var be = ve.pos - te;
					ye.depth = ve.depth, ye.height = ve.height, _e.push({
						type: "elem",
						elem: ye,
						shift: be
					});
				}
			}
			var xe = G({
				positionType: "individualShift",
				children: _e
			}), Se = W(["col-align-" + (ue?.align || "c")], [xe]);
			re.push(Se), (i < s - 1 || t.hskipBeforeAndAfter) && (ge = ue?.postgap ?? f, ge !== 0 && (ie = W(["arraycolsep"], []), ie.style.width = k(ge), re.push(ie)));
		}
	}
	var Ce = W(["mtable"], re);
	if (l.length > 0) {
		for (var we = Vt("hline", n, u), Te = Vt("hdashline", n, u), Ee = [{
			type: "elem",
			elem: Ce,
			shift: 0
		}]; l.length > 0;) {
			var De = l.pop(), Oe = De.pos - te;
			De.isDashed ? Ee.push({
				type: "elem",
				elem: Te,
				shift: Oe
			}) : Ee.push({
				type: "elem",
				elem: we,
				shift: Oe
			});
		}
		Ce = G({
			positionType: "individualShift",
			children: Ee
		});
	}
	if (oe.length === 0) return W(["mord"], [Ce], n);
	var ke = W(["tag"], [G({
		positionType: "individualShift",
		children: oe
	})], n);
	return Ut([Ce, ke]);
}, di = {
	c: "center ",
	l: "left ",
	r: "right "
}, fi = function(e, t) {
	for (var n = [], r = new X("mtd", [], ["mtr-glue"]), i = new X("mtd", [], ["mml-eqn-num"]), a = 0; a < e.body.length; a++) {
		for (var o = e.body[a], s = [], c = 0; c < o.length; c++) s.push(new X("mtd", [Z(o[c], t)]));
		e.tags && e.tags[a] && (s.unshift(r), s.push(r), e.leqno ? s.unshift(i) : s.push(i)), n.push(new X("mtr", s));
	}
	var l = new X("mtable", n), u = e.arraystretch === .5 ? .1 : .16 + e.arraystretch - 1 + (e.addJot ? .09 : 0);
	l.setAttribute("rowspacing", k(u));
	var d = "", f = "";
	if (e.cols && e.cols.length > 0) {
		var p = e.cols, m = "", h = !1, g = 0, _ = p.length;
		p[0].type === "separator" && (d += "top ", g = 1), p[p.length - 1].type === "separator" && (d += "bottom ", --_);
		for (var v = g; v < _; v++) {
			var y = p[v];
			y.type === "align" ? (f += di[y.align], h && (m += "none "), h = !0) : y.type === "separator" && h && (m += y.separator === "|" ? "solid " : "dashed ", h = !1);
		}
		l.setAttribute("columnalign", f.trim()), /[sd]/.test(m) && l.setAttribute("columnlines", m.trim());
	}
	if (e.colSeparationType === "align") {
		for (var b = e.cols || [], x = "", S = 1; S < b.length; S++) x += S % 2 ? "0em " : "1em ";
		l.setAttribute("columnspacing", x.trim());
	} else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? l.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? l.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? l.setAttribute("columnspacing", "0.5em") : l.setAttribute("columnspacing", "1em");
	var C = "", w = e.hLinesBeforeRow;
	d += w[0].length > 0 ? "left " : "", d += w[w.length - 1].length > 0 ? "right " : "";
	for (var ee = 1; ee < w.length - 1; ee++) C += w[ee].length === 0 ? "none " : w[ee][0] ? "dashed " : "solid ";
	return /[sd]/.test(C) && l.setAttribute("rowlines", C.trim()), d !== "" && (l = new X("menclose", [l]), l.setAttribute("notation", d.trim())), e.arraystretch && e.arraystretch < 1 && (l = new X("mstyle", [l]), l.setAttribute("scriptlevel", "1")), l;
}, pi = function(t, n) {
	t.envName.includes("ed") || ai(t);
	var r = [], i = t.envName.includes("at") ? "alignat" : "align", a = t.envName === "split", o = ci(t.parser, {
		cols: r,
		addJot: !0,
		autoTag: a ? void 0 : si(t.envName),
		emptySingleRow: !0,
		colSeparationType: i,
		maxNumCols: a ? 2 : void 0,
		leqno: t.parser.settings.leqno
	}, "display"), s = 0, c = 0, l = {
		type: "ordgroup",
		mode: t.mode,
		body: []
	};
	if (n[0] && n[0].type === "ordgroup") {
		for (var u = "", d = 0; d < n[0].body.length; d++) {
			var f = Q(n[0].body[d], "textord");
			u += f.text;
		}
		s = Number(u), c = s * 2;
	}
	var p = !c;
	o.body.forEach(function(t) {
		for (var n = 1; n < t.length; n += 2) Q(Q(t[n], "styling").body[0], "ordgroup").body.unshift(l);
		if (p) c < t.length && (c = t.length);
		else {
			var r = t.length / 2;
			if (s < r) throw new e("Too many math in a row: " + ("expected " + s + ", but got " + r), t[0]);
		}
	});
	for (var m = 0; m < c; ++m) {
		var h = "r", g = 0;
		m % 2 == 1 ? h = "l" : m > 0 && p && (g = 1), r[m] = {
			type: "align",
			align: h,
			pregap: g,
			postgap: 0
		};
	}
	return o.colSeparationType = p ? "align" : "alignat", o;
};
ei({
	type: "array",
	names: ["array", "darray"],
	props: { numArgs: 1 },
	handler(t, n) {
		var r = (Xn(n[0]) ? [n[0]] : Q(n[0], "ordgroup").body).map(function(t) {
			var n = Yn(t).text;
			if ("lcr".includes(n)) return {
				type: "align",
				align: n
			};
			if (n === "|") return {
				type: "separator",
				separator: "|"
			};
			if (n === ":") return {
				type: "separator",
				separator: ":"
			};
			throw new e("Unknown column alignment: " + n, t);
		}), i = {
			cols: r,
			hskipBeforeAndAfter: !0,
			maxNumCols: r.length
		};
		return ci(t.parser, i, li(t.envName));
	},
	htmlBuilder: ui,
	mathmlBuilder: fi
}), ei({
	type: "array",
	names: [
		"matrix",
		"pmatrix",
		"bmatrix",
		"Bmatrix",
		"vmatrix",
		"Vmatrix",
		"matrix*",
		"pmatrix*",
		"bmatrix*",
		"Bmatrix*",
		"vmatrix*",
		"Vmatrix*"
	],
	props: { numArgs: 0 },
	handler(t) {
		var n = {
			matrix: null,
			pmatrix: ["(", ")"],
			bmatrix: ["[", "]"],
			Bmatrix: ["\\{", "\\}"],
			vmatrix: ["|", "|"],
			Vmatrix: ["\\Vert", "\\Vert"]
		}[t.envName.replace("*", "")], r = "c", i = {
			hskipBeforeAndAfter: !1,
			cols: [{
				type: "align",
				align: r
			}]
		};
		if (t.envName.charAt(t.envName.length - 1) === "*") {
			var a = t.parser;
			if (a.consumeSpaces(), a.fetch().text === "[") {
				if (a.consume(), a.consumeSpaces(), r = a.fetch().text, !"lcr".includes(r)) throw new e("Expected l or c or r", a.nextToken);
				a.consume(), a.consumeSpaces(), a.expect("]"), a.consume(), i.cols = [{
					type: "align",
					align: r
				}];
			}
		}
		var o = ci(t.parser, i, li(t.envName)), s = Math.max(0, ...o.body.map((e) => e.length));
		return o.cols = Array(s).fill({
			type: "align",
			align: r
		}), n ? {
			type: "leftright",
			mode: t.mode,
			body: [o],
			left: n[0],
			right: n[1],
			rightColor: void 0
		} : o;
	},
	htmlBuilder: ui,
	mathmlBuilder: fi
}), ei({
	type: "array",
	names: ["smallmatrix"],
	props: { numArgs: 0 },
	handler(e) {
		var t = ci(e.parser, { arraystretch: .5 }, "script");
		return t.colSeparationType = "small", t;
	},
	htmlBuilder: ui,
	mathmlBuilder: fi
}), ei({
	type: "array",
	names: ["subarray"],
	props: { numArgs: 1 },
	handler(t, n) {
		var r = (Xn(n[0]) ? [n[0]] : Q(n[0], "ordgroup").body).map(function(t) {
			var n = Yn(t).text;
			if ("lc".includes(n)) return {
				type: "align",
				align: n
			};
			throw new e("Unknown column alignment: " + n, t);
		});
		if (r.length > 1) throw new e("{subarray} can contain only one column");
		var i = {
			cols: r,
			hskipBeforeAndAfter: !1,
			arraystretch: .5
		}, a = ci(t.parser, i, "script");
		if (a.body.length > 0 && a.body[0].length > 1) throw new e("{subarray} can contain only one column");
		return a;
	},
	htmlBuilder: ui,
	mathmlBuilder: fi
}), ei({
	type: "array",
	names: [
		"cases",
		"dcases",
		"rcases",
		"drcases"
	],
	props: { numArgs: 0 },
	handler(e) {
		var t = ci(e.parser, {
			arraystretch: 1.2,
			cols: [{
				type: "align",
				align: "l",
				pregap: 0,
				postgap: 1
			}, {
				type: "align",
				align: "l",
				pregap: 0,
				postgap: 0
			}]
		}, li(e.envName));
		return {
			type: "leftright",
			mode: e.mode,
			body: [t],
			left: e.envName.includes("r") ? "." : "\\{",
			right: e.envName.includes("r") ? "\\}" : ".",
			rightColor: void 0
		};
	},
	htmlBuilder: ui,
	mathmlBuilder: fi
}), ei({
	type: "array",
	names: [
		"align",
		"align*",
		"aligned",
		"split"
	],
	props: { numArgs: 0 },
	handler: pi,
	htmlBuilder: ui,
	mathmlBuilder: fi
}), ei({
	type: "array",
	names: [
		"gathered",
		"gather",
		"gather*"
	],
	props: { numArgs: 0 },
	handler(e) {
		oi.has(e.envName) && ai(e);
		var t = {
			cols: [{
				type: "align",
				align: "c"
			}],
			addJot: !0,
			colSeparationType: "gather",
			autoTag: si(e.envName),
			emptySingleRow: !0,
			leqno: e.parser.settings.leqno
		};
		return ci(e.parser, t, "display");
	},
	htmlBuilder: ui,
	mathmlBuilder: fi
}), ei({
	type: "array",
	names: [
		"alignat",
		"alignat*",
		"alignedat"
	],
	props: { numArgs: 1 },
	handler: pi,
	htmlBuilder: ui,
	mathmlBuilder: fi
}), ei({
	type: "array",
	names: ["equation", "equation*"],
	props: { numArgs: 0 },
	handler(e) {
		ai(e);
		var t = {
			autoTag: si(e.envName),
			emptySingleRow: !0,
			singleRow: !0,
			maxNumCols: 1,
			leqno: e.parser.settings.leqno
		};
		return ci(e.parser, t, "display");
	},
	htmlBuilder: ui,
	mathmlBuilder: fi
}), ei({
	type: "array",
	names: ["CD"],
	props: { numArgs: 0 },
	handler(e) {
		return ai(e), ur(e.parser);
	},
	htmlBuilder: ui,
	mathmlBuilder: fi
}), $("\\nonumber", "\\gdef\\@eqnsw{0}"), $("\\notag", "\\nonumber"), q({
	type: "text",
	names: ["\\hline", "\\hdashline"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		allowedInMath: !0
	},
	handler(t, n) {
		throw new e(t.funcName + " valid only within array environment");
	}
});
var mi = $r;
q({
	type: "environment",
	names: ["\\begin", "\\end"],
	props: {
		numArgs: 1,
		argTypes: ["text"]
	},
	handler(t, n) {
		var { parser: r, funcName: i } = t, a = n[0];
		if (a.type !== "ordgroup") throw new e("Invalid environment name", a);
		for (var o = "", s = 0; s < a.body.length; ++s) o += Q(a.body[s], "textord").text;
		if (i === "\\begin") {
			if (!mi.hasOwnProperty(o)) throw new e("No such environment: " + o, a);
			var c = mi[o], { args: l, optArgs: u } = r.parseArguments("\\begin{" + o + "}", c), d = {
				mode: r.mode,
				envName: o,
				parser: r
			}, f = c.handler(d, l, u);
			r.expect("\\end", !1);
			var p = r.nextToken, m = Q(r.parseFunction(), "environment");
			if (m.name !== o) throw new e("Mismatch: \\begin{" + o + "} matched by \\end{" + m.name + "}", p);
			return f;
		}
		return {
			type: "environment",
			mode: r.mode,
			name: o,
			nameGroup: a
		};
	}
});
var hi = (e, t) => {
	var n = e.font, r = t.withFont(n);
	return Y(e.body, r);
}, gi = (e, t) => {
	var n = e.font, r = t.withFont(n);
	return Z(e.body, r);
}, _i = {
	"\\Bbb": "\\mathbb",
	"\\bold": "\\mathbf",
	"\\frak": "\\mathfrak"
};
q({
	type: "font",
	names: [
		"\\mathrm",
		"\\mathit",
		"\\mathbf",
		"\\mathnormal",
		"\\mathsfit",
		"\\mathbb",
		"\\mathcal",
		"\\mathfrak",
		"\\mathscr",
		"\\mathsf",
		"\\mathtt",
		"\\Bbb",
		"\\bold",
		"\\frak"
	],
	props: {
		numArgs: 1,
		allowedInArgument: !0
	},
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = on(t[0]), a = r;
		return a in _i && (a = _i[a]), {
			type: "font",
			mode: n.mode,
			font: a.slice(1),
			body: i
		};
	},
	htmlBuilder: hi,
	mathmlBuilder: gi
}), q({
	type: "mclass",
	names: ["\\boldsymbol", "\\bm"],
	props: { numArgs: 1 },
	handler: (e, t) => {
		var { parser: n } = e, r = t[0];
		return {
			type: "mclass",
			mode: n.mode,
			mclass: ir(r),
			body: [{
				type: "font",
				mode: n.mode,
				font: "boldsymbol",
				body: r
			}],
			isCharacterBox: c(r)
		};
	}
}), q({
	type: "font",
	names: [
		"\\rm",
		"\\sf",
		"\\tt",
		"\\bf",
		"\\it",
		"\\cal"
	],
	props: {
		numArgs: 0,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n, funcName: r, breakOnTokenText: i } = e, { mode: a } = n, o = n.parseExpression(!0, i);
		return {
			type: "font",
			mode: a,
			font: "math" + r.slice(1),
			body: {
				type: "ordgroup",
				mode: n.mode,
				body: o
			}
		};
	},
	htmlBuilder: hi,
	mathmlBuilder: gi
});
var vi = (e, t) => {
	var n = t.style, r = n.fracNum(), i = n.fracDen(), a = t.havingStyle(r), o = Y(e.numer, a, t);
	if (e.continued) {
		var s = 8.5 / t.fontMetrics().ptPerEm, c = 3.5 / t.fontMetrics().ptPerEm;
		o.height = o.height < s ? s : o.height, o.depth = o.depth < c ? c : o.depth;
	}
	a = t.havingStyle(i);
	var l = Y(e.denom, a, t), u, d, f;
	e.hasBarLine ? (e.barSize ? (d = O(e.barSize, t), u = Vt("frac-line", t, d)) : u = Vt("frac-line", t), d = u.height, f = u.height) : (u = null, d = 0, f = t.fontMetrics().defaultRuleThickness);
	var p, m, h;
	n.size === E.DISPLAY.size ? (p = t.fontMetrics().num1, m = d > 0 ? 3 * f : 7 * f, h = t.fontMetrics().denom1) : (d > 0 ? (p = t.fontMetrics().num2, m = f) : (p = t.fontMetrics().num3, m = 3 * f), h = t.fontMetrics().denom2);
	var g;
	if (u) {
		var _ = t.fontMetrics().axisHeight;
		p - o.depth - (_ + .5 * d) < m && (p += m - (p - o.depth - (_ + .5 * d))), _ - .5 * d - (l.height - h) < m && (h += m - (_ - .5 * d - (l.height - h)));
		var v = -(_ - .5 * d);
		g = G({
			positionType: "individualShift",
			children: [
				{
					type: "elem",
					elem: l,
					shift: h
				},
				{
					type: "elem",
					elem: u,
					shift: v
				},
				{
					type: "elem",
					elem: o,
					shift: -p
				}
			]
		});
	} else {
		var y = p - o.depth - (l.height - h);
		y < m && (p += .5 * (m - y), h += .5 * (m - y)), g = G({
			positionType: "individualShift",
			children: [{
				type: "elem",
				elem: l,
				shift: h
			}, {
				type: "elem",
				elem: o,
				shift: -p
			}]
		});
	}
	a = t.havingStyle(n), g.height *= a.sizeMultiplier / t.sizeMultiplier, g.depth *= a.sizeMultiplier / t.sizeMultiplier;
	var b = n.size === E.DISPLAY.size ? t.fontMetrics().delim1 : n.size === E.SCRIPTSCRIPT.size ? t.havingStyle(E.SCRIPT).fontMetrics().delim2 : t.fontMetrics().delim2, x, S;
	return x = e.leftDelim == null ? gn(t, ["mopen"]) : Wr(e.leftDelim, b, !0, t.havingStyle(n), e.mode, ["mopen"]), S = e.continued ? W([]) : e.rightDelim == null ? gn(t, ["mclose"]) : Wr(e.rightDelim, b, !0, t.havingStyle(n), e.mode, ["mclose"]), W(["mord"].concat(a.sizingClasses(t)), [
		x,
		W(["mfrac"], [g]),
		S
	], t);
}, yi = (e, t) => {
	var n = new X("mfrac", [Z(e.numer, t), Z(e.denom, t)]);
	if (!e.hasBarLine) n.setAttribute("linethickness", "0px");
	else if (e.barSize) {
		var r = O(e.barSize, t);
		n.setAttribute("linethickness", k(r));
	}
	if (e.leftDelim != null || e.rightDelim != null) {
		var i = [];
		if (e.leftDelim != null) {
			var a = new X("mo", [new bn(e.leftDelim.replace("\\", ""))]);
			a.setAttribute("fence", "true"), i.push(a);
		}
		if (i.push(n), e.rightDelim != null) {
			var o = new X("mo", [new bn(e.rightDelim.replace("\\", ""))]);
			o.setAttribute("fence", "true"), i.push(o);
		}
		return Tn(i);
	}
	return n;
}, bi = (e, t) => t ? {
	type: "styling",
	mode: e.mode,
	style: t,
	body: [e]
} : e;
q({
	type: "genfrac",
	names: [
		"\\cfrac",
		"\\dfrac",
		"\\frac",
		"\\tfrac",
		"\\dbinom",
		"\\binom",
		"\\tbinom",
		"\\\\atopfrac",
		"\\\\bracefrac",
		"\\\\brackfrac"
	],
	props: {
		numArgs: 2,
		allowedInArgument: !0
	},
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = t[0], a = t[1], o, s = null, c = null;
		switch (r) {
			case "\\cfrac":
			case "\\dfrac":
			case "\\frac":
			case "\\tfrac":
				o = !0;
				break;
			case "\\\\atopfrac":
				o = !1;
				break;
			case "\\dbinom":
			case "\\binom":
			case "\\tbinom":
				o = !1, s = "(", c = ")";
				break;
			case "\\\\bracefrac":
				o = !1, s = "\\{", c = "\\}";
				break;
			case "\\\\brackfrac":
				o = !1, s = "[", c = "]";
				break;
			default: throw Error("Unrecognized genfrac command");
		}
		var l = r === "\\cfrac", u = null;
		return l || r.startsWith("\\d") ? u = "display" : r.startsWith("\\t") && (u = "text"), bi({
			type: "genfrac",
			mode: n.mode,
			numer: i,
			denom: a,
			continued: l,
			hasBarLine: o,
			leftDelim: s,
			rightDelim: c,
			barSize: null
		}, u);
	},
	htmlBuilder: vi,
	mathmlBuilder: yi
}), q({
	type: "infix",
	names: [
		"\\over",
		"\\choose",
		"\\atop",
		"\\brace",
		"\\brack"
	],
	props: {
		numArgs: 0,
		infix: !0
	},
	handler(e) {
		var { parser: t, funcName: n, token: r } = e, i;
		switch (n) {
			case "\\over":
				i = "\\frac";
				break;
			case "\\choose":
				i = "\\binom";
				break;
			case "\\atop":
				i = "\\\\atopfrac";
				break;
			case "\\brace":
				i = "\\\\bracefrac";
				break;
			case "\\brack":
				i = "\\\\brackfrac";
				break;
			default: throw Error("Unrecognized infix genfrac command");
		}
		return {
			type: "infix",
			mode: t.mode,
			replaceWith: i,
			token: r
		};
	}
});
var xi = [
	"display",
	"text",
	"script",
	"scriptscript"
], Si = function(e) {
	var t = null;
	return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
q({
	type: "genfrac",
	names: ["\\genfrac"],
	props: {
		numArgs: 6,
		allowedInArgument: !0,
		argTypes: [
			"math",
			"math",
			"size",
			"text",
			"math",
			"math"
		]
	},
	handler(e, t) {
		var { parser: n } = e, r = t[4], i = t[5], a = on(t[0]), o = a.type === "atom" && a.family === "open" ? Si(a.text) : null, s = on(t[1]), c = s.type === "atom" && s.family === "close" ? Si(s.text) : null, l = Q(t[2], "size"), u, d = null;
		l.isBlank ? u = !0 : (d = l.value, u = d.number > 0);
		var f = null, p = t[3];
		if (p.type === "ordgroup") {
			if (p.body.length > 0) {
				var m = Q(p.body[0], "textord");
				f = xi[Number(m.text)];
			}
		} else p = Q(p, "textord"), f = xi[Number(p.text)];
		return bi({
			type: "genfrac",
			mode: n.mode,
			numer: r,
			denom: i,
			continued: !1,
			hasBarLine: u,
			barSize: d,
			leftDelim: o,
			rightDelim: c
		}, f);
	}
}), q({
	type: "infix",
	names: ["\\above"],
	props: {
		numArgs: 1,
		argTypes: ["size"],
		infix: !0
	},
	handler(e, t) {
		var { parser: n, funcName: r, token: i } = e;
		return {
			type: "infix",
			mode: n.mode,
			replaceWith: "\\\\abovefrac",
			size: Q(t[0], "size").value,
			token: i
		};
	}
}), q({
	type: "genfrac",
	names: ["\\\\abovefrac"],
	props: {
		numArgs: 3,
		argTypes: [
			"math",
			"size",
			"math"
		]
	},
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = t[0], a = Q(t[1], "infix").size;
		if (!a) throw Error("\\\\abovefrac expected size, but got " + String(a));
		var o = t[2], s = a.number > 0;
		return {
			type: "genfrac",
			mode: n.mode,
			numer: i,
			denom: o,
			continued: !1,
			hasBarLine: s,
			barSize: a,
			leftDelim: null,
			rightDelim: null
		};
	}
});
var Ci = (e, t) => {
	var n = t.style, r, i;
	e.type === "supsub" ? (r = e.sup ? Y(e.sup, t.havingStyle(n.sup()), t) : Y(e.sub, t.havingStyle(n.sub()), t), i = Q(e.base, "horizBrace")) : i = Q(e, "horizBrace");
	var a = Y(i.base, t.havingBaseStyle(E.DISPLAY)), o = Wn(i, t), s;
	if (s = i.isOver ? G({
		positionType: "firstBaseline",
		children: [
			{
				type: "elem",
				elem: a
			},
			{
				type: "kern",
				size: .1
			},
			{
				type: "elem",
				elem: o,
				wrapperClasses: ["svg-align"]
			}
		]
	}) : G({
		positionType: "bottom",
		positionData: a.depth + .1 + o.height,
		children: [
			{
				type: "elem",
				elem: o,
				wrapperClasses: ["svg-align"]
			},
			{
				type: "kern",
				size: .1
			},
			{
				type: "elem",
				elem: a
			}
		]
	}), r) {
		var c = W(["minner", i.isOver ? "mover" : "munder"], [s], t);
		s = i.isOver ? G({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: c
				},
				{
					type: "kern",
					size: .2
				},
				{
					type: "elem",
					elem: r
				}
			]
		}) : G({
			positionType: "bottom",
			positionData: c.depth + .2 + r.height + r.depth,
			children: [
				{
					type: "elem",
					elem: r
				},
				{
					type: "kern",
					size: .2
				},
				{
					type: "elem",
					elem: c
				}
			]
		});
	}
	return W(["minner", i.isOver ? "mover" : "munder"], [s], t);
};
q({
	type: "horizBrace",
	names: [
		"\\overbrace",
		"\\underbrace",
		"\\overbracket",
		"\\underbracket"
	],
	props: { numArgs: 1 },
	handler(e, t) {
		var { parser: n, funcName: r } = e;
		return {
			type: "horizBrace",
			mode: n.mode,
			label: r,
			isOver: r.includes("\\over"),
			base: t[0]
		};
	},
	htmlBuilder: Ci,
	mathmlBuilder: (e, t) => {
		var n = Vn(e.label);
		return new X(e.isOver ? "mover" : "munder", [Z(e.base, t), n]);
	}
}), q({
	type: "href",
	names: ["\\href"],
	props: {
		numArgs: 2,
		argTypes: ["url", "original"],
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n } = e, r = t[1], i = Q(t[0], "url").url;
		return n.settings.isTrusted({
			command: "\\href",
			url: i
		}) ? {
			type: "href",
			mode: n.mode,
			href: i,
			body: J(r)
		} : n.formatUnsupportedCmd("\\href");
	},
	htmlBuilder: (e, t) => {
		var n = dn(e.body, t, !1);
		return Ht(e.href, [], n, t);
	},
	mathmlBuilder: (e, t) => {
		var n = An(e.body, t);
		return n instanceof X || (n = new X("mrow", [n])), n.setAttribute("href", e.href), n;
	}
}), q({
	type: "href",
	names: ["\\url"],
	props: {
		numArgs: 1,
		argTypes: ["url"],
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n } = e, r = Q(t[0], "url").url;
		if (!n.settings.isTrusted({
			command: "\\url",
			url: r
		})) return n.formatUnsupportedCmd("\\url");
		for (var i = [], a = 0; a < r.length; a++) {
			var o = r[a];
			o === "~" && (o = "\\textasciitilde"), i.push({
				type: "textord",
				mode: "text",
				text: o
			});
		}
		var s = {
			type: "text",
			mode: n.mode,
			font: "\\texttt",
			body: i
		};
		return {
			type: "href",
			mode: n.mode,
			href: r,
			body: J(s)
		};
	}
}), q({
	type: "hbox",
	names: ["\\hbox"],
	props: {
		numArgs: 1,
		argTypes: ["text"],
		allowedInText: !0,
		primitive: !0
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "hbox",
			mode: n.mode,
			body: J(t[0])
		};
	},
	htmlBuilder(e, t) {
		return Ut(dn(e.body, t.withFont(""), !1));
	},
	mathmlBuilder(e, t) {
		return new X("mrow", kn(e.body, t.withFont("")));
	}
}), q({
	type: "html",
	names: [
		"\\htmlClass",
		"\\htmlId",
		"\\htmlStyle",
		"\\htmlData"
	],
	props: {
		numArgs: 2,
		argTypes: ["raw", "original"],
		allowedInText: !0
	},
	handler: (t, n) => {
		var { parser: r, funcName: i, token: a } = t, o = Q(n[0], "raw").string, s = n[1];
		r.settings.strict && r.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
		var c, l = {};
		switch (i) {
			case "\\htmlClass":
				l.class = o, c = {
					command: "\\htmlClass",
					class: o
				};
				break;
			case "\\htmlId":
				l.id = o, c = {
					command: "\\htmlId",
					id: o
				};
				break;
			case "\\htmlStyle":
				l.style = o, c = {
					command: "\\htmlStyle",
					style: o
				};
				break;
			case "\\htmlData":
				for (var u = o.split(","), d = 0; d < u.length; d++) {
					var f = u[d], p = f.indexOf("=");
					if (p < 0) throw new e("\\htmlData key/value '" + f + "' missing equals sign");
					var m = f.slice(0, p), h = f.slice(p + 1);
					l["data-" + m.trim()] = h;
				}
				c = {
					command: "\\htmlData",
					attributes: l
				};
				break;
			default: throw Error("Unrecognized html command");
		}
		return r.settings.isTrusted(c) ? {
			type: "html",
			mode: r.mode,
			attributes: l,
			body: J(s)
		} : r.formatUnsupportedCmd(i);
	},
	htmlBuilder: (e, t) => {
		var n = dn(e.body, t, !1), r = ["enclosing"];
		e.attributes.class && r.push(...e.attributes.class.trim().split(/\s+/));
		var i = W(r, n, t);
		for (var a in e.attributes) a !== "class" && e.attributes.hasOwnProperty(a) && i.setAttribute(a, e.attributes[a]);
		return i;
	},
	mathmlBuilder: (e, t) => An(e.body, t)
}), q({
	type: "htmlmathml",
	names: ["\\html@mathml"],
	props: {
		numArgs: 2,
		allowedInArgument: !0,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n } = e;
		return {
			type: "htmlmathml",
			mode: n.mode,
			html: J(t[0]),
			mathml: J(t[1])
		};
	},
	htmlBuilder: (e, t) => Ut(dn(e.html, t, !1)),
	mathmlBuilder: (e, t) => An(e.mathml, t)
});
var wi = function(t) {
	if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(t)) return {
		number: +t,
		unit: "bp"
	};
	var n = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(t);
	if (!n) throw new e("Invalid size: '" + t + "' in \\includegraphics");
	var r = {
		number: +(n[1] + n[2]),
		unit: n[3]
	};
	if (!Te(r)) throw new e("Invalid unit: '" + r.unit + "' in \\includegraphics.");
	return r;
};
q({
	type: "includegraphics",
	names: ["\\includegraphics"],
	props: {
		numArgs: 1,
		numOptionalArgs: 1,
		argTypes: ["raw", "url"],
		allowedInText: !1
	},
	handler: (t, n, r) => {
		var { parser: i } = t, a = {
			number: 0,
			unit: "em"
		}, o = {
			number: .9,
			unit: "em"
		}, s = {
			number: 0,
			unit: "em"
		}, c = "";
		if (r[0]) for (var l = Q(r[0], "raw").string, u = l.split(","), d = 0; d < u.length; d++) {
			var f = u[d].split("=");
			if (f.length === 2) {
				var p = f[1].trim();
				switch (f[0].trim()) {
					case "alt":
						c = p;
						break;
					case "width":
						a = wi(p);
						break;
					case "height":
						o = wi(p);
						break;
					case "totalheight":
						s = wi(p);
						break;
					default: throw new e("Invalid key: '" + f[0] + "' in \\includegraphics.");
				}
			}
		}
		var m = Q(n[0], "url").url;
		return c === "" && (c = m, c = c.replace(/^.*[\\/]/, ""), c = c.substring(0, c.lastIndexOf("."))), i.settings.isTrusted({
			command: "\\includegraphics",
			url: m
		}) ? {
			type: "includegraphics",
			mode: i.mode,
			alt: c,
			width: a,
			height: o,
			totalheight: s,
			src: m
		} : i.formatUnsupportedCmd("\\includegraphics");
	},
	htmlBuilder: (e, t) => {
		var n = O(e.height, t), r = 0;
		e.totalheight.number > 0 && (r = O(e.totalheight, t) - n);
		var i = 0;
		e.width.number > 0 && (i = O(e.width, t));
		var a = { height: k(n + r) };
		i > 0 && (a.width = k(i)), r > 0 && (a.verticalAlign = k(-r));
		var o = new Pe(e.src, e.alt, a);
		return o.height = n, o.depth = r, o;
	},
	mathmlBuilder: (e, t) => {
		var n = new X("mglyph", []);
		n.setAttribute("alt", e.alt);
		var r = O(e.height, t), i = 0;
		if (e.totalheight.number > 0 && (i = O(e.totalheight, t) - r, n.setAttribute("valign", k(-i))), n.setAttribute("height", k(r + i)), e.width.number > 0) {
			var a = O(e.width, t);
			n.setAttribute("width", k(a));
		}
		return n.setAttribute("src", e.src), n;
	}
}), q({
	type: "kern",
	names: [
		"\\kern",
		"\\mkern",
		"\\hskip",
		"\\mskip"
	],
	props: {
		numArgs: 1,
		argTypes: ["size"],
		primitive: !0,
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n, funcName: r } = e, i = Q(t[0], "size");
		if (n.settings.strict) {
			var a = r[1] === "m", o = i.value.unit === "mu";
			a ? (o || n.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " supports only mu units, " + ("not " + i.value.unit + " units")), n.mode !== "math" && n.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " works only in math mode")) : o && n.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " doesn't support mu units");
		}
		return {
			type: "kern",
			mode: n.mode,
			dimension: i.value
		};
	},
	htmlBuilder(e, t) {
		return Kt(e.dimension, t);
	},
	mathmlBuilder(e, t) {
		return new xn(O(e.dimension, t));
	}
}), q({
	type: "lap",
	names: [
		"\\mathllap",
		"\\mathrlap",
		"\\mathclap"
	],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "lap",
			mode: n.mode,
			alignment: r.slice(5),
			body: i
		};
	},
	htmlBuilder: (e, t) => {
		var n;
		e.alignment === "clap" ? (n = W([], [Y(e.body, t)]), n = W(["inner"], [n], t)) : n = W(["inner"], [Y(e.body, t)]);
		var r = W(["fix"], []), i = W([e.alignment], [n, r], t), a = W(["strut"]);
		return a.style.height = k(i.height + i.depth), i.depth && (a.style.verticalAlign = k(-i.depth)), i.children.unshift(a), i = W(["thinbox"], [i], t), W(["mord", "vbox"], [i], t);
	},
	mathmlBuilder: (e, t) => {
		var n = new X("mpadded", [Z(e.body, t)]);
		if (e.alignment !== "rlap") {
			var r = e.alignment === "llap" ? "-1" : "-0.5";
			n.setAttribute("lspace", r + "width");
		}
		return n.setAttribute("width", "0px"), n;
	}
}), q({
	type: "styling",
	names: ["\\(", "$"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		allowedInMath: !1
	},
	handler(e, t) {
		var { funcName: n, parser: r } = e, i = r.mode;
		r.switchMode("math");
		var a = n === "\\(" ? "\\)" : "$", o = r.parseExpression(!1, a);
		return r.expect(a), r.switchMode(i), {
			type: "styling",
			mode: r.mode,
			style: "text",
			resetFont: !0,
			body: o
		};
	}
}), q({
	type: "text",
	names: ["\\)", "\\]"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		allowedInMath: !1
	},
	handler(t, n) {
		throw new e("Mismatched " + t.funcName);
	}
});
var Ti = (e, t) => {
	switch (t.style.size) {
		case E.DISPLAY.size: return e.display;
		case E.TEXT.size: return e.text;
		case E.SCRIPT.size: return e.script;
		case E.SCRIPTSCRIPT.size: return e.scriptscript;
		default: return e.text;
	}
};
q({
	type: "mathchoice",
	names: ["\\mathchoice"],
	props: {
		numArgs: 4,
		primitive: !0
	},
	handler: (e, t) => {
		var { parser: n } = e;
		return {
			type: "mathchoice",
			mode: n.mode,
			display: J(t[0]),
			text: J(t[1]),
			script: J(t[2]),
			scriptscript: J(t[3])
		};
	},
	htmlBuilder: (e, t) => Ut(dn(Ti(e, t), t, !1)),
	mathmlBuilder: (e, t) => An(Ti(e, t), t)
});
var Ei = (e, t, n, r, i, a, o) => {
	e = W([], [e]);
	var s = n && c(n), l, u;
	if (t) {
		var d = Y(t, r.havingStyle(i.sup()), r);
		u = {
			elem: d,
			kern: Math.max(r.fontMetrics().bigOpSpacing1, r.fontMetrics().bigOpSpacing3 - d.depth)
		};
	}
	if (n) {
		var f = Y(n, r.havingStyle(i.sub()), r);
		l = {
			elem: f,
			kern: Math.max(r.fontMetrics().bigOpSpacing2, r.fontMetrics().bigOpSpacing4 - f.height)
		};
	}
	var p;
	if (u && l) p = G({
		positionType: "bottom",
		positionData: r.fontMetrics().bigOpSpacing5 + l.elem.height + l.elem.depth + l.kern + e.depth + o,
		children: [
			{
				type: "kern",
				size: r.fontMetrics().bigOpSpacing5
			},
			{
				type: "elem",
				elem: l.elem,
				marginLeft: k(-a)
			},
			{
				type: "kern",
				size: l.kern
			},
			{
				type: "elem",
				elem: e
			},
			{
				type: "kern",
				size: u.kern
			},
			{
				type: "elem",
				elem: u.elem,
				marginLeft: k(a)
			},
			{
				type: "kern",
				size: r.fontMetrics().bigOpSpacing5
			}
		]
	});
	else if (l) p = G({
		positionType: "top",
		positionData: e.height - o,
		children: [
			{
				type: "kern",
				size: r.fontMetrics().bigOpSpacing5
			},
			{
				type: "elem",
				elem: l.elem,
				marginLeft: k(-a)
			},
			{
				type: "kern",
				size: l.kern
			},
			{
				type: "elem",
				elem: e
			}
		]
	});
	else if (u) p = G({
		positionType: "bottom",
		positionData: e.depth + o,
		children: [
			{
				type: "elem",
				elem: e
			},
			{
				type: "kern",
				size: u.kern
			},
			{
				type: "elem",
				elem: u.elem,
				marginLeft: k(a)
			},
			{
				type: "kern",
				size: r.fontMetrics().bigOpSpacing5
			}
		]
	});
	else return e;
	var m = [p];
	if (l && a !== 0 && !s) {
		var h = W(["mspace"], [], r);
		h.style.marginRight = k(a), m.unshift(h);
	}
	return W(["mop", "op-limits"], m, r);
}, Di = /* @__PURE__ */ new Set(["\\smallint"]), Oi = (e, t) => {
	var n, r, i = !1, a;
	e.type === "supsub" ? (n = e.sup, r = e.sub, a = Q(e.base, "op"), i = !0) : a = Q(e, "op");
	var o = t.style, s = !1;
	o.size === E.DISPLAY.size && a.symbol && !Di.has(a.name) && (s = !0);
	var c, l;
	if (a.symbol) {
		var u = s ? "Size2-Regular" : "Size1-Regular", d = "";
		if ((a.name === "\\oiint" || a.name === "\\oiiint") && (d = a.name.slice(1), a.name = d === "oiint" ? "\\iint" : "\\iiint"), c = Nt(a.name, u, "math", t, [
			"mop",
			"op-symbol",
			s ? "large-op" : "small-op"
		]), l = c.italic, d.length > 0) {
			var f = Xt(d + "Size" + (s ? "2" : "1"), t);
			c = G({
				positionType: "individualShift",
				children: [{
					type: "elem",
					elem: c,
					shift: 0
				}, {
					type: "elem",
					elem: f,
					shift: s ? .08 : 0
				}]
			}), a.name = "\\" + d, c.classes.unshift("mop"), c.italic = l;
		}
	} else if (a.body) {
		var p = dn(a.body, t, !0);
		p.length === 1 && p[0] instanceof Ie ? (c = p[0], c.classes[0] = "mop") : c = W(["mop"], p, t);
	} else {
		for (var m = [], h = 1; h < a.name.length; h++) m.push(Pt(a.name[h], a.mode, t));
		c = W(["mop"], m, t);
	}
	var g = 0, _ = 0;
	return (c instanceof Ie || a.name === "\\oiint" || a.name === "\\oiiint") && !a.suppressBaseShift && (g = (c.height - c.depth) / 2 - t.fontMetrics().axisHeight, _ = c.italic ?? 0), i ? Ei(c, n, r, t, o, _, g) : (g && (c.style.position = "relative", c.style.top = k(g)), c);
}, ki = (e, t) => {
	var n;
	if (e.symbol) n = new X("mo", [wn(e.name, e.mode)]), Di.has(e.name) && n.setAttribute("largeop", "false");
	else if (e.body) n = new X("mo", kn(e.body, t));
	else {
		n = new X("mi", [new bn(e.name.slice(1))]);
		var r = new X("mo", [wn("⁡", "text")]);
		n = e.parentIsSupSub ? new X("mrow", [n, r]) : yn([n, r]);
	}
	return n;
}, Ai = {
	"∏": "\\prod",
	"∐": "\\coprod",
	"∑": "\\sum",
	"⋀": "\\bigwedge",
	"⋁": "\\bigvee",
	"⋂": "\\bigcap",
	"⋃": "\\bigcup",
	"⨀": "\\bigodot",
	"⨁": "\\bigoplus",
	"⨂": "\\bigotimes",
	"⨄": "\\biguplus",
	"⨆": "\\bigsqcup"
};
q({
	type: "op",
	names: /* @__PURE__ */ "\\coprod.\\bigvee.\\bigwedge.\\biguplus.\\bigcap.\\bigcup.\\intop.\\prod.\\sum.\\bigotimes.\\bigoplus.\\bigodot.\\bigsqcup.\\smallint.∏.∐.∑.⋀.⋁.⋂.⋃.⨀.⨁.⨂.⨄.⨆".split("."),
	props: { numArgs: 0 },
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = r;
		return i.length === 1 && (i = Ai[i]), {
			type: "op",
			mode: n.mode,
			limits: !0,
			parentIsSupSub: !1,
			symbol: !0,
			name: i
		};
	},
	htmlBuilder: Oi,
	mathmlBuilder: ki
}), q({
	type: "op",
	names: ["\\mathop"],
	props: {
		numArgs: 1,
		primitive: !0
	},
	handler: (e, t) => {
		var { parser: n } = e, r = t[0];
		return {
			type: "op",
			mode: n.mode,
			limits: !1,
			parentIsSupSub: !1,
			symbol: !1,
			body: J(r)
		};
	},
	htmlBuilder: Oi,
	mathmlBuilder: ki
});
var ji = {
	"∫": "\\int",
	"∬": "\\iint",
	"∭": "\\iiint",
	"∮": "\\oint",
	"∯": "\\oiint",
	"∰": "\\oiiint"
};
q({
	type: "op",
	names: /* @__PURE__ */ "\\arcsin.\\arccos.\\arctan.\\arctg.\\arcctg.\\arg.\\ch.\\cos.\\cosec.\\cosh.\\cot.\\cotg.\\coth.\\csc.\\ctg.\\cth.\\deg.\\dim.\\exp.\\hom.\\ker.\\lg.\\ln.\\log.\\sec.\\sin.\\sinh.\\sh.\\tan.\\tanh.\\tg.\\th".split("."),
	props: { numArgs: 0 },
	handler(e) {
		var { parser: t, funcName: n } = e;
		return {
			type: "op",
			mode: t.mode,
			limits: !1,
			parentIsSupSub: !1,
			symbol: !1,
			name: n
		};
	},
	htmlBuilder: Oi,
	mathmlBuilder: ki
}), q({
	type: "op",
	names: [
		"\\det",
		"\\gcd",
		"\\inf",
		"\\lim",
		"\\max",
		"\\min",
		"\\Pr",
		"\\sup"
	],
	props: { numArgs: 0 },
	handler(e) {
		var { parser: t, funcName: n } = e;
		return {
			type: "op",
			mode: t.mode,
			limits: !0,
			parentIsSupSub: !1,
			symbol: !1,
			name: n
		};
	},
	htmlBuilder: Oi,
	mathmlBuilder: ki
}), q({
	type: "op",
	names: [
		"\\int",
		"\\iint",
		"\\iiint",
		"\\oint",
		"\\oiint",
		"\\oiiint",
		"∫",
		"∬",
		"∭",
		"∮",
		"∯",
		"∰"
	],
	props: {
		numArgs: 0,
		allowedInArgument: !0
	},
	handler(e) {
		var { parser: t, funcName: n } = e, r = n;
		return r.length === 1 && (r = ji[r]), {
			type: "op",
			mode: t.mode,
			limits: !1,
			parentIsSupSub: !1,
			symbol: !0,
			name: r
		};
	},
	htmlBuilder: Oi,
	mathmlBuilder: ki
});
var Mi = (e, t) => {
	var n, r, i = !1, a;
	e.type === "supsub" ? (n = e.sup, r = e.sub, a = Q(e.base, "operatorname"), i = !0) : a = Q(e, "operatorname");
	var o;
	if (a.body.length > 0) {
		for (var s = dn(a.body.map((e) => {
			var t = "text" in e ? e.text : void 0;
			return typeof t == "string" ? {
				type: "textord",
				mode: e.mode,
				text: t
			} : e;
		}), t.withFont("mathrm"), !0), c = 0; c < s.length; c++) {
			var l = s[c];
			l instanceof Ie && (l.text = l.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
		}
		o = W(["mop"], s, t);
	} else o = W(["mop"], [], t);
	return i ? Ei(o, n, r, t, t.style, 0, 0) : o;
};
q({
	type: "operatorname",
	names: ["\\operatorname@", "\\operatornamewithlimits"],
	props: { numArgs: 1 },
	handler: (e, t) => {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "operatorname",
			mode: n.mode,
			body: J(i),
			alwaysHandleSupSub: r === "\\operatornamewithlimits",
			limits: !1,
			parentIsSupSub: !1
		};
	},
	htmlBuilder: Mi,
	mathmlBuilder: (e, t) => {
		for (var n = kn(e.body, t.withFont("mathrm")), r = !0, i = 0; i < n.length; i++) {
			var a = n[i];
			if (!(a instanceof xn)) {
				if (a instanceof X) switch (a.type) {
					case "mi":
					case "mn":
					case "mspace":
					case "mtext": break;
					case "mo":
						var o = a.children[0];
						a.children.length === 1 && o instanceof bn ? o.text = o.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : r = !1;
						break;
					default: r = !1;
				}
				else r = !1;
			}
		}
		r && (n = [new bn(n.map((e) => e.toText()).join(""))]);
		var s = new X("mi", n);
		s.setAttribute("mathvariant", "normal");
		var c = new X("mo", [wn("⁡", "text")]);
		return e.parentIsSupSub ? new X("mrow", [s, c]) : yn([s, c]);
	}
}), $("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@"), an({
	type: "ordgroup",
	htmlBuilder(e, t) {
		return e.semisimple ? Ut(dn(e.body, t, !1)) : W(["mord"], dn(e.body, t, !0), t);
	},
	mathmlBuilder(e, t) {
		return An(e.body, t, !0);
	}
}), q({
	type: "overline",
	names: ["\\overline"],
	props: { numArgs: 1 },
	handler(e, t) {
		var { parser: n } = e, r = t[0];
		return {
			type: "overline",
			mode: n.mode,
			body: r
		};
	},
	htmlBuilder(e, t) {
		var n = Y(e.body, t.havingCrampedStyle()), r = Vt("overline-line", t), i = t.fontMetrics().defaultRuleThickness;
		return W(["mord", "overline"], [G({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: n
				},
				{
					type: "kern",
					size: 3 * i
				},
				{
					type: "elem",
					elem: r
				},
				{
					type: "kern",
					size: i
				}
			]
		})], t);
	},
	mathmlBuilder(e, t) {
		var n = new X("mo", [new bn("‾")]);
		n.setAttribute("stretchy", "true");
		var r = new X("mover", [Z(e.body, t), n]);
		return r.setAttribute("accent", "true"), r;
	}
}), q({
	type: "phantom",
	names: ["\\phantom"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n } = e, r = t[0];
		return {
			type: "phantom",
			mode: n.mode,
			body: J(r)
		};
	},
	htmlBuilder: (e, t) => Ut(dn(e.body, t.withPhantom(), !1)),
	mathmlBuilder: (e, t) => new X("mphantom", kn(e.body, t))
}), $("\\hphantom", "\\smash{\\phantom{#1}}"), q({
	type: "vphantom",
	names: ["\\vphantom"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { parser: n } = e, r = t[0];
		return {
			type: "vphantom",
			mode: n.mode,
			body: r
		};
	},
	htmlBuilder: (e, t) => W(["mord", "rlap"], [W(["inner"], [Y(e.body, t.withPhantom())]), W(["fix"], [])], t),
	mathmlBuilder: (e, t) => {
		var n = new X("mpadded", [new X("mphantom", kn(J(e.body), t))]);
		return n.setAttribute("width", "0px"), n;
	}
}), q({
	type: "raisebox",
	names: ["\\raisebox"],
	props: {
		numArgs: 2,
		argTypes: ["size", "hbox"],
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n } = e, r = Q(t[0], "size").value, i = t[1];
		return {
			type: "raisebox",
			mode: n.mode,
			dy: r,
			body: i
		};
	},
	htmlBuilder(e, t) {
		var n = Y(e.body, t);
		return G({
			positionType: "shift",
			positionData: -O(e.dy, t),
			children: [{
				type: "elem",
				elem: n
			}]
		});
	},
	mathmlBuilder(e, t) {
		var n = new X("mpadded", [Z(e.body, t)]), r = e.dy.number + e.dy.unit;
		return n.setAttribute("voffset", r), n;
	}
}), q({
	type: "internal",
	names: ["\\relax"],
	props: {
		numArgs: 0,
		allowedInText: !0,
		allowedInArgument: !0
	},
	handler(e) {
		var { parser: t } = e;
		return {
			type: "internal",
			mode: t.mode
		};
	}
}), q({
	type: "rule",
	names: ["\\rule"],
	props: {
		numArgs: 2,
		numOptionalArgs: 1,
		allowedInText: !0,
		allowedInMath: !0,
		argTypes: [
			"size",
			"size",
			"size"
		]
	},
	handler(e, t, n) {
		var { parser: r } = e, i = n[0], a = Q(t[0], "size"), o = Q(t[1], "size");
		return {
			type: "rule",
			mode: r.mode,
			shift: i && Q(i, "size").value,
			width: a.value,
			height: o.value
		};
	},
	htmlBuilder(e, t) {
		var n = W(["mord", "rule"], [], t), r = O(e.width, t), i = O(e.height, t), a = e.shift ? O(e.shift, t) : 0;
		return n.style.borderRightWidth = k(r), n.style.borderTopWidth = k(i), n.style.bottom = k(a), n.width = r, n.height = i + a, n.depth = -a, n.maxFontSize = i * 1.125 * t.sizeMultiplier, n;
	},
	mathmlBuilder(e, t) {
		var n = O(e.width, t), r = O(e.height, t), i = e.shift ? O(e.shift, t) : 0, a = t.color && t.getColor() || "black", o = new X("mspace");
		o.setAttribute("mathbackground", a), o.setAttribute("width", k(n)), o.setAttribute("height", k(r));
		var s = new X("mpadded", [o]);
		return i >= 0 ? s.setAttribute("height", k(i)) : (s.setAttribute("height", k(i)), s.setAttribute("depth", k(-i))), s.setAttribute("voffset", k(i)), s;
	}
});
function Ni(e, t, n) {
	for (var r = dn(e, t, !1), i = t.sizeMultiplier / n.sizeMultiplier, a = 0; a < r.length; a++) {
		var o = r[a].classes.indexOf("sizing");
		o < 0 ? Array.prototype.push.apply(r[a].classes, t.sizingClasses(n)) : r[a].classes[o + 1] === "reset-size" + t.size && (r[a].classes[o + 1] = "reset-size" + n.size), r[a].height *= i, r[a].depth *= i;
	}
	return Ut(r);
}
var Pi = [
	"\\tiny",
	"\\sixptsize",
	"\\scriptsize",
	"\\footnotesize",
	"\\small",
	"\\normalsize",
	"\\large",
	"\\Large",
	"\\LARGE",
	"\\huge",
	"\\Huge"
];
q({
	type: "sizing",
	names: Pi,
	props: {
		numArgs: 0,
		allowedInText: !0
	},
	handler: (e, t) => {
		var { breakOnTokenText: n, funcName: r, parser: i } = e, a = i.parseExpression(!1, n);
		return {
			type: "sizing",
			mode: i.mode,
			size: Pi.indexOf(r) + 1,
			body: a
		};
	},
	htmlBuilder: (e, t) => {
		var n = t.havingSize(e.size);
		return Ni(e.body, n, t);
	},
	mathmlBuilder: (e, t) => {
		var n = t.havingSize(e.size), r = new X("mstyle", kn(e.body, n));
		return r.setAttribute("mathsize", k(n.sizeMultiplier)), r;
	}
}), q({
	type: "smash",
	names: ["\\smash"],
	props: {
		numArgs: 1,
		numOptionalArgs: 1,
		allowedInText: !0
	},
	handler: (e, t, n) => {
		var { parser: r } = e, i = !1, a = !1, o = n[0] && Q(n[0], "ordgroup");
		if (o) for (var s, c = 0; c < o.body.length; ++c) {
			var l = o.body[c];
			if (s = Yn(l).text, s === "t") i = !0;
			else if (s === "b") a = !0;
			else {
				i = !1, a = !1;
				break;
			}
		}
		else i = !0, a = !0;
		var u = t[0];
		return {
			type: "smash",
			mode: r.mode,
			body: u,
			smashHeight: i,
			smashDepth: a
		};
	},
	htmlBuilder: (e, t) => {
		var n = W([], [Y(e.body, t)]);
		if (!e.smashHeight && !e.smashDepth) return n;
		if (e.smashHeight && (n.height = 0), e.smashDepth && (n.depth = 0), e.smashHeight && e.smashDepth) return W(["mord", "smash"], [n], t);
		if (n.children) for (var r = 0; r < n.children.length; r++) e.smashHeight && (n.children[r].height = 0), e.smashDepth && (n.children[r].depth = 0);
		return W(["mord"], [G({
			positionType: "firstBaseline",
			children: [{
				type: "elem",
				elem: n
			}]
		})], t);
	},
	mathmlBuilder: (e, t) => {
		var n = new X("mpadded", [Z(e.body, t)]);
		return e.smashHeight && n.setAttribute("height", "0px"), e.smashDepth && n.setAttribute("depth", "0px"), n;
	}
}), q({
	type: "sqrt",
	names: ["\\sqrt"],
	props: {
		numArgs: 1,
		numOptionalArgs: 1
	},
	handler(e, t, n) {
		var { parser: r } = e, i = n[0], a = t[0];
		return {
			type: "sqrt",
			mode: r.mode,
			body: a,
			index: i
		};
	},
	htmlBuilder(e, t) {
		var n = Y(e.body, t.havingCrampedStyle());
		n.height === 0 && (n.height = t.fontMetrics().xHeight), n = Wt(n, t);
		var r = t.fontMetrics().defaultRuleThickness, i = r;
		t.style.id < E.TEXT.id && (i = t.fontMetrics().xHeight);
		var a = r + i / 4, { span: o, ruleWidth: s, advanceWidth: c } = Nr(n.height + n.depth + a + r, t), l = o.height - s;
		l > n.height + n.depth + a && (a = (a + l - n.height - n.depth) / 2);
		var u = o.height - n.height - a - s;
		n.style.paddingLeft = k(c);
		var d = G({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: n,
					wrapperClasses: ["svg-align"]
				},
				{
					type: "kern",
					size: -(n.height + u)
				},
				{
					type: "elem",
					elem: o
				},
				{
					type: "kern",
					size: s
				}
			]
		});
		if (e.index) {
			var f = t.havingStyle(E.SCRIPTSCRIPT), p = Y(e.index, f, t);
			return W(["mord", "sqrt"], [W(["root"], [G({
				positionType: "shift",
				positionData: -(.6 * (d.height - d.depth)),
				children: [{
					type: "elem",
					elem: p
				}]
			})]), d], t);
		}
		return W(["mord", "sqrt"], [d], t);
	},
	mathmlBuilder(e, t) {
		var { body: n, index: r } = e;
		return r ? new X("mroot", [Z(n, t), Z(r, t)]) : new X("msqrt", [Z(n, t)]);
	}
});
var Fi = {
	display: E.DISPLAY,
	text: E.TEXT,
	script: E.SCRIPT,
	scriptscript: E.SCRIPTSCRIPT
};
function Ii(e) {
	return e in Fi;
}
q({
	type: "styling",
	names: [
		"\\displaystyle",
		"\\textstyle",
		"\\scriptstyle",
		"\\scriptscriptstyle"
	],
	props: {
		numArgs: 0,
		allowedInText: !0,
		primitive: !0
	},
	handler(e, t) {
		var { breakOnTokenText: n, funcName: r, parser: i } = e, a = i.parseExpression(!0, n), o = r.slice(1, r.length - 5);
		if (!Ii(o)) throw Error("Unknown style: " + o);
		return {
			type: "styling",
			mode: i.mode,
			style: o,
			body: a
		};
	},
	htmlBuilder(e, t) {
		var n = Fi[e.style], r = t.havingStyle(n);
		return e.resetFont && (r = r.withFont("")), Ni(e.body, r, t);
	},
	mathmlBuilder(e, t) {
		var n = Fi[e.style], r = t.havingStyle(n);
		e.resetFont && (r = r.withFont(""));
		var i = new X("mstyle", kn(e.body, r)), a = {
			display: ["0", "true"],
			text: ["0", "false"],
			script: ["1", "false"],
			scriptscript: ["2", "false"]
		}[e.style];
		return i.setAttribute("scriptlevel", a[0]), i.setAttribute("displaystyle", a[1]), i;
	}
});
var Li = function(e, t) {
	var n = e.base;
	return n ? n.type === "op" ? n.limits && (t.style.size === E.DISPLAY.size || n.alwaysHandleSupSub) ? Oi : null : n.type === "operatorname" ? n.alwaysHandleSupSub && (t.style.size === E.DISPLAY.size || n.limits) ? Mi : null : n.type === "accent" ? c(n.base) ? Qn : null : n.type === "horizBrace" && !e.sub === n.isOver ? Ci : null : null;
};
an({
	type: "supsub",
	htmlBuilder(e, t) {
		var n = Li(e, t);
		if (n) return n(e, t);
		var { base: r, sup: i, sub: a } = e, o = Y(r, t), s, l, u = t.fontMetrics(), d = 0, f = 0, p = r && c(r);
		if (i) {
			var m = t.havingStyle(t.style.sup());
			s = Y(i, m, t), p || (d = o.height - m.fontMetrics().supDrop * m.sizeMultiplier / t.sizeMultiplier);
		}
		if (a) {
			var h = t.havingStyle(t.style.sub());
			l = Y(a, h, t), p || (f = o.depth + h.fontMetrics().subDrop * h.sizeMultiplier / t.sizeMultiplier);
		}
		var g = t.style === E.DISPLAY ? u.sup1 : t.style.cramped ? u.sup3 : u.sup2, _ = t.sizeMultiplier, v = k(.5 / u.ptPerEm / _), y = null;
		if (l) {
			var b = e.base && e.base.type === "op" && e.base.name && (e.base.name === "\\oiint" || e.base.name === "\\oiiint");
			(o instanceof Ie || b) && (y = k(-(o.italic ?? 0)));
		}
		var x;
		if (s && l) {
			d = Math.max(d, g, s.depth + .25 * u.xHeight), f = Math.max(f, u.sub2);
			var S = 4 * u.defaultRuleThickness;
			if (d - s.depth - (l.height - f) < S) {
				f = S - (d - s.depth) + l.height;
				var C = .8 * u.xHeight - (d - s.depth);
				C > 0 && (d += C, f -= C);
			}
			x = G({
				positionType: "individualShift",
				children: [{
					type: "elem",
					elem: l,
					shift: f,
					marginRight: v,
					marginLeft: y
				}, {
					type: "elem",
					elem: s,
					shift: -d,
					marginRight: v
				}]
			});
		} else if (l) f = Math.max(f, u.sub1, l.height - .8 * u.xHeight), x = G({
			positionType: "shift",
			positionData: f,
			children: [{
				type: "elem",
				elem: l,
				marginLeft: y,
				marginRight: v
			}]
		});
		else if (s) d = Math.max(d, g, s.depth + .25 * u.xHeight), x = G({
			positionType: "shift",
			positionData: -d,
			children: [{
				type: "elem",
				elem: s,
				marginRight: v
			}]
		});
		else throw Error("supsub must have either sup or sub.");
		return W([hn(o, "right") || "mord"], [o, W(["msupsub"], [x])], t);
	},
	mathmlBuilder(e, t) {
		var n = !1, r, i;
		e.base && e.base.type === "horizBrace" && (i = !!e.sup, i === e.base.isOver && (n = !0, r = e.base.isOver)), e.base && (e.base.type === "op" || e.base.type === "operatorname") && (e.base.parentIsSupSub = !0);
		var a = [Z(e.base, t)];
		e.sub && a.push(Z(e.sub, t)), e.sup && a.push(Z(e.sup, t));
		var o;
		if (n) o = r ? "mover" : "munder";
		else if (e.sub) {
			if (e.sup) {
				var s = e.base;
				o = s && s.type === "op" && s.limits && t.style === E.DISPLAY || s && s.type === "operatorname" && s.alwaysHandleSupSub && (t.style === E.DISPLAY || s.limits) ? "munderover" : "msubsup";
			} else {
				var c = e.base;
				o = c && c.type === "op" && c.limits && (t.style === E.DISPLAY || c.alwaysHandleSupSub) || c && c.type === "operatorname" && c.alwaysHandleSupSub && (c.limits || t.style === E.DISPLAY) ? "munder" : "msub";
			}
		} else {
			var l = e.base;
			o = l && l.type === "op" && l.limits && (t.style === E.DISPLAY || l.alwaysHandleSupSub) || l && l.type === "operatorname" && l.alwaysHandleSupSub && (l.limits || t.style === E.DISPLAY) ? "mover" : "msup";
		}
		return new X(o, a);
	}
}), an({
	type: "atom",
	htmlBuilder(e, t) {
		return Pt(e.text, e.mode, t, ["m" + e.family]);
	},
	mathmlBuilder(e, t) {
		var n = new X("mo", [wn(e.text, e.mode)]);
		if (e.family === "bin") {
			var r = Dn(e, t);
			r === "bold-italic" && n.setAttribute("mathvariant", r);
		} else e.family === "punct" ? n.setAttribute("separator", "true") : (e.family === "open" || e.family === "close") && n.setAttribute("stretchy", "false");
		return n;
	}
});
var Ri = {
	mi: "italic",
	mn: "normal",
	mtext: "normal"
};
an({
	type: "mathord",
	htmlBuilder(e, t) {
		return It(e, t, "mathord");
	},
	mathmlBuilder(e, t) {
		var n = new X("mi", [wn(e.text, e.mode, t)]), r = Dn(e, t) || "italic";
		return r !== Ri[n.type] && n.setAttribute("mathvariant", r), n;
	}
}), an({
	type: "textord",
	htmlBuilder(e, t) {
		return It(e, t, "textord");
	},
	mathmlBuilder(e, t) {
		var n = wn(e.text, e.mode, t), r = Dn(e, t) || "normal", i;
		return i = e.mode === "text" ? new X("mtext", [n]) : /[0-9]/.test(e.text) ? new X("mn", [n]) : e.text === "\\prime" ? new X("mo", [n]) : new X("mi", [n]), r !== Ri[i.type] && i.setAttribute("mathvariant", r), i;
	}
});
var zi = {
	"\\nobreak": "nobreak",
	"\\allowbreak": "allowbreak"
}, Bi = {
	" ": {},
	"\\ ": {},
	"~": { className: "nobreak" },
	"\\space": {},
	"\\nobreakspace": { className: "nobreak" }
};
an({
	type: "spacing",
	htmlBuilder(t, n) {
		if (Bi.hasOwnProperty(t.text)) {
			var r = Bi[t.text].className || "";
			if (t.mode === "text") {
				var i = It(t, n, "textord");
				return i.classes.push(r), i;
			}
			return W(["mspace", r], [Pt(t.text, t.mode, n)], n);
		}
		if (zi.hasOwnProperty(t.text)) return W(["mspace", zi[t.text]], [], n);
		throw new e("Unknown type of space \"" + t.text + "\"");
	},
	mathmlBuilder(t, n) {
		var r;
		if (Bi.hasOwnProperty(t.text)) r = new X("mtext", [new bn("\xA0")]);
		else {
			if (zi.hasOwnProperty(t.text)) return new X("mspace");
			throw new e("Unknown type of space \"" + t.text + "\"");
		}
		return r;
	}
});
var Vi = () => {
	var e = new X("mtd", []);
	return e.setAttribute("width", "50%"), e;
};
an({
	type: "tag",
	mathmlBuilder(e, t) {
		var n = new X("mtable", [new X("mtr", [
			Vi(),
			new X("mtd", [An(e.body, t)]),
			Vi(),
			new X("mtd", [An(e.tag, t)])
		])]);
		return n.setAttribute("width", "100%"), n;
	}
});
var Hi = {
	"\\text": void 0,
	"\\textrm": "textrm",
	"\\textsf": "textsf",
	"\\texttt": "texttt",
	"\\textnormal": "textrm"
}, Ui = {
	"\\textbf": "textbf",
	"\\textmd": "textmd"
}, Wi = {
	"\\textit": "textit",
	"\\textup": "textup"
}, Gi = (e, t) => {
	var n = e.font;
	if (n) {
		if (Hi[n]) return t.withTextFontFamily(Hi[n]);
		if (Ui[n]) return t.withTextFontWeight(Ui[n]);
		if (n === "\\emph") return t.fontShape === "textit" ? t.withTextFontShape("textup") : t.withTextFontShape("textit");
	} else return t;
	return t.withTextFontShape(Wi[n]);
};
q({
	type: "text",
	names: [
		"\\text",
		"\\textrm",
		"\\textsf",
		"\\texttt",
		"\\textnormal",
		"\\textbf",
		"\\textmd",
		"\\textit",
		"\\textup",
		"\\emph"
	],
	props: {
		numArgs: 1,
		argTypes: ["text"],
		allowedInArgument: !0,
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n, funcName: r } = e, i = t[0];
		return {
			type: "text",
			mode: n.mode,
			body: J(i),
			font: r
		};
	},
	htmlBuilder(e, t) {
		var n = Gi(e, t);
		return W(["mord", "text"], dn(e.body, n, !0), n);
	},
	mathmlBuilder(e, t) {
		var n = Gi(e, t);
		return An(e.body, n);
	}
}), q({
	type: "underline",
	names: ["\\underline"],
	props: {
		numArgs: 1,
		allowedInText: !0
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "underline",
			mode: n.mode,
			body: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = Y(e.body, t), r = Vt("underline-line", t), i = t.fontMetrics().defaultRuleThickness;
		return W(["mord", "underline"], [G({
			positionType: "top",
			positionData: n.height,
			children: [
				{
					type: "kern",
					size: i
				},
				{
					type: "elem",
					elem: r
				},
				{
					type: "kern",
					size: 3 * i
				},
				{
					type: "elem",
					elem: n
				}
			]
		})], t);
	},
	mathmlBuilder(e, t) {
		var n = new X("mo", [new bn("‾")]);
		n.setAttribute("stretchy", "true");
		var r = new X("munder", [Z(e.body, t), n]);
		return r.setAttribute("accentunder", "true"), r;
	}
}), q({
	type: "vcenter",
	names: ["\\vcenter"],
	props: {
		numArgs: 1,
		argTypes: ["original"],
		allowedInText: !1
	},
	handler(e, t) {
		var { parser: n } = e;
		return {
			type: "vcenter",
			mode: n.mode,
			body: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = Y(e.body, t), r = t.fontMetrics().axisHeight;
		return G({
			positionType: "shift",
			positionData: .5 * (n.height - r - (n.depth + r)),
			children: [{
				type: "elem",
				elem: n
			}]
		});
	},
	mathmlBuilder(e, t) {
		return new X("mrow", [new X("mpadded", [Z(e.body, t)], ["vcenter"])]);
	}
}), q({
	type: "verb",
	names: ["\\verb"],
	props: {
		numArgs: 0,
		allowedInText: !0
	},
	handler(t, n, r) {
		throw new e("\\verb ended by end of line instead of matching delimiter");
	},
	htmlBuilder(e, t) {
		for (var n = Ki(e), r = [], i = t.havingStyle(t.style.text()), a = 0; a < n.length; a++) {
			var o = n[a];
			o === "~" && (o = "\\textasciitilde"), r.push(Nt(o, "Typewriter-Regular", e.mode, i, ["mord", "texttt"]));
		}
		return W(["mord", "text"].concat(i.sizingClasses(t)), Rt(r), i);
	},
	mathmlBuilder(e, t) {
		var n = new X("mtext", [new bn(Ki(e))]);
		return n.setAttribute("mathvariant", "monospace"), n;
	}
});
var Ki = (e) => e.body.replace(/ /g, e.star ? "␣" : "\xA0"), qi = tn, Ji = "[ \r\n	]", Yi = "\\\\[a-zA-Z@]+", Xi = "\\\\[^\ud800-\udfff]", Zi = "(" + Yi + ")" + Ji + "*", Qi = "\\\\(\n|[ \r	]+\n?)[ \r	]*", $i = "[̀-ͯ]", ea = RegExp($i + "+$"), ta = "(" + Ji + "+)|" + (Qi + "|") + "([!-\\[\\]-‧‪-퟿豈-￿]" + ($i + "*") + "|[\ud800-\udbff][\udc00-\udfff]" + ($i + "*") + "|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + ("|" + Zi) + ("|" + Xi + ")"), na = class {
	constructor(e, t) {
		this.input = void 0, this.settings = void 0, this.tokenRegex = void 0, this.catcodes = void 0, this.input = e, this.settings = t, this.tokenRegex = new RegExp(ta, "g"), this.catcodes = {
			"%": 14,
			"~": 13
		};
	}
	setCatcode(e, t) {
		this.catcodes[e] = t;
	}
	lex() {
		var t = this.input, n = this.tokenRegex.lastIndex;
		if (n === t.length) return new ri("EOF", new ni(this, n, n));
		var r = this.tokenRegex.exec(t);
		if (r === null || r.index !== n) throw new e("Unexpected character: '" + t[n] + "'", new ri(t[n], new ni(this, n, n + 1)));
		var i = r[6] || r[3] || (r[2] ? "\\ " : " ");
		if (this.catcodes[i] === 14) {
			var a = t.indexOf("\n", this.tokenRegex.lastIndex);
			return a === -1 ? (this.tokenRegex.lastIndex = t.length, this.settings.reportNonstrict("commentAtEnd", "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)")) : this.tokenRegex.lastIndex = a + 1, this.lex();
		}
		return new ri(i, new ni(this, n, this.tokenRegex.lastIndex));
	}
}, ra = class {
	constructor(e, t) {
		e === void 0 && (e = {}), t === void 0 && (t = {}), this.current = void 0, this.builtins = void 0, this.undefStack = void 0, this.current = t, this.builtins = e, this.undefStack = [];
	}
	beginGroup() {
		this.undefStack.push({});
	}
	endGroup() {
		if (this.undefStack.length === 0) throw new e("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
		var t = this.undefStack.pop();
		for (var n in t) t.hasOwnProperty(n) && (t[n] == null ? delete this.current[n] : this.current[n] = t[n]);
	}
	endGroups() {
		for (; this.undefStack.length > 0;) this.endGroup();
	}
	has(e) {
		return this.current.hasOwnProperty(e) || this.builtins.hasOwnProperty(e);
	}
	get(e) {
		return this.current.hasOwnProperty(e) ? this.current[e] : this.builtins[e];
	}
	set(e, t, n) {
		if (n === void 0 && (n = !1), n) {
			for (var r = 0; r < this.undefStack.length; r++) delete this.undefStack[r][e];
			this.undefStack.length > 0 && (this.undefStack[this.undefStack.length - 1][e] = t);
		} else {
			var i = this.undefStack[this.undefStack.length - 1];
			i && !i.hasOwnProperty(e) && (i[e] = this.current[e]);
		}
		t == null ? delete this.current[e] : this.current[e] = t;
	}
}, ia = ti;
$("\\noexpand", function(e) {
	var t = e.popToken();
	return e.isExpandable(t.text) && (t.noexpand = !0, t.treatAsRelax = !0), {
		tokens: [t],
		numArgs: 0
	};
}), $("\\expandafter", function(e) {
	var t = e.popToken();
	return e.expandOnce(!0), {
		tokens: [t],
		numArgs: 0
	};
}), $("\\@firstoftwo", function(e) {
	return {
		tokens: e.consumeArgs(2)[0],
		numArgs: 0
	};
}), $("\\@secondoftwo", function(e) {
	return {
		tokens: e.consumeArgs(2)[1],
		numArgs: 0
	};
}), $("\\@ifnextchar", function(e) {
	var t = e.consumeArgs(3);
	e.consumeSpaces();
	var n = e.future();
	return t[0].length === 1 && t[0][0].text === n.text ? {
		tokens: t[1],
		numArgs: 0
	} : {
		tokens: t[2],
		numArgs: 0
	};
}), $("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}"), $("\\TextOrMath", function(e) {
	var t = e.consumeArgs(2);
	return e.mode === "text" ? {
		tokens: t[0],
		numArgs: 0
	} : {
		tokens: t[1],
		numArgs: 0
	};
});
var aa = {
	0: 0,
	1: 1,
	2: 2,
	3: 3,
	4: 4,
	5: 5,
	6: 6,
	7: 7,
	8: 8,
	9: 9,
	a: 10,
	A: 10,
	b: 11,
	B: 11,
	c: 12,
	C: 12,
	d: 13,
	D: 13,
	e: 14,
	E: 14,
	f: 15,
	F: 15
};
$("\\char", function(t) {
	var n = t.popToken(), r, i = 0;
	if (n.text === "'") r = 8, n = t.popToken();
	else if (n.text === "\"") r = 16, n = t.popToken();
	else if (n.text === "`") {
		if (n = t.popToken(), n.text[0] === "\\") i = n.text.charCodeAt(1);
		else {
			if (n.text === "EOF") throw new e("\\char` missing argument");
			i = n.text.charCodeAt(0);
		}
	} else r = 10;
	if (r) {
		if (i = aa[n.text], i == null || i >= r) throw new e("Invalid base-" + r + " digit " + n.text);
		for (var a; (a = aa[t.future().text]) != null && a < r;) i *= r, i += a, t.popToken();
	}
	return "\\@char{" + i + "}";
});
var oa = (t, n, r, i) => {
	var a = t.consumeArg().tokens;
	if (a.length !== 1) throw new e("\\newcommand's first argument must be a macro name");
	var o = a[0].text, s = t.isDefined(o);
	if (s && !n) throw new e("\\newcommand{" + o + "} attempting to redefine " + (o + "; use \\renewcommand"));
	if (!s && !r) throw new e("\\renewcommand{" + o + "} when command " + o + " does not yet exist; use \\newcommand");
	var c = 0;
	if (a = t.consumeArg().tokens, a.length === 1 && a[0].text === "[") {
		for (var l = "", u = t.expandNextToken(); u.text !== "]" && u.text !== "EOF";) l += u.text, u = t.expandNextToken();
		if (!l.match(/^\s*[0-9]+\s*$/)) throw new e("Invalid number of arguments: " + l);
		c = parseInt(l), a = t.consumeArg().tokens;
	}
	return s && i || t.macros.set(o, {
		tokens: a,
		numArgs: c
	}), "";
};
$("\\newcommand", (e) => oa(e, !1, !0, !1)), $("\\renewcommand", (e) => oa(e, !0, !1, !1)), $("\\providecommand", (e) => oa(e, !0, !0, !0)), $("\\message", (e) => {
	var t = e.consumeArgs(1)[0];
	return console.log(t.reverse().map((e) => e.text).join("")), "";
}), $("\\errmessage", (e) => {
	var t = e.consumeArgs(1)[0];
	return console.error(t.reverse().map((e) => e.text).join("")), "";
}), $("\\show", (e) => {
	var t = e.popToken(), n = t.text;
	return console.log(t, e.macros.get(n), qi[n], A.math[n], A.text[n]), "";
}), $("\\bgroup", "{"), $("\\egroup", "}"), $("~", "\\nobreakspace"), $("\\lq", "`"), $("\\rq", "'"), $("\\aa", "\\r a"), $("\\AA", "\\r A"), $("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}"), $("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}"), $("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}"), $("ℬ", "\\mathscr{B}"), $("ℰ", "\\mathscr{E}"), $("ℱ", "\\mathscr{F}"), $("ℋ", "\\mathscr{H}"), $("ℐ", "\\mathscr{I}"), $("ℒ", "\\mathscr{L}"), $("ℳ", "\\mathscr{M}"), $("ℛ", "\\mathscr{R}"), $("ℭ", "\\mathfrak{C}"), $("ℌ", "\\mathfrak{H}"), $("ℨ", "\\mathfrak{Z}"), $("\\Bbbk", "\\Bbb{k}"), $("\\llap", "\\mathllap{\\textrm{#1}}"), $("\\rlap", "\\mathrlap{\\textrm{#1}}"), $("\\clap", "\\mathclap{\\textrm{#1}}"), $("\\mathstrut", "\\vphantom{(}"), $("\\underbar", "\\underline{\\text{#1}}"), $("\\not", "\\html@mathml{\\mathrel{\\mathrlap\\@not}\\nobreak}{\\char\"338}"), $("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}"), $("\\ne", "\\neq"), $("≠", "\\neq"), $("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}"), $("∉", "\\notin"), $("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}"), $("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}"), $("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}"), $("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}"), $("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}"), $("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}"), $("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}"), $("⟂", "\\perp"), $("‼", "\\mathclose{!\\mkern-0.8mu!}"), $("∌", "\\notni"), $("⌜", "\\ulcorner"), $("⌝", "\\urcorner"), $("⌞", "\\llcorner"), $("⌟", "\\lrcorner"), $("©", "\\copyright"), $("®", "\\textregistered"), $("\\ulcorner", "\\html@mathml{\\@ulcorner}{\\mathop{\\char\"231c}}"), $("\\urcorner", "\\html@mathml{\\@urcorner}{\\mathop{\\char\"231d}}"), $("\\llcorner", "\\html@mathml{\\@llcorner}{\\mathop{\\char\"231e}}"), $("\\lrcorner", "\\html@mathml{\\@lrcorner}{\\mathop{\\char\"231f}}"), $("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}"), $("⋮", "\\vdots"), $("\\varGamma", "\\mathit{\\Gamma}"), $("\\varDelta", "\\mathit{\\Delta}"), $("\\varTheta", "\\mathit{\\Theta}"), $("\\varLambda", "\\mathit{\\Lambda}"), $("\\varXi", "\\mathit{\\Xi}"), $("\\varPi", "\\mathit{\\Pi}"), $("\\varSigma", "\\mathit{\\Sigma}"), $("\\varUpsilon", "\\mathit{\\Upsilon}"), $("\\varPhi", "\\mathit{\\Phi}"), $("\\varPsi", "\\mathit{\\Psi}"), $("\\varOmega", "\\mathit{\\Omega}"), $("\\substack", "\\begin{subarray}{c}#1\\end{subarray}"), $("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax"), $("\\boxed", "\\fbox{$\\displaystyle{#1}$}"), $("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;"), $("\\implies", "\\DOTSB\\;\\Longrightarrow\\;"), $("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;"), $("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}"), $("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
var sa = {
	",": "\\dotsc",
	"\\not": "\\dotsb",
	"+": "\\dotsb",
	"=": "\\dotsb",
	"<": "\\dotsb",
	">": "\\dotsb",
	"-": "\\dotsb",
	"*": "\\dotsb",
	":": "\\dotsb",
	"\\DOTSB": "\\dotsb",
	"\\coprod": "\\dotsb",
	"\\bigvee": "\\dotsb",
	"\\bigwedge": "\\dotsb",
	"\\biguplus": "\\dotsb",
	"\\bigcap": "\\dotsb",
	"\\bigcup": "\\dotsb",
	"\\prod": "\\dotsb",
	"\\sum": "\\dotsb",
	"\\bigotimes": "\\dotsb",
	"\\bigoplus": "\\dotsb",
	"\\bigodot": "\\dotsb",
	"\\bigsqcup": "\\dotsb",
	"\\And": "\\dotsb",
	"\\longrightarrow": "\\dotsb",
	"\\Longrightarrow": "\\dotsb",
	"\\longleftarrow": "\\dotsb",
	"\\Longleftarrow": "\\dotsb",
	"\\longleftrightarrow": "\\dotsb",
	"\\Longleftrightarrow": "\\dotsb",
	"\\mapsto": "\\dotsb",
	"\\longmapsto": "\\dotsb",
	"\\hookrightarrow": "\\dotsb",
	"\\doteq": "\\dotsb",
	"\\mathbin": "\\dotsb",
	"\\mathrel": "\\dotsb",
	"\\relbar": "\\dotsb",
	"\\Relbar": "\\dotsb",
	"\\xrightarrow": "\\dotsb",
	"\\xleftarrow": "\\dotsb",
	"\\DOTSI": "\\dotsi",
	"\\int": "\\dotsi",
	"\\oint": "\\dotsi",
	"\\iint": "\\dotsi",
	"\\iiint": "\\dotsi",
	"\\iiiint": "\\dotsi",
	"\\idotsint": "\\dotsi",
	"\\DOTSX": "\\dotsx"
}, ca = /* @__PURE__ */ new Set(["bin", "rel"]);
$("\\dots", function(e) {
	var t = "\\dotso", n = e.expandAfterFuture().text;
	return n in sa ? t = sa[n] : (n.slice(0, 4) === "\\not" || n in A.math && ca.has(A.math[n].group)) && (t = "\\dotsb"), t;
});
var la = {
	")": !0,
	"]": !0,
	"\\rbrack": !0,
	"\\}": !0,
	"\\rbrace": !0,
	"\\rangle": !0,
	"\\rceil": !0,
	"\\rfloor": !0,
	"\\rgroup": !0,
	"\\rmoustache": !0,
	"\\right": !0,
	"\\bigr": !0,
	"\\biggr": !0,
	"\\Bigr": !0,
	"\\Biggr": !0,
	$: !0,
	";": !0,
	".": !0,
	",": !0
};
$("\\dotso", function(e) {
	return e.future().text in la ? "\\ldots\\," : "\\ldots";
}), $("\\dotsc", function(e) {
	var t = e.future().text;
	return t in la && t !== "," ? "\\ldots\\," : "\\ldots";
}), $("\\cdots", function(e) {
	return e.future().text in la ? "\\@cdots\\," : "\\@cdots";
}), $("\\dotsb", "\\cdots"), $("\\dotsm", "\\cdots"), $("\\dotsi", "\\!\\cdots"), $("\\dotsx", "\\ldots\\,"), $("\\DOTSI", "\\relax"), $("\\DOTSB", "\\relax"), $("\\DOTSX", "\\relax"), $("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax"), $("\\,", "\\tmspace+{3mu}{.1667em}"), $("\\thinspace", "\\,"), $("\\>", "\\mskip{4mu}"), $("\\:", "\\tmspace+{4mu}{.2222em}"), $("\\medspace", "\\:"), $("\\;", "\\tmspace+{5mu}{.2777em}"), $("\\thickspace", "\\;"), $("\\!", "\\tmspace-{3mu}{.1667em}"), $("\\negthinspace", "\\!"), $("\\negmedspace", "\\tmspace-{4mu}{.2222em}"), $("\\negthickspace", "\\tmspace-{5mu}{.277em}"), $("\\enspace", "\\kern.5em "), $("\\enskip", "\\hskip.5em\\relax"), $("\\quad", "\\hskip1em\\relax"), $("\\qquad", "\\hskip2em\\relax"), $("\\tag", "\\@ifstar\\tag@literal\\tag@paren"), $("\\tag@paren", "\\tag@literal{({#1})}"), $("\\tag@literal", (t) => {
	if (t.macros.get("\\df@tag")) throw new e("Multiple \\tag");
	return "\\gdef\\df@tag{\\text{#1}}";
}), $("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}"), $("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)"), $("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}"), $("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1"), $("\\newline", "\\\\\\relax"), $("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var ua = k(Ue["Main-Regular"][84][1] - .7 * Ue["Main-Regular"][65][1]);
$("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + ua + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}"), $("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + ua + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}"), $("\\hspace", "\\@ifstar\\@hspacer\\@hspace"), $("\\@hspace", "\\hskip #1\\relax"), $("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax"), $("\\ordinarycolon", ":"), $("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}"), $("\\dblcolon", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char\"2237}}"), $("\\coloneqq", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char\"2254}}"), $("\\Coloneqq", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char\"2237\\char\"3d}}"), $("\\coloneq", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char\"3a\\char\"2212}}"), $("\\Coloneq", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char\"2237\\char\"2212}}"), $("\\eqqcolon", "\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char\"2255}}"), $("\\Eqqcolon", "\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char\"3d\\char\"2237}}"), $("\\eqcolon", "\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char\"2239}}"), $("\\Eqcolon", "\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char\"2212\\char\"2237}}"), $("\\colonapprox", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char\"3a\\char\"2248}}"), $("\\Colonapprox", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char\"2237\\char\"2248}}"), $("\\colonsim", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char\"3a\\char\"223c}}"), $("\\Colonsim", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char\"2237\\char\"223c}}"), $("∷", "\\dblcolon"), $("∹", "\\eqcolon"), $("≔", "\\coloneqq"), $("≕", "\\eqqcolon"), $("⩴", "\\Coloneqq"), $("\\ratio", "\\vcentcolon"), $("\\coloncolon", "\\dblcolon"), $("\\colonequals", "\\coloneqq"), $("\\coloncolonequals", "\\Coloneqq"), $("\\equalscolon", "\\eqqcolon"), $("\\equalscoloncolon", "\\Eqqcolon"), $("\\colonminus", "\\coloneq"), $("\\coloncolonminus", "\\Coloneq"), $("\\minuscolon", "\\eqcolon"), $("\\minuscoloncolon", "\\Eqcolon"), $("\\coloncolonapprox", "\\Colonapprox"), $("\\coloncolonsim", "\\Colonsim"), $("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}"), $("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}"), $("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}"), $("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}"), $("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}"), $("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}"), $("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}"), $("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}"), $("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}"), $("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}"), $("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}"), $("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}"), $("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}"), $("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}"), $("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}"), $("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}"), $("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}"), $("\\nleqq", "\\html@mathml{\\@nleqq}{≰}"), $("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}"), $("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}"), $("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}"), $("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}"), $("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}"), $("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}"), $("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}"), $("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}"), $("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}"), $("\\imath", "\\html@mathml{\\@imath}{ı}"), $("\\jmath", "\\html@mathml{\\@jmath}{ȷ}"), $("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}"), $("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}"), $("⟦", "\\llbracket"), $("⟧", "\\rrbracket"), $("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}"), $("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}"), $("⦃", "\\lBrace"), $("⦄", "\\rBrace"), $("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}"), $("⦵", "\\minuso"), $("\\darr", "\\downarrow"), $("\\dArr", "\\Downarrow"), $("\\Darr", "\\Downarrow"), $("\\lang", "\\langle"), $("\\rang", "\\rangle"), $("\\uarr", "\\uparrow"), $("\\uArr", "\\Uparrow"), $("\\Uarr", "\\Uparrow"), $("\\N", "\\mathbb{N}"), $("\\R", "\\mathbb{R}"), $("\\Z", "\\mathbb{Z}"), $("\\alef", "\\aleph"), $("\\alefsym", "\\aleph"), $("\\Alpha", "\\mathrm{A}"), $("\\Beta", "\\mathrm{B}"), $("\\bull", "\\bullet"), $("\\Chi", "\\mathrm{X}"), $("\\clubs", "\\clubsuit"), $("\\cnums", "\\mathbb{C}"), $("\\Complex", "\\mathbb{C}"), $("\\Dagger", "\\ddagger"), $("\\diamonds", "\\diamondsuit"), $("\\empty", "\\emptyset"), $("\\Epsilon", "\\mathrm{E}"), $("\\Eta", "\\mathrm{H}"), $("\\exist", "\\exists"), $("\\harr", "\\leftrightarrow"), $("\\hArr", "\\Leftrightarrow"), $("\\Harr", "\\Leftrightarrow"), $("\\hearts", "\\heartsuit"), $("\\image", "\\Im"), $("\\infin", "\\infty"), $("\\Iota", "\\mathrm{I}"), $("\\isin", "\\in"), $("\\Kappa", "\\mathrm{K}"), $("\\larr", "\\leftarrow"), $("\\lArr", "\\Leftarrow"), $("\\Larr", "\\Leftarrow"), $("\\lrarr", "\\leftrightarrow"), $("\\lrArr", "\\Leftrightarrow"), $("\\Lrarr", "\\Leftrightarrow"), $("\\Mu", "\\mathrm{M}"), $("\\natnums", "\\mathbb{N}"), $("\\Nu", "\\mathrm{N}"), $("\\Omicron", "\\mathrm{O}"), $("\\plusmn", "\\pm"), $("\\rarr", "\\rightarrow"), $("\\rArr", "\\Rightarrow"), $("\\Rarr", "\\Rightarrow"), $("\\real", "\\Re"), $("\\reals", "\\mathbb{R}"), $("\\Reals", "\\mathbb{R}"), $("\\Rho", "\\mathrm{P}"), $("\\sdot", "\\cdot"), $("\\sect", "\\S"), $("\\spades", "\\spadesuit"), $("\\sub", "\\subset"), $("\\sube", "\\subseteq"), $("\\supe", "\\supseteq"), $("\\Tau", "\\mathrm{T}"), $("\\thetasym", "\\vartheta"), $("\\weierp", "\\wp"), $("\\Zeta", "\\mathrm{Z}"), $("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}"), $("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}"), $("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits"), $("\\bra", "\\mathinner{\\langle{#1}|}"), $("\\ket", "\\mathinner{|{#1}\\rangle}"), $("\\braket", "\\mathinner{\\langle{#1}\\rangle}"), $("\\Bra", "\\left\\langle#1\\right|"), $("\\Ket", "\\left|#1\\right\\rangle");
var da = (e) => (t) => {
	var n = t.consumeArg().tokens, r = t.consumeArg().tokens, i = t.consumeArg().tokens, a = t.consumeArg().tokens, o = t.macros.get("|"), s = t.macros.get("\\|");
	t.macros.beginGroup();
	var c = (t) => (n) => {
		e && (n.macros.set("|", o), i.length && n.macros.set("\\|", s));
		var a = t;
		return !t && i.length && n.future().text === "|" && (n.popToken(), a = !0), {
			tokens: a ? i : r,
			numArgs: 0
		};
	};
	t.macros.set("|", c(!1)), i.length && t.macros.set("\\|", c(!0));
	var l = t.consumeArg().tokens, u = t.expandTokens([
		...a,
		...l,
		...n
	]);
	return t.macros.endGroup(), {
		tokens: u.reverse(),
		numArgs: 0
	};
};
$("\\bra@ket", da(!1)), $("\\bra@set", da(!0)), $("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}"), $("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}"), $("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}"), $("\\angln", "{\\angl n}"), $("\\blue", "\\textcolor{##6495ed}{#1}"), $("\\orange", "\\textcolor{##ffa500}{#1}"), $("\\pink", "\\textcolor{##ff00af}{#1}"), $("\\red", "\\textcolor{##df0030}{#1}"), $("\\green", "\\textcolor{##28ae7b}{#1}"), $("\\gray", "\\textcolor{gray}{#1}"), $("\\purple", "\\textcolor{##9d38bd}{#1}"), $("\\blueA", "\\textcolor{##ccfaff}{#1}"), $("\\blueB", "\\textcolor{##80f6ff}{#1}"), $("\\blueC", "\\textcolor{##63d9ea}{#1}"), $("\\blueD", "\\textcolor{##11accd}{#1}"), $("\\blueE", "\\textcolor{##0c7f99}{#1}"), $("\\tealA", "\\textcolor{##94fff5}{#1}"), $("\\tealB", "\\textcolor{##26edd5}{#1}"), $("\\tealC", "\\textcolor{##01d1c1}{#1}"), $("\\tealD", "\\textcolor{##01a995}{#1}"), $("\\tealE", "\\textcolor{##208170}{#1}"), $("\\greenA", "\\textcolor{##b6ffb0}{#1}"), $("\\greenB", "\\textcolor{##8af281}{#1}"), $("\\greenC", "\\textcolor{##74cf70}{#1}"), $("\\greenD", "\\textcolor{##1fab54}{#1}"), $("\\greenE", "\\textcolor{##0d923f}{#1}"), $("\\goldA", "\\textcolor{##ffd0a9}{#1}"), $("\\goldB", "\\textcolor{##ffbb71}{#1}"), $("\\goldC", "\\textcolor{##ff9c39}{#1}"), $("\\goldD", "\\textcolor{##e07d10}{#1}"), $("\\goldE", "\\textcolor{##a75a05}{#1}"), $("\\redA", "\\textcolor{##fca9a9}{#1}"), $("\\redB", "\\textcolor{##ff8482}{#1}"), $("\\redC", "\\textcolor{##f9685d}{#1}"), $("\\redD", "\\textcolor{##e84d39}{#1}"), $("\\redE", "\\textcolor{##bc2612}{#1}"), $("\\maroonA", "\\textcolor{##ffbde0}{#1}"), $("\\maroonB", "\\textcolor{##ff92c6}{#1}"), $("\\maroonC", "\\textcolor{##ed5fa6}{#1}"), $("\\maroonD", "\\textcolor{##ca337c}{#1}"), $("\\maroonE", "\\textcolor{##9e034e}{#1}"), $("\\purpleA", "\\textcolor{##ddd7ff}{#1}"), $("\\purpleB", "\\textcolor{##c6b9fc}{#1}"), $("\\purpleC", "\\textcolor{##aa87ff}{#1}"), $("\\purpleD", "\\textcolor{##7854ab}{#1}"), $("\\purpleE", "\\textcolor{##543b78}{#1}"), $("\\mintA", "\\textcolor{##f5f9e8}{#1}"), $("\\mintB", "\\textcolor{##edf2df}{#1}"), $("\\mintC", "\\textcolor{##e0e5cc}{#1}"), $("\\grayA", "\\textcolor{##f6f7f7}{#1}"), $("\\grayB", "\\textcolor{##f0f1f2}{#1}"), $("\\grayC", "\\textcolor{##e3e5e6}{#1}"), $("\\grayD", "\\textcolor{##d6d8da}{#1}"), $("\\grayE", "\\textcolor{##babec2}{#1}"), $("\\grayF", "\\textcolor{##888d93}{#1}"), $("\\grayG", "\\textcolor{##626569}{#1}"), $("\\grayH", "\\textcolor{##3b3e40}{#1}"), $("\\grayI", "\\textcolor{##21242c}{#1}"), $("\\kaBlue", "\\textcolor{##314453}{#1}"), $("\\kaGreen", "\\textcolor{##71B307}{#1}");
var fa = {
	"^": !0,
	_: !0,
	"\\limits": !0,
	"\\nolimits": !0
}, pa = class {
	constructor(e, t, n) {
		this.settings = void 0, this.expansionCount = void 0, this.lexer = void 0, this.macros = void 0, this.stack = void 0, this.mode = void 0, this.settings = t, this.expansionCount = 0, this.feed(e), this.macros = new ra(ia, t.macros), this.mode = n, this.stack = [];
	}
	feed(e) {
		this.lexer = new na(e, this.settings);
	}
	switchMode(e) {
		this.mode = e;
	}
	beginGroup() {
		this.macros.beginGroup();
	}
	endGroup() {
		this.macros.endGroup();
	}
	endGroups() {
		this.macros.endGroups();
	}
	future() {
		return this.stack.length === 0 && this.pushToken(this.lexer.lex()), this.stack[this.stack.length - 1];
	}
	popToken() {
		return this.future(), this.stack.pop();
	}
	pushToken(e) {
		this.stack.push(e);
	}
	pushTokens(e) {
		this.stack.push(...e);
	}
	scanArgument(e) {
		var t, n, r;
		if (e) {
			if (this.consumeSpaces(), this.future().text !== "[") return null;
			t = this.popToken(), {tokens: r, end: n} = this.consumeArg(["]"]);
		} else ({tokens: r, start: t, end: n} = this.consumeArg());
		return this.pushToken(new ri("EOF", n.loc)), this.pushTokens(r), new ri("", ni.range(t, n));
	}
	consumeSpaces() {
		for (; this.future().text === " ";) this.stack.pop();
	}
	consumeArg(t) {
		var n = [], r = t && t.length > 0;
		r || this.consumeSpaces();
		var i = this.future(), a, o = 0, s = 0;
		do {
			if (a = this.popToken(), n.push(a), a.text === "{") ++o;
			else if (a.text === "}") {
				if (--o, o === -1) throw new e("Extra }", a);
			} else if (a.text === "EOF") throw new e("Unexpected end of input in a macro argument, expected '" + (t && r ? t[s] : "}") + "'", a);
			if (t && r) {
				if ((o === 0 || o === 1 && t[s] === "{") && a.text === t[s]) {
					if (++s, s === t.length) {
						n.splice(-s, s);
						break;
					}
				} else s = 0;
			}
		} while (o !== 0 || r);
		return i.text === "{" && n[n.length - 1].text === "}" && (n.pop(), n.shift()), n.reverse(), {
			tokens: n,
			start: i,
			end: a
		};
	}
	consumeArgs(t, n) {
		if (n) {
			if (n.length !== t + 1) throw new e("The length of delimiters doesn't match the number of args!");
			for (var r = n[0], i = 0; i < r.length; i++) {
				var a = this.popToken();
				if (r[i] !== a.text) throw new e("Use of the macro doesn't match its definition", a);
			}
		}
		for (var o = [], s = 0; s < t; s++) o.push(this.consumeArg(n && n[s + 1]).tokens);
		return o;
	}
	countExpansion(t) {
		if (this.expansionCount += t, this.expansionCount > this.settings.maxExpand) throw new e("Too many expansions: infinite loop or need to increase maxExpand setting");
	}
	expandOnce(t) {
		var n = this.popToken(), r = n.text, i = n.noexpand ? null : this._getExpansion(r);
		if (i == null || t && i.unexpandable) {
			if (t && i == null && r[0] === "\\" && !this.isDefined(r)) throw new e("Undefined control sequence: " + r);
			return this.pushToken(n), !1;
		}
		this.countExpansion(1);
		var a = i.tokens, o = this.consumeArgs(i.numArgs, i.delimiters);
		if (i.numArgs) {
			a = a.slice();
			for (var s = a.length - 1; s >= 0; --s) {
				var c = a[s];
				if (c.text === "#") {
					if (s === 0) throw new e("Incomplete placeholder at end of macro body", c);
					if (c = a[--s], c.text === "#") a.splice(s + 1, 1);
					else if (/^[1-9]$/.test(c.text)) a.splice(s, 2, ...o[c.text - 1]);
					else throw new e("Not a valid argument number", c);
				}
			}
		}
		return this.pushTokens(a), a.length;
	}
	expandAfterFuture() {
		return this.expandOnce(), this.future();
	}
	expandNextToken() {
		for (;;) if (this.expandOnce() === !1) {
			var e = this.stack.pop();
			return e.treatAsRelax && (e.text = "\\relax"), e;
		}
	}
	expandMacro(e) {
		return this.macros.has(e) ? this.expandTokens([new ri(e)]) : void 0;
	}
	expandTokens(e) {
		var t = [], n = this.stack.length;
		for (this.pushTokens(e); this.stack.length > n;) if (this.expandOnce(!0) === !1) {
			var r = this.stack.pop();
			r.treatAsRelax &&= (r.noexpand = !1, !1), t.push(r);
		}
		return this.countExpansion(t.length), t;
	}
	expandMacroAsText(e) {
		var t = this.expandMacro(e);
		return t && t.map((e) => e.text).join("");
	}
	_getExpansion(e) {
		var t = this.macros.get(e);
		if (t == null) return t;
		if (e.length === 1) {
			var n = this.lexer.catcodes[e];
			if (n != null && n !== 13) return;
		}
		var r = typeof t == "function" ? t(this) : t;
		if (typeof r == "string") {
			var i = 0;
			if (r.includes("#")) for (var a = r.replace(/##/g, ""); a.includes("#" + (i + 1));) ++i;
			for (var o = new na(r, this.settings), s = [], c = o.lex(); c.text !== "EOF";) s.push(c), c = o.lex();
			return s.reverse(), {
				tokens: s,
				numArgs: i
			};
		}
		return r;
	}
	isDefined(e) {
		return this.macros.has(e) || qi.hasOwnProperty(e) || A.math.hasOwnProperty(e) || A.text.hasOwnProperty(e) || fa.hasOwnProperty(e);
	}
	isExpandable(e) {
		var t = this.macros.get(e);
		return t == null ? qi.hasOwnProperty(e) && !qi[e].primitive : typeof t == "string" || typeof t == "function" || !t.unexpandable;
	}
}, ma = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/, ha = Object.freeze({
	"₊": "+",
	"₋": "-",
	"₌": "=",
	"₍": "(",
	"₎": ")",
	"₀": "0",
	"₁": "1",
	"₂": "2",
	"₃": "3",
	"₄": "4",
	"₅": "5",
	"₆": "6",
	"₇": "7",
	"₈": "8",
	"₉": "9",
	ₐ: "a",
	ₑ: "e",
	ₕ: "h",
	ᵢ: "i",
	ⱼ: "j",
	ₖ: "k",
	ₗ: "l",
	ₘ: "m",
	ₙ: "n",
	ₒ: "o",
	ₚ: "p",
	ᵣ: "r",
	ₛ: "s",
	ₜ: "t",
	ᵤ: "u",
	ᵥ: "v",
	ₓ: "x",
	ᵦ: "β",
	ᵧ: "γ",
	ᵨ: "ρ",
	ᵩ: "ϕ",
	ᵪ: "χ",
	"⁺": "+",
	"⁻": "-",
	"⁼": "=",
	"⁽": "(",
	"⁾": ")",
	"⁰": "0",
	"¹": "1",
	"²": "2",
	"³": "3",
	"⁴": "4",
	"⁵": "5",
	"⁶": "6",
	"⁷": "7",
	"⁸": "8",
	"⁹": "9",
	ᴬ: "A",
	ᴮ: "B",
	ᴰ: "D",
	ᴱ: "E",
	ᴳ: "G",
	ᴴ: "H",
	ᴵ: "I",
	ᴶ: "J",
	ᴷ: "K",
	ᴸ: "L",
	ᴹ: "M",
	ᴺ: "N",
	ᴼ: "O",
	ᴾ: "P",
	ᴿ: "R",
	ᵀ: "T",
	ᵁ: "U",
	ⱽ: "V",
	ᵂ: "W",
	ᵃ: "a",
	ᵇ: "b",
	ᶜ: "c",
	ᵈ: "d",
	ᵉ: "e",
	ᶠ: "f",
	ᵍ: "g",
	ʰ: "h",
	ⁱ: "i",
	ʲ: "j",
	ᵏ: "k",
	ˡ: "l",
	ᵐ: "m",
	ⁿ: "n",
	ᵒ: "o",
	ᵖ: "p",
	ʳ: "r",
	ˢ: "s",
	ᵗ: "t",
	ᵘ: "u",
	ᵛ: "v",
	ʷ: "w",
	ˣ: "x",
	ʸ: "y",
	ᶻ: "z",
	ᵝ: "β",
	ᵞ: "γ",
	ᵟ: "δ",
	ᵠ: "ϕ",
	ᵡ: "χ",
	ᶿ: "θ"
}), ga = {
	"́": {
		text: "\\'",
		math: "\\acute"
	},
	"̀": {
		text: "\\`",
		math: "\\grave"
	},
	"̈": {
		text: "\\\"",
		math: "\\ddot"
	},
	"̃": {
		text: "\\~",
		math: "\\tilde"
	},
	"̄": {
		text: "\\=",
		math: "\\bar"
	},
	"̆": {
		text: "\\u",
		math: "\\breve"
	},
	"̌": {
		text: "\\v",
		math: "\\check"
	},
	"̂": {
		text: "\\^",
		math: "\\hat"
	},
	"̇": {
		text: "\\.",
		math: "\\dot"
	},
	"̊": {
		text: "\\r",
		math: "\\mathring"
	},
	"̋": { text: "\\H" },
	"̧": { text: "\\c" }
}, _a = {
	á: "á",
	à: "à",
	ä: "ä",
	ǟ: "ǟ",
	ã: "ã",
	ā: "ā",
	ă: "ă",
	ắ: "ắ",
	ằ: "ằ",
	ẵ: "ẵ",
	ǎ: "ǎ",
	â: "â",
	ấ: "ấ",
	ầ: "ầ",
	ẫ: "ẫ",
	ȧ: "ȧ",
	ǡ: "ǡ",
	å: "å",
	ǻ: "ǻ",
	ḃ: "ḃ",
	ć: "ć",
	ḉ: "ḉ",
	č: "č",
	ĉ: "ĉ",
	ċ: "ċ",
	ç: "ç",
	ď: "ď",
	ḋ: "ḋ",
	ḑ: "ḑ",
	é: "é",
	è: "è",
	ë: "ë",
	ẽ: "ẽ",
	ē: "ē",
	ḗ: "ḗ",
	ḕ: "ḕ",
	ĕ: "ĕ",
	ḝ: "ḝ",
	ě: "ě",
	ê: "ê",
	ế: "ế",
	ề: "ề",
	ễ: "ễ",
	ė: "ė",
	ȩ: "ȩ",
	ḟ: "ḟ",
	ǵ: "ǵ",
	ḡ: "ḡ",
	ğ: "ğ",
	ǧ: "ǧ",
	ĝ: "ĝ",
	ġ: "ġ",
	ģ: "ģ",
	ḧ: "ḧ",
	ȟ: "ȟ",
	ĥ: "ĥ",
	ḣ: "ḣ",
	ḩ: "ḩ",
	í: "í",
	ì: "ì",
	ï: "ï",
	ḯ: "ḯ",
	ĩ: "ĩ",
	ī: "ī",
	ĭ: "ĭ",
	ǐ: "ǐ",
	î: "î",
	ǰ: "ǰ",
	ĵ: "ĵ",
	ḱ: "ḱ",
	ǩ: "ǩ",
	ķ: "ķ",
	ĺ: "ĺ",
	ľ: "ľ",
	ļ: "ļ",
	ḿ: "ḿ",
	ṁ: "ṁ",
	ń: "ń",
	ǹ: "ǹ",
	ñ: "ñ",
	ň: "ň",
	ṅ: "ṅ",
	ņ: "ņ",
	ó: "ó",
	ò: "ò",
	ö: "ö",
	ȫ: "ȫ",
	õ: "õ",
	ṍ: "ṍ",
	ṏ: "ṏ",
	ȭ: "ȭ",
	ō: "ō",
	ṓ: "ṓ",
	ṑ: "ṑ",
	ŏ: "ŏ",
	ǒ: "ǒ",
	ô: "ô",
	ố: "ố",
	ồ: "ồ",
	ỗ: "ỗ",
	ȯ: "ȯ",
	ȱ: "ȱ",
	ő: "ő",
	ṕ: "ṕ",
	ṗ: "ṗ",
	ŕ: "ŕ",
	ř: "ř",
	ṙ: "ṙ",
	ŗ: "ŗ",
	ś: "ś",
	ṥ: "ṥ",
	š: "š",
	ṧ: "ṧ",
	ŝ: "ŝ",
	ṡ: "ṡ",
	ş: "ş",
	ẗ: "ẗ",
	ť: "ť",
	ṫ: "ṫ",
	ţ: "ţ",
	ú: "ú",
	ù: "ù",
	ü: "ü",
	ǘ: "ǘ",
	ǜ: "ǜ",
	ǖ: "ǖ",
	ǚ: "ǚ",
	ũ: "ũ",
	ṹ: "ṹ",
	ū: "ū",
	ṻ: "ṻ",
	ŭ: "ŭ",
	ǔ: "ǔ",
	û: "û",
	ů: "ů",
	ű: "ű",
	ṽ: "ṽ",
	ẃ: "ẃ",
	ẁ: "ẁ",
	ẅ: "ẅ",
	ŵ: "ŵ",
	ẇ: "ẇ",
	ẘ: "ẘ",
	ẍ: "ẍ",
	ẋ: "ẋ",
	ý: "ý",
	ỳ: "ỳ",
	ÿ: "ÿ",
	ỹ: "ỹ",
	ȳ: "ȳ",
	ŷ: "ŷ",
	ẏ: "ẏ",
	ẙ: "ẙ",
	ź: "ź",
	ž: "ž",
	ẑ: "ẑ",
	ż: "ż",
	Á: "Á",
	À: "À",
	Ä: "Ä",
	Ǟ: "Ǟ",
	Ã: "Ã",
	Ā: "Ā",
	Ă: "Ă",
	Ắ: "Ắ",
	Ằ: "Ằ",
	Ẵ: "Ẵ",
	Ǎ: "Ǎ",
	Â: "Â",
	Ấ: "Ấ",
	Ầ: "Ầ",
	Ẫ: "Ẫ",
	Ȧ: "Ȧ",
	Ǡ: "Ǡ",
	Å: "Å",
	Ǻ: "Ǻ",
	Ḃ: "Ḃ",
	Ć: "Ć",
	Ḉ: "Ḉ",
	Č: "Č",
	Ĉ: "Ĉ",
	Ċ: "Ċ",
	Ç: "Ç",
	Ď: "Ď",
	Ḋ: "Ḋ",
	Ḑ: "Ḑ",
	É: "É",
	È: "È",
	Ë: "Ë",
	Ẽ: "Ẽ",
	Ē: "Ē",
	Ḗ: "Ḗ",
	Ḕ: "Ḕ",
	Ĕ: "Ĕ",
	Ḝ: "Ḝ",
	Ě: "Ě",
	Ê: "Ê",
	Ế: "Ế",
	Ề: "Ề",
	Ễ: "Ễ",
	Ė: "Ė",
	Ȩ: "Ȩ",
	Ḟ: "Ḟ",
	Ǵ: "Ǵ",
	Ḡ: "Ḡ",
	Ğ: "Ğ",
	Ǧ: "Ǧ",
	Ĝ: "Ĝ",
	Ġ: "Ġ",
	Ģ: "Ģ",
	Ḧ: "Ḧ",
	Ȟ: "Ȟ",
	Ĥ: "Ĥ",
	Ḣ: "Ḣ",
	Ḩ: "Ḩ",
	Í: "Í",
	Ì: "Ì",
	Ï: "Ï",
	Ḯ: "Ḯ",
	Ĩ: "Ĩ",
	Ī: "Ī",
	Ĭ: "Ĭ",
	Ǐ: "Ǐ",
	Î: "Î",
	İ: "İ",
	Ĵ: "Ĵ",
	Ḱ: "Ḱ",
	Ǩ: "Ǩ",
	Ķ: "Ķ",
	Ĺ: "Ĺ",
	Ľ: "Ľ",
	Ļ: "Ļ",
	Ḿ: "Ḿ",
	Ṁ: "Ṁ",
	Ń: "Ń",
	Ǹ: "Ǹ",
	Ñ: "Ñ",
	Ň: "Ň",
	Ṅ: "Ṅ",
	Ņ: "Ņ",
	Ó: "Ó",
	Ò: "Ò",
	Ö: "Ö",
	Ȫ: "Ȫ",
	Õ: "Õ",
	Ṍ: "Ṍ",
	Ṏ: "Ṏ",
	Ȭ: "Ȭ",
	Ō: "Ō",
	Ṓ: "Ṓ",
	Ṑ: "Ṑ",
	Ŏ: "Ŏ",
	Ǒ: "Ǒ",
	Ô: "Ô",
	Ố: "Ố",
	Ồ: "Ồ",
	Ỗ: "Ỗ",
	Ȯ: "Ȯ",
	Ȱ: "Ȱ",
	Ő: "Ő",
	Ṕ: "Ṕ",
	Ṗ: "Ṗ",
	Ŕ: "Ŕ",
	Ř: "Ř",
	Ṙ: "Ṙ",
	Ŗ: "Ŗ",
	Ś: "Ś",
	Ṥ: "Ṥ",
	Š: "Š",
	Ṧ: "Ṧ",
	Ŝ: "Ŝ",
	Ṡ: "Ṡ",
	Ş: "Ş",
	Ť: "Ť",
	Ṫ: "Ṫ",
	Ţ: "Ţ",
	Ú: "Ú",
	Ù: "Ù",
	Ü: "Ü",
	Ǘ: "Ǘ",
	Ǜ: "Ǜ",
	Ǖ: "Ǖ",
	Ǚ: "Ǚ",
	Ũ: "Ũ",
	Ṹ: "Ṹ",
	Ū: "Ū",
	Ṻ: "Ṻ",
	Ŭ: "Ŭ",
	Ǔ: "Ǔ",
	Û: "Û",
	Ů: "Ů",
	Ű: "Ű",
	Ṽ: "Ṽ",
	Ẃ: "Ẃ",
	Ẁ: "Ẁ",
	Ẅ: "Ẅ",
	Ŵ: "Ŵ",
	Ẇ: "Ẇ",
	Ẍ: "Ẍ",
	Ẋ: "Ẋ",
	Ý: "Ý",
	Ỳ: "Ỳ",
	Ÿ: "Ÿ",
	Ỹ: "Ỹ",
	Ȳ: "Ȳ",
	Ŷ: "Ŷ",
	Ẏ: "Ẏ",
	Ź: "Ź",
	Ž: "Ž",
	Ẑ: "Ẑ",
	Ż: "Ż",
	ά: "ά",
	ὰ: "ὰ",
	ᾱ: "ᾱ",
	ᾰ: "ᾰ",
	έ: "έ",
	ὲ: "ὲ",
	ή: "ή",
	ὴ: "ὴ",
	ί: "ί",
	ὶ: "ὶ",
	ϊ: "ϊ",
	ΐ: "ΐ",
	ῒ: "ῒ",
	ῑ: "ῑ",
	ῐ: "ῐ",
	ό: "ό",
	ὸ: "ὸ",
	ύ: "ύ",
	ὺ: "ὺ",
	ϋ: "ϋ",
	ΰ: "ΰ",
	ῢ: "ῢ",
	ῡ: "ῡ",
	ῠ: "ῠ",
	ώ: "ώ",
	ὼ: "ὼ",
	Ύ: "Ύ",
	Ὺ: "Ὺ",
	Ϋ: "Ϋ",
	Ῡ: "Ῡ",
	Ῠ: "Ῠ",
	Ώ: "Ώ",
	Ὼ: "Ὼ"
}, va = class t {
	constructor(e, t) {
		this.mode = void 0, this.gullet = void 0, this.settings = void 0, this.leftrightDepth = void 0, this.nextToken = void 0, this.mode = "math", this.gullet = new pa(e, t, this.mode), this.settings = t, this.leftrightDepth = 0, this.nextToken = null;
	}
	expect(t, n) {
		if (n === void 0 && (n = !0), this.fetch().text !== t) throw new e("Expected '" + t + "', got '" + this.fetch().text + "'", this.fetch());
		n && this.consume();
	}
	consume() {
		this.nextToken = null;
	}
	fetch() {
		return this.nextToken ??= this.gullet.expandNextToken(), this.nextToken;
	}
	switchMode(e) {
		this.mode = e, this.gullet.switchMode(e);
	}
	parse() {
		this.settings.globalGroup || this.gullet.beginGroup(), this.settings.colorIsTextColor && this.gullet.macros.set("\\color", "\\textcolor");
		try {
			var e = this.parseExpression(!1);
			return this.expect("EOF"), this.settings.globalGroup || this.gullet.endGroup(), e;
		} finally {
			this.gullet.endGroups();
		}
	}
	subparse(e) {
		var t = this.nextToken;
		this.consume(), this.gullet.pushToken(new ri("}")), this.gullet.pushTokens(e);
		var n = this.parseExpression(!1);
		return this.expect("}"), this.nextToken = t, n;
	}
	parseExpression(e, n) {
		for (var r = [];;) {
			this.mode === "math" && this.consumeSpaces();
			var i = this.fetch();
			if (t.endOfExpression.has(i.text) || n && i.text === n || e && qi[i.text] && qi[i.text].infix) break;
			var a = this.parseAtom(n);
			if (a) {
				if (a.type === "internal") continue;
			} else break;
			r.push(a);
		}
		return this.mode === "text" && this.formLigatures(r), this.handleInfixNodes(r);
	}
	handleInfixNodes(t) {
		for (var n = -1, r, i = 0; i < t.length; i++) {
			var a = t[i];
			if (a.type === "infix") {
				if (n !== -1) throw new e("only one infix operator per group", a.token);
				n = i, r = a.replaceWith;
			}
		}
		if (n !== -1 && r) {
			var o, s, c = t.slice(0, n), l = t.slice(n + 1);
			o = c.length === 1 && c[0].type === "ordgroup" ? c[0] : {
				type: "ordgroup",
				mode: this.mode,
				body: c
			}, s = l.length === 1 && l[0].type === "ordgroup" ? l[0] : {
				type: "ordgroup",
				mode: this.mode,
				body: l
			};
			var u;
			return u = r === "\\\\abovefrac" ? this.callFunction(r, [
				o,
				t[n],
				s
			], []) : this.callFunction(r, [o, s], []), [u];
		}
		return t;
	}
	handleSupSubscript(t) {
		var n = this.fetch(), r = n.text;
		this.consume(), this.consumeSpaces();
		var i;
		do
			i = this.parseGroup(t);
		while (i?.type === "internal");
		if (!i) throw new e("Expected group after '" + r + "'", n);
		return i;
	}
	formatUnsupportedCmd(e) {
		for (var t = [], n = 0; n < e.length; n++) t.push({
			type: "textord",
			mode: "text",
			text: e[n]
		});
		var r = {
			type: "text",
			mode: this.mode,
			body: t
		};
		return {
			type: "color",
			mode: this.mode,
			color: this.settings.errorColor,
			body: [r]
		};
	}
	parseAtom(t) {
		var n = this.parseGroup("atom", t);
		if (n?.type === "internal" || this.mode === "text") return n;
		for (var r, i;;) {
			this.consumeSpaces();
			var a = this.fetch();
			if (a.text === "\\limits" || a.text === "\\nolimits") {
				if (n && n.type === "op") n.limits = a.text === "\\limits", n.alwaysHandleSupSub = !0;
				else if (n && n.type === "operatorname") n.alwaysHandleSupSub && (n.limits = a.text === "\\limits");
				else throw new e("Limit controls must follow a math operator", a);
				this.consume();
			} else if (a.text === "^") {
				if (r) throw new e("Double superscript", a);
				r = this.handleSupSubscript("superscript");
			} else if (a.text === "_") {
				if (i) throw new e("Double subscript", a);
				i = this.handleSupSubscript("subscript");
			} else if (a.text === "'") {
				if (r) throw new e("Double superscript", a);
				var o = {
					type: "textord",
					mode: this.mode,
					text: "\\prime"
				}, s = [o];
				for (this.consume(); this.fetch().text === "'";) s.push(o), this.consume();
				this.fetch().text === "^" && s.push(this.handleSupSubscript("superscript")), r = {
					type: "ordgroup",
					mode: this.mode,
					body: s
				};
			} else if (ha[a.text]) {
				var c = ma.test(a.text), l = [];
				for (l.push(new ri(ha[a.text])), this.consume();;) {
					var u = this.fetch().text;
					if (!ha[u] || ma.test(u) !== c) break;
					l.unshift(new ri(ha[u])), this.consume();
				}
				var d = this.subparse(l);
				c ? i = {
					type: "ordgroup",
					mode: "math",
					body: d
				} : r = {
					type: "ordgroup",
					mode: "math",
					body: d
				};
			} else break;
		}
		return r || i ? {
			type: "supsub",
			mode: this.mode,
			base: n,
			sup: r,
			sub: i
		} : n;
	}
	parseFunction(t, n) {
		var r = this.fetch(), i = r.text, a = qi[i];
		if (!a) return null;
		if (this.consume(), n && n !== "atom" && !a.allowedInArgument) throw new e("Got function '" + i + "' with no arguments" + (n ? " as " + n : ""), r);
		if (this.mode === "text" && !a.allowedInText) throw new e("Can't use function '" + i + "' in text mode", r);
		if (this.mode === "math" && a.allowedInMath === !1) throw new e("Can't use function '" + i + "' in math mode", r);
		var { args: o, optArgs: s } = this.parseArguments(i, a);
		return this.callFunction(i, o, s, r, t);
	}
	callFunction(t, n, r, i, a) {
		var o = {
			funcName: t,
			parser: this,
			token: i,
			breakOnTokenText: a
		}, s = qi[t];
		if (s && s.handler) return s.handler(o, n, r);
		throw new e("No function handler for " + t);
	}
	parseArguments(t, n) {
		var r = n.numArgs + n.numOptionalArgs;
		if (r === 0) return {
			args: [],
			optArgs: []
		};
		for (var i = [], a = [], o = 0; o < r; o++) {
			var s = n.argTypes && n.argTypes[o], c = o < n.numOptionalArgs;
			("primitive" in n && n.primitive && s == null || n.type === "sqrt" && o === 1 && a[0] == null) && (s = "primitive");
			var l = this.parseGroupOfType("argument to '" + t + "'", s, c);
			if (c) a.push(l);
			else if (l != null) i.push(l);
			else throw new e("Null argument, please report this as a bug");
		}
		return {
			args: i,
			optArgs: a
		};
	}
	parseGroupOfType(t, n, r) {
		switch (n) {
			case "color": return this.parseColorGroup(r);
			case "size": return this.parseSizeGroup(r);
			case "url": return this.parseUrlGroup(r);
			case "math":
			case "text": return this.parseArgumentGroup(r, n);
			case "hbox":
				var i = this.parseArgumentGroup(r, "text");
				return i == null ? null : {
					type: "styling",
					mode: i.mode,
					body: [i],
					style: "text",
					resetFont: !0
				};
			case "raw":
				var a = this.parseStringGroup("raw", r);
				return a == null ? null : {
					type: "raw",
					mode: "text",
					string: a.text
				};
			case "primitive":
				if (r) throw new e("A primitive argument cannot be optional");
				var o = this.parseGroup(t);
				if (o == null) throw new e("Expected group as " + t, this.fetch());
				return o;
			case "original":
			case null:
			case void 0: return this.parseArgumentGroup(r);
			default: throw new e("Unknown group type as " + t, this.fetch());
		}
	}
	consumeSpaces() {
		for (; this.fetch().text === " ";) this.consume();
	}
	parseStringGroup(e, t) {
		var n = this.gullet.scanArgument(t);
		if (n == null) return null;
		for (var r = "", i; (i = this.fetch()).text !== "EOF";) r += i.text, this.consume();
		return this.consume(), n.text = r, n;
	}
	parseRegexGroup(t, n) {
		for (var r = this.fetch(), i = r, a = "", o; (o = this.fetch()).text !== "EOF" && t.test(a + o.text);) i = o, a += i.text, this.consume();
		if (a === "") throw new e("Invalid " + n + ": '" + r.text + "'", r);
		return r.range(i, a);
	}
	parseColorGroup(t) {
		var n = this.parseStringGroup("color", t);
		if (n == null) return null;
		var r = /^(#[a-f0-9]{3,4}|#[a-f0-9]{6}|#[a-f0-9]{8}|[a-f0-9]{6}|[a-z]+)$/i.exec(n.text);
		if (!r) throw new e("Invalid color: '" + n.text + "'", n);
		var i = r[0];
		return /^[0-9a-f]{6}$/i.test(i) && (i = "#" + i), {
			type: "color-token",
			mode: this.mode,
			color: i
		};
	}
	parseSizeGroup(t) {
		var n, r = !1;
		if (this.gullet.consumeSpaces(), n = !t && this.gullet.future().text !== "{" ? this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size") : this.parseStringGroup("size", t), !n) return null;
		!t && n.text.length === 0 && (n.text = "0pt", r = !0);
		var i = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(n.text);
		if (!i) throw new e("Invalid size: '" + n.text + "'", n);
		var a = {
			number: +(i[1] + i[2]),
			unit: i[3]
		};
		if (!Te(a)) throw new e("Invalid unit: '" + a.unit + "'", n);
		return {
			type: "size",
			mode: this.mode,
			value: a,
			isBlank: r
		};
	}
	parseUrlGroup(e) {
		this.gullet.lexer.setCatcode("%", 13), this.gullet.lexer.setCatcode("~", 12);
		var t = this.parseStringGroup("url", e);
		if (this.gullet.lexer.setCatcode("%", 14), this.gullet.lexer.setCatcode("~", 13), t == null) return null;
		var n = t.text.replace(/\\([#$%&~_^{}])/g, "$1");
		return {
			type: "url",
			mode: this.mode,
			url: n
		};
	}
	parseArgumentGroup(e, t) {
		var n = this.gullet.scanArgument(e);
		if (n == null) return null;
		var r = this.mode;
		t && this.switchMode(t), this.gullet.beginGroup();
		var i = this.parseExpression(!1, "EOF");
		this.expect("EOF"), this.gullet.endGroup();
		var a = {
			type: "ordgroup",
			mode: this.mode,
			loc: n.loc,
			body: i
		};
		return t && this.switchMode(r), a;
	}
	parseGroup(t, n) {
		var r = this.fetch(), i = r.text, a;
		if (i === "{" || i === "\\begingroup") {
			this.consume();
			var o = i === "{" ? "}" : "\\endgroup";
			this.gullet.beginGroup();
			var s = this.parseExpression(!1, o), c = this.fetch();
			this.expect(o), this.gullet.endGroup(), a = {
				type: "ordgroup",
				mode: this.mode,
				loc: ni.range(r, c),
				body: s,
				semisimple: i === "\\begingroup" || void 0
			};
		} else if (a = this.parseFunction(n, t) || this.parseSymbol(), a == null && i[0] === "\\" && !fa.hasOwnProperty(i)) {
			if (this.settings.throwOnError) throw new e("Undefined control sequence: " + i, r);
			a = this.formatUnsupportedCmd(i), this.consume();
		}
		return a;
	}
	formLigatures(e) {
		for (var t = e.length - 1, n = 0; n < t; ++n) {
			var r = e[n];
			if (r.type === "textord") {
				var i = r.text, a = e[n + 1];
				if (!(!a || a.type !== "textord")) {
					if (i === "-" && a.text === "-") {
						var o = e[n + 2];
						n + 1 < t && o && o.type === "textord" && o.text === "-" ? (e.splice(n, 3, {
							type: "textord",
							mode: "text",
							loc: ni.range(r, o),
							text: "---"
						}), t -= 2) : (e.splice(n, 2, {
							type: "textord",
							mode: "text",
							loc: ni.range(r, a),
							text: "--"
						}), --t);
					}
					(i === "'" || i === "`") && a.text === i && (e.splice(n, 2, {
						type: "textord",
						mode: "text",
						loc: ni.range(r, a),
						text: i + i
					}), --t);
				}
			}
		}
	}
	parseSymbol() {
		var t = this.fetch(), n = t.text;
		if (/^\\verb[^a-zA-Z]/.test(n)) {
			this.consume();
			var r = n.slice(5), i = r.charAt(0) === "*";
			if (i && (r = r.slice(1)), r.length < 2 || r.charAt(0) !== r.slice(-1)) throw new e("\\verb assertion failed --\n                    please report what input caused this bug");
			return r = r.slice(1, -1), {
				type: "verb",
				mode: "text",
				body: r,
				star: i
			};
		}
		_a.hasOwnProperty(n[0]) && !A[this.mode][n[0]] && (this.settings.strict && this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", "Accented Unicode text character \"" + n[0] + "\" used in math mode", t), n = _a[n[0]] + n.slice(1));
		var a = ea.exec(n);
		a && (n = n.substring(0, a.index), n === "i" ? n = "ı" : n === "j" && (n = "ȷ"));
		var o;
		if (A[this.mode][n]) {
			this.settings.strict && this.mode === "math" && mt.includes(n) && this.settings.reportNonstrict("unicodeTextInMathMode", "Latin-1/Unicode text character \"" + n[0] + "\" used in math mode", t);
			var s = A[this.mode][n].group, c = ni.range(t);
			o = Jn(s) ? {
				type: "atom",
				mode: this.mode,
				family: s,
				loc: c,
				text: n
			} : {
				type: s,
				mode: this.mode,
				loc: c,
				text: n
			};
		} else if (n.charCodeAt(0) >= 128) this.settings.strict && (ce(n.charCodeAt(0)) ? this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", "Unicode text character \"" + n[0] + "\" used in math mode", t) : this.settings.reportNonstrict("unknownSymbol", "Unrecognized Unicode character \"" + n[0] + "\"" + (" (" + n.charCodeAt(0) + ")"), t)), o = {
			type: "textord",
			mode: "text",
			loc: ni.range(t),
			text: n
		};
		else return null;
		if (this.consume(), a) for (var l = 0; l < a[0].length; l++) {
			var u = a[0][l];
			if (!ga[u]) throw new e("Unknown accent ' " + u + "'", t);
			var d = ga[u][this.mode] || ga[u].text;
			if (!d) throw new e("Accent " + u + " unsupported in " + this.mode + " mode", t);
			o = {
				type: "accent",
				mode: this.mode,
				loc: ni.range(t),
				label: d,
				isStretchy: !1,
				isShifty: !0,
				base: o
			};
		}
		return o;
	}
};
va.endOfExpression = /* @__PURE__ */ new Set([
	"}",
	"\\endgroup",
	"\\end",
	"\\right",
	"&"
]);
var ya = function(t, n) {
	if (!(typeof t == "string" || t instanceof String)) throw TypeError("KaTeX can only parse string typed expression");
	var r = new va(t, n);
	delete r.gullet.macros.current["\\df@tag"];
	var i = r.parse();
	if (delete r.gullet.macros.current["\\current@color"], delete r.gullet.macros.current["\\color"], r.gullet.macros.get("\\df@tag")) {
		if (!n.displayMode) throw new e("\\tag works only in display equations");
		i = [{
			type: "tag",
			mode: "text",
			body: i,
			tag: r.subparse([new ri("\\df@tag")])
		}];
	}
	return i;
}, ba = function(e, t, n) {
	t.textContent = "";
	var r = wa(e, n).toNode();
	t.appendChild(r);
};
typeof document < "u" && document.compatMode !== "CSS1Compat" && (typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype."), ba = function() {
	throw new e("KaTeX doesn't work in quirks mode.");
});
var xa = function(e, t) {
	return wa(e, t).toMarkup();
}, Sa = function(e, t) {
	return ya(e, new m(t));
}, Ca = function(t, n, r) {
	if (r.throwOnError || !(t instanceof e)) throw t;
	var i = W(["katex-error"], [new Ie(n)]);
	return i.setAttribute("title", t.toString()), i.setAttribute("style", "color:" + r.errorColor), i;
}, wa = function(e, t) {
	var n = new m(t);
	try {
		return Rn(ya(e, n), e, n);
	} catch (t) {
		return Ca(t, e, n);
	}
}, Ta = {
	version: "0.16.47",
	render: ba,
	renderToString: xa,
	ParseError: e,
	SETTINGS_SCHEMA: u,
	__parse: Sa,
	__renderToDomTree: wa,
	__renderToHTMLTree: function(e, t) {
		var n = new m(t);
		try {
			return zn(ya(e, n), e, n);
		} catch (t) {
			return Ca(t, e, n);
		}
	},
	__setFontMetrics: Ke,
	__defineSymbol: j,
	__defineFunction: q,
	__defineMacro: $,
	__domTree: {
		Span: Me,
		Anchor: Ne,
		SymbolNode: Ie,
		SvgNode: Le,
		PathNode: Re,
		LineNode: ze
	}
};
//#endregion
export { Ta as default };

//# sourceMappingURL=katex-DoRnZ_sp-BOTuK-J8.js.map