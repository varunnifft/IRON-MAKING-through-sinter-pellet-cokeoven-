import { c as e, e as t } from "./es6-BxevHr5y-Dmh0kddl.js";
//#region ../react/build/memory-C-LDMFc2.js
var { File: n, Blob: r, DOMException: i } = e, { INVALID: a, GONE: o, MISMATCH: s, MOD_ERR: c, SYNTAX: l, SECURITY: u, DISALLOWED: d } = t, f = class {
	constructor(e, t) {
		this.fileHandle = e, this.file = t, this.size = t.size, this.position = 0;
	}
	write(e) {
		let t = this.file;
		if (typeof e == "object") {
			if (e.type === "write") {
				if (Number.isInteger(e.position) && e.position >= 0 && (this.position = e.position, this.size < e.position && (this.file = new n([this.file, new ArrayBuffer(e.position - this.size)], this.file.name, this.file))), !("data" in e)) throw new i(...l("write requires a data argument"));
				e = e.data;
			} else if (e.type === "seek") {
				if (Number.isInteger(e.position) && e.position >= 0) {
					if (this.size < e.position) throw new i(...a);
					this.position = e.position;
					return;
				}
				throw new i(...l("seek requires a position argument"));
			} else if (e.type === "truncate") {
				if (Number.isInteger(e.size) && e.size >= 0) {
					t = e.size < this.size ? new n([t.slice(0, e.size)], t.name, t) : new n([t, new Uint8Array(e.size - this.size)], t.name), this.size = t.size, this.position > t.size && (this.position = t.size), this.file = t;
					return;
				}
				throw new i(...l("truncate requires a size argument"));
			}
		}
		e = new r([e]);
		let o = this.file, s = o.slice(0, this.position), c = o.slice(this.position + e.size), u = this.position - s.size;
		u < 0 && (u = 0), o = new n([
			s,
			new Uint8Array(u),
			e,
			c
		], o.name), this.size = o.size, this.position += e.size, this.file = o;
	}
	close() {
		if (this.fileHandle._deleted) throw new i(...o);
		this.fileHandle._file = this.file, this.file = this.position = this.size = null, this.fileHandle.onclose && this.fileHandle.onclose(this.fileHandle);
	}
}, p = class {
	constructor(e = "", t = new n([], e), r = !0) {
		this._file = t, this.name = e, this.kind = "file", this._deleted = !1, this.writable = r, this.readable = !0;
	}
	async getFile() {
		if (this._deleted) throw new i(...o);
		return this._file;
	}
	async createWritable(e) {
		if (!this.writable) throw new i(...d);
		if (this._deleted) throw new i(...o);
		let t = e.keepExistingData ? await this.getFile() : new n([], this.name);
		return new f(this, t);
	}
	async isSameEntry(e) {
		return this === e;
	}
	async _destroy() {
		this._deleted = !0, this._file = null;
	}
}, m = class e {
	constructor(e, t = !0) {
		this.name = e, this.kind = "directory", this._deleted = !1, this._entries = {}, this.writable = t, this.readable = !0;
	}
	async *entries() {
		if (this._deleted) throw new i(...o);
		yield* Object.entries(this._entries);
	}
	async isSameEntry(e) {
		return this === e;
	}
	async getDirectoryHandle(t, n) {
		if (this._deleted) throw new i(...o);
		let r = this._entries[t];
		if (r) {
			if (r instanceof p) throw new i(...s);
			return r;
		}
		if (n.create) return this._entries[t] = new e(t);
		throw new i(...o);
	}
	async getFileHandle(e, t) {
		let n = this._entries[e], r = n instanceof p;
		if (n && r) return n;
		if (n && !r) throw new i(...s);
		if (!n && !t.create) throw new i(...o);
		if (!n && t.create) return this._entries[e] = new p(e);
	}
	async removeEntry(e, t) {
		let n = this._entries[e];
		if (!n) throw new i(...o);
		await n._destroy(t.recursive), delete this._entries[e];
	}
	async _destroy(e) {
		for (let t of Object.values(this._entries)) {
			if (!e) throw new i(...c);
			await t._destroy(e);
		}
		this._entries = {}, this._deleted = !0;
	}
}, h = new m(""), g = () => h;
//#endregion
export { p as FileHandle, m as FolderHandle, f as Sink, g as default };

//# sourceMappingURL=memory-C-LDMFc2-ChUTo7n_.js.map