import "./transform-B2AI7qp--hg0kwf7R.js";
import { a2 as e, a7 as t, aQ as n, al as r, am as i, aq as a, ax as o, b2 as s, b6 as c, bs as l, bw as u, c as d } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
import { t as f } from "./chunk-XXDRQBXY-DcJOot-0-BYhvkPGZ.js";
import { t as p } from "./chunk-POPQ4Y6H-DyYSXPbN-CYLHdqjk.js";
//#region ../react/build/mindmap-definition-YA3MSWOX-7vteITMf.js
var m = [];
for (let e = 0; e < 256; ++e) m.push((e + 256).toString(16).slice(1));
function h(e, t = 0) {
	return (m[e[t + 0]] + m[e[t + 1]] + m[e[t + 2]] + m[e[t + 3]] + "-" + m[e[t + 4]] + m[e[t + 5]] + "-" + m[e[t + 6]] + m[e[t + 7]] + "-" + m[e[t + 8]] + m[e[t + 9]] + "-" + m[e[t + 10]] + m[e[t + 11]] + m[e[t + 12]] + m[e[t + 13]] + m[e[t + 14]] + m[e[t + 15]]).toLowerCase();
}
var g = /* @__PURE__ */ new Uint8Array(16);
function _() {
	return crypto.getRandomValues(g);
}
function v(e, t, n) {
	return crypto.randomUUID ? crypto.randomUUID() : y(e);
}
function y(e, t, n) {
	e ||= {};
	let r = e.random ?? e.rng?.() ?? _();
	if (r.length < 16) throw Error("Random bytes length must be >= 16");
	return r[6] = r[6] & 15 | 64, r[8] = r[8] & 63 | 128, h(r);
}
var b = function() {
	var e = /* @__PURE__ */ d(function(e, t, n, r) {
		for (n ||= {}, r = e.length; r--; n[e[r]] = t);
		return n;
	}, "o"), t = [1, 4], n = [1, 13], r = [1, 12], i = [1, 15], a = [1, 16], o = [1, 20], s = [1, 19], c = [
		6,
		7,
		8
	], l = [1, 26], u = [1, 24], f = [1, 25], p = [
		6,
		7,
		11
	], m = [
		1,
		6,
		13,
		15,
		16,
		19,
		22
	], h = [1, 33], g = [1, 34], _ = [
		1,
		6,
		7,
		11,
		13,
		15,
		16,
		19,
		22
	], v = {
		trace: /* @__PURE__ */ d(function() {}, "trace"),
		yy: {},
		symbols_: {
			error: 2,
			start: 3,
			mindMap: 4,
			spaceLines: 5,
			SPACELINE: 6,
			NL: 7,
			MINDMAP: 8,
			document: 9,
			stop: 10,
			EOF: 11,
			statement: 12,
			SPACELIST: 13,
			node: 14,
			ICON: 15,
			CLASS: 16,
			nodeWithId: 17,
			nodeWithoutId: 18,
			NODE_DSTART: 19,
			NODE_DESCR: 20,
			NODE_DEND: 21,
			NODE_ID: 22,
			$accept: 0,
			$end: 1
		},
		terminals_: {
			2: "error",
			6: "SPACELINE",
			7: "NL",
			8: "MINDMAP",
			11: "EOF",
			13: "SPACELIST",
			15: "ICON",
			16: "CLASS",
			19: "NODE_DSTART",
			20: "NODE_DESCR",
			21: "NODE_DEND",
			22: "NODE_ID"
		},
		productions_: [
			0,
			[3, 1],
			[3, 2],
			[5, 1],
			[5, 2],
			[5, 2],
			[4, 2],
			[4, 3],
			[10, 1],
			[10, 1],
			[10, 1],
			[10, 2],
			[10, 2],
			[9, 3],
			[9, 2],
			[12, 2],
			[12, 2],
			[12, 2],
			[12, 1],
			[12, 1],
			[12, 1],
			[12, 1],
			[12, 1],
			[14, 1],
			[14, 1],
			[18, 3],
			[17, 1],
			[17, 4]
		],
		performAction: /* @__PURE__ */ d(function(e, t, n, r, i, a, o) {
			var s = a.length - 1;
			switch (i) {
				case 6:
				case 7: return r;
				case 8:
					r.getLogger().trace("Stop NL ");
					break;
				case 9:
					r.getLogger().trace("Stop EOF ");
					break;
				case 11:
					r.getLogger().trace("Stop NL2 ");
					break;
				case 12:
					r.getLogger().trace("Stop EOF2 ");
					break;
				case 15:
					r.getLogger().info("Node: ", a[s].id), r.addNode(a[s - 1].length, a[s].id, a[s].descr, a[s].type);
					break;
				case 16:
					r.getLogger().trace("Icon: ", a[s]), r.decorateNode({ icon: a[s] });
					break;
				case 17:
				case 21:
					r.decorateNode({ class: a[s] });
					break;
				case 18:
					r.getLogger().trace("SPACELIST");
					break;
				case 19:
					r.getLogger().trace("Node: ", a[s].id), r.addNode(0, a[s].id, a[s].descr, a[s].type);
					break;
				case 20:
					r.decorateNode({ icon: a[s] });
					break;
				case 25:
					r.getLogger().trace("node found ..", a[s - 2]), this.$ = {
						id: a[s - 1],
						descr: a[s - 1],
						type: r.getType(a[s - 2], a[s])
					};
					break;
				case 26:
					this.$ = {
						id: a[s],
						descr: a[s],
						type: r.nodeType.DEFAULT
					};
					break;
				case 27: r.getLogger().trace("node found ..", a[s - 3]), this.$ = {
					id: a[s - 3],
					descr: a[s - 1],
					type: r.getType(a[s - 2], a[s])
				};
			}
		}, "anonymous"),
		table: [
			{
				3: 1,
				4: 2,
				5: 3,
				6: [1, 5],
				8: t
			},
			{ 1: [3] },
			{ 1: [2, 1] },
			{
				4: 6,
				6: [1, 7],
				7: [1, 8],
				8: t
			},
			{
				6: n,
				7: [1, 10],
				9: 9,
				12: 11,
				13: r,
				14: 14,
				15: i,
				16: a,
				17: 17,
				18: 18,
				19: o,
				22: s
			},
			e(c, [2, 3]),
			{ 1: [2, 2] },
			e(c, [2, 4]),
			e(c, [2, 5]),
			{
				1: [2, 6],
				6: n,
				12: 21,
				13: r,
				14: 14,
				15: i,
				16: a,
				17: 17,
				18: 18,
				19: o,
				22: s
			},
			{
				6: n,
				9: 22,
				12: 11,
				13: r,
				14: 14,
				15: i,
				16: a,
				17: 17,
				18: 18,
				19: o,
				22: s
			},
			{
				6: l,
				7: u,
				10: 23,
				11: f
			},
			e(p, [2, 22], {
				17: 17,
				18: 18,
				14: 27,
				15: [1, 28],
				16: [1, 29],
				19: o,
				22: s
			}),
			e(p, [2, 18]),
			e(p, [2, 19]),
			e(p, [2, 20]),
			e(p, [2, 21]),
			e(p, [2, 23]),
			e(p, [2, 24]),
			e(p, [2, 26], { 19: [1, 30] }),
			{ 20: [1, 31] },
			{
				6: l,
				7: u,
				10: 32,
				11: f
			},
			{
				1: [2, 7],
				6: n,
				12: 21,
				13: r,
				14: 14,
				15: i,
				16: a,
				17: 17,
				18: 18,
				19: o,
				22: s
			},
			e(m, [2, 14], {
				7: h,
				11: g
			}),
			e(_, [2, 8]),
			e(_, [2, 9]),
			e(_, [2, 10]),
			e(p, [2, 15]),
			e(p, [2, 16]),
			e(p, [2, 17]),
			{ 20: [1, 35] },
			{ 21: [1, 36] },
			e(m, [2, 13], {
				7: h,
				11: g
			}),
			e(_, [2, 11]),
			e(_, [2, 12]),
			{ 21: [1, 37] },
			e(p, [2, 25]),
			e(p, [2, 27])
		],
		defaultActions: {
			2: [2, 1],
			6: [2, 2]
		},
		parseError: /* @__PURE__ */ d(function(e, t) {
			if (t.recoverable) this.trace(e);
			else {
				var n = Error(e);
				throw n.hash = t, n;
			}
		}, "parseError"),
		parse: /* @__PURE__ */ d(function(e) {
			var t = this, n = [0], r = [], i = [null], a = [], o = this.table, s = "", c = 0, l = 0, u = 2, f = 1, p = a.slice.call(arguments, 1), m = Object.create(this.lexer), h = { yy: {} };
			for (var g in this.yy) Object.prototype.hasOwnProperty.call(this.yy, g) && (h.yy[g] = this.yy[g]);
			m.setInput(e, h.yy), h.yy.lexer = m, h.yy.parser = this, typeof m.yylloc > "u" && (m.yylloc = {});
			var _ = m.yylloc;
			a.push(_);
			var v = m.options && m.options.ranges;
			this.parseError = typeof h.yy.parseError == "function" ? h.yy.parseError : Object.getPrototypeOf(this).parseError;
			function y(e) {
				n.length -= 2 * e, i.length -= e, a.length -= e;
			}
			d(y, "popStack");
			function b() {
				var e;
				return e = r.pop() || m.lex() || f, typeof e != "number" && (e instanceof Array && (r = e, e = r.pop()), e = t.symbols_[e] || e), e;
			}
			d(b, "lex");
			for (var x, S, C, w, T = {}, E, D, O, k;;) {
				if (S = n[n.length - 1], this.defaultActions[S] ? C = this.defaultActions[S] : ((x === null || typeof x > "u") && (x = b()), C = o[S] && o[S][x]), typeof C > "u" || !C.length || !C[0]) {
					var A = "";
					for (E in k = [], o[S]) this.terminals_[E] && E > u && k.push("'" + this.terminals_[E] + "'");
					A = m.showPosition ? "Parse error on line " + (c + 1) + ":\n" + m.showPosition() + "\nExpecting " + k.join(", ") + ", got '" + (this.terminals_[x] || x) + "'" : "Parse error on line " + (c + 1) + ": Unexpected " + (x == f ? "end of input" : "'" + (this.terminals_[x] || x) + "'"), this.parseError(A, {
						text: m.match,
						token: this.terminals_[x] || x,
						line: m.yylineno,
						loc: _,
						expected: k
					});
				}
				if (C[0] instanceof Array && C.length > 1) throw Error("Parse Error: multiple actions possible at state: " + S + ", token: " + x);
				switch (C[0]) {
					case 1:
						n.push(x), i.push(m.yytext), a.push(m.yylloc), n.push(C[1]), x = null, l = m.yyleng, s = m.yytext, c = m.yylineno, _ = m.yylloc;
						break;
					case 2:
						if (D = this.productions_[C[1]][1], T.$ = i[i.length - D], T._$ = {
							first_line: a[a.length - (D || 1)].first_line,
							last_line: a[a.length - 1].last_line,
							first_column: a[a.length - (D || 1)].first_column,
							last_column: a[a.length - 1].last_column
						}, v && (T._$.range = [a[a.length - (D || 1)].range[0], a[a.length - 1].range[1]]), w = this.performAction.apply(T, [
							s,
							l,
							c,
							h.yy,
							C[1],
							i,
							a
						].concat(p)), typeof w < "u") return w;
						D && (n = n.slice(0, -1 * D * 2), i = i.slice(0, -1 * D), a = a.slice(0, -1 * D)), n.push(this.productions_[C[1]][0]), i.push(T.$), a.push(T._$), O = o[n[n.length - 2]][n[n.length - 1]], n.push(O);
						break;
					case 3: return !0;
				}
			}
			return !0;
		}, "parse")
	};
	v.lexer = /* @__PURE__ */ function() {
		return {
			EOF: 1,
			parseError: /* @__PURE__ */ d(function(e, t) {
				if (this.yy.parser) this.yy.parser.parseError(e, t);
				else throw Error(e);
			}, "parseError"),
			setInput: /* @__PURE__ */ d(function(e, t) {
				return this.yy = t || this.yy || {}, this._input = e, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
					first_line: 1,
					first_column: 0,
					last_line: 1,
					last_column: 0
				}, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
			}, "setInput"),
			input: /* @__PURE__ */ d(function() {
				var e = this._input[0];
				return this.yytext += e, this.yyleng++, this.offset++, this.match += e, this.matched += e, e.match(/(?:\r\n?|\n).*/g) ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), e;
			}, "input"),
			unput: /* @__PURE__ */ d(function(e) {
				var t = e.length, n = e.split(/(?:\r\n?|\n)/g);
				this._input = e + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - t), this.offset -= t;
				var r = this.match.split(/(?:\r\n?|\n)/g);
				this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), n.length - 1 && (this.yylineno -= n.length - 1);
				var i = this.yylloc.range;
				return this.yylloc = {
					first_line: this.yylloc.first_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.first_column,
					last_column: n ? (n.length === r.length ? this.yylloc.first_column : 0) + r[r.length - n.length].length - n[0].length : this.yylloc.first_column - t
				}, this.options.ranges && (this.yylloc.range = [i[0], i[0] + this.yyleng - t]), this.yyleng = this.yytext.length, this;
			}, "unput"),
			more: /* @__PURE__ */ d(function() {
				return this._more = !0, this;
			}, "more"),
			reject: /* @__PURE__ */ d(function() {
				if (this.options.backtrack_lexer) this._backtrack = !0;
				else return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
				return this;
			}, "reject"),
			less: /* @__PURE__ */ d(function(e) {
				this.unput(this.match.slice(e));
			}, "less"),
			pastInput: /* @__PURE__ */ d(function() {
				var e = this.matched.substr(0, this.matched.length - this.match.length);
				return (e.length > 20 ? "..." : "") + e.substr(-20).replace(/\n/g, "");
			}, "pastInput"),
			upcomingInput: /* @__PURE__ */ d(function() {
				var e = this.match;
				return e.length < 20 && (e += this._input.substr(0, 20 - e.length)), (e.substr(0, 20) + (e.length > 20 ? "..." : "")).replace(/\n/g, "");
			}, "upcomingInput"),
			showPosition: /* @__PURE__ */ d(function() {
				var e = this.pastInput(), t = Array(e.length + 1).join("-");
				return e + this.upcomingInput() + "\n" + t + "^";
			}, "showPosition"),
			test_match: /* @__PURE__ */ d(function(e, t) {
				var n, r, i;
				if (this.options.backtrack_lexer && (i = {
					yylineno: this.yylineno,
					yylloc: {
						first_line: this.yylloc.first_line,
						last_line: this.last_line,
						first_column: this.yylloc.first_column,
						last_column: this.yylloc.last_column
					},
					yytext: this.yytext,
					match: this.match,
					matches: this.matches,
					matched: this.matched,
					yyleng: this.yyleng,
					offset: this.offset,
					_more: this._more,
					_input: this._input,
					yy: this.yy,
					conditionStack: this.conditionStack.slice(0),
					done: this.done
				}, this.options.ranges && (i.yylloc.range = this.yylloc.range.slice(0))), r = e[0].match(/(?:\r\n?|\n).*/g), r && (this.yylineno += r.length), this.yylloc = {
					first_line: this.yylloc.last_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.last_column,
					last_column: r ? r[r.length - 1].length - r[r.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + e[0].length
				}, this.yytext += e[0], this.match += e[0], this.matches = e, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(e[0].length), this.matched += e[0], n = this.performAction.call(this, this.yy, this, t, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), n) return n;
				if (this._backtrack) {
					for (var a in i) this[a] = i[a];
					return !1;
				}
				return !1;
			}, "test_match"),
			next: /* @__PURE__ */ d(function() {
				if (this.done) return this.EOF;
				this._input || (this.done = !0);
				var e, t, n, r;
				this._more || (this.yytext = "", this.match = "");
				for (var i = this._currentRules(), a = 0; a < i.length; a++) if (n = this._input.match(this.rules[i[a]]), n && (!t || n[0].length > t[0].length)) {
					if (t = n, r = a, this.options.backtrack_lexer) {
						if (e = this.test_match(n, i[a]), e !== !1) return e;
						if (this._backtrack) {
							t = !1;
							continue;
						}
						return !1;
					}
					if (!this.options.flex) break;
				}
				return t ? (e = this.test_match(t, i[r]), e !== !1 && e) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
			}, "next"),
			lex: /* @__PURE__ */ d(function() {
				return this.next() || this.lex();
			}, "lex"),
			begin: /* @__PURE__ */ d(function(e) {
				this.conditionStack.push(e);
			}, "begin"),
			popState: /* @__PURE__ */ d(function() {
				return this.conditionStack.length - 1 > 0 ? this.conditionStack.pop() : this.conditionStack[0];
			}, "popState"),
			_currentRules: /* @__PURE__ */ d(function() {
				return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
			}, "_currentRules"),
			topState: /* @__PURE__ */ d(function(e) {
				return e = this.conditionStack.length - 1 - Math.abs(e || 0), e >= 0 ? this.conditionStack[e] : "INITIAL";
			}, "topState"),
			pushState: /* @__PURE__ */ d(function(e) {
				this.begin(e);
			}, "pushState"),
			stateStackSize: /* @__PURE__ */ d(function() {
				return this.conditionStack.length;
			}, "stateStackSize"),
			options: { "case-insensitive": !0 },
			performAction: /* @__PURE__ */ d(function(e, t, n, r) {
				switch (n) {
					case 0: return e.getLogger().trace("Found comment", t.yytext), 6;
					case 1: return 8;
					case 2:
						this.begin("CLASS");
						break;
					case 3: return this.popState(), 16;
					case 4:
						this.popState();
						break;
					case 5:
						e.getLogger().trace("Begin icon"), this.begin("ICON");
						break;
					case 6: return e.getLogger().trace("SPACELINE"), 6;
					case 7: return 7;
					case 8: return 15;
					case 9:
						e.getLogger().trace("end icon"), this.popState();
						break;
					case 10: return e.getLogger().trace("Exploding node"), this.begin("NODE"), 19;
					case 11: return e.getLogger().trace("Cloud"), this.begin("NODE"), 19;
					case 12: return e.getLogger().trace("Explosion Bang"), this.begin("NODE"), 19;
					case 13: return e.getLogger().trace("Cloud Bang"), this.begin("NODE"), 19;
					case 14: return this.begin("NODE"), 19;
					case 15: return this.begin("NODE"), 19;
					case 16: return this.begin("NODE"), 19;
					case 17: return this.begin("NODE"), 19;
					case 18: return 13;
					case 19: return 22;
					case 20: return 11;
					case 21:
						this.begin("NSTR2");
						break;
					case 22: return "NODE_DESCR";
					case 23:
						this.popState();
						break;
					case 24:
						e.getLogger().trace("Starting NSTR"), this.begin("NSTR");
						break;
					case 25: return e.getLogger().trace("description:", t.yytext), "NODE_DESCR";
					case 26:
						this.popState();
						break;
					case 27: return this.popState(), e.getLogger().trace("node end ))"), "NODE_DEND";
					case 28: return this.popState(), e.getLogger().trace("node end )"), "NODE_DEND";
					case 29: return this.popState(), e.getLogger().trace("node end ...", t.yytext), "NODE_DEND";
					case 30: return this.popState(), e.getLogger().trace("node end (("), "NODE_DEND";
					case 31: return this.popState(), e.getLogger().trace("node end (-"), "NODE_DEND";
					case 32: return this.popState(), e.getLogger().trace("node end (-"), "NODE_DEND";
					case 33: return this.popState(), e.getLogger().trace("node end (("), "NODE_DEND";
					case 34: return this.popState(), e.getLogger().trace("node end (("), "NODE_DEND";
					case 35: return e.getLogger().trace("Long description:", t.yytext), 20;
					case 36: return e.getLogger().trace("Long description:", t.yytext), 20;
				}
			}, "anonymous"),
			rules: [
				/^(?:\s*%%.*)/i,
				/^(?:mindmap\b)/i,
				/^(?::::)/i,
				/^(?:.+)/i,
				/^(?:\n)/i,
				/^(?:::icon\()/i,
				/^(?:[\s]+[\n])/i,
				/^(?:[\n]+)/i,
				/^(?:[^\)]+)/i,
				/^(?:\))/i,
				/^(?:-\))/i,
				/^(?:\(-)/i,
				/^(?:\)\))/i,
				/^(?:\))/i,
				/^(?:\(\()/i,
				/^(?:\{\{)/i,
				/^(?:\()/i,
				/^(?:\[)/i,
				/^(?:[\s]+)/i,
				/^(?:[^\(\[\n\)\{\}]+)/i,
				/^(?:$)/i,
				/^(?:["][`])/i,
				/^(?:[^`"]+)/i,
				/^(?:[`]["])/i,
				/^(?:["])/i,
				/^(?:[^"]+)/i,
				/^(?:["])/i,
				/^(?:[\)]\))/i,
				/^(?:[\)])/i,
				/^(?:[\]])/i,
				/^(?:\}\})/i,
				/^(?:\(-)/i,
				/^(?:-\))/i,
				/^(?:\(\()/i,
				/^(?:\()/i,
				/^(?:[^\)\]\(\}]+)/i,
				/^(?:.+(?!\(\())/i
			],
			conditions: {
				CLASS: {
					rules: [3, 4],
					inclusive: !1
				},
				ICON: {
					rules: [8, 9],
					inclusive: !1
				},
				NSTR2: {
					rules: [22, 23],
					inclusive: !1
				},
				NSTR: {
					rules: [25, 26],
					inclusive: !1
				},
				NODE: {
					rules: [
						21,
						24,
						27,
						28,
						29,
						30,
						31,
						32,
						33,
						34,
						35,
						36
					],
					inclusive: !1
				},
				INITIAL: {
					rules: [
						0,
						1,
						2,
						5,
						6,
						7,
						10,
						11,
						12,
						13,
						14,
						15,
						16,
						17,
						18,
						19,
						20
					],
					inclusive: !0
				}
			}
		};
	}();
	function y() {
		this.yy = {};
	}
	return d(y, "Parser"), y.prototype = v, v.Parser = y, new y();
}();
b.parser = b;
var x = b, S = 12, C = {
	DEFAULT: 0,
	NO_BORDER: 0,
	ROUNDED_RECT: 1,
	RECT: 2,
	CIRCLE: 3,
	CLOUD: 4,
	BANG: 5,
	HEXAGON: 6
}, w, T = (w = class {
	constructor() {
		this.nodes = [], this.count = 0, this.elements = {}, this.getLogger = this.getLogger.bind(this), this.nodeType = C, this.clear(), this.getType = this.getType.bind(this), this.getElementById = this.getElementById.bind(this), this.getParent = this.getParent.bind(this), this.getMindmap = this.getMindmap.bind(this), this.addNode = this.addNode.bind(this), this.decorateNode = this.decorateNode.bind(this);
	}
	clear() {
		this.nodes = [], this.count = 0, this.elements = {}, this.baseLevel = void 0;
	}
	getParent(e) {
		for (let t = this.nodes.length - 1; t >= 0; t--) if (this.nodes[t].level < e) return this.nodes[t];
		return null;
	}
	getMindmap() {
		return this.nodes.length > 0 ? this.nodes[0] : null;
	}
	addNode(e, n, r, a) {
		c.info("addNode", e, n, r, a);
		let o = !1;
		this.nodes.length === 0 ? (this.baseLevel = e, e = 0, o = !0) : this.baseLevel !== void 0 && (e -= this.baseLevel, o = !1);
		let s = i(), l = s.mindmap?.padding ?? t.mindmap.padding;
		switch (a) {
			case this.nodeType.ROUNDED_RECT:
			case this.nodeType.RECT:
			case this.nodeType.HEXAGON: l *= 2;
		}
		let d = {
			id: this.count++,
			nodeId: u(n, s),
			level: e,
			descr: u(r, s),
			type: a,
			children: [],
			width: s.mindmap?.maxNodeWidth ?? t.mindmap.maxNodeWidth,
			padding: l,
			isRoot: o
		}, f = this.getParent(e);
		if (f) f.children.push(d), this.nodes.push(d);
		else if (o) this.nodes.push(d);
		else throw Error(`There can be only one root. No parent could be found for ("${d.descr}")`);
	}
	getType(e, t) {
		switch (c.debug("In get type", e, t), e) {
			case "[": return this.nodeType.RECT;
			case "(": return t === ")" ? this.nodeType.ROUNDED_RECT : this.nodeType.CLOUD;
			case "((": return this.nodeType.CIRCLE;
			case ")": return this.nodeType.CLOUD;
			case "))": return this.nodeType.BANG;
			case "{{": return this.nodeType.HEXAGON;
			default: return this.nodeType.DEFAULT;
		}
	}
	setElementForId(e, t) {
		this.elements[e] = t;
	}
	getElementById(e) {
		return this.elements[e];
	}
	decorateNode(e) {
		if (!e) return;
		let t = i(), n = this.nodes[this.nodes.length - 1];
		e.icon && (n.icon = u(e.icon, t)), e.class && (n.class = u(e.class, t));
	}
	type2Str(e) {
		switch (e) {
			case this.nodeType.DEFAULT: return "no-border";
			case this.nodeType.RECT: return "rect";
			case this.nodeType.ROUNDED_RECT: return "rounded-rect";
			case this.nodeType.CIRCLE: return "circle";
			case this.nodeType.CLOUD: return "cloud";
			case this.nodeType.BANG: return "bang";
			case this.nodeType.HEXAGON: return "hexgon";
			default: return "no-border";
		}
	}
	assignSections(e, t) {
		if (e.section = e.level === 0 ? void 0 : t, e.children) for (let [n, r] of e.children.entries()) {
			let i = e.level === 0 ? n % (S - 1) : t;
			this.assignSections(r, i);
		}
	}
	flattenNodes(e, t) {
		let n = i(), r = ["mindmap-node"];
		e.isRoot === !0 ? r.push("section-root", "section--1") : e.section !== void 0 && r.push(`section-${e.section}`), e.class && r.push(e.class);
		let a = r.join(" "), o = /* @__PURE__ */ d((e) => {
			let t = (n.theme?.toLowerCase() ?? "").includes("redux");
			switch (e) {
				case C.CIRCLE: return "mindmapCircle";
				case C.RECT: return "rect";
				case C.ROUNDED_RECT: return "rounded";
				case C.CLOUD: return "cloud";
				case C.BANG: return "bang";
				case C.HEXAGON: return "hexagon";
				case C.DEFAULT: return t ? "rounded" : "defaultMindmapNode";
				case C.NO_BORDER:
				default: return "rect";
			}
		}, "getShapeFromType"), s = {
			id: e.id.toString(),
			domId: "node_" + e.id.toString(),
			label: e.descr,
			labelType: "markdown",
			isGroup: !1,
			shape: o(e.type),
			width: e.width,
			height: e.height ?? 0,
			padding: e.padding,
			cssClasses: a,
			cssStyles: [],
			look: n.look,
			icon: e.icon,
			x: e.x,
			y: e.y,
			level: e.level,
			nodeId: e.nodeId,
			type: e.type,
			section: e.section
		};
		if (t.push(s), e.children) for (let n of e.children) this.flattenNodes(n, t);
	}
	generateEdges(e, t) {
		if (!e.children) return;
		let n = i();
		for (let r of e.children) {
			let i = "edge";
			r.section !== void 0 && (i += ` section-edge-${r.section}`);
			let a = e.level + 1;
			i += ` edge-depth-${a}`;
			let o = {
				id: `edge_${e.id}_${r.id}`,
				start: e.id.toString(),
				end: r.id.toString(),
				type: "normal",
				curve: "basis",
				thickness: "normal",
				look: n.look,
				classes: i,
				depth: e.level,
				section: r.section
			};
			t.push(o), this.generateEdges(r, t);
		}
	}
	getData() {
		let e = this.getMindmap(), t = i(), n = o().layout !== void 0, r = t;
		if (n || (r.layout = "cose-bilkent"), !e) return {
			nodes: [],
			edges: [],
			config: r
		};
		c.debug("getData: mindmapRoot", e, t), this.assignSections(e);
		let a = [], s = [];
		this.flattenNodes(e, a), this.generateEdges(e, s), c.debug(`getData: processed ${a.length} nodes and ${s.length} edges`);
		let l = /* @__PURE__ */ new Map();
		for (let e of a) l.set(e.id, {
			shape: e.shape,
			width: e.width,
			height: e.height,
			padding: e.padding
		});
		return {
			nodes: a,
			edges: s,
			config: r,
			rootNode: e,
			markers: ["point"],
			direction: "TB",
			nodeSpacing: 50,
			rankSpacing: 50,
			shapes: Object.fromEntries(l),
			type: "mindmap",
			diagramId: "mindmap-" + v()
		};
	}
	getLogger() {
		return c;
	}
}, d(w, "MindmapDB"), w), E = { draw: /* @__PURE__ */ d(async (e, n, i, o) => {
	c.debug("Rendering mindmap diagram\n" + e);
	let s = o.db, u = s.getData(), d = f(n, u.config.securityLevel);
	if (u.type = o.type, u.layoutAlgorithm = a(u.config.layout, { fallback: "cose-bilkent" }), u.diagramId = n, !s.getMindmap()) return;
	u.nodes.forEach((e) => {
		e.shape === "rounded" ? (e.radius = 15, e.taper = 15, e.stroke = "none", e.width = 0, e.padding = 15) : e.shape === "circle" ? e.padding = 10 : e.shape === "rect" ? (e.width = 0, e.padding = 10) : e.shape === "hexagon" && (e.width = 0, e.height = 0);
	}), await l(u, d);
	let { themeVariables: m } = r(), { useGradient: h, gradientStart: g, gradientStop: _ } = m;
	if (h && g && _) {
		let e = d.attr("id"), t = d.append("defs").append("linearGradient").attr("id", `${e}-gradient`).attr("gradientUnits", "objectBoundingBox").attr("x1", "0%").attr("y1", "0%").attr("x2", "100%").attr("y2", "0%");
		t.append("stop").attr("offset", "0%").attr("stop-color", g).attr("stop-opacity", 1), t.append("stop").attr("offset", "100%").attr("stop-color", _).attr("stop-opacity", 1);
	}
	p(d, u.config.mindmap?.padding ?? t.mindmap.padding, "mindmapDiagram", u.config.mindmap?.useMaxWidth ?? t.mindmap.useMaxWidth);
}, "draw") }, D = /* @__PURE__ */ d((t) => {
	let { theme: r, look: i } = t, a = "";
	for (let r = 0; r < t.THEME_COLOR_LIMIT; r++) t["lineColor" + r] = t["lineColor" + r] || t["cScaleInv" + r], n(t["lineColor" + r]) ? t["lineColor" + r] = s(t["lineColor" + r], 20) : t["lineColor" + r] = e(t["lineColor" + r], 20);
	for (let e = 0; e < t.THEME_COLOR_LIMIT; e++) {
		let n = "" + (i === "neo" ? Math.max(10 - (e - 1) * 2, 2) : 17 - 3 * e);
		a += `
    .section-${e - 1} rect, .section-${e - 1} path, .section-${e - 1} circle, .section-${e - 1} polygon, .section-${e - 1} path  {
      fill: ${t["cScale" + e]};
    }
    .section-${e - 1} text {
     fill: ${t["cScaleLabel" + e]};
    }
     .section-${e - 1} span {
     color: ${t["cScaleLabel" + e]};
    }
    .node-icon-${e - 1} {
      font-size: 40px;
      color: ${t["cScaleLabel" + e]};
    }
    .section-edge-${e - 1}{
      stroke: ${t["cScale" + e]};
    }
    .edge-depth-${e - 1}{
      stroke-width: ${n};
    }
    .section-${e - 1} line {
      stroke: ${t["cScaleInv" + e]} ;
      stroke-width: 3;
    }

    .disabled, .disabled circle, .disabled text {
      fill: lightgray;
    }
    .disabled text {
      fill: #efefef;
    }
    [data-look="neo"].mindmap-node.section-${e - 1} rect, [data-look="neo"].mindmap-node.section-${e - 1} path, [data-look="neo"].mindmap-node.section-${e - 1} circle, [data-look="neo"].mindmap-node.section-${e - 1} polygon {
      fill: ${r === "redux" || r === "redux-dark" || r === "neutral" ? t.mainBkg : t["cScale" + e]};
      stroke: ${r === "redux" || r === "redux-dark" ? t.nodeBorder : t["cScale" + e]};
      stroke-width: ${t.strokeWidth ?? 2}px;
    }
    [data-look="neo"].section-edge-${e - 1}{
      stroke: ${r?.includes("redux") || r === "neo-dark" ? t.nodeBorder : t["cScale" + e]};
    }
    [data-look="neo"].mindmap-node.section-${e - 1} text {
     fill: ${r === "redux" || r === "redux-dark" ? t.nodeBorder : t["cScaleLabel" + (r === "neutral" ? 1 : e)]};
    }
    `;
	}
	return a;
}, "genSections"), O = /* @__PURE__ */ d((e, t, n) => {
	let r = "";
	for (let i = 0; i < e; i++) r += `
    [data-look="neo"].mindmap-node.section-${i - 1} rect, [data-look="neo"].mindmap-node.section-${i - 1} path, [data-look="neo"].mindmap-node.section-${i - 1} circle, [data-look="neo"].mindmap-node.section-${i - 1} polygon {
      stroke: url(${t}-gradient);
      fill: ${n};
    }
    .section-${i - 1} line {
      stroke-width: 0;
    }`;
	return r;
}, "genGradient"), k = {
	get db() {
		return new T();
	},
	renderer: E,
	parser: x,
	styles: /* @__PURE__ */ d((e) => {
		let { theme: t } = e, n = e.svgId, r = e.dropShadow ? e.dropShadow.replace("url(#drop-shadow)", `url(${n}-drop-shadow)`) : "none";
		return `
  .edge {
    stroke-width: 3;
  }
  ${D(e)}
  .section-root rect, .section-root path, .section-root circle, .section-root polygon  {
    fill: ${e.git0};
  }
  .section-root text {
    fill: ${e.gitBranchLabel0};
  }
  .section-root span {
    color: ${t?.includes("redux") ? e.nodeBorder : e.gitBranchLabel0};
  }
  .icon-container {
    height:100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .edge {
    fill: none;
  }
  .mindmap-node-label {
    dy: 1em;
    alignment-baseline: middle;
    text-anchor: middle;
    dominant-baseline: middle;
    text-align: center;
  }
  [data-look="neo"].mindmap-node  {
    filter: ${r};
  }
  [data-look="neo"].mindmap-node.section-root rect, [data-look="neo"].mindmap-node.section-root path, [data-look="neo"].mindmap-node.section-root circle, [data-look="neo"].mindmap-node.section-root polygon  {
    fill: ${t?.includes("redux") ? e.mainBkg : e.git0};
  }
  [data-look="neo"].mindmap-node.section-root .text-inner-tspan {
    fill:  ${t?.includes("redux") ? e.nodeBorder : e["cScaleLabel" + +(t === "neutral")]};
  }
  ${e.useGradient && n && e.mainBkg ? O(e.THEME_COLOR_LIMIT, n, e.mainBkg) : ""}
`;
	}, "getStyles")
};
//#endregion
export { k as diagram };

//# sourceMappingURL=mindmap-definition-YA3MSWOX-7vteITMf-z0_eDwia.js.map