import { ds as e, ms as t } from "./index-B1FrxEMd-BsPMjC5n.js";
import { s as n } from "./DataFrame-DRF8lFxD-CzB3xmp7.js";
//#region ../react/build/number-overlay-editor-C2wAcnJq.js
var r = /* @__PURE__ */ t(e(), 1), i = /* @__PURE__ */ n("div")({
	name: "NumberOverlayEditorStyle",
	class: "gdg-n15fjm3e",
	propsAsIs: !1
});
function a(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
var o;
(function(e) {
	e.event = "event", e.props = "prop";
})(o ||= {});
function s() {}
function c(e) {
	var t, n = void 0;
	return function() {
		for (var r = [], i = arguments.length; i--;) r[i] = arguments[i];
		return t && r.length === t.length && r.every(function(e, n) {
			return e === t[n];
		}) || (t = r, n = e.apply(void 0, r)), n;
	};
}
function l(e) {
	return !!(e || "").match(/\d/);
}
function u(e) {
	return e == null;
}
function d(e) {
	return typeof e == "number" && isNaN(e);
}
function f(e) {
	return u(e) || d(e) || typeof e == "number" && !isFinite(e);
}
function p(e) {
	return e.replace(/[-[\]/{}()*+?.\\^$|]/g, "\\$&");
}
function m(e) {
	switch (e) {
		case "lakh": return /(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/g;
		case "wan": return /(\d)(?=(\d{4})+(?!\d))/g;
		default: return /(\d)(?=(\d{3})+(?!\d))/g;
	}
}
function h(e, t, n) {
	var r = m(n), i = e.search(/[1-9]/);
	return i = i === -1 ? e.length : i, e.substring(0, i) + e.substring(i, e.length).replace(r, "$1" + t);
}
function g(e) {
	var t = (0, r.useRef)(e);
	return t.current = e, (0, r.useRef)(function() {
		for (var e = [], n = arguments.length; n--;) e[n] = arguments[n];
		return t.current.apply(t, e);
	}).current;
}
function _(e, t) {
	t === void 0 && (t = !0);
	var n = e[0] === "-", r = n && t;
	e = e.replace("-", "");
	var i = e.split(".");
	return {
		beforeDecimal: i[0],
		afterDecimal: i[1] || "",
		hasNegation: n,
		addNegation: r
	};
}
function v(e) {
	if (!e) return e;
	var t = e[0] === "-";
	t && (e = e.substring(1, e.length));
	var n = e.split("."), r = n[0].replace(/^0+/, "") || "0", i = n[1] || "";
	return (t ? "-" : "") + r + (i ? "." + i : "");
}
function y(e, t, n) {
	for (var r = "", i = n ? "0" : "", a = 0; a <= t - 1; a++) r += e[a] || i;
	return r;
}
function b(e, t) {
	return Array(t + 1).join(e);
}
function x(e) {
	var t = e + "", n = t[0] === "-" ? "-" : "";
	n && (t = t.substring(1));
	var r = t.split(/[eE]/g), i = r[0], a = r[1];
	if (a = Number(a), !a) return n + i;
	i = i.replace(".", "");
	var o = 1 + a, s = i.length;
	return o < 0 ? i = "0." + b("0", Math.abs(o)) + i : o >= s ? i += b("0", o - s) : i = (i.substring(0, o) || "0") + "." + i.substring(o), n + i;
}
function S(e, t, n) {
	if (["", "-"].indexOf(e) !== -1) return e;
	var r = (e.indexOf(".") !== -1 || n) && t, i = _(e), a = i.beforeDecimal, o = i.afterDecimal, s = i.hasNegation, c = parseFloat("0." + (o || "0")), l = (o.length <= t ? "0." + o : c.toFixed(t)).split("."), u = a;
	a && Number(l[0]) && (u = a.split("").reverse().reduce(function(e, t, n) {
		return e.length > n ? (Number(e[0]) + Number(t)).toString() + e.substring(1, e.length) : t + e;
	}, l[0]));
	var d = y(l[1] || "", t, n), f = s ? "-" : "", p = r ? "." : "";
	return "" + f + u + p + d;
}
function C(e, t) {
	if (e.value = e.value, e !== null) {
		if (e.createTextRange) {
			var n = e.createTextRange();
			return n.move("character", t), n.select(), !0;
		}
		return e.selectionStart || e.selectionStart === 0 ? (e.focus(), e.setSelectionRange(t, t), !0) : (e.focus(), !1);
	}
}
var w = c(function(e, t) {
	for (var n = 0, r = 0, i = e.length, a = t.length; e[n] === t[n] && n < i;) n++;
	for (; e[i - 1 - r] === t[a - 1 - r] && a - r > n && i - r > n;) r++;
	return {
		from: {
			start: n,
			end: i - r
		},
		to: {
			start: n,
			end: a - r
		}
	};
}), T = function(e, t) {
	var n = Math.min(e.selectionStart, t);
	return {
		from: {
			start: n,
			end: e.selectionEnd
		},
		to: {
			start: n,
			end: t
		}
	};
};
function E(e, t, n) {
	return Math.min(Math.max(e, t), n);
}
function D(e) {
	return Math.max(e.selectionStart, e.selectionEnd);
}
function O() {
	return typeof navigator < "u" && !(navigator.platform && /iPhone|iPod/.test(navigator.platform));
}
function k(e) {
	return {
		from: {
			start: 0,
			end: 0
		},
		to: {
			start: 0,
			end: e.length
		},
		lastValue: ""
	};
}
function A(e) {
	var t = e.currentValue, n = e.formattedValue, r = e.currentValueIndex, i = e.formattedValueIndex;
	return t[r] === n[i];
}
function j(e, t, n, r, i, a, o) {
	o === void 0 && (o = A);
	var s = i.findIndex(function(e) {
		return e;
	}), c = e.slice(0, s);
	!t && !n.startsWith(c) && (t = c, n = c + n, r += c.length);
	for (var l = n.length, u = e.length, d = {}, f = Array(l), p = 0; p < l; p++) {
		f[p] = -1;
		for (var m = 0, h = u; m < h; m++) if (o({
			currentValue: n,
			lastValue: t,
			formattedValue: e,
			currentValueIndex: p,
			formattedValueIndex: m
		}) && d[m] !== !0) {
			f[p] = m, d[m] = !0;
			break;
		}
	}
	for (var g = r; g < l && (f[g] === -1 || !a(n[g]));) g++;
	var _ = g === l || f[g] === -1 ? u : f[g];
	for (g = r - 1; g > 0 && f[g] === -1;) g--;
	var v = g === -1 || f[g] === -1 ? 0 : f[g] + 1;
	return v > _ ? _ : r - v < _ - r ? v : _;
}
function M(e, t, n, r) {
	var i = e.length;
	if (t = E(t, 0, i), r === "left") {
		for (; t >= 0 && !n[t];) t--;
		t === -1 && (t = n.indexOf(!0));
	} else {
		for (; t <= i && !n[t];) t++;
		t > i && (t = n.lastIndexOf(!0));
	}
	return t === -1 && (t = i), t;
}
function N(e) {
	for (var t = Array.from({ length: e.length + 1 }).map(function() {
		return !0;
	}), n = 0, r = t.length; n < r; n++) t[n] = !!(l(e[n]) || l(e[n - 1]));
	return t;
}
function P(e, t, n, i, a, o) {
	o === void 0 && (o = s);
	var c = g(function(e, t) {
		var n, r;
		return f(e) ? (r = "", n = "") : typeof e == "number" || t ? (r = typeof e == "number" ? x(e) : e, n = i(r)) : (r = a(e, void 0), n = i(r)), {
			formattedValue: n,
			numAsString: r
		};
	}), l = (0, r.useState)(function() {
		return c(u(e) ? t : e, n);
	}), d = l[0], p = l[1], m = function(e, t) {
		e.formattedValue !== d.formattedValue && p({
			formattedValue: e.formattedValue,
			numAsString: e.value
		}), o(e, t);
	}, h = e, _ = n;
	u(e) && (h = d.numAsString, _ = !0);
	var v = c(h, _);
	return (0, r.useMemo)(function() {
		p(v);
	}, [v.formattedValue]), [d, m];
}
function F(e) {
	return e.replace(/[^0-9]/g, "");
}
function I(e) {
	return e;
}
function L(e) {
	var t = e.type;
	t === void 0 && (t = "text");
	var n = e.displayType;
	n === void 0 && (n = "input");
	var i = e.customInput, c = e.renderText, u = e.getInputRef, d = e.format;
	d === void 0 && (d = I);
	var f = e.removeFormatting;
	f === void 0 && (f = F);
	var p = e.defaultValue, m = e.valueIsNumericString, h = e.onValueChange, g = e.isAllowed, _ = e.onChange;
	_ === void 0 && (_ = s);
	var v = e.onKeyDown;
	v === void 0 && (v = s);
	var y = e.onMouseUp;
	y === void 0 && (y = s);
	var b = e.onFocus;
	b === void 0 && (b = s);
	var x = e.onBlur;
	x === void 0 && (x = s);
	var S = e.value, E = e.getCaretBoundary;
	E === void 0 && (E = N);
	var k = e.isValidInputCharacter;
	k === void 0 && (k = l);
	var A = e.isCharacterSame, L = a(e, [
		"type",
		"displayType",
		"customInput",
		"renderText",
		"getInputRef",
		"format",
		"removeFormatting",
		"defaultValue",
		"valueIsNumericString",
		"onValueChange",
		"isAllowed",
		"onChange",
		"onKeyDown",
		"onMouseUp",
		"onFocus",
		"onBlur",
		"value",
		"getCaretBoundary",
		"isValidInputCharacter",
		"isCharacterSame"
	]), R = P(S, p, !!m, d, f, h), z = R[0], B = z.formattedValue, V = z.numAsString, ee = R[1], H = (0, r.useRef)(), U = (0, r.useRef)({
		formattedValue: B,
		numAsString: V
	}), W = function(e, t) {
		U.current = {
			formattedValue: e.formattedValue,
			numAsString: e.value
		}, ee(e, t);
	}, G = (0, r.useState)(!1), te = G[0], K = G[1], q = (0, r.useRef)(null), J = (0, r.useRef)({
		setCaretTimeout: null,
		focusTimeout: null
	});
	(0, r.useEffect)(function() {
		return K(!0), function() {
			clearTimeout(J.current.setCaretTimeout), clearTimeout(J.current.focusTimeout);
		};
	}, []);
	var ne = d, Y = function(e, t) {
		var n = parseFloat(t);
		return {
			formattedValue: e,
			value: t,
			floatValue: isNaN(n) ? void 0 : n
		};
	}, X = function(e, t, n) {
		e.selectionStart === 0 && e.selectionEnd === e.value.length || (C(e, t), J.current.setCaretTimeout = setTimeout(function() {
			e.value === n && e.selectionStart !== t && C(e, t);
		}, 0));
	}, Z = function(e, t, n) {
		return M(e, t, E(e), n);
	}, Q = function(e, t, n) {
		var r = E(t), i = j(t, B, e, n, r, k, A);
		return i = M(t, i, r), i;
	}, re = function(e) {
		var t = e.formattedValue;
		t === void 0 && (t = "");
		var n = e.input, r = e.source, i = e.event, a = e.numAsString, o;
		if (n) {
			var s = e.inputValue || n.value, c = D(n);
			n.value = t, o = Q(s, t, c), o !== void 0 && X(n, o, t);
		}
		t !== B && W(Y(t, a), {
			event: i,
			source: r
		});
	};
	(0, r.useEffect)(function() {
		var e = U.current, t = e.formattedValue, n = e.numAsString;
		(B !== t || V !== n) && W(Y(B, V), {
			event: void 0,
			source: o.props
		});
	}, [B, V]);
	var ie = q.current ? D(q.current) : void 0;
	(typeof window < "u" ? r.useLayoutEffect : r.useEffect)(function() {
		var e = q.current;
		if (B !== U.current.formattedValue && e) {
			var t = Q(U.current.formattedValue, B, ie);
			e.value = B, X(e, t, B);
		}
	}, [B]);
	var ae = function(e, t, n) {
		var r = t.target, i = H.current ? T(H.current, r.selectionEnd) : w(B, e), a = Object.assign(Object.assign({}, i), { lastValue: B }), o = f(e, a), s = ne(o);
		if (o = f(s, void 0), g && !g(Y(s, o))) {
			var c = t.target, l = Q(e, B, D(c));
			return c.value = B, X(c, l, B), !1;
		}
		return re({
			formattedValue: s,
			numAsString: o,
			inputValue: e,
			event: t,
			source: n,
			input: t.target
		}), !0;
	}, $ = function(e, t) {
		t === void 0 && (t = 0), H.current = {
			selectionStart: e.selectionStart,
			selectionEnd: e.selectionEnd + t
		};
	}, oe = function(e) {
		var t = e.target.value;
		ae(t, e, o.event) && _(e), H.current = void 0;
	}, se = function(e) {
		var t = e.target, n = e.key, r = t.selectionStart, i = t.selectionEnd, a = t.value;
		a === void 0 && (a = "");
		var o;
		n === "ArrowLeft" || n === "Backspace" ? o = Math.max(r - 1, 0) : n === "ArrowRight" ? o = Math.min(r + 1, a.length) : n === "Delete" && (o = r);
		var s = 0;
		n === "Delete" && r === i && (s = 1);
		var c = n === "ArrowLeft" || n === "ArrowRight";
		if (o === void 0 || r !== i && !c) {
			v(e), $(t, s);
			return;
		}
		var l = o;
		c ? (l = Z(a, o, n === "ArrowLeft" ? "left" : "right"), l !== o && e.preventDefault()) : n === "Delete" && !k(a[o]) ? l = Z(a, o, "right") : n === "Backspace" && !k(a[o]) && (l = Z(a, o, "left")), l !== o && X(t, l, a), v(e), $(t, s);
	}, ce = function(e) {
		var t = e.target, n = function() {
			var e = t.selectionStart, n = t.selectionEnd, r = t.value;
			if (r === void 0 && (r = ""), e === n) {
				var i = Z(r, e);
				i !== e && X(t, i, r);
			}
		};
		n(), requestAnimationFrame(function() {
			n();
		}), y(e), $(t);
	}, le = function(e) {
		e.persist && e.persist();
		var t = e.target, n = e.currentTarget;
		q.current = t, J.current.focusTimeout = setTimeout(function() {
			var r = t.selectionStart, i = t.selectionEnd, a = t.value;
			a === void 0 && (a = "");
			var o = Z(a, r);
			o !== r && (r !== 0 || i !== a.length) && X(t, o, a), b(Object.assign(Object.assign({}, e), { currentTarget: n }));
		}, 0);
	}, ue = function(e) {
		q.current = null, clearTimeout(J.current.focusTimeout), clearTimeout(J.current.setCaretTimeout), x(e);
	}, de = te && O() ? "numeric" : void 0, fe = Object.assign({ inputMode: de }, L, {
		type: t,
		value: B,
		onChange: oe,
		onKeyDown: se,
		onMouseUp: ce,
		onFocus: le,
		onBlur: ue
	});
	if (n === "text") return c ? r.createElement(r.Fragment, null, c(B, L) || null) : r.createElement("span", Object.assign({}, L, { ref: u }), B);
	if (i) {
		var pe = i;
		return r.createElement(pe, Object.assign({}, fe, { ref: u }));
	}
	return r.createElement("input", Object.assign({}, fe, { ref: u }));
}
function R(e, t) {
	var n = t.decimalScale, r = t.fixedDecimalScale, i = t.prefix;
	i === void 0 && (i = "");
	var a = t.suffix;
	a === void 0 && (a = "");
	var o = t.allowNegative, s = t.thousandsGroupStyle;
	if (s === void 0 && (s = "thousand"), e === "" || e === "-") return e;
	var c = z(t), l = c.thousandSeparator, u = c.decimalSeparator, d = n !== 0 && e.indexOf(".") !== -1 || n && r, f = _(e, o), p = f.beforeDecimal, m = f.afterDecimal, g = f.addNegation;
	return n !== void 0 && (m = y(m, n, !!r)), l && (p = h(p, l, s)), i && (p = i + p), a && (m += a), g && (p = "-" + p), e = p + (d && u || "") + m, e;
}
function z(e) {
	var t = e.decimalSeparator;
	t === void 0 && (t = ".");
	var n = e.thousandSeparator, r = e.allowedDecimalSeparators;
	return n === !0 && (n = ","), r ||= [t, "."], {
		decimalSeparator: t,
		thousandSeparator: n,
		allowedDecimalSeparators: r
	};
}
function B(e, t) {
	e === void 0 && (e = "");
	var n = /* @__PURE__ */ RegExp("(-)"), r = /* @__PURE__ */ RegExp("(-)(.)*(-)"), i = n.test(e), a = r.test(e);
	return e = e.replace(/-/g, ""), i && !a && t && (e = "-" + e), e;
}
function V(e, t) {
	return RegExp("(^-)|[0-9]|" + p(e), "g");
}
function ee(e, t, n) {
	return e === "" || !t?.match(/\d/) && !n?.match(/\d/) && typeof e == "string" && !isNaN(Number(e));
}
function H(e, t, n) {
	var r;
	t === void 0 && (t = k(e));
	var i = n.allowNegative, a = n.prefix;
	a === void 0 && (a = "");
	var o = n.suffix;
	o === void 0 && (o = "");
	var s = n.decimalScale, c = t.from, u = t.to, d = u.start, f = u.end, m = z(n), h = m.allowedDecimalSeparators, g = m.decimalSeparator, v = e[f] === g;
	if (l(e) && (e === a || e === o) && t.lastValue === "") return e;
	if (f - d === 1 && h.indexOf(e[d]) !== -1) {
		var y = s === 0 ? "" : g;
		e = e.substring(0, d) + y + e.substring(d + 1, e.length);
	}
	var b = function(e, t, n) {
		var r = !1, i = !1;
		a.startsWith("-") ? r = !1 : e.startsWith("--") ? (r = !1, i = !0) : o.startsWith("-") && e.length === o.length ? r = !1 : e[0] === "-" && (r = !0);
		var s = +!!r;
		return i && (s = 2), s && (e = e.substring(s), t -= s, n -= s), {
			value: e,
			start: t,
			end: n,
			hasNegation: r
		};
	}, x = b(e, d, f), S = x.hasNegation;
	r = x, e = r.value, d = r.start, f = r.end;
	var C = b(t.lastValue, c.start, c.end), w = C.start, T = C.end, E = C.value, D = e.substring(d, f);
	e.length && E.length && (w > E.length - o.length || T < a.length) && !(D && o.startsWith(D)) && (e = E);
	var O = 0;
	e.startsWith(a) ? O += a.length : d < a.length && (O = d), e = e.substring(O), f -= O;
	var A = e.length, j = e.length - o.length;
	e.endsWith(o) ? A = j : (f > j || f > e.length - o.length) && (A = f), e = e.substring(0, A), e = B(S ? "-" + e : e, i), e = (e.match(V(g)) || []).join("");
	var M = e.indexOf(g);
	e = e.replace(new RegExp(p(g), "g"), function(e, t) {
		return t === M ? "." : "";
	});
	var N = _(e, i), P = N.beforeDecimal, F = N.afterDecimal, I = N.addNegation;
	return u.end - u.start < c.end - c.start && P === "" && v && !parseFloat(F) && (e = I ? "-" : ""), e;
}
function U(e, t) {
	var n = t.prefix;
	n === void 0 && (n = "");
	var r = t.suffix;
	r === void 0 && (r = "");
	var i = Array.from({ length: e.length + 1 }).map(function() {
		return !0;
	}), a = e[0] === "-";
	i.fill(!1, 0, n.length + +!!a);
	var o = e.length;
	return i.fill(!1, o - r.length + 1, o + 1), i;
}
function W(e) {
	var t = z(e), n = t.thousandSeparator, r = t.decimalSeparator, i = e.prefix;
	i === void 0 && (i = "");
	var a = e.allowNegative;
	if (a === void 0 && (a = !0), n === r) throw Error("\n        Decimal separator can't be same as thousand separator.\n        thousandSeparator: " + n + " (thousandSeparator = {true} is same as thousandSeparator = \",\")\n        decimalSeparator: " + r + " (default value for decimalSeparator is .)\n     ");
	return i.startsWith("-") && a && (console.error("\n      Prefix can't start with '-' when allowNegative is true.\n      prefix: " + i + "\n      allowNegative: " + a + "\n    "), a = !1), Object.assign(Object.assign({}, e), { allowNegative: a });
}
function G(e) {
	e = W(e), e.decimalSeparator, e.allowedDecimalSeparators, e.thousandsGroupStyle;
	var t = e.suffix, n = e.allowNegative, r = e.allowLeadingZeros, i = e.onKeyDown;
	i === void 0 && (i = s);
	var c = e.onBlur;
	c === void 0 && (c = s);
	var d = e.thousandSeparator, p = e.decimalScale, m = e.fixedDecimalScale, h = e.prefix;
	h === void 0 && (h = "");
	var g = e.defaultValue, _ = e.value, y = e.valueIsNumericString, b = e.onValueChange, T = a(e, [
		"decimalSeparator",
		"allowedDecimalSeparators",
		"thousandsGroupStyle",
		"suffix",
		"allowNegative",
		"allowLeadingZeros",
		"onKeyDown",
		"onBlur",
		"thousandSeparator",
		"decimalScale",
		"fixedDecimalScale",
		"prefix",
		"defaultValue",
		"value",
		"valueIsNumericString",
		"onValueChange"
	]), E = z(e), D = E.decimalSeparator, O = E.allowedDecimalSeparators, k = function(t) {
		return R(t, e);
	}, A = function(t, n) {
		return H(t, n, e);
	}, j = u(_) ? g : _, M = y ?? ee(j, h, t);
	u(_) ? u(g) || (M ||= typeof g == "number") : M ||= typeof _ == "number";
	var N = function(e) {
		return f(e) ? e : (typeof e == "number" && (e = x(e)), M && typeof p == "number" ? S(e, p, !!m) : e);
	}, F = P(N(_), N(g), !!M, k, A, b), I = F[0], L = I.numAsString, B = I.formattedValue, V = F[1];
	return Object.assign(Object.assign({}, T), {
		value: B,
		valueIsNumericString: !1,
		isValidInputCharacter: function(e) {
			return e === D || l(e);
		},
		isCharacterSame: function(e) {
			var t = e.currentValue, n = e.lastValue, r = e.formattedValue, i = e.currentValueIndex, a = e.formattedValueIndex, o = t[i], s = r[a], c = w(n, t).to, l = function(e) {
				return A(e).indexOf(".") + h.length;
			};
			return _ === 0 && m && p && t[c.start] === D && l(t) < i && l(r) > a ? !1 : i >= c.start && i < c.end && O && O.includes(o) && s === D ? !0 : o === s;
		},
		onValueChange: V,
		format: k,
		removeFormatting: A,
		getCaretBoundary: function(t) {
			return U(t, e);
		},
		onKeyDown: function(e) {
			var t = e.target, r = e.key, a = t.selectionStart, o = t.selectionEnd, s = t.value;
			if (s === void 0 && (s = ""), (r === "Backspace" || r === "Delete") && o < h.length) {
				e.preventDefault();
				return;
			}
			if (a !== o) {
				i(e);
				return;
			}
			r === "Backspace" && s[0] === "-" && a === h.length + 1 && n && C(t, 1), p && m && (r === "Backspace" && s[a - 1] === D ? (C(t, a - 1), e.preventDefault()) : r === "Delete" && s[a] === D && e.preventDefault()), O?.includes(r) && s[a] === D && C(t, a + 1);
			var c = d === !0 ? "," : d;
			r === "Backspace" && s[a - 1] === c && C(t, a - 1), r === "Delete" && s[a] === c && C(t, a + 1), i(e);
		},
		onBlur: function(t) {
			var n = L;
			n.match(/\d/g) || (n = ""), r || (n = v(n)), m && p && (n = S(n, p, m)), n !== L && V({
				formattedValue: R(n, e),
				value: n,
				floatValue: parseFloat(n)
			}, {
				event: t,
				source: o.event
			}), c(t);
		}
	});
}
function te(e) {
	var t = G(e);
	return r.createElement(L, Object.assign({}, t));
}
function K() {
	return Intl.NumberFormat()?.formatToParts(1.1)?.find((e) => e.type === "decimal")?.value ?? ".";
}
function q() {
	return K() === "." ? "," : ".";
}
var J = (e) => {
	let { value: t, onChange: n, disabled: a, highlight: o, validatedSelection: s, fixedDecimals: c, allowNegative: l, thousandSeparator: u, decimalSeparator: d } = e, f = r.useRef();
	return r.useLayoutEffect(() => {
		if (s !== void 0) {
			let e = typeof s == "number" ? [s, null] : s;
			f.current?.setSelectionRange(e[0], e[1]);
		}
	}, [s]), r.createElement(i, null, r.createElement(te, {
		autoFocus: !0,
		getInputRef: f,
		className: "gdg-input",
		onFocus: (e) => e.target.setSelectionRange(o ? 0 : e.target.value.length, e.target.value.length),
		disabled: a === !0,
		decimalScale: c,
		allowNegative: l,
		thousandSeparator: u ?? q(),
		decimalSeparator: d ?? K(),
		value: Object.is(t, -0) ? "-" : t ?? "",
		onValueChange: n
	}));
};
//#endregion
export { J as default };

//# sourceMappingURL=number-overlay-editor-C2wAcnJq-U12_eG7L.js.map