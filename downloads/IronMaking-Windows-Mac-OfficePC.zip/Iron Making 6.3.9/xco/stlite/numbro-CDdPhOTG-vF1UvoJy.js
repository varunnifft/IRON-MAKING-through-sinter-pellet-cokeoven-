//#region ../react/build/numbro-CDdPhOTG.js
var e = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function t(e) {
	return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var n, r;
function i() {
	return r || (r = 1, n = {
		languageTag: "en-US",
		delimiters: {
			thousands: ",",
			decimal: "."
		},
		abbreviations: {
			thousand: "k",
			million: "m",
			billion: "b",
			trillion: "t"
		},
		spaceSeparated: !1,
		ordinal: function(e) {
			let t = e % 10;
			return ~~(e % 100 / 10) == 1 ? "th" : t === 1 ? "st" : t === 2 ? "nd" : t === 3 ? "rd" : "th";
		},
		bytes: {
			binarySuffixes: [
				"B",
				"KiB",
				"MiB",
				"GiB",
				"TiB",
				"PiB",
				"EiB",
				"ZiB",
				"YiB"
			],
			decimalSuffixes: [
				"B",
				"KB",
				"MB",
				"GB",
				"TB",
				"PB",
				"EB",
				"ZB",
				"YB"
			]
		},
		currency: {
			symbol: "$",
			position: "prefix",
			code: "USD"
		},
		currencyFormat: {
			thousandSeparated: !0,
			totalLength: 4,
			spaceSeparated: !0,
			spaceSeparatedCurrency: !0
		},
		formats: {
			fourDigits: {
				totalLength: 4,
				spaceSeparated: !0
			},
			fullWithTwoDecimals: {
				output: "currency",
				thousandSeparated: !0,
				mantissa: 2
			},
			fullWithTwoDecimalsNoCurrency: {
				thousandSeparated: !0,
				mantissa: 2
			},
			fullWithNoDecimals: {
				output: "currency",
				thousandSeparated: !0,
				mantissa: 0
			}
		}
	}), n;
}
var a, o;
function s() {
	if (o) return a;
	o = 1;
	let e = [
		{
			key: "ZiB",
			factor: 1024 ** 7
		},
		{
			key: "ZB",
			factor: 1e3 ** 7
		},
		{
			key: "YiB",
			factor: 1024 ** 8
		},
		{
			key: "YB",
			factor: 1e3 ** 8
		},
		{
			key: "TiB",
			factor: 1024 ** 4
		},
		{
			key: "TB",
			factor: 1e3 ** 4
		},
		{
			key: "PiB",
			factor: 1024 ** 5
		},
		{
			key: "PB",
			factor: 1e3 ** 5
		},
		{
			key: "MiB",
			factor: 1024 ** 2
		},
		{
			key: "MB",
			factor: 1e3 ** 2
		},
		{
			key: "KiB",
			factor: 1024
		},
		{
			key: "KB",
			factor: 1e3
		},
		{
			key: "GiB",
			factor: 1024 ** 3
		},
		{
			key: "GB",
			factor: 1e3 ** 3
		},
		{
			key: "EiB",
			factor: 1024 ** 6
		},
		{
			key: "EB",
			factor: 1e3 ** 6
		},
		{
			key: "B",
			factor: 1
		}
	];
	function t(e) {
		return e.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
	}
	function n(r, i, a, o, s, c, l) {
		if (!isNaN(+r)) return +r;
		let u = "", d = r.replace(/(^[^(]*)\((.*)\)([^)]*$)/, "$1$2$3");
		if (d !== r) return -1 * n(d, i, a, o, s, c);
		for (let t = 0; t < e.length; t++) {
			let l = e[t];
			if (u = r.replace(RegExp(`([0-9 ])(${l.key})$`), "$1"), u !== r) return n(u, i, a, o, s, c) * l.factor;
		}
		if (u = r.replace("%", ""), u !== r) return n(u, i, a, o, s, c) / 100;
		let f = parseFloat(r);
		if (isNaN(f)) return;
		let p = o(f);
		if (p && p !== "." && (u = r.replace(RegExp(`${t(p)}$`), ""), u !== r)) return n(u, i, a, o, s, c);
		let m = {};
		Object.keys(c).forEach((e) => {
			m[c[e]] = e;
		});
		let h = Object.keys(m).sort().reverse(), g = h.length;
		for (let e = 0; e < g; e++) {
			let t = h[e], l = m[t];
			if (u = r.replace(t, ""), u !== r) {
				let e;
				switch (l) {
					case "thousand":
						e = 1e3;
						break;
					case "million":
						e = 10 ** 6;
						break;
					case "billion":
						e = 10 ** 9;
						break;
					case "trillion": e = 10 ** 12;
				}
				return n(u, i, a, o, s, c) * e;
			}
		}
	}
	function r(e, n, r) {
		let i = e.replace(r, "");
		return i = i.replace(RegExp(`([0-9])${t(n.thousands)}([0-9])`, "g"), "$1$2"), i = i.replace(n.decimal, "."), i;
	}
	function i(e, t, i = "", a, o, s, c) {
		if (e !== "") return e === o ? 0 : n(r(e, t, i), t, i, a, o, s);
	}
	function s(e, t) {
		if (!(e.indexOf(":") && t.thousands !== ":")) return !1;
		let n = e.split(":");
		if (n.length !== 3) return !1;
		let r = +n[0], i = +n[1], a = +n[2];
		return !isNaN(r) && !isNaN(i) && !isNaN(a);
	}
	function c(e) {
		let t = e.split(":"), n = +t[0], r = +t[1];
		return +t[2] + 60 * r + 3600 * n;
	}
	function l(e, t) {
		let n = A(), r = n.currentDelimiters(), a = n.currentCurrency().symbol, o = n.currentOrdinal(), l = n.getZeroFormat(), u = n.currentAbbreviations(), d;
		if (typeof e == "string") d = s(e, r) ? c(e) : i(e, r, a, o, l, u);
		else if (typeof e == "number") d = e;
		else return;
		if (d !== void 0) return d;
	}
	return a = { unformat: l }, a;
}
var c, l;
function u() {
	if (l) return c;
	l = 1;
	let e = s(), t = /^[a-z]{2,3}(-[a-zA-Z]{4})?(-([A-Z]{2}|[0-9]{3}))?$/, n = [
		"currency",
		"percent",
		"byte",
		"time",
		"ordinal",
		"number"
	], r = [
		"trillion",
		"billion",
		"million",
		"thousand"
	], i = [
		"prefix",
		"infix",
		"postfix"
	], a = ["sign", "parenthesis"], o = {
		type: "object",
		children: {
			thousand: {
				type: "string",
				mandatory: !0
			},
			million: {
				type: "string",
				mandatory: !0
			},
			billion: {
				type: "string",
				mandatory: !0
			},
			trillion: {
				type: "string",
				mandatory: !0
			}
		},
		mandatory: !0
	}, u = {
		output: {
			type: "string",
			validValues: n
		},
		base: {
			type: "string",
			validValues: [
				"decimal",
				"binary",
				"general"
			],
			restriction: (e, t) => t.output === "byte",
			message: "`base` must be provided only when the output is `byte`",
			mandatory: (e) => e.output === "byte"
		},
		characteristic: {
			type: "number",
			restriction: (e) => e >= 0,
			message: "value must be positive"
		},
		prefix: "string",
		postfix: "string",
		forceAverage: {
			type: "string",
			validValues: r
		},
		average: "boolean",
		lowPrecision: {
			type: "boolean",
			restriction: (e, t) => t.average === !0,
			message: "`lowPrecision` must be provided only when the option `average` is set"
		},
		currencyPosition: {
			type: "string",
			validValues: i
		},
		currencySymbol: "string",
		totalLength: {
			type: "number",
			restrictions: [{
				restriction: (e) => e >= 0,
				message: "value must be positive"
			}, {
				restriction: (e, t) => !t.exponential,
				message: "`totalLength` is incompatible with `exponential`"
			}]
		},
		mantissa: {
			type: "number",
			restriction: (e) => e >= 0,
			message: "value must be positive"
		},
		optionalMantissa: "boolean",
		trimMantissa: "boolean",
		roundingFunction: "function",
		optionalCharacteristic: "boolean",
		thousandSeparated: "boolean",
		spaceSeparated: "boolean",
		spaceSeparatedCurrency: "boolean",
		spaceSeparatedAbbreviation: "boolean",
		abbreviations: {
			type: "object",
			children: {
				thousand: "string",
				million: "string",
				billion: "string",
				trillion: "string"
			}
		},
		negative: {
			type: "string",
			validValues: a
		},
		forceSign: "boolean",
		exponential: { type: "boolean" },
		prefixSymbol: {
			type: "boolean",
			restriction: (e, t) => t.output === "percent",
			message: "`prefixSymbol` can be provided only when the output is `percent`"
		}
	}, d = {
		languageTag: {
			type: "string",
			mandatory: !0,
			restriction: (e) => e.match(t),
			message: "the language tag must follow the BCP 47 specification (see https://tools.ieft.org/html/bcp47)"
		},
		delimiters: {
			type: "object",
			children: {
				thousands: "string",
				decimal: "string",
				thousandsSize: "number"
			},
			mandatory: !0
		},
		abbreviations: o,
		spaceSeparated: "boolean",
		spaceSeparatedCurrency: "boolean",
		ordinal: {
			type: "function",
			mandatory: !0
		},
		bytes: {
			type: "object",
			children: {
				binarySuffixes: "object",
				decimalSuffixes: "object"
			}
		},
		currency: {
			type: "object",
			children: {
				symbol: "string",
				position: "string",
				code: "string"
			},
			mandatory: !0
		},
		defaults: "format",
		ordinalFormat: "format",
		byteFormat: "format",
		percentageFormat: "format",
		currencyFormat: "format",
		timeDefaults: "format",
		formats: {
			type: "object",
			children: {
				fourDigits: {
					type: "format",
					mandatory: !0
				},
				fullWithTwoDecimals: {
					type: "format",
					mandatory: !0
				},
				fullWithTwoDecimalsNoCurrency: {
					type: "format",
					mandatory: !0
				},
				fullWithNoDecimals: {
					type: "format",
					mandatory: !0
				}
			}
		}
	};
	function f(e, t) {
		let n = p(e), r = h(t);
		return n && r;
	}
	function p(t) {
		return e.unformat(t) !== void 0;
	}
	function m(e, t, n, r = !1) {
		let i = Object.keys(e).map((r) => {
			if (!t[r]) return console.error(`${n} Invalid key: ${r}`), !1;
			let i = e[r], a = t[r];
			if (typeof a == "string" && (a = { type: a }), a.type === "format") {
				if (!m(i, u, `[Validate ${r}]`, !0)) return !1;
			} else if (typeof i !== a.type) return console.error(`${n} ${r} type mismatched: "${a.type}" expected, "${typeof i}" provided`), !1;
			if (a.restrictions && a.restrictions.length) {
				let t = a.restrictions.length;
				for (let o = 0; o < t; o++) {
					let { restriction: t, message: s } = a.restrictions[o];
					if (!t(i, e)) return console.error(`${n} ${r} invalid value: ${s}`), !1;
				}
			}
			return a.restriction && !a.restriction(i, e) ? (console.error(`${n} ${r} invalid value: ${a.message}`), !1) : a.validValues && a.validValues.indexOf(i) === -1 ? (console.error(`${n} ${r} invalid value: must be among ${JSON.stringify(a.validValues)}, "${i}" provided`), !1) : !(a.children && !m(i, a.children, `[Validate ${r}]`));
		});
		return r || i.push(...Object.keys(t).map((r) => {
			let i = t[r];
			if (typeof i == "string" && (i = { type: i }), i.mandatory) {
				let t = i.mandatory;
				if (typeof t == "function" && (t = t(e)), t && e[r] === void 0) return console.error(`${n} Missing mandatory key "${r}"`), !1;
			}
			return !0;
		})), i.reduce((e, t) => e && t, !0);
	}
	function h(e) {
		return m(e, u, "[Validate format]");
	}
	function g(e) {
		return m(e, d, "[Validate language]");
	}
	return c = {
		validate: f,
		validateFormat: h,
		validateInput: p,
		validateLanguage: g
	}, c;
}
function d(e, t) {
	let n = e.match(/^{([^}]*)}/);
	return n ? (t.prefix = n[1], e.slice(n[0].length)) : e;
}
function f(e, t) {
	let n = e.match(/{([^}]*)}$/);
	return n ? (t.postfix = n[1], e.slice(0, -n[0].length)) : e;
}
function p(e, t) {
	if (e.indexOf("$") !== -1) {
		t.output = "currency";
		return;
	}
	if (e.indexOf("%") !== -1) {
		t.output = "percent";
		return;
	}
	if (e.indexOf("bd") !== -1) {
		t.output = "byte", t.base = "general";
		return;
	}
	if (e.indexOf("b") !== -1) {
		t.output = "byte", t.base = "binary";
		return;
	}
	if (e.indexOf("d") !== -1) {
		t.output = "byte", t.base = "decimal";
		return;
	}
	if (e.indexOf(":") !== -1) {
		t.output = "time";
		return;
	}
	e.indexOf("o") !== -1 && (t.output = "ordinal");
}
function m(e, t) {
	e.indexOf(",") !== -1 && (t.thousandSeparated = !0);
}
function h(e, t) {
	e.indexOf(" ") !== -1 && (t.spaceSeparated = !0, t.spaceSeparatedCurrency = !0, (t.average || t.forceAverage) && (t.spaceSeparatedAbbreviation = !0));
}
function g(e, t) {
	let n = e.match(/[1-9]+[0-9]*/);
	n && (t.totalLength = +n[0]);
}
function _(e, t) {
	let n = e.split(".")[0].match(/0+/);
	n && (t.characteristic = n[0].length);
}
function v(e, t) {
	let n = e.split(".")[1];
	if (n) {
		let e = n.match(/0+/);
		e && (t.mantissa = e[0].length);
	}
}
function y(e, t) {
	let n = e.split(".")[1];
	n && (t.trimMantissa = n.indexOf("[") !== -1);
}
function b(e, t) {
	e.indexOf("a") !== -1 && (t.average = !0);
}
function x(e, t) {
	e.indexOf("K") === -1 ? e.indexOf("M") === -1 ? e.indexOf("B") === -1 ? e.indexOf("T") !== -1 && (t.forceAverage = "trillion") : t.forceAverage = "billion" : t.forceAverage = "million" : t.forceAverage = "thousand";
}
function S(e, t) {
	e.match(/\[\.]/) ? t.optionalMantissa = !0 : e.match(/\./) && (t.optionalMantissa = !1);
}
function C(e, t) {
	e.indexOf(".") !== -1 && (t.optionalCharacteristic = e.split(".")[0].indexOf("0") === -1);
}
function w(e, t) {
	e.match(/^\+?\([^)]*\)$/) && (t.negative = "parenthesis"), e.match(/^\+?-/) && (t.negative = "sign");
}
function T(e, t) {
	e.match(/^\+/) && (t.forceSign = !0);
}
function E(e, t = {}) {
	return typeof e == "string" ? (e = d(e, t), e = f(e, t), p(e, t), g(e, t), _(e, t), C(e, t), b(e, t), x(e, t), v(e, t), S(e, t), y(e, t), m(e, t), h(e, t), w(e, t), T(e, t), t) : e;
}
var D = { parseFormat: E }, O, k;
function A() {
	if (k) return O;
	k = 1;
	let e = i(), t = u(), n = D, r = {}, a, o = {}, s = null, c = {};
	function l(e) {
		a = e;
	}
	function d() {
		return o[a];
	}
	return r.languages = () => Object.assign({}, o), r.currentLanguage = () => a, r.currentBytes = () => d().bytes || {}, r.currentCurrency = () => d().currency, r.currentAbbreviations = () => d().abbreviations, r.currentDelimiters = () => d().delimiters, r.currentOrdinal = () => d().ordinal, r.currentDefaults = () => Object.assign({}, d().defaults, c), r.currentOrdinalDefaultFormat = () => Object.assign({}, r.currentDefaults(), d().ordinalFormat), r.currentByteDefaultFormat = () => Object.assign({}, r.currentDefaults(), d().byteFormat), r.currentPercentageDefaultFormat = () => Object.assign({}, r.currentDefaults(), d().percentageFormat), r.currentCurrencyDefaultFormat = () => Object.assign({}, r.currentDefaults(), d().currencyFormat), r.currentTimeDefaultFormat = () => Object.assign({}, r.currentDefaults(), d().timeFormat), r.setDefaults = (e) => {
		e = n.parseFormat(e), t.validateFormat(e) && (c = e);
	}, r.getZeroFormat = () => s, r.setZeroFormat = (e) => s = typeof e == "string" ? e : null, r.hasZeroFormat = () => s !== null, r.languageData = (e) => {
		if (e) {
			if (o[e]) return o[e];
			throw Error(`Unknown tag "${e}"`);
		}
		return d();
	}, r.registerLanguage = (e, n = !1) => {
		if (!t.validateLanguage(e)) throw Error("Invalid language data");
		o[e.languageTag] = e, n && l(e.languageTag);
	}, r.setLanguage = (t, n = e.languageTag) => {
		if (!o[t]) {
			let e = t.split("-")[0], r = Object.keys(o).find((t) => t.split("-")[0] === e);
			if (!o[r]) {
				l(n);
				return;
			}
			l(r);
			return;
		}
		l(t);
	}, r.registerLanguage(e), a = e.languageTag, O = r, O;
}
function j(e) {
	throw Error("Could not dynamically require \"" + e + "\". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.");
}
function M(e, t) {
	e.forEach((e) => {
		let n;
		try {
			n = j(`../languages/${e}`);
		} catch {
			console.error(`Unable to load "${e}". No matching language file found.`);
		}
		n && t.registerLanguage(n);
	});
}
var N = (e) => ({ loadLanguagesInNode: (t) => M(t, e) }), P = { exports: {} };
(function(t) {
	(function(e) {
		var n, r = /^-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i, i = Math.ceil, a = Math.floor, o = "[BigNumber Error] ", s = o + "Number primitive has more than 15 significant digits: ", c = 0x5af3107a4000, l = 14, u = 9007199254740991, d = [
			1,
			10,
			100,
			1e3,
			1e4,
			1e5,
			1e6,
			1e7,
			1e8,
			1e9,
			1e10,
			1e11,
			0xe8d4a51000,
			0x9184e72a000
		], f = 1e7, p = 1e9;
		function m(e) {
			var t, n, S, C = L.prototype = {
				constructor: L,
				toString: null,
				valueOf: null
			}, w = new L(1), T = 20, E = 4, D = -7, O = 21, k = -1e7, A = 1e7, j = !1, M = 1, N = 0, P = {
				prefix: "",
				groupSize: 3,
				secondaryGroupSize: 0,
				groupSeparator: ",",
				decimalSeparator: ".",
				fractionGroupSize: 0,
				fractionGroupSeparator: "\xA0",
				suffix: ""
			}, F = "0123456789abcdefghijklmnopqrstuvwxyz", I = !0;
			function L(e, t) {
				var i, o, c, d, f, p, m, h, g = this;
				if (!(g instanceof L)) return new L(e, t);
				if (t == null) {
					if (e && e._isBigNumber === !0) {
						g.s = e.s, !e.c || e.e > A ? g.c = g.e = null : e.e < k ? g.c = [g.e = 0] : (g.e = e.e, g.c = e.c.slice());
						return;
					}
					if ((p = typeof e == "number") && e * 0 == 0) {
						if (g.s = 1 / e < 0 ? (e = -e, -1) : 1, e === ~~e) {
							for (d = 0, f = e; f >= 10; f /= 10, d++);
							d > A ? g.c = g.e = null : (g.e = d, g.c = [e]);
							return;
						}
						h = String(e);
					} else {
						if (!r.test(h = String(e))) return S(g, h, p);
						g.s = h.charCodeAt(0) == 45 ? (h = h.slice(1), -1) : 1;
					}
					(d = h.indexOf(".")) > -1 && (h = h.replace(".", "")), (f = h.search(/e/i)) > 0 ? (d < 0 && (d = f), d += +h.slice(f + 1), h = h.substring(0, f)) : d < 0 && (d = h.length);
				} else {
					if (v(t, 2, F.length, "Base"), t == 10 && I) return g = new L(e), V(g, T + g.e + 1, E);
					if (h = String(e), p = typeof e == "number") {
						if (e * 0 != 0) return S(g, h, p, t);
						if (g.s = 1 / e < 0 ? (h = h.slice(1), -1) : 1, L.DEBUG && h.replace(/^0\.0*|\./, "").length > 15) throw Error(s + e);
					} else g.s = h.charCodeAt(0) === 45 ? (h = h.slice(1), -1) : 1;
					for (i = F.slice(0, t), d = f = 0, m = h.length; f < m; f++) if (i.indexOf(o = h.charAt(f)) < 0) {
						if (o == ".") {
							if (f > d) {
								d = m;
								continue;
							}
						} else if (!c && (h == h.toUpperCase() && (h = h.toLowerCase()) || h == h.toLowerCase() && (h = h.toUpperCase()))) {
							c = !0, f = -1, d = 0;
							continue;
						}
						return S(g, String(e), p, t);
					}
					p = !1, h = n(h, t, 10, g.s), (d = h.indexOf(".")) > -1 ? h = h.replace(".", "") : d = h.length;
				}
				for (f = 0; h.charCodeAt(f) === 48; f++);
				for (m = h.length; h.charCodeAt(--m) === 48;);
				if (h = h.slice(f, ++m)) {
					if (m -= f, p && L.DEBUG && m > 15 && (e > u || e !== a(e))) throw Error(s + g.s * e);
					if ((d = d - f - 1) > A) g.c = g.e = null;
					else if (d < k) g.c = [g.e = 0];
					else {
						if (g.e = d, g.c = [], f = (d + 1) % l, d < 0 && (f += l), f < m) {
							for (f && g.c.push(+h.slice(0, f)), m -= l; f < m;) g.c.push(+h.slice(f, f += l));
							f = l - (h = h.slice(f)).length;
						} else f -= m;
						for (; f--; h += "0");
						g.c.push(+h);
					}
				} else g.c = [g.e = 0];
			}
			L.clone = m, L.ROUND_UP = 0, L.ROUND_DOWN = 1, L.ROUND_CEIL = 2, L.ROUND_FLOOR = 3, L.ROUND_HALF_UP = 4, L.ROUND_HALF_DOWN = 5, L.ROUND_HALF_EVEN = 6, L.ROUND_HALF_CEIL = 7, L.ROUND_HALF_FLOOR = 8, L.EUCLID = 9, L.config = L.set = function(e) {
				var t, n;
				if (e != null) {
					if (typeof e == "object") {
						if (e.hasOwnProperty(t = "DECIMAL_PLACES") && (n = e[t], v(n, 0, p, t), T = n), e.hasOwnProperty(t = "ROUNDING_MODE") && (n = e[t], v(n, 0, 8, t), E = n), e.hasOwnProperty(t = "EXPONENTIAL_AT") && (n = e[t], n && n.pop ? (v(n[0], -p, 0, t), v(n[1], 0, p, t), D = n[0], O = n[1]) : (v(n, -p, p, t), D = -(O = n < 0 ? -n : n))), e.hasOwnProperty(t = "RANGE")) {
							if (n = e[t], n && n.pop) v(n[0], -p, -1, t), v(n[1], 1, p, t), k = n[0], A = n[1];
							else if (v(n, -p, p, t), n) k = -(A = n < 0 ? -n : n);
							else throw Error(o + t + " cannot be zero: " + n);
						}
						if (e.hasOwnProperty(t = "CRYPTO")) {
							if (n = e[t], n === !!n) {
								if (n) {
									if (typeof crypto < "u" && crypto && (crypto.getRandomValues || crypto.randomBytes)) j = n;
									else throw j = !n, Error(o + "crypto unavailable");
								} else j = n;
							} else throw Error(o + t + " not true or false: " + n);
						}
						if (e.hasOwnProperty(t = "MODULO_MODE") && (n = e[t], v(n, 0, 9, t), M = n), e.hasOwnProperty(t = "POW_PRECISION") && (n = e[t], v(n, 0, p, t), N = n), e.hasOwnProperty(t = "FORMAT")) {
							if (n = e[t], typeof n == "object") P = n;
							else throw Error(o + t + " not an object: " + n);
						}
						if (e.hasOwnProperty(t = "ALPHABET")) {
							if (n = e[t], typeof n == "string" && !/^.?$|[+\-.\s]|(.).*\1/.test(n)) I = n.slice(0, 10) == "0123456789", F = n;
							else throw Error(o + t + " invalid: " + n);
						}
					} else throw Error(o + "Object expected: " + e);
				}
				return {
					DECIMAL_PLACES: T,
					ROUNDING_MODE: E,
					EXPONENTIAL_AT: [D, O],
					RANGE: [k, A],
					CRYPTO: j,
					MODULO_MODE: M,
					POW_PRECISION: N,
					FORMAT: P,
					ALPHABET: F
				};
			}, L.isBigNumber = function(e) {
				if (!e || e._isBigNumber !== !0) return !1;
				if (!L.DEBUG) return !0;
				var t, n, r = e.c, i = e.e, s = e.s;
				e: if ({}.toString.call(r) == "[object Array]") {
					if ((s === 1 || s === -1) && i >= -p && i <= p && i === a(i)) {
						if (r[0] === 0) {
							if (i === 0 && r.length === 1) return !0;
							break e;
						}
						if (t = (i + 1) % l, t < 1 && (t += l), String(r[0]).length == t) {
							for (t = 0; t < r.length; t++) if (n = r[t], n < 0 || n >= c || n !== a(n)) break e;
							if (n !== 0) return !0;
						}
					}
				} else if (r === null && i === null && (s === null || s === 1 || s === -1)) return !0;
				throw Error(o + "Invalid BigNumber: " + e);
			}, L.maximum = L.max = function() {
				return z(arguments, -1);
			}, L.minimum = L.min = function() {
				return z(arguments, 1);
			}, L.random = function() {
				var e = 9007199254740992, t = Math.random() * e & 2097151 ? function() {
					return a(Math.random() * e);
				} : function() {
					return (Math.random() * 1073741824 | 0) * 8388608 + (Math.random() * 8388608 | 0);
				};
				return function(e) {
					var n, r, s, c, u, f = 0, m = [], h = new L(w);
					if (e == null ? e = T : v(e, 0, p), c = i(e / l), j) {
						if (crypto.getRandomValues) {
							for (n = crypto.getRandomValues(new Uint32Array(c *= 2)); f < c;) u = n[f] * 131072 + (n[f + 1] >>> 11), u >= 9e15 ? (r = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(2)), n[f] = r[0], n[f + 1] = r[1]) : (m.push(u % 0x5af3107a4000), f += 2);
							f = c / 2;
						} else if (crypto.randomBytes) {
							for (n = crypto.randomBytes(c *= 7); f < c;) u = (n[f] & 31) * 281474976710656 + n[f + 1] * 1099511627776 + n[f + 2] * 4294967296 + n[f + 3] * 16777216 + (n[f + 4] << 16) + (n[f + 5] << 8) + n[f + 6], u >= 9e15 ? crypto.randomBytes(7).copy(n, f) : (m.push(u % 0x5af3107a4000), f += 7);
							f = c / 7;
						} else throw j = !1, Error(o + "crypto unavailable");
					}
					if (!j) for (; f < c;) u = t(), u < 9e15 && (m[f++] = u % 0x5af3107a4000);
					for (c = m[--f], e %= l, c && e && (u = d[l - e], m[f] = a(c / u) * u); m[f] === 0; m.pop(), f--);
					if (f < 0) m = [s = 0];
					else {
						for (s = -1; m[0] === 0; m.splice(0, 1), s -= l);
						for (f = 1, u = m[0]; u >= 10; u /= 10, f++);
						f < l && (s -= l - f);
					}
					return h.e = s, h.c = m, h;
				};
			}(), L.sum = function() {
				for (var e = 1, t = arguments, n = new L(t[0]); e < t.length;) n = n.plus(t[e++]);
				return n;
			}, n = /* @__PURE__ */ function() {
				var e = "0123456789";
				function n(e, t, n, r) {
					for (var i, a = [0], o, s = 0, c = e.length; s < c;) {
						for (o = a.length; o--; a[o] *= t);
						for (a[0] += r.indexOf(e.charAt(s++)), i = 0; i < a.length; i++) a[i] > n - 1 && (a[i + 1] ?? (a[i + 1] = 0), a[i + 1] += a[i] / n | 0, a[i] %= n);
					}
					return a.reverse();
				}
				return function(r, i, a, o, s) {
					var c, l, u, d, f, p, m, h, _ = r.indexOf("."), v = T, y = E;
					for (_ >= 0 && (d = N, N = 0, r = r.replace(".", ""), h = new L(i), p = h.pow(r.length - _), N = d, h.c = n(x(g(p.c), p.e, "0"), 10, a, e), h.e = h.c.length), m = n(r, i, a, s ? (c = F, e) : (c = e, F)), u = d = m.length; m[--d] == 0; m.pop());
					if (!m[0]) return c.charAt(0);
					if (_ < 0 ? --u : (p.c = m, p.e = u, p.s = o, p = t(p, h, v, y, a), m = p.c, f = p.r, u = p.e), l = u + v + 1, _ = m[l], d = a / 2, f = f || l < 0 || m[l + 1] != null, f = y < 4 ? (_ != null || f) && (y == 0 || y == (p.s < 0 ? 3 : 2)) : _ > d || _ == d && (y == 4 || f || y == 6 && m[l - 1] & 1 || y == (p.s < 0 ? 8 : 7)), l < 1 || !m[0]) r = f ? x(c.charAt(1), -v, c.charAt(0)) : c.charAt(0);
					else {
						if (m.length = l, f) for (--a; ++m[--l] > a;) m[l] = 0, l || (++u, m = [1].concat(m));
						for (d = m.length; !m[--d];);
						for (_ = 0, r = ""; _ <= d; r += c.charAt(m[_++]));
						r = x(r, u, c.charAt(0));
					}
					return r;
				};
			}(), t = /* @__PURE__ */ function() {
				function e(e, t, n) {
					var r, i, a, o, s = 0, c = e.length, l = t % f, u = t / f | 0;
					for (e = e.slice(); c--;) a = e[c] % f, o = e[c] / f | 0, r = u * a + o * l, i = l * a + r % f * f + s, s = (i / n | 0) + (r / f | 0) + u * o, e[c] = i % n;
					return s && (e = [s].concat(e)), e;
				}
				function t(e, t, n, r) {
					var i, a;
					if (n != r) a = n > r ? 1 : -1;
					else for (i = a = 0; i < n; i++) if (e[i] != t[i]) {
						a = e[i] > t[i] ? 1 : -1;
						break;
					}
					return a;
				}
				function n(e, t, n, r) {
					for (var i = 0; n--;) e[n] -= i, i = +(e[n] < t[n]), e[n] = i * r + e[n] - t[n];
					for (; !e[0] && e.length > 1; e.splice(0, 1));
				}
				return function(r, i, o, s, u) {
					var d, f, p, m, g, _, v, y, b, x, S, C, w, T, E, D, O, k = r.s == i.s ? 1 : -1, A = r.c, j = i.c;
					if (!A || !A[0] || !j || !j[0]) return new L(!r.s || !i.s || (A ? j && A[0] == j[0] : !j) ? NaN : A && A[0] == 0 || !j ? k * 0 : k / 0);
					for (y = new L(k), b = y.c = [], f = r.e - i.e, k = o + f + 1, u || (u = c, f = h(r.e / l) - h(i.e / l), k = k / l | 0), p = 0; j[p] == (A[p] || 0); p++);
					if (j[p] > (A[p] || 0) && f--, k < 0) b.push(1), m = !0;
					else {
						for (T = A.length, D = j.length, p = 0, k += 2, g = a(u / (j[0] + 1)), g > 1 && (j = e(j, g, u), A = e(A, g, u), D = j.length, T = A.length), w = D, x = A.slice(0, D), S = x.length; S < D; x[S++] = 0);
						O = j.slice(), O = [0].concat(O), E = j[0], j[1] >= u / 2 && E++;
						do {
							if (g = 0, d = t(j, x, D, S), d < 0) {
								if (C = x[0], D != S && (C = C * u + (x[1] || 0)), g = a(C / E), g > 1) for (g >= u && (g = u - 1), _ = e(j, g, u), v = _.length, S = x.length; t(_, x, v, S) == 1;) g--, n(_, D < v ? O : j, v, u), v = _.length, d = 1;
								else g == 0 && (d = g = 1), _ = j.slice(), v = _.length;
								if (v < S && (_ = [0].concat(_)), n(x, _, S, u), S = x.length, d == -1) for (; t(j, x, D, S) < 1;) g++, n(x, D < S ? O : j, S, u), S = x.length;
							} else d === 0 && (g++, x = [0]);
							b[p++] = g, x[0] ? x[S++] = A[w] || 0 : (x = [A[w]], S = 1);
						} while ((w++ < T || x[0] != null) && k--);
						m = x[0] != null, b[0] || b.splice(0, 1);
					}
					if (u == c) {
						for (p = 1, k = b[0]; k >= 10; k /= 10, p++);
						V(y, o + (y.e = p + f * l - 1) + 1, s, m);
					} else y.e = f, y.r = +m;
					return y;
				};
			}();
			function R(e, t, n, r) {
				var i, a, o, s, c;
				if (n == null ? n = E : v(n, 0, 8), !e.c) return e.toString();
				if (i = e.c[0], o = e.e, t == null) c = g(e.c), c = r == 1 || r == 2 && (o <= D || o >= O) ? b(c, o) : x(c, o, "0");
				else if (e = V(new L(e), t, n), a = e.e, c = g(e.c), s = c.length, r == 1 || r == 2 && (t <= a || a <= D)) {
					for (; s < t; c += "0", s++);
					c = b(c, a);
				} else if (t -= o, c = x(c, a, "0"), a + 1 > s) {
					if (--t > 0) for (c += "."; t--; c += "0");
				} else if (t += a - s, t > 0) for (a + 1 == s && (c += "."); t--; c += "0");
				return e.s < 0 && i ? "-" + c : c;
			}
			function z(e, t) {
				for (var n, r, i = 1, a = new L(e[0]); i < e.length; i++) r = new L(e[i]), (!r.s || (n = _(a, r)) === t || n === 0 && a.s === t) && (a = r);
				return a;
			}
			function B(e, t, n) {
				for (var r = 1, i = t.length; !t[--i]; t.pop());
				for (i = t[0]; i >= 10; i /= 10, r++);
				return (n = r + n * l - 1) > A ? e.c = e.e = null : n < k ? e.c = [e.e = 0] : (e.e = n, e.c = t), e;
			}
			S = /* @__PURE__ */ function() {
				var e = /^(-?)0([xbo])(?=\w[\w.]*$)/i, t = /^([^.]+)\.$/, n = /^\.([^.]+)$/, r = /^-?(Infinity|NaN)$/, i = /^\s*\+(?=[\w.])|^\s+|\s+$/g;
				return function(a, s, c, l) {
					var u, d = c ? s : s.replace(i, "");
					if (r.test(d)) a.s = isNaN(d) ? null : d < 0 ? -1 : 1;
					else {
						if (!c && (d = d.replace(e, function(e, t, n) {
							return u = (n = n.toLowerCase()) == "x" ? 16 : n == "b" ? 2 : 8, !l || l == u ? t : e;
						}), l && (u = l, d = d.replace(t, "$1").replace(n, "0.$1")), s != d)) return new L(d, u);
						if (L.DEBUG) throw Error(o + "Not a" + (l ? " base " + l : "") + " number: " + s);
						a.s = null;
					}
					a.c = a.e = null;
				};
			}();
			function V(e, t, n, r) {
				var o, s, u, f, p, m, h, g = e.c, _ = d;
				if (g) {
					e: {
						for (o = 1, f = g[0]; f >= 10; f /= 10, o++);
						if (s = t - o, s < 0) s += l, u = t, p = g[m = 0], h = a(p / _[o - u - 1] % 10);
						else if (m = i((s + 1) / l), m >= g.length) {
							if (r) {
								for (; g.length <= m; g.push(0));
								p = h = 0, o = 1, s %= l, u = s - l + 1;
							} else break e;
						} else {
							for (p = f = g[m], o = 1; f >= 10; f /= 10, o++);
							s %= l, u = s - l + o, h = u < 0 ? 0 : a(p / _[o - u - 1] % 10);
						}
						if (r = r || t < 0 || g[m + 1] != null || (u < 0 ? p : p % _[o - u - 1]), r = n < 4 ? (h || r) && (n == 0 || n == (e.s < 0 ? 3 : 2)) : h > 5 || h == 5 && (n == 4 || r || n == 6 && (s > 0 ? u > 0 ? p / _[o - u] : 0 : g[m - 1]) % 10 & 1 || n == (e.s < 0 ? 8 : 7)), t < 1 || !g[0]) return g.length = 0, r ? (t -= e.e + 1, g[0] = _[(l - t % l) % l], e.e = -t || 0) : g[0] = e.e = 0, e;
						if (s == 0 ? (g.length = m, f = 1, m--) : (g.length = m + 1, f = _[l - s], g[m] = u > 0 ? a(p / _[o - u] % _[u]) * f : 0), r) for (;;) if (m == 0) {
							for (s = 1, u = g[0]; u >= 10; u /= 10, s++);
							for (u = g[0] += f, f = 1; u >= 10; u /= 10, f++);
							s != f && (e.e++, g[0] == c && (g[0] = 1));
							break;
						} else {
							if (g[m] += f, g[m] != c) break;
							g[m--] = 0, f = 1;
						}
						for (s = g.length; g[--s] === 0; g.pop());
					}
					e.e > A ? e.c = e.e = null : e.e < k && (e.c = [e.e = 0]);
				}
				return e;
			}
			function H(e) {
				var t, n = e.e;
				return n === null ? e.toString() : (t = g(e.c), t = n <= D || n >= O ? b(t, n) : x(t, n, "0"), e.s < 0 ? "-" + t : t);
			}
			return C.absoluteValue = C.abs = function() {
				var e = new L(this);
				return e.s < 0 && (e.s = 1), e;
			}, C.comparedTo = function(e, t) {
				return _(this, new L(e, t));
			}, C.decimalPlaces = C.dp = function(e, t) {
				var n, r, i, a = this;
				if (e != null) return v(e, 0, p), t == null ? t = E : v(t, 0, 8), V(new L(a), e + a.e + 1, t);
				if (!(n = a.c)) return null;
				if (r = ((i = n.length - 1) - h(this.e / l)) * l, i = n[i]) for (; i % 10 == 0; i /= 10, r--);
				return r < 0 && (r = 0), r;
			}, C.dividedBy = C.div = function(e, n) {
				return t(this, new L(e, n), T, E);
			}, C.dividedToIntegerBy = C.idiv = function(e, n) {
				return t(this, new L(e, n), 0, 1);
			}, C.exponentiatedBy = C.pow = function(e, t) {
				var n, r, s, c, u, d, f, p, m, h = this;
				if (e = new L(e), e.c && !e.isInteger()) throw Error(o + "Exponent not an integer: " + H(e));
				if (t != null && (t = new L(t)), d = e.e > 14, !h.c || !h.c[0] || h.c[0] == 1 && !h.e && h.c.length == 1 || !e.c || !e.c[0]) return m = new L((+H(h)) ** (d ? e.s * (2 - y(e)) : +H(e))), t ? m.mod(t) : m;
				if (f = e.s < 0, t) {
					if (t.c ? !t.c[0] : !t.s) return new L(NaN);
					r = !f && h.isInteger() && t.isInteger(), r && (h = h.mod(t));
				} else {
					if (e.e > 9 && (h.e > 0 || h.e < -1 || (h.e == 0 ? h.c[0] > 1 || d && h.c[1] >= 24e7 : h.c[0] < 8e13 || d && h.c[0] <= 9999975e7))) return c = h.s < 0 && y(e) ? -0 : 0, h.e > -1 && (c = 1 / c), new L(f ? 1 / c : c);
					N && (c = i(N / l + 2));
				}
				for (d ? (n = new L(.5), f && (e.s = 1), p = y(e)) : (s = Math.abs(+H(e)), p = s % 2), m = new L(w);;) {
					if (p) {
						if (m = m.times(h), !m.c) break;
						c ? m.c.length > c && (m.c.length = c) : r && (m = m.mod(t));
					}
					if (s) {
						if (s = a(s / 2), s === 0) break;
						p = s % 2;
					} else if (e = e.times(n), V(e, e.e + 1, 1), e.e > 14) p = y(e);
					else {
						if (s = +H(e), s === 0) break;
						p = s % 2;
					}
					h = h.times(h), c ? h.c && h.c.length > c && (h.c.length = c) : r && (h = h.mod(t));
				}
				return r ? m : (f && (m = w.div(m)), t ? m.mod(t) : c ? V(m, N, E, u) : m);
			}, C.integerValue = function(e) {
				var t = new L(this);
				return e == null ? e = E : v(e, 0, 8), V(t, t.e + 1, e);
			}, C.isEqualTo = C.eq = function(e, t) {
				return _(this, new L(e, t)) === 0;
			}, C.isFinite = function() {
				return !!this.c;
			}, C.isGreaterThan = C.gt = function(e, t) {
				return _(this, new L(e, t)) > 0;
			}, C.isGreaterThanOrEqualTo = C.gte = function(e, t) {
				return (t = _(this, new L(e, t))) === 1 || t === 0;
			}, C.isInteger = function() {
				return !!this.c && h(this.e / l) > this.c.length - 2;
			}, C.isLessThan = C.lt = function(e, t) {
				return _(this, new L(e, t)) < 0;
			}, C.isLessThanOrEqualTo = C.lte = function(e, t) {
				return (t = _(this, new L(e, t))) === -1 || t === 0;
			}, C.isNaN = function() {
				return !this.s;
			}, C.isNegative = function() {
				return this.s < 0;
			}, C.isPositive = function() {
				return this.s > 0;
			}, C.isZero = function() {
				return !!this.c && this.c[0] == 0;
			}, C.minus = function(e, t) {
				var n, r, i, a, o = this, s = o.s;
				if (e = new L(e, t), t = e.s, !s || !t) return new L(NaN);
				if (s != t) return e.s = -t, o.plus(e);
				var u = o.e / l, d = e.e / l, f = o.c, p = e.c;
				if (!u || !d) {
					if (!f || !p) return f ? (e.s = -t, e) : new L(p ? o : NaN);
					if (!f[0] || !p[0]) return p[0] ? (e.s = -t, e) : new L(f[0] ? o : E == 3 ? -0 : 0);
				}
				if (u = h(u), d = h(d), f = f.slice(), s = u - d) {
					for ((a = s < 0) ? (s = -s, i = f) : (d = u, i = p), i.reverse(), t = s; t--; i.push(0));
					i.reverse();
				} else for (r = (a = (s = f.length) < (t = p.length)) ? s : t, s = t = 0; t < r; t++) if (f[t] != p[t]) {
					a = f[t] < p[t];
					break;
				}
				if (a && (i = f, f = p, p = i, e.s = -e.s), t = (r = p.length) - (n = f.length), t > 0) for (; t--; f[n++] = 0);
				for (t = c - 1; r > s;) {
					if (f[--r] < p[r]) {
						for (n = r; n && !f[--n]; f[n] = t);
						--f[n], f[r] += c;
					}
					f[r] -= p[r];
				}
				for (; f[0] == 0; f.splice(0, 1), --d);
				return f[0] ? B(e, f, d) : (e.s = E == 3 ? -1 : 1, e.c = [e.e = 0], e);
			}, C.modulo = C.mod = function(e, n) {
				var r, i, a = this;
				return e = new L(e, n), !a.c || !e.s || e.c && !e.c[0] ? new L(NaN) : !e.c || a.c && !a.c[0] ? new L(a) : (M == 9 ? (i = e.s, e.s = 1, r = t(a, e, 0, 3), e.s = i, r.s *= i) : r = t(a, e, 0, M), e = a.minus(r.times(e)), !e.c[0] && M == 1 && (e.s = a.s), e);
			}, C.multipliedBy = C.times = function(e, t) {
				var n, r, i, a, o, s, u, d, p, m, g, _, v, y, b, x = this, S = x.c, C = (e = new L(e, t)).c;
				if (!S || !C || !S[0] || !C[0]) return !x.s || !e.s || S && !S[0] && !C || C && !C[0] && !S ? e.c = e.e = e.s = null : (e.s *= x.s, !S || !C ? e.c = e.e = null : (e.c = [0], e.e = 0)), e;
				for (r = h(x.e / l) + h(e.e / l), e.s *= x.s, u = S.length, m = C.length, u < m && (v = S, S = C, C = v, i = u, u = m, m = i), i = u + m, v = []; i--; v.push(0));
				for (y = c, b = f, i = m; --i >= 0;) {
					for (n = 0, g = C[i] % b, _ = C[i] / b | 0, o = u, a = i + o; a > i;) d = S[--o] % b, p = S[o] / b | 0, s = _ * d + p * g, d = g * d + s % b * b + v[a] + n, n = (d / y | 0) + (s / b | 0) + _ * p, v[a--] = d % y;
					v[a] = n;
				}
				return n ? ++r : v.splice(0, 1), B(e, v, r);
			}, C.negated = function() {
				var e = new L(this);
				return e.s = -e.s || null, e;
			}, C.plus = function(e, t) {
				var n, r = this, i = r.s;
				if (e = new L(e, t), t = e.s, !i || !t) return new L(NaN);
				if (i != t) return e.s = -t, r.minus(e);
				var a = r.e / l, o = e.e / l, s = r.c, u = e.c;
				if (!a || !o) {
					if (!s || !u) return new L(i / 0);
					if (!s[0] || !u[0]) return u[0] ? e : new L(s[0] ? r : i * 0);
				}
				if (a = h(a), o = h(o), s = s.slice(), i = a - o) {
					for (i > 0 ? (o = a, n = u) : (i = -i, n = s), n.reverse(); i--; n.push(0));
					n.reverse();
				}
				for (i = s.length, t = u.length, i - t < 0 && (n = u, u = s, s = n, t = i), i = 0; t;) i = (s[--t] = s[t] + u[t] + i) / c | 0, s[t] = c === s[t] ? 0 : s[t] % c;
				return i && (s = [i].concat(s), ++o), B(e, s, o);
			}, C.precision = C.sd = function(e, t) {
				var n, r, i, a = this;
				if (e != null && e !== !!e) return v(e, 1, p), t == null ? t = E : v(t, 0, 8), V(new L(a), e, t);
				if (!(n = a.c)) return null;
				if (i = n.length - 1, r = i * l + 1, i = n[i]) {
					for (; i % 10 == 0; i /= 10, r--);
					for (i = n[0]; i >= 10; i /= 10, r++);
				}
				return e && a.e + 1 > r && (r = a.e + 1), r;
			}, C.shiftedBy = function(e) {
				return v(e, -u, u), this.times("1e" + e);
			}, C.squareRoot = C.sqrt = function() {
				var e, n, r, i, a, o = this, s = o.c, c = o.s, l = o.e, u = T + 4, d = new L("0.5");
				if (c !== 1 || !s || !s[0]) return new L(!c || c < 0 && (!s || s[0]) ? NaN : s ? o : 1 / 0);
				if (c = Math.sqrt(+H(o)), c == 0 || c == 1 / 0 ? (n = g(s), (n.length + l) % 2 == 0 && (n += "0"), c = Math.sqrt(+n), l = h((l + 1) / 2) - (l < 0 || l % 2), c == 1 / 0 ? n = "5e" + l : (n = c.toExponential(), n = n.slice(0, n.indexOf("e") + 1) + l), r = new L(n)) : r = new L(c + ""), r.c[0]) {
					for (l = r.e, c = l + u, c < 3 && (c = 0);;) if (a = r, r = d.times(a.plus(t(o, a, u, 1))), g(a.c).slice(0, c) === (n = g(r.c)).slice(0, c)) {
						if (r.e < l && --c, n = n.slice(c - 3, c + 1), n == "9999" || !i && n == "4999") {
							if (!i && (V(a, a.e + T + 2, 0), a.times(a).eq(o))) {
								r = a;
								break;
							}
							u += 4, c += 4, i = 1;
						} else {
							(!+n || !+n.slice(1) && n.charAt(0) == "5") && (V(r, r.e + T + 2, 1), e = !r.times(r).eq(o));
							break;
						}
					}
				}
				return V(r, r.e + T + 1, E, e);
			}, C.toExponential = function(e, t) {
				return e != null && (v(e, 0, p), e++), R(this, e, t, 1);
			}, C.toFixed = function(e, t) {
				return e != null && (v(e, 0, p), e = e + this.e + 1), R(this, e, t);
			}, C.toFormat = function(e, t, n) {
				var r, i = this;
				if (n == null) e != null && t && typeof t == "object" ? (n = t, t = null) : e && typeof e == "object" ? (n = e, e = t = null) : n = P;
				else if (typeof n != "object") throw Error(o + "Argument not an object: " + n);
				if (r = i.toFixed(e, t), i.c) {
					var a, s = r.split("."), c = +n.groupSize, l = +n.secondaryGroupSize, u = n.groupSeparator || "", d = s[0], f = s[1], p = i.s < 0, m = p ? d.slice(1) : d, h = m.length;
					if (l && (a = c, c = l, l = a, h -= a), c > 0 && h > 0) {
						for (a = h % c || c, d = m.substr(0, a); a < h; a += c) d += u + m.substr(a, c);
						l > 0 && (d += u + m.slice(a)), p && (d = "-" + d);
					}
					r = f ? d + (n.decimalSeparator || "") + ((l = +n.fractionGroupSize) ? f.replace(RegExp("\\d{" + l + "}\\B", "g"), "$&" + (n.fractionGroupSeparator || "")) : f) : d;
				}
				return (n.prefix || "") + r + (n.suffix || "");
			}, C.toFraction = function(e) {
				var n, r, i, a, s, c, u, f, p, m, h, _, v = this, y = v.c;
				if (e != null && (u = new L(e), !u.isInteger() && (u.c || u.s !== 1) || u.lt(w))) throw Error(o + "Argument " + (u.isInteger() ? "out of range: " : "not an integer: ") + H(u));
				if (!y) return new L(v);
				for (n = new L(w), p = r = new L(w), i = f = new L(w), _ = g(y), s = n.e = _.length - v.e - 1, n.c[0] = d[(c = s % l) < 0 ? l + c : c], e = !e || u.comparedTo(n) > 0 ? s > 0 ? n : p : u, c = A, A = 1 / 0, u = new L(_), f.c[0] = 0; m = t(u, n, 0, 1), a = r.plus(m.times(i)), a.comparedTo(e) != 1;) r = i, i = a, p = f.plus(m.times(a = p)), f = a, n = u.minus(m.times(a = n)), u = a;
				return a = t(e.minus(r), i, 0, 1), f = f.plus(a.times(p)), r = r.plus(a.times(i)), f.s = p.s = v.s, s *= 2, h = t(p, i, s, E).minus(v).abs().comparedTo(t(f, r, s, E).minus(v).abs()) < 1 ? [p, i] : [f, r], A = c, h;
			}, C.toNumber = function() {
				return +H(this);
			}, C.toPrecision = function(e, t) {
				return e != null && v(e, 1, p), R(this, e, t, 2);
			}, C.toString = function(e) {
				var t, r = this, i = r.s, a = r.e;
				return a === null ? i ? (t = "Infinity", i < 0 && (t = "-" + t)) : t = "NaN" : (e == null ? t = a <= D || a >= O ? b(g(r.c), a) : x(g(r.c), a, "0") : e === 10 && I ? (r = V(new L(r), T + a + 1, E), t = x(g(r.c), r.e, "0")) : (v(e, 2, F.length, "Base"), t = n(x(g(r.c), a, "0"), 10, e, i, !0)), i < 0 && r.c[0] && (t = "-" + t)), t;
			}, C.valueOf = C.toJSON = function() {
				return H(this);
			}, C._isBigNumber = !0, e != null && L.set(e), L;
		}
		function h(e) {
			var t = e | 0;
			return e > 0 || e === t ? t : t - 1;
		}
		function g(e) {
			for (var t, n, r = 1, i = e.length, a = e[0] + ""; r < i;) {
				for (t = e[r++] + "", n = l - t.length; n--; t = "0" + t);
				a += t;
			}
			for (i = a.length; a.charCodeAt(--i) === 48;);
			return a.slice(0, i + 1 || 1);
		}
		function _(e, t) {
			var n, r, i = e.c, a = t.c, o = e.s, s = t.s, c = e.e, l = t.e;
			if (!o || !s) return null;
			if (n = i && !i[0], r = a && !a[0], n || r) return n ? r ? 0 : -s : o;
			if (o != s) return o;
			if (n = o < 0, r = c == l, !i || !a) return r ? 0 : !i ^ n ? 1 : -1;
			if (!r) return c > l ^ n ? 1 : -1;
			for (s = (c = i.length) < (l = a.length) ? c : l, o = 0; o < s; o++) if (i[o] != a[o]) return i[o] > a[o] ^ n ? 1 : -1;
			return c == l ? 0 : c > l ^ n ? 1 : -1;
		}
		function v(e, t, n, r) {
			if (e < t || e > n || e !== a(e)) throw Error(o + (r || "Argument") + (typeof e == "number" ? e < t || e > n ? " out of range: " : " not an integer: " : " not a primitive number: ") + String(e));
		}
		function y(e) {
			var t = e.c.length - 1;
			return h(e.e / l) == t && e.c[t] % 2 != 0;
		}
		function b(e, t) {
			return (e.length > 1 ? e.charAt(0) + "." + e.slice(1) : e) + (t < 0 ? "e" : "e+") + t;
		}
		function x(e, t, n) {
			var r, i;
			if (t < 0) {
				for (i = n + "."; ++t; i += n);
				e = i + e;
			} else if (r = e.length, ++t > r) {
				for (i = n, t -= r; --t; i += n);
				e += i;
			} else t < r && (e = e.slice(0, t) + "." + e.slice(t));
			return e;
		}
		n = m(), n.default = n.BigNumber = n, t.exports ? t.exports = n : (e ||= typeof self < "u" && self ? self : window, e.BigNumber = n);
	})(e);
})(P);
var F = P.exports, I = A(), L = u(), R = D, z = F, B = {
	trillion: 10 ** 12,
	billion: 10 ** 9,
	million: 10 ** 6,
	thousand: 1e3
}, V = {
	totalLength: 0,
	characteristic: 0,
	forceAverage: !1,
	average: !1,
	mantissa: -1,
	optionalMantissa: !0,
	thousandSeparated: !1,
	spaceSeparated: !1,
	negative: "sign",
	forceSign: !1,
	roundingFunction: Math.round,
	spaceSeparatedAbbreviation: !1
}, { binarySuffixes: H, decimalSuffixes: U } = I.currentBytes(), W = {
	general: {
		scale: 1024,
		suffixes: U
	},
	binary: {
		scale: 1024,
		suffixes: H
	},
	decimal: {
		scale: 1e3,
		suffixes: U
	}
};
function ee(e, t = {}, n) {
	if (typeof t == "string" && (t = R.parseFormat(t)), !L.validateFormat(t)) return "ERROR: invalid format";
	let r = t.prefix || "", i = t.postfix || "", a = te(e, t, n);
	return a = be(a, r), a = xe(a, i), a;
}
function te(e, t, n) {
	switch (t.output) {
		case "currency": return t = J(t, I.currentCurrencyDefaultFormat()), le(e, t, I);
		case "percent": return t = J(t, I.currentPercentageDefaultFormat()), ce(e, t, I, n);
		case "byte": return t = J(t, I.currentByteDefaultFormat()), ae(e, t, I, n);
		case "time": return t = J(t, I.currentTimeDefaultFormat()), se(e);
		case "ordinal": return t = J(t, I.currentOrdinalDefaultFormat()), oe(e, t, I);
		default: return q({
			instance: e,
			providedFormat: t
		});
	}
}
function ne(e) {
	let t = W.decimal;
	return G(e._value, t.suffixes, t.scale).suffix;
}
function re(e) {
	let t = W.binary;
	return G(e._value, t.suffixes, t.scale).suffix;
}
function ie(e) {
	let t = W.general;
	return G(e._value, t.suffixes, t.scale).suffix;
}
function G(e, t, n) {
	let r = t[0], i = Math.abs(e);
	if (i >= n) {
		for (let a = 1; a < t.length; ++a) {
			let o = n ** +a, s = n ** +(a + 1);
			if (i >= o && i < s) {
				r = t[a], e /= o;
				break;
			}
		}
		r === t[0] && (e /= n ** (t.length - 1), r = t[t.length - 1]);
	}
	return {
		value: e,
		suffix: r
	};
}
function ae(e, t, n, r) {
	let i = t.base || "binary", a = Object.assign({}, V, t), { binarySuffixes: o, decimalSuffixes: s } = n.currentBytes(), c = {
		general: {
			scale: 1024,
			suffixes: s || U,
			marker: "bd"
		},
		binary: {
			scale: 1024,
			suffixes: o || H,
			marker: "b"
		},
		decimal: {
			scale: 1e3,
			suffixes: s || U,
			marker: "d"
		}
	}[i], { value: l, suffix: u } = G(e._value, c.suffixes, c.scale);
	return `${q({
		instance: r(l),
		providedFormat: t,
		state: n,
		defaults: n.currentByteDefaultFormat()
	})}${a.spaceSeparated ? " " : ""}${u}`;
}
function oe(e, t, n) {
	let r = n.currentOrdinal(), i = Object.assign({}, V, t), a = q({
		instance: e,
		providedFormat: t,
		state: n
	}), o = r(e._value);
	return `${a}${i.spaceSeparated ? " " : ""}${o}`;
}
function se(e) {
	let t = Math.floor(e._value / 60 / 60), n = Math.floor((e._value - t * 60 * 60) / 60), r = Math.round(e._value - t * 60 * 60 - n * 60);
	return `${t}:${n < 10 ? "0" : ""}${n}:${r < 10 ? "0" : ""}${r}`;
}
function ce(e, t, n, r) {
	let i = t.prefixSymbol, a = q({
		instance: r(e._value * 100),
		providedFormat: t,
		state: n
	}), o = Object.assign({}, V, t);
	return i ? `%${o.spaceSeparated ? " " : ""}${a}` : `${a}${o.spaceSeparated ? " " : ""}%`;
}
function le(e, t, n) {
	let r = n.currentCurrency(), i = Object.assign({}, t), a = Object.assign({}, V, i), o, s = "", c = !!a.totalLength || !!a.forceAverage || a.average, l = i.currencyPosition || r.position, u = i.currencySymbol || r.symbol, d = a.spaceSeparatedCurrency === void 0 ? a.spaceSeparated : a.spaceSeparatedCurrency;
	i.lowPrecision === void 0 && (i.lowPrecision = !1), d && (s = " "), l === "infix" && (o = s + u + s);
	let f = q({
		instance: e,
		providedFormat: i,
		state: n,
		decimalSeparator: o
	});
	return l === "prefix" && (f = e._value < 0 && a.negative === "sign" ? `-${s}${u}${f.slice(1)}` : e._value > 0 && a.forceSign ? `+${s}${u}${f.slice(1)}` : u + s + f), (!l || l === "postfix") && (s = !a.spaceSeparatedAbbreviation && c ? "" : s, f = f + s + u), f;
}
function ue({ value: e, forceAverage: t, lowPrecision: n = !0, abbreviations: r, spaceSeparated: i = !1, totalLength: a = 0, roundingFunction: o = Math.round }) {
	let s = "", c = Math.abs(e), l = -1;
	if (t && r[t] && B[t] ? (s = r[t], e /= B[t]) : c >= B.trillion || n && o(c / B.trillion) === 1 ? (s = r.trillion, e /= B.trillion) : c < B.trillion && c >= B.billion || n && o(c / B.billion) === 1 ? (s = r.billion, e /= B.billion) : c < B.billion && c >= B.million || n && o(c / B.million) === 1 ? (s = r.million, e /= B.million) : (c < B.million && c >= B.thousand || n && o(c / B.thousand) === 1) && (s = r.thousand, e /= B.thousand), s &&= (i ? " " : "") + s, a) {
		let t = e < 0, n = e.toString().split(".")[0], r = t ? n.length - 1 : n.length;
		l = Math.max(a - r, 0);
	}
	return {
		value: e,
		abbreviation: s,
		mantissaPrecision: l
	};
}
function de({ value: e, characteristicPrecision: t }) {
	let [n, r] = e.toExponential().split("e"), i = +n;
	return t && 1 < t && (i *= 10 ** (t - 1), r = +r - (t - 1), r = r >= 0 ? `+${r}` : r), {
		value: i,
		abbreviation: `e${r}`
	};
}
function K(e) {
	let t = "";
	for (let n = 0; n < e; n++) t += "0";
	return t;
}
function fe(e, t) {
	let n = e.toString(), [r, i] = n.split("e"), [a, o = ""] = r.split(".");
	if (+i > 0) n = a + o + K(i - o.length);
	else {
		let e = ".";
		e = +a < 0 ? `-0${e}` : `0${e}`;
		let r = (K(-i - 1) + Math.abs(a) + o).substr(0, t);
		r.length < t && (r += K(t - r.length)), n = e + r;
	}
	return +i > 0 && t > 0 && (n += `.${K(t)}`), n;
}
function pe(e, t, n = Math.round) {
	return e.toString().indexOf("e") === -1 ? new z(n(+`${e}e+${t}`) / 10 ** t).toFixed(t) : fe(e, t);
}
function me(e, t, n, r, i, a) {
	if (r === -1) return e;
	let o = pe(t, r, a), [s, c = ""] = o.toString().split(".");
	if (c.match(/^0+$/) && (n || i)) return s;
	let l = c.match(/0+$/);
	return i && l ? `${s}.${c.toString().slice(0, l.index)}` : o.toString();
}
function he(e, t, n, r) {
	let i = e, [a, o] = i.toString().split(".");
	if (a.match(/^-?0$/) && n) return o ? `${a.replace("0", "")}.${o}` : a.replace("0", "");
	let s = t < 0 && a.indexOf("-") === 0;
	if (s && (a = a.slice(1), i = i.slice(1)), a.length < r) {
		let e = r - a.length;
		for (let t = 0; t < e; t++) i = `0${i}`;
	}
	return s && (i = `-${i}`), i.toString();
}
function ge(e, t) {
	let n = [], r = 0;
	for (let i = e; i > 0; i--) r === t && (n.unshift(i), r = 0), r++;
	return n;
}
function _e(e, t, n, r, i) {
	let a = r.currentDelimiters(), o = a.thousands;
	i ||= a.decimal;
	let s = a.thousandsSize || 3, c = e.toString(), l = c.split(".")[0], u = c.split(".")[1], d = t < 0 && l.indexOf("-") === 0;
	return n && (d && (l = l.slice(1)), ge(l.length, s).forEach((e, t) => {
		l = l.slice(0, e + t) + o + l.slice(e + t);
	}), d && (l = `-${l}`)), c = u ? l + i + u : l, c;
}
function ve(e, t) {
	return e + t;
}
function ye(e, t, n) {
	return t === 0 ? e : +e == 0 ? e.replace("-", "") : t > 0 ? `+${e}` : n === "sign" ? e : `(${e.replace("-", "")})`;
}
function be(e, t) {
	return t + e;
}
function xe(e, t) {
	return e + t;
}
function q({ instance: e, providedFormat: t, state: n = I, decimalSeparator: r, defaults: i = n.currentDefaults() }) {
	let a = e._value;
	if (a === 0 && n.hasZeroFormat()) return n.getZeroFormat();
	if (!isFinite(a)) return a.toString();
	let o = Object.assign({}, V, i, t), s = o.totalLength, c = s ? 0 : o.characteristic, l = o.optionalCharacteristic, u = o.forceAverage, d = o.lowPrecision, f = !!s || !!u || o.average, p = s ? -1 : f && t.mantissa === void 0 ? 0 : o.mantissa, m = s ? !1 : t.optionalMantissa === void 0 ? p === -1 : o.optionalMantissa, h = o.trimMantissa, g = o.thousandSeparated, _ = o.spaceSeparated, v = o.negative, y = o.forceSign, b = o.exponential, x = o.roundingFunction, S = "";
	if (f) {
		let e = ue({
			value: a,
			forceAverage: u,
			lowPrecision: d,
			abbreviations: n.currentAbbreviations(),
			spaceSeparated: _,
			roundingFunction: x,
			totalLength: s
		});
		a = e.value, S += e.abbreviation, s && (p = e.mantissaPrecision);
	}
	if (b) {
		let e = de({
			value: a,
			characteristicPrecision: c
		});
		a = e.value, S = e.abbreviation + S;
	}
	let C = me(a.toString(), a, m, p, h, x);
	return C = he(C, a, l, c), C = _e(C, a, g, n, r), (f || b) && (C = ve(C, S)), (y || a < 0) && (C = ye(C, a, v)), C;
}
function J(e, t) {
	if (!e) return t;
	let n = Object.keys(e);
	return n.length === 1 && n[0] === "output" ? t : e;
}
var Se = (e) => ({
	format: (...t) => ee(...t, e),
	getByteUnit: (...t) => ie(...t, e),
	getBinaryByteUnit: (...t) => re(...t, e),
	getDecimalByteUnit: (...t) => ne(...t, e),
	formatOrDefault: J
}), Y = F;
function Ce(e, t, n) {
	let r = new Y(e._value), i = t;
	return n.isNumbro(t) && (i = t._value), i = new Y(i), e._value = r.plus(i).toNumber(), e;
}
function we(e, t, n) {
	let r = new Y(e._value), i = t;
	return n.isNumbro(t) && (i = t._value), i = new Y(i), e._value = r.minus(i).toNumber(), e;
}
function Te(e, t, n) {
	let r = new Y(e._value), i = t;
	return n.isNumbro(t) && (i = t._value), i = new Y(i), e._value = r.times(i).toNumber(), e;
}
function Ee(e, t, n) {
	let r = new Y(e._value), i = t;
	return n.isNumbro(t) && (i = t._value), i = new Y(i), e._value = r.dividedBy(i).toNumber(), e;
}
function De(e, t, n) {
	let r = t;
	return n.isNumbro(t) && (r = t._value), e._value = r, e;
}
function Oe(e, t, n) {
	let r = n(e._value);
	return we(r, t, n), Math.abs(r._value);
}
var ke = (e) => ({
	add: (t, n) => Ce(t, n, e),
	subtract: (t, n) => we(t, n, e),
	multiply: (t, n) => Te(t, n, e),
	divide: (t, n) => Ee(t, n, e),
	set: (t, n) => De(t, n, e),
	difference: (t, n) => Oe(t, n, e),
	BigNumber: Y
}), Ae = "2.5.0", X = A(), je = u(), Me = N($), Ne = s(), Z = Se($), Q = ke($), Pe = D, Fe = class {
	constructor(e) {
		this._value = e;
	}
	clone() {
		return $(this._value);
	}
	format(e = {}) {
		return Z.format(this, e);
	}
	formatCurrency(e) {
		return typeof e == "string" && (e = Pe.parseFormat(e)), e = Z.formatOrDefault(e, X.currentCurrencyDefaultFormat()), e.output = "currency", Z.format(this, e);
	}
	formatTime(e = {}) {
		return e.output = "time", Z.format(this, e);
	}
	binaryByteUnits() {
		return Z.getBinaryByteUnit(this);
	}
	decimalByteUnits() {
		return Z.getDecimalByteUnit(this);
	}
	byteUnits() {
		return Z.getByteUnit(this);
	}
	difference(e) {
		return Q.difference(this, e);
	}
	add(e) {
		return Q.add(this, e);
	}
	subtract(e) {
		return Q.subtract(this, e);
	}
	multiply(e) {
		return Q.multiply(this, e);
	}
	divide(e) {
		return Q.divide(this, e);
	}
	set(e) {
		return Q.set(this, Ie(e));
	}
	value() {
		return this._value;
	}
	valueOf() {
		return this._value;
	}
};
function Ie(e) {
	let t = e;
	return $.isNumbro(e) ? t = e._value : typeof e == "string" ? t = $.unformat(e) : isNaN(e) && (t = NaN), t;
}
function $(e) {
	return new Fe(Ie(e));
}
$.version = Ae, $.isNumbro = function(e) {
	return e instanceof Fe;
}, $.language = X.currentLanguage, $.registerLanguage = X.registerLanguage, $.setLanguage = X.setLanguage, $.languages = X.languages, $.languageData = X.languageData, $.zeroFormat = X.setZeroFormat, $.defaultFormat = X.currentDefaults, $.setDefaults = X.setDefaults, $.defaultCurrencyFormat = X.currentCurrencyDefaultFormat, $.validate = je.validate, $.loadLanguagesInNode = Me.loadLanguagesInNode, $.unformat = Ne.unformat, $.BigNumber = Q.BigNumber;
var Le = /* @__PURE__ */ t($);
//#endregion
export { Le as t };

//# sourceMappingURL=numbro-CDdPhOTG-vF1UvoJy.js.map