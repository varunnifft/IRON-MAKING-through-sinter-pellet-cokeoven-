import { d as e } from "./linear-CJvvCWKw-rrRTERsA.js";
import { c as t } from "./transform-B2AI7qp--hg0kwf7R.js";
import { N as n, T as r, a7 as i, ai as a, aj as o, am as s, an as c, av as l, b6 as u, bB as d, bw as f, by as p, bz as m, c as h } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
//#region ../react/build/quadrantDiagram-AXDQQJYC-1i3l2RVr.js
var g = function() {
	var e = /* @__PURE__ */ h(function(e, t, n, r) {
		for (n ||= {}, r = e.length; r--; n[e[r]] = t);
		return n;
	}, "o"), t = [1, 3], n = [1, 4], r = [1, 5], i = [1, 6], a = [1, 7], o = [
		1,
		4,
		5,
		10,
		12,
		13,
		14,
		15,
		18,
		25,
		35,
		37,
		39,
		41,
		42,
		48,
		50,
		51,
		52,
		53,
		54,
		55,
		56,
		57,
		60,
		61,
		63,
		64,
		65,
		66,
		67
	], s = [
		1,
		4,
		5,
		10,
		12,
		13,
		14,
		15,
		18,
		25,
		28,
		35,
		37,
		39,
		41,
		42,
		48,
		50,
		51,
		52,
		53,
		54,
		55,
		56,
		57,
		60,
		61,
		63,
		64,
		65,
		66,
		67
	], c = [
		55,
		56,
		57
	], l = [2, 36], u = [1, 37], d = [1, 36], f = [1, 38], p = [1, 35], m = [1, 43], g = [1, 41], _ = [1, 45], v = [1, 14], y = [1, 23], b = [1, 18], x = [1, 19], S = [1, 20], C = [1, 21], w = [1, 22], T = [1, 24], E = [1, 25], D = [1, 26], O = [1, 27], k = [1, 28], A = [1, 29], j = [1, 32], M = [1, 33], N = [1, 34], P = [1, 39], F = [1, 40], I = [1, 42], L = [1, 44], R = [1, 63], z = [1, 62], B = [
		4,
		5,
		8,
		10,
		12,
		13,
		14,
		15,
		18,
		44,
		47,
		49,
		55,
		56,
		57,
		63,
		64,
		65,
		66,
		67
	], V = [1, 66], ee = [1, 67], te = [1, 68], ne = [1, 69], re = [1, 70], ie = [1, 71], ae = [1, 72], oe = [1, 73], se = [1, 74], ce = [1, 75], le = [1, 76], ue = [1, 77], H = [
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		12,
		13,
		14,
		15,
		18
	], U = [1, 91], W = [1, 92], G = [1, 93], K = [1, 100], q = [1, 94], J = [1, 97], Y = [1, 95], X = [1, 96], Z = [1, 98], Q = [1, 99], de = [1, 103], fe = [
		10,
		55,
		56,
		57
	], $ = [
		4,
		5,
		6,
		8,
		10,
		11,
		13,
		17,
		18,
		19,
		20,
		55,
		56,
		57
	], pe = {
		trace: /* @__PURE__ */ h(function() {}, "trace"),
		yy: {},
		symbols_: {
			error: 2,
			idStringToken: 3,
			ALPHA: 4,
			NUM: 5,
			NODE_STRING: 6,
			DOWN: 7,
			MINUS: 8,
			DEFAULT: 9,
			COMMA: 10,
			COLON: 11,
			AMP: 12,
			BRKT: 13,
			MULT: 14,
			UNICODE_TEXT: 15,
			styleComponent: 16,
			UNIT: 17,
			SPACE: 18,
			STYLE: 19,
			PCT: 20,
			idString: 21,
			style: 22,
			stylesOpt: 23,
			classDefStatement: 24,
			CLASSDEF: 25,
			start: 26,
			eol: 27,
			QUADRANT: 28,
			document: 29,
			line: 30,
			statement: 31,
			axisDetails: 32,
			quadrantDetails: 33,
			points: 34,
			title: 35,
			title_value: 36,
			acc_title: 37,
			acc_title_value: 38,
			acc_descr: 39,
			acc_descr_value: 40,
			acc_descr_multiline_value: 41,
			section: 42,
			text: 43,
			point_start: 44,
			point_x: 45,
			point_y: 46,
			class_name: 47,
			"X-AXIS": 48,
			"AXIS-TEXT-DELIMITER": 49,
			"Y-AXIS": 50,
			QUADRANT_1: 51,
			QUADRANT_2: 52,
			QUADRANT_3: 53,
			QUADRANT_4: 54,
			NEWLINE: 55,
			SEMI: 56,
			EOF: 57,
			alphaNumToken: 58,
			textNoTagsToken: 59,
			STR: 60,
			MD_STR: 61,
			alphaNum: 62,
			PUNCTUATION: 63,
			PLUS: 64,
			EQUALS: 65,
			DOT: 66,
			UNDERSCORE: 67,
			$accept: 0,
			$end: 1
		},
		terminals_: {
			2: "error",
			4: "ALPHA",
			5: "NUM",
			6: "NODE_STRING",
			7: "DOWN",
			8: "MINUS",
			9: "DEFAULT",
			10: "COMMA",
			11: "COLON",
			12: "AMP",
			13: "BRKT",
			14: "MULT",
			15: "UNICODE_TEXT",
			17: "UNIT",
			18: "SPACE",
			19: "STYLE",
			20: "PCT",
			25: "CLASSDEF",
			28: "QUADRANT",
			35: "title",
			36: "title_value",
			37: "acc_title",
			38: "acc_title_value",
			39: "acc_descr",
			40: "acc_descr_value",
			41: "acc_descr_multiline_value",
			42: "section",
			44: "point_start",
			45: "point_x",
			46: "point_y",
			47: "class_name",
			48: "X-AXIS",
			49: "AXIS-TEXT-DELIMITER",
			50: "Y-AXIS",
			51: "QUADRANT_1",
			52: "QUADRANT_2",
			53: "QUADRANT_3",
			54: "QUADRANT_4",
			55: "NEWLINE",
			56: "SEMI",
			57: "EOF",
			60: "STR",
			61: "MD_STR",
			63: "PUNCTUATION",
			64: "PLUS",
			65: "EQUALS",
			66: "DOT",
			67: "UNDERSCORE"
		},
		productions_: [
			0,
			[3, 1],
			[3, 1],
			[3, 1],
			[3, 1],
			[3, 1],
			[3, 1],
			[3, 1],
			[3, 1],
			[3, 1],
			[3, 1],
			[3, 1],
			[3, 1],
			[16, 1],
			[16, 1],
			[16, 1],
			[16, 1],
			[16, 1],
			[16, 1],
			[16, 1],
			[16, 1],
			[16, 1],
			[16, 1],
			[21, 1],
			[21, 2],
			[22, 1],
			[22, 2],
			[23, 1],
			[23, 3],
			[24, 5],
			[26, 2],
			[26, 2],
			[26, 2],
			[29, 0],
			[29, 2],
			[30, 2],
			[31, 0],
			[31, 1],
			[31, 2],
			[31, 1],
			[31, 1],
			[31, 1],
			[31, 2],
			[31, 2],
			[31, 2],
			[31, 1],
			[31, 1],
			[34, 4],
			[34, 5],
			[34, 5],
			[34, 6],
			[32, 4],
			[32, 3],
			[32, 2],
			[32, 4],
			[32, 3],
			[32, 2],
			[33, 2],
			[33, 2],
			[33, 2],
			[33, 2],
			[27, 1],
			[27, 1],
			[27, 1],
			[43, 1],
			[43, 2],
			[43, 1],
			[43, 1],
			[62, 1],
			[62, 2],
			[58, 1],
			[58, 1],
			[58, 1],
			[58, 1],
			[58, 1],
			[58, 1],
			[58, 1],
			[58, 1],
			[58, 1],
			[58, 1],
			[58, 1],
			[58, 1],
			[59, 1],
			[59, 1],
			[59, 1]
		],
		performAction: /* @__PURE__ */ h(function(e, t, n, r, i, a, o) {
			var s = a.length - 1;
			switch (i) {
				case 23:
					this.$ = a[s];
					break;
				case 24:
					this.$ = a[s - 1] + "" + a[s];
					break;
				case 26:
					this.$ = a[s - 1] + a[s];
					break;
				case 27:
					this.$ = [a[s].trim()];
					break;
				case 28:
					a[s - 2].push(a[s].trim()), this.$ = a[s - 2];
					break;
				case 29:
					this.$ = a[s - 4], r.addClass(a[s - 2], a[s]);
					break;
				case 37:
					this.$ = [];
					break;
				case 42:
					this.$ = a[s].trim(), r.setDiagramTitle(this.$);
					break;
				case 43:
					this.$ = a[s].trim(), r.setAccTitle(this.$);
					break;
				case 44:
				case 45:
					this.$ = a[s].trim(), r.setAccDescription(this.$);
					break;
				case 46:
					r.addSection(a[s].substr(8)), this.$ = a[s].substr(8);
					break;
				case 47:
					r.addPoint(a[s - 3], "", a[s - 1], a[s], []);
					break;
				case 48:
					r.addPoint(a[s - 4], a[s - 3], a[s - 1], a[s], []);
					break;
				case 49:
					r.addPoint(a[s - 4], "", a[s - 2], a[s - 1], a[s]);
					break;
				case 50:
					r.addPoint(a[s - 5], a[s - 4], a[s - 2], a[s - 1], a[s]);
					break;
				case 51:
					r.setXAxisLeftText(a[s - 2]), r.setXAxisRightText(a[s]);
					break;
				case 52:
					a[s - 1].text += " ⟶ ", r.setXAxisLeftText(a[s - 1]);
					break;
				case 53:
					r.setXAxisLeftText(a[s]);
					break;
				case 54:
					r.setYAxisBottomText(a[s - 2]), r.setYAxisTopText(a[s]);
					break;
				case 55:
					a[s - 1].text += " ⟶ ", r.setYAxisBottomText(a[s - 1]);
					break;
				case 56:
					r.setYAxisBottomText(a[s]);
					break;
				case 57:
					r.setQuadrant1Text(a[s]);
					break;
				case 58:
					r.setQuadrant2Text(a[s]);
					break;
				case 59:
					r.setQuadrant3Text(a[s]);
					break;
				case 60:
					r.setQuadrant4Text(a[s]);
					break;
				case 64:
					this.$ = {
						text: a[s],
						type: "text"
					};
					break;
				case 65:
					this.$ = {
						text: a[s - 1].text + "" + a[s],
						type: a[s - 1].type
					};
					break;
				case 66:
					this.$ = {
						text: a[s],
						type: "text"
					};
					break;
				case 67:
					this.$ = {
						text: a[s],
						type: "markdown"
					};
					break;
				case 68:
					this.$ = a[s];
					break;
				case 69: this.$ = a[s - 1] + "" + a[s];
			}
		}, "anonymous"),
		table: [
			{
				18: t,
				26: 1,
				27: 2,
				28: n,
				55: r,
				56: i,
				57: a
			},
			{ 1: [3] },
			{
				18: t,
				26: 8,
				27: 2,
				28: n,
				55: r,
				56: i,
				57: a
			},
			{
				18: t,
				26: 9,
				27: 2,
				28: n,
				55: r,
				56: i,
				57: a
			},
			e(o, [2, 33], { 29: 10 }),
			e(s, [2, 61]),
			e(s, [2, 62]),
			e(s, [2, 63]),
			{ 1: [2, 30] },
			{ 1: [2, 31] },
			e(c, l, {
				30: 11,
				31: 12,
				24: 13,
				32: 15,
				33: 16,
				34: 17,
				43: 30,
				58: 31,
				1: [2, 32],
				4: u,
				5: d,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				18: v,
				25: y,
				35: b,
				37: x,
				39: S,
				41: C,
				42: w,
				48: T,
				50: E,
				51: D,
				52: O,
				53: k,
				54: A,
				60: j,
				61: M,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			e(o, [2, 34]),
			{
				27: 46,
				55: r,
				56: i,
				57: a
			},
			e(c, [2, 37]),
			e(c, l, {
				24: 13,
				32: 15,
				33: 16,
				34: 17,
				43: 30,
				58: 31,
				31: 47,
				4: u,
				5: d,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				18: v,
				25: y,
				35: b,
				37: x,
				39: S,
				41: C,
				42: w,
				48: T,
				50: E,
				51: D,
				52: O,
				53: k,
				54: A,
				60: j,
				61: M,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			e(c, [2, 39]),
			e(c, [2, 40]),
			e(c, [2, 41]),
			{ 36: [1, 48] },
			{ 38: [1, 49] },
			{ 40: [1, 50] },
			e(c, [2, 45]),
			e(c, [2, 46]),
			{ 18: [1, 51] },
			{
				4: u,
				5: d,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				43: 52,
				58: 31,
				60: j,
				61: M,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			},
			{
				4: u,
				5: d,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				43: 53,
				58: 31,
				60: j,
				61: M,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			},
			{
				4: u,
				5: d,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				43: 54,
				58: 31,
				60: j,
				61: M,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			},
			{
				4: u,
				5: d,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				43: 55,
				58: 31,
				60: j,
				61: M,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			},
			{
				4: u,
				5: d,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				43: 56,
				58: 31,
				60: j,
				61: M,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			},
			{
				4: u,
				5: d,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				43: 57,
				58: 31,
				60: j,
				61: M,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			},
			{
				4: u,
				5: d,
				8: R,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				18: z,
				44: [1, 58],
				47: [1, 59],
				58: 61,
				59: 60,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			},
			e(B, [2, 64]),
			e(B, [2, 66]),
			e(B, [2, 67]),
			e(B, [2, 70]),
			e(B, [2, 71]),
			e(B, [2, 72]),
			e(B, [2, 73]),
			e(B, [2, 74]),
			e(B, [2, 75]),
			e(B, [2, 76]),
			e(B, [2, 77]),
			e(B, [2, 78]),
			e(B, [2, 79]),
			e(B, [2, 80]),
			e(B, [2, 81]),
			e(o, [2, 35]),
			e(c, [2, 38]),
			e(c, [2, 42]),
			e(c, [2, 43]),
			e(c, [2, 44]),
			{
				3: 65,
				4: V,
				5: ee,
				6: te,
				7: ne,
				8: re,
				9: ie,
				10: ae,
				11: oe,
				12: se,
				13: ce,
				14: le,
				15: ue,
				21: 64
			},
			e(c, [2, 53], {
				59: 60,
				58: 61,
				4: u,
				5: d,
				8: R,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				18: z,
				49: [1, 78],
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			e(c, [2, 56], {
				59: 60,
				58: 61,
				4: u,
				5: d,
				8: R,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				18: z,
				49: [1, 79],
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			e(c, [2, 57], {
				59: 60,
				58: 61,
				4: u,
				5: d,
				8: R,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				18: z,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			e(c, [2, 58], {
				59: 60,
				58: 61,
				4: u,
				5: d,
				8: R,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				18: z,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			e(c, [2, 59], {
				59: 60,
				58: 61,
				4: u,
				5: d,
				8: R,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				18: z,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			e(c, [2, 60], {
				59: 60,
				58: 61,
				4: u,
				5: d,
				8: R,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				18: z,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			{ 45: [1, 80] },
			{ 44: [1, 81] },
			e(B, [2, 65]),
			e(B, [2, 82]),
			e(B, [2, 83]),
			e(B, [2, 84]),
			{
				3: 83,
				4: V,
				5: ee,
				6: te,
				7: ne,
				8: re,
				9: ie,
				10: ae,
				11: oe,
				12: se,
				13: ce,
				14: le,
				15: ue,
				18: [1, 82]
			},
			e(H, [2, 23]),
			e(H, [2, 1]),
			e(H, [2, 2]),
			e(H, [2, 3]),
			e(H, [2, 4]),
			e(H, [2, 5]),
			e(H, [2, 6]),
			e(H, [2, 7]),
			e(H, [2, 8]),
			e(H, [2, 9]),
			e(H, [2, 10]),
			e(H, [2, 11]),
			e(H, [2, 12]),
			e(c, [2, 52], {
				58: 31,
				43: 84,
				4: u,
				5: d,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				60: j,
				61: M,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			e(c, [2, 55], {
				58: 31,
				43: 85,
				4: u,
				5: d,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				60: j,
				61: M,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			{ 46: [1, 86] },
			{ 45: [1, 87] },
			{
				4: U,
				5: W,
				6: G,
				8: K,
				11: q,
				13: J,
				16: 90,
				17: Y,
				18: X,
				19: Z,
				20: Q,
				22: 89,
				23: 88
			},
			e(H, [2, 24]),
			e(c, [2, 51], {
				59: 60,
				58: 61,
				4: u,
				5: d,
				8: R,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				18: z,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			e(c, [2, 54], {
				59: 60,
				58: 61,
				4: u,
				5: d,
				8: R,
				10: f,
				12: p,
				13: m,
				14: g,
				15: _,
				18: z,
				63: N,
				64: P,
				65: F,
				66: I,
				67: L
			}),
			e(c, [2, 47], {
				22: 89,
				16: 90,
				23: 101,
				4: U,
				5: W,
				6: G,
				8: K,
				11: q,
				13: J,
				17: Y,
				18: X,
				19: Z,
				20: Q
			}),
			{ 46: [1, 102] },
			e(c, [2, 29], { 10: de }),
			e(fe, [2, 27], {
				16: 104,
				4: U,
				5: W,
				6: G,
				8: K,
				11: q,
				13: J,
				17: Y,
				18: X,
				19: Z,
				20: Q
			}),
			e($, [2, 25]),
			e($, [2, 13]),
			e($, [2, 14]),
			e($, [2, 15]),
			e($, [2, 16]),
			e($, [2, 17]),
			e($, [2, 18]),
			e($, [2, 19]),
			e($, [2, 20]),
			e($, [2, 21]),
			e($, [2, 22]),
			e(c, [2, 49], { 10: de }),
			e(c, [2, 48], {
				22: 89,
				16: 90,
				23: 105,
				4: U,
				5: W,
				6: G,
				8: K,
				11: q,
				13: J,
				17: Y,
				18: X,
				19: Z,
				20: Q
			}),
			{
				4: U,
				5: W,
				6: G,
				8: K,
				11: q,
				13: J,
				16: 90,
				17: Y,
				18: X,
				19: Z,
				20: Q,
				22: 106
			},
			e($, [2, 26]),
			e(c, [2, 50], { 10: de }),
			e(fe, [2, 28], {
				16: 104,
				4: U,
				5: W,
				6: G,
				8: K,
				11: q,
				13: J,
				17: Y,
				18: X,
				19: Z,
				20: Q
			})
		],
		defaultActions: {
			8: [2, 30],
			9: [2, 31]
		},
		parseError: /* @__PURE__ */ h(function(e, t) {
			if (t.recoverable) this.trace(e);
			else {
				var n = Error(e);
				throw n.hash = t, n;
			}
		}, "parseError"),
		parse: /* @__PURE__ */ h(function(e) {
			var t = this, n = [0], r = [], i = [null], a = [], o = this.table, s = "", c = 0, l = 0, u = 2, d = 1, f = a.slice.call(arguments, 1), p = Object.create(this.lexer), m = { yy: {} };
			for (var g in this.yy) Object.prototype.hasOwnProperty.call(this.yy, g) && (m.yy[g] = this.yy[g]);
			p.setInput(e, m.yy), m.yy.lexer = p, m.yy.parser = this, typeof p.yylloc > "u" && (p.yylloc = {});
			var _ = p.yylloc;
			a.push(_);
			var v = p.options && p.options.ranges;
			this.parseError = typeof m.yy.parseError == "function" ? m.yy.parseError : Object.getPrototypeOf(this).parseError;
			function y(e) {
				n.length -= 2 * e, i.length -= e, a.length -= e;
			}
			h(y, "popStack");
			function b() {
				var e;
				return e = r.pop() || p.lex() || d, typeof e != "number" && (e instanceof Array && (r = e, e = r.pop()), e = t.symbols_[e] || e), e;
			}
			h(b, "lex");
			for (var x, S, C, w, T = {}, E, D, O, k;;) {
				if (S = n[n.length - 1], this.defaultActions[S] ? C = this.defaultActions[S] : ((x === null || typeof x > "u") && (x = b()), C = o[S] && o[S][x]), typeof C > "u" || !C.length || !C[0]) {
					var A = "";
					for (E in k = [], o[S]) this.terminals_[E] && E > u && k.push("'" + this.terminals_[E] + "'");
					A = p.showPosition ? "Parse error on line " + (c + 1) + ":\n" + p.showPosition() + "\nExpecting " + k.join(", ") + ", got '" + (this.terminals_[x] || x) + "'" : "Parse error on line " + (c + 1) + ": Unexpected " + (x == d ? "end of input" : "'" + (this.terminals_[x] || x) + "'"), this.parseError(A, {
						text: p.match,
						token: this.terminals_[x] || x,
						line: p.yylineno,
						loc: _,
						expected: k
					});
				}
				if (C[0] instanceof Array && C.length > 1) throw Error("Parse Error: multiple actions possible at state: " + S + ", token: " + x);
				switch (C[0]) {
					case 1:
						n.push(x), i.push(p.yytext), a.push(p.yylloc), n.push(C[1]), x = null, l = p.yyleng, s = p.yytext, c = p.yylineno, _ = p.yylloc;
						break;
					case 2:
						if (D = this.productions_[C[1]][1], T.$ = i[i.length - D], T._$ = {
							first_line: a[a.length - (D || 1)].first_line,
							last_line: a[a.length - 1].last_line,
							first_column: a[a.length - (D || 1)].first_column,
							last_column: a[a.length - 1].last_column
						}, v && (T._$.range = [a[a.length - (D || 1)].range[0], a[a.length - 1].range[1]]), w = this.performAction.apply(T, [
							s,
							l,
							c,
							m.yy,
							C[1],
							i,
							a
						].concat(f)), typeof w < "u") return w;
						D && (n = n.slice(0, -1 * D * 2), i = i.slice(0, -1 * D), a = a.slice(0, -1 * D)), n.push(this.productions_[C[1]][0]), i.push(T.$), a.push(T._$), O = o[n[n.length - 2]][n[n.length - 1]], n.push(O);
						break;
					case 3: return !0;
				}
			}
			return !0;
		}, "parse")
	};
	pe.lexer = /* @__PURE__ */ function() {
		return {
			EOF: 1,
			parseError: /* @__PURE__ */ h(function(e, t) {
				if (this.yy.parser) this.yy.parser.parseError(e, t);
				else throw Error(e);
			}, "parseError"),
			setInput: /* @__PURE__ */ h(function(e, t) {
				return this.yy = t || this.yy || {}, this._input = e, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
					first_line: 1,
					first_column: 0,
					last_line: 1,
					last_column: 0
				}, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
			}, "setInput"),
			input: /* @__PURE__ */ h(function() {
				var e = this._input[0];
				return this.yytext += e, this.yyleng++, this.offset++, this.match += e, this.matched += e, e.match(/(?:\r\n?|\n).*/g) ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), e;
			}, "input"),
			unput: /* @__PURE__ */ h(function(e) {
				var t = e.length, n = e.split(/(?:\r\n?|\n)/g);
				this._input = e + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - t), this.offset -= t;
				var r = this.match.split(/(?:\r\n?|\n)/g);
				this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), n.length - 1 && (this.yylineno -= n.length - 1);
				var i = this.yylloc.range;
				return this.yylloc = {
					first_line: this.yylloc.first_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.first_column,
					last_column: n ? (n.length === r.length ? this.yylloc.first_column : 0) + r[r.length - n.length].length - n[0].length : this.yylloc.first_column - t
				}, this.options.ranges && (this.yylloc.range = [i[0], i[0] + this.yyleng - t]), this.yyleng = this.yytext.length, this;
			}, "unput"),
			more: /* @__PURE__ */ h(function() {
				return this._more = !0, this;
			}, "more"),
			reject: /* @__PURE__ */ h(function() {
				if (this.options.backtrack_lexer) this._backtrack = !0;
				else return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
				return this;
			}, "reject"),
			less: /* @__PURE__ */ h(function(e) {
				this.unput(this.match.slice(e));
			}, "less"),
			pastInput: /* @__PURE__ */ h(function() {
				var e = this.matched.substr(0, this.matched.length - this.match.length);
				return (e.length > 20 ? "..." : "") + e.substr(-20).replace(/\n/g, "");
			}, "pastInput"),
			upcomingInput: /* @__PURE__ */ h(function() {
				var e = this.match;
				return e.length < 20 && (e += this._input.substr(0, 20 - e.length)), (e.substr(0, 20) + (e.length > 20 ? "..." : "")).replace(/\n/g, "");
			}, "upcomingInput"),
			showPosition: /* @__PURE__ */ h(function() {
				var e = this.pastInput(), t = Array(e.length + 1).join("-");
				return e + this.upcomingInput() + "\n" + t + "^";
			}, "showPosition"),
			test_match: /* @__PURE__ */ h(function(e, t) {
				var n, r, i;
				if (this.options.backtrack_lexer && (i = {
					yylineno: this.yylineno,
					yylloc: {
						first_line: this.yylloc.first_line,
						last_line: this.last_line,
						first_column: this.yylloc.first_column,
						last_column: this.yylloc.last_column
					},
					yytext: this.yytext,
					match: this.match,
					matches: this.matches,
					matched: this.matched,
					yyleng: this.yyleng,
					offset: this.offset,
					_more: this._more,
					_input: this._input,
					yy: this.yy,
					conditionStack: this.conditionStack.slice(0),
					done: this.done
				}, this.options.ranges && (i.yylloc.range = this.yylloc.range.slice(0))), r = e[0].match(/(?:\r\n?|\n).*/g), r && (this.yylineno += r.length), this.yylloc = {
					first_line: this.yylloc.last_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.last_column,
					last_column: r ? r[r.length - 1].length - r[r.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + e[0].length
				}, this.yytext += e[0], this.match += e[0], this.matches = e, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(e[0].length), this.matched += e[0], n = this.performAction.call(this, this.yy, this, t, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), n) return n;
				if (this._backtrack) {
					for (var a in i) this[a] = i[a];
					return !1;
				}
				return !1;
			}, "test_match"),
			next: /* @__PURE__ */ h(function() {
				if (this.done) return this.EOF;
				this._input || (this.done = !0);
				var e, t, n, r;
				this._more || (this.yytext = "", this.match = "");
				for (var i = this._currentRules(), a = 0; a < i.length; a++) if (n = this._input.match(this.rules[i[a]]), n && (!t || n[0].length > t[0].length)) {
					if (t = n, r = a, this.options.backtrack_lexer) {
						if (e = this.test_match(n, i[a]), e !== !1) return e;
						if (this._backtrack) {
							t = !1;
							continue;
						}
						return !1;
					}
					if (!this.options.flex) break;
				}
				return t ? (e = this.test_match(t, i[r]), e !== !1 && e) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
			}, "next"),
			lex: /* @__PURE__ */ h(function() {
				return this.next() || this.lex();
			}, "lex"),
			begin: /* @__PURE__ */ h(function(e) {
				this.conditionStack.push(e);
			}, "begin"),
			popState: /* @__PURE__ */ h(function() {
				return this.conditionStack.length - 1 > 0 ? this.conditionStack.pop() : this.conditionStack[0];
			}, "popState"),
			_currentRules: /* @__PURE__ */ h(function() {
				return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
			}, "_currentRules"),
			topState: /* @__PURE__ */ h(function(e) {
				return e = this.conditionStack.length - 1 - Math.abs(e || 0), e >= 0 ? this.conditionStack[e] : "INITIAL";
			}, "topState"),
			pushState: /* @__PURE__ */ h(function(e) {
				this.begin(e);
			}, "pushState"),
			stateStackSize: /* @__PURE__ */ h(function() {
				return this.conditionStack.length;
			}, "stateStackSize"),
			options: { "case-insensitive": !0 },
			performAction: /* @__PURE__ */ h(function(e, t, n, r) {
				switch (n) {
					case 0: break;
					case 1: break;
					case 2: return 55;
					case 3: break;
					case 4: return this.begin("title"), 35;
					case 5: return this.popState(), "title_value";
					case 6: return this.begin("acc_title"), 37;
					case 7: return this.popState(), "acc_title_value";
					case 8: return this.begin("acc_descr"), 39;
					case 9: return this.popState(), "acc_descr_value";
					case 10:
						this.begin("acc_descr_multiline");
						break;
					case 11:
						this.popState();
						break;
					case 12: return "acc_descr_multiline_value";
					case 13: return 48;
					case 14: return 50;
					case 15: return 49;
					case 16: return 51;
					case 17: return 52;
					case 18: return 53;
					case 19: return 54;
					case 20: return 25;
					case 21:
						this.begin("md_string");
						break;
					case 22: return "MD_STR";
					case 23:
						this.popState();
						break;
					case 24:
						this.begin("string");
						break;
					case 25:
						this.popState();
						break;
					case 26: return "STR";
					case 27:
						this.begin("class_name");
						break;
					case 28: return this.popState(), 47;
					case 29: return this.begin("point_start"), 44;
					case 30: return this.begin("point_x"), 45;
					case 31:
						this.popState();
						break;
					case 32:
						this.popState(), this.begin("point_y");
						break;
					case 33: return this.popState(), 46;
					case 34: return 28;
					case 35: return 4;
					case 36: return 15;
					case 37: return 11;
					case 38: return 64;
					case 39: return 10;
					case 40: return 65;
					case 41: return 65;
					case 42: return 14;
					case 43: return 13;
					case 44: return 67;
					case 45: return 66;
					case 46: return 12;
					case 47: return 8;
					case 48: return 5;
					case 49: return 18;
					case 50: return 56;
					case 51: return 63;
					case 52: return 57;
				}
			}, "anonymous"),
			rules: [
				/^(?:%%(?!\{)[^\n]*)/i,
				/^(?:[^\}]%%[^\n]*)/i,
				/^(?:[\n\r]+)/i,
				/^(?:%%[^\n]*)/i,
				/^(?:title\b)/i,
				/^(?:(?!\n||)*[^\n]*)/i,
				/^(?:accTitle\s*:\s*)/i,
				/^(?:(?!\n||)*[^\n]*)/i,
				/^(?:accDescr\s*:\s*)/i,
				/^(?:(?!\n||)*[^\n]*)/i,
				/^(?:accDescr\s*\{\s*)/i,
				/^(?:[\}])/i,
				/^(?:[^\}]*)/i,
				/^(?: *x-axis *)/i,
				/^(?: *y-axis *)/i,
				/^(?: *--+> *)/i,
				/^(?: *quadrant-1 *)/i,
				/^(?: *quadrant-2 *)/i,
				/^(?: *quadrant-3 *)/i,
				/^(?: *quadrant-4 *)/i,
				/^(?:classDef\b)/i,
				/^(?:["][`])/i,
				/^(?:[^`"]+)/i,
				/^(?:[`]["])/i,
				/^(?:["])/i,
				/^(?:["])/i,
				/^(?:[^"]*)/i,
				/^(?::::)/i,
				/^(?:^\w+)/i,
				/^(?:\s*:\s*\[\s*)/i,
				/^(?:(1)|(0(.\d+)?))/i,
				/^(?:\s*\] *)/i,
				/^(?:\s*,\s*)/i,
				/^(?:(1)|(0(.\d+)?))/i,
				/^(?: *quadrantChart *)/i,
				/^(?:[A-Za-z]+)/i,
				/^(?:[^\x00-\x7F]+)/i,
				/^(?::)/i,
				/^(?:\+)/i,
				/^(?:,)/i,
				/^(?:=)/i,
				/^(?:=)/i,
				/^(?:\*)/i,
				/^(?:#)/i,
				/^(?:[\_])/i,
				/^(?:\.)/i,
				/^(?:&)/i,
				/^(?:-)/i,
				/^(?:[0-9]+)/i,
				/^(?:\s)/i,
				/^(?:;)/i,
				/^(?:[!"#$%&'*+,-.`?\\_/])/i,
				/^(?:$)/i
			],
			conditions: {
				class_name: {
					rules: [28],
					inclusive: !1
				},
				point_y: {
					rules: [33],
					inclusive: !1
				},
				point_x: {
					rules: [32],
					inclusive: !1
				},
				point_start: {
					rules: [30, 31],
					inclusive: !1
				},
				acc_descr_multiline: {
					rules: [11, 12],
					inclusive: !1
				},
				acc_descr: {
					rules: [9],
					inclusive: !1
				},
				acc_title: {
					rules: [7],
					inclusive: !1
				},
				title: {
					rules: [5],
					inclusive: !1
				},
				md_string: {
					rules: [22, 23],
					inclusive: !1
				},
				string: {
					rules: [25, 26],
					inclusive: !1
				},
				INITIAL: {
					rules: [
						0,
						1,
						2,
						3,
						4,
						6,
						8,
						10,
						13,
						14,
						15,
						16,
						17,
						18,
						19,
						20,
						21,
						24,
						27,
						29,
						34,
						35,
						36,
						37,
						38,
						39,
						40,
						41,
						42,
						43,
						44,
						45,
						46,
						47,
						48,
						49,
						50,
						51,
						52
					],
					inclusive: !0
				}
			}
		};
	}();
	function me() {
		this.yy = {};
	}
	return h(me, "Parser"), me.prototype = pe, pe.Parser = me, new me();
}();
g.parser = g;
var _ = g, v = l(), y, b = (y = class {
	constructor() {
		this.classes = /* @__PURE__ */ new Map(), this.config = this.getDefaultConfig(), this.themeConfig = this.getDefaultThemeConfig(), this.data = this.getDefaultData();
	}
	getDefaultData() {
		return {
			titleText: "",
			quadrant1Text: "",
			quadrant2Text: "",
			quadrant3Text: "",
			quadrant4Text: "",
			xAxisLeftText: "",
			xAxisRightText: "",
			yAxisBottomText: "",
			yAxisTopText: "",
			points: []
		};
	}
	getDefaultConfig() {
		return {
			showXAxis: !0,
			showYAxis: !0,
			showTitle: !0,
			chartHeight: i.quadrantChart?.chartWidth || 500,
			chartWidth: i.quadrantChart?.chartHeight || 500,
			titlePadding: i.quadrantChart?.titlePadding || 10,
			titleFontSize: i.quadrantChart?.titleFontSize || 20,
			quadrantPadding: i.quadrantChart?.quadrantPadding || 5,
			xAxisLabelPadding: i.quadrantChart?.xAxisLabelPadding || 5,
			yAxisLabelPadding: i.quadrantChart?.yAxisLabelPadding || 5,
			xAxisLabelFontSize: i.quadrantChart?.xAxisLabelFontSize || 16,
			yAxisLabelFontSize: i.quadrantChart?.yAxisLabelFontSize || 16,
			quadrantLabelFontSize: i.quadrantChart?.quadrantLabelFontSize || 16,
			quadrantTextTopPadding: i.quadrantChart?.quadrantTextTopPadding || 5,
			pointTextPadding: i.quadrantChart?.pointTextPadding || 5,
			pointLabelFontSize: i.quadrantChart?.pointLabelFontSize || 12,
			pointRadius: i.quadrantChart?.pointRadius || 5,
			xAxisPosition: i.quadrantChart?.xAxisPosition || "top",
			yAxisPosition: i.quadrantChart?.yAxisPosition || "left",
			quadrantInternalBorderStrokeWidth: i.quadrantChart?.quadrantInternalBorderStrokeWidth || 1,
			quadrantExternalBorderStrokeWidth: i.quadrantChart?.quadrantExternalBorderStrokeWidth || 2
		};
	}
	getDefaultThemeConfig() {
		return {
			quadrant1Fill: v.quadrant1Fill,
			quadrant2Fill: v.quadrant2Fill,
			quadrant3Fill: v.quadrant3Fill,
			quadrant4Fill: v.quadrant4Fill,
			quadrant1TextFill: v.quadrant1TextFill,
			quadrant2TextFill: v.quadrant2TextFill,
			quadrant3TextFill: v.quadrant3TextFill,
			quadrant4TextFill: v.quadrant4TextFill,
			quadrantPointFill: v.quadrantPointFill,
			quadrantPointTextFill: v.quadrantPointTextFill,
			quadrantXAxisTextFill: v.quadrantXAxisTextFill,
			quadrantYAxisTextFill: v.quadrantYAxisTextFill,
			quadrantTitleFill: v.quadrantTitleFill,
			quadrantInternalBorderStrokeFill: v.quadrantInternalBorderStrokeFill,
			quadrantExternalBorderStrokeFill: v.quadrantExternalBorderStrokeFill
		};
	}
	clear() {
		this.config = this.getDefaultConfig(), this.themeConfig = this.getDefaultThemeConfig(), this.data = this.getDefaultData(), this.classes = /* @__PURE__ */ new Map(), u.info("clear called");
	}
	setData(e) {
		this.data = {
			...this.data,
			...e
		};
	}
	addPoints(e) {
		this.data.points = [...e, ...this.data.points];
	}
	addClass(e, t) {
		this.classes.set(e, t);
	}
	setConfig(e) {
		u.trace("setConfig called with: ", e), this.config = {
			...this.config,
			...e
		};
	}
	setThemeConfig(e) {
		u.trace("setThemeConfig called with: ", e), this.themeConfig = {
			...this.themeConfig,
			...e
		};
	}
	calculateSpace(e, t, n, r) {
		let i = this.config.xAxisLabelPadding * 2 + this.config.xAxisLabelFontSize, a = {
			top: e === "top" && t ? i : 0,
			bottom: e === "bottom" && t ? i : 0
		}, o = this.config.yAxisLabelPadding * 2 + this.config.yAxisLabelFontSize, s = {
			left: this.config.yAxisPosition === "left" && n ? o : 0,
			right: this.config.yAxisPosition === "right" && n ? o : 0
		}, c = this.config.titleFontSize + this.config.titlePadding * 2, l = { top: r ? c : 0 }, u = this.config.quadrantPadding + s.left, d = this.config.quadrantPadding + a.top + l.top, f = this.config.chartWidth - this.config.quadrantPadding * 2 - s.left - s.right, p = this.config.chartHeight - this.config.quadrantPadding * 2 - a.top - a.bottom - l.top;
		return {
			xAxisSpace: a,
			yAxisSpace: s,
			titleSpace: l,
			quadrantSpace: {
				quadrantLeft: u,
				quadrantTop: d,
				quadrantWidth: f,
				quadrantHalfWidth: f / 2,
				quadrantHeight: p,
				quadrantHalfHeight: p / 2
			}
		};
	}
	getAxisLabels(e, t, n, r) {
		let { quadrantSpace: i, titleSpace: a } = r, { quadrantHalfHeight: o, quadrantHeight: s, quadrantLeft: c, quadrantHalfWidth: l, quadrantTop: u, quadrantWidth: d } = i, f = !!this.data.xAxisRightText, p = !!this.data.yAxisTopText, m = [];
		return this.data.xAxisLeftText && t && m.push({
			text: this.data.xAxisLeftText,
			fill: this.themeConfig.quadrantXAxisTextFill,
			x: c + (f ? l / 2 : 0),
			y: e === "top" ? this.config.xAxisLabelPadding + a.top : this.config.xAxisLabelPadding + u + s + this.config.quadrantPadding,
			fontSize: this.config.xAxisLabelFontSize,
			verticalPos: f ? "center" : "left",
			horizontalPos: "top",
			rotation: 0
		}), this.data.xAxisRightText && t && m.push({
			text: this.data.xAxisRightText,
			fill: this.themeConfig.quadrantXAxisTextFill,
			x: c + l + (f ? l / 2 : 0),
			y: e === "top" ? this.config.xAxisLabelPadding + a.top : this.config.xAxisLabelPadding + u + s + this.config.quadrantPadding,
			fontSize: this.config.xAxisLabelFontSize,
			verticalPos: f ? "center" : "left",
			horizontalPos: "top",
			rotation: 0
		}), this.data.yAxisBottomText && n && m.push({
			text: this.data.yAxisBottomText,
			fill: this.themeConfig.quadrantYAxisTextFill,
			x: this.config.yAxisPosition === "left" ? this.config.yAxisLabelPadding : this.config.yAxisLabelPadding + c + d + this.config.quadrantPadding,
			y: u + s - (p ? o / 2 : 0),
			fontSize: this.config.yAxisLabelFontSize,
			verticalPos: p ? "center" : "left",
			horizontalPos: "top",
			rotation: -90
		}), this.data.yAxisTopText && n && m.push({
			text: this.data.yAxisTopText,
			fill: this.themeConfig.quadrantYAxisTextFill,
			x: this.config.yAxisPosition === "left" ? this.config.yAxisLabelPadding : this.config.yAxisLabelPadding + c + d + this.config.quadrantPadding,
			y: u + o - (p ? o / 2 : 0),
			fontSize: this.config.yAxisLabelFontSize,
			verticalPos: p ? "center" : "left",
			horizontalPos: "top",
			rotation: -90
		}), m;
	}
	getQuadrants(e) {
		let { quadrantSpace: t } = e, { quadrantHalfHeight: n, quadrantLeft: r, quadrantHalfWidth: i, quadrantTop: a } = t, o = [
			{
				text: {
					text: this.data.quadrant1Text,
					fill: this.themeConfig.quadrant1TextFill,
					x: 0,
					y: 0,
					fontSize: this.config.quadrantLabelFontSize,
					verticalPos: "center",
					horizontalPos: "middle",
					rotation: 0
				},
				x: r + i,
				y: a,
				width: i,
				height: n,
				fill: this.themeConfig.quadrant1Fill
			},
			{
				text: {
					text: this.data.quadrant2Text,
					fill: this.themeConfig.quadrant2TextFill,
					x: 0,
					y: 0,
					fontSize: this.config.quadrantLabelFontSize,
					verticalPos: "center",
					horizontalPos: "middle",
					rotation: 0
				},
				x: r,
				y: a,
				width: i,
				height: n,
				fill: this.themeConfig.quadrant2Fill
			},
			{
				text: {
					text: this.data.quadrant3Text,
					fill: this.themeConfig.quadrant3TextFill,
					x: 0,
					y: 0,
					fontSize: this.config.quadrantLabelFontSize,
					verticalPos: "center",
					horizontalPos: "middle",
					rotation: 0
				},
				x: r,
				y: a + n,
				width: i,
				height: n,
				fill: this.themeConfig.quadrant3Fill
			},
			{
				text: {
					text: this.data.quadrant4Text,
					fill: this.themeConfig.quadrant4TextFill,
					x: 0,
					y: 0,
					fontSize: this.config.quadrantLabelFontSize,
					verticalPos: "center",
					horizontalPos: "middle",
					rotation: 0
				},
				x: r + i,
				y: a + n,
				width: i,
				height: n,
				fill: this.themeConfig.quadrant4Fill
			}
		];
		for (let e of o) e.text.x = e.x + e.width / 2, this.data.points.length === 0 ? (e.text.y = e.y + e.height / 2, e.text.horizontalPos = "middle") : (e.text.y = e.y + this.config.quadrantTextTopPadding, e.text.horizontalPos = "top");
		return o;
	}
	getQuadrantPoints(t) {
		let { quadrantSpace: n } = t, { quadrantHeight: r, quadrantLeft: i, quadrantTop: a, quadrantWidth: o } = n, s = e().domain([0, 1]).range([i, o + i]), c = e().domain([0, 1]).range([r + a, a]);
		return this.data.points.map((e) => {
			let t = this.classes.get(e.className);
			return t && (e = {
				...t,
				...e
			}), {
				x: s(e.x),
				y: c(e.y),
				fill: e.color ?? this.themeConfig.quadrantPointFill,
				radius: e.radius ?? this.config.pointRadius,
				text: {
					text: e.text,
					fill: this.themeConfig.quadrantPointTextFill,
					x: s(e.x),
					y: c(e.y) + this.config.pointTextPadding,
					verticalPos: "center",
					horizontalPos: "top",
					fontSize: this.config.pointLabelFontSize,
					rotation: 0
				},
				strokeColor: e.strokeColor ?? this.themeConfig.quadrantPointFill,
				strokeWidth: e.strokeWidth ?? "0px"
			};
		});
	}
	getBorders(e) {
		let t = this.config.quadrantExternalBorderStrokeWidth / 2, { quadrantSpace: n } = e, { quadrantHalfHeight: r, quadrantHeight: i, quadrantLeft: a, quadrantHalfWidth: o, quadrantTop: s, quadrantWidth: c } = n;
		return [
			{
				strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill,
				strokeWidth: this.config.quadrantExternalBorderStrokeWidth,
				x1: a - t,
				y1: s,
				x2: a + c + t,
				y2: s
			},
			{
				strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill,
				strokeWidth: this.config.quadrantExternalBorderStrokeWidth,
				x1: a + c,
				y1: s + t,
				x2: a + c,
				y2: s + i - t
			},
			{
				strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill,
				strokeWidth: this.config.quadrantExternalBorderStrokeWidth,
				x1: a - t,
				y1: s + i,
				x2: a + c + t,
				y2: s + i
			},
			{
				strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill,
				strokeWidth: this.config.quadrantExternalBorderStrokeWidth,
				x1: a,
				y1: s + t,
				x2: a,
				y2: s + i - t
			},
			{
				strokeFill: this.themeConfig.quadrantInternalBorderStrokeFill,
				strokeWidth: this.config.quadrantInternalBorderStrokeWidth,
				x1: a + o,
				y1: s + t,
				x2: a + o,
				y2: s + i - t
			},
			{
				strokeFill: this.themeConfig.quadrantInternalBorderStrokeFill,
				strokeWidth: this.config.quadrantInternalBorderStrokeWidth,
				x1: a + t,
				y1: s + r,
				x2: a + c - t,
				y2: s + r
			}
		];
	}
	getTitle(e) {
		if (e) return {
			text: this.data.titleText,
			fill: this.themeConfig.quadrantTitleFill,
			fontSize: this.config.titleFontSize,
			horizontalPos: "top",
			verticalPos: "center",
			rotation: 0,
			y: this.config.titlePadding,
			x: this.config.chartWidth / 2
		};
	}
	build() {
		let e = this.config.showXAxis && !!(this.data.xAxisLeftText || this.data.xAxisRightText), t = this.config.showYAxis && !!(this.data.yAxisTopText || this.data.yAxisBottomText), n = this.config.showTitle && !!this.data.titleText, r = this.data.points.length > 0 ? "bottom" : this.config.xAxisPosition, i = this.calculateSpace(r, e, t, n);
		return {
			points: this.getQuadrantPoints(i),
			quadrants: this.getQuadrants(i),
			axisLabels: this.getAxisLabels(r, e, t, i),
			borderLines: this.getBorders(i),
			title: this.getTitle(n)
		};
	}
}, h(y, "QuadrantBuilder"), y), x, S = (x = class extends Error {
	constructor(e, t, n) {
		super(`value for ${e} ${t} is invalid, please use a valid ${n}`), this.name = "InvalidStyleError";
	}
}, h(x, "InvalidStyleError"), x);
function C(e) {
	return !/^#?([\dA-Fa-f]{6}|[\dA-Fa-f]{3})$/.test(e);
}
h(C, "validateHexCode");
function w(e) {
	return !/^\d+$/.test(e);
}
h(w, "validateNumber");
function T(e) {
	return !/^\d+px$/.test(e);
}
h(T, "validateSizeInPixels");
function E(e) {
	return f(e.trim(), s());
}
h(E, "textSanitizer");
var D = new b();
function O(e) {
	D.setData({ quadrant1Text: E(e.text) });
}
h(O, "setQuadrant1Text");
function k(e) {
	D.setData({ quadrant2Text: E(e.text) });
}
h(k, "setQuadrant2Text");
function A(e) {
	D.setData({ quadrant3Text: E(e.text) });
}
h(A, "setQuadrant3Text");
function j(e) {
	D.setData({ quadrant4Text: E(e.text) });
}
h(j, "setQuadrant4Text");
function M(e) {
	D.setData({ xAxisLeftText: E(e.text) });
}
h(M, "setXAxisLeftText");
function N(e) {
	D.setData({ xAxisRightText: E(e.text) });
}
h(N, "setXAxisRightText");
function P(e) {
	D.setData({ yAxisTopText: E(e.text) });
}
h(P, "setYAxisTopText");
function F(e) {
	D.setData({ yAxisBottomText: E(e.text) });
}
h(F, "setYAxisBottomText");
function I(e) {
	let t = {};
	for (let n of e) {
		let [e, r] = n.trim().split(/\s*:\s*/);
		if (e === "radius") {
			if (w(r)) throw new S(e, r, "number");
			t.radius = parseInt(r);
		} else if (e === "color") {
			if (C(r)) throw new S(e, r, "hex code");
			t.color = r;
		} else if (e === "stroke-color") {
			if (C(r)) throw new S(e, r, "hex code");
			t.strokeColor = r;
		} else if (e === "stroke-width") {
			if (T(r)) throw new S(e, r, "number of pixels (eg. 10px)");
			t.strokeWidth = r;
		} else throw Error(`style named ${e} is not supported.`);
	}
	return t;
}
h(I, "parseStyles");
function L(e, t, n, r, i) {
	let a = I(i);
	D.addPoints([{
		x: n,
		y: r,
		text: E(e.text),
		className: t,
		...a
	}]);
}
h(L, "addPoint");
function R(e, t) {
	D.addClass(e, I(t));
}
h(R, "addClass");
function z(e) {
	D.setConfig({ chartWidth: e });
}
h(z, "setWidth");
function B(e) {
	D.setConfig({ chartHeight: e });
}
h(B, "setHeight");
function V() {
	let { themeVariables: e, quadrantChart: t } = s();
	return t && D.setConfig(t), D.setThemeConfig({
		quadrant1Fill: e.quadrant1Fill,
		quadrant2Fill: e.quadrant2Fill,
		quadrant3Fill: e.quadrant3Fill,
		quadrant4Fill: e.quadrant4Fill,
		quadrant1TextFill: e.quadrant1TextFill,
		quadrant2TextFill: e.quadrant2TextFill,
		quadrant3TextFill: e.quadrant3TextFill,
		quadrant4TextFill: e.quadrant4TextFill,
		quadrantPointFill: e.quadrantPointFill,
		quadrantPointTextFill: e.quadrantPointTextFill,
		quadrantXAxisTextFill: e.quadrantXAxisTextFill,
		quadrantYAxisTextFill: e.quadrantYAxisTextFill,
		quadrantExternalBorderStrokeFill: e.quadrantExternalBorderStrokeFill,
		quadrantInternalBorderStrokeFill: e.quadrantInternalBorderStrokeFill,
		quadrantTitleFill: e.quadrantTitleFill
	}), D.setData({ titleText: c() }), D.build();
}
h(V, "getQuadrantData");
var ee = {
	parser: _,
	db: {
		setWidth: z,
		setHeight: B,
		setQuadrant1Text: O,
		setQuadrant2Text: k,
		setQuadrant3Text: A,
		setQuadrant4Text: j,
		setXAxisLeftText: M,
		setXAxisRightText: N,
		setYAxisTopText: P,
		setYAxisBottomText: F,
		parseStyles: I,
		addPoint: L,
		addClass: R,
		getQuadrantData: V,
		clear: /* @__PURE__ */ h(function() {
			D.clear(), n();
		}, "clear"),
		setAccTitle: m,
		getAccTitle: o,
		setDiagramTitle: d,
		getDiagramTitle: c,
		getAccDescription: a,
		setAccDescription: p
	},
	renderer: { draw: /* @__PURE__ */ h((e, n, i, a) => {
		function o(e) {
			return e === "top" ? "hanging" : "middle";
		}
		h(o, "getDominantBaseLine");
		function c(e) {
			return e === "left" ? "start" : "middle";
		}
		h(c, "getTextAnchor");
		function l(e) {
			return `translate(${e.x}, ${e.y}) rotate(${e.rotation || 0})`;
		}
		h(l, "getTransformation");
		let d = s();
		u.debug("Rendering quadrant chart\n" + e);
		let f = d.securityLevel, p;
		f === "sandbox" && (p = t("#i" + n));
		let m = t(f === "sandbox" ? p.nodes()[0].contentDocument.body : "body").select(`[id="${n}"]`), g = m.append("g").attr("class", "main"), _ = d.quadrantChart?.chartWidth ?? 500, v = d.quadrantChart?.chartHeight ?? 500;
		r(m, v, _, d.quadrantChart?.useMaxWidth ?? !0), m.attr("viewBox", "0 0 " + _ + " " + v), a.db.setHeight(v), a.db.setWidth(_);
		let y = a.db.getQuadrantData(), b = g.append("g").attr("class", "quadrants"), x = g.append("g").attr("class", "border"), S = g.append("g").attr("class", "data-points"), C = g.append("g").attr("class", "labels"), w = g.append("g").attr("class", "title");
		y.title && w.append("text").attr("x", 0).attr("y", 0).attr("fill", y.title.fill).attr("font-size", y.title.fontSize).attr("dominant-baseline", o(y.title.horizontalPos)).attr("text-anchor", c(y.title.verticalPos)).attr("transform", l(y.title)).text(y.title.text), y.borderLines && x.selectAll("line").data(y.borderLines).enter().append("line").attr("x1", (e) => e.x1).attr("y1", (e) => e.y1).attr("x2", (e) => e.x2).attr("y2", (e) => e.y2).style("stroke", (e) => e.strokeFill).style("stroke-width", (e) => e.strokeWidth);
		let T = b.selectAll("g.quadrant").data(y.quadrants).enter().append("g").attr("class", "quadrant");
		T.append("rect").attr("x", (e) => e.x).attr("y", (e) => e.y).attr("width", (e) => e.width).attr("height", (e) => e.height).attr("fill", (e) => e.fill), T.append("text").attr("x", 0).attr("y", 0).attr("fill", (e) => e.text.fill).attr("font-size", (e) => e.text.fontSize).attr("dominant-baseline", (e) => o(e.text.horizontalPos)).attr("text-anchor", (e) => c(e.text.verticalPos)).attr("transform", (e) => l(e.text)).text((e) => e.text.text), C.selectAll("g.label").data(y.axisLabels).enter().append("g").attr("class", "label").append("text").attr("x", 0).attr("y", 0).text((e) => e.text).attr("fill", (e) => e.fill).attr("font-size", (e) => e.fontSize).attr("dominant-baseline", (e) => o(e.horizontalPos)).attr("text-anchor", (e) => c(e.verticalPos)).attr("transform", (e) => l(e));
		let E = S.selectAll("g.data-point").data(y.points).enter().append("g").attr("class", "data-point");
		E.append("circle").attr("cx", (e) => e.x).attr("cy", (e) => e.y).attr("r", (e) => e.radius).attr("fill", (e) => e.fill).attr("stroke", (e) => e.strokeColor).attr("stroke-width", (e) => e.strokeWidth), E.append("text").attr("x", 0).attr("y", 0).text((e) => e.text.text).attr("fill", (e) => e.text.fill).attr("font-size", (e) => e.text.fontSize).attr("dominant-baseline", (e) => o(e.text.horizontalPos)).attr("text-anchor", (e) => c(e.text.verticalPos)).attr("transform", (e) => l(e.text));
	}, "draw") },
	styles: /* @__PURE__ */ h(() => "", "styles")
};
//#endregion
export { ee as diagram };

//# sourceMappingURL=quadrantDiagram-AXDQQJYC-1i3l2RVr-CVShImHS.js.map