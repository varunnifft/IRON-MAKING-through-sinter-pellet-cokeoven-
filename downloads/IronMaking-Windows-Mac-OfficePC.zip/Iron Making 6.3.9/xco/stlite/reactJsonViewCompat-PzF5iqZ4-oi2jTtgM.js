import { Ki as e, ds as t, ms as n, xi as r } from "./index-B1FrxEMd-BsPMjC5n.js";
import { t as i } from "./resolveDefaultExport-Cy5TTESD-CcwO08HL.js";
//#region ../react/build/reactJsonViewCompat-PzF5iqZ4.js
var a = /* @__PURE__ */ n(t(), 1), o = { exports: {} }, s = o.exports, c;
function l() {
	return c || (c = 1, function(e, t) {
		(function(t, n) {
			e.exports = n(a.default);
		})(s, (e) => (() => {
			var t = {
				165(e, t, n) {
					let r = n(877), i = {};
					for (let e of Object.keys(r)) i[r[e]] = e;
					let a = {
						rgb: {
							channels: 3,
							labels: "rgb"
						},
						hsl: {
							channels: 3,
							labels: "hsl"
						},
						hsv: {
							channels: 3,
							labels: "hsv"
						},
						hwb: {
							channels: 3,
							labels: "hwb"
						},
						cmyk: {
							channels: 4,
							labels: "cmyk"
						},
						xyz: {
							channels: 3,
							labels: "xyz"
						},
						lab: {
							channels: 3,
							labels: "lab"
						},
						lch: {
							channels: 3,
							labels: "lch"
						},
						hex: {
							channels: 1,
							labels: ["hex"]
						},
						keyword: {
							channels: 1,
							labels: ["keyword"]
						},
						ansi16: {
							channels: 1,
							labels: ["ansi16"]
						},
						ansi256: {
							channels: 1,
							labels: ["ansi256"]
						},
						hcg: {
							channels: 3,
							labels: [
								"h",
								"c",
								"g"
							]
						},
						apple: {
							channels: 3,
							labels: [
								"r16",
								"g16",
								"b16"
							]
						},
						gray: {
							channels: 1,
							labels: ["gray"]
						}
					};
					e.exports = a;
					for (let e of Object.keys(a)) {
						if (!("channels" in a[e])) throw Error("missing channels property: " + e);
						if (!("labels" in a[e])) throw Error("missing channel labels property: " + e);
						if (a[e].labels.length !== a[e].channels) throw Error("channel and label counts mismatch: " + e);
						let { channels: t, labels: n } = a[e];
						delete a[e].channels, delete a[e].labels, Object.defineProperty(a[e], "channels", { value: t }), Object.defineProperty(a[e], "labels", { value: n });
					}
					function o(e, t) {
						return (e[0] - t[0]) ** 2 + (e[1] - t[1]) ** 2 + (e[2] - t[2]) ** 2;
					}
					a.rgb.hsl = function(e) {
						let t = e[0] / 255, n = e[1] / 255, r = e[2] / 255, i = Math.min(t, n, r), a = Math.max(t, n, r), o = a - i, s, c;
						a === i ? s = 0 : t === a ? s = (n - r) / o : n === a ? s = 2 + (r - t) / o : r === a && (s = 4 + (t - n) / o), s = Math.min(60 * s, 360), s < 0 && (s += 360);
						let l = (i + a) / 2;
						return c = a === i ? 0 : l <= .5 ? o / (a + i) : o / (2 - a - i), [
							s,
							100 * c,
							100 * l
						];
					}, a.rgb.hsv = function(e) {
						let t, n, r, i, a, o = e[0] / 255, s = e[1] / 255, c = e[2] / 255, l = Math.max(o, s, c), u = l - Math.min(o, s, c), d = function(e) {
							return (l - e) / 6 / u + .5;
						};
						return u === 0 ? (i = 0, a = 0) : (a = u / l, t = d(o), n = d(s), r = d(c), o === l ? i = r - n : s === l ? i = .3333333333333333 + t - r : c === l && (i = .6666666666666666 + n - t), i < 0 ? i += 1 : i > 1 && --i), [
							360 * i,
							100 * a,
							100 * l
						];
					}, a.rgb.hwb = function(e) {
						let t = e[0], n = e[1], r = e[2], i = a.rgb.hsl(e)[0], o = 1 / 255 * Math.min(t, Math.min(n, r));
						return r = 1 - .00392156862745098 * Math.max(t, Math.max(n, r)), [
							i,
							100 * o,
							100 * r
						];
					}, a.rgb.cmyk = function(e) {
						let t = e[0] / 255, n = e[1] / 255, r = e[2] / 255, i = Math.min(1 - t, 1 - n, 1 - r);
						return [
							100 * ((1 - t - i) / (1 - i) || 0),
							100 * ((1 - n - i) / (1 - i) || 0),
							100 * ((1 - r - i) / (1 - i) || 0),
							100 * i
						];
					}, a.rgb.keyword = function(e) {
						let t = i[e];
						if (t) return t;
						let n, a = 1 / 0;
						for (let t of Object.keys(r)) {
							let i = o(e, r[t]);
							i < a && (a = i, n = t);
						}
						return n;
					}, a.keyword.rgb = function(e) {
						return r[e];
					}, a.rgb.xyz = function(e) {
						let t = e[0] / 255, n = e[1] / 255, r = e[2] / 255;
						return t = t > .04045 ? ((t + .055) / 1.055) ** 2.4 : t / 12.92, n = n > .04045 ? ((n + .055) / 1.055) ** 2.4 : n / 12.92, r = r > .04045 ? ((r + .055) / 1.055) ** 2.4 : r / 12.92, [
							100 * (.4124 * t + .3576 * n + .1805 * r),
							100 * (.2126 * t + .7152 * n + .0722 * r),
							100 * (.0193 * t + .1192 * n + .9505 * r)
						];
					}, a.rgb.lab = function(e) {
						let t = a.rgb.xyz(e), n = t[0], r = t[1], i = t[2];
						return n /= 95.047, r /= 100, i /= 108.883, n = n > .008856 ? n ** .3333333333333333 : 7.787 * n + .13793103448275862, r = r > .008856 ? r ** .3333333333333333 : 7.787 * r + .13793103448275862, i = i > .008856 ? i ** .3333333333333333 : 7.787 * i + .13793103448275862, [
							116 * r - 16,
							500 * (n - r),
							200 * (r - i)
						];
					}, a.hsl.rgb = function(e) {
						let t = e[0] / 360, n = e[1] / 100, r = e[2] / 100, i, a, o;
						if (n === 0) return o = 255 * r, [
							o,
							o,
							o
						];
						i = r < .5 ? r * (1 + n) : r + n - r * n;
						let s = 2 * r - i, c = [
							0,
							0,
							0
						];
						for (let e = 0; e < 3; e++) a = t + .3333333333333333 * -(e - 1), a < 0 && a++, a > 1 && a--, o = 6 * a < 1 ? s + 6 * (i - s) * a : 2 * a < 1 ? i : 3 * a < 2 ? s + (i - s) * (.6666666666666666 - a) * 6 : s, c[e] = 255 * o;
						return c;
					}, a.hsl.hsv = function(e) {
						let t = e[0], n = e[1] / 100, r = e[2] / 100, i = n, a = Math.max(r, .01);
						return r *= 2, n *= r <= 1 ? r : 2 - r, i *= a <= 1 ? a : 2 - a, [
							t,
							100 * (r === 0 ? 2 * i / (a + i) : 2 * n / (r + n)),
							100 * ((r + n) / 2)
						];
					}, a.hsv.rgb = function(e) {
						let t = e[0] / 60, n = e[1] / 100, r = e[2] / 100, i = Math.floor(t) % 6, a = t - Math.floor(t), o = 255 * r * (1 - n), s = 255 * r * (1 - n * a), c = 255 * r * (1 - n * (1 - a));
						switch (r *= 255, i) {
							case 0: return [
								r,
								c,
								o
							];
							case 1: return [
								s,
								r,
								o
							];
							case 2: return [
								o,
								r,
								c
							];
							case 3: return [
								o,
								s,
								r
							];
							case 4: return [
								c,
								o,
								r
							];
							case 5: return [
								r,
								o,
								s
							];
						}
					}, a.hsv.hsl = function(e) {
						let t = e[0], n = e[1] / 100, r = e[2] / 100, i = Math.max(r, .01), a, o;
						o = (2 - n) * r;
						let s = (2 - n) * i;
						return a = n * i, a /= s <= 1 ? s : 2 - s, a ||= 0, o /= 2, [
							t,
							100 * a,
							100 * o
						];
					}, a.hwb.rgb = function(e) {
						let t = e[0] / 360, n = e[1] / 100, r = e[2] / 100, i = n + r, a;
						i > 1 && (n /= i, r /= i);
						let o = Math.floor(6 * t), s = 1 - r;
						a = 6 * t - o, 1 & o && (a = 1 - a);
						let c = n + a * (s - n), l, u, d;
						switch (o) {
							default:
							case 6:
							case 0:
								l = s, u = c, d = n;
								break;
							case 1:
								l = c, u = s, d = n;
								break;
							case 2:
								l = n, u = s, d = c;
								break;
							case 3:
								l = n, u = c, d = s;
								break;
							case 4:
								l = c, u = n, d = s;
								break;
							case 5: l = s, u = n, d = c;
						}
						return [
							255 * l,
							255 * u,
							255 * d
						];
					}, a.cmyk.rgb = function(e) {
						let t = e[0] / 100, n = e[1] / 100, r = e[2] / 100, i = e[3] / 100;
						return [
							255 * (1 - Math.min(1, t * (1 - i) + i)),
							255 * (1 - Math.min(1, n * (1 - i) + i)),
							255 * (1 - Math.min(1, r * (1 - i) + i))
						];
					}, a.xyz.rgb = function(e) {
						let t = e[0] / 100, n = e[1] / 100, r = e[2] / 100, i, a, o;
						return i = 3.2406 * t + -1.5372 * n + -.4986 * r, a = -.9689 * t + 1.8758 * n + .0415 * r, o = .0557 * t + -.204 * n + 1.057 * r, i = i > .0031308 ? 1.055 * i ** .4166666666666667 - .055 : 12.92 * i, a = a > .0031308 ? 1.055 * a ** .4166666666666667 - .055 : 12.92 * a, o = o > .0031308 ? 1.055 * o ** .4166666666666667 - .055 : 12.92 * o, i = Math.min(Math.max(0, i), 1), a = Math.min(Math.max(0, a), 1), o = Math.min(Math.max(0, o), 1), [
							255 * i,
							255 * a,
							255 * o
						];
					}, a.xyz.lab = function(e) {
						let t = e[0], n = e[1], r = e[2];
						return t /= 95.047, n /= 100, r /= 108.883, t = t > .008856 ? t ** .3333333333333333 : 7.787 * t + .13793103448275862, n = n > .008856 ? n ** .3333333333333333 : 7.787 * n + .13793103448275862, r = r > .008856 ? r ** .3333333333333333 : 7.787 * r + .13793103448275862, [
							116 * n - 16,
							500 * (t - n),
							200 * (n - r)
						];
					}, a.lab.xyz = function(e) {
						let t, n, r;
						n = (e[0] + 16) / 116, t = e[1] / 500 + n, r = n - e[2] / 200;
						let i = n ** 3, a = t ** 3, o = r ** 3;
						return n = i > .008856 ? i : (n - .13793103448275862) / 7.787, t = a > .008856 ? a : (t - .13793103448275862) / 7.787, r = o > .008856 ? o : (r - .13793103448275862) / 7.787, t *= 95.047, n *= 100, r *= 108.883, [
							t,
							n,
							r
						];
					}, a.lab.lch = function(e) {
						let t = e[0], n = e[1], r = e[2], i;
						return i = 360 * Math.atan2(r, n) / 2 / Math.PI, i < 0 && (i += 360), [
							t,
							Math.sqrt(n * n + r * r),
							i
						];
					}, a.lch.lab = function(e) {
						let t = e[0], n = e[1], r = e[2] / 360 * 2 * Math.PI;
						return [
							t,
							n * Math.cos(r),
							n * Math.sin(r)
						];
					}, a.rgb.ansi16 = function(e, t = null) {
						let [n, r, i] = e, o = t === null ? a.rgb.hsv(e)[2] : t;
						if (o = Math.round(o / 50), o === 0) return 30;
						let s = 30 + (Math.round(i / 255) << 2 | Math.round(r / 255) << 1 | Math.round(n / 255));
						return o === 2 && (s += 60), s;
					}, a.hsv.ansi16 = function(e) {
						return a.rgb.ansi16(a.hsv.rgb(e), e[2]);
					}, a.rgb.ansi256 = function(e) {
						let t = e[0], n = e[1], r = e[2];
						return t === n && n === r ? t < 8 ? 16 : t > 248 ? 231 : Math.round((t - 8) / 247 * 24) + 232 : 16 + 36 * Math.round(t / 255 * 5) + 6 * Math.round(n / 255 * 5) + Math.round(r / 255 * 5);
					}, a.ansi16.rgb = function(e) {
						let t = e % 10;
						if (t === 0 || t === 7) return e > 50 && (t += 3.5), t = t / 10.5 * 255, [
							t,
							t,
							t
						];
						let n = .5 * (1 + ~~(e > 50));
						return [
							(1 & t) * n * 255,
							(t >> 1 & 1) * n * 255,
							(t >> 2 & 1) * n * 255
						];
					}, a.ansi256.rgb = function(e) {
						if (e >= 232) {
							let t = 10 * (e - 232) + 8;
							return [
								t,
								t,
								t
							];
						}
						let t;
						return e -= 16, [
							Math.floor(e / 36) / 5 * 255,
							Math.floor((t = e % 36) / 6) / 5 * 255,
							t % 6 / 5 * 255
						];
					}, a.rgb.hex = function(e) {
						let t = (((255 & Math.round(e[0])) << 16) + ((255 & Math.round(e[1])) << 8) + (255 & Math.round(e[2]))).toString(16).toUpperCase();
						return "000000".substring(t.length) + t;
					}, a.hex.rgb = function(e) {
						let t = e.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
						if (!t) return [
							0,
							0,
							0
						];
						let n = t[0];
						t[0].length === 3 && (n = n.split("").map((e) => e + e).join(""));
						let r = parseInt(n, 16);
						return [
							r >> 16 & 255,
							r >> 8 & 255,
							255 & r
						];
					}, a.rgb.hcg = function(e) {
						let t = e[0] / 255, n = e[1] / 255, r = e[2] / 255, i = Math.max(Math.max(t, n), r), a = Math.min(Math.min(t, n), r), o = i - a, s, c;
						return s = o < 1 ? a / (1 - o) : 0, c = o <= 0 ? 0 : i === t ? (n - r) / o % 6 : i === n ? 2 + (r - t) / o : 4 + (t - n) / o, c /= 6, c %= 1, [
							360 * c,
							100 * o,
							100 * s
						];
					}, a.hsl.hcg = function(e) {
						let t = e[1] / 100, n = e[2] / 100, r = n < .5 ? 2 * t * n : 2 * t * (1 - n), i = 0;
						return r < 1 && (i = (n - .5 * r) / (1 - r)), [
							e[0],
							100 * r,
							100 * i
						];
					}, a.hsv.hcg = function(e) {
						let t = e[1] / 100, n = e[2] / 100, r = t * n, i = 0;
						return r < 1 && (i = (n - r) / (1 - r)), [
							e[0],
							100 * r,
							100 * i
						];
					}, a.hcg.rgb = function(e) {
						let t = e[0] / 360, n = e[1] / 100, r = e[2] / 100;
						if (n === 0) return [
							255 * r,
							255 * r,
							255 * r
						];
						let i = [
							0,
							0,
							0
						], a = t % 1 * 6, o = a % 1, s = 1 - o, c = 0;
						switch (Math.floor(a)) {
							case 0:
								i[0] = 1, i[1] = o, i[2] = 0;
								break;
							case 1:
								i[0] = s, i[1] = 1, i[2] = 0;
								break;
							case 2:
								i[0] = 0, i[1] = 1, i[2] = o;
								break;
							case 3:
								i[0] = 0, i[1] = s, i[2] = 1;
								break;
							case 4:
								i[0] = o, i[1] = 0, i[2] = 1;
								break;
							default: i[0] = 1, i[1] = 0, i[2] = s;
						}
						return c = (1 - n) * r, [
							255 * (n * i[0] + c),
							255 * (n * i[1] + c),
							255 * (n * i[2] + c)
						];
					}, a.hcg.hsv = function(e) {
						let t = e[1] / 100, n = t + e[2] / 100 * (1 - t), r = 0;
						return n > 0 && (r = t / n), [
							e[0],
							100 * r,
							100 * n
						];
					}, a.hcg.hsl = function(e) {
						let t = e[1] / 100, n = e[2] / 100 * (1 - t) + .5 * t, r = 0;
						return n > 0 && n < .5 ? r = t / (2 * n) : n >= .5 && n < 1 && (r = t / (2 * (1 - n))), [
							e[0],
							100 * r,
							100 * n
						];
					}, a.hcg.hwb = function(e) {
						let t = e[1] / 100, n = t + e[2] / 100 * (1 - t);
						return [
							e[0],
							100 * (n - t),
							100 * (1 - n)
						];
					}, a.hwb.hcg = function(e) {
						let t = e[1] / 100, n = 1 - e[2] / 100, r = n - t, i = 0;
						return r < 1 && (i = (n - r) / (1 - r)), [
							e[0],
							100 * r,
							100 * i
						];
					}, a.apple.rgb = function(e) {
						return [
							e[0] / 65535 * 255,
							e[1] / 65535 * 255,
							e[2] / 65535 * 255
						];
					}, a.rgb.apple = function(e) {
						return [
							e[0] / 255 * 65535,
							e[1] / 255 * 65535,
							e[2] / 255 * 65535
						];
					}, a.gray.rgb = function(e) {
						return [
							e[0] / 100 * 255,
							e[0] / 100 * 255,
							e[0] / 100 * 255
						];
					}, a.gray.hsl = function(e) {
						return [
							0,
							0,
							e[0]
						];
					}, a.gray.hsv = a.gray.hsl, a.gray.hwb = function(e) {
						return [
							0,
							100,
							e[0]
						];
					}, a.gray.cmyk = function(e) {
						return [
							0,
							0,
							0,
							e[0]
						];
					}, a.gray.lab = function(e) {
						return [
							e[0],
							0,
							0
						];
					}, a.gray.hex = function(e) {
						let t = 255 & Math.round(e[0] / 100 * 255), n = ((t << 16) + (t << 8) + t).toString(16).toUpperCase();
						return "000000".substring(n.length) + n;
					}, a.rgb.gray = function(e) {
						return [(e[0] + e[1] + e[2]) / 3 / 255 * 100];
					};
				},
				880(e, t, n) {
					let r = n(165), i = n(985), a = {};
					Object.keys(r).forEach((e) => {
						a[e] = {}, Object.defineProperty(a[e], "channels", { value: r[e].channels }), Object.defineProperty(a[e], "labels", { value: r[e].labels });
						let t = i(e);
						Object.keys(t).forEach((n) => {
							let r = t[n];
							a[e][n] = function(e) {
								let t = function(...t) {
									let n = t[0];
									if (n == null) return n;
									n.length > 1 && (t = n);
									let r = e(t);
									if (typeof r == "object") for (let e = r.length, t = 0; t < e; t++) r[t] = Math.round(r[t]);
									return r;
								};
								return "conversion" in e && (t.conversion = e.conversion), t;
							}(r), a[e][n].raw = function(e) {
								let t = function(...t) {
									let n = t[0];
									return n == null ? n : (n.length > 1 && (t = n), e(t));
								};
								return "conversion" in e && (t.conversion = e.conversion), t;
							}(r);
						});
					}), e.exports = a;
				},
				985(e, t, n) {
					let r = n(165);
					function i(e) {
						let t = function() {
							let e = {}, t = Object.keys(r);
							for (let n = t.length, r = 0; r < n; r++) e[t[r]] = {
								distance: -1,
								parent: null
							};
							return e;
						}(), n = [e];
						for (t[e].distance = 0; n.length;) {
							let e = n.pop(), i = Object.keys(r[e]);
							for (let r = i.length, a = 0; a < r; a++) {
								let r = i[a], o = t[r];
								o.distance === -1 && (o.distance = t[e].distance + 1, o.parent = e, n.unshift(r));
							}
						}
						return t;
					}
					function a(e, t) {
						return function(n) {
							return t(e(n));
						};
					}
					function o(e, t) {
						let n = [t[e].parent, e], i = r[t[e].parent][e], o = t[e].parent;
						for (; t[o].parent;) n.unshift(t[o].parent), i = a(r[t[o].parent][o], i), o = t[o].parent;
						return i.conversion = n, i;
					}
					e.exports = function(e) {
						let t = i(e), n = {}, r = Object.keys(t);
						for (let e = r.length, i = 0; i < e; i++) {
							let e = r[i];
							t[e].parent !== null && (n[e] = o(e, t));
						}
						return n;
					};
				},
				877(e) {
					e.exports = {
						aliceblue: [
							240,
							248,
							255
						],
						antiquewhite: [
							250,
							235,
							215
						],
						aqua: [
							0,
							255,
							255
						],
						aquamarine: [
							127,
							255,
							212
						],
						azure: [
							240,
							255,
							255
						],
						beige: [
							245,
							245,
							220
						],
						bisque: [
							255,
							228,
							196
						],
						black: [
							0,
							0,
							0
						],
						blanchedalmond: [
							255,
							235,
							205
						],
						blue: [
							0,
							0,
							255
						],
						blueviolet: [
							138,
							43,
							226
						],
						brown: [
							165,
							42,
							42
						],
						burlywood: [
							222,
							184,
							135
						],
						cadetblue: [
							95,
							158,
							160
						],
						chartreuse: [
							127,
							255,
							0
						],
						chocolate: [
							210,
							105,
							30
						],
						coral: [
							255,
							127,
							80
						],
						cornflowerblue: [
							100,
							149,
							237
						],
						cornsilk: [
							255,
							248,
							220
						],
						crimson: [
							220,
							20,
							60
						],
						cyan: [
							0,
							255,
							255
						],
						darkblue: [
							0,
							0,
							139
						],
						darkcyan: [
							0,
							139,
							139
						],
						darkgoldenrod: [
							184,
							134,
							11
						],
						darkgray: [
							169,
							169,
							169
						],
						darkgreen: [
							0,
							100,
							0
						],
						darkgrey: [
							169,
							169,
							169
						],
						darkkhaki: [
							189,
							183,
							107
						],
						darkmagenta: [
							139,
							0,
							139
						],
						darkolivegreen: [
							85,
							107,
							47
						],
						darkorange: [
							255,
							140,
							0
						],
						darkorchid: [
							153,
							50,
							204
						],
						darkred: [
							139,
							0,
							0
						],
						darksalmon: [
							233,
							150,
							122
						],
						darkseagreen: [
							143,
							188,
							143
						],
						darkslateblue: [
							72,
							61,
							139
						],
						darkslategray: [
							47,
							79,
							79
						],
						darkslategrey: [
							47,
							79,
							79
						],
						darkturquoise: [
							0,
							206,
							209
						],
						darkviolet: [
							148,
							0,
							211
						],
						deeppink: [
							255,
							20,
							147
						],
						deepskyblue: [
							0,
							191,
							255
						],
						dimgray: [
							105,
							105,
							105
						],
						dimgrey: [
							105,
							105,
							105
						],
						dodgerblue: [
							30,
							144,
							255
						],
						firebrick: [
							178,
							34,
							34
						],
						floralwhite: [
							255,
							250,
							240
						],
						forestgreen: [
							34,
							139,
							34
						],
						fuchsia: [
							255,
							0,
							255
						],
						gainsboro: [
							220,
							220,
							220
						],
						ghostwhite: [
							248,
							248,
							255
						],
						gold: [
							255,
							215,
							0
						],
						goldenrod: [
							218,
							165,
							32
						],
						gray: [
							128,
							128,
							128
						],
						green: [
							0,
							128,
							0
						],
						greenyellow: [
							173,
							255,
							47
						],
						grey: [
							128,
							128,
							128
						],
						honeydew: [
							240,
							255,
							240
						],
						hotpink: [
							255,
							105,
							180
						],
						indianred: [
							205,
							92,
							92
						],
						indigo: [
							75,
							0,
							130
						],
						ivory: [
							255,
							255,
							240
						],
						khaki: [
							240,
							230,
							140
						],
						lavender: [
							230,
							230,
							250
						],
						lavenderblush: [
							255,
							240,
							245
						],
						lawngreen: [
							124,
							252,
							0
						],
						lemonchiffon: [
							255,
							250,
							205
						],
						lightblue: [
							173,
							216,
							230
						],
						lightcoral: [
							240,
							128,
							128
						],
						lightcyan: [
							224,
							255,
							255
						],
						lightgoldenrodyellow: [
							250,
							250,
							210
						],
						lightgray: [
							211,
							211,
							211
						],
						lightgreen: [
							144,
							238,
							144
						],
						lightgrey: [
							211,
							211,
							211
						],
						lightpink: [
							255,
							182,
							193
						],
						lightsalmon: [
							255,
							160,
							122
						],
						lightseagreen: [
							32,
							178,
							170
						],
						lightskyblue: [
							135,
							206,
							250
						],
						lightslategray: [
							119,
							136,
							153
						],
						lightslategrey: [
							119,
							136,
							153
						],
						lightsteelblue: [
							176,
							196,
							222
						],
						lightyellow: [
							255,
							255,
							224
						],
						lime: [
							0,
							255,
							0
						],
						limegreen: [
							50,
							205,
							50
						],
						linen: [
							250,
							240,
							230
						],
						magenta: [
							255,
							0,
							255
						],
						maroon: [
							128,
							0,
							0
						],
						mediumaquamarine: [
							102,
							205,
							170
						],
						mediumblue: [
							0,
							0,
							205
						],
						mediumorchid: [
							186,
							85,
							211
						],
						mediumpurple: [
							147,
							112,
							219
						],
						mediumseagreen: [
							60,
							179,
							113
						],
						mediumslateblue: [
							123,
							104,
							238
						],
						mediumspringgreen: [
							0,
							250,
							154
						],
						mediumturquoise: [
							72,
							209,
							204
						],
						mediumvioletred: [
							199,
							21,
							133
						],
						midnightblue: [
							25,
							25,
							112
						],
						mintcream: [
							245,
							255,
							250
						],
						mistyrose: [
							255,
							228,
							225
						],
						moccasin: [
							255,
							228,
							181
						],
						navajowhite: [
							255,
							222,
							173
						],
						navy: [
							0,
							0,
							128
						],
						oldlace: [
							253,
							245,
							230
						],
						olive: [
							128,
							128,
							0
						],
						olivedrab: [
							107,
							142,
							35
						],
						orange: [
							255,
							165,
							0
						],
						orangered: [
							255,
							69,
							0
						],
						orchid: [
							218,
							112,
							214
						],
						palegoldenrod: [
							238,
							232,
							170
						],
						palegreen: [
							152,
							251,
							152
						],
						paleturquoise: [
							175,
							238,
							238
						],
						palevioletred: [
							219,
							112,
							147
						],
						papayawhip: [
							255,
							239,
							213
						],
						peachpuff: [
							255,
							218,
							185
						],
						peru: [
							205,
							133,
							63
						],
						pink: [
							255,
							192,
							203
						],
						plum: [
							221,
							160,
							221
						],
						powderblue: [
							176,
							224,
							230
						],
						purple: [
							128,
							0,
							128
						],
						rebeccapurple: [
							102,
							51,
							153
						],
						red: [
							255,
							0,
							0
						],
						rosybrown: [
							188,
							143,
							143
						],
						royalblue: [
							65,
							105,
							225
						],
						saddlebrown: [
							139,
							69,
							19
						],
						salmon: [
							250,
							128,
							114
						],
						sandybrown: [
							244,
							164,
							96
						],
						seagreen: [
							46,
							139,
							87
						],
						seashell: [
							255,
							245,
							238
						],
						sienna: [
							160,
							82,
							45
						],
						silver: [
							192,
							192,
							192
						],
						skyblue: [
							135,
							206,
							235
						],
						slateblue: [
							106,
							90,
							205
						],
						slategray: [
							112,
							128,
							144
						],
						slategrey: [
							112,
							128,
							144
						],
						snow: [
							255,
							250,
							250
						],
						springgreen: [
							0,
							255,
							127
						],
						steelblue: [
							70,
							130,
							180
						],
						tan: [
							210,
							180,
							140
						],
						teal: [
							0,
							128,
							128
						],
						thistle: [
							216,
							191,
							216
						],
						tomato: [
							255,
							99,
							71
						],
						turquoise: [
							64,
							224,
							208
						],
						violet: [
							238,
							130,
							238
						],
						wheat: [
							245,
							222,
							179
						],
						white: [
							255,
							255,
							255
						],
						whitesmoke: [
							245,
							245,
							245
						],
						yellow: [
							255,
							255,
							0
						],
						yellowgreen: [
							154,
							205,
							50
						]
					};
				},
				138(e, t, n) {
					var r = n(877), i = n(403), a = Object.hasOwnProperty, o = /* @__PURE__ */ Object.create(null);
					for (var s in r) a.call(r, s) && (o[r[s]] = s);
					var c = e.exports = {
						to: {},
						get: {}
					};
					function l(e, t, n) {
						return Math.min(Math.max(t, e), n);
					}
					function u(e) {
						var t = Math.round(e).toString(16).toUpperCase();
						return t.length < 2 ? "0" + t : t;
					}
					c.get = function(e) {
						var t, n;
						switch (e.substring(0, 3).toLowerCase()) {
							case "hsl":
								t = c.get.hsl(e), n = "hsl";
								break;
							case "hwb":
								t = c.get.hwb(e), n = "hwb";
								break;
							default: t = c.get.rgb(e), n = "rgb";
						}
						return t ? {
							model: n,
							value: t
						} : null;
					}, c.get.rgb = function(e) {
						if (!e) return null;
						var t, n, i, o = [
							0,
							0,
							0,
							1
						];
						if (t = e.match(/^#([a-f0-9]{6})([a-f0-9]{2})?$/i)) {
							for (i = t[2], t = t[1], n = 0; n < 3; n++) {
								var s = 2 * n;
								o[n] = parseInt(t.slice(s, s + 2), 16);
							}
							i && (o[3] = parseInt(i, 16) / 255);
						} else if (t = e.match(/^#([a-f0-9]{3,4})$/i)) {
							for (i = (t = t[1])[3], n = 0; n < 3; n++) o[n] = parseInt(t[n] + t[n], 16);
							i && (o[3] = parseInt(i + i, 16) / 255);
						} else if (t = e.match(/^rgba?\(\s*([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)\s*(?:[,|\/]\s*([+-]?[\d\.]+)(%?)\s*)?\)$/)) {
							for (n = 0; n < 3; n++) o[n] = parseInt(t[n + 1], 0);
							t[4] && (t[5] ? o[3] = .01 * parseFloat(t[4]) : o[3] = parseFloat(t[4]));
						} else {
							if (!(t = e.match(/^rgba?\(\s*([+-]?[\d\.]+)\%\s*,?\s*([+-]?[\d\.]+)\%\s*,?\s*([+-]?[\d\.]+)\%\s*(?:[,|\/]\s*([+-]?[\d\.]+)(%?)\s*)?\)$/))) return (t = e.match(/^(\w+)$/)) ? t[1] === "transparent" ? [
								0,
								0,
								0,
								0
							] : a.call(r, t[1]) ? ((o = r[t[1]])[3] = 1, o) : null : null;
							for (n = 0; n < 3; n++) o[n] = Math.round(2.55 * parseFloat(t[n + 1]));
							t[4] && (t[5] ? o[3] = .01 * parseFloat(t[4]) : o[3] = parseFloat(t[4]));
						}
						for (n = 0; n < 3; n++) o[n] = l(o[n], 0, 255);
						return o[3] = l(o[3], 0, 1), o;
					}, c.get.hsl = function(e) {
						if (!e) return null;
						var t = e.match(/^hsla?\(\s*([+-]?(?:\d{0,3}\.)?\d+)(?:deg)?\s*,?\s*([+-]?[\d\.]+)%\s*,?\s*([+-]?[\d\.]+)%\s*(?:[,|\/]\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:[eE][+-]?\d+)?)\s*)?\)$/);
						if (t) {
							var n = parseFloat(t[4]);
							return [
								(parseFloat(t[1]) % 360 + 360) % 360,
								l(parseFloat(t[2]), 0, 100),
								l(parseFloat(t[3]), 0, 100),
								l(isNaN(n) ? 1 : n, 0, 1)
							];
						}
						return null;
					}, c.get.hwb = function(e) {
						if (!e) return null;
						var t = e.match(/^hwb\(\s*([+-]?\d{0,3}(?:\.\d+)?)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:[eE][+-]?\d+)?)\s*)?\)$/);
						if (t) {
							var n = parseFloat(t[4]);
							return [
								(parseFloat(t[1]) % 360 + 360) % 360,
								l(parseFloat(t[2]), 0, 100),
								l(parseFloat(t[3]), 0, 100),
								l(isNaN(n) ? 1 : n, 0, 1)
							];
						}
						return null;
					}, c.to.hex = function() {
						var e = i(arguments);
						return "#" + u(e[0]) + u(e[1]) + u(e[2]) + (e[3] < 1 ? u(Math.round(255 * e[3])) : "");
					}, c.to.rgb = function() {
						var e = i(arguments);
						return e.length < 4 || e[3] === 1 ? "rgb(" + Math.round(e[0]) + ", " + Math.round(e[1]) + ", " + Math.round(e[2]) + ")" : "rgba(" + Math.round(e[0]) + ", " + Math.round(e[1]) + ", " + Math.round(e[2]) + ", " + e[3] + ")";
					}, c.to.rgb.percent = function() {
						var e = i(arguments), t = Math.round(e[0] / 255 * 100), n = Math.round(e[1] / 255 * 100), r = Math.round(e[2] / 255 * 100);
						return e.length < 4 || e[3] === 1 ? "rgb(" + t + "%, " + n + "%, " + r + "%)" : "rgba(" + t + "%, " + n + "%, " + r + "%, " + e[3] + ")";
					}, c.to.hsl = function() {
						var e = i(arguments);
						return e.length < 4 || e[3] === 1 ? "hsl(" + e[0] + ", " + e[1] + "%, " + e[2] + "%)" : "hsla(" + e[0] + ", " + e[1] + "%, " + e[2] + "%, " + e[3] + ")";
					}, c.to.hwb = function() {
						var e = i(arguments), t = "";
						return e.length >= 4 && e[3] !== 1 && (t = ", " + e[3]), "hwb(" + e[0] + ", " + e[1] + "%, " + e[2] + "%" + t + ")";
					}, c.to.keyword = function(e) {
						return o[e.slice(0, 3)];
					};
				},
				742(e, t, n) {
					let r = n(138), i = n(880), a = [
						"keyword",
						"gray",
						"hex"
					], o = {};
					for (let e of Object.keys(i)) o[[...i[e].labels].sort().join("")] = e;
					let s = {};
					function c(e, t) {
						if (!(this instanceof c)) return new c(e, t);
						if (t && t in a && (t = null), t && !(t in i)) throw Error("Unknown model: " + t);
						let n, l;
						if (e == null) this.model = "rgb", this.color = [
							0,
							0,
							0
						], this.valpha = 1;
						else if (e instanceof c) this.model = e.model, this.color = [...e.color], this.valpha = e.valpha;
						else if (typeof e == "string") {
							let t = r.get(e);
							if (t === null) throw Error("Unable to parse color from string: " + e);
							this.model = t.model, l = i[this.model].channels, this.color = t.value.slice(0, l), this.valpha = typeof t.value[l] == "number" ? t.value[l] : 1;
						} else if (e.length > 0) {
							this.model = t || "rgb", l = i[this.model].channels;
							let n = Array.prototype.slice.call(e, 0, l);
							this.color = f(n, l), this.valpha = typeof e[l] == "number" ? e[l] : 1;
						} else if (typeof e == "number") this.model = "rgb", this.color = [
							e >> 16 & 255,
							e >> 8 & 255,
							255 & e
						], this.valpha = 1;
						else {
							this.valpha = 1;
							let t = Object.keys(e);
							"alpha" in e && (t.splice(t.indexOf("alpha"), 1), this.valpha = typeof e.alpha == "number" ? e.alpha : 0);
							let r = t.sort().join("");
							if (!(r in o)) throw Error("Unable to parse color from object: " + JSON.stringify(e));
							this.model = o[r];
							let { labels: a } = i[this.model], s = [];
							for (n = 0; n < a.length; n++) s.push(e[a[n]]);
							this.color = f(s);
						}
						if (s[this.model]) for (l = i[this.model].channels, n = 0; n < l; n++) {
							let e = s[this.model][n];
							e && (this.color[n] = e(this.color[n]));
						}
						this.valpha = Math.max(0, Math.min(1, this.valpha)), Object.freeze && Object.freeze(this);
					}
					c.prototype = {
						toString() {
							return this.string();
						},
						toJSON() {
							return this[this.model]();
						},
						string(e) {
							let t = this.model in r.to ? this : this.rgb();
							t = t.round(typeof e == "number" ? e : 1);
							let n = t.valpha === 1 ? t.color : [...t.color, this.valpha];
							return r.to[t.model](n);
						},
						percentString(e) {
							let t = this.rgb().round(typeof e == "number" ? e : 1), n = t.valpha === 1 ? t.color : [...t.color, this.valpha];
							return r.to.rgb.percent(n);
						},
						array() {
							return this.valpha === 1 ? [...this.color] : [...this.color, this.valpha];
						},
						object() {
							let e = {}, { channels: t } = i[this.model], { labels: n } = i[this.model];
							for (let r = 0; r < t; r++) e[n[r]] = this.color[r];
							return this.valpha !== 1 && (e.alpha = this.valpha), e;
						},
						unitArray() {
							let e = this.rgb().color;
							return e[0] /= 255, e[1] /= 255, e[2] /= 255, this.valpha !== 1 && e.push(this.valpha), e;
						},
						unitObject() {
							let e = this.rgb().object();
							return e.r /= 255, e.g /= 255, e.b /= 255, this.valpha !== 1 && (e.alpha = this.valpha), e;
						},
						round(e) {
							return e = Math.max(e || 0, 0), new c([...this.color.map(l(e)), this.valpha], this.model);
						},
						alpha(e) {
							return e === void 0 ? this.valpha : new c([...this.color, Math.max(0, Math.min(1, e))], this.model);
						},
						red: u("rgb", 0, d(255)),
						green: u("rgb", 1, d(255)),
						blue: u("rgb", 2, d(255)),
						hue: u([
							"hsl",
							"hsv",
							"hsl",
							"hwb",
							"hcg"
						], 0, (e) => (e % 360 + 360) % 360),
						saturationl: u("hsl", 1, d(100)),
						lightness: u("hsl", 2, d(100)),
						saturationv: u("hsv", 1, d(100)),
						value: u("hsv", 2, d(100)),
						chroma: u("hcg", 1, d(100)),
						gray: u("hcg", 2, d(100)),
						white: u("hwb", 1, d(100)),
						wblack: u("hwb", 2, d(100)),
						cyan: u("cmyk", 0, d(100)),
						magenta: u("cmyk", 1, d(100)),
						yellow: u("cmyk", 2, d(100)),
						black: u("cmyk", 3, d(100)),
						x: u("xyz", 0, d(95.047)),
						y: u("xyz", 1, d(100)),
						z: u("xyz", 2, d(108.833)),
						l: u("lab", 0, d(100)),
						a: u("lab", 1),
						b: u("lab", 2),
						keyword(e) {
							return e === void 0 ? i[this.model].keyword(this.color) : new c(e);
						},
						hex(e) {
							return e === void 0 ? r.to.hex(this.rgb().round().color) : new c(e);
						},
						hexa(e) {
							if (e !== void 0) return new c(e);
							let t = this.rgb().round().color, n = Math.round(255 * this.valpha).toString(16).toUpperCase();
							return n.length === 1 && (n = "0" + n), r.to.hex(t) + n;
						},
						rgbNumber() {
							let e = this.rgb().color;
							return (255 & e[0]) << 16 | (255 & e[1]) << 8 | 255 & e[2];
						},
						luminosity() {
							let e = this.rgb().color, t = [];
							for (let [n, r] of e.entries()) {
								let e = r / 255;
								t[n] = e <= .04045 ? e / 12.92 : ((e + .055) / 1.055) ** 2.4;
							}
							return .2126 * t[0] + .7152 * t[1] + .0722 * t[2];
						},
						contrast(e) {
							let t = this.luminosity(), n = e.luminosity();
							return t > n ? (t + .05) / (n + .05) : (n + .05) / (t + .05);
						},
						level(e) {
							let t = this.contrast(e);
							return t >= 7 ? "AAA" : t >= 4.5 ? "AA" : "";
						},
						isDark() {
							let e = this.rgb().color;
							return (2126 * e[0] + 7152 * e[1] + 722 * e[2]) / 1e4 < 128;
						},
						isLight() {
							return !this.isDark();
						},
						negate() {
							let e = this.rgb();
							for (let t = 0; t < 3; t++) e.color[t] = 255 - e.color[t];
							return e;
						},
						lighten(e) {
							let t = this.hsl();
							return t.color[2] += t.color[2] * e, t;
						},
						darken(e) {
							let t = this.hsl();
							return t.color[2] -= t.color[2] * e, t;
						},
						saturate(e) {
							let t = this.hsl();
							return t.color[1] += t.color[1] * e, t;
						},
						desaturate(e) {
							let t = this.hsl();
							return t.color[1] -= t.color[1] * e, t;
						},
						whiten(e) {
							let t = this.hwb();
							return t.color[1] += t.color[1] * e, t;
						},
						blacken(e) {
							let t = this.hwb();
							return t.color[2] += t.color[2] * e, t;
						},
						grayscale() {
							let e = this.rgb().color, t = .3 * e[0] + .59 * e[1] + .11 * e[2];
							return c.rgb(t, t, t);
						},
						fade(e) {
							return this.alpha(this.valpha - this.valpha * e);
						},
						opaquer(e) {
							return this.alpha(this.valpha + this.valpha * e);
						},
						rotate(e) {
							let t = this.hsl(), n = t.color[0];
							return n = (n + e) % 360, n = n < 0 ? 360 + n : n, t.color[0] = n, t;
						},
						mix(e, t) {
							if (!e || !e.rgb) throw Error("Argument to \"mix\" was not a Color instance, but rather an instance of " + typeof e);
							let n = e.rgb(), r = this.rgb(), i = t === void 0 ? .5 : t, a = 2 * i - 1, o = n.alpha() - r.alpha(), s = ((a * o === -1 ? a : (a + o) / (1 + a * o)) + 1) / 2, l = 1 - s;
							return c.rgb(s * n.red() + l * r.red(), s * n.green() + l * r.green(), s * n.blue() + l * r.blue(), n.alpha() * i + r.alpha() * (1 - i));
						}
					};
					for (let e of Object.keys(i)) {
						if (a.includes(e)) continue;
						let { channels: t } = i[e];
						c.prototype[e] = function(...t) {
							return this.model === e ? new c(this) : t.length > 0 ? new c(t, e) : new c([...(n = i[this.model][e].raw(this.color), Array.isArray(n) ? n : [n]), this.valpha], e);
							var n;
						}, c[e] = function(...n) {
							let r = n[0];
							return typeof r == "number" && (r = f(n, t)), new c(r, e);
						};
					}
					function l(e) {
						return function(t) {
							return function(e, t) {
								return Number(e.toFixed(t));
							}(t, e);
						};
					}
					function u(e, t, n) {
						e = Array.isArray(e) ? e : [e];
						for (let r of e) (s[r] || (s[r] = []))[t] = n;
						return e = e[0], function(r) {
							let i;
							return r === void 0 ? (i = this[e]().color[t], n && (i = n(i)), i) : (n && (r = n(r)), i = this[e](), i.color[t] = r, i);
						};
					}
					function d(e) {
						return function(t) {
							return Math.max(0, Math.min(e, t));
						};
					}
					function f(e, t) {
						for (let n = 0; n < t; n++) typeof e[n] != "number" && (e[n] = 0);
						return e;
					}
					e.exports = c;
				},
				94(e) {
					e.exports = function(e) {
						return !(!e || typeof e == "string") && (e instanceof Array || Array.isArray(e) || e.length >= 0 && (e.splice instanceof Function || Object.getOwnPropertyDescriptor(e, e.length - 1) && e.constructor.name !== "String"));
					};
				},
				403(e, t, n) {
					var r = n(94), i = Array.prototype.concat, a = Array.prototype.slice, o = e.exports = function(e) {
						for (var t = [], n = 0, o = e.length; n < o; n++) {
							var s = e[n];
							r(s) ? t = i.call(t, a.call(s)) : t.push(s);
						}
						return t;
					};
					o.wrap = function(e) {
						return function() {
							return e(o(arguments));
						};
					};
				},
				119(t) {
					t.exports = e;
				}
			};
			let n = {};
			function i(e) {
				let r = n[e];
				if (r !== void 0) return r.exports;
				let a = n[e] = { exports: {} };
				return t[e](a, a.exports, i), a.exports;
			}
			i.n = (e) => {
				let t = e && e.__esModule ? () => e.default : () => e;
				return i.d(t, { a: t }), t;
			}, i.cw = (e) => {
				var t;
				return () => {
					if (e) {
						var n = e;
						e = 0, t = { exports: {} }, n.call(t.exports, t, t.exports);
					}
					return t.exports;
				};
			}, i.d = (e, t) => {
				for (var n in t) i.o(t, n) && !i.o(e, n) && Object.defineProperty(e, n, {
					enumerable: !0,
					get: t[n]
				});
			}, i.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), i.r = (e) => {
				Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
			};
			let a = {};
			return (() => {
				i.r(a), i.d(a, { default: () => Kn });
				var e = i.cw(function(e, t) {
					var n, r = typeof Reflect == "object" ? Reflect : null, i = r && typeof r.apply == "function" ? r.apply : function(e, t, n) {
						return Function.prototype.apply.call(e, t, n);
					};
					n = r && typeof r.ownKeys == "function" ? r.ownKeys : Object.getOwnPropertySymbols ? function(e) {
						return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e));
					} : function(e) {
						return Object.getOwnPropertyNames(e);
					};
					var a = Number.isNaN || function(e) {
						return e != e;
					};
					function o() {
						o.init.call(this);
					}
					e.exports = o, e.exports.once = function(e, t) {
						return new Promise(function(n, r) {
							function i(n) {
								e.removeListener(t, a), r(n);
							}
							function a() {
								typeof e.removeListener == "function" && e.removeListener("error", i), n([].slice.call(arguments));
							}
							g(e, t, a, { once: !0 }), t !== "error" && function(e, t, n) {
								typeof e.on == "function" && g(e, "error", t, n);
							}(e, i, { once: !0 });
						});
					}, o.EventEmitter = o, o.prototype._events = void 0, o.prototype._eventsCount = 0, o.prototype._maxListeners = void 0;
					var s = 10;
					function c(e) {
						if (typeof e != "function") throw TypeError("The \"listener\" argument must be of type Function. Received type " + typeof e);
					}
					function l(e) {
						return e._maxListeners === void 0 ? o.defaultMaxListeners : e._maxListeners;
					}
					function u(e, t, n, r) {
						var i, a, o, s;
						if (c(n), (a = e._events) === void 0 ? (a = e._events = /* @__PURE__ */ Object.create(null), e._eventsCount = 0) : (a.newListener !== void 0 && (e.emit("newListener", t, n.listener ? n.listener : n), a = e._events), o = a[t]), o === void 0) o = a[t] = n, ++e._eventsCount;
						else if (typeof o == "function" ? o = a[t] = r ? [n, o] : [o, n] : r ? o.unshift(n) : o.push(n), (i = l(e)) > 0 && o.length > i && !o.warned) {
							o.warned = !0;
							var u = /* @__PURE__ */ Error("Possible EventEmitter memory leak detected. " + o.length + " " + String(t) + " listeners added. Use emitter.setMaxListeners() to increase limit");
							u.name = "MaxListenersExceededWarning", u.emitter = e, u.type = t, u.count = o.length, s = u, console && console.warn && console.warn(s);
						}
						return e;
					}
					function d() {
						if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
					}
					function f(e, t, n) {
						var r = {
							fired: !1,
							wrapFn: void 0,
							target: e,
							type: t,
							listener: n
						}, i = d.bind(r);
						return i.listener = n, r.wrapFn = i, i;
					}
					function p(e, t, n) {
						var r = e._events;
						if (r === void 0) return [];
						var i = r[t];
						return i === void 0 ? [] : typeof i == "function" ? n ? [i.listener || i] : [i] : n ? function(e) {
							for (var t = Array(e.length), n = 0; n < t.length; ++n) t[n] = e[n].listener || e[n];
							return t;
						}(i) : h(i, i.length);
					}
					function m(e) {
						var t = this._events;
						if (t !== void 0) {
							var n = t[e];
							if (typeof n == "function") return 1;
							if (n !== void 0) return n.length;
						}
						return 0;
					}
					function h(e, t) {
						for (var n = Array(t), r = 0; r < t; ++r) n[r] = e[r];
						return n;
					}
					function g(e, t, n, r) {
						if (typeof e.on == "function") r.once ? e.once(t, n) : e.on(t, n);
						else {
							if (typeof e.addEventListener != "function") throw TypeError("The \"emitter\" argument must be of type EventEmitter. Received type " + typeof e);
							e.addEventListener(t, function i(a) {
								r.once && e.removeEventListener(t, i), n(a);
							});
						}
					}
					Object.defineProperty(o, "defaultMaxListeners", {
						enumerable: !0,
						get: function() {
							return s;
						},
						set: function(e) {
							if (typeof e != "number" || e < 0 || a(e)) throw RangeError("The value of \"defaultMaxListeners\" is out of range. It must be a non-negative number. Received " + e + ".");
							s = e;
						}
					}), o.init = function() {
						this._events !== void 0 && this._events !== Object.getPrototypeOf(this)._events || (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
					}, o.prototype.setMaxListeners = function(e) {
						if (typeof e != "number" || e < 0 || a(e)) throw RangeError("The value of \"n\" is out of range. It must be a non-negative number. Received " + e + ".");
						return this._maxListeners = e, this;
					}, o.prototype.getMaxListeners = function() {
						return l(this);
					}, o.prototype.emit = function(e) {
						for (var t = [], n = 1; n < arguments.length; n++) t.push(arguments[n]);
						var r = e === "error", a = this._events;
						if (a !== void 0) r &&= a.error === void 0;
						else if (!r) return !1;
						if (r) {
							var o;
							if (t.length > 0 && (o = t[0]), o instanceof Error) throw o;
							var s = /* @__PURE__ */ Error("Unhandled error." + (o ? " (" + o.message + ")" : ""));
							throw s.context = o, s;
						}
						var c = a[e];
						if (c === void 0) return !1;
						if (typeof c == "function") i(c, this, t);
						else {
							var l = c.length, u = h(c, l);
							for (n = 0; n < l; ++n) i(u[n], this, t);
						}
						return !0;
					}, o.prototype.addListener = function(e, t) {
						return u(this, e, t, !1);
					}, o.prototype.on = o.prototype.addListener, o.prototype.prependListener = function(e, t) {
						return u(this, e, t, !0);
					}, o.prototype.once = function(e, t) {
						return c(t), this.on(e, f(this, e, t)), this;
					}, o.prototype.prependOnceListener = function(e, t) {
						return c(t), this.prependListener(e, f(this, e, t)), this;
					}, o.prototype.removeListener = function(e, t) {
						var n, r, i, a, o;
						if (c(t), (r = this._events) === void 0 || (n = r[e]) === void 0) return this;
						if (n === t || n.listener === t) --this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : (delete r[e], r.removeListener && this.emit("removeListener", e, n.listener || t));
						else if (typeof n != "function") {
							for (i = -1, a = n.length - 1; a >= 0; a--) if (n[a] === t || n[a].listener === t) {
								o = n[a].listener, i = a;
								break;
							}
							if (i < 0) return this;
							i === 0 ? n.shift() : function(e, t) {
								for (; t + 1 < e.length; t++) e[t] = e[t + 1];
								e.pop();
							}(n, i), n.length === 1 && (r[e] = n[0]), r.removeListener !== void 0 && this.emit("removeListener", e, o || t);
						}
						return this;
					}, o.prototype.off = o.prototype.removeListener, o.prototype.removeAllListeners = function(e) {
						var t, n, r;
						if ((n = this._events) === void 0) return this;
						if (n.removeListener === void 0) return arguments.length === 0 ? (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0) : n[e] !== void 0 && (--this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : delete n[e]), this;
						if (arguments.length === 0) {
							var i, a = Object.keys(n);
							for (r = 0; r < a.length; ++r) (i = a[r]) !== "removeListener" && this.removeAllListeners(i);
							return this.removeAllListeners("removeListener"), this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0, this;
						}
						if (typeof (t = n[e]) == "function") this.removeListener(e, t);
						else if (t !== void 0) for (r = t.length - 1; r >= 0; r--) this.removeListener(e, t[r]);
						return this;
					}, o.prototype.listeners = function(e) {
						return p(this, e, !0);
					}, o.prototype.rawListeners = function(e) {
						return p(this, e, !1);
					}, o.listenerCount = function(e, t) {
						return typeof e.listenerCount == "function" ? e.listenerCount(t) : m.call(e, t);
					}, o.prototype.listenerCount = m, o.prototype.eventNames = function() {
						return this._eventsCount > 0 ? n(this._events) : [];
					};
				}), t = i(119), n = i.n(t);
				function o() {
					var e = this.constructor.getDerivedStateFromProps(this.props, this.state);
					e != null && this.setState(e);
				}
				function s(e) {
					this.setState(function(t) {
						return this.constructor.getDerivedStateFromProps(e, t) ?? null;
					}.bind(this));
				}
				function c(e, t) {
					try {
						var n = this.props, r = this.state;
						this.props = e, this.state = t, this.__reactInternalSnapshotFlag = !0, this.__reactInternalSnapshot = this.getSnapshotBeforeUpdate(n, r);
					} finally {
						this.props = n, this.state = r;
					}
				}
				function l(e) {
					var t = e.prototype;
					if (!t || !t.isReactComponent) throw Error("Can only polyfill class components");
					if (typeof e.getDerivedStateFromProps != "function" && typeof t.getSnapshotBeforeUpdate != "function") return e;
					var n = null, r = null, i = null;
					if (typeof t.componentWillMount == "function" ? n = "componentWillMount" : typeof t.UNSAFE_componentWillMount == "function" && (n = "UNSAFE_componentWillMount"), typeof t.componentWillReceiveProps == "function" ? r = "componentWillReceiveProps" : typeof t.UNSAFE_componentWillReceiveProps == "function" && (r = "UNSAFE_componentWillReceiveProps"), typeof t.componentWillUpdate == "function" ? i = "componentWillUpdate" : typeof t.UNSAFE_componentWillUpdate == "function" && (i = "UNSAFE_componentWillUpdate"), n !== null || r !== null || i !== null) {
						var a = e.displayName || e.name, l = typeof e.getDerivedStateFromProps == "function" ? "getDerivedStateFromProps()" : "getSnapshotBeforeUpdate()";
						throw Error("Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n" + a + " uses " + l + " but also contains the following legacy lifecycles:" + (n === null ? "" : "\n  " + n) + (r === null ? "" : "\n  " + r) + (i === null ? "" : "\n  " + i) + "\n\nThe above lifecycles should be removed. Learn more about this warning here:\nhttps://fb.me/react-async-component-lifecycle-hooks");
					}
					if (typeof e.getDerivedStateFromProps == "function" && (t.componentWillMount = o, t.componentWillReceiveProps = s), typeof t.getSnapshotBeforeUpdate == "function") {
						if (typeof t.componentDidUpdate != "function") throw Error("Cannot polyfill getSnapshotBeforeUpdate() for components that do not define componentDidUpdate() on the prototype");
						t.componentWillUpdate = c;
						var u = t.componentDidUpdate;
						t.componentDidUpdate = function(e, t, n) {
							var r = this.__reactInternalSnapshotFlag ? this.__reactInternalSnapshot : n;
							u.call(this, e, t, r);
						};
					}
					return e;
				}
				function u(e, t) {
					if (t && e?.constructor === t) return "bigNumber";
					let n = function(e) {
						return {}.toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
					}(e);
					return n === "number" && (n = isNaN(e) ? "nan" : (0 | e) === e ? "integer" : "float"), n;
				}
				function d(e) {
					return e.replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/\t/g, "\\t").replace(/\r/g, "\\r").replace(/\f/g, "\\f");
				}
				o.__suppressDeprecationWarning = !0, s.__suppressDeprecationWarning = !0, c.__suppressDeprecationWarning = !0;
				let f = class extends n().PureComponent {
					render() {
						let { props: e } = this, { parent_type: t, namespace: r, quotesOnKeys: i, indentWidth: a, theme: o, singleIndent: s, showComma: c, isLast: l, jsvRoot: u } = e, d = e.name ? e.name : "";
						return n().createElement("div", { className: "variable-row" }, n().createElement("span", {
							...z(o, "object-name"),
							key: r,
							...z(o, "objectKeyVal", { paddingLeft: a * s })
						}, n().createElement("span", { className: "object-key" }, i && n().createElement("span", { style: { verticalAlign: "top" } }, "\""), n().createElement("span", null, d), i && n().createElement("span", { style: { verticalAlign: "top" } }, "\"")), n().createElement("span", z(o, "colon"), ":")), n().createElement("span", z(o, "circularReference"), "[CIRCULAR REFERENCE]"), c && !l && !u && n().createElement("span", z(o, "comma"), ","));
					}
				}, p = {
					scheme: "rjv-default",
					author: "mac gainor",
					base00: "rgba(0, 0, 0, 0)",
					base01: "rgb(245, 245, 245)",
					base02: "rgb(235, 235, 235)",
					base03: "#93a1a1",
					base04: "rgba(0, 0, 0, 0.3)",
					base05: "#586e75",
					base06: "#073642",
					base07: "#002b36",
					base08: "#d33682",
					base09: "#cb4b16",
					base0A: "#dc322f",
					base0B: "#859900",
					base0C: "#6c71c4",
					base0D: "#586e75",
					base0E: "#2aa198",
					base0F: "#268bd2"
				}, m = {
					scheme: "rjv-grey",
					author: "mac gainor",
					base00: "rgba(1, 1, 1, 0)",
					base01: "rgba(1, 1, 1, 0.1)",
					base02: "rgba(0, 0, 0, 0.2)",
					base03: "rgba(1, 1, 1, 0.3)",
					base04: "rgba(0, 0, 0, 0.4)",
					base05: "rgba(1, 1, 1, 0.5)",
					base06: "rgba(1, 1, 1, 0.6)",
					base07: "rgba(1, 1, 1, 0.7)",
					base08: "rgba(1, 1, 1, 0.8)",
					base09: "rgba(1, 1, 1, 0.8)",
					base0A: "rgba(1, 1, 1, 0.8)",
					base0B: "rgba(1, 1, 1, 0.8)",
					base0C: "rgba(1, 1, 1, 0.8)",
					base0D: "rgba(1, 1, 1, 0.8)",
					base0E: "rgba(1, 1, 1, 0.8)",
					base0F: "rgba(1, 1, 1, 0.8)"
				}, h = {
					globalFontFamily: "monospace",
					globalCursor: "default",
					braceFontWeight: "bold",
					braceCursor: "pointer",
					ellipsisFontSize: "18px",
					ellipsisLineHeight: "10px",
					ellipsisCursor: "pointer",
					keyMargin: "0px 5px",
					keyLetterSpacing: "0.5px",
					keyFontStyle: "none",
					keyVerticalAlign: "top",
					keyOpacity: "0.85",
					keyOpacityHover: "1",
					keyValPaddingTop: "3px",
					keyValPaddingBottom: "3px",
					keyValPaddingRight: "5px",
					keyValBorderLeft: "1px solid",
					keyValBorderHover: "2px solid",
					pushedContentMarginLeft: "6px",
					variableValuePaddingRight: "6px",
					nullFontSize: "11px",
					nullFontWeight: "bold",
					nullPadding: "1px 2px",
					nullBorderRadius: "3px",
					nanFontSize: "11px",
					nanFontWeight: "bold",
					nanPadding: "1px 2px",
					nanBorderRadius: "3px",
					undefinedFontSize: "11px",
					undefinedPadding: "1px 2px",
					undefinedBorderRadius: "3px",
					dataTypeFontSize: "11px",
					dataTypeMarginRight: "4px",
					datatypeOpacity: "0.8",
					objectSizeBorderRadius: "3px",
					objectSizeFontStyle: "italic",
					objectSizeMargin: "0px 6px 0px 0px",
					clipboardCursor: "pointer",
					clipboardCheckMarginLeft: "-12px",
					metaDataPadding: "0px 0px 0px 10px",
					arrayGroupMetaPadding: "0px 0px 0px 4px",
					iconContainerWidth: "17px",
					tooltipPadding: "4px",
					editInputMinWidth: "130px",
					editInputBorderRadius: "2px",
					editInputPadding: "5px",
					editInputMarginRight: "4px",
					editInputFontFamily: "monospace",
					iconCursor: "pointer",
					iconFontSize: "15px",
					iconPaddingRight: "1px",
					dateValueMarginLeft: "2px",
					iconMarginRight: "3px",
					detectedRowPaddingTop: "3px",
					addKeyCoverBackground: "rgba(255, 255, 255, 0.3)",
					addKeyCoverPosition: "absolute",
					addKeyCoverPositionPx: "0px",
					addKeyModalWidth: "200px",
					addKeyModalMargin: "auto",
					addKeyModalPadding: "10px",
					addKeyModalRadius: "3px",
					commaColor: "#666",
					commaFontSize: "12px",
					commaMarginRight: "4px"
				};
				var g = i(742);
				let _ = function(e) {
					return e;
				}, v = typeof r == "object" && r && r.Object === Object && r;
				var y = typeof self == "object" && self && self.Object === Object && self;
				let b = v || y || Function("return this")(), x = b.Symbol;
				var S = Object.prototype, ee = S.hasOwnProperty, te = S.toString, C = x ? x.toStringTag : void 0;
				let w = function(e) {
					var t = ee.call(e, C), n = e[C];
					try {
						e[C] = void 0;
						var r = !0;
					} catch {}
					var i = te.call(e);
					return r && (t ? e[C] = n : delete e[C]), i;
				};
				var ne = Object.prototype.toString;
				let re = function(e) {
					return ne.call(e);
				};
				var ie = x ? x.toStringTag : void 0;
				let ae = function(e) {
					return e == null ? e === void 0 ? "[object Undefined]" : "[object Null]" : ie && ie in Object(e) ? w(e) : re(e);
				}, T = function(e) {
					var t = typeof e;
					return e != null && (t == "object" || t == "function");
				}, oe = function(e) {
					if (!T(e)) return !1;
					var t = ae(e);
					return t == "[object Function]" || t == "[object GeneratorFunction]" || t == "[object AsyncFunction]" || t == "[object Proxy]";
				}, E = b["__core-js_shared__"];
				var se, ce = (se = /[^.]+$/.exec(E && E.keys && E.keys.IE_PROTO || "")) ? "Symbol(src)_1." + se : "";
				let le = function(e) {
					return !!ce && ce in e;
				};
				var ue = Function.prototype.toString;
				let de = function(e) {
					if (e != null) {
						try {
							return ue.call(e);
						} catch {}
						try {
							return e + "";
						} catch {}
					}
					return "";
				};
				var fe = /^\[object .+?Constructor\]$/, pe = Function.prototype, me = Object.prototype, he = pe.toString, ge = me.hasOwnProperty, _e = RegExp("^" + he.call(ge).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
				let ve = function(e) {
					return !(!T(e) || le(e)) && (oe(e) ? _e : fe).test(de(e));
				}, ye = function(e, t) {
					return e?.[t];
				}, be = function(e, t) {
					var n = ye(e, t);
					return ve(n) ? n : void 0;
				};
				var xe = be(b, "WeakMap");
				let D = xe && new xe(), Se = D ? function(e, t) {
					return D.set(e, t), e;
				} : _;
				var Ce = Object.create;
				let O = /* @__PURE__ */ function() {
					function e() {}
					return function(t) {
						if (!T(t)) return {};
						if (Ce) return Ce(t);
						e.prototype = t;
						var n = new e();
						return e.prototype = void 0, n;
					};
				}(), k = function(e) {
					return function() {
						var t = arguments;
						switch (t.length) {
							case 0: return new e();
							case 1: return new e(t[0]);
							case 2: return new e(t[0], t[1]);
							case 3: return new e(t[0], t[1], t[2]);
							case 4: return new e(t[0], t[1], t[2], t[3]);
							case 5: return new e(t[0], t[1], t[2], t[3], t[4]);
							case 6: return new e(t[0], t[1], t[2], t[3], t[4], t[5]);
							case 7: return new e(t[0], t[1], t[2], t[3], t[4], t[5], t[6]);
						}
						var n = O(e.prototype), r = e.apply(n, t);
						return T(r) ? r : n;
					};
				}, we = function(e, t, n) {
					var r = 1 & t, i = k(e);
					return function t() {
						return (this && this !== b && this instanceof t ? i : e).apply(r ? n : this, arguments);
					};
				}, Te = function(e, t, n) {
					switch (n.length) {
						case 0: return e.call(t);
						case 1: return e.call(t, n[0]);
						case 2: return e.call(t, n[0], n[1]);
						case 3: return e.call(t, n[0], n[1], n[2]);
					}
					return e.apply(t, n);
				};
				var Ee = Math.max;
				let De = function(e, t, n, r) {
					for (var i = -1, a = e.length, o = n.length, s = -1, c = t.length, l = Ee(a - o, 0), u = Array(c + l), d = !r; ++s < c;) u[s] = t[s];
					for (; ++i < o;) (d || i < a) && (u[n[i]] = e[i]);
					for (; l--;) u[s++] = e[i++];
					return u;
				};
				var Oe = Math.max;
				let ke = function(e, t, n, r) {
					for (var i = -1, a = e.length, o = -1, s = n.length, c = -1, l = t.length, u = Oe(a - s, 0), d = Array(u + l), f = !r; ++i < u;) d[i] = e[i];
					for (var p = i; ++c < l;) d[p + c] = t[c];
					for (; ++o < s;) (f || i < a) && (d[p + n[o]] = e[i++]);
					return d;
				}, Ae = function(e, t) {
					for (var n = e.length, r = 0; n--;) e[n] === t && ++r;
					return r;
				}, A = function() {};
				function j(e) {
					this.__wrapped__ = e, this.__actions__ = [], this.__dir__ = 1, this.__filtered__ = !1, this.__iteratees__ = [], this.__takeCount__ = 4294967295, this.__views__ = [];
				}
				j.prototype = O(A.prototype), j.prototype.constructor = j;
				let je = j, Me = D ? function(e) {
					return D.get(e);
				} : function() {}, Ne = {};
				var Pe = Object.prototype.hasOwnProperty;
				let Fe = function(e) {
					for (var t = e.name + "", n = Ne[t], r = Pe.call(Ne, t) ? n.length : 0; r--;) {
						var i = n[r], a = i.func;
						if (a == null || a == e) return i.name;
					}
					return t;
				};
				function M(e, t) {
					this.__wrapped__ = e, this.__actions__ = [], this.__chain__ = !!t, this.__index__ = 0, this.__values__ = void 0;
				}
				M.prototype = O(A.prototype), M.prototype.constructor = M;
				let N = M, Ie = Array.isArray, Le = function(e) {
					return typeof e == "object" && !!e;
				}, Re = function(e, t) {
					var n = -1, r = e.length;
					for (t ||= Array(r); ++n < r;) t[n] = e[n];
					return t;
				}, ze = function(e) {
					if (e instanceof je) return e.clone();
					var t = new N(e.__wrapped__, e.__chain__);
					return t.__actions__ = Re(e.__actions__), t.__index__ = e.__index__, t.__values__ = e.__values__, t;
				};
				var Be = Object.prototype.hasOwnProperty;
				function P(e) {
					if (Le(e) && !Ie(e) && !(e instanceof je)) {
						if (e instanceof N) return e;
						if (Be.call(e, "__wrapped__")) return ze(e);
					}
					return new N(e);
				}
				P.prototype = A.prototype, P.prototype.constructor = P;
				let Ve = P, He = function(e) {
					var t = Fe(e), n = Ve[t];
					if (typeof n != "function" || !(t in je.prototype)) return !1;
					if (e === n) return !0;
					var r = Me(n);
					return !!r && e === r[0];
				};
				var Ue = Date.now;
				let We = function(e) {
					var t = 0, n = 0;
					return function() {
						var r = Ue(), i = 16 - (r - n);
						if (n = r, i > 0) {
							if (++t >= 800) return arguments[0];
						} else t = 0;
						return e.apply(void 0, arguments);
					};
				}, Ge = We(Se);
				var Ke = /\{\n\/\* \[wrapped with (.+)\] \*/, qe = /,? & /;
				let Je = function(e) {
					var t = e.match(Ke);
					return t ? t[1].split(qe) : [];
				};
				var Ye = /\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/;
				let Xe = function(e, t) {
					var n = t.length;
					if (!n) return e;
					var r = n - 1;
					return t[r] = (n > 1 ? "& " : "") + t[r], t = t.join(n > 2 ? ", " : " "), e.replace(Ye, "{\n/* [wrapped with " + t + "] */\n");
				}, Ze = function(e) {
					return function() {
						return e;
					};
				}, Qe = function() {
					try {
						var e = be(Object, "defineProperty");
						return e({}, "", {}), e;
					} catch {}
				}(), $e = We(Qe ? function(e, t) {
					return Qe(e, "toString", {
						configurable: !0,
						enumerable: !1,
						value: Ze(t),
						writable: !0
					});
				} : _), et = function(e, t) {
					for (var n = -1, r = e == null ? 0 : e.length; ++n < r && t(e[n], n, e) !== !1;);
					return e;
				}, tt = function(e, t, n, r) {
					for (var i = e.length, a = n + -1; ++a < i;) if (t(e[a], a, e)) return a;
					return -1;
				}, nt = function(e) {
					return e != e;
				}, rt = function(e, t, n) {
					for (var r = n - 1, i = e.length; ++r < i;) if (e[r] === t) return r;
					return -1;
				}, it = function(e, t, n) {
					return t == t ? rt(e, t, n) : tt(e, nt, n);
				}, at = function(e, t) {
					return !!(e != null && e.length) && it(e, t, 0) > -1;
				};
				var ot = [
					["ary", 128],
					["bind", 1],
					["bindKey", 2],
					["curry", 8],
					["curryRight", 16],
					["flip", 512],
					["partial", 32],
					["partialRight", 64],
					["rearg", 256]
				];
				let st = function(e, t) {
					return et(ot, function(n) {
						var r = "_." + n[0];
						t & n[1] && !at(e, r) && e.push(r);
					}), e.sort();
				}, ct = function(e, t, n) {
					var r = t + "";
					return $e(e, Xe(r, st(Je(r), n)));
				}, lt = function(e, t, n, r, i, a, o, s, c, l) {
					var u = 8 & t;
					t |= u ? 32 : 64, 4 & (t &= ~(u ? 64 : 32)) || (t &= -4);
					var d = [
						e,
						t,
						i,
						u ? a : void 0,
						u ? o : void 0,
						u ? void 0 : a,
						u ? void 0 : o,
						s,
						c,
						l
					], f = n.apply(void 0, d);
					return He(e) && Ge(f, d), f.placeholder = r, ct(f, e, t);
				}, ut = function(e) {
					return e.placeholder;
				};
				var dt = /^(?:0|[1-9]\d*)$/;
				let ft = function(e, t) {
					var n = typeof e;
					return !!(t ??= 9007199254740991) && (n == "number" || n != "symbol" && dt.test(e)) && e > -1 && e % 1 == 0 && e < t;
				};
				var pt = Math.min;
				let mt = function(e, t) {
					for (var n = e.length, r = pt(t.length, n), i = Re(e); r--;) {
						var a = t[r];
						e[r] = ft(a, n) ? i[a] : void 0;
					}
					return e;
				};
				var ht = "__lodash_placeholder__";
				let F = function(e, t) {
					for (var n = -1, r = e.length, i = 0, a = []; ++n < r;) {
						var o = e[n];
						o !== t && o !== ht || (e[n] = ht, a[i++] = n);
					}
					return a;
				}, gt = function e(t, n, r, i, a, o, s, c, l, u) {
					var d = 128 & n, f = 1 & n, p = 2 & n, m = 24 & n, h = 512 & n, g = p ? void 0 : k(t);
					return function _() {
						for (var v = arguments.length, y = Array(v), x = v; x--;) y[x] = arguments[x];
						if (m) var S = ut(_), ee = Ae(y, S);
						if (i && (y = De(y, i, a, m)), o && (y = ke(y, o, s, m)), v -= ee, m && v < u) {
							var te = F(y, S);
							return lt(t, n, e, _.placeholder, r, y, te, c, l, u - v);
						}
						var C = f ? r : this, w = p ? C[t] : t;
						return v = y.length, c ? y = mt(y, c) : h && v > 1 && y.reverse(), d && l < v && (y.length = l), this && this !== b && this instanceof _ && (w = g || k(w)), w.apply(C, y);
					};
				}, _t = function(e, t, n) {
					var r = k(e);
					return function i() {
						for (var a = arguments.length, o = Array(a), s = a, c = ut(i); s--;) o[s] = arguments[s];
						var l = a < 3 && o[0] !== c && o[a - 1] !== c ? [] : F(o, c);
						return (a -= l.length) < n ? lt(e, t, gt, i.placeholder, void 0, o, l, void 0, void 0, n - a) : Te(this && this !== b && this instanceof i ? r : e, this, o);
					};
				}, vt = function(e, t, n, r) {
					var i = 1 & t, a = k(e);
					return function t() {
						for (var o = -1, s = arguments.length, c = -1, l = r.length, u = Array(l + s), d = this && this !== b && this instanceof t ? a : e; ++c < l;) u[c] = r[c];
						for (; s--;) u[c++] = arguments[++o];
						return Te(d, i ? n : this, u);
					};
				};
				var yt = "__lodash_placeholder__", I = 128, bt = Math.min;
				let xt = function(e, t) {
					var n = e[1], r = t[1], i = n | r, a = i < 131, o = r == I && n == 8 || r == I && n == 256 && e[7].length <= t[8] || r == 384 && t[7].length <= t[8] && n == 8;
					if (!a && !o) return e;
					1 & r && (e[2] = t[2], i |= 1 & n ? 0 : 4);
					var s = t[3];
					if (s) {
						var c = e[3];
						e[3] = c ? De(c, s, t[4]) : s, e[4] = c ? F(e[3], yt) : t[4];
					}
					return (s = t[5]) && (c = e[5], e[5] = c ? ke(c, s, t[6]) : s, e[6] = c ? F(e[5], yt) : t[6]), (s = t[7]) && (e[7] = s), r & I && (e[8] = e[8] == null ? t[8] : bt(e[8], t[8])), e[9] ??= t[9], e[0] = t[0], e[1] = i, e;
				};
				var St = /\s/;
				let Ct = function(e) {
					for (var t = e.length; t-- && St.test(e.charAt(t)););
					return t;
				};
				var wt = /^\s+/;
				let Tt = function(e) {
					return e && e.slice(0, Ct(e) + 1).replace(wt, "");
				}, Et = function(e) {
					return typeof e == "symbol" || Le(e) && ae(e) == "[object Symbol]";
				};
				var Dt = /^[-+]0x[0-9a-f]+$/i, Ot = /^0b[01]+$/i, kt = /^0o[0-7]+$/i, At = parseInt;
				let jt = function(e) {
					if (typeof e == "number") return e;
					if (Et(e)) return NaN;
					if (T(e)) {
						var t = typeof e.valueOf == "function" ? e.valueOf() : e;
						e = T(t) ? t + "" : t;
					}
					if (typeof e != "string") return e === 0 ? e : +e;
					e = Tt(e);
					var n = Ot.test(e);
					return n || kt.test(e) ? At(e.slice(2), n ? 2 : 8) : Dt.test(e) ? NaN : +e;
				};
				var Mt = 1 / 0;
				let Nt = function(e) {
					return e ? (e = jt(e)) === Mt || e === -1 / 0 ? 17976931348623157e292 * (e < 0 ? -1 : 1) : e == e ? e : 0 : e === 0 ? e : 0;
				}, Pt = function(e) {
					var t = Nt(e), n = t % 1;
					return t == t ? n ? t - n : t : 0;
				};
				var Ft = Math.max;
				let It = function(e, t, n, r, i, a, o, s) {
					var c = 2 & t;
					if (!c && typeof e != "function") throw TypeError("Expected a function");
					var l = r ? r.length : 0;
					if (l || (t &= -97, r = i = void 0), o = o === void 0 ? o : Ft(Pt(o), 0), s = s === void 0 ? s : Pt(s), l -= i ? i.length : 0, 64 & t) {
						var u = r, d = i;
						r = i = void 0;
					}
					var f = c ? void 0 : Me(e), p = [
						e,
						t,
						n,
						r,
						i,
						u,
						d,
						a,
						o,
						s
					];
					if (f && xt(p, f), e = p[0], t = p[1], n = p[2], r = p[3], i = p[4], !(s = p[9] = p[9] === void 0 ? c ? 0 : e.length : Ft(p[9] - l, 0)) && 24 & t && (t &= -25), t && t != 1) m = t == 8 || t == 16 ? _t(e, t, s) : t != 32 && t != 33 || i.length ? gt.apply(void 0, p) : vt(e, t, n, r);
					else var m = we(e, t, n);
					return ct((f ? Se : Ge)(m, p), e, t);
				};
				function L(e, t, n) {
					var r = It(e, 8, void 0, void 0, void 0, void 0, void 0, t = n ? void 0 : t);
					return r.placeholder = L.placeholder, r;
				}
				L.placeholder = {};
				let Lt = L, Rt = {
					threezerotwofour: {
						scheme: "threezerotwofour",
						author: "jan t. sott (http://github.com/idleberg)",
						base00: "#090300",
						base01: "#3a3432",
						base02: "#4a4543",
						base03: "#5c5855",
						base04: "#807d7c",
						base05: "#a5a2a2",
						base06: "#d6d5d4",
						base07: "#f7f7f7",
						base08: "#db2d20",
						base09: "#e8bbd0",
						base0A: "#fded02",
						base0B: "#01a252",
						base0C: "#b5e4f4",
						base0D: "#01a0e4",
						base0E: "#a16a94",
						base0F: "#cdab53"
					},
					apathy: {
						scheme: "apathy",
						author: "jannik siebert (https://github.com/janniks)",
						base00: "#031A16",
						base01: "#0B342D",
						base02: "#184E45",
						base03: "#2B685E",
						base04: "#5F9C92",
						base05: "#81B5AC",
						base06: "#A7CEC8",
						base07: "#D2E7E4",
						base08: "#3E9688",
						base09: "#3E7996",
						base0A: "#3E4C96",
						base0B: "#883E96",
						base0C: "#963E4C",
						base0D: "#96883E",
						base0E: "#4C963E",
						base0F: "#3E965B"
					},
					ashes: {
						scheme: "ashes",
						author: "jannik siebert (https://github.com/janniks)",
						base00: "#1C2023",
						base01: "#393F45",
						base02: "#565E65",
						base03: "#747C84",
						base04: "#ADB3BA",
						base05: "#C7CCD1",
						base06: "#DFE2E5",
						base07: "#F3F4F5",
						base08: "#C7AE95",
						base09: "#C7C795",
						base0A: "#AEC795",
						base0B: "#95C7AE",
						base0C: "#95AEC7",
						base0D: "#AE95C7",
						base0E: "#C795AE",
						base0F: "#C79595"
					},
					atelierDune: {
						scheme: "atelier dune",
						author: "bram de haan (http://atelierbram.github.io/syntax-highlighting/atelier-schemes/dune)",
						base00: "#20201d",
						base01: "#292824",
						base02: "#6e6b5e",
						base03: "#7d7a68",
						base04: "#999580",
						base05: "#a6a28c",
						base06: "#e8e4cf",
						base07: "#fefbec",
						base08: "#d73737",
						base09: "#b65611",
						base0A: "#cfb017",
						base0B: "#60ac39",
						base0C: "#1fad83",
						base0D: "#6684e1",
						base0E: "#b854d4",
						base0F: "#d43552"
					},
					atelierForest: {
						scheme: "atelier forest",
						author: "bram de haan (http://atelierbram.github.io/syntax-highlighting/atelier-schemes/forest)",
						base00: "#1b1918",
						base01: "#2c2421",
						base02: "#68615e",
						base03: "#766e6b",
						base04: "#9c9491",
						base05: "#a8a19f",
						base06: "#e6e2e0",
						base07: "#f1efee",
						base08: "#f22c40",
						base09: "#df5320",
						base0A: "#d5911a",
						base0B: "#5ab738",
						base0C: "#00ad9c",
						base0D: "#407ee7",
						base0E: "#6666ea",
						base0F: "#c33ff3"
					},
					atelierHeath: {
						scheme: "atelier heath",
						author: "bram de haan (http://atelierbram.github.io/syntax-highlighting/atelier-schemes/heath)",
						base00: "#1b181b",
						base01: "#292329",
						base02: "#695d69",
						base03: "#776977",
						base04: "#9e8f9e",
						base05: "#ab9bab",
						base06: "#d8cad8",
						base07: "#f7f3f7",
						base08: "#ca402b",
						base09: "#a65926",
						base0A: "#bb8a35",
						base0B: "#379a37",
						base0C: "#159393",
						base0D: "#516aec",
						base0E: "#7b59c0",
						base0F: "#cc33cc"
					},
					atelierLakeside: {
						scheme: "atelier lakeside",
						author: "bram de haan (http://atelierbram.github.io/syntax-highlighting/atelier-schemes/lakeside/)",
						base00: "#161b1d",
						base01: "#1f292e",
						base02: "#516d7b",
						base03: "#5a7b8c",
						base04: "#7195a8",
						base05: "#7ea2b4",
						base06: "#c1e4f6",
						base07: "#ebf8ff",
						base08: "#d22d72",
						base09: "#935c25",
						base0A: "#8a8a0f",
						base0B: "#568c3b",
						base0C: "#2d8f6f",
						base0D: "#257fad",
						base0E: "#5d5db1",
						base0F: "#b72dd2"
					},
					atelierSeaside: {
						scheme: "atelier seaside",
						author: "bram de haan (http://atelierbram.github.io/syntax-highlighting/atelier-schemes/seaside/)",
						base00: "#131513",
						base01: "#242924",
						base02: "#5e6e5e",
						base03: "#687d68",
						base04: "#809980",
						base05: "#8ca68c",
						base06: "#cfe8cf",
						base07: "#f0fff0",
						base08: "#e6193c",
						base09: "#87711d",
						base0A: "#c3c322",
						base0B: "#29a329",
						base0C: "#1999b3",
						base0D: "#3d62f5",
						base0E: "#ad2bee",
						base0F: "#e619c3"
					},
					bespin: {
						scheme: "bespin",
						author: "jan t. sott",
						base00: "#28211c",
						base01: "#36312e",
						base02: "#5e5d5c",
						base03: "#666666",
						base04: "#797977",
						base05: "#8a8986",
						base06: "#9d9b97",
						base07: "#baae9e",
						base08: "#cf6a4c",
						base09: "#cf7d34",
						base0A: "#f9ee98",
						base0B: "#54be0d",
						base0C: "#afc4db",
						base0D: "#5ea6ea",
						base0E: "#9b859d",
						base0F: "#937121"
					},
					brewer: {
						scheme: "brewer",
						author: "timothée poisot (http://github.com/tpoisot)",
						base00: "#0c0d0e",
						base01: "#2e2f30",
						base02: "#515253",
						base03: "#737475",
						base04: "#959697",
						base05: "#b7b8b9",
						base06: "#dadbdc",
						base07: "#fcfdfe",
						base08: "#e31a1c",
						base09: "#e6550d",
						base0A: "#dca060",
						base0B: "#31a354",
						base0C: "#80b1d3",
						base0D: "#3182bd",
						base0E: "#756bb1",
						base0F: "#b15928"
					},
					bright: {
						scheme: "bright",
						author: "chris kempson (http://chriskempson.com)",
						base00: "#000000",
						base01: "#303030",
						base02: "#505050",
						base03: "#b0b0b0",
						base04: "#d0d0d0",
						base05: "#e0e0e0",
						base06: "#f5f5f5",
						base07: "#ffffff",
						base08: "#fb0120",
						base09: "#fc6d24",
						base0A: "#fda331",
						base0B: "#a1c659",
						base0C: "#76c7b7",
						base0D: "#6fb3d2",
						base0E: "#d381c3",
						base0F: "#be643c"
					},
					chalk: {
						scheme: "chalk",
						author: "chris kempson (http://chriskempson.com)",
						base00: "#151515",
						base01: "#202020",
						base02: "#303030",
						base03: "#505050",
						base04: "#b0b0b0",
						base05: "#d0d0d0",
						base06: "#e0e0e0",
						base07: "#f5f5f5",
						base08: "#fb9fb1",
						base09: "#eda987",
						base0A: "#ddb26f",
						base0B: "#acc267",
						base0C: "#12cfc0",
						base0D: "#6fc2ef",
						base0E: "#e1a3ee",
						base0F: "#deaf8f"
					},
					codeschool: {
						scheme: "codeschool",
						author: "brettof86",
						base00: "#232c31",
						base01: "#1c3657",
						base02: "#2a343a",
						base03: "#3f4944",
						base04: "#84898c",
						base05: "#9ea7a6",
						base06: "#a7cfa3",
						base07: "#b5d8f6",
						base08: "#2a5491",
						base09: "#43820d",
						base0A: "#a03b1e",
						base0B: "#237986",
						base0C: "#b02f30",
						base0D: "#484d79",
						base0E: "#c59820",
						base0F: "#c98344"
					},
					colors: {
						scheme: "colors",
						author: "mrmrs (http://clrs.cc)",
						base00: "#111111",
						base01: "#333333",
						base02: "#555555",
						base03: "#777777",
						base04: "#999999",
						base05: "#bbbbbb",
						base06: "#dddddd",
						base07: "#ffffff",
						base08: "#ff4136",
						base09: "#ff851b",
						base0A: "#ffdc00",
						base0B: "#2ecc40",
						base0C: "#7fdbff",
						base0D: "#0074d9",
						base0E: "#b10dc9",
						base0F: "#85144b"
					},
					default: {
						scheme: "default",
						author: "chris kempson (http://chriskempson.com)",
						base00: "#181818",
						base01: "#282828",
						base02: "#383838",
						base03: "#585858",
						base04: "#b8b8b8",
						base05: "#d8d8d8",
						base06: "#e8e8e8",
						base07: "#f8f8f8",
						base08: "#ab4642",
						base09: "#dc9656",
						base0A: "#f7ca88",
						base0B: "#a1b56c",
						base0C: "#86c1b9",
						base0D: "#7cafc2",
						base0E: "#ba8baf",
						base0F: "#a16946"
					},
					eighties: {
						scheme: "eighties",
						author: "chris kempson (http://chriskempson.com)",
						base00: "#2d2d2d",
						base01: "#393939",
						base02: "#515151",
						base03: "#747369",
						base04: "#a09f93",
						base05: "#d3d0c8",
						base06: "#e8e6df",
						base07: "#f2f0ec",
						base08: "#f2777a",
						base09: "#f99157",
						base0A: "#ffcc66",
						base0B: "#99cc99",
						base0C: "#66cccc",
						base0D: "#6699cc",
						base0E: "#cc99cc",
						base0F: "#d27b53"
					},
					embers: {
						scheme: "embers",
						author: "jannik siebert (https://github.com/janniks)",
						base00: "#16130F",
						base01: "#2C2620",
						base02: "#433B32",
						base03: "#5A5047",
						base04: "#8A8075",
						base05: "#A39A90",
						base06: "#BEB6AE",
						base07: "#DBD6D1",
						base08: "#826D57",
						base09: "#828257",
						base0A: "#6D8257",
						base0B: "#57826D",
						base0C: "#576D82",
						base0D: "#6D5782",
						base0E: "#82576D",
						base0F: "#825757"
					},
					flat: {
						scheme: "flat",
						author: "chris kempson (http://chriskempson.com)",
						base00: "#2C3E50",
						base01: "#34495E",
						base02: "#7F8C8D",
						base03: "#95A5A6",
						base04: "#BDC3C7",
						base05: "#e0e0e0",
						base06: "#f5f5f5",
						base07: "#ECF0F1",
						base08: "#E74C3C",
						base09: "#E67E22",
						base0A: "#F1C40F",
						base0B: "#2ECC71",
						base0C: "#1ABC9C",
						base0D: "#3498DB",
						base0E: "#9B59B6",
						base0F: "#be643c"
					},
					google: {
						scheme: "google",
						author: "seth wright (http://sethawright.com)",
						base00: "#1d1f21",
						base01: "#282a2e",
						base02: "#373b41",
						base03: "#969896",
						base04: "#b4b7b4",
						base05: "#c5c8c6",
						base06: "#e0e0e0",
						base07: "#ffffff",
						base08: "#CC342B",
						base09: "#F96A38",
						base0A: "#FBA922",
						base0B: "#198844",
						base0C: "#3971ED",
						base0D: "#3971ED",
						base0E: "#A36AC7",
						base0F: "#3971ED"
					},
					grayscale: {
						scheme: "grayscale",
						author: "alexandre gavioli (https://github.com/alexx2/)",
						base00: "#101010",
						base01: "#252525",
						base02: "#464646",
						base03: "#525252",
						base04: "#ababab",
						base05: "#b9b9b9",
						base06: "#e3e3e3",
						base07: "#f7f7f7",
						base08: "#7c7c7c",
						base09: "#999999",
						base0A: "#a0a0a0",
						base0B: "#8e8e8e",
						base0C: "#868686",
						base0D: "#686868",
						base0E: "#747474",
						base0F: "#5e5e5e"
					},
					greenscreen: {
						scheme: "green screen",
						author: "chris kempson (http://chriskempson.com)",
						base00: "#001100",
						base01: "#003300",
						base02: "#005500",
						base03: "#007700",
						base04: "#009900",
						base05: "#00bb00",
						base06: "#00dd00",
						base07: "#00ff00",
						base08: "#007700",
						base09: "#009900",
						base0A: "#007700",
						base0B: "#00bb00",
						base0C: "#005500",
						base0D: "#009900",
						base0E: "#00bb00",
						base0F: "#005500"
					},
					harmonic: {
						scheme: "harmonic16",
						author: "jannik siebert (https://github.com/janniks)",
						base00: "#0b1c2c",
						base01: "#223b54",
						base02: "#405c79",
						base03: "#627e99",
						base04: "#aabcce",
						base05: "#cbd6e2",
						base06: "#e5ebf1",
						base07: "#f7f9fb",
						base08: "#bf8b56",
						base09: "#bfbf56",
						base0A: "#8bbf56",
						base0B: "#56bf8b",
						base0C: "#568bbf",
						base0D: "#8b56bf",
						base0E: "#bf568b",
						base0F: "#bf5656"
					},
					hopscotch: {
						scheme: "hopscotch",
						author: "jan t. sott",
						base00: "#322931",
						base01: "#433b42",
						base02: "#5c545b",
						base03: "#797379",
						base04: "#989498",
						base05: "#b9b5b8",
						base06: "#d5d3d5",
						base07: "#ffffff",
						base08: "#dd464c",
						base09: "#fd8b19",
						base0A: "#fdcc59",
						base0B: "#8fc13e",
						base0C: "#149b93",
						base0D: "#1290bf",
						base0E: "#c85e7c",
						base0F: "#b33508"
					},
					isotope: {
						scheme: "isotope",
						author: "jan t. sott",
						base00: "#000000",
						base01: "#404040",
						base02: "#606060",
						base03: "#808080",
						base04: "#c0c0c0",
						base05: "#d0d0d0",
						base06: "#e0e0e0",
						base07: "#ffffff",
						base08: "#ff0000",
						base09: "#ff9900",
						base0A: "#ff0099",
						base0B: "#33ff00",
						base0C: "#00ffff",
						base0D: "#0066ff",
						base0E: "#cc00ff",
						base0F: "#3300ff"
					},
					marrakesh: {
						scheme: "marrakesh",
						author: "alexandre gavioli (http://github.com/alexx2/)",
						base00: "#201602",
						base01: "#302e00",
						base02: "#5f5b17",
						base03: "#6c6823",
						base04: "#86813b",
						base05: "#948e48",
						base06: "#ccc37a",
						base07: "#faf0a5",
						base08: "#c35359",
						base09: "#b36144",
						base0A: "#a88339",
						base0B: "#18974e",
						base0C: "#75a738",
						base0D: "#477ca1",
						base0E: "#8868b3",
						base0F: "#b3588e"
					},
					mocha: {
						scheme: "mocha",
						author: "chris kempson (http://chriskempson.com)",
						base00: "#3B3228",
						base01: "#534636",
						base02: "#645240",
						base03: "#7e705a",
						base04: "#b8afad",
						base05: "#d0c8c6",
						base06: "#e9e1dd",
						base07: "#f5eeeb",
						base08: "#cb6077",
						base09: "#d28b71",
						base0A: "#f4bc87",
						base0B: "#beb55b",
						base0C: "#7bbda4",
						base0D: "#8ab3b5",
						base0E: "#a89bb9",
						base0F: "#bb9584"
					},
					monokai: {
						scheme: "monokai",
						author: "wimer hazenberg (http://www.monokai.nl)",
						base00: "#272822",
						base01: "#383830",
						base02: "#49483e",
						base03: "#75715e",
						base04: "#a59f85",
						base05: "#f8f8f2",
						base06: "#f5f4f1",
						base07: "#f9f8f5",
						base08: "#f92672",
						base09: "#fd971f",
						base0A: "#f4bf75",
						base0B: "#a6e22e",
						base0C: "#a1efe4",
						base0D: "#66d9ef",
						base0E: "#ae81ff",
						base0F: "#cc6633"
					},
					nicinabox: {
						scheme: "nicinabox",
						author: "nicinabox (http://github.com/nicinabox)",
						base00: "#2A2F3A",
						base01: "#3C444F",
						base02: "#4F5A65",
						base03: "#BEBEBE",
						base04: "#b0b0b0",
						base05: "#d0d0d0",
						base06: "#FFFFFF",
						base07: "#f5f5f5",
						base08: "#fb9fb1",
						base09: "#FC6D24",
						base0A: "#ddb26f",
						base0B: "#A1C659",
						base0C: "#12cfc0",
						base0D: "#6FB3D2",
						base0E: "#D381C3",
						base0F: "#deaf8f"
					},
					ocean: {
						scheme: "ocean",
						author: "chris kempson (http://chriskempson.com)",
						base00: "#2b303b",
						base01: "#343d46",
						base02: "#4f5b66",
						base03: "#65737e",
						base04: "#a7adba",
						base05: "#c0c5ce",
						base06: "#dfe1e8",
						base07: "#eff1f5",
						base08: "#bf616a",
						base09: "#d08770",
						base0A: "#ebcb8b",
						base0B: "#a3be8c",
						base0C: "#96b5b4",
						base0D: "#8fa1b3",
						base0E: "#b48ead",
						base0F: "#ab7967"
					},
					paraiso: {
						scheme: "paraiso",
						author: "jan t. sott",
						base00: "#2f1e2e",
						base01: "#41323f",
						base02: "#4f424c",
						base03: "#776e71",
						base04: "#8d8687",
						base05: "#a39e9b",
						base06: "#b9b6b0",
						base07: "#e7e9db",
						base08: "#ef6155",
						base09: "#f99b15",
						base0A: "#fec418",
						base0B: "#48b685",
						base0C: "#5bc4bf",
						base0D: "#06b6ef",
						base0E: "#815ba4",
						base0F: "#e96ba8"
					},
					pop: {
						scheme: "pop",
						author: "chris kempson (http://chriskempson.com)",
						base00: "#000000",
						base01: "#202020",
						base02: "#303030",
						base03: "#505050",
						base04: "#b0b0b0",
						base05: "#d0d0d0",
						base06: "#e0e0e0",
						base07: "#ffffff",
						base08: "#eb008a",
						base09: "#f29333",
						base0A: "#f8ca12",
						base0B: "#37b349",
						base0C: "#00aabb",
						base0D: "#0e5a94",
						base0E: "#b31e8d",
						base0F: "#7a2d00"
					},
					railscasts: {
						scheme: "railscasts",
						author: "ryan bates (http://railscasts.com)",
						base00: "#2b2b2b",
						base01: "#272935",
						base02: "#3a4055",
						base03: "#5a647e",
						base04: "#d4cfc9",
						base05: "#e6e1dc",
						base06: "#f4f1ed",
						base07: "#f9f7f3",
						base08: "#da4939",
						base09: "#cc7833",
						base0A: "#ffc66d",
						base0B: "#a5c261",
						base0C: "#519f50",
						base0D: "#6d9cbe",
						base0E: "#b6b3eb",
						base0F: "#bc9458"
					},
					shapeshifter: {
						scheme: "shapeshifter",
						author: "tyler benziger (http://tybenz.com)",
						base00: "#000000",
						base01: "#040404",
						base02: "#102015",
						base03: "#343434",
						base04: "#555555",
						base05: "#ababab",
						base06: "#e0e0e0",
						base07: "#f9f9f9",
						base08: "#e92f2f",
						base09: "#e09448",
						base0A: "#dddd13",
						base0B: "#0ed839",
						base0C: "#23edda",
						base0D: "#3b48e3",
						base0E: "#f996e2",
						base0F: "#69542d"
					},
					solarized: {
						scheme: "solarized",
						author: "ethan schoonover (http://ethanschoonover.com/solarized)",
						base00: "#002b36",
						base01: "#073642",
						base02: "#586e75",
						base03: "#657b83",
						base04: "#839496",
						base05: "#93a1a1",
						base06: "#eee8d5",
						base07: "#fdf6e3",
						base08: "#dc322f",
						base09: "#cb4b16",
						base0A: "#b58900",
						base0B: "#859900",
						base0C: "#2aa198",
						base0D: "#268bd2",
						base0E: "#6c71c4",
						base0F: "#d33682"
					},
					summerfruit: {
						scheme: "summerfruit",
						author: "christopher corley (http://cscorley.github.io/)",
						base00: "#151515",
						base01: "#202020",
						base02: "#303030",
						base03: "#505050",
						base04: "#B0B0B0",
						base05: "#D0D0D0",
						base06: "#E0E0E0",
						base07: "#FFFFFF",
						base08: "#FF0086",
						base09: "#FD8900",
						base0A: "#ABA800",
						base0B: "#00C918",
						base0C: "#1faaaa",
						base0D: "#3777E6",
						base0E: "#AD00A1",
						base0F: "#cc6633"
					},
					tomorrow: {
						scheme: "tomorrow",
						author: "chris kempson (http://chriskempson.com)",
						base00: "#1d1f21",
						base01: "#282a2e",
						base02: "#373b41",
						base03: "#969896",
						base04: "#b4b7b4",
						base05: "#c5c8c6",
						base06: "#e0e0e0",
						base07: "#ffffff",
						base08: "#cc6666",
						base09: "#de935f",
						base0A: "#f0c674",
						base0B: "#b5bd68",
						base0C: "#8abeb7",
						base0D: "#81a2be",
						base0E: "#b294bb",
						base0F: "#a3685a"
					},
					tube: {
						scheme: "london tube",
						author: "jan t. sott",
						base00: "#231f20",
						base01: "#1c3f95",
						base02: "#5a5758",
						base03: "#737171",
						base04: "#959ca1",
						base05: "#d9d8d8",
						base06: "#e7e7e8",
						base07: "#ffffff",
						base08: "#ee2e24",
						base09: "#f386a1",
						base0A: "#ffd204",
						base0B: "#00853e",
						base0C: "#85cebc",
						base0D: "#009ddc",
						base0E: "#98005d",
						base0F: "#b06110"
					},
					twilight: {
						scheme: "twilight",
						author: "david hart (http://hart-dev.com)",
						base00: "#1e1e1e",
						base01: "#323537",
						base02: "#464b50",
						base03: "#5f5a60",
						base04: "#838184",
						base05: "#a7a7a7",
						base06: "#c3c3c3",
						base07: "#ffffff",
						base08: "#cf6a4c",
						base09: "#cda869",
						base0A: "#f9ee98",
						base0B: "#8f9d6a",
						base0C: "#afc4db",
						base0D: "#7587a6",
						base0E: "#9b859d",
						base0F: "#9b703f"
					}
				}, zt = Rt.default, Bt = Object.keys(zt), Vt = (e) => {
					let [t, n, r] = function(e) {
						let t = e[0] / 255, n = e[1] / 255, r = e[2] / 255;
						return [
							.299 * t + .587 * n + .114 * r,
							-.14713 * t + -.28886 * n + .436 * r,
							.615 * t + -.51499 * n + -.10001 * r
						];
					}(g(e).array());
					var i;
					let a = function(e) {
						let t = e[0], n = e[1], r = e[2], i, a, o;
						return i = 1 * t + 0 * n + 1.13983 * r, a = 1 * t + -.39465 * n + -.5806 * r, o = 1 * t + 2.02311 * n + 0 * r, i = Math.min(Math.max(0, i), 1), a = Math.min(Math.max(0, a), 1), o = Math.min(Math.max(0, o), 1), [
							255 * i,
							255 * a,
							255 * o
						];
					}([
						(i = t, i < .25 ? 1 : i < .5 ? .9 - i : 1.1 - i),
						n,
						r
					]);
					return g.rgb(a).hex();
				}, R = (e) => (t) => ({
					className: [t.className, e.className].filter(Boolean).join(" "),
					style: {
						...t.style || {},
						...e.style || {}
					}
				}), Ht = (e, t) => {
					let n = Object.keys(t);
					for (let t in e) n.indexOf(t) === -1 && n.push(t);
					return n.reduce((n, r) => (n[r] = ((e, t) => {
						if (e === void 0) return t;
						if (t === void 0) return e;
						let n = typeof t;
						switch (typeof e) {
							case "string":
								switch (n) {
									case "string": return [t, e].filter(Boolean).join(" ");
									case "object": return R({
										className: e,
										style: t
									});
									case "function": return (n, ...r) => R({ className: e })(t(n, ...r));
								}
								break;
							case "object":
								switch (n) {
									case "string": return R({
										className: t,
										style: e
									});
									case "object": return {
										...t,
										...e
									};
									case "function": return (n, ...r) => R({ style: e })(t(n, ...r));
								}
								break;
							case "function": switch (n) {
								case "string": return (n, ...r) => e(R(n)({ className: t }), ...r);
								case "object": return (n, ...r) => e(R(n)({ style: t }), ...r);
								case "function": return (n, ...r) => e(t(n, ...r), ...r);
							}
						}
					})(e[r], t[r]), n), {});
				}, Ut = (e, t, ...n) => {
					if (t === null) return e;
					Array.isArray(t) || (t = [t]);
					let r = t.map((t) => e[t]).filter(Boolean).reduce((e, t) => (typeof t == "string" ? e.className = [e.className, t].filter(Boolean).join(" ") : typeof t == "object" ? e.style = {
						...e.style,
						...t
					} : typeof t == "function" && (e = {
						...e,
						...t(e, ...n)
					}), e), {
						className: "",
						style: {}
					});
					return r.className || delete r.className, Object.keys(r.style).length === 0 && delete r.style, r;
				}, Wt = (e) => Object.keys(e).reduce((t, n) => (t[n] = /^base/.test(n) ? Vt(e[n]) : n === "scheme" ? e[n] + ":inverted" : e[n], t), {}), Gt = Lt((e, t = {}, n = {}, ...r) => {
					let { defaultBase16: i = zt, base16Themes: a = null } = t, o = qt(n, a);
					o && (n = {
						...o,
						...n
					});
					let s = Bt.reduce((e, t) => (e[t] = n[t] || i[t], e), {}), c = Object.keys(n).reduce((e, t) => (Bt.indexOf(t) === -1 && (e[t] = n[t]), e), {}), l = e(s), u = Ht(c, l);
					return Lt(Ut, 2)(u, ...r);
				}, 3), Kt = (e) => !!e.extend, qt = (e, t) => {
					if (e && Kt(e) && e.extend && (e = e.extend), typeof e == "string") {
						let [n, r] = e.split(":");
						e = t ? t[n] : Rt[n], r === "inverted" && (e = Wt(e));
					}
					return e && Object.prototype.hasOwnProperty.call(e, "base00") ? e : void 0;
				}, Jt = (e) => {
					let t = ((e) => ({
						backgroundColor: e.base00,
						ellipsisColor: e.base09,
						braceColor: e.base07,
						expandedIcon: e.base0D,
						collapsedIcon: e.base0E,
						keyColor: e.base07,
						arrayKeyColor: e.base0C,
						objectSize: e.base04,
						copyToClipboard: e.base0F,
						copyToClipboardCheck: e.base0D,
						objectBorder: e.base02,
						dataTypes: {
							boolean: e.base0E,
							date: e.base0D,
							float: e.base0B,
							function: e.base0D,
							integer: e.base0F,
							string: e.base09,
							nan: e.base08,
							null: e.base0A,
							undefined: e.base05,
							regexp: e.base0A,
							background: e.base02,
							bigNumber: e.base09
						},
						editVariable: {
							editIcon: e.base0E,
							cancelIcon: e.base09,
							removeIcon: e.base09,
							addIcon: e.base0E,
							checkIcon: e.base0E,
							background: e.base01,
							color: e.base0A,
							border: e.base07
						},
						addKeyModal: {
							background: e.base05,
							border: e.base04,
							color: e.base0A,
							labelColor: e.base01
						},
						validationFailure: {
							background: e.base09,
							iconColor: e.base01,
							fontColor: e.base01
						}
					}))(e);
					return {
						"app-container": {
							fontFamily: h.globalFontFamily,
							cursor: h.globalCursor,
							backgroundColor: t.backgroundColor,
							position: "relative"
						},
						ellipsis: {
							display: "inline-block",
							color: t.ellipsisColor,
							fontSize: h.ellipsisFontSize,
							lineHeight: h.ellipsisLineHeight,
							cursor: h.ellipsisCursor
						},
						"brace-row": {
							display: "inline-block",
							cursor: "pointer"
						},
						brace: {
							display: "inline-block",
							cursor: h.braceCursor,
							fontWeight: h.braceFontWeight,
							color: t.braceColor
						},
						"expanded-icon": { color: t.expandedIcon },
						"collapsed-icon": { color: t.collapsedIcon },
						colon: {
							display: "inline-block",
							margin: h.keyMargin,
							color: t.keyColor,
							verticalAlign: "top"
						},
						objectKeyVal: (e, n) => ({ style: {
							paddingTop: h.keyValPaddingTop,
							paddingRight: h.keyValPaddingRight,
							paddingBottom: h.keyValPaddingBottom,
							borderLeft: h.keyValBorderLeft + " " + t.objectBorder,
							":hover": {
								paddingLeft: n.paddingLeft - 1 + "px",
								borderLeft: h.keyValBorderHover + " " + t.objectBorder
							},
							...n
						} }),
						"object-key-val-no-border": { padding: h.keyValPadding },
						"pushed-content": { marginLeft: h.pushedContentMarginLeft },
						variableValue: (e, t) => ({ style: {
							display: "inline-block",
							paddingRight: h.variableValuePaddingRight,
							position: "relative",
							...t
						} }),
						"object-name": {
							display: "inline-block",
							color: t.keyColor,
							letterSpacing: h.keyLetterSpacing,
							fontStyle: h.keyFontStyle,
							verticalAlign: h.keyVerticalAlign,
							opacity: h.keyOpacity,
							":hover": { opacity: h.keyOpacityHover }
						},
						"array-key": {
							display: "inline-block",
							color: t.arrayKeyColor,
							letterSpacing: h.keyLetterSpacing,
							fontStyle: h.keyFontStyle,
							verticalAlign: h.keyVerticalAlign,
							opacity: h.keyOpacity,
							":hover": { opacity: h.keyOpacityHover }
						},
						"object-size": {
							color: t.objectSize,
							borderRadius: h.objectSizeBorderRadius,
							fontStyle: h.objectSizeFontStyle,
							margin: h.objectSizeMargin,
							cursor: "default"
						},
						"data-type-label": {
							fontSize: h.dataTypeFontSize,
							marginRight: h.dataTypeMarginRight,
							opacity: h.datatypeOpacity
						},
						boolean: {
							display: "inline-block",
							color: t.dataTypes.boolean
						},
						date: {
							display: "inline-block",
							color: t.dataTypes.date
						},
						"date-value": { marginLeft: h.dateValueMarginLeft },
						float: {
							display: "inline-block",
							color: t.dataTypes.float
						},
						function: {
							display: "inline-block",
							color: t.dataTypes.function,
							cursor: "pointer",
							whiteSpace: "pre-line"
						},
						"function-value": { fontStyle: "italic" },
						integer: {
							display: "inline-block",
							color: t.dataTypes.integer
						},
						bigNumber: {
							display: "inline-block",
							color: t.dataTypes.bigNumber
						},
						string: {
							display: "inline-block",
							color: t.dataTypes.string
						},
						nan: {
							display: "inline-block",
							color: t.dataTypes.nan,
							fontSize: h.nanFontSize,
							fontWeight: h.nanFontWeight,
							backgroundColor: t.dataTypes.background,
							padding: h.nanPadding,
							borderRadius: h.nanBorderRadius
						},
						null: {
							display: "inline-block",
							color: t.dataTypes.null,
							fontSize: h.nullFontSize,
							fontWeight: h.nullFontWeight,
							backgroundColor: t.dataTypes.background,
							padding: h.nullPadding,
							borderRadius: h.nullBorderRadius
						},
						undefined: {
							display: "inline-block",
							color: t.dataTypes.undefined,
							fontSize: h.undefinedFontSize,
							padding: h.undefinedPadding,
							borderRadius: h.undefinedBorderRadius,
							backgroundColor: t.dataTypes.background
						},
						circularReference: {
							display: "inline-block",
							color: t.dataTypes.null,
							fontSize: h.nullFontSize,
							fontWeight: h.nullFontWeight,
							backgroundColor: t.dataTypes.background,
							padding: h.nullPadding,
							borderRadius: h.nullBorderRadius
						},
						regexp: {
							display: "inline-block",
							color: t.dataTypes.regexp
						},
						"copy-to-clipboard": { cursor: h.clipboardCursor },
						"copy-icon": {
							color: t.copyToClipboard,
							fontSize: h.iconFontSize,
							marginRight: h.iconMarginRight,
							verticalAlign: "top"
						},
						"copy-icon-copied": {
							color: t.copyToClipboardCheck,
							marginLeft: h.clipboardCheckMarginLeft
						},
						"array-group-meta-data": {
							display: "inline-block",
							padding: h.arrayGroupMetaPadding
						},
						"object-meta-data": {
							display: "inline-block",
							padding: h.metaDataPadding
						},
						"icon-container": {
							display: "inline-block",
							width: h.iconContainerWidth
						},
						tooltip: { padding: h.tooltipPadding },
						removeVarIcon: {
							verticalAlign: "top",
							display: "inline-block",
							color: t.editVariable.removeIcon,
							cursor: h.iconCursor,
							fontSize: h.iconFontSize,
							marginRight: h.iconMarginRight
						},
						addVarIcon: {
							verticalAlign: "top",
							display: "inline-block",
							color: t.editVariable.addIcon,
							cursor: h.iconCursor,
							fontSize: h.iconFontSize,
							marginRight: h.iconMarginRight
						},
						editVarIcon: {
							verticalAlign: "top",
							display: "inline-block",
							color: t.editVariable.editIcon,
							cursor: h.iconCursor,
							fontSize: h.iconFontSize,
							marginRight: h.iconMarginRight
						},
						"edit-icon-container": {
							display: "inline-block",
							verticalAlign: "top"
						},
						"check-icon": {
							display: "inline-block",
							cursor: h.iconCursor,
							color: t.editVariable.checkIcon,
							fontSize: h.iconFontSize,
							paddingRight: h.iconPaddingRight
						},
						"cancel-icon": {
							display: "inline-block",
							cursor: h.iconCursor,
							color: t.editVariable.cancelIcon,
							fontSize: h.iconFontSize,
							paddingRight: h.iconPaddingRight
						},
						"edit-input": {
							display: "inline-block",
							minWidth: h.editInputMinWidth,
							borderRadius: h.editInputBorderRadius,
							backgroundColor: t.editVariable.background,
							color: t.editVariable.color,
							padding: h.editInputPadding,
							marginRight: h.editInputMarginRight,
							fontFamily: h.editInputFontFamily
						},
						"detected-row": { paddingTop: h.detectedRowPaddingTop },
						"key-modal-request": {
							position: h.addKeyCoverPosition,
							top: h.addKeyCoverPositionPx,
							left: h.addKeyCoverPositionPx,
							right: h.addKeyCoverPositionPx,
							bottom: h.addKeyCoverPositionPx,
							backgroundColor: h.addKeyCoverBackground
						},
						"key-modal": {
							width: h.addKeyModalWidth,
							backgroundColor: t.addKeyModal.background,
							marginLeft: h.addKeyModalMargin,
							marginRight: h.addKeyModalMargin,
							padding: h.addKeyModalPadding,
							borderRadius: h.addKeyModalRadius,
							marginTop: "15px",
							position: "relative"
						},
						"key-modal-label": {
							color: t.addKeyModal.labelColor,
							marginLeft: "2px",
							marginBottom: "5px",
							fontSize: "11px"
						},
						"key-modal-input-container": { overflow: "hidden" },
						"key-modal-input": {
							width: "100%",
							padding: "3px 6px",
							fontFamily: "monospace",
							color: t.addKeyModal.color,
							border: "none",
							boxSizing: "border-box",
							borderRadius: "2px"
						},
						"key-modal-cancel": {
							backgroundColor: t.editVariable.removeIcon,
							position: "absolute",
							top: "0px",
							right: "0px",
							borderRadius: "0px 3px 0px 3px",
							cursor: "pointer"
						},
						"key-modal-cancel-icon": {
							color: t.addKeyModal.labelColor,
							fontSize: h.iconFontSize,
							transform: "rotate(45deg)"
						},
						"key-modal-submit": {
							color: t.editVariable.addIcon,
							fontSize: h.iconFontSize,
							position: "absolute",
							right: "2px",
							top: "3px",
							cursor: "pointer"
						},
						"function-ellipsis": {
							display: "inline-block",
							color: t.ellipsisColor,
							fontSize: h.ellipsisFontSize,
							lineHeight: h.ellipsisLineHeight,
							cursor: h.ellipsisCursor
						},
						"validation-failure": {
							float: "right",
							padding: "3px 6px",
							borderRadius: "2px",
							cursor: "pointer",
							color: t.validationFailure.fontColor,
							backgroundColor: t.validationFailure.background
						},
						"validation-failure-label": { marginRight: "6px" },
						"validation-failure-clear": {
							position: "relative",
							verticalAlign: "top",
							cursor: "pointer",
							color: t.validationFailure.iconColor,
							fontSize: h.iconFontSize,
							transform: "rotate(45deg)"
						},
						comma: {
							display: "inline-block",
							color: h.commaColor,
							fontSize: h.commaFontSize,
							marginRight: h.commaMarginRight,
							cursor: "default"
						}
					};
				}, Yt = (e) => {
					let t = p;
					return e !== !1 && e !== "none" || (t = m), Gt(Jt, { defaultBase16: t })(e);
				};
				function z(e, t, n) {
					return e || console.error("theme has not been set"), Yt(e)(t, n);
				}
				let B = class extends n().PureComponent {
					render() {
						let { typeName: e, displayDataTypes: t, theme: r } = this.props;
						return t ? n().createElement("span", {
							className: "data-type-label",
							...z(r, "data-type-label")
						}, e) : null;
					}
				}, Xt = class extends n().PureComponent {
					render() {
						let { props: e } = this;
						return n().createElement("div", z(e.theme, "boolean"), n().createElement(B, {
							typeName: "bool",
							...e
						}), e.value ? "true" : "false");
					}
				}, Zt = class extends n().PureComponent {
					render() {
						let { props: e } = this;
						return n().createElement("div", z(e.theme, "date"), n().createElement(B, {
							typeName: "date",
							...e
						}), n().createElement("span", {
							className: "date-value",
							...z(e.theme, "date-value")
						}, e.value.toLocaleTimeString("en-us", {
							weekday: "short",
							year: "numeric",
							month: "short",
							day: "numeric",
							hour: "2-digit",
							minute: "2-digit"
						})));
					}
				}, Qt = class extends n().PureComponent {
					render() {
						let { props: e } = this;
						return n().createElement("div", z(e.theme, "float"), n().createElement(B, {
							typeName: "float",
							...e
						}), this.props.value);
					}
				};
				e();
				class $t {
					handler = () => {};
					register(e) {
						this.handler = e;
					}
					dispatch(e) {
						this.handler?.(e);
					}
				}
				globalThis.__globalDispatcherInstance || (globalThis.__globalDispatcherInstance = new $t());
				let V = globalThis.__globalDispatcherInstance, H = "updated_src";
				class en extends e().EventEmitter {
					objects = {};
					set = (e, t, n, r) => {
						this.objects[e] === void 0 && (this.objects[e] = {}), this.objects[e][t] === void 0 && (this.objects[e][t] = {}), this.objects[e][t][n] = r;
					};
					get = (e, t, n, r) => this.objects[e] === void 0 || this.objects[e][t] === void 0 || this.objects[e][t][n] === void 0 ? r : this.objects[e][t][n];
					handleAction = (e) => {
						let { rjvId: t, data: n, name: r } = e;
						switch (r) {
							case "RESET":
								this.emit("reset-" + t);
								break;
							case "VARIABLE_UPDATED":
								e.data[H] = this.updateSrc(t, n), this.set(t, "action", "variable-update", {
									...n,
									type: "variable-edited"
								}), this.emit("variable-update-" + t);
								break;
							case "VARIABLE_REMOVED":
								e.data[H] = this.updateSrc(t, n), this.set(t, "action", "variable-update", {
									...n,
									type: "variable-removed"
								}), this.emit("variable-update-" + t);
								break;
							case "VARIABLE_ADDED":
								e.data[H] = this.updateSrc(t, n), this.set(t, "action", "variable-update", {
									...n,
									type: "variable-added"
								}), this.emit("variable-update-" + t);
								break;
							case "ADD_VARIABLE_KEY_REQUEST": this.set(t, "action", "new-key-request", n), this.emit("add-key-request-" + t);
						}
					};
					updateSrc = (e, t) => {
						let { name: n, namespace: r } = t, i = t.new_value, a = t.variable_removed;
						r.shift();
						let o = this.get(e, "global", "src"), s = this.deepCopy(o, [...r]), c = s;
						for (let e of r) c = c[e];
						return a ? u(c) === "array" ? c.splice(n, 1) : delete c[n] : n === null ? s = i : c[n] = i, this.set(e, "global", "src", s), s;
					};
					deepCopy = (e, t) => {
						let n = u(e), r, i = t.shift();
						return n === "array" ? r = [...e] : n === "object" && (r = { ...e }), i !== void 0 && (r[i] = this.deepCopy(e[i], t)), r;
					};
				}
				let U = new en();
				V.register(U.handleAction.bind(U));
				let W = U, tn = class extends n().PureComponent {
					constructor(e) {
						super(e), this.state = { collapsed: W.get(e.rjvId, e.namespace, "collapsed", !0) };
					}
					handleToggleCollapsed = () => {
						this.setState({ collapsed: !this.state.collapsed }, () => {
							W.set(this.props.rjvId, this.props.namespace, "collapsed", this.state.collapsed);
						});
					};
					render() {
						let { props: e } = this, { collapsed: t } = this.state;
						return n().createElement("div", z(e.theme, "function"), n().createElement(B, {
							typeName: "function",
							...e
						}), n().createElement("span", {
							...z(e.theme, "function-value"),
							className: "rjv-function-container",
							onClick: this.handleToggleCollapsed
						}, this.getFunctionDisplay(t)));
					}
					getFunctionDisplay = (e) => {
						let { props: t } = this;
						return e ? n().createElement("span", null, this.props.value.toString().slice(9, -1).replace(/\{[\s\S]+/, ""), n().createElement("span", {
							className: "function-collapsed",
							style: { fontWeight: "bold" }
						}, n().createElement("span", null, "{"), n().createElement("span", z(t.theme, "ellipsis"), "..."), n().createElement("span", null, "}"))) : this.props.value.toString().slice(9, -1);
					};
				}, nn = class extends n().PureComponent {
					render() {
						return n().createElement("div", z(this.props.theme, "nan"), "NaN");
					}
				}, rn = class extends n().PureComponent {
					render() {
						return n().createElement("div", z(this.props.theme, "null"), "NULL");
					}
				}, an = class extends n().PureComponent {
					render() {
						let { props: e } = this;
						return n().createElement("div", z(e.theme, "integer"), n().createElement(B, {
							typeName: "int",
							...e
						}), this.props.value);
					}
				}, on = class extends n().PureComponent {
					render() {
						let { props: e } = this;
						return n().createElement("div", z(e.theme, "regexp"), n().createElement(B, {
							typeName: "regexp",
							...e
						}), this.props.value.toString());
					}
				}, sn = class extends n().PureComponent {
					constructor(e) {
						super(e), this.state = { collapsed: W.get(e.rjvId, e.namespace, "collapsed", !0) };
					}
					handleToggleCollapsed = () => {
						this.setState({ collapsed: !this.state.collapsed }, () => {
							W.set(this.props.rjvId, this.props.namespace, "collapsed", this.state.collapsed);
						});
					};
					render() {
						let { collapsed: e } = this.state, { props: t } = this, { collapseStringsAfterLength: r, theme: i, escapeStrings: a } = t, { value: o } = t, s = u(r) === "integer", c = { style: {
							cursor: "default",
							wordBreak: "break-all"
						} };
						return a && (o = d(o)), s && o.length > r && (c.style.cursor = "pointer", e && (o = n().createElement("span", null, o.substring(0, r), n().createElement("span", z(i, "ellipsis"), " ...")))), n().createElement("div", z(i, "string"), n().createElement(B, {
							typeName: "string",
							...t
						}), n().createElement("span", {
							className: "string-value",
							...c,
							onClick: this.handleToggleCollapsed
						}, "\"", o, "\""));
					}
				}, cn = class extends n().PureComponent {
					render() {
						return n().createElement("div", z(this.props.theme, "undefined"), "undefined");
					}
				}, ln = class extends n().PureComponent {
					render() {
						let { props: e } = this;
						return n().createElement("div", z(e.theme, "bigNumber"), n().createElement(B, {
							typeName: "bigNumber",
							...e
						}), this.props.value.toString());
					}
				};
				function G() {
					return G = Object.assign ? Object.assign.bind() : function(e) {
						for (var t = 1; t < arguments.length; t++) {
							var n = arguments[t];
							for (var r in n) ({}).hasOwnProperty.call(n, r) && (e[r] = n[r]);
						}
						return e;
					}, G.apply(null, arguments);
				}
				var un = t.useLayoutEffect, dn = function(e, t) {
					typeof e == "function" ? e(t) : e.current = t;
				}, fn = {
					"min-height": "0",
					"max-height": "none",
					height: "0",
					visibility: "hidden",
					overflow: "hidden",
					position: "absolute",
					"z-index": "-1000",
					top: "0",
					right: "0",
					display: "block"
				}, pn = function(e) {
					Object.keys(fn).forEach(function(t) {
						e.style.setProperty(t, fn[t], "important");
					});
				}, K = null, mn = function(e, t) {
					var n = e.scrollHeight;
					return t.sizingStyle.boxSizing === "border-box" ? n + t.borderSize : n - t.paddingSize;
				}, hn = function() {}, gn = [
					"borderBottomWidth",
					"borderLeftWidth",
					"borderRightWidth",
					"borderTopWidth",
					"boxSizing",
					"fontFamily",
					"fontSize",
					"fontStyle",
					"fontWeight",
					"letterSpacing",
					"lineHeight",
					"paddingBottom",
					"paddingLeft",
					"paddingRight",
					"paddingTop",
					"tabSize",
					"textIndent",
					"textRendering",
					"textTransform",
					"width",
					"wordBreak",
					"wordSpacing",
					"scrollbarGutter"
				], _n = !!document.documentElement.currentStyle, vn = function(e) {
					var t = window.getComputedStyle(e);
					if (t === null) return null;
					var n, r = (n = t, gn.reduce(function(e, t) {
						return e[t] = n[t], e;
					}, {})), i = r.boxSizing;
					return i === "" ? null : (_n && i === "border-box" && (r.width = parseFloat(r.width) + parseFloat(r.borderRightWidth) + parseFloat(r.borderLeftWidth) + parseFloat(r.paddingRight) + parseFloat(r.paddingLeft) + "px"), {
						sizingStyle: r,
						paddingSize: parseFloat(r.paddingBottom) + parseFloat(r.paddingTop),
						borderSize: parseFloat(r.borderBottomWidth) + parseFloat(r.borderTopWidth)
					});
				};
				function q(e, r, i) {
					var a, o, s = (a = i, o = n().useRef(a), un(function() {
						o.current = a;
					}), o);
					t.useLayoutEffect(function() {
						var t = function(e) {
							return s.current(e);
						};
						if (e) return e.addEventListener(r, t), function() {
							return e.removeEventListener(r, t);
						};
					}, []);
				}
				var yn = [
					"cacheMeasurements",
					"maxRows",
					"minRows",
					"onChange",
					"onHeightChange"
				], bn = t.forwardRef(function(e, r) {
					var i = e.cacheMeasurements, a = e.maxRows, o = e.minRows, s = e.onChange, c = s === void 0 ? hn : s, l = e.onHeightChange, u = l === void 0 ? hn : l, d = function(e, t) {
						if (e == null) return {};
						var n = {};
						for (var r in e) if ({}.hasOwnProperty.call(e, r)) {
							if (t.indexOf(r) !== -1) continue;
							n[r] = e[r];
						}
						return n;
					}(e, yn), f = d.value !== void 0, p = t.useRef(null), m = function(e, t) {
						var r = n().useRef();
						return n().useCallback(function(n) {
							e.current = n, r.current && dn(r.current, null), r.current = t, t && dn(t, n);
						}, [t]);
					}(p, r), h = t.useRef(0), g = t.useRef(), _ = function() {
						var e = p.current, t = i && g.current ? g.current : vn(e);
						if (t) {
							g.current = t;
							var n = function(e, t, n, r) {
								n === void 0 && (n = 1), r === void 0 && (r = 1 / 0), K || ((K = document.createElement("textarea")).setAttribute("tabindex", "-1"), K.setAttribute("aria-hidden", "true"), pn(K)), K.parentNode === null && document.body.appendChild(K);
								var i = e.paddingSize, a = e.borderSize, o = e.sizingStyle, s = o.boxSizing;
								Object.keys(o).forEach(function(e) {
									var t = e;
									K.style[t] = o[t];
								}), pn(K), K.value = t;
								var c = mn(K, e);
								K.value = t, c = mn(K, e), K.value = "x";
								var l = K.scrollHeight - i, u = l * n;
								s === "border-box" && (u = u + i + a), c = Math.max(u, c);
								var d = l * r;
								return s === "border-box" && (d = d + i + a), [c = Math.min(d, c), l];
							}(t, e.value || e.placeholder || "x", o, a), r = n[0], s = n[1];
							h.current !== r && (h.current = r, e.style.setProperty("height", r + "px", "important"), u(r, { rowHeight: s }));
						}
					};
					return t.useLayoutEffect(_), function(e, t) {
						q(document.body, "reset", function(n) {
							e.current.form === n.target && t(n);
						});
					}(p, function() {
						if (!f) {
							var e = p.current.value;
							requestAnimationFrame(function() {
								var t = p.current;
								t && e !== t.value && _();
							});
						}
					}), q(window, "resize", _), function(e) {
						q(document.fonts, "loadingdone", e);
					}(_), t.createElement("textarea", G({}, d, {
						onChange: function(e) {
							f || _(), c(e);
						},
						ref: m
					}));
				});
				function xn(e, t) {
					e = e.trim();
					try {
						if ((e = structuredClone(e))[0] === "[") return J("array", JSON.parse(e));
						if (e[0] === "{") return J("object", JSON.parse(e));
						if (e.match(/-?\d+\.\d+/) && e.match(/-?\d+\.\d+/)[0] === e) return t && parseFloat(e).toString() !== e ? J("bigNumber", e) : J("float", parseFloat(e));
						if (e.match(/-?\d+e-\d+/) && e.match(/-?\d+e-\d+/)[0] === e) return J("float", Number(e));
						if (e.match(/-?\d+/) && e.match(/-?\d+/)[0] === e) return t && parseInt(e).toString() !== e ? J("bigNumber", e) : J("integer", parseInt(e));
						if (e.match(/-?\d+e\+\d+/) && e.match(/-?\d+e\+\d+/)[0] === e) return J("integer", Number(e));
					} catch {}
					switch (e = e.toLowerCase()) {
						case "undefined": return J("undefined", void 0);
						case "nan": return J("nan", NaN);
						case "null": return J("null", null);
						case "true": return J("boolean", !0);
						case "false": return J("boolean", !1);
						default: if (e = Date.parse(e)) return J("date", new Date(e));
					}
					return J(!1, null);
				}
				function J(e, t) {
					return {
						type: e,
						value: t
					};
				}
				class Sn extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e;
						return n().createElement("span", r, n().createElement("svg", {
							...X(t),
							viewBox: "0 0 24 24",
							fill: "currentColor",
							preserveAspectRatio: "xMidYMid meet"
						}, n().createElement("path", { d: "M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M7,13H17V11H7" })));
					}
				}
				class Cn extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e;
						return n().createElement("span", r, n().createElement("svg", {
							...X(t),
							viewBox: "0 0 24 24",
							fill: "currentColor",
							preserveAspectRatio: "xMidYMid meet"
						}, n().createElement("path", { d: "M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M13,7H11V11H7V13H11V17H13V13H17V11H13V7Z" })));
					}
				}
				class wn extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e, i = X(t).style;
						return n().createElement("span", r, n().createElement("svg", {
							fill: i.color,
							width: i.height,
							height: i.width,
							style: i,
							viewBox: "0 0 1792 1792"
						}, n().createElement("path", { d: "M1344 800v64q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-64q0-14 9-23t23-9h832q14 0 23 9t9 23zm128 448v-832q0-66-47-113t-113-47h-832q-66 0-113 47t-47 113v832q0 66 47 113t113 47h832q66 0 113-47t47-113zm128-832v832q0 119-84.5 203.5t-203.5 84.5h-832q-119 0-203.5-84.5t-84.5-203.5v-832q0-119 84.5-203.5t203.5-84.5h832q119 0 203.5 84.5t84.5 203.5z" })));
					}
				}
				class Tn extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e, i = X(t).style;
						return n().createElement("span", r, n().createElement("svg", {
							fill: i.color,
							width: i.height,
							height: i.width,
							style: i,
							viewBox: "0 0 1792 1792"
						}, n().createElement("path", { d: "M1344 800v64q0 14-9 23t-23 9h-352v352q0 14-9 23t-23 9h-64q-14 0-23-9t-9-23v-352h-352q-14 0-23-9t-9-23v-64q0-14 9-23t23-9h352v-352q0-14 9-23t23-9h64q14 0 23 9t9 23v352h352q14 0 23 9t9 23zm128 448v-832q0-66-47-113t-113-47h-832q-66 0-113 47t-47 113v832q0 66 47 113t113 47h832q66 0 113-47t47-113zm128-832v832q0 119-84.5 203.5t-203.5 84.5h-832q-119 0-203.5-84.5t-84.5-203.5v-832q0-119 84.5-203.5t203.5-84.5h832q119 0 203.5 84.5t84.5 203.5z" })));
					}
				}
				class En extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e;
						return n().createElement("span", r, n().createElement("svg", {
							style: {
								...X(t).style,
								paddingLeft: "2px",
								verticalAlign: "top"
							},
							viewBox: "0 0 15 15",
							fill: "currentColor"
						}, n().createElement("path", { d: "M0 14l6-6-6-6z" })));
					}
				}
				class Dn extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e;
						return n().createElement("span", r, n().createElement("svg", {
							style: {
								...X(t).style,
								paddingLeft: "2px",
								verticalAlign: "top"
							},
							viewBox: "0 0 15 15",
							fill: "currentColor"
						}, n().createElement("path", { d: "M0 5l6 6 6-6z" })));
					}
				}
				class On extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e;
						return n().createElement("span", r, n().createElement("svg", {
							...X(t),
							viewBox: "0 0 40 40",
							fill: "currentColor",
							preserveAspectRatio: "xMidYMid meet"
						}, n().createElement("g", null, n().createElement("path", { d: "m30 35h-25v-22.5h25v7.5h2.5v-12.5c0-1.4-1.1-2.5-2.5-2.5h-7.5c0-2.8-2.2-5-5-5s-5 2.2-5 5h-7.5c-1.4 0-2.5 1.1-2.5 2.5v27.5c0 1.4 1.1 2.5 2.5 2.5h25c1.4 0 2.5-1.1 2.5-2.5v-5h-2.5v5z m-20-27.5h2.5s2.5-1.1 2.5-2.5 1.1-2.5 2.5-2.5 2.5 1.1 2.5 2.5 1.3 2.5 2.5 2.5h2.5s2.5 1.1 2.5 2.5h-20c0-1.5 1.1-2.5 2.5-2.5z m-2.5 20h5v-2.5h-5v2.5z m17.5-5v-5l-10 7.5 10 7.5v-5h12.5v-5h-12.5z m-17.5 10h7.5v-2.5h-7.5v2.5z m12.5-17.5h-12.5v2.5h12.5v-2.5z m-7.5 5h-5v2.5h5v-2.5z" }))));
					}
				}
				class Y extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e;
						return n().createElement("span", r, n().createElement("svg", {
							...X(t),
							viewBox: "0 0 40 40",
							fill: "currentColor",
							preserveAspectRatio: "xMidYMid meet"
						}, n().createElement("g", null, n().createElement("path", { d: "m28.6 25q0-0.5-0.4-1l-4-4 4-4q0.4-0.5 0.4-1 0-0.6-0.4-1.1l-2-2q-0.4-0.4-1-0.4-0.6 0-1 0.4l-4.1 4.1-4-4.1q-0.4-0.4-1-0.4-0.6 0-1 0.4l-2 2q-0.5 0.5-0.5 1.1 0 0.5 0.5 1l4 4-4 4q-0.5 0.5-0.5 1 0 0.7 0.5 1.1l2 2q0.4 0.4 1 0.4 0.6 0 1-0.4l4-4.1 4.1 4.1q0.4 0.4 1 0.4 0.6 0 1-0.4l2-2q0.4-0.4 0.4-1z m8.7-5q0 4.7-2.3 8.6t-6.3 6.2-8.6 2.3-8.6-2.3-6.2-6.2-2.3-8.6 2.3-8.6 6.2-6.2 8.6-2.3 8.6 2.3 6.3 6.2 2.3 8.6z" }))));
					}
				}
				class kn extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e;
						return n().createElement("span", r, n().createElement("svg", {
							...X(t),
							viewBox: "0 0 40 40",
							fill: "currentColor",
							preserveAspectRatio: "xMidYMid meet"
						}, n().createElement("g", null, n().createElement("path", { d: "m30.1 21.4v-2.8q0-0.6-0.4-1t-1-0.5h-5.7v-5.7q0-0.6-0.4-1t-1-0.4h-2.9q-0.6 0-1 0.4t-0.4 1v5.7h-5.7q-0.6 0-1 0.5t-0.5 1v2.8q0 0.6 0.5 1t1 0.5h5.7v5.7q0 0.5 0.4 1t1 0.4h2.9q0.6 0 1-0.4t0.4-1v-5.7h5.7q0.6 0 1-0.5t0.4-1z m7.2-1.4q0 4.7-2.3 8.6t-6.3 6.2-8.6 2.3-8.6-2.3-6.2-6.2-2.3-8.6 2.3-8.6 6.2-6.2 8.6-2.3 8.6 2.3 6.3 6.2 2.3 8.6z" }))));
					}
				}
				class An extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e;
						return n().createElement("span", r, n().createElement("svg", {
							...X(t),
							viewBox: "0 0 40 40",
							fill: "currentColor",
							preserveAspectRatio: "xMidYMid meet"
						}, n().createElement("g", null, n().createElement("path", { d: "m31.6 21.6h-10v10h-3.2v-10h-10v-3.2h10v-10h3.2v10h10v3.2z" }))));
					}
				}
				class jn extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e;
						return n().createElement("span", r, n().createElement("svg", {
							...X(t),
							viewBox: "0 0 40 40",
							fill: "currentColor",
							preserveAspectRatio: "xMidYMid meet"
						}, n().createElement("g", null, n().createElement("path", { d: "m19.8 26.4l2.6-2.6-3.4-3.4-2.6 2.6v1.3h2.2v2.1h1.2z m9.8-16q-0.3-0.4-0.7 0l-7.8 7.8q-0.4 0.4 0 0.7t0.7 0l7.8-7.8q0.4-0.4 0-0.7z m1.8 13.2v4.3q0 2.6-1.9 4.5t-4.5 1.9h-18.6q-2.6 0-4.5-1.9t-1.9-4.5v-18.6q0-2.7 1.9-4.6t4.5-1.8h18.6q1.4 0 2.6 0.5 0.3 0.2 0.4 0.5 0.1 0.4-0.2 0.7l-1.1 1.1q-0.3 0.3-0.7 0.1-0.5-0.1-1-0.1h-18.6q-1.4 0-2.5 1.1t-1 2.5v18.6q0 1.4 1 2.5t2.5 1h18.6q1.5 0 2.5-1t1.1-2.5v-2.9q0-0.2 0.2-0.4l1.4-1.5q0.3-0.3 0.8-0.1t0.4 0.6z m-2.1-16.5l6.4 6.5-15 15h-6.4v-6.5z m9.9 3l-2.1 2-6.4-6.4 2.1-2q0.6-0.7 1.5-0.7t1.5 0.7l3.4 3.4q0.6 0.6 0.6 1.5t-0.6 1.5z" }))));
					}
				}
				class Mn extends n().PureComponent {
					render() {
						let { props: e } = this, { style: t, ...r } = e;
						return n().createElement("span", r, n().createElement("svg", {
							...X(t),
							viewBox: "0 0 40 40",
							fill: "currentColor",
							preserveAspectRatio: "xMidYMid meet"
						}, n().createElement("g", null, n().createElement("path", { d: "m31.7 16.4q0-0.6-0.4-1l-2.1-2.1q-0.4-0.4-1-0.4t-1 0.4l-9.1 9.1-5-5q-0.5-0.4-1-0.4t-1 0.4l-2.1 2q-0.4 0.4-0.4 1 0 0.6 0.4 1l8.1 8.1q0.4 0.4 1 0.4 0.6 0 1-0.4l12.2-12.1q0.4-0.4 0.4-1z m5.6 3.6q0 4.7-2.3 8.6t-6.3 6.2-8.6 2.3-8.6-2.3-6.2-6.2-2.3-8.6 2.3-8.6 6.2-6.2 8.6-2.3 8.6 2.3 6.3 6.2 2.3 8.6z" }))));
					}
				}
				function X(e) {
					return e ||= {}, { style: {
						verticalAlign: "middle",
						...e,
						color: e.color ? e.color : "#000000",
						height: "1em",
						width: "1em"
					} };
				}
				let Nn = class extends n().PureComponent {
					constructor(e) {
						super(e), this.state = { copied: !1 };
					}
					copiedTimer = null;
					componentWillUnmount() {
						this.copiedTimer &&= (clearTimeout(this.copiedTimer), null);
					}
					copyToClipboardFallback = (e) => {
						let t = document.createElement("textarea");
						t.value = e, document.body.appendChild(t), t.select(), document.execCommand("copy"), document.body.removeChild(t);
					};
					handleCopy = () => {
						let { clickCallback: e, src: t, namespace: n } = this.props, r = this.clipboardText(t);
						navigator.clipboard ? navigator.clipboard.writeText(r).catch(() => {
							this.copyToClipboardFallback(r);
						}) : this.copyToClipboardFallback(r), this.copiedTimer = setTimeout(() => {
							this.setState({ copied: !1 });
						}, 5500), this.setState({ copied: !0 }, () => {
							typeof e == "function" && e({
								src: t,
								namespace: n,
								name: n[n.length - 1]
							});
						});
					};
					getClippyIcon = () => {
						let { theme: e } = this.props;
						return this.state.copied ? n().createElement("span", null, n().createElement(On, {
							className: "copy-icon",
							...z(e, "copy-icon")
						}), n().createElement("span", z(e, "copy-icon-copied"), "✔")) : n().createElement(On, {
							className: "copy-icon",
							...z(e, "copy-icon")
						});
					};
					clipboardValue = (e) => {
						switch (u(e)) {
							case "function":
							case "regexp": return e.toString();
							default: return e;
						}
					};
					clipboardText = (e) => {
						let t = this.clipboardValue(e);
						return typeof t == "string" ? t : JSON.stringify(t, null, "  ");
					};
					render() {
						let { theme: e, hidden: t, rowHovered: r } = this.props, i = z(e, "copy-to-clipboard").style, a = "inline";
						return t && (a = "none"), n().createElement("span", {
							className: "copy-to-clipboard-container",
							title: "Copy to clipboard",
							style: {
								verticalAlign: "top",
								display: r ? "inline-block" : "none"
							}
						}, n().createElement("span", {
							style: {
								...i,
								display: a
							},
							onClick: this.handleCopy
						}, this.getClippyIcon()));
					}
				};
				class Pn extends n().PureComponent {
					constructor(e) {
						super(e), this.state = {
							editMode: !1,
							editValue: "",
							hovered: !1,
							renameKey: !1,
							parsedInput: {
								type: !1,
								value: null
							}
						};
					}
					render() {
						let { variable: e, singleIndent: t, type: r, theme: i, namespace: a, indentWidth: o, enableClipboard: s, onEdit: c, onDelete: l, onSelect: u, displayArrayKey: f, quotesOnKeys: p, showComma: m, isLast: h } = this.props, { editMode: g } = this.state, _ = u !== !1 || c !== !1;
						return n().createElement("div", {
							...z(i, "objectKeyVal", { paddingLeft: o * t }),
							onMouseEnter: () => this.setState({
								...this.state,
								hovered: !0
							}),
							onMouseLeave: () => this.setState({
								...this.state,
								hovered: !1
							}),
							className: "variable-row",
							key: e.name
						}, r === "array" ? f ? n().createElement("span", {
							...z(i, "array-key"),
							key: e.name + "_" + a
						}, e.name, n().createElement("div", z(i, "colon"), ":")) : null : n().createElement("span", null, n().createElement("span", {
							...z(i, "object-name"),
							className: "object-key",
							key: e.name + "_" + a,
							onClick: _ ? this.handleSelect : null
						}, !!p && n().createElement("span", { style: { verticalAlign: "top" } }, "\""), n().createElement("span", { style: { display: "inline-block" } }, d(e.name)), !!p && n().createElement("span", { style: { verticalAlign: "top" } }, "\"")), n().createElement("span", z(i, "colon"), ":")), n().createElement("div", {
							className: "variable-value",
							onClick: _ ? this.handleSelect : null,
							...z(i, "variableValue", { cursor: u === !1 ? "default" : "pointer" })
						}, this.getValue(e, g)), m && !h && n().createElement("span", z(i, "comma"), ","), s ? n().createElement(Nn, {
							rowHovered: this.state.hovered,
							hidden: g,
							src: e.value,
							clickCallback: s,
							theme: i,
							namespace: [...a, e.name]
						}) : null, c !== !1 && g === !1 ? this.getEditIcon() : null, l !== !1 && g === !1 ? this.getRemoveIcon() : null);
					}
					handleSelect = (e) => {
						let { variable: t, namespace: n, onEdit: r, onSelect: i, keyModifier: a } = this.props, o = [...n];
						a(e, "edit") && r !== !1 ? this.prepopInput(t) : i !== !1 && (o.shift(), i({
							...t,
							namespace: o
						}));
					};
					getEditIcon = () => {
						let { variable: e, theme: t } = this.props;
						return n().createElement("div", {
							className: "click-to-edit",
							style: {
								verticalAlign: "top",
								display: this.state.hovered ? "inline-block" : "none"
							}
						}, n().createElement(jn, {
							className: "click-to-edit-icon",
							...z(t, "editVarIcon"),
							onClick: () => {
								this.prepopInput(e);
							}
						}));
					};
					prepopInput = (e) => {
						if (this.props.onEdit !== !1) {
							let t = ((e, t) => {
								let n;
								switch (u(e, t)) {
									case "undefined":
										n = "undefined";
										break;
									case "nan":
										n = "NaN";
										break;
									case "string":
										n = e;
										break;
									case "bigNumber":
									case "date":
									case "function":
									case "regexp":
										n = e.toString();
										break;
									default: try {
										n = JSON.stringify(e, null, "  ");
									} catch {
										n = "";
									}
								}
								return n;
							})(e.value, this.props.bigNumber), n = xn(t, this.props.bigNumber);
							this.setState({
								editMode: !0,
								editValue: t,
								parsedInput: {
									type: n.type,
									value: n.value
								}
							});
						}
					};
					getRemoveIcon = () => {
						let { variable: e, namespace: t, theme: r, rjvId: i } = this.props;
						return n().createElement("div", {
							className: "click-to-remove",
							style: {
								verticalAlign: "top",
								display: this.state.hovered ? "inline-block" : "none"
							}
						}, n().createElement(Y, {
							className: "click-to-remove-icon",
							...z(r, "removeVarIcon"),
							onClick: () => {
								V.dispatch({
									name: "VARIABLE_REMOVED",
									rjvId: i,
									data: {
										name: e.name,
										namespace: t,
										existing_value: e.value,
										variable_removed: !0
									}
								});
							}
						}));
					};
					getValue = (e, t) => {
						let r = !t && e.type, { props: i } = this;
						switch (r) {
							case !1: return this.getEditInput();
							case "string": return n().createElement(sn, {
								value: e.value,
								...i
							});
							case "integer": return n().createElement(an, {
								value: e.value,
								...i
							});
							case "float": return n().createElement(Qt, {
								value: e.value,
								...i
							});
							case "boolean": return n().createElement(Xt, {
								value: e.value,
								...i
							});
							case "function": return n().createElement(tn, {
								value: e.value,
								...i
							});
							case "null": return n().createElement(rn, i);
							case "nan": return n().createElement(nn, i);
							case "undefined": return n().createElement(cn, i);
							case "date": return n().createElement(Zt, {
								value: e.value,
								...i
							});
							case "regexp": return n().createElement(on, {
								value: e.value,
								...i
							});
							case "bigNumber": return n().createElement(ln, {
								value: e.value,
								...i
							});
							case "circularReference": return n().createElement(JsonCircularReference, {
								value: e.value,
								...i
							});
							default:
								var a = "";
								try {
									a = JSON.stringify(e.value);
								} catch {
									a = "";
								}
								return n().createElement("div", { className: "object-value" }, a);
						}
					};
					getEditInput = () => {
						let { keyModifier: e, selectOnFocus: t, theme: r } = this.props, { editValue: i } = this.state;
						return n().createElement("div", null, n().createElement(bn, {
							type: "text",
							ref: (e) => {
								e && e[t ? "select" : "focus"]();
							},
							value: i,
							className: "variable-editor",
							onChange: (e) => {
								let t = e.target.value, n = xn(t, this.props.bigNumber);
								this.setState({
									editValue: t,
									parsedInput: {
										type: n.type,
										value: n.value
									}
								});
							},
							onKeyDown: (t) => {
								switch (t.key) {
									case "Escape":
										this.setState({
											editMode: !1,
											editValue: ""
										});
										break;
									case "Enter": e(t, "submit") && this.submitEdit(!0);
								}
								t.stopPropagation();
							},
							placeholder: "update this value",
							minRows: 2,
							...z(r, "edit-input")
						}), n().createElement("div", z(r, "edit-icon-container"), n().createElement(Y, {
							className: "edit-cancel",
							...z(r, "cancel-icon"),
							onClick: (e) => {
								e && e.stopPropagation(), this.setState({
									editMode: !1,
									editValue: ""
								});
							}
						}), n().createElement(Mn, {
							className: "edit-check string-value",
							...z(r, "check-icon"),
							onClick: (e) => {
								e && e.stopPropagation(), this.submitEdit();
							}
						}), n().createElement("div", null, this.showDetected())));
					};
					submitEdit = (e) => {
						let { variable: t, namespace: n, rjvId: r, bigNumber: i } = this.props, { editValue: a, parsedInput: o } = this.state, s = a;
						e && o.type && (s = o.value, i && o.type === "bigNumber" && (s = new i(s))), this.setState({ editMode: !1 }), V.dispatch({
							name: "VARIABLE_UPDATED",
							rjvId: r,
							data: {
								name: t.name,
								namespace: n,
								existing_value: t.value,
								new_value: s,
								variable_removed: !1
							}
						});
					};
					showDetected = () => {
						let { theme: e } = this.props, t = this.getDetectedInput();
						if (t) return n().createElement("div", null, n().createElement("div", z(e, "detected-row"), t, n().createElement(Mn, {
							className: "edit-check detected",
							style: {
								verticalAlign: "top",
								paddingLeft: "3px",
								...z(e, "check-icon").style
							},
							onClick: (e) => {
								e && e.stopPropagation(), this.submitEdit(!0);
							}
						})));
					};
					getDetectedInput = () => {
						let { parsedInput: e } = this.state, { type: t, value: r } = e, { props: i } = this, { theme: a } = i;
						if (t !== !1) switch (t.toLowerCase()) {
							case "object": return n().createElement("span", null, n().createElement("span", { style: {
								...z(a, "brace").style,
								cursor: "default"
							} }, "{"), n().createElement("span", { style: {
								...z(a, "ellipsis").style,
								cursor: "default"
							} }, "..."), n().createElement("span", { style: {
								...z(a, "brace").style,
								cursor: "default"
							} }, "}"));
							case "array": return n().createElement("span", null, n().createElement("span", { style: {
								...z(a, "brace").style,
								cursor: "default"
							} }, "["), n().createElement("span", { style: {
								...z(a, "ellipsis").style,
								cursor: "default"
							} }, "..."), n().createElement("span", { style: {
								...z(a, "brace").style,
								cursor: "default"
							} }, "]"));
							case "string": return n().createElement(sn, {
								value: r,
								...i
							});
							case "integer": return n().createElement(an, {
								value: r,
								...i
							});
							case "float": return n().createElement(Qt, {
								value: r,
								...i
							});
							case "boolean": return n().createElement(Xt, {
								value: r,
								...i
							});
							case "function": return n().createElement(tn, {
								value: r,
								...i
							});
							case "null": return n().createElement(rn, i);
							case "nan": return n().createElement(nn, i);
							case "undefined": return n().createElement(cn, i);
							case "date": return n().createElement(Zt, {
								value: new Date(r),
								...i
							});
							case "bignumber": return n().createElement(ln, {
								value: r,
								...i
							});
							case "circularreference": return n().createElement(JsonCircularReference, {
								value: variable.value,
								...i
							});
						}
					};
				}
				let Fn = Pn, In = class extends n().PureComponent {
					getObjectSize = () => {
						let { size: e, theme: t, displayObjectSize: r } = this.props;
						if (r) return n().createElement("span", {
							className: "object-size",
							...z(t, "object-size")
						}, e, " item", e === 1 ? "" : "s");
					};
					getAddAttribute = (e) => {
						let { theme: t, namespace: r, name: i, src: a, rjvId: o, depth: s } = this.props;
						return n().createElement("span", {
							className: "click-to-add",
							style: {
								verticalAlign: "top",
								display: e ? "inline-block" : "none"
							}
						}, n().createElement(kn, {
							className: "click-to-add-icon",
							...z(t, "addVarIcon"),
							onClick: () => {
								let e = {
									name: s > 0 ? i : null,
									namespace: r.splice(0, r.length - 1),
									existing_value: a,
									variable_removed: !1,
									key_name: null
								};
								u(a) === "object" ? V.dispatch({
									name: "ADD_VARIABLE_KEY_REQUEST",
									rjvId: o,
									data: e
								}) : V.dispatch({
									name: "VARIABLE_ADDED",
									rjvId: o,
									data: {
										...e,
										new_value: [...a, null]
									}
								});
							}
						}));
					};
					getRemoveObject = (e) => {
						let { theme: t, namespace: r, name: i, src: a, rjvId: o } = this.props;
						if (r.length !== 1) return n().createElement("span", {
							className: "click-to-remove",
							style: { display: e ? "inline-block" : "none" }
						}, n().createElement(Y, {
							className: "click-to-remove-icon",
							...z(t, "removeVarIcon"),
							onClick: () => {
								V.dispatch({
									name: "VARIABLE_REMOVED",
									rjvId: o,
									data: {
										name: i,
										namespace: r.splice(0, r.length - 1),
										existing_value: a,
										variable_removed: !0
									}
								});
							}
						}));
					};
					render = () => {
						let { theme: e, onDelete: t, onAdd: r, enableClipboard: i, src: a, namespace: o, rowHovered: s } = this.props;
						return n().createElement("div", {
							...z(e, "object-meta-data"),
							className: "object-meta-data",
							onClick: (e) => {
								e.stopPropagation();
							}
						}, this.getObjectSize(), i ? n().createElement(Nn, {
							rowHovered: s,
							clickCallback: i,
							src: a,
							theme: e,
							namespace: o
						}) : null, r === !1 ? null : this.getAddAttribute(s), t === !1 ? null : this.getRemoveObject(s));
					};
				};
				function Ln(e) {
					let { parent_type: t, namespace: r, quotesOnKeys: i, theme: a, jsvRoot: o, name: s, displayArrayKey: c, onKeyClick: l } = e, u = e.name ? e.name : "", d = typeof l == "function" ? l : null;
					return !o || s !== !1 && s !== null ? t === "array" ? c ? n().createElement("span", {
						...z(a, "array-key"),
						key: r,
						onClick: d
					}, n().createElement("span", { className: "array-key" }, u), n().createElement("span", z(a, "colon"), ":")) : n().createElement("span", null) : n().createElement("span", {
						...z(a, "object-name"),
						key: r,
						onClick: d
					}, n().createElement("span", { className: "object-key" }, i && n().createElement("span", { style: { verticalAlign: "top" } }, "\""), n().createElement("span", null, u), i && n().createElement("span", { style: { verticalAlign: "top" } }, "\"")), n().createElement("span", z(a, "colon"), ":")) : n().createElement("span", null);
				}
				function Rn(e) {
					let { theme: t, iconStyle: r } = e;
					switch (r) {
						case "triangle": return n().createElement(Dn, {
							...z(t, "expanded-icon"),
							className: "expanded-icon"
						});
						case "square": return n().createElement(wn, {
							...z(t, "expanded-icon"),
							className: "expanded-icon"
						});
						default: return n().createElement(Sn, {
							...z(t, "expanded-icon"),
							className: "expanded-icon"
						});
					}
				}
				function zn(e) {
					let { theme: t, iconStyle: r } = e;
					switch (r) {
						case "triangle": return n().createElement(En, {
							...z(t, "collapsed-icon"),
							className: "collapsed-icon"
						});
						case "square": return n().createElement(Tn, {
							...z(t, "collapsed-icon"),
							className: "collapsed-icon"
						});
						default: return n().createElement(Cn, {
							...z(t, "collapsed-icon"),
							className: "collapsed-icon"
						});
					}
				}
				let Bn = class extends n().PureComponent {
					constructor(e) {
						super(e), this.state = { expanded: [] };
					}
					toggleCollapsed = (e) => {
						let { expanded: t } = this.state, n = [], r = Math.max(t.length || 0, e + 1);
						for (let e = 0; e < r; e++) n[e] = t[e] === !0;
						n[e] = !n[e], this.setState({ expanded: n });
					};
					getExpandedIcon(e) {
						let { theme: t, iconStyle: r } = this.props;
						return this.state.expanded[e] ? n().createElement(Rn, {
							theme: t,
							iconStyle: r
						}) : n().createElement(zn, {
							theme: t,
							iconStyle: r
						});
					}
					handleKeySelect = () => {
						let { name: e, namespace: t, onSelect: n, src: r } = this.props;
						if (typeof n != "function") return;
						let i = [...t];
						i.shift(), i.length > 0 && i.pop(), n({
							name: e,
							value: r,
							type: "array",
							namespace: i
						});
					};
					render() {
						let { src: e, groupArraysAfterLength: t, depth: r, name: i, theme: a, jsvRoot: o, namespace: s, ...c } = this.props, l = 0, u = 5 * this.props.indentWidth;
						o || (l = 5 * this.props.indentWidth);
						let d = t, f = Math.ceil(e.length / d);
						return n().createElement("div", {
							className: "object-key-val",
							...z(a, o ? "jsv-root" : "objectKeyVal", { paddingLeft: l })
						}, n().createElement(Ln, {
							...this.props,
							onKeyClick: this.handleKeySelect
						}), n().createElement("span", null, n().createElement(In, {
							size: e.length,
							...this.props
						})), [...Array(f)].map((t, r) => n().createElement("div", {
							key: r,
							className: "object-key-val array-group",
							...z(a, "objectKeyVal", {
								marginLeft: 6,
								paddingLeft: u
							})
						}, n().createElement("span", z(a, "brace-row"), n().createElement("div", {
							className: "icon-container",
							...z(a, "icon-container"),
							onClick: (e) => {
								this.toggleCollapsed(r);
							}
						}, this.getExpandedIcon(r)), this.state.expanded[r] ? n().createElement(Q, {
							key: i + r,
							depth: 0,
							name: !1,
							collapsed: !1,
							groupArraysAfterLength: d,
							index_offset: r * d,
							src: e.slice(r * d, r * d + d),
							namespace: s,
							type: "array",
							parent_type: "array_group",
							theme: a,
							showComma: this.props.showComma,
							isLast: r === f - 1,
							...c
						}) : n().createElement("span", {
							...z(a, "brace"),
							onClick: (e) => {
								this.toggleCollapsed(r);
							},
							className: "array-group-brace"
						}, "[", n().createElement("div", {
							...z(a, "array-group-meta-data"),
							className: "array-group-meta-data"
						}, n().createElement("span", {
							className: "object-size",
							...z(a, "object-size")
						}, r * d, " - ", r * d + d - 1 > e.length ? e.length - 1 : r * d + d - 1)), "]")))));
					}
				};
				class Z extends n().PureComponent {
					constructor(e) {
						super(e);
						let t = Z.getState(e);
						this.state = {
							...t,
							prevProps: {}
						}, this.listOfAncestors = Array.from(this.props.listOfAncestors || []), this.listOfAncestors.push(e.src);
					}
					static getState = (e) => {
						let t = Object.keys(e.src).length, n = (e.collapsed === !1 || e.collapsed !== !0 && e.collapsed > e.depth) && (!e.shouldCollapse || e.shouldCollapse({
							name: e.name,
							src: e.src,
							type: u(e.src),
							namespace: e.namespace
						}) === !1) && t !== 0;
						return {
							expanded: W.get(e.rjvId, e.namespace, "expanded", n),
							object_type: e.type === "array" ? "array" : "object",
							parent_type: e.type === "array" ? "array" : "object",
							size: t,
							hovered: !1
						};
					};
					static getDerivedStateFromProps(e, t) {
						let { prevProps: n } = t;
						return e.src !== n.src || e.collapsed !== n.collapsed || e.name !== n.name || e.namespace !== n.namespace || e.rjvId !== n.rjvId ? {
							...Z.getState(e),
							prevProps: e
						} : null;
					}
					handleToggleCollapsed = () => {
						this.setState({ expanded: !this.state.expanded }, () => {
							W.set(this.props.rjvId, this.props.namespace, "expanded", this.state.expanded);
						});
					};
					handleKeySelect = () => {
						let { name: e, namespace: t, onSelect: n, src: r } = this.props, { object_type: i } = this.state;
						if (typeof n != "function") return;
						let a = [...t];
						a.shift(), a.length > 0 && a.pop(), n({
							name: e,
							value: r,
							type: i,
							namespace: a
						});
					};
					getObjectContent = (e, t, r) => n().createElement("div", { className: "pushed-content object-container" }, n().createElement("div", {
						className: "object-content",
						...z(this.props.theme, "pushed-content")
					}, this.renderObjectContents(t, r)));
					getEllipsis = () => {
						let { size: e } = this.state;
						return e === 0 ? null : n().createElement("div", {
							...z(this.props.theme, "ellipsis"),
							className: "node-ellipsis",
							onClick: this.handleToggleCollapsed
						}, "...");
					};
					getObjectMetaData = (e) => {
						let { size: t, hovered: r } = this.state;
						return n().createElement(In, {
							rowHovered: r,
							size: t,
							...this.props
						});
					};
					getBraceStart(e, t) {
						let { theme: r, iconStyle: i, parent_type: a } = this.props;
						if (a === "array_group") return n().createElement("span", null, n().createElement("span", z(r, "brace"), e === "array" ? "[" : "{"));
						let o = t ? Rn : zn;
						return n().createElement("span", null, n().createElement("span", {
							onClick: this.handleToggleCollapsed,
							...z(r, "brace-row")
						}, n().createElement("div", {
							className: "icon-container",
							...z(r, "icon-container")
						}, n().createElement(o, {
							theme: r,
							iconStyle: i
						})), n().createElement(Ln, {
							...this.props,
							onKeyClick: this.handleKeySelect
						}), n().createElement("span", z(r, "brace"), e === "array" ? "[" : "{")));
					}
					isCircularReference(e) {
						return this.listOfAncestors.indexOf(e.value) > -1 || e.value === this.props.src;
					}
					render() {
						let { depth: e, src: t, namespace: r, name: i, type: a, parent_type: o, theme: s, jsvRoot: c, iconStyle: l, showComma: u, isLast: d, ...f } = this.props, { object_type: p, expanded: m } = this.state, h = {};
						return c || o === "array_group" ? o === "array_group" && (h.borderLeft = 0, h.display = "inline") : h.paddingLeft = 5 * this.props.indentWidth, n().createElement("div", {
							className: "object-key-val",
							onMouseEnter: () => this.setState({
								...this.state,
								hovered: !0
							}),
							onMouseLeave: () => this.setState({
								...this.state,
								hovered: !1
							}),
							...z(s, c ? "jsv-root" : "objectKeyVal", h)
						}, this.getBraceStart(p, m), m ? this.getObjectContent(e, t, {
							theme: s,
							iconStyle: l,
							...f
						}) : this.getEllipsis(), n().createElement("span", { className: "brace-row" }, n().createElement("span", { style: {
							...z(s, "brace").style,
							paddingLeft: m ? "3px" : "0px"
						} }, p === "array" ? "]" : "}")), u && !d && !c && n().createElement("span", z(s, "comma"), ","), this.getObjectMetaData(t));
					}
					renderObjectContents = (e, t) => {
						let { depth: r, parent_type: i, index_offset: a, groupArraysAfterLength: o, namespace: s, showComma: c } = this.props, { object_type: l } = this.state, u = [], d, p = Object.keys(e || {});
						return this.props.sortKeys && l !== "array" && (p = p.sort()), p.forEach((m, h) => {
							d = new Vn(m, e[m], t.bigNumber);
							let g = h === p.length - 1;
							if (i === "array_group" && a && (d.name = parseInt(d.name, 10) + a), Object.prototype.hasOwnProperty.call(e, m) && d.type.toLowerCase() !== "window") {
								if (this.isCircularReference(d)) u.push(n().createElement(f, {
									key: d.name,
									depth: r + 1,
									name: d.name,
									src: d.value,
									namespace: s.concat(d.name),
									type: "array",
									parent_type: l,
									isLast: g,
									showComma: c,
									singleIndent: 5,
									indentWidth: this.props.indentWidth,
									...t
								}));
								else if (d.type === "object") u.push(n().createElement(Q, {
									key: d.name,
									depth: r + 1,
									name: d.name,
									src: d.value,
									namespace: s.concat(d.name),
									parent_type: l,
									isLast: g,
									showComma: c,
									listOfAncestors: this.listOfAncestors.concat([this.props.src]),
									...t
								}));
								else if (d.type === "array") {
									let e = Q;
									o && d.value.length > o && (e = Bn), u.push(n().createElement(e, {
										key: d.name,
										depth: r + 1,
										name: d.name,
										src: d.value,
										namespace: s.concat(d.name),
										type: "array",
										parent_type: l,
										isLast: g,
										showComma: c,
										listOfAncestors: this.listOfAncestors.concat([this.props.src]),
										...t
									}));
								} else u.push(n().createElement(Fn, {
									key: d.name + "_" + s,
									variable: d,
									singleIndent: 5,
									namespace: s,
									type: this.props.type,
									isLast: g,
									showComma: c,
									...t
								}));
							}
						}), u;
					};
				}
				class Vn {
					constructor(e, t, n) {
						this.name = e, this.value = t, this.type = u(t, n);
					}
				}
				l(Z);
				let Q = Z, Hn = class extends n().PureComponent {
					render = () => {
						let { props: e } = this, t = [e.name], r = Q;
						return typeof e.name == "object" && !Array.isArray(e.name) && (t = [e.name?.displayName || e.name?.name || e.name?.type?.name || "Anonymous"]), Array.isArray(e.src) && e.groupArraysAfterLength && e.src.length > e.groupArraysAfterLength && (r = Bn), n().createElement("div", { className: "pretty-json-container object-container" }, n().createElement("div", { className: "object-content" }, n().createElement(r, {
							namespace: t,
							depth: 0,
							jsvRoot: !0,
							...e
						})));
					};
				}, Un = class extends n().PureComponent {
					constructor(e) {
						super(e), this.state = { input: e.input ? e.input : "" };
					}
					render() {
						let { theme: e, rjvId: t, isValid: r } = this.props, { input: i } = this.state, a = r(i);
						return n().createElement("div", {
							className: "key-modal-request",
							...z(e, "key-modal-request"),
							onClick: this.handleCloseModal
						}, n().createElement("div", {
							...z(e, "key-modal"),
							onClick: (e) => {
								e.stopPropagation();
							}
						}, n().createElement("div", z(e, "key-modal-label"), "Key Name:"), n().createElement("div", { style: { position: "relative" } }, n().createElement("input", {
							...z(e, "key-modal-input"),
							className: "key-modal-input",
							ref: (e) => e && e.focus(),
							spellCheck: !1,
							value: i,
							placeholder: "...",
							onChange: (e) => {
								this.setState({ input: e.target.value });
							},
							onKeyPress: (e) => {
								a && e.key === "Enter" ? this.handleSubmit() : e.key === "Escape" && this.handleCloseModal();
							}
						}), a ? n().createElement(Mn, {
							...z(e, "key-modal-submit"),
							className: "key-modal-submit",
							onClick: this.handleSubmit
						}) : null), n().createElement("span", z(e, "key-modal-cancel"), n().createElement(An, {
							...z(e, "key-modal-cancel-icon"),
							className: "key-modal-cancel",
							onClick: () => {
								V.dispatch({
									rjvId: t,
									name: "RESET"
								});
							}
						}))));
					}
					handleCloseModal = () => {
						V.dispatch({
							rjvId: this.props.rjvId,
							name: "RESET"
						});
					};
					handleSubmit = () => {
						this.props.submit(this.state.input);
					};
				}, Wn = class extends n().PureComponent {
					render() {
						let { active: e, theme: t, rjvId: r } = this.props;
						return e ? n().createElement(Un, {
							rjvId: r,
							theme: t,
							isValid: this.isValid,
							submit: this.submit
						}) : null;
					}
					isValid = (e) => {
						let { rjvId: t } = this.props, n = W.get(t, "action", "new-key-request");
						return e !== "" && Object.keys(n.existing_value).indexOf(e) === -1;
					};
					submit = (e) => {
						let { rjvId: t } = this.props, n = W.get(t, "action", "new-key-request");
						n.new_value = { ...n.existing_value }, n.new_value[e] = this.props.defaultValue, V.dispatch({
							name: "VARIABLE_ADDED",
							rjvId: t,
							data: n
						});
					};
				}, Gn = class extends n().PureComponent {
					render() {
						let { message: e, active: t, theme: r, rjvId: i } = this.props;
						return t ? n().createElement("div", {
							className: "validation-failure",
							...z(r, "validation-failure"),
							onClick: () => {
								V.dispatch({
									rjvId: i,
									name: "RESET"
								});
							}
						}, n().createElement("span", z(r, "validation-failure-label"), e), n().createElement(An, z(r, "validation-failure-clear"))) : null;
					}
				};
				class $ extends n().PureComponent {
					constructor(e) {
						super(e), this.state = {
							addKeyRequest: !1,
							editKeyRequest: !1,
							validationFailure: !1,
							src: $.defaultProps.src,
							name: $.defaultProps.name,
							theme: $.defaultProps.theme,
							validationMessage: $.defaultProps.validationMessage,
							prevSrc: $.defaultProps.src,
							prevName: $.defaultProps.name,
							prevTheme: $.defaultProps.theme
						};
					}
					rjvId = Date.now().toString() + Math.random().toString(36).slice(2);
					static defaultProps = {
						src: {},
						name: "root",
						theme: "rjv-default",
						collapsed: !1,
						collapseStringsAfterLength: !1,
						shouldCollapse: !1,
						sortKeys: !1,
						quotesOnKeys: !0,
						groupArraysAfterLength: 100,
						indentWidth: 4,
						enableClipboard: !0,
						escapeStrings: !0,
						displayObjectSize: !0,
						displayDataTypes: !0,
						onEdit: !1,
						onDelete: !1,
						onAdd: !1,
						onSelect: !1,
						iconStyle: "triangle",
						style: {},
						validationMessage: "Validation Error",
						defaultValue: null,
						displayArrayKey: !0,
						selectOnFocus: !1,
						keyModifier: (e) => e.metaKey || e.ctrlKey,
						bigNumber: null,
						showComma: !0
					};
					static getDerivedStateFromProps(e, t) {
						if (e.src !== t.prevSrc || e.name !== t.prevName || e.theme !== t.prevTheme) {
							let t = {
								src: e.src,
								name: e.name,
								theme: e.theme,
								validationMessage: e.validationMessage,
								prevSrc: e.src,
								prevName: e.name,
								prevTheme: e.theme
							};
							return $.validateState(t);
						}
						return null;
					}
					componentDidMount() {
						W.set(this.rjvId, "global", "src", this.state.src);
						let e = this.getListeners();
						for (let t in e) W.on(t + "-" + this.rjvId, e[t]);
						this.setState({
							addKeyRequest: !1,
							editKeyRequest: !1
						});
					}
					componentDidUpdate(e, t) {
						t.addKeyRequest !== !1 && this.setState({ addKeyRequest: !1 }), t.editKeyRequest !== !1 && this.setState({ editKeyRequest: !1 }), e.src !== this.state.src && W.set(this.rjvId, "global", "src", this.state.src);
					}
					componentWillUnmount() {
						let e = this.getListeners();
						for (let t in e) W.removeListener(t + "-" + this.rjvId, e[t]);
					}
					getListeners = () => ({
						reset: this.resetState,
						"variable-update": this.updateSrc,
						"add-key-request": this.addKeyRequest
					});
					static validateState = (e) => {
						let t = {};
						return u(e.theme) !== "object" || function(e) {
							let t = [
								"base00",
								"base01",
								"base02",
								"base03",
								"base04",
								"base05",
								"base06",
								"base07",
								"base08",
								"base09",
								"base0A",
								"base0B",
								"base0C",
								"base0D",
								"base0E",
								"base0F"
							];
							if (u(e) === "object") {
								for (let n = 0; n < t.length; n++) if (!(t[n] in e)) return !1;
								return !0;
							}
							return !1;
						}(e.theme) || (console.error("react-json-view error:", "theme prop must be a theme name or valid base-16 theme object.", "defaulting to \"rjv-default\" theme"), t.theme = "rjv-default"), u(e.src) !== "object" && u(e.src) !== "array" && (console.error("react-json-view error:", "src property must be a valid json object"), t.name = "ERROR", t.src = { message: "src property must be a valid json object" }), {
							...e,
							...t
						};
					};
					render() {
						let { validationFailure: e, validationMessage: t, addKeyRequest: r, theme: i, src: a, name: o } = this.state, { style: s, defaultValue: c } = this.props;
						return n().createElement("div", {
							className: "react-json-view",
							style: {
								...z(i, "app-container").style,
								...s
							}
						}, n().createElement(Gn, {
							message: t,
							active: e,
							theme: i,
							rjvId: this.rjvId
						}), n().createElement(Hn, {
							...this.props,
							src: a,
							name: o,
							theme: i,
							type: u(a),
							rjvId: this.rjvId
						}), n().createElement(Wn, {
							active: r,
							theme: i,
							rjvId: this.rjvId,
							defaultValue: c
						}));
					}
					updateSrc = () => {
						let { name: e, namespace: t, new_value: n, existing_value: r, updated_src: i, type: a } = W.get(this.rjvId, "action", "variable-update"), { onEdit: o, onDelete: s, onAdd: c } = this.props, { src: l } = this.state, u, d = {
							existing_src: l,
							new_value: n,
							updated_src: i,
							name: e,
							namespace: t,
							existing_value: r
						};
						switch (a) {
							case "variable-added":
								u = c(d);
								break;
							case "variable-edited":
								u = o(d);
								break;
							case "variable-removed": u = s(d);
						}
						u === !1 ? this.setState({ validationFailure: !0 }) : (W.set(this.rjvId, "global", "src", i), this.setState({ src: i }));
					};
					addKeyRequest = () => {
						this.setState({ addKeyRequest: !0 });
					};
					resetState = () => {
						this.setState({
							validationFailure: !1,
							addKeyRequest: !1
						});
					};
				}
				l($);
				let Kn = $;
			})(), a;
		})());
	}(o)), o.exports;
}
var u = l(), d = /* @__PURE__ */ e(u), f = d.default || d, p = i(/* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
	__proto__: null,
	default: f
}, Symbol.toStringTag, { value: "Module" })));
//#endregion
export { p as t };

//# sourceMappingURL=reactJsonViewCompat-PzF5iqZ4-oi2jTtgM.js.map