//#region ../react/build/record.esm-DOwSVePN.js
function e(e, t, n, r) {
	return new (n ||= Promise)(function(t, i) {
		function a(e) {
			try {
				s(r.next(e));
			} catch (e) {
				i(e);
			}
		}
		function o(e) {
			try {
				s(r.throw(e));
			} catch (e) {
				i(e);
			}
		}
		function s(e) {
			var r;
			e.done ? t(e.value) : (r = e.value, r instanceof n ? r : new n(function(e) {
				e(r);
			})).then(a, o);
		}
		s((r = r.apply(e, [])).next());
	});
}
var t = class {
	constructor() {
		this.listeners = {};
	}
	on(e, t, n) {
		if (this.listeners[e] || (this.listeners[e] = /* @__PURE__ */ new Set()), n?.once) {
			let n = (...r) => {
				this.un(e, n), t(...r);
			};
			return this.listeners[e].add(n), () => this.un(e, n);
		}
		return this.listeners[e].add(t), () => this.un(e, t);
	}
	un(e, t) {
		var n;
		(n = this.listeners[e]) == null || n.delete(t);
	}
	once(e, t) {
		return this.on(e, t, { once: !0 });
	}
	unAll() {
		this.listeners = {};
	}
	emit(e, ...t) {
		this.listeners[e] && this.listeners[e].forEach((e) => e(...t));
	}
}, n = class e {
	constructor() {
		this.disposers = [], this.children = /* @__PURE__ */ new Set(), this.parent = null, this._disposed = !1, this.abortController = null;
	}
	get disposed() {
		return this._disposed;
	}
	add(e) {
		return this._disposed ? (this.safeRun(e), () => {}) : (this.disposers.push(e), () => {
			let t = this.disposers.indexOf(e);
			t !== -1 && (this.disposers.splice(t, 1), this.safeRun(e));
		});
	}
	child() {
		let t = new e();
		return this._disposed ? (t.dispose(), t) : (t.parent = this, this.children.add(t), t);
	}
	listen(e, t, n, r) {
		return e.addEventListener(t, n, r), this.add(() => e.removeEventListener(t, n, r));
	}
	timeout(e, t) {
		let n = setTimeout(() => {
			r(), e();
		}, t), r = this.add(() => clearTimeout(n));
		return r;
	}
	interval(e, t) {
		let n = setInterval(e, t);
		return this.add(() => clearInterval(n));
	}
	raf(e) {
		let t = requestAnimationFrame((t) => {
			n(), e(t);
		}), n = this.add(() => cancelAnimationFrame(t));
		return n;
	}
	observeResize(e, t) {
		e.observe(t), this.add(() => e.unobserve(t));
	}
	createResizeObserver(e, t) {
		let n = new ResizeObserver(t);
		return n.observe(e), this.add(() => n.disconnect()), n;
	}
	abortSignal() {
		return this.abortController || (this.abortController = new AbortController(), this._disposed && this.abortController.abort()), this.abortController.signal;
	}
	dispose() {
		var e;
		if (this._disposed) return;
		this._disposed = !0, this.parent &&= (this.parent.children.delete(this), null);
		for (let e of [...this.children]) e.dispose();
		this.children.clear();
		let t = this.disposers;
		this.disposers = [];
		for (let e = t.length - 1; e >= 0; e--) this.safeRun(t[e]);
		(e = this.abortController) == null || e.abort();
	}
	safeRun(e) {
		try {
			e();
		} catch (e) {
			console.error("Scope disposer error:", e);
		}
	}
}, r = class extends t {
	get destroyed() {
		return this.isDestroyed;
	}
	constructor(e) {
		super(), this.subscriptions = [], this.scope = new n(), this.isDestroyed = !1, this.options = e;
	}
	onInit() {}
	_init(e) {
		this.isDestroyed = !1, this.wavesurfer = e, this.onInit();
	}
	destroy() {
		this.isDestroyed || (this.isDestroyed = !0, this.emit("destroy"), this.subscriptions.forEach((e) => e()), this.subscriptions = [], this.unAll(), this.scope.dispose(), this.wavesurfer = void 0);
	}
}, i = class {
	constructor(e) {
		this.frameId = null, this.callback = null, this.isRunning = !1, e.add(() => this.stop());
	}
	get running() {
		return this.isRunning;
	}
	start(e) {
		if (this.callback = e, this.isRunning) return;
		this.isRunning = !0;
		let t = () => {
			var e;
			this.isRunning && (this.frameId = requestAnimationFrame(t), (e = this.callback) == null || e.call(this));
		};
		t();
	}
	stop() {
		this.isRunning = !1, this.frameId !== null && (cancelAnimationFrame(this.frameId), this.frameId = null);
	}
}, a = 100, o = [
	"audio/webm",
	"audio/wav",
	"audio/mpeg",
	"audio/mp4",
	"audio/mp3"
], s = class t extends r {
	constructor(e) {
		var t, n, r;
		super(Object.assign(Object.assign({}, e), {
			audioBitsPerSecond: e.audioBitsPerSecond ?? 128e3,
			scrollingWaveform: (t = e.scrollingWaveform) != null && t,
			scrollingWaveformWindow: e.scrollingWaveformWindow ?? 5,
			continuousWaveform: (n = e.continuousWaveform) != null && n,
			renderRecordedAudio: (r = e.renderRecordedAudio) == null || r,
			mediaRecorderTimeslice: e.mediaRecorderTimeslice ?? void 0
		})), this.stream = null, this.mediaRecorder = null, this.dataWindow = null, this.isWaveformPaused = !1, this.lastStartTime = 0, this.lastDuration = 0, this.duration = 0, this.micStream = null, this.unsubscribeTrackEnded = [], this.recordedBlobUrl = null, this.pendingFinalRecordEndListeners = null, this.handleTick = () => {
			let e = performance.now() - this.lastStartTime;
			this.duration = this.isPaused() ? this.duration : this.lastDuration + e, this.emit("record-progress", this.duration);
		}, this.frameScheduler = new i(this.scope);
	}
	onInit() {
		this.scope = new n(), this.frameScheduler = new i(this.scope);
	}
	static create(e) {
		return new t(e || {});
	}
	renderMicStream(e) {
		let t = new AudioContext(), n = t.createMediaStreamSource(e), r = t.createAnalyser();
		n.connect(r), (this.options.continuousWaveform || this.options.scrollingWaveform) && (r.fftSize = 32);
		let i = r.frequencyBinCount, o = new Float32Array(i), s = 0;
		this.wavesurfer && (this.originalOptions ??= Object.assign({}, this.wavesurfer.options), this.wavesurfer.options.interact = !1, this.options.scrollingWaveform && (this.wavesurfer.options.cursorWidth = 0, this.wavesurfer.options.normalize = !0, this.wavesurfer.options.maxPeak = 1));
		let c = this.scope.child();
		return c.add(() => {
			n?.disconnect(), t?.close();
		}), c.interval(() => {
			if (!this.isWaveformPaused) {
				if (r.getFloatTimeDomainData(o), this.options.scrollingWaveform) {
					let e = Math.floor((this.options.scrollingWaveformWindow || 0) * a), t = 0;
					for (let e = 0; e < i; e++) {
						let n = Math.abs(o[e]);
						n > t && (t = n);
					}
					this.dataWindow ||= new Float32Array(e);
					let n = new Float32Array(e);
					if (this.dataWindow && this.dataWindow.length > 0) {
						let t = e - 1, r = this.dataWindow.slice(-t);
						n.set(r, 0);
					}
					n[e - 1] = t, this.dataWindow = n;
				} else if (this.options.continuousWaveform) {
					if (!this.dataWindow) {
						let e = this.options.continuousWaveformDuration ? Math.round(this.options.continuousWaveformDuration * a) : (this.wavesurfer?.getWidth() ?? 0) * window.devicePixelRatio;
						this.dataWindow = new Float32Array(e);
					}
					let e = 0;
					for (let t = 0; t < i; t++) {
						let n = Math.abs(o[t]);
						n > e && (e = n);
					}
					if (s + 1 > this.dataWindow.length) {
						let e = new Float32Array(2 * this.dataWindow.length);
						e.set(this.dataWindow, 0), this.dataWindow = e;
					}
					this.dataWindow[s] = e, s++;
				} else this.dataWindow = o;
				if (this.wavesurfer) {
					let e = (this.dataWindow?.length ?? 0) / a;
					this.wavesurfer.load("", [this.dataWindow], this.options.scrollingWaveform ? this.options.scrollingWaveformWindow : e).then(() => {
						this.wavesurfer && this.options.continuousWaveform && (this.wavesurfer.setTime(this.getDuration() / 1e3), this.wavesurfer.options.minPxPerSec || this.wavesurfer.setOptions({ minPxPerSec: this.wavesurfer.getWidth() / this.wavesurfer.getDuration() }));
					}).catch((e) => {
						e instanceof DOMException && e.name === "AbortError" || console.error("Error rendering real-time recording data:", e);
					});
				}
			}
		}, 10), {
			onDestroy: () => c.dispose(),
			onEnd: () => {
				this.isWaveformPaused = !0, this.stopMic();
			}
		};
	}
	startMic(t) {
		return e(this, void 0, void 0, function* () {
			this.micStream && this.stopMic();
			let e = this.scope, n;
			try {
				n = yield navigator.mediaDevices.getUserMedia({ audio: t == null || t });
			} catch (e) {
				throw Error("Error accessing the microphone: " + e.message);
			}
			if (this.destroyed || e.disposed) throw n.getTracks().forEach((e) => e.stop()), /* @__PURE__ */ Error("The plugin was destroyed while requesting the microphone");
			let r = this.renderMicStream(n);
			return this.micStream = r, this.unsubscribeRecordEnd = this.once("record-end", r.onEnd), this.stream = n, this.unsubscribeTrackEnded = n.getTracks().map((e) => this.scope.listen(e, "ended", () => this.handleTrackEnded())), n;
		});
	}
	handleTrackEnded() {
		this.isActive() ? (this.emit("record-ended-externally"), this.stopRecording()) : this.stopMic();
	}
	stopMic() {
		var e, t;
		(e = this.micStream) == null || e.onDestroy(), (t = this.unsubscribeRecordEnd) == null || t.call(this), this.micStream = null, this.unsubscribeRecordEnd = void 0, this.unsubscribeTrackEnded.forEach((e) => e()), this.unsubscribeTrackEnded = [], this.applyOriginalOptionsIfNeeded(), this.stream && (this.stream.getTracks().forEach((e) => e.stop()), this.stream = null, this.mediaRecorder = null);
	}
	startRecording(t) {
		return e(this, void 0, void 0, function* () {
			let e = this.stream || (yield this.startMic(t));
			this.dataWindow = null;
			let n = this.mediaRecorder;
			n && n.state !== "inactive" && (n.ondataavailable = null, n.onpause = null, n.onstop = null, n.stop(), this.frameScheduler.stop());
			let r = new MediaRecorder(e, {
				mimeType: this.options.mimeType || o.find((e) => MediaRecorder.isTypeSupported(e)),
				audioBitsPerSecond: this.options.audioBitsPerSecond
			});
			this.mediaRecorder = r;
			let i = this.scope, a = [];
			r.ondataavailable = (e) => {
				e.data.size > 0 && a.push(e.data), this.emit("record-data-available", e.data);
			};
			let s = (e) => {
				var t;
				let n = new Blob(a, { type: r.mimeType }), o = this.scope !== i;
				if (o || this.emit(e, n), e === "record-end" && this.pendingFinalRecordEndListeners) {
					let e = this.pendingFinalRecordEndListeners;
					this.pendingFinalRecordEndListeners = null, (this.destroyed || o) && e.forEach((e) => {
						try {
							e(n);
						} catch (e) {
							console.error("Error in record-end listener during destroy teardown:", e);
						}
					});
				}
				!this.options.renderRecordedAudio || this.destroyed || o || (this.applyOriginalOptionsIfNeeded(), this.recordedBlobUrl && URL.revokeObjectURL(this.recordedBlobUrl), this.recordedBlobUrl = URL.createObjectURL(n), (t = this.wavesurfer) == null || t.load(this.recordedBlobUrl));
			};
			r.onpause = () => s("record-pause"), r.onstop = () => s("record-end"), r.start(this.options.mediaRecorderTimeslice), this.lastStartTime = performance.now(), this.lastDuration = 0, this.duration = 0, this.isWaveformPaused = !1, this.frameScheduler.start(this.handleTick), this.emit("record-start");
		});
	}
	getDuration() {
		return this.duration;
	}
	isRecording() {
		return this.mediaRecorder?.state === "recording";
	}
	isPaused() {
		return this.mediaRecorder?.state === "paused";
	}
	isActive() {
		return !!this.mediaRecorder && this.mediaRecorder.state !== "inactive";
	}
	stopRecording() {
		var e;
		this.isActive() && ((e = this.mediaRecorder) == null || e.stop(), this.frameScheduler.stop());
	}
	pauseRecording() {
		var e, t;
		this.isRecording() && (this.isWaveformPaused = !0, (e = this.mediaRecorder) == null || e.requestData(), (t = this.mediaRecorder) == null || t.pause(), this.frameScheduler.stop(), this.lastDuration = this.duration);
	}
	resumeRecording() {
		var e;
		this.isPaused() && (this.isWaveformPaused = !1, (e = this.mediaRecorder) == null || e.resume(), this.lastStartTime = performance.now(), this.frameScheduler.start(this.handleTick), this.emit("record-resume"));
	}
	static getAvailableAudioDevices() {
		return e(this, void 0, void 0, function* () {
			return navigator.mediaDevices.enumerateDevices().then((e) => e.filter((e) => e.kind === "audioinput"));
		});
	}
	destroy() {
		if (this.applyOriginalOptionsIfNeeded(), this.mediaRecorder && (this.mediaRecorder.state === "recording" || this.mediaRecorder.state === "paused")) {
			let e = this.listeners?.["record-end"];
			this.pendingFinalRecordEndListeners = e ? new Set(e) : null;
		}
		this.stopRecording(), this.stopMic(), this.frameScheduler.stop(), this.recordedBlobUrl &&= (URL.revokeObjectURL(this.recordedBlobUrl), null), super.destroy();
	}
	applyOriginalOptionsIfNeeded() {
		this.wavesurfer && this.originalOptions && (this.wavesurfer.setOptions(this.originalOptions), delete this.originalOptions);
	}
};
//#endregion
export { s as default };

//# sourceMappingURL=record.esm-DOwSVePN-68cwvovj.js.map