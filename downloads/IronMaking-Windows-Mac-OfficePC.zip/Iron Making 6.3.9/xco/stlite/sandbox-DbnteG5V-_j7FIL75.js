import { e } from "./es6-BxevHr5y-Dmh0kddl.js";
//#region ../react/build/sandbox-DbnteG5V.js
var { DISALLOWED: t } = e, n = class {
	constructor(e, t) {
		this.writer = e, this.fileEntry = t;
	}
	async write(e) {
		if (typeof e == "object") {
			if (e.type === "write") {
				if (Number.isInteger(e.position) && e.position >= 0 && (this.writer.seek(e.position), this.writer.position !== e.position && (await new Promise((t, n) => {
					this.writer.onwriteend = t, this.writer.onerror = n, this.writer.truncate(e.position);
				}), this.writer.seek(e.position))), !("data" in e)) throw new DOMException("Failed to execute 'write' on 'UnderlyingSinkBase': Invalid params passed. write requires a data argument", "SyntaxError");
				e = e.data;
			} else if (e.type === "seek") {
				if (Number.isInteger(e.position) && e.position >= 0) {
					if (this.writer.seek(e.position), this.writer.position !== e.position) throw new DOMException("seeking position failed", "InvalidStateError");
					return;
				}
				throw new DOMException("Failed to execute 'write' on 'UnderlyingSinkBase': Invalid params passed. seek requires a position argument", "SyntaxError");
			} else if (e.type === "truncate") return new Promise((t) => {
				if (Number.isInteger(e.size) && e.size >= 0) this.writer.onwriteend = (e) => t(), this.writer.truncate(e.size);
				else throw new DOMException("Failed to execute 'write' on 'UnderlyingSinkBase': Invalid params passed. truncate requires a size argument", "SyntaxError");
			});
		}
		await new Promise((t, n) => {
			this.writer.onwriteend = t, this.writer.onerror = n, this.writer.write(new Blob([e]));
		});
	}
	close() {
		return new Promise(this.fileEntry.file.bind(this.fileEntry));
	}
}, r = class {
	constructor(e, t = !0) {
		this.file = e, this.kind = "file", this.writable = t, this.readable = !0;
	}
	get name() {
		return this.file.name;
	}
	isSameEntry(e) {
		return this.file.toURL() === e.file.toURL();
	}
	getFile() {
		return new Promise(this.file.file.bind(this.file));
	}
	createWritable(e) {
		if (!this.writable) throw new DOMException(...t);
		return new Promise((t, r) => this.file.createWriter((r) => {
			e.keepExistingData === !1 ? (r.onwriteend = (e) => t(new n(r, this.file)), r.truncate(0)) : t(new n(r, this.file));
		}, r));
	}
}, i = class e {
	constructor(e, t = !0) {
		this.dir = e, this.writable = t, this.readable = !0, this.kind = "directory", this.name = e.name;
	}
	isSameEntry(e) {
		return this.dir.fullPath === e.dir.fullPath;
	}
	async *entries() {
		let t = this.dir.createReader(), n = await new Promise(t.readEntries.bind(t));
		for (let t of n) yield [t.name, t.isFile ? new r(t, this.writable) : new e(t, this.writable)];
	}
	getDirectoryHandle(t, n) {
		return new Promise((r, i) => {
			this.dir.getDirectory(t, n, (t) => {
				r(new e(t));
			}, i);
		});
	}
	getFileHandle(e, t) {
		return new Promise((n, i) => this.dir.getFile(e, t, (e) => n(new r(e)), i));
	}
	async removeEntry(t, n) {
		let r = await this.getDirectoryHandle(t, { create: !1 }).catch((e) => e.name === "TypeMismatchError" ? this.getFileHandle(t, { create: !1 }) : e);
		if (r instanceof Error) throw r;
		return new Promise((t, i) => {
			r instanceof e ? n.recursive ? r.dir.removeRecursively(() => t(), i) : r.dir.remove(() => t(), i) : r.file && r.file.remove(() => t(), i);
		});
	}
}, a = (e = {}) => new Promise((t, n) => window.webkitRequestFileSystem(e._persistent, 0, (e) => t(new i(e.root)), n));
//#endregion
export { r as FileHandle, i as FolderHandle, a as default };

//# sourceMappingURL=sandbox-DbnteG5V-_j7FIL75.js.map