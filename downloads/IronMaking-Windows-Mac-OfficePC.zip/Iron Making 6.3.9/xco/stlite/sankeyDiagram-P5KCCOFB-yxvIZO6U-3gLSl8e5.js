import { n as e } from "./ordinal-DkyryJlW-DURmPlUH.js";
import { t } from "./colors-BD7LS4qt-BehGd4Ls.js";
import { c as n } from "./transform-B2AI7qp--hg0kwf7R.js";
import { N as r, Q as i, a6 as a, ai as o, aj as s, am as c, an as l, bB as u, bF as d, by as f, bz as p, c as m } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
//#region ../react/build/sankeyDiagram-P5KCCOFB-yxvIZO6U.js
var h = t("4e79a7f28e2ce1575976b7b259a14fedc949af7aa1ff9da79c755fbab0ab");
function g(e, t) {
	let n;
	if (t === void 0) for (let t of e) t != null && (n < t || n === void 0 && t >= t) && (n = t);
	else {
		let r = -1;
		for (let i of e) (i = t(i, ++r, e)) != null && (n < i || n === void 0 && i >= i) && (n = i);
	}
	return n;
}
function _(e, t) {
	let n;
	if (t === void 0) for (let t of e) t != null && (n > t || n === void 0 && t >= t) && (n = t);
	else {
		let r = -1;
		for (let i of e) (i = t(i, ++r, e)) != null && (n > i || n === void 0 && i >= i) && (n = i);
	}
	return n;
}
function v(e, t) {
	let n = 0;
	if (t === void 0) for (let t of e) (t = +t) && (n += t);
	else {
		let r = -1;
		for (let i of e) (i = +t(i, ++r, e)) && (n += i);
	}
	return n;
}
function y(e) {
	return e.target.depth;
}
function b(e) {
	return e.depth;
}
function x(e, t) {
	return t - 1 - e.height;
}
function S(e, t) {
	return e.sourceLinks.length ? e.depth : t - 1;
}
function C(e) {
	return e.targetLinks.length ? e.depth : e.sourceLinks.length ? _(e.sourceLinks, y) - 1 : 0;
}
function w(e) {
	return function() {
		return e;
	};
}
function T(e, t) {
	return D(e.source, t.source) || e.index - t.index;
}
function E(e, t) {
	return D(e.target, t.target) || e.index - t.index;
}
function D(e, t) {
	return e.y0 - t.y0;
}
function O(e) {
	return e.value;
}
function k(e) {
	return e.index;
}
function A(e) {
	return e.nodes;
}
function j(e) {
	return e.links;
}
function M(e, t) {
	let n = e.get(t);
	if (!n) throw Error("missing: " + t);
	return n;
}
function N({ nodes: e }) {
	for (let t of e) {
		let e = t.y0, n = e;
		for (let n of t.sourceLinks) n.y0 = e + n.width / 2, e += n.width;
		for (let e of t.targetLinks) e.y1 = n + e.width / 2, n += e.width;
	}
}
function P() {
	let e = 0, t = 0, n = 1, r = 1, i = 24, a = 8, o, s = k, c = S, l, u, d = A, f = j, p = 6;
	function m() {
		let e = {
			nodes: d.apply(null, arguments),
			links: f.apply(null, arguments)
		};
		return h(e), y(e), b(e), x(e), F(e), N(e), e;
	}
	m.update = function(e) {
		return N(e), e;
	}, m.nodeId = function(e) {
		return arguments.length ? (s = typeof e == "function" ? e : w(e), m) : s;
	}, m.nodeAlign = function(e) {
		return arguments.length ? (c = typeof e == "function" ? e : w(e), m) : c;
	}, m.nodeSort = function(e) {
		return arguments.length ? (l = e, m) : l;
	}, m.nodeWidth = function(e) {
		return arguments.length ? (i = +e, m) : i;
	}, m.nodePadding = function(e) {
		return arguments.length ? (a = o = +e, m) : a;
	}, m.nodes = function(e) {
		return arguments.length ? (d = typeof e == "function" ? e : w(e), m) : d;
	}, m.links = function(e) {
		return arguments.length ? (f = typeof e == "function" ? e : w(e), m) : f;
	}, m.linkSort = function(e) {
		return arguments.length ? (u = e, m) : u;
	}, m.size = function(i) {
		return arguments.length ? (e = t = 0, n = +i[0], r = +i[1], m) : [n - e, r - t];
	}, m.extent = function(i) {
		return arguments.length ? (e = +i[0][0], n = +i[1][0], t = +i[0][1], r = +i[1][1], m) : [[e, t], [n, r]];
	}, m.iterations = function(e) {
		return arguments.length ? (p = +e, m) : p;
	};
	function h({ nodes: e, links: t }) {
		for (let [t, n] of e.entries()) n.index = t, n.sourceLinks = [], n.targetLinks = [];
		let n = new Map(e.map((t, n) => [s(t, n, e), t]));
		for (let [e, r] of t.entries()) {
			r.index = e;
			let { source: t, target: i } = r;
			typeof t != "object" && (t = r.source = M(n, t)), typeof i != "object" && (i = r.target = M(n, i)), t.sourceLinks.push(r), i.targetLinks.push(r);
		}
		if (u != null) for (let { sourceLinks: t, targetLinks: n } of e) t.sort(u), n.sort(u);
	}
	function y({ nodes: e }) {
		for (let t of e) t.value = t.fixedValue === void 0 ? Math.max(v(t.sourceLinks, O), v(t.targetLinks, O)) : t.fixedValue;
	}
	function b({ nodes: e }) {
		let t = e.length, n = new Set(e), r = /* @__PURE__ */ new Set(), i = 0;
		for (; n.size;) {
			for (let e of n) {
				e.depth = i;
				for (let { target: t } of e.sourceLinks) r.add(t);
			}
			if (++i > t) throw Error("circular link");
			n = r, r = /* @__PURE__ */ new Set();
		}
	}
	function x({ nodes: e }) {
		let t = e.length, n = new Set(e), r = /* @__PURE__ */ new Set(), i = 0;
		for (; n.size;) {
			for (let e of n) {
				e.height = i;
				for (let { source: t } of e.targetLinks) r.add(t);
			}
			if (++i > t) throw Error("circular link");
			n = r, r = /* @__PURE__ */ new Set();
		}
	}
	function C({ nodes: t }) {
		let r = g(t, (e) => e.depth) + 1, a = (n - e - i) / (r - 1), o = Array(r);
		for (let n of t) {
			let t = Math.max(0, Math.min(r - 1, Math.floor(c.call(null, n, r))));
			n.layer = t, n.x0 = e + t * a, n.x1 = n.x0 + i, o[t] ? o[t].push(n) : o[t] = [n];
		}
		if (l) for (let e of o) e.sort(l);
		return o;
	}
	function P(e) {
		let n = _(e, (e) => (r - t - (e.length - 1) * o) / v(e, O));
		for (let i of e) {
			let e = t;
			for (let t of i) {
				t.y0 = e, t.y1 = e + t.value * n, e = t.y1 + o;
				for (let e of t.sourceLinks) e.width = e.value * n;
			}
			e = (r - e + o) / (i.length + 1);
			for (let t = 0; t < i.length; ++t) {
				let n = i[t];
				n.y0 += e * (t + 1), n.y1 += e * (t + 1);
			}
			H(i);
		}
	}
	function F(e) {
		let n = C(e);
		o = Math.min(a, (r - t) / (g(n, (e) => e.length) - 1)), P(n);
		for (let e = 0; e < p; ++e) {
			let t = .99 ** e, r = Math.max(1 - t, (e + 1) / p);
			L(n, t, r), I(n, t, r);
		}
	}
	function I(e, t, n) {
		for (let r = 1, i = e.length; r < i; ++r) {
			let i = e[r];
			for (let e of i) {
				let n = 0, r = 0;
				for (let { source: t, value: i } of e.targetLinks) {
					let a = i * (e.layer - t.layer);
					n += U(t, e) * a, r += a;
				}
				if (!(r > 0)) continue;
				let i = (n / r - e.y0) * t;
				e.y0 += i, e.y1 += i, V(e);
			}
			l === void 0 && i.sort(D), R(i, n);
		}
	}
	function L(e, t, n) {
		for (let r = e.length - 2; r >= 0; --r) {
			let i = e[r];
			for (let e of i) {
				let n = 0, r = 0;
				for (let { target: t, value: i } of e.sourceLinks) {
					let a = i * (t.layer - e.layer);
					n += W(e, t) * a, r += a;
				}
				if (!(r > 0)) continue;
				let i = (n / r - e.y0) * t;
				e.y0 += i, e.y1 += i, V(e);
			}
			l === void 0 && i.sort(D), R(i, n);
		}
	}
	function R(e, n) {
		let i = e.length >> 1, a = e[i];
		B(e, a.y0 - o, i - 1, n), z(e, a.y1 + o, i + 1, n), B(e, r, e.length - 1, n), z(e, t, 0, n);
	}
	function z(e, t, n, r) {
		for (; n < e.length; ++n) {
			let i = e[n], a = (t - i.y0) * r;
			a > 1e-6 && (i.y0 += a, i.y1 += a), t = i.y1 + o;
		}
	}
	function B(e, t, n, r) {
		for (; n >= 0; --n) {
			let i = e[n], a = (i.y1 - t) * r;
			a > 1e-6 && (i.y0 -= a, i.y1 -= a), t = i.y0 - o;
		}
	}
	function V({ sourceLinks: e, targetLinks: t }) {
		if (u === void 0) {
			for (let { source: { sourceLinks: e } } of t) e.sort(E);
			for (let { target: { targetLinks: t } } of e) t.sort(T);
		}
	}
	function H(e) {
		if (u === void 0) for (let { sourceLinks: t, targetLinks: n } of e) t.sort(E), n.sort(T);
	}
	function U(e, t) {
		let n = e.y0 - (e.sourceLinks.length - 1) * o / 2;
		for (let { target: r, width: i } of e.sourceLinks) {
			if (r === t) break;
			n += i + o;
		}
		for (let { source: r, width: i } of t.targetLinks) {
			if (r === e) break;
			n -= i;
		}
		return n;
	}
	function W(e, t) {
		let n = t.y0 - (t.targetLinks.length - 1) * o / 2;
		for (let { source: r, width: i } of t.targetLinks) {
			if (r === e) break;
			n += i + o;
		}
		for (let { target: r, width: i } of e.sourceLinks) {
			if (r === t) break;
			n -= i;
		}
		return n;
	}
	return m;
}
var F = Math.PI, I = 2 * F, L = 1e-6, R = I - L;
function z() {
	this._x0 = this._y0 = this._x1 = this._y1 = null, this._ = "";
}
function B() {
	return new z();
}
z.prototype = B.prototype = {
	constructor: z,
	moveTo: function(e, t) {
		this._ += "M" + (this._x0 = this._x1 = +e) + "," + (this._y0 = this._y1 = +t);
	},
	closePath: function() {
		this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._ += "Z");
	},
	lineTo: function(e, t) {
		this._ += "L" + (this._x1 = +e) + "," + (this._y1 = +t);
	},
	quadraticCurveTo: function(e, t, n, r) {
		this._ += "Q" + +e + "," + +t + "," + (this._x1 = +n) + "," + (this._y1 = +r);
	},
	bezierCurveTo: function(e, t, n, r, i, a) {
		this._ += "C" + +e + "," + +t + "," + +n + "," + +r + "," + (this._x1 = +i) + "," + (this._y1 = +a);
	},
	arcTo: function(e, t, n, r, i) {
		e = +e, t = +t, n = +n, r = +r, i = +i;
		var a = this._x1, o = this._y1, s = n - e, c = r - t, l = a - e, u = o - t, d = l * l + u * u;
		if (i < 0) throw Error("negative radius: " + i);
		if (this._x1 === null) this._ += "M" + (this._x1 = e) + "," + (this._y1 = t);
		else if (d > L) {
			if (!(Math.abs(u * s - c * l) > L) || !i) this._ += "L" + (this._x1 = e) + "," + (this._y1 = t);
			else {
				var f = n - a, p = r - o, m = s * s + c * c, h = f * f + p * p, g = Math.sqrt(m), _ = Math.sqrt(d), v = i * Math.tan((F - Math.acos((m + d - h) / (2 * g * _))) / 2), y = v / _, b = v / g;
				Math.abs(y - 1) > L && (this._ += "L" + (e + y * l) + "," + (t + y * u)), this._ += "A" + i + "," + i + ",0,0," + +(u * f > l * p) + "," + (this._x1 = e + b * s) + "," + (this._y1 = t + b * c);
			}
		}
	},
	arc: function(e, t, n, r, i, a) {
		e = +e, t = +t, n = +n, a = !!a;
		var o = n * Math.cos(r), s = n * Math.sin(r), c = e + o, l = t + s, u = 1 ^ a, d = a ? r - i : i - r;
		if (n < 0) throw Error("negative radius: " + n);
		this._x1 === null ? this._ += "M" + c + "," + l : (Math.abs(this._x1 - c) > L || Math.abs(this._y1 - l) > L) && (this._ += "L" + c + "," + l), n && (d < 0 && (d = d % I + I), d > R ? this._ += "A" + n + "," + n + ",0,1," + u + "," + (e - o) + "," + (t - s) + "A" + n + "," + n + ",0,1," + u + "," + (this._x1 = c) + "," + (this._y1 = l) : d > L && (this._ += "A" + n + "," + n + ",0," + +(d >= F) + "," + u + "," + (this._x1 = e + n * Math.cos(i)) + "," + (this._y1 = t + n * Math.sin(i))));
	},
	rect: function(e, t, n, r) {
		this._ += "M" + (this._x0 = this._x1 = +e) + "," + (this._y0 = this._y1 = +t) + "h" + +n + "v" + +r + "h" + -n + "Z";
	},
	toString: function() {
		return this._;
	}
};
function V(e) {
	return function() {
		return e;
	};
}
function H(e) {
	return e[0];
}
function U(e) {
	return e[1];
}
var W = Array.prototype.slice;
function ee(e) {
	return e.source;
}
function te(e) {
	return e.target;
}
function ne(e) {
	var t = ee, n = te, r = H, i = U, a = null;
	function o() {
		var o, s = W.call(arguments), c = t.apply(this, s), l = n.apply(this, s);
		if (a ||= o = B(), e(a, +r.apply(this, (s[0] = c, s)), +i.apply(this, s), +r.apply(this, (s[0] = l, s)), +i.apply(this, s)), o) return a = null, o + "" || null;
	}
	return o.source = function(e) {
		return arguments.length ? (t = e, o) : t;
	}, o.target = function(e) {
		return arguments.length ? (n = e, o) : n;
	}, o.x = function(e) {
		return arguments.length ? (r = typeof e == "function" ? e : V(+e), o) : r;
	}, o.y = function(e) {
		return arguments.length ? (i = typeof e == "function" ? e : V(+e), o) : i;
	}, o.context = function(e) {
		return arguments.length ? (a = e ?? null, o) : a;
	}, o;
}
function re(e, t, n, r, i) {
	e.moveTo(t, n), e.bezierCurveTo(t = (t + r) / 2, n, t, i, r, i);
}
function ie() {
	return ne(re);
}
function ae(e) {
	return [e.source.x1, e.y0];
}
function oe(e) {
	return [e.target.x0, e.y1];
}
function se() {
	return ie().source(ae).target(oe);
}
var G = function() {
	var e = /* @__PURE__ */ m(function(e, t, n, r) {
		for (n ||= {}, r = e.length; r--; n[e[r]] = t);
		return n;
	}, "o"), t = [1, 9], n = [1, 10], r = [
		1,
		5,
		10,
		12
	], i = {
		trace: /* @__PURE__ */ m(function() {}, "trace"),
		yy: {},
		symbols_: {
			error: 2,
			start: 3,
			SANKEY: 4,
			NEWLINE: 5,
			csv: 6,
			opt_eof: 7,
			record: 8,
			csv_tail: 9,
			EOF: 10,
			"field[source]": 11,
			COMMA: 12,
			"field[target]": 13,
			"field[value]": 14,
			field: 15,
			escaped: 16,
			non_escaped: 17,
			DQUOTE: 18,
			ESCAPED_TEXT: 19,
			NON_ESCAPED_TEXT: 20,
			$accept: 0,
			$end: 1
		},
		terminals_: {
			2: "error",
			4: "SANKEY",
			5: "NEWLINE",
			10: "EOF",
			11: "field[source]",
			12: "COMMA",
			13: "field[target]",
			14: "field[value]",
			18: "DQUOTE",
			19: "ESCAPED_TEXT",
			20: "NON_ESCAPED_TEXT"
		},
		productions_: [
			0,
			[3, 4],
			[6, 2],
			[9, 2],
			[9, 0],
			[7, 1],
			[7, 0],
			[8, 5],
			[15, 1],
			[15, 1],
			[16, 3],
			[17, 1]
		],
		performAction: /* @__PURE__ */ m(function(e, t, n, r, i, a, o) {
			var s = a.length - 1;
			switch (i) {
				case 7:
					let e = r.findOrCreateNode(a[s - 4].trim().replaceAll("\"\"", "\"")), t = r.findOrCreateNode(a[s - 2].trim().replaceAll("\"\"", "\"")), n = parseFloat(a[s].trim());
					r.addLink(e, t, n);
					break;
				case 8:
				case 9:
				case 11:
					this.$ = a[s];
					break;
				case 10: this.$ = a[s - 1];
			}
		}, "anonymous"),
		table: [
			{
				3: 1,
				4: [1, 2]
			},
			{ 1: [3] },
			{ 5: [1, 3] },
			{
				6: 4,
				8: 5,
				15: 6,
				16: 7,
				17: 8,
				18: t,
				20: n
			},
			{
				1: [2, 6],
				7: 11,
				10: [1, 12]
			},
			e(n, [2, 4], {
				9: 13,
				5: [1, 14]
			}),
			{ 12: [1, 15] },
			e(r, [2, 8]),
			e(r, [2, 9]),
			{ 19: [1, 16] },
			e(r, [2, 11]),
			{ 1: [2, 1] },
			{ 1: [2, 5] },
			e(n, [2, 2]),
			{
				6: 17,
				8: 5,
				15: 6,
				16: 7,
				17: 8,
				18: t,
				20: n
			},
			{
				15: 18,
				16: 7,
				17: 8,
				18: t,
				20: n
			},
			{ 18: [1, 19] },
			e(n, [2, 3]),
			{ 12: [1, 20] },
			e(r, [2, 10]),
			{
				15: 21,
				16: 7,
				17: 8,
				18: t,
				20: n
			},
			e([
				1,
				5,
				10
			], [2, 7])
		],
		defaultActions: {
			11: [2, 1],
			12: [2, 5]
		},
		parseError: /* @__PURE__ */ m(function(e, t) {
			if (t.recoverable) this.trace(e);
			else {
				var n = Error(e);
				throw n.hash = t, n;
			}
		}, "parseError"),
		parse: /* @__PURE__ */ m(function(e) {
			var t = this, n = [0], r = [], i = [null], a = [], o = this.table, s = "", c = 0, l = 0, u = 2, d = 1, f = a.slice.call(arguments, 1), p = Object.create(this.lexer), h = { yy: {} };
			for (var g in this.yy) Object.prototype.hasOwnProperty.call(this.yy, g) && (h.yy[g] = this.yy[g]);
			p.setInput(e, h.yy), h.yy.lexer = p, h.yy.parser = this, typeof p.yylloc > "u" && (p.yylloc = {});
			var _ = p.yylloc;
			a.push(_);
			var v = p.options && p.options.ranges;
			this.parseError = typeof h.yy.parseError == "function" ? h.yy.parseError : Object.getPrototypeOf(this).parseError;
			function y(e) {
				n.length -= 2 * e, i.length -= e, a.length -= e;
			}
			m(y, "popStack");
			function b() {
				var e;
				return e = r.pop() || p.lex() || d, typeof e != "number" && (e instanceof Array && (r = e, e = r.pop()), e = t.symbols_[e] || e), e;
			}
			m(b, "lex");
			for (var x, S, C, w, T = {}, E, D, O, k;;) {
				if (S = n[n.length - 1], this.defaultActions[S] ? C = this.defaultActions[S] : ((x === null || typeof x > "u") && (x = b()), C = o[S] && o[S][x]), typeof C > "u" || !C.length || !C[0]) {
					var A = "";
					for (E in k = [], o[S]) this.terminals_[E] && E > u && k.push("'" + this.terminals_[E] + "'");
					A = p.showPosition ? "Parse error on line " + (c + 1) + ":\n" + p.showPosition() + "\nExpecting " + k.join(", ") + ", got '" + (this.terminals_[x] || x) + "'" : "Parse error on line " + (c + 1) + ": Unexpected " + (x == d ? "end of input" : "'" + (this.terminals_[x] || x) + "'"), this.parseError(A, {
						text: p.match,
						token: this.terminals_[x] || x,
						line: p.yylineno,
						loc: _,
						expected: k
					});
				}
				if (C[0] instanceof Array && C.length > 1) throw Error("Parse Error: multiple actions possible at state: " + S + ", token: " + x);
				switch (C[0]) {
					case 1:
						n.push(x), i.push(p.yytext), a.push(p.yylloc), n.push(C[1]), x = null, l = p.yyleng, s = p.yytext, c = p.yylineno, _ = p.yylloc;
						break;
					case 2:
						if (D = this.productions_[C[1]][1], T.$ = i[i.length - D], T._$ = {
							first_line: a[a.length - (D || 1)].first_line,
							last_line: a[a.length - 1].last_line,
							first_column: a[a.length - (D || 1)].first_column,
							last_column: a[a.length - 1].last_column
						}, v && (T._$.range = [a[a.length - (D || 1)].range[0], a[a.length - 1].range[1]]), w = this.performAction.apply(T, [
							s,
							l,
							c,
							h.yy,
							C[1],
							i,
							a
						].concat(f)), typeof w < "u") return w;
						D && (n = n.slice(0, -1 * D * 2), i = i.slice(0, -1 * D), a = a.slice(0, -1 * D)), n.push(this.productions_[C[1]][0]), i.push(T.$), a.push(T._$), O = o[n[n.length - 2]][n[n.length - 1]], n.push(O);
						break;
					case 3: return !0;
				}
			}
			return !0;
		}, "parse")
	};
	i.lexer = /* @__PURE__ */ function() {
		return {
			EOF: 1,
			parseError: /* @__PURE__ */ m(function(e, t) {
				if (this.yy.parser) this.yy.parser.parseError(e, t);
				else throw Error(e);
			}, "parseError"),
			setInput: /* @__PURE__ */ m(function(e, t) {
				return this.yy = t || this.yy || {}, this._input = e, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
					first_line: 1,
					first_column: 0,
					last_line: 1,
					last_column: 0
				}, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
			}, "setInput"),
			input: /* @__PURE__ */ m(function() {
				var e = this._input[0];
				return this.yytext += e, this.yyleng++, this.offset++, this.match += e, this.matched += e, e.match(/(?:\r\n?|\n).*/g) ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), e;
			}, "input"),
			unput: /* @__PURE__ */ m(function(e) {
				var t = e.length, n = e.split(/(?:\r\n?|\n)/g);
				this._input = e + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - t), this.offset -= t;
				var r = this.match.split(/(?:\r\n?|\n)/g);
				this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), n.length - 1 && (this.yylineno -= n.length - 1);
				var i = this.yylloc.range;
				return this.yylloc = {
					first_line: this.yylloc.first_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.first_column,
					last_column: n ? (n.length === r.length ? this.yylloc.first_column : 0) + r[r.length - n.length].length - n[0].length : this.yylloc.first_column - t
				}, this.options.ranges && (this.yylloc.range = [i[0], i[0] + this.yyleng - t]), this.yyleng = this.yytext.length, this;
			}, "unput"),
			more: /* @__PURE__ */ m(function() {
				return this._more = !0, this;
			}, "more"),
			reject: /* @__PURE__ */ m(function() {
				if (this.options.backtrack_lexer) this._backtrack = !0;
				else return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
				return this;
			}, "reject"),
			less: /* @__PURE__ */ m(function(e) {
				this.unput(this.match.slice(e));
			}, "less"),
			pastInput: /* @__PURE__ */ m(function() {
				var e = this.matched.substr(0, this.matched.length - this.match.length);
				return (e.length > 20 ? "..." : "") + e.substr(-20).replace(/\n/g, "");
			}, "pastInput"),
			upcomingInput: /* @__PURE__ */ m(function() {
				var e = this.match;
				return e.length < 20 && (e += this._input.substr(0, 20 - e.length)), (e.substr(0, 20) + (e.length > 20 ? "..." : "")).replace(/\n/g, "");
			}, "upcomingInput"),
			showPosition: /* @__PURE__ */ m(function() {
				var e = this.pastInput(), t = Array(e.length + 1).join("-");
				return e + this.upcomingInput() + "\n" + t + "^";
			}, "showPosition"),
			test_match: /* @__PURE__ */ m(function(e, t) {
				var n, r, i;
				if (this.options.backtrack_lexer && (i = {
					yylineno: this.yylineno,
					yylloc: {
						first_line: this.yylloc.first_line,
						last_line: this.last_line,
						first_column: this.yylloc.first_column,
						last_column: this.yylloc.last_column
					},
					yytext: this.yytext,
					match: this.match,
					matches: this.matches,
					matched: this.matched,
					yyleng: this.yyleng,
					offset: this.offset,
					_more: this._more,
					_input: this._input,
					yy: this.yy,
					conditionStack: this.conditionStack.slice(0),
					done: this.done
				}, this.options.ranges && (i.yylloc.range = this.yylloc.range.slice(0))), r = e[0].match(/(?:\r\n?|\n).*/g), r && (this.yylineno += r.length), this.yylloc = {
					first_line: this.yylloc.last_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.last_column,
					last_column: r ? r[r.length - 1].length - r[r.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + e[0].length
				}, this.yytext += e[0], this.match += e[0], this.matches = e, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(e[0].length), this.matched += e[0], n = this.performAction.call(this, this.yy, this, t, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), n) return n;
				if (this._backtrack) {
					for (var a in i) this[a] = i[a];
					return !1;
				}
				return !1;
			}, "test_match"),
			next: /* @__PURE__ */ m(function() {
				if (this.done) return this.EOF;
				this._input || (this.done = !0);
				var e, t, n, r;
				this._more || (this.yytext = "", this.match = "");
				for (var i = this._currentRules(), a = 0; a < i.length; a++) if (n = this._input.match(this.rules[i[a]]), n && (!t || n[0].length > t[0].length)) {
					if (t = n, r = a, this.options.backtrack_lexer) {
						if (e = this.test_match(n, i[a]), e !== !1) return e;
						if (this._backtrack) {
							t = !1;
							continue;
						}
						return !1;
					}
					if (!this.options.flex) break;
				}
				return t ? (e = this.test_match(t, i[r]), e !== !1 && e) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
			}, "next"),
			lex: /* @__PURE__ */ m(function() {
				return this.next() || this.lex();
			}, "lex"),
			begin: /* @__PURE__ */ m(function(e) {
				this.conditionStack.push(e);
			}, "begin"),
			popState: /* @__PURE__ */ m(function() {
				return this.conditionStack.length - 1 > 0 ? this.conditionStack.pop() : this.conditionStack[0];
			}, "popState"),
			_currentRules: /* @__PURE__ */ m(function() {
				return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
			}, "_currentRules"),
			topState: /* @__PURE__ */ m(function(e) {
				return e = this.conditionStack.length - 1 - Math.abs(e || 0), e >= 0 ? this.conditionStack[e] : "INITIAL";
			}, "topState"),
			pushState: /* @__PURE__ */ m(function(e) {
				this.begin(e);
			}, "pushState"),
			stateStackSize: /* @__PURE__ */ m(function() {
				return this.conditionStack.length;
			}, "stateStackSize"),
			options: { "case-insensitive": !0 },
			performAction: /* @__PURE__ */ m(function(e, t, n, r) {
				switch (n) {
					case 0: return this.pushState("csv"), 4;
					case 1: return this.pushState("csv"), 4;
					case 2: return 10;
					case 3: return 5;
					case 4: return 12;
					case 5: return this.pushState("escaped_text"), 18;
					case 6: return 20;
					case 7: return this.popState("escaped_text"), 18;
					case 8: return 19;
				}
			}, "anonymous"),
			rules: [
				/^(?:sankey-beta\b)/i,
				/^(?:sankey\b)/i,
				/^(?:$)/i,
				/^(?:((\u000D\u000A)|(\u000A)))/i,
				/^(?:(\u002C))/i,
				/^(?:(\u0022))/i,
				/^(?:([\u0020-\u0021\u0023-\u002B\u002D-\u007E])*)/i,
				/^(?:(\u0022)(?!(\u0022)))/i,
				/^(?:(([\u0020-\u0021\u0023-\u002B\u002D-\u007E])|(\u002C)|(\u000D)|(\u000A)|(\u0022)(\u0022))*)/i
			],
			conditions: {
				csv: {
					rules: [
						2,
						3,
						4,
						5,
						6,
						7,
						8
					],
					inclusive: !1
				},
				escaped_text: {
					rules: [7, 8],
					inclusive: !1
				},
				INITIAL: {
					rules: [
						0,
						1,
						2,
						3,
						4,
						5,
						6,
						7,
						8
					],
					inclusive: !0
				}
			}
		};
	}();
	function a() {
		this.yy = {};
	}
	return m(a, "Parser"), a.prototype = i, i.Parser = a, new a();
}();
G.parser = G;
var K = G, q = [], J = [], Y = /* @__PURE__ */ new Map(), ce = /* @__PURE__ */ m(() => {
	q = [], J = [], Y = /* @__PURE__ */ new Map(), r();
}, "clear"), X, le = (X = class {
	constructor(e, t, n = 0) {
		this.source = e, this.target = t, this.value = n;
	}
}, m(X, "SankeyLink"), X), ue = /* @__PURE__ */ m((e, t, n) => {
	q.push(new le(e, t, n));
}, "addLink"), Z, de = (Z = class {
	constructor(e) {
		this.ID = e;
	}
}, m(Z, "SankeyNode"), Z), fe = {
	nodesMap: Y,
	getConfig: /* @__PURE__ */ m(() => c().sankey, "getConfig"),
	getNodes: /* @__PURE__ */ m(() => J, "getNodes"),
	getLinks: /* @__PURE__ */ m(() => q, "getLinks"),
	getGraph: /* @__PURE__ */ m(() => ({
		nodes: J.map((e) => ({ id: e.ID })),
		links: q.map((e) => ({
			source: e.source.ID,
			target: e.target.ID,
			value: e.value
		}))
	}), "getGraph"),
	addLink: ue,
	findOrCreateNode: /* @__PURE__ */ m((e) => {
		e = i.sanitizeText(e, c());
		let t = Y.get(e);
		return t === void 0 && (t = new de(e), Y.set(e, t), J.push(t)), t;
	}, "findOrCreateNode"),
	getAccTitle: s,
	setAccTitle: p,
	getAccDescription: o,
	setAccDescription: f,
	getDiagramTitle: l,
	setDiagramTitle: u,
	clear: ce
}, Q, $ = (Q = class {
	static next(e) {
		return new Q(e + ++Q.count);
	}
	constructor(e) {
		this.id = e, this.href = `#${e}`;
	}
	toString() {
		return "url(" + this.href + ")";
	}
}, m(Q, "Uid"), Q.count = 0, Q), pe = {
	left: b,
	right: x,
	center: C,
	justify: S
}, me = /* @__PURE__ */ m((e) => {
	let t = 0, n = 0;
	for (let r of e) {
		let e = r.value ?? 0;
		e > t && (t = e, n = r.layer ?? 0);
	}
	return n;
}, "findCentralNodeLayer"), he = { draw: /* @__PURE__ */ m(function(t, r, i, o) {
	let { securityLevel: s, sankey: l } = c(), u = a.sankey, f;
	s === "sandbox" && (f = n("#i" + r));
	let p = n(s === "sandbox" ? f.nodes()[0].contentDocument.body : "body"), g = s === "sandbox" ? p.select(`[id="${r}"]`) : n(`[id="${r}"]`), _ = l?.width ?? u.width, v = l?.height ?? u.width, y = l?.useMaxWidth ?? u.useMaxWidth, b = l?.nodeAlignment ?? u.nodeAlignment, x = l?.prefix ?? u.prefix, S = l?.suffix ?? u.suffix, C = l?.showValues ?? u.showValues, w = l?.nodeWidth ?? u.nodeWidth ?? 10, T = l?.nodePadding ?? u.nodePadding ?? 12, E = l?.labelStyle ?? u.labelStyle ?? "legacy", D = l?.nodeColors ?? {}, O = o.db.getGraph(), k = pe[b];
	P().nodeId((e) => e.id).nodeWidth(w).nodePadding(T + (C ? 15 : 0)).nodeAlign(k).extent([[0, 0], [_, v]])(O);
	let A = me(O.nodes), j = e(h), M = /* @__PURE__ */ m((e) => D[e] ?? j(e), "getNodeColor");
	g.append("g").attr("class", "nodes").selectAll(".node").data(O.nodes).join("g").attr("class", "node").attr("id", (e) => (e.uid = $.next("node-")).id).attr("transform", function(e) {
		return "translate(" + e.x0 + "," + e.y0 + ")";
	}).attr("x", (e) => e.x0).attr("y", (e) => e.y0).append("rect").attr("height", (e) => e.y1 - e.y0).attr("width", (e) => e.x1 - e.x0).attr("fill", (e) => M(e.id));
	let N = /* @__PURE__ */ m(({ id: e, value: t }) => C ? `${e}
${x}${Math.round(t * 100) / 100}${S}` : e, "getText"), F = /* @__PURE__ */ m((e) => E === "outlined" ? (e.layer ?? 0) < A ? {
		x: e.x0 - 6,
		anchor: "end"
	} : {
		x: e.x1 + 6,
		anchor: "start"
	} : e.x0 < _ / 2 ? {
		x: e.x1 + 6,
		anchor: "start"
	} : {
		x: e.x0 - 6,
		anchor: "end"
	}, "getLabelPosition"), I = g.append("g").attr("class", "node-labels").attr("font-size", 14), L = /* @__PURE__ */ m((e) => I.selectAll(e ? `.${e}` : "text").data(O.nodes).join("text").attr("class", e ?? null).attr("x", (e) => F(e).x).attr("y", (e) => (e.y1 + e.y0) / 2).attr("dy", `${C ? "0" : "0.35"}em`).attr("text-anchor", (e) => F(e).anchor).text(N), "appendLabel");
	E === "outlined" ? (L("sankey-label-bg"), L("sankey-label-fg")) : L();
	let R = g.append("g").attr("class", "links").attr("fill", "none").attr("stroke-opacity", .5).selectAll(".link").data(O.links).join("g").attr("class", "link").style("mix-blend-mode", "multiply"), z = l?.linkColor ?? "gradient";
	if (z === "gradient") {
		let e = R.append("linearGradient").attr("id", (e) => (e.uid = $.next("linearGradient-")).id).attr("gradientUnits", "userSpaceOnUse").attr("x1", (e) => e.source.x1).attr("x2", (e) => e.target.x0);
		e.append("stop").attr("offset", "0%").attr("stop-color", (e) => M(e.source.id)), e.append("stop").attr("offset", "100%").attr("stop-color", (e) => M(e.target.id));
	}
	let B;
	switch (z) {
		case "gradient":
			B = /* @__PURE__ */ m((e) => e.uid, "coloring");
			break;
		case "source":
			B = /* @__PURE__ */ m((e) => M(e.source.id), "coloring");
			break;
		case "target":
			B = /* @__PURE__ */ m((e) => M(e.target.id), "coloring");
			break;
		default: B = z;
	}
	R.append("path").attr("d", se()).attr("stroke", B).attr("stroke-width", (e) => Math.max(1, e.width)), d(void 0, g, 0, y);
}, "draw") }, ge = /* @__PURE__ */ m((e) => e.replaceAll(/^[^\S\n\r]+|[^\S\n\r]+$/g, "").replaceAll(/([\n\r])+/g, "\n").trim(), "prepareTextForParsing"), _e = /* @__PURE__ */ m((e) => `.label {
    font-family: ${e.fontFamily};
  }

  .node-labels {
    font-family: ${e.fontFamily};
  }

  /* Outlined label style - background stroke for better readability */
  .sankey-label-bg {
    stroke: ${e.mainBkg || e.background || "#fff"};
    stroke-width: 4px;
    stroke-linejoin: round;
    paint-order: stroke;
  }

  /* Foreground label text */
  .sankey-label-fg {
    fill: ${e.textColor};
  }

  /* Node styling */
  .node rect {
    shape-rendering: crispEdges;
  }

  /* Link styling */
  .link {
    fill: none;
    stroke-opacity: 0.5;
    mix-blend-mode: multiply;
  }
`, "getStyles"), ve = K.parse.bind(K);
K.parse = (e) => ve(ge(e));
var ye = {
	styles: _e,
	parser: K,
	db: fe,
	renderer: he
};
//#endregion
export { ye as diagram };

//# sourceMappingURL=sankeyDiagram-P5KCCOFB-yxvIZO6U-3gLSl8e5.js.map