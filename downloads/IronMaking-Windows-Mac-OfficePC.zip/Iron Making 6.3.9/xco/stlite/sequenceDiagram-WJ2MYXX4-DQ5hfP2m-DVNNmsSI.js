import { c as e } from "./transform-B2AI7qp--hg0kwf7R.js";
import { E as t, J as n, N as r, Q as i, T as a, a9 as o, aA as s, ai as c, aj as l, al as u, am as d, an as f, aw as p, b5 as m, b6 as h, bA as g, bB as _, bX as v, bi as y, bt as b, bw as x, by as S, bz as C, c as w, p as T } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
import { c as E, n as D, o as O, r as k, s as A, t as j } from "./chunk-F27PBJKO-D1wNBEs6-BZkgQri7.js";
import { t as M } from "./chunk-2Q5K7J3B-5AANKyYA-BUoajoM4.js";
//#region ../react/build/sequenceDiagram-WJ2MYXX4-DQ5hfP2m.js
var N = function() {
	var e = /* @__PURE__ */ w(function(e, t, n, r) {
		for (n ||= {}, r = e.length; r--; n[e[r]] = t);
		return n;
	}, "o"), t = [1, 2], n = [1, 3], r = [1, 4], i = [2, 4], a = [1, 9], o = [1, 11], s = [1, 12], c = [1, 14], l = [1, 15], u = [1, 17], d = [1, 18], f = [1, 19], p = [1, 25], m = [1, 26], h = [1, 27], g = [1, 28], _ = [1, 29], v = [1, 30], y = [1, 31], b = [1, 32], x = [1, 33], S = [1, 34], C = [1, 35], T = [1, 36], E = [1, 37], D = [1, 38], O = [1, 39], k = [1, 40], A = [1, 42], j = [1, 43], M = [1, 44], N = [1, 45], P = [1, 46], F = [1, 47], I = [
		1,
		4,
		5,
		10,
		14,
		15,
		17,
		19,
		22,
		24,
		30,
		31,
		32,
		34,
		36,
		37,
		38,
		39,
		40,
		42,
		44,
		45,
		47,
		48,
		49,
		50,
		51,
		53,
		54,
		56,
		61,
		62,
		63,
		64,
		73
	], ee = [1, 74], L = [1, 80], R = [1, 81], te = [1, 82], ne = [1, 83], z = [1, 84], B = [1, 85], V = [1, 86], re = [1, 87], H = [1, 88], U = [1, 89], W = [1, 90], ie = [1, 91], ae = [1, 92], oe = [1, 93], G = [1, 94], se = [1, 95], K = [1, 96], ce = [1, 97], le = [1, 98], ue = [1, 99], de = [1, 100], fe = [1, 101], pe = [1, 102], me = [1, 103], he = [1, 104], ge = [1, 105], _e = [2, 78], ve = [
		4,
		5,
		17,
		51,
		53,
		54
	], ye = [
		4,
		5,
		10,
		14,
		15,
		17,
		19,
		22,
		24,
		30,
		31,
		32,
		34,
		36,
		37,
		38,
		39,
		40,
		42,
		44,
		45,
		47,
		51,
		53,
		54,
		56,
		61,
		62,
		63,
		64,
		73
	], be = [
		4,
		5,
		10,
		14,
		15,
		17,
		19,
		22,
		24,
		30,
		31,
		32,
		34,
		36,
		37,
		38,
		39,
		40,
		42,
		44,
		45,
		47,
		50,
		51,
		53,
		54,
		56,
		61,
		62,
		63,
		64,
		73
	], xe = [
		4,
		5,
		10,
		14,
		15,
		17,
		19,
		22,
		24,
		30,
		31,
		32,
		34,
		36,
		37,
		38,
		39,
		40,
		42,
		44,
		45,
		47,
		49,
		51,
		53,
		54,
		56,
		61,
		62,
		63,
		64,
		73
	], Se = [
		4,
		5,
		10,
		14,
		15,
		17,
		19,
		22,
		24,
		30,
		31,
		32,
		34,
		36,
		37,
		38,
		39,
		40,
		42,
		44,
		45,
		47,
		48,
		51,
		53,
		54,
		56,
		61,
		62,
		63,
		64,
		73
	], Ce = [5, 52], q = [
		70,
		71,
		72,
		73
	], J = [1, 151], we = {
		trace: /* @__PURE__ */ w(function() {}, "trace"),
		yy: {},
		symbols_: {
			error: 2,
			start: 3,
			SPACE: 4,
			NEWLINE: 5,
			SD: 6,
			document: 7,
			line: 8,
			statement: 9,
			INVALID: 10,
			box_section: 11,
			box_line: 12,
			participant_statement: 13,
			create: 14,
			box: 15,
			restOfLine: 16,
			end: 17,
			signal: 18,
			autonumber: 19,
			NUM: 20,
			off: 21,
			activate: 22,
			actor: 23,
			deactivate: 24,
			note_statement: 25,
			links_statement: 26,
			link_statement: 27,
			properties_statement: 28,
			details_statement: 29,
			title: 30,
			legacy_title: 31,
			acc_title: 32,
			acc_title_value: 33,
			acc_descr: 34,
			acc_descr_value: 35,
			acc_descr_multiline_value: 36,
			loop: 37,
			rect: 38,
			opt: 39,
			alt: 40,
			else_sections: 41,
			par: 42,
			par_sections: 43,
			par_over: 44,
			critical: 45,
			option_sections: 46,
			break: 47,
			option: 48,
			and: 49,
			else: 50,
			participant: 51,
			AS: 52,
			participant_actor: 53,
			destroy: 54,
			actor_with_config: 55,
			note: 56,
			placement: 57,
			text2: 58,
			over: 59,
			actor_pair: 60,
			links: 61,
			link: 62,
			properties: 63,
			details: 64,
			spaceList: 65,
			",": 66,
			left_of: 67,
			right_of: 68,
			signaltype: 69,
			"+": 70,
			"-": 71,
			"()": 72,
			ACTOR: 73,
			config_object: 74,
			CONFIG_START: 75,
			CONFIG_CONTENT: 76,
			CONFIG_END: 77,
			SOLID_OPEN_ARROW: 78,
			DOTTED_OPEN_ARROW: 79,
			SOLID_ARROW: 80,
			SOLID_ARROW_TOP: 81,
			SOLID_ARROW_BOTTOM: 82,
			STICK_ARROW_TOP: 83,
			STICK_ARROW_BOTTOM: 84,
			SOLID_ARROW_TOP_DOTTED: 85,
			SOLID_ARROW_BOTTOM_DOTTED: 86,
			STICK_ARROW_TOP_DOTTED: 87,
			STICK_ARROW_BOTTOM_DOTTED: 88,
			SOLID_ARROW_TOP_REVERSE: 89,
			SOLID_ARROW_BOTTOM_REVERSE: 90,
			STICK_ARROW_TOP_REVERSE: 91,
			STICK_ARROW_BOTTOM_REVERSE: 92,
			SOLID_ARROW_TOP_REVERSE_DOTTED: 93,
			SOLID_ARROW_BOTTOM_REVERSE_DOTTED: 94,
			STICK_ARROW_TOP_REVERSE_DOTTED: 95,
			STICK_ARROW_BOTTOM_REVERSE_DOTTED: 96,
			BIDIRECTIONAL_SOLID_ARROW: 97,
			DOTTED_ARROW: 98,
			BIDIRECTIONAL_DOTTED_ARROW: 99,
			SOLID_CROSS: 100,
			DOTTED_CROSS: 101,
			SOLID_POINT: 102,
			DOTTED_POINT: 103,
			TXT: 104,
			$accept: 0,
			$end: 1
		},
		terminals_: {
			2: "error",
			4: "SPACE",
			5: "NEWLINE",
			6: "SD",
			10: "INVALID",
			14: "create",
			15: "box",
			16: "restOfLine",
			17: "end",
			19: "autonumber",
			20: "NUM",
			21: "off",
			22: "activate",
			24: "deactivate",
			30: "title",
			31: "legacy_title",
			32: "acc_title",
			33: "acc_title_value",
			34: "acc_descr",
			35: "acc_descr_value",
			36: "acc_descr_multiline_value",
			37: "loop",
			38: "rect",
			39: "opt",
			40: "alt",
			42: "par",
			44: "par_over",
			45: "critical",
			47: "break",
			48: "option",
			49: "and",
			50: "else",
			51: "participant",
			52: "AS",
			53: "participant_actor",
			54: "destroy",
			56: "note",
			59: "over",
			61: "links",
			62: "link",
			63: "properties",
			64: "details",
			66: ",",
			67: "left_of",
			68: "right_of",
			70: "+",
			71: "-",
			72: "()",
			73: "ACTOR",
			75: "CONFIG_START",
			76: "CONFIG_CONTENT",
			77: "CONFIG_END",
			78: "SOLID_OPEN_ARROW",
			79: "DOTTED_OPEN_ARROW",
			80: "SOLID_ARROW",
			81: "SOLID_ARROW_TOP",
			82: "SOLID_ARROW_BOTTOM",
			83: "STICK_ARROW_TOP",
			84: "STICK_ARROW_BOTTOM",
			85: "SOLID_ARROW_TOP_DOTTED",
			86: "SOLID_ARROW_BOTTOM_DOTTED",
			87: "STICK_ARROW_TOP_DOTTED",
			88: "STICK_ARROW_BOTTOM_DOTTED",
			89: "SOLID_ARROW_TOP_REVERSE",
			90: "SOLID_ARROW_BOTTOM_REVERSE",
			91: "STICK_ARROW_TOP_REVERSE",
			92: "STICK_ARROW_BOTTOM_REVERSE",
			93: "SOLID_ARROW_TOP_REVERSE_DOTTED",
			94: "SOLID_ARROW_BOTTOM_REVERSE_DOTTED",
			95: "STICK_ARROW_TOP_REVERSE_DOTTED",
			96: "STICK_ARROW_BOTTOM_REVERSE_DOTTED",
			97: "BIDIRECTIONAL_SOLID_ARROW",
			98: "DOTTED_ARROW",
			99: "BIDIRECTIONAL_DOTTED_ARROW",
			100: "SOLID_CROSS",
			101: "DOTTED_CROSS",
			102: "SOLID_POINT",
			103: "DOTTED_POINT",
			104: "TXT"
		},
		productions_: [
			0,
			[3, 2],
			[3, 2],
			[3, 2],
			[7, 0],
			[7, 2],
			[8, 2],
			[8, 1],
			[8, 1],
			[8, 1],
			[11, 0],
			[11, 2],
			[12, 2],
			[12, 1],
			[12, 1],
			[9, 1],
			[9, 2],
			[9, 4],
			[9, 2],
			[9, 4],
			[9, 3],
			[9, 3],
			[9, 2],
			[9, 3],
			[9, 3],
			[9, 2],
			[9, 2],
			[9, 2],
			[9, 2],
			[9, 2],
			[9, 1],
			[9, 1],
			[9, 2],
			[9, 2],
			[9, 1],
			[9, 4],
			[9, 4],
			[9, 4],
			[9, 4],
			[9, 4],
			[9, 4],
			[9, 4],
			[9, 4],
			[46, 1],
			[46, 4],
			[43, 1],
			[43, 4],
			[41, 1],
			[41, 4],
			[13, 5],
			[13, 3],
			[13, 5],
			[13, 3],
			[13, 3],
			[13, 5],
			[13, 3],
			[13, 5],
			[13, 3],
			[25, 4],
			[25, 4],
			[26, 3],
			[27, 3],
			[28, 3],
			[29, 3],
			[65, 2],
			[65, 1],
			[60, 3],
			[60, 1],
			[57, 1],
			[57, 1],
			[18, 5],
			[18, 5],
			[18, 5],
			[18, 5],
			[18, 6],
			[18, 4],
			[55, 2],
			[74, 3],
			[23, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[69, 1],
			[58, 1]
		],
		performAction: /* @__PURE__ */ w(function(e, t, n, r, i, a, o) {
			var s = a.length - 1;
			switch (i) {
				case 3: return r.apply(a[s]), a[s];
				case 4:
				case 10:
					this.$ = [];
					break;
				case 5:
				case 11:
					a[s - 1].push(a[s]), this.$ = a[s - 1];
					break;
				case 6:
				case 7:
				case 12:
				case 13:
					this.$ = a[s];
					break;
				case 8:
				case 9:
				case 14:
					this.$ = [];
					break;
				case 16:
					a[s].type = "createParticipant", this.$ = a[s];
					break;
				case 17:
					a[s - 1].unshift({
						type: "boxStart",
						boxData: r.parseBoxData(a[s - 2])
					}), a[s - 1].push({
						type: "boxEnd",
						boxText: a[s - 2]
					}), this.$ = a[s - 1];
					break;
				case 19:
					this.$ = {
						type: "sequenceIndex",
						sequenceIndex: Number(a[s - 2]),
						sequenceIndexStep: Number(a[s - 1]),
						sequenceVisible: !0,
						signalType: r.LINETYPE.AUTONUMBER
					};
					break;
				case 20:
					this.$ = {
						type: "sequenceIndex",
						sequenceIndex: Number(a[s - 1]),
						sequenceIndexStep: 1,
						sequenceVisible: !0,
						signalType: r.LINETYPE.AUTONUMBER
					};
					break;
				case 21:
					this.$ = {
						type: "sequenceIndex",
						sequenceVisible: !1,
						signalType: r.LINETYPE.AUTONUMBER
					};
					break;
				case 22:
					this.$ = {
						type: "sequenceIndex",
						sequenceVisible: !0,
						signalType: r.LINETYPE.AUTONUMBER
					};
					break;
				case 23:
					this.$ = {
						type: "activeStart",
						signalType: r.LINETYPE.ACTIVE_START,
						actor: a[s - 1].actor
					};
					break;
				case 24:
					this.$ = {
						type: "activeEnd",
						signalType: r.LINETYPE.ACTIVE_END,
						actor: a[s - 1].actor
					};
					break;
				case 30:
					r.setDiagramTitle(a[s].substring(6)), this.$ = a[s].substring(6);
					break;
				case 31:
					r.setDiagramTitle(a[s].substring(7)), this.$ = a[s].substring(7);
					break;
				case 32:
					this.$ = a[s].trim(), r.setAccTitle(this.$);
					break;
				case 33:
				case 34:
					this.$ = a[s].trim(), r.setAccDescription(this.$);
					break;
				case 35:
					a[s - 1].unshift({
						type: "loopStart",
						loopText: r.parseMessage(a[s - 2]),
						signalType: r.LINETYPE.LOOP_START
					}), a[s - 1].push({
						type: "loopEnd",
						loopText: a[s - 2],
						signalType: r.LINETYPE.LOOP_END
					}), this.$ = a[s - 1];
					break;
				case 36:
					a[s - 1].unshift({
						type: "rectStart",
						color: r.parseMessage(a[s - 2]),
						signalType: r.LINETYPE.RECT_START
					}), a[s - 1].push({
						type: "rectEnd",
						color: r.parseMessage(a[s - 2]),
						signalType: r.LINETYPE.RECT_END
					}), this.$ = a[s - 1];
					break;
				case 37:
					a[s - 1].unshift({
						type: "optStart",
						optText: r.parseMessage(a[s - 2]),
						signalType: r.LINETYPE.OPT_START
					}), a[s - 1].push({
						type: "optEnd",
						optText: r.parseMessage(a[s - 2]),
						signalType: r.LINETYPE.OPT_END
					}), this.$ = a[s - 1];
					break;
				case 38:
					a[s - 1].unshift({
						type: "altStart",
						altText: r.parseMessage(a[s - 2]),
						signalType: r.LINETYPE.ALT_START
					}), a[s - 1].push({
						type: "altEnd",
						signalType: r.LINETYPE.ALT_END
					}), this.$ = a[s - 1];
					break;
				case 39:
					a[s - 1].unshift({
						type: "parStart",
						parText: r.parseMessage(a[s - 2]),
						signalType: r.LINETYPE.PAR_START
					}), a[s - 1].push({
						type: "parEnd",
						signalType: r.LINETYPE.PAR_END
					}), this.$ = a[s - 1];
					break;
				case 40:
					a[s - 1].unshift({
						type: "parStart",
						parText: r.parseMessage(a[s - 2]),
						signalType: r.LINETYPE.PAR_OVER_START
					}), a[s - 1].push({
						type: "parEnd",
						signalType: r.LINETYPE.PAR_END
					}), this.$ = a[s - 1];
					break;
				case 41:
					a[s - 1].unshift({
						type: "criticalStart",
						criticalText: r.parseMessage(a[s - 2]),
						signalType: r.LINETYPE.CRITICAL_START
					}), a[s - 1].push({
						type: "criticalEnd",
						signalType: r.LINETYPE.CRITICAL_END
					}), this.$ = a[s - 1];
					break;
				case 42:
					a[s - 1].unshift({
						type: "breakStart",
						breakText: r.parseMessage(a[s - 2]),
						signalType: r.LINETYPE.BREAK_START
					}), a[s - 1].push({
						type: "breakEnd",
						optText: r.parseMessage(a[s - 2]),
						signalType: r.LINETYPE.BREAK_END
					}), this.$ = a[s - 1];
					break;
				case 44:
					this.$ = a[s - 3].concat([{
						type: "option",
						optionText: r.parseMessage(a[s - 1]),
						signalType: r.LINETYPE.CRITICAL_OPTION
					}, a[s]]);
					break;
				case 46:
					this.$ = a[s - 3].concat([{
						type: "and",
						parText: r.parseMessage(a[s - 1]),
						signalType: r.LINETYPE.PAR_AND
					}, a[s]]);
					break;
				case 48:
					this.$ = a[s - 3].concat([{
						type: "else",
						altText: r.parseMessage(a[s - 1]),
						signalType: r.LINETYPE.ALT_ELSE
					}, a[s]]);
					break;
				case 49:
					a[s - 3].draw = "participant", a[s - 3].type = "addParticipant", a[s - 3].description = r.parseMessage(a[s - 1]), this.$ = a[s - 3];
					break;
				case 50:
					a[s - 1].draw = "participant", a[s - 1].type = "addParticipant", this.$ = a[s - 1];
					break;
				case 51:
					a[s - 3].draw = "actor", a[s - 3].type = "addParticipant", a[s - 3].description = r.parseMessage(a[s - 1]), this.$ = a[s - 3];
					break;
				case 52:
				case 57:
					a[s - 1].draw = "actor", a[s - 1].type = "addParticipant", this.$ = a[s - 1];
					break;
				case 53:
					a[s - 1].type = "destroyParticipant", this.$ = a[s - 1];
					break;
				case 54:
					a[s - 3].draw = "participant", a[s - 3].type = "addParticipant", a[s - 3].description = r.parseMessage(a[s - 1]), this.$ = a[s - 3];
					break;
				case 55:
					a[s - 1].draw = "participant", a[s - 1].type = "addParticipant", this.$ = a[s - 1];
					break;
				case 56:
					a[s - 3].draw = "actor", a[s - 3].type = "addParticipant", a[s - 3].description = r.parseMessage(a[s - 1]), this.$ = a[s - 3];
					break;
				case 58:
					this.$ = [a[s - 1], {
						type: "addNote",
						placement: a[s - 2],
						actor: a[s - 1].actor,
						text: a[s]
					}];
					break;
				case 59:
					a[s - 2] = [].concat(a[s - 1], a[s - 1]).slice(0, 2), a[s - 2][0] = a[s - 2][0].actor, a[s - 2][1] = a[s - 2][1].actor, this.$ = [a[s - 1], {
						type: "addNote",
						placement: r.PLACEMENT.OVER,
						actor: a[s - 2].slice(0, 2),
						text: a[s]
					}];
					break;
				case 60:
					this.$ = [a[s - 1], {
						type: "addLinks",
						actor: a[s - 1].actor,
						text: a[s]
					}];
					break;
				case 61:
					this.$ = [a[s - 1], {
						type: "addALink",
						actor: a[s - 1].actor,
						text: a[s]
					}];
					break;
				case 62:
					this.$ = [a[s - 1], {
						type: "addProperties",
						actor: a[s - 1].actor,
						text: a[s]
					}];
					break;
				case 63:
					this.$ = [a[s - 1], {
						type: "addDetails",
						actor: a[s - 1].actor,
						text: a[s]
					}];
					break;
				case 66:
					this.$ = [a[s - 2], a[s]];
					break;
				case 67:
					this.$ = a[s];
					break;
				case 68:
					this.$ = r.PLACEMENT.LEFTOF;
					break;
				case 69:
					this.$ = r.PLACEMENT.RIGHTOF;
					break;
				case 70:
					this.$ = [
						a[s - 4],
						a[s - 1],
						{
							type: "addMessage",
							from: a[s - 4].actor,
							to: a[s - 1].actor,
							signalType: a[s - 3],
							msg: a[s],
							activate: !0
						},
						{
							type: "activeStart",
							signalType: r.LINETYPE.ACTIVE_START,
							actor: a[s - 1].actor
						}
					];
					break;
				case 71:
					this.$ = [
						a[s - 4],
						a[s - 1],
						{
							type: "addMessage",
							from: a[s - 4].actor,
							to: a[s - 1].actor,
							signalType: a[s - 3],
							msg: a[s]
						},
						{
							type: "activeEnd",
							signalType: r.LINETYPE.ACTIVE_END,
							actor: a[s - 4].actor
						}
					];
					break;
				case 72:
					this.$ = [
						a[s - 4],
						a[s - 1],
						{
							type: "addMessage",
							from: a[s - 4].actor,
							to: a[s - 1].actor,
							signalType: a[s - 3],
							msg: a[s],
							activate: !0,
							centralConnection: r.LINETYPE.CENTRAL_CONNECTION
						},
						{
							type: "centralConnection",
							signalType: r.LINETYPE.CENTRAL_CONNECTION,
							actor: a[s - 1].actor
						}
					];
					break;
				case 73:
					this.$ = [
						a[s - 4],
						a[s - 1],
						{
							type: "addMessage",
							from: a[s - 4].actor,
							to: a[s - 1].actor,
							signalType: a[s - 2],
							msg: a[s],
							activate: !1,
							centralConnection: r.LINETYPE.CENTRAL_CONNECTION_REVERSE
						},
						{
							type: "centralConnectionReverse",
							signalType: r.LINETYPE.CENTRAL_CONNECTION_REVERSE,
							actor: a[s - 4].actor
						}
					];
					break;
				case 74:
					this.$ = [
						a[s - 5],
						a[s - 1],
						{
							type: "addMessage",
							from: a[s - 5].actor,
							to: a[s - 1].actor,
							signalType: a[s - 3],
							msg: a[s],
							activate: !0,
							centralConnection: r.LINETYPE.CENTRAL_CONNECTION_DUAL
						},
						{
							type: "centralConnection",
							signalType: r.LINETYPE.CENTRAL_CONNECTION,
							actor: a[s - 1].actor
						},
						{
							type: "centralConnectionReverse",
							signalType: r.LINETYPE.CENTRAL_CONNECTION_REVERSE,
							actor: a[s - 5].actor
						}
					];
					break;
				case 75:
					this.$ = [
						a[s - 3],
						a[s - 1],
						{
							type: "addMessage",
							from: a[s - 3].actor,
							to: a[s - 1].actor,
							signalType: a[s - 2],
							msg: a[s]
						}
					];
					break;
				case 76:
					this.$ = {
						type: "addParticipant",
						actor: a[s - 1],
						config: a[s]
					};
					break;
				case 77:
					this.$ = a[s - 1].trim();
					break;
				case 78:
					this.$ = {
						type: "addParticipant",
						actor: a[s]
					};
					break;
				case 79:
					this.$ = r.LINETYPE.SOLID_OPEN;
					break;
				case 80:
					this.$ = r.LINETYPE.DOTTED_OPEN;
					break;
				case 81:
					this.$ = r.LINETYPE.SOLID;
					break;
				case 82:
					this.$ = r.LINETYPE.SOLID_TOP;
					break;
				case 83:
					this.$ = r.LINETYPE.SOLID_BOTTOM;
					break;
				case 84:
					this.$ = r.LINETYPE.STICK_TOP;
					break;
				case 85:
					this.$ = r.LINETYPE.STICK_BOTTOM;
					break;
				case 86:
					this.$ = r.LINETYPE.SOLID_TOP_DOTTED;
					break;
				case 87:
					this.$ = r.LINETYPE.SOLID_BOTTOM_DOTTED;
					break;
				case 88:
					this.$ = r.LINETYPE.STICK_TOP_DOTTED;
					break;
				case 89:
					this.$ = r.LINETYPE.STICK_BOTTOM_DOTTED;
					break;
				case 90:
					this.$ = r.LINETYPE.SOLID_ARROW_TOP_REVERSE;
					break;
				case 91:
					this.$ = r.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE;
					break;
				case 92:
					this.$ = r.LINETYPE.STICK_ARROW_TOP_REVERSE;
					break;
				case 93:
					this.$ = r.LINETYPE.STICK_ARROW_BOTTOM_REVERSE;
					break;
				case 94:
					this.$ = r.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED;
					break;
				case 95:
					this.$ = r.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED;
					break;
				case 96:
					this.$ = r.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED;
					break;
				case 97:
					this.$ = r.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED;
					break;
				case 98:
					this.$ = r.LINETYPE.BIDIRECTIONAL_SOLID;
					break;
				case 99:
					this.$ = r.LINETYPE.DOTTED;
					break;
				case 100:
					this.$ = r.LINETYPE.BIDIRECTIONAL_DOTTED;
					break;
				case 101:
					this.$ = r.LINETYPE.SOLID_CROSS;
					break;
				case 102:
					this.$ = r.LINETYPE.DOTTED_CROSS;
					break;
				case 103:
					this.$ = r.LINETYPE.SOLID_POINT;
					break;
				case 104:
					this.$ = r.LINETYPE.DOTTED_POINT;
					break;
				case 105: this.$ = r.parseMessage(a[s].trim().substring(1));
			}
		}, "anonymous"),
		table: [
			{
				3: 1,
				4: t,
				5: n,
				6: r
			},
			{ 1: [3] },
			{
				3: 5,
				4: t,
				5: n,
				6: r
			},
			{
				3: 6,
				4: t,
				5: n,
				6: r
			},
			e([
				1,
				4,
				5,
				10,
				14,
				15,
				19,
				22,
				24,
				30,
				31,
				32,
				34,
				36,
				37,
				38,
				39,
				40,
				42,
				44,
				45,
				47,
				51,
				53,
				54,
				56,
				61,
				62,
				63,
				64,
				73
			], i, { 7: 7 }),
			{ 1: [2, 1] },
			{ 1: [2, 2] },
			{
				1: [2, 3],
				4: a,
				5: o,
				8: 8,
				9: 10,
				10: s,
				13: 13,
				14: c,
				15: l,
				18: 16,
				19: u,
				22: d,
				23: 41,
				24: f,
				25: 20,
				26: 21,
				27: 22,
				28: 23,
				29: 24,
				30: p,
				31: m,
				32: h,
				34: g,
				36: _,
				37: v,
				38: y,
				39: b,
				40: x,
				42: S,
				44: C,
				45: T,
				47: E,
				51: D,
				53: O,
				54: k,
				56: A,
				61: j,
				62: M,
				63: N,
				64: P,
				73: F
			},
			e(I, [2, 5]),
			{
				9: 48,
				13: 13,
				14: c,
				15: l,
				18: 16,
				19: u,
				22: d,
				23: 41,
				24: f,
				25: 20,
				26: 21,
				27: 22,
				28: 23,
				29: 24,
				30: p,
				31: m,
				32: h,
				34: g,
				36: _,
				37: v,
				38: y,
				39: b,
				40: x,
				42: S,
				44: C,
				45: T,
				47: E,
				51: D,
				53: O,
				54: k,
				56: A,
				61: j,
				62: M,
				63: N,
				64: P,
				73: F
			},
			e(I, [2, 7]),
			e(I, [2, 8]),
			e(I, [2, 9]),
			e(I, [2, 15]),
			{
				13: 49,
				51: D,
				53: O,
				54: k
			},
			{ 16: [1, 50] },
			{ 5: [1, 51] },
			{
				5: [1, 54],
				20: [1, 52],
				21: [1, 53]
			},
			{
				23: 55,
				73: F
			},
			{
				23: 56,
				73: F
			},
			{ 5: [1, 57] },
			{ 5: [1, 58] },
			{ 5: [1, 59] },
			{ 5: [1, 60] },
			{ 5: [1, 61] },
			e(I, [2, 30]),
			e(I, [2, 31]),
			{ 33: [1, 62] },
			{ 35: [1, 63] },
			e(I, [2, 34]),
			{ 16: [1, 64] },
			{ 16: [1, 65] },
			{ 16: [1, 66] },
			{ 16: [1, 67] },
			{ 16: [1, 68] },
			{ 16: [1, 69] },
			{ 16: [1, 70] },
			{ 16: [1, 71] },
			{
				23: 72,
				55: 73,
				73: ee
			},
			{
				23: 75,
				55: 76,
				73: ee
			},
			{
				23: 77,
				73: F
			},
			{
				69: 78,
				72: [1, 79],
				78: L,
				79: R,
				80: te,
				81: ne,
				82: z,
				83: B,
				84: V,
				85: re,
				86: H,
				87: U,
				88: W,
				89: ie,
				90: ae,
				91: oe,
				92: G,
				93: se,
				94: K,
				95: ce,
				96: le,
				97: ue,
				98: de,
				99: fe,
				100: pe,
				101: me,
				102: he,
				103: ge
			},
			{
				57: 106,
				59: [1, 107],
				67: [1, 108],
				68: [1, 109]
			},
			{
				23: 110,
				73: F
			},
			{
				23: 111,
				73: F
			},
			{
				23: 112,
				73: F
			},
			{
				23: 113,
				73: F
			},
			e([
				5,
				66,
				72,
				78,
				79,
				80,
				81,
				82,
				83,
				84,
				85,
				86,
				87,
				88,
				89,
				90,
				91,
				92,
				93,
				94,
				95,
				96,
				97,
				98,
				99,
				100,
				101,
				102,
				103,
				104
			], _e),
			e(I, [2, 6]),
			e(I, [2, 16]),
			e(ve, [2, 10], { 11: 114 }),
			e(I, [2, 18]),
			{
				5: [1, 116],
				20: [1, 115]
			},
			{ 5: [1, 117] },
			e(I, [2, 22]),
			{ 5: [1, 118] },
			{ 5: [1, 119] },
			e(I, [2, 25]),
			e(I, [2, 26]),
			e(I, [2, 27]),
			e(I, [2, 28]),
			e(I, [2, 29]),
			e(I, [2, 32]),
			e(I, [2, 33]),
			e(ye, i, { 7: 120 }),
			e(ye, i, { 7: 121 }),
			e(ye, i, { 7: 122 }),
			e(be, i, {
				41: 123,
				7: 124
			}),
			e(xe, i, {
				43: 125,
				7: 126
			}),
			e(xe, i, {
				7: 126,
				43: 127
			}),
			e(Se, i, {
				46: 128,
				7: 129
			}),
			e(ye, i, { 7: 130 }),
			{
				5: [1, 132],
				52: [1, 131]
			},
			{
				5: [1, 134],
				52: [1, 133]
			},
			e(Ce, _e, {
				74: 135,
				75: [1, 136]
			}),
			{
				5: [1, 138],
				52: [1, 137]
			},
			{
				5: [1, 140],
				52: [1, 139]
			},
			{ 5: [1, 141] },
			{
				23: 145,
				70: [1, 142],
				71: [1, 143],
				72: [1, 144],
				73: F
			},
			{
				69: 146,
				78: L,
				79: R,
				80: te,
				81: ne,
				82: z,
				83: B,
				84: V,
				85: re,
				86: H,
				87: U,
				88: W,
				89: ie,
				90: ae,
				91: oe,
				92: G,
				93: se,
				94: K,
				95: ce,
				96: le,
				97: ue,
				98: de,
				99: fe,
				100: pe,
				101: me,
				102: he,
				103: ge
			},
			e(q, [2, 79]),
			e(q, [2, 80]),
			e(q, [2, 81]),
			e(q, [2, 82]),
			e(q, [2, 83]),
			e(q, [2, 84]),
			e(q, [2, 85]),
			e(q, [2, 86]),
			e(q, [2, 87]),
			e(q, [2, 88]),
			e(q, [2, 89]),
			e(q, [2, 90]),
			e(q, [2, 91]),
			e(q, [2, 92]),
			e(q, [2, 93]),
			e(q, [2, 94]),
			e(q, [2, 95]),
			e(q, [2, 96]),
			e(q, [2, 97]),
			e(q, [2, 98]),
			e(q, [2, 99]),
			e(q, [2, 100]),
			e(q, [2, 101]),
			e(q, [2, 102]),
			e(q, [2, 103]),
			e(q, [2, 104]),
			{
				23: 147,
				73: F
			},
			{
				23: 149,
				60: 148,
				73: F
			},
			{ 73: [2, 68] },
			{ 73: [2, 69] },
			{
				58: 150,
				104: J
			},
			{
				58: 152,
				104: J
			},
			{
				58: 153,
				104: J
			},
			{
				58: 154,
				104: J
			},
			{
				4: [1, 157],
				5: [1, 159],
				12: 156,
				13: 158,
				17: [1, 155],
				51: D,
				53: O,
				54: k
			},
			{ 5: [1, 160] },
			e(I, [2, 20]),
			e(I, [2, 21]),
			e(I, [2, 23]),
			e(I, [2, 24]),
			{
				4: a,
				5: o,
				8: 8,
				9: 10,
				10: s,
				13: 13,
				14: c,
				15: l,
				17: [1, 161],
				18: 16,
				19: u,
				22: d,
				23: 41,
				24: f,
				25: 20,
				26: 21,
				27: 22,
				28: 23,
				29: 24,
				30: p,
				31: m,
				32: h,
				34: g,
				36: _,
				37: v,
				38: y,
				39: b,
				40: x,
				42: S,
				44: C,
				45: T,
				47: E,
				51: D,
				53: O,
				54: k,
				56: A,
				61: j,
				62: M,
				63: N,
				64: P,
				73: F
			},
			{
				4: a,
				5: o,
				8: 8,
				9: 10,
				10: s,
				13: 13,
				14: c,
				15: l,
				17: [1, 162],
				18: 16,
				19: u,
				22: d,
				23: 41,
				24: f,
				25: 20,
				26: 21,
				27: 22,
				28: 23,
				29: 24,
				30: p,
				31: m,
				32: h,
				34: g,
				36: _,
				37: v,
				38: y,
				39: b,
				40: x,
				42: S,
				44: C,
				45: T,
				47: E,
				51: D,
				53: O,
				54: k,
				56: A,
				61: j,
				62: M,
				63: N,
				64: P,
				73: F
			},
			{
				4: a,
				5: o,
				8: 8,
				9: 10,
				10: s,
				13: 13,
				14: c,
				15: l,
				17: [1, 163],
				18: 16,
				19: u,
				22: d,
				23: 41,
				24: f,
				25: 20,
				26: 21,
				27: 22,
				28: 23,
				29: 24,
				30: p,
				31: m,
				32: h,
				34: g,
				36: _,
				37: v,
				38: y,
				39: b,
				40: x,
				42: S,
				44: C,
				45: T,
				47: E,
				51: D,
				53: O,
				54: k,
				56: A,
				61: j,
				62: M,
				63: N,
				64: P,
				73: F
			},
			{ 17: [1, 164] },
			{
				4: a,
				5: o,
				8: 8,
				9: 10,
				10: s,
				13: 13,
				14: c,
				15: l,
				17: [2, 47],
				18: 16,
				19: u,
				22: d,
				23: 41,
				24: f,
				25: 20,
				26: 21,
				27: 22,
				28: 23,
				29: 24,
				30: p,
				31: m,
				32: h,
				34: g,
				36: _,
				37: v,
				38: y,
				39: b,
				40: x,
				42: S,
				44: C,
				45: T,
				47: E,
				50: [1, 165],
				51: D,
				53: O,
				54: k,
				56: A,
				61: j,
				62: M,
				63: N,
				64: P,
				73: F
			},
			{ 17: [1, 166] },
			{
				4: a,
				5: o,
				8: 8,
				9: 10,
				10: s,
				13: 13,
				14: c,
				15: l,
				17: [2, 45],
				18: 16,
				19: u,
				22: d,
				23: 41,
				24: f,
				25: 20,
				26: 21,
				27: 22,
				28: 23,
				29: 24,
				30: p,
				31: m,
				32: h,
				34: g,
				36: _,
				37: v,
				38: y,
				39: b,
				40: x,
				42: S,
				44: C,
				45: T,
				47: E,
				49: [1, 167],
				51: D,
				53: O,
				54: k,
				56: A,
				61: j,
				62: M,
				63: N,
				64: P,
				73: F
			},
			{ 17: [1, 168] },
			{ 17: [1, 169] },
			{
				4: a,
				5: o,
				8: 8,
				9: 10,
				10: s,
				13: 13,
				14: c,
				15: l,
				17: [2, 43],
				18: 16,
				19: u,
				22: d,
				23: 41,
				24: f,
				25: 20,
				26: 21,
				27: 22,
				28: 23,
				29: 24,
				30: p,
				31: m,
				32: h,
				34: g,
				36: _,
				37: v,
				38: y,
				39: b,
				40: x,
				42: S,
				44: C,
				45: T,
				47: E,
				48: [1, 170],
				51: D,
				53: O,
				54: k,
				56: A,
				61: j,
				62: M,
				63: N,
				64: P,
				73: F
			},
			{
				4: a,
				5: o,
				8: 8,
				9: 10,
				10: s,
				13: 13,
				14: c,
				15: l,
				17: [1, 171],
				18: 16,
				19: u,
				22: d,
				23: 41,
				24: f,
				25: 20,
				26: 21,
				27: 22,
				28: 23,
				29: 24,
				30: p,
				31: m,
				32: h,
				34: g,
				36: _,
				37: v,
				38: y,
				39: b,
				40: x,
				42: S,
				44: C,
				45: T,
				47: E,
				51: D,
				53: O,
				54: k,
				56: A,
				61: j,
				62: M,
				63: N,
				64: P,
				73: F
			},
			{ 16: [1, 172] },
			e(I, [2, 50]),
			{ 16: [1, 173] },
			e(I, [2, 55]),
			e(Ce, [2, 76]),
			{ 76: [1, 174] },
			{ 16: [1, 175] },
			e(I, [2, 52]),
			{ 16: [1, 176] },
			e(I, [2, 57]),
			e(I, [2, 53]),
			{
				23: 177,
				73: F
			},
			{
				23: 178,
				73: F
			},
			{
				23: 179,
				73: F
			},
			{
				58: 180,
				104: J
			},
			{
				23: 181,
				72: [1, 182],
				73: F
			},
			{
				58: 183,
				104: J
			},
			{
				58: 184,
				104: J
			},
			{
				66: [1, 185],
				104: [2, 67]
			},
			{ 5: [2, 60] },
			{ 5: [2, 105] },
			{ 5: [2, 61] },
			{ 5: [2, 62] },
			{ 5: [2, 63] },
			e(I, [2, 17]),
			e(ve, [2, 11]),
			{
				13: 186,
				51: D,
				53: O,
				54: k
			},
			e(ve, [2, 13]),
			e(ve, [2, 14]),
			e(I, [2, 19]),
			e(I, [2, 35]),
			e(I, [2, 36]),
			e(I, [2, 37]),
			e(I, [2, 38]),
			{ 16: [1, 187] },
			e(I, [2, 39]),
			{ 16: [1, 188] },
			e(I, [2, 40]),
			e(I, [2, 41]),
			{ 16: [1, 189] },
			e(I, [2, 42]),
			{ 5: [1, 190] },
			{ 5: [1, 191] },
			{ 77: [1, 192] },
			{ 5: [1, 193] },
			{ 5: [1, 194] },
			{
				58: 195,
				104: J
			},
			{
				58: 196,
				104: J
			},
			{
				58: 197,
				104: J
			},
			{ 5: [2, 75] },
			{
				58: 198,
				104: J
			},
			{
				23: 199,
				73: F
			},
			{ 5: [2, 58] },
			{ 5: [2, 59] },
			{
				23: 200,
				73: F
			},
			e(ve, [2, 12]),
			e(be, i, {
				7: 124,
				41: 201
			}),
			e(xe, i, {
				7: 126,
				43: 202
			}),
			e(Se, i, {
				7: 129,
				46: 203
			}),
			e(I, [2, 49]),
			e(I, [2, 54]),
			e(Ce, [2, 77]),
			e(I, [2, 51]),
			e(I, [2, 56]),
			{ 5: [2, 70] },
			{ 5: [2, 71] },
			{ 5: [2, 72] },
			{ 5: [2, 73] },
			{
				58: 204,
				104: J
			},
			{ 104: [2, 66] },
			{ 17: [2, 48] },
			{ 17: [2, 46] },
			{ 17: [2, 44] },
			{ 5: [2, 74] }
		],
		defaultActions: {
			5: [2, 1],
			6: [2, 2],
			108: [2, 68],
			109: [2, 69],
			150: [2, 60],
			151: [2, 105],
			152: [2, 61],
			153: [2, 62],
			154: [2, 63],
			180: [2, 75],
			183: [2, 58],
			184: [2, 59],
			195: [2, 70],
			196: [2, 71],
			197: [2, 72],
			198: [2, 73],
			200: [2, 66],
			201: [2, 48],
			202: [2, 46],
			203: [2, 44],
			204: [2, 74]
		},
		parseError: /* @__PURE__ */ w(function(e, t) {
			if (t.recoverable) this.trace(e);
			else {
				var n = Error(e);
				throw n.hash = t, n;
			}
		}, "parseError"),
		parse: /* @__PURE__ */ w(function(e) {
			var t = this, n = [0], r = [], i = [null], a = [], o = this.table, s = "", c = 0, l = 0, u = 2, d = 1, f = a.slice.call(arguments, 1), p = Object.create(this.lexer), m = { yy: {} };
			for (var h in this.yy) Object.prototype.hasOwnProperty.call(this.yy, h) && (m.yy[h] = this.yy[h]);
			p.setInput(e, m.yy), m.yy.lexer = p, m.yy.parser = this, typeof p.yylloc > "u" && (p.yylloc = {});
			var g = p.yylloc;
			a.push(g);
			var _ = p.options && p.options.ranges;
			this.parseError = typeof m.yy.parseError == "function" ? m.yy.parseError : Object.getPrototypeOf(this).parseError;
			function v(e) {
				n.length -= 2 * e, i.length -= e, a.length -= e;
			}
			w(v, "popStack");
			function y() {
				var e;
				return e = r.pop() || p.lex() || d, typeof e != "number" && (e instanceof Array && (r = e, e = r.pop()), e = t.symbols_[e] || e), e;
			}
			w(y, "lex");
			for (var b, x, S, C, T = {}, E, D, O, k;;) {
				if (x = n[n.length - 1], this.defaultActions[x] ? S = this.defaultActions[x] : ((b === null || typeof b > "u") && (b = y()), S = o[x] && o[x][b]), typeof S > "u" || !S.length || !S[0]) {
					var A = "";
					for (E in k = [], o[x]) this.terminals_[E] && E > u && k.push("'" + this.terminals_[E] + "'");
					A = p.showPosition ? "Parse error on line " + (c + 1) + ":\n" + p.showPosition() + "\nExpecting " + k.join(", ") + ", got '" + (this.terminals_[b] || b) + "'" : "Parse error on line " + (c + 1) + ": Unexpected " + (b == d ? "end of input" : "'" + (this.terminals_[b] || b) + "'"), this.parseError(A, {
						text: p.match,
						token: this.terminals_[b] || b,
						line: p.yylineno,
						loc: g,
						expected: k
					});
				}
				if (S[0] instanceof Array && S.length > 1) throw Error("Parse Error: multiple actions possible at state: " + x + ", token: " + b);
				switch (S[0]) {
					case 1:
						n.push(b), i.push(p.yytext), a.push(p.yylloc), n.push(S[1]), b = null, l = p.yyleng, s = p.yytext, c = p.yylineno, g = p.yylloc;
						break;
					case 2:
						if (D = this.productions_[S[1]][1], T.$ = i[i.length - D], T._$ = {
							first_line: a[a.length - (D || 1)].first_line,
							last_line: a[a.length - 1].last_line,
							first_column: a[a.length - (D || 1)].first_column,
							last_column: a[a.length - 1].last_column
						}, _ && (T._$.range = [a[a.length - (D || 1)].range[0], a[a.length - 1].range[1]]), C = this.performAction.apply(T, [
							s,
							l,
							c,
							m.yy,
							S[1],
							i,
							a
						].concat(f)), typeof C < "u") return C;
						D && (n = n.slice(0, -1 * D * 2), i = i.slice(0, -1 * D), a = a.slice(0, -1 * D)), n.push(this.productions_[S[1]][0]), i.push(T.$), a.push(T._$), O = o[n[n.length - 2]][n[n.length - 1]], n.push(O);
						break;
					case 3: return !0;
				}
			}
			return !0;
		}, "parse")
	};
	we.lexer = /* @__PURE__ */ function() {
		return {
			EOF: 1,
			parseError: /* @__PURE__ */ w(function(e, t) {
				if (this.yy.parser) this.yy.parser.parseError(e, t);
				else throw Error(e);
			}, "parseError"),
			setInput: /* @__PURE__ */ w(function(e, t) {
				return this.yy = t || this.yy || {}, this._input = e, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
					first_line: 1,
					first_column: 0,
					last_line: 1,
					last_column: 0
				}, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
			}, "setInput"),
			input: /* @__PURE__ */ w(function() {
				var e = this._input[0];
				return this.yytext += e, this.yyleng++, this.offset++, this.match += e, this.matched += e, e.match(/(?:\r\n?|\n).*/g) ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), e;
			}, "input"),
			unput: /* @__PURE__ */ w(function(e) {
				var t = e.length, n = e.split(/(?:\r\n?|\n)/g);
				this._input = e + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - t), this.offset -= t;
				var r = this.match.split(/(?:\r\n?|\n)/g);
				this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), n.length - 1 && (this.yylineno -= n.length - 1);
				var i = this.yylloc.range;
				return this.yylloc = {
					first_line: this.yylloc.first_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.first_column,
					last_column: n ? (n.length === r.length ? this.yylloc.first_column : 0) + r[r.length - n.length].length - n[0].length : this.yylloc.first_column - t
				}, this.options.ranges && (this.yylloc.range = [i[0], i[0] + this.yyleng - t]), this.yyleng = this.yytext.length, this;
			}, "unput"),
			more: /* @__PURE__ */ w(function() {
				return this._more = !0, this;
			}, "more"),
			reject: /* @__PURE__ */ w(function() {
				if (this.options.backtrack_lexer) this._backtrack = !0;
				else return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
				return this;
			}, "reject"),
			less: /* @__PURE__ */ w(function(e) {
				this.unput(this.match.slice(e));
			}, "less"),
			pastInput: /* @__PURE__ */ w(function() {
				var e = this.matched.substr(0, this.matched.length - this.match.length);
				return (e.length > 20 ? "..." : "") + e.substr(-20).replace(/\n/g, "");
			}, "pastInput"),
			upcomingInput: /* @__PURE__ */ w(function() {
				var e = this.match;
				return e.length < 20 && (e += this._input.substr(0, 20 - e.length)), (e.substr(0, 20) + (e.length > 20 ? "..." : "")).replace(/\n/g, "");
			}, "upcomingInput"),
			showPosition: /* @__PURE__ */ w(function() {
				var e = this.pastInput(), t = Array(e.length + 1).join("-");
				return e + this.upcomingInput() + "\n" + t + "^";
			}, "showPosition"),
			test_match: /* @__PURE__ */ w(function(e, t) {
				var n, r, i;
				if (this.options.backtrack_lexer && (i = {
					yylineno: this.yylineno,
					yylloc: {
						first_line: this.yylloc.first_line,
						last_line: this.last_line,
						first_column: this.yylloc.first_column,
						last_column: this.yylloc.last_column
					},
					yytext: this.yytext,
					match: this.match,
					matches: this.matches,
					matched: this.matched,
					yyleng: this.yyleng,
					offset: this.offset,
					_more: this._more,
					_input: this._input,
					yy: this.yy,
					conditionStack: this.conditionStack.slice(0),
					done: this.done
				}, this.options.ranges && (i.yylloc.range = this.yylloc.range.slice(0))), r = e[0].match(/(?:\r\n?|\n).*/g), r && (this.yylineno += r.length), this.yylloc = {
					first_line: this.yylloc.last_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.last_column,
					last_column: r ? r[r.length - 1].length - r[r.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + e[0].length
				}, this.yytext += e[0], this.match += e[0], this.matches = e, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(e[0].length), this.matched += e[0], n = this.performAction.call(this, this.yy, this, t, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), n) return n;
				if (this._backtrack) {
					for (var a in i) this[a] = i[a];
					return !1;
				}
				return !1;
			}, "test_match"),
			next: /* @__PURE__ */ w(function() {
				if (this.done) return this.EOF;
				this._input || (this.done = !0);
				var e, t, n, r;
				this._more || (this.yytext = "", this.match = "");
				for (var i = this._currentRules(), a = 0; a < i.length; a++) if (n = this._input.match(this.rules[i[a]]), n && (!t || n[0].length > t[0].length)) {
					if (t = n, r = a, this.options.backtrack_lexer) {
						if (e = this.test_match(n, i[a]), e !== !1) return e;
						if (this._backtrack) {
							t = !1;
							continue;
						}
						return !1;
					}
					if (!this.options.flex) break;
				}
				return t ? (e = this.test_match(t, i[r]), e !== !1 && e) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
			}, "next"),
			lex: /* @__PURE__ */ w(function() {
				return this.next() || this.lex();
			}, "lex"),
			begin: /* @__PURE__ */ w(function(e) {
				this.conditionStack.push(e);
			}, "begin"),
			popState: /* @__PURE__ */ w(function() {
				return this.conditionStack.length - 1 > 0 ? this.conditionStack.pop() : this.conditionStack[0];
			}, "popState"),
			_currentRules: /* @__PURE__ */ w(function() {
				return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
			}, "_currentRules"),
			topState: /* @__PURE__ */ w(function(e) {
				return e = this.conditionStack.length - 1 - Math.abs(e || 0), e >= 0 ? this.conditionStack[e] : "INITIAL";
			}, "topState"),
			pushState: /* @__PURE__ */ w(function(e) {
				this.begin(e);
			}, "pushState"),
			stateStackSize: /* @__PURE__ */ w(function() {
				return this.conditionStack.length;
			}, "stateStackSize"),
			options: { "case-insensitive": !0 },
			performAction: /* @__PURE__ */ w(function(e, t, n, r) {
				switch (n) {
					case 0: return 5;
					case 1: break;
					case 2: break;
					case 3: break;
					case 4: break;
					case 5: break;
					case 6: return 20;
					case 7: return this.begin("CONFIG"), 75;
					case 8: return 76;
					case 9: return this.popState(), this.begin("ALIAS"), 77;
					case 10: return this.popState(), this.popState(), 77;
					case 11: return t.yytext = t.yytext.trim(), 73;
					case 12: return t.yytext = t.yytext.trim(), this.begin("ALIAS"), 73;
					case 13: return t.yytext = t.yytext.trim(), this.popState(), 73;
					case 14: return this.popState(), 10;
					case 15: return t.yytext = t.yytext.trim(), this.popState(), 10;
					case 16: return this.begin("LINE"), 15;
					case 17: return this.begin("ID"), 51;
					case 18: return this.begin("ID"), 53;
					case 19: return 14;
					case 20: return this.begin("ID"), 54;
					case 21: return this.popState(), this.popState(), this.begin("LINE"), 52;
					case 22: return this.popState(), this.popState(), 5;
					case 23: return this.begin("LINE"), 37;
					case 24: return this.begin("LINE"), 38;
					case 25: return this.begin("LINE"), 39;
					case 26: return this.begin("LINE"), 40;
					case 27: return this.begin("LINE"), 50;
					case 28: return this.begin("LINE"), 42;
					case 29: return this.begin("LINE"), 44;
					case 30: return this.begin("LINE"), 49;
					case 31: return this.begin("LINE"), 45;
					case 32: return this.begin("LINE"), 48;
					case 33: return this.begin("LINE"), 47;
					case 34: return this.popState(), 16;
					case 35: return 17;
					case 36: return 67;
					case 37: return 68;
					case 38: return 61;
					case 39: return 62;
					case 40: return 63;
					case 41: return 64;
					case 42: return 59;
					case 43: return 56;
					case 44: return this.begin("ID"), 22;
					case 45: return this.begin("ID"), 24;
					case 46: return 30;
					case 47: return 31;
					case 48: return this.begin("acc_title"), 32;
					case 49: return this.popState(), "acc_title_value";
					case 50: return this.begin("acc_descr"), 34;
					case 51: return this.popState(), "acc_descr_value";
					case 52:
						this.begin("acc_descr_multiline");
						break;
					case 53:
						this.popState();
						break;
					case 54: return "acc_descr_multiline_value";
					case 55: return 6;
					case 56: return 19;
					case 57: return 21;
					case 58: return 66;
					case 59: return 5;
					case 60: return t.yytext = t.yytext.trim(), 73;
					case 61: return 80;
					case 62: return 97;
					case 63: return 98;
					case 64: return 99;
					case 65: return 78;
					case 66: return 79;
					case 67: return 100;
					case 68: return 101;
					case 69: return 102;
					case 70: return 103;
					case 71: return 85;
					case 72: return 86;
					case 73: return 87;
					case 74: return 88;
					case 75: return 93;
					case 76: return 94;
					case 77: return 95;
					case 78: return 96;
					case 79: return 81;
					case 80: return 82;
					case 81: return 83;
					case 82: return 84;
					case 83: return 89;
					case 84: return 90;
					case 85: return 91;
					case 86: return 92;
					case 87: return 104;
					case 88: return 104;
					case 89: return 70;
					case 90: return 71;
					case 91: return 72;
					case 92: return 5;
					case 93: return 10;
				}
			}, "anonymous"),
			rules: [
				/^(?:[\n]+)/i,
				/^(?:\s+)/i,
				/^(?:((?!\n)\s)+)/i,
				/^(?:#[^\n]*)/i,
				/^(?:%(?!\{)[^\n]*)/i,
				/^(?:[^\}]%%[^\n]*)/i,
				/^(?:([0-9]+(\.[0-9]{1,2})?|\.[0-9]{1,2})(?=[ \n]+))/i,
				/^(?:@\{)/i,
				/^(?:[^\}]+)/i,
				/^(?:\}(?=\s+as\s))/i,
				/^(?:\})/i,
				/^(?:[^\<->\->:\n,;@\s]+(?=@\{))/i,
				/^(?:[^<>:\n,;@\s]+(?=\s+as\s))/i,
				/^(?:[^<>:\n,;@]+(?=\s*[\n;#]|$))/i,
				/^(?:[^<>:\n,;@]*<[^\n]*)/i,
				/^(?:[^\n]+)/i,
				/^(?:box\b)/i,
				/^(?:participant\b)/i,
				/^(?:actor\b)/i,
				/^(?:create\b)/i,
				/^(?:destroy\b)/i,
				/^(?:as\b)/i,
				/^(?:(?:))/i,
				/^(?:loop\b)/i,
				/^(?:rect\b)/i,
				/^(?:opt\b)/i,
				/^(?:alt\b)/i,
				/^(?:else\b)/i,
				/^(?:par\b)/i,
				/^(?:par_over\b)/i,
				/^(?:and\b)/i,
				/^(?:critical\b)/i,
				/^(?:option\b)/i,
				/^(?:break\b)/i,
				/^(?:(?:[:]?(?:no)?wrap)?[^#\n;]*)/i,
				/^(?:end\b)/i,
				/^(?:left of\b)/i,
				/^(?:right of\b)/i,
				/^(?:links\b)/i,
				/^(?:link\b)/i,
				/^(?:properties\b)/i,
				/^(?:details\b)/i,
				/^(?:over\b)/i,
				/^(?:note\b)/i,
				/^(?:activate\b)/i,
				/^(?:deactivate\b)/i,
				/^(?:title\s[^#\n;]+)/i,
				/^(?:title:\s[^#\n;]+)/i,
				/^(?:accTitle\s*:\s*)/i,
				/^(?:(?!\n||)*[^\n]*)/i,
				/^(?:accDescr\s*:\s*)/i,
				/^(?:(?!\n||)*[^\n]*)/i,
				/^(?:accDescr\s*\{\s*)/i,
				/^(?:[\}])/i,
				/^(?:[^\}]*)/i,
				/^(?:sequenceDiagram\b)/i,
				/^(?:autonumber\b)/i,
				/^(?:off\b)/i,
				/^(?:,)/i,
				/^(?:;)/i,
				/^(?:[^\/\\\+\()\+<\->\->:\n,;]+((?!(-x|--x|-\)|--\)|-\|\\|-\\|-\/|-\/\/|-\|\/|\/\|-|\\\|-|\/\/-|\\\\-|\/\|-|--\|\\|--|\(\)))[\-]*[^\+<\->\->:\n,;]+)*)/i,
				/^(?:->>)/i,
				/^(?:<<->>)/i,
				/^(?:-->>)/i,
				/^(?:<<-->>)/i,
				/^(?:->)/i,
				/^(?:-->)/i,
				/^(?:-[x])/i,
				/^(?:--[x])/i,
				/^(?:-[\)])/i,
				/^(?:--[\)])/i,
				/^(?:--\|\\)/i,
				/^(?:--\|\/)/i,
				/^(?:--\\\\)/i,
				/^(?:--\/\/)/i,
				/^(?:\/\|--)/i,
				/^(?:\\\|--)/i,
				/^(?:\/\/--)/i,
				/^(?:\\\\--)/i,
				/^(?:-\|\\)/i,
				/^(?:-\|\/)/i,
				/^(?:-\\\\)/i,
				/^(?:-\/\/)/i,
				/^(?:\/\|-)/i,
				/^(?:\\\|-)/i,
				/^(?:\/\/-)/i,
				/^(?:\\\\-)/i,
				/^(?::(?:(?:no)?wrap)?[^#\n;]*)/i,
				/^(?::)/i,
				/^(?:\+)/i,
				/^(?:-)/i,
				/^(?:\(\))/i,
				/^(?:$)/i,
				/^(?:.)/i
			],
			conditions: {
				acc_descr_multiline: {
					rules: [53, 54],
					inclusive: !1
				},
				acc_descr: {
					rules: [51],
					inclusive: !1
				},
				acc_title: {
					rules: [49],
					inclusive: !1
				},
				ID: {
					rules: [
						2,
						3,
						7,
						11,
						12,
						13,
						14,
						15
					],
					inclusive: !1
				},
				ALIAS: {
					rules: [
						2,
						3,
						21,
						22
					],
					inclusive: !1
				},
				LINE: {
					rules: [
						2,
						3,
						34
					],
					inclusive: !1
				},
				CONFIG: {
					rules: [
						8,
						9,
						10
					],
					inclusive: !1
				},
				CONFIG_DATA: {
					rules: [],
					inclusive: !1
				},
				INITIAL: {
					rules: [
						0,
						1,
						3,
						4,
						5,
						6,
						16,
						17,
						18,
						19,
						20,
						23,
						24,
						25,
						26,
						27,
						28,
						29,
						30,
						31,
						32,
						33,
						35,
						36,
						37,
						38,
						39,
						40,
						41,
						42,
						43,
						44,
						45,
						46,
						47,
						48,
						50,
						52,
						55,
						56,
						57,
						58,
						59,
						60,
						61,
						62,
						63,
						64,
						65,
						66,
						67,
						68,
						69,
						70,
						71,
						72,
						73,
						74,
						75,
						76,
						77,
						78,
						79,
						80,
						81,
						82,
						83,
						84,
						85,
						86,
						87,
						88,
						89,
						90,
						91,
						92,
						93
					],
					inclusive: !0
				}
			}
		};
	}();
	function Te() {
		this.yy = {};
	}
	return w(Te, "Parser"), Te.prototype = we, we.Parser = Te, new Te();
}();
N.parser = N;
var P = N, F = {
	SOLID: 0,
	DOTTED: 1,
	NOTE: 2,
	SOLID_CROSS: 3,
	DOTTED_CROSS: 4,
	SOLID_OPEN: 5,
	DOTTED_OPEN: 6,
	LOOP_START: 10,
	LOOP_END: 11,
	ALT_START: 12,
	ALT_ELSE: 13,
	ALT_END: 14,
	OPT_START: 15,
	OPT_END: 16,
	ACTIVE_START: 17,
	ACTIVE_END: 18,
	PAR_START: 19,
	PAR_AND: 20,
	PAR_END: 21,
	RECT_START: 22,
	RECT_END: 23,
	SOLID_POINT: 24,
	DOTTED_POINT: 25,
	AUTONUMBER: 26,
	CRITICAL_START: 27,
	CRITICAL_OPTION: 28,
	CRITICAL_END: 29,
	BREAK_START: 30,
	BREAK_END: 31,
	PAR_OVER_START: 32,
	BIDIRECTIONAL_SOLID: 33,
	BIDIRECTIONAL_DOTTED: 34,
	SOLID_TOP: 41,
	SOLID_BOTTOM: 42,
	STICK_TOP: 43,
	STICK_BOTTOM: 44,
	SOLID_ARROW_TOP_REVERSE: 45,
	SOLID_ARROW_BOTTOM_REVERSE: 46,
	STICK_ARROW_TOP_REVERSE: 47,
	STICK_ARROW_BOTTOM_REVERSE: 48,
	SOLID_TOP_DOTTED: 51,
	SOLID_BOTTOM_DOTTED: 52,
	STICK_TOP_DOTTED: 53,
	STICK_BOTTOM_DOTTED: 54,
	SOLID_ARROW_TOP_REVERSE_DOTTED: 55,
	SOLID_ARROW_BOTTOM_REVERSE_DOTTED: 56,
	STICK_ARROW_TOP_REVERSE_DOTTED: 57,
	STICK_ARROW_BOTTOM_REVERSE_DOTTED: 58,
	CENTRAL_CONNECTION: 59,
	CENTRAL_CONNECTION_REVERSE: 60,
	CENTRAL_CONNECTION_DUAL: 61
}, I = {
	FILLED: 0,
	OPEN: 1
}, ee = {
	LEFTOF: 0,
	RIGHTOF: 1,
	OVER: 2
}, L = {
	ACTOR: "actor",
	CONTROL: "control",
	DATABASE: "database",
	ENTITY: "entity"
}, R, te = (R = class {
	constructor() {
		this.state = new M(() => ({
			prevActor: void 0,
			actors: /* @__PURE__ */ new Map(),
			createdActors: /* @__PURE__ */ new Map(),
			destroyedActors: /* @__PURE__ */ new Map(),
			boxes: [],
			messages: [],
			notes: [],
			sequenceNumbersEnabled: !1,
			wrapEnabled: void 0,
			currentBox: void 0,
			lastCreated: void 0,
			lastDestroyed: void 0
		})), this.setAccTitle = C, this.setAccDescription = S, this.setDiagramTitle = _, this.getAccTitle = l, this.getAccDescription = c, this.getDiagramTitle = f, this.apply = this.apply.bind(this), this.parseBoxData = this.parseBoxData.bind(this), this.parseMessage = this.parseMessage.bind(this), this.clear(), this.setWrap(d().wrap), this.LINETYPE = F, this.ARROWTYPE = I, this.PLACEMENT = ee;
	}
	addBox(e) {
		this.state.records.boxes.push({
			name: e.text,
			wrap: e.wrap ?? this.autoWrap(),
			fill: e.color,
			actorKeys: []
		}), this.state.records.currentBox = this.state.records.boxes.slice(-1)[0];
	}
	addActor(e, t, r, i, a) {
		let o = this.state.records.currentBox, s;
		if (a !== void 0) {
			let e;
			e = a.includes("\n") ? a + "\n" : "{\n" + a + "\n}", s = m(e, { schema: n });
		}
		i = s?.type ?? i, s?.alias && (!r || r.text === t) && (r = {
			text: s.alias,
			wrap: r?.wrap,
			type: i
		});
		let c = this.state.records.actors.get(e);
		if (c) {
			if (this.state.records.currentBox && c.box && this.state.records.currentBox !== c.box) throw Error(`A same participant should only be defined in one Box: ${c.name} can't be in '${c.box.name}' and in '${this.state.records.currentBox.name}' at the same time.`);
			if (o = c.box ? c.box : this.state.records.currentBox, c.box = o, c && t === c.name && r == null) return;
		}
		if (r?.text ?? (r = {
			text: t,
			type: i
		}), (i == null || r.text == null) && (r = {
			text: t,
			type: i
		}), this.state.records.actors.set(e, {
			box: o,
			name: t,
			description: r.text,
			wrap: r.wrap ?? this.autoWrap(),
			prevActor: this.state.records.prevActor,
			links: {},
			properties: {},
			actorCnt: null,
			rectData: null,
			type: i ?? "participant"
		}), this.state.records.prevActor) {
			let t = this.state.records.actors.get(this.state.records.prevActor);
			t && (t.nextActor = e);
		}
		this.state.records.currentBox && this.state.records.currentBox.actorKeys.push(e), this.state.records.prevActor = e;
	}
	activationCount(e) {
		let t, n = 0;
		if (!e) return 0;
		for (t = 0; t < this.state.records.messages.length; t++) this.state.records.messages[t].type === this.LINETYPE.ACTIVE_START && this.state.records.messages[t].from === e && n++, this.state.records.messages[t].type === this.LINETYPE.ACTIVE_END && this.state.records.messages[t].from === e && n--;
		return n;
	}
	addMessage(e, t, n, r) {
		this.state.records.messages.push({
			id: this.state.records.messages.length.toString(),
			from: e,
			to: t,
			message: n.text,
			wrap: n.wrap ?? this.autoWrap(),
			answer: r
		});
	}
	addSignal(e, t, n, r, i = !1, a) {
		if (r === this.LINETYPE.ACTIVE_END && this.activationCount(e ?? "") < 1) {
			let t = /* @__PURE__ */ Error("Trying to inactivate an inactive participant (" + e + ")");
			throw t.hash = {
				text: "->>-",
				token: "->>-",
				line: "1",
				loc: {
					first_line: 1,
					last_line: 1,
					first_column: 1,
					last_column: 1
				},
				expected: ["'ACTIVE_PARTICIPANT'"]
			}, t;
		}
		return this.state.records.messages.push({
			id: this.state.records.messages.length.toString(),
			from: e,
			to: t,
			message: n?.text ?? "",
			wrap: n?.wrap ?? this.autoWrap(),
			type: r,
			activate: i,
			centralConnection: a ?? 0
		}), !0;
	}
	hasAtLeastOneBox() {
		return this.state.records.boxes.length > 0;
	}
	hasAtLeastOneBoxWithTitle() {
		return this.state.records.boxes.some((e) => e.name);
	}
	getMessages() {
		return this.state.records.messages;
	}
	getBoxes() {
		return this.state.records.boxes;
	}
	getActors() {
		return this.state.records.actors;
	}
	getCreatedActors() {
		return this.state.records.createdActors;
	}
	getDestroyedActors() {
		return this.state.records.destroyedActors;
	}
	getActor(e) {
		return this.state.records.actors.get(e);
	}
	getActorKeys() {
		return [...this.state.records.actors.keys()];
	}
	enableSequenceNumbers() {
		this.state.records.sequenceNumbersEnabled = !0;
	}
	disableSequenceNumbers() {
		this.state.records.sequenceNumbersEnabled = !1;
	}
	showSequenceNumbers() {
		return this.state.records.sequenceNumbersEnabled;
	}
	setWrap(e) {
		this.state.records.wrapEnabled = e;
	}
	extractWrap(e) {
		if (e === void 0) return {};
		e = e.trim();
		let t = /^:?wrap:/.exec(e) !== null || /^:?nowrap:/.exec(e) === null && void 0;
		return {
			cleanedText: (t === void 0 ? e : e.replace(/^:?(?:no)?wrap:/, "")).trim(),
			wrap: t
		};
	}
	autoWrap() {
		return this.state.records.wrapEnabled === void 0 ? d().sequence?.wrap ?? !1 : this.state.records.wrapEnabled;
	}
	clear() {
		this.state.reset(), r();
	}
	parseMessage(e) {
		let t = e.trim(), { wrap: n, cleanedText: r } = this.extractWrap(t), i = {
			text: r,
			wrap: n
		};
		return h.debug(`parseMessage: ${JSON.stringify(i)}`), i;
	}
	parseBoxData(e) {
		let t = /^((?:rgba?|hsla?)\s*\(.*\)|\w*)(.*)$/.exec(e), n = t?.[1] ? t[1].trim() : "transparent", r = t?.[2] ? t[2].trim() : void 0;
		if (window?.CSS) window.CSS.supports("color", n) || (n = "transparent", r = e.trim());
		else {
			let t = new Option().style;
			t.color = n, t.color !== n && (n = "transparent", r = e.trim());
		}
		let { wrap: i, cleanedText: a } = this.extractWrap(r);
		return {
			text: a ? x(a, d()) : void 0,
			color: n,
			wrap: i
		};
	}
	addNote(e, t, n) {
		let r = {
			actor: e,
			placement: t,
			message: n.text,
			wrap: n.wrap ?? this.autoWrap()
		}, i = [].concat(e, e);
		this.state.records.notes.push(r), this.state.records.messages.push({
			id: this.state.records.messages.length.toString(),
			from: i[0],
			to: i[1],
			message: n.text,
			wrap: n.wrap ?? this.autoWrap(),
			type: this.LINETYPE.NOTE,
			placement: t
		});
	}
	addLinks(e, t) {
		let n = this.getActor(e);
		try {
			let e = x(t.text, d());
			e = e.replace(/&equals;/g, "="), e = e.replace(/&amp;/g, "&");
			let r = JSON.parse(e);
			this.insertLinks(n, r);
		} catch (e) {
			h.error("error while parsing actor link text", e);
		}
	}
	addALink(e, t) {
		let n = this.getActor(e);
		try {
			let e = {}, r = x(t.text, d()), i = r.indexOf("@");
			r = r.replace(/&equals;/g, "="), r = r.replace(/&amp;/g, "&");
			let a = r.slice(0, i - 1).trim();
			e[a] = r.slice(i + 1).trim(), this.insertLinks(n, e);
		} catch (e) {
			h.error("error while parsing actor link text", e);
		}
	}
	insertLinks(e, t) {
		if (e.links == null) e.links = t;
		else for (let n in t) e.links[n] = t[n];
	}
	addProperties(e, t) {
		let n = this.getActor(e);
		try {
			let e = x(t.text, d()), r = JSON.parse(e);
			this.insertProperties(n, r);
		} catch (e) {
			h.error("error while parsing actor properties text", e);
		}
	}
	insertProperties(e, t) {
		if (e.properties == null) e.properties = t;
		else for (let n in t) e.properties[n] = t[n];
	}
	boxEnd() {
		this.state.records.currentBox = void 0;
	}
	addDetails(e, t) {
		let n = this.getActor(e), r = document.getElementById(t.text);
		try {
			let e = r.innerHTML, t = JSON.parse(e);
			t.properties && this.insertProperties(n, t.properties), t.links && this.insertLinks(n, t.links);
		} catch (e) {
			h.error("error while parsing actor details text", e);
		}
	}
	getActorProperty(e, t) {
		if (e?.properties !== void 0) return e.properties[t];
	}
	apply(e) {
		if (Array.isArray(e)) e.forEach((e) => {
			this.apply(e);
		});
		else switch (e.type) {
			case "sequenceIndex":
				this.state.records.messages.push({
					id: this.state.records.messages.length.toString(),
					from: void 0,
					to: void 0,
					message: {
						start: e.sequenceIndex,
						step: e.sequenceIndexStep,
						visible: e.sequenceVisible
					},
					wrap: !1,
					type: e.signalType
				});
				break;
			case "addParticipant":
				this.addActor(e.actor, e.actor, e.description, e.draw, e.config);
				break;
			case "createParticipant":
				if (this.state.records.actors.has(e.actor)) throw Error("It is not possible to have actors with the same id, even if one is destroyed before the next is created. Use 'AS' aliases to simulate the behavior");
				this.state.records.lastCreated = e.actor, this.addActor(e.actor, e.actor, e.description, e.draw, e.config), this.state.records.createdActors.set(e.actor, this.state.records.messages.length);
				break;
			case "destroyParticipant":
				this.state.records.lastDestroyed = e.actor, this.state.records.destroyedActors.set(e.actor, this.state.records.messages.length);
				break;
			case "activeStart":
				this.addSignal(e.actor, void 0, void 0, e.signalType);
				break;
			case "centralConnection":
				this.addSignal(e.actor, void 0, void 0, e.signalType);
				break;
			case "centralConnectionReverse":
				this.addSignal(e.actor, void 0, void 0, e.signalType);
				break;
			case "activeEnd":
				this.addSignal(e.actor, void 0, void 0, e.signalType);
				break;
			case "addNote":
				this.addNote(e.actor, e.placement, e.text);
				break;
			case "addLinks":
				this.addLinks(e.actor, e.text);
				break;
			case "addALink":
				this.addALink(e.actor, e.text);
				break;
			case "addProperties":
				this.addProperties(e.actor, e.text);
				break;
			case "addDetails":
				this.addDetails(e.actor, e.text);
				break;
			case "addMessage":
				if (this.state.records.lastCreated) {
					if (e.to !== this.state.records.lastCreated) throw Error("The created participant " + this.state.records.lastCreated.name + " does not have an associated creating message after its declaration. Please check the sequence diagram.");
					this.state.records.lastCreated = void 0;
				} else if (this.state.records.lastDestroyed) {
					if (e.to !== this.state.records.lastDestroyed && e.from !== this.state.records.lastDestroyed) throw Error("The destroyed participant " + this.state.records.lastDestroyed.name + " does not have an associated destroying message after its declaration. Please check the sequence diagram.");
					this.state.records.lastDestroyed = void 0;
				}
				this.addSignal(e.from, e.to, e.msg, e.signalType, e.activate, e.centralConnection);
				break;
			case "boxStart":
				this.addBox(e.boxData);
				break;
			case "boxEnd":
				this.boxEnd();
				break;
			case "loopStart":
				this.addSignal(void 0, void 0, e.loopText, e.signalType);
				break;
			case "loopEnd":
				this.addSignal(void 0, void 0, void 0, e.signalType);
				break;
			case "rectStart":
				this.addSignal(void 0, void 0, e.color, e.signalType);
				break;
			case "rectEnd":
				this.addSignal(void 0, void 0, void 0, e.signalType);
				break;
			case "optStart":
				this.addSignal(void 0, void 0, e.optText, e.signalType);
				break;
			case "optEnd":
				this.addSignal(void 0, void 0, void 0, e.signalType);
				break;
			case "altStart":
				this.addSignal(void 0, void 0, e.altText, e.signalType);
				break;
			case "else":
				this.addSignal(void 0, void 0, e.altText, e.signalType);
				break;
			case "altEnd":
				this.addSignal(void 0, void 0, void 0, e.signalType);
				break;
			case "setAccTitle":
				C(e.text);
				break;
			case "parStart":
				this.addSignal(void 0, void 0, e.parText, e.signalType);
				break;
			case "and":
				this.addSignal(void 0, void 0, e.parText, e.signalType);
				break;
			case "parEnd":
				this.addSignal(void 0, void 0, void 0, e.signalType);
				break;
			case "criticalStart":
				this.addSignal(void 0, void 0, e.criticalText, e.signalType);
				break;
			case "option":
				this.addSignal(void 0, void 0, e.optionText, e.signalType);
				break;
			case "criticalEnd":
				this.addSignal(void 0, void 0, void 0, e.signalType);
				break;
			case "breakStart":
				this.addSignal(void 0, void 0, e.breakText, e.signalType);
				break;
			case "breakEnd": this.addSignal(void 0, void 0, void 0, e.signalType);
		}
	}
	getConfig() {
		return d().sequence;
	}
}, w(R, "SequenceDB"), R), ne = /* @__PURE__ */ w((e) => {
	let t = e.dropShadow ?? "none", { look: n } = d();
	return `.actor {
    stroke: ${e.actorBorder};
    fill: ${e.actorBkg};
    stroke-width: ${e.strokeWidth ?? 1};
  }

  rect.actor.outer-path[data-look="neo"] {
      filter: ${t};
  }

  rect.note[data-look="neo"] {
      stroke:${e.noteBorderColor};
      fill:${e.noteBkgColor};
      filter: ${t};
  }

  text.actor > tspan {
    fill: ${e.actorTextColor};
    stroke: none;
  }

  .actor-line {
    stroke: ${e.actorLineColor};
  }

  .innerArc {
    stroke-width: 1.5;
    stroke-dasharray: none;
  }

  .messageLine0 {
    stroke-width: 1.5;
    stroke-dasharray: none;
    stroke: ${e.signalColor};
  }

  .messageLine1 {
    stroke-width: 1.5;
    stroke-dasharray: 2, 2;
    stroke: ${e.signalColor};
  }

  [id$="-arrowhead"] path {
    fill: ${e.signalColor};
    stroke: ${e.signalColor};
  }

  .sequenceNumber {
    fill: ${e.sequenceNumberColor};
  }

  [id$="-sequencenumber"] {
    fill: ${e.signalColor};
  }

  [id$="-crosshead"] path {
    fill: ${e.signalColor};
    stroke: ${e.signalColor};
  }

  .messageText {
    fill: ${e.signalTextColor};
    stroke: none;
  }

  .labelBox {
    stroke: ${e.labelBoxBorderColor};
    fill: ${e.labelBoxBkgColor};
    filter: ${n === "neo" ? t : "none"};
  }

  .labelText, .labelText > tspan {
    fill: ${e.labelTextColor};
    stroke: none;
  }

  .loopText, .loopText > tspan {
    fill: ${e.loopTextColor};
    stroke: none;
  }

  .sectionTitle, .sectionTitle > tspan {
    fill: ${e.loopTextColor};
    stroke: none;
  }

  .loopLine {
    stroke-width: 2px;
    stroke-dasharray: 2, 2;
    stroke: ${e.labelBoxBorderColor};
    fill: ${e.labelBoxBorderColor};
  }

  .note {
    //stroke: #decc93;
    stroke: ${e.noteBorderColor};
    fill: ${e.noteBkgColor};
  }

  .noteText, .noteText > tspan {
    fill: ${e.noteTextColor};
    stroke: none;
    ${e.noteFontWeight ? `font-weight: ${e.noteFontWeight};` : ""}
  }

  .activation0 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .activation1 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .activation2 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .actorPopupMenu {
    position: absolute;
  }

  .actorPopupMenuPanel {
    position: absolute;
    fill: ${e.actorBkg};
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    filter: drop-shadow(3px 5px 2px rgb(0 0 0 / 0.4));
}
  .actor-man circle, line {
    fill: ${e.actorBkg};
    stroke-width: 2px;
  }

  g rect.rect {
    filter: ${t};
    stroke: ${e.nodeBorder};
  }
`;
}, "getStyles"), z = 36, B = "actor-top", V = "actor-bottom", re = "actor-box", H = "actor-man", U = /* @__PURE__ */ new Set(["redux-color", "redux-dark-color"]), W = /* @__PURE__ */ w(function(e, t) {
	let n = A(e, t);
	return u().look === "neo" && n.attr("data-look", "neo"), n;
}, "drawRect"), ie = /* @__PURE__ */ w(function(e, t, n, r, i) {
	if (t.links === void 0 || t.links === null || Object.keys(t.links).length === 0) return {
		height: 0,
		width: 0
	};
	let a = t.links, s = t.actorCnt, c = t.rectData;
	var l = "none";
	i && (l = "block !important");
	let u = e.append("g");
	u.attr("id", "actor" + s + "_popup"), u.attr("class", "actorPopupMenu"), u.attr("display", l);
	var d = "";
	c.class !== void 0 && (d = " " + c.class);
	let f = c.width > n ? c.width : n, p = u.append("rect");
	if (p.attr("class", "actorPopupMenuPanel" + d), p.attr("x", c.x), p.attr("y", c.height), p.attr("fill", c.fill), p.attr("stroke", c.stroke), p.attr("width", f), p.attr("height", c.height), p.attr("rx", c.rx), p.attr("ry", c.ry), a != null) {
		var m = 20;
		for (let e in a) {
			var h = u.append("a"), g = o.sanitizeUrl(a[e]);
			h.attr("xlink:href", g), h.attr("target", "_blank"), je(r)(e, h, c.x + 10, c.height + m, f, 20, { class: "actor" }, r), m += 30;
		}
	}
	return p.attr("height", m), {
		height: c.height + m,
		width: f
	};
}, "drawPopup"), ae = /* @__PURE__ */ w(function(e) {
	return "var pu = document.getElementById('" + e + "'); if (pu != null) { pu.style.display = pu.style.display == 'block' ? 'none' : 'block'; }";
}, "popupMenuToggle"), oe = /* @__PURE__ */ w(async function(e, t, n = null) {
	let r = e.append("foreignObject"), i = await b(t.text, u()), a = r.append("xhtml:div").attr("style", "width: fit-content;").attr("xmlns", "http://www.w3.org/1999/xhtml").html(i).node().getBoundingClientRect();
	if (r.attr("height", Math.round(a.height)).attr("width", Math.round(a.width)), t.class === "noteText") {
		let n = e.node().firstChild;
		n.setAttribute("height", a.height + 2 * t.textMargin);
		let i = n.getBBox();
		r.attr("x", Math.round(i.x + i.width / 2 - a.width / 2)).attr("y", Math.round(i.y + i.height / 2 - a.height / 2));
	} else if (n) {
		let { startx: e, stopx: i, starty: o } = n;
		if (e > i) {
			let t = e;
			e = i, i = t;
		}
		r.attr("x", Math.round(e + Math.abs(e - i) / 2 - a.width / 2)), t.class === "loopText" ? r.attr("y", Math.round(o)) : r.attr("y", Math.round(o - a.height));
	}
	return [r];
}, "drawKatex"), G = /* @__PURE__ */ w(function(e, t) {
	let n = 0, r = 0, a = t.text.split(i.lineBreakRegex), [o, s] = y(t.fontSize), c = [], l = 0, u = /* @__PURE__ */ w(() => t.y, "yfunc");
	if (t.valign !== void 0 && t.textMargin !== void 0 && t.textMargin > 0) switch (t.valign) {
		case "top":
		case "start":
			u = /* @__PURE__ */ w(() => Math.round(t.y + t.textMargin), "yfunc");
			break;
		case "middle":
		case "center":
			u = /* @__PURE__ */ w(() => Math.round(t.y + (n + r + t.textMargin) / 2), "yfunc");
			break;
		case "bottom":
		case "end": u = /* @__PURE__ */ w(() => Math.round(t.y + (n + r + 2 * t.textMargin) - t.textMargin), "yfunc");
	}
	if (t.anchor !== void 0 && t.textMargin !== void 0 && t.width !== void 0) switch (t.anchor) {
		case "left":
		case "start":
			t.x = Math.round(t.x + t.textMargin), t.anchor = "start", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
			break;
		case "middle":
		case "center":
			t.x = Math.round(t.x + t.width / 2), t.anchor = "middle", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
			break;
		case "right":
		case "end": t.x = Math.round(t.x + t.width - t.textMargin), t.anchor = "end", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
	}
	for (let [i, d] of a.entries()) {
		t.textMargin !== void 0 && t.textMargin === 0 && o !== void 0 && (l = i * o);
		let a = e.append("text");
		a.attr("x", t.x), a.attr("y", u()), t.anchor !== void 0 && a.attr("text-anchor", t.anchor).attr("dominant-baseline", t.dominantBaseline).attr("alignment-baseline", t.alignmentBaseline), t.fontFamily !== void 0 && a.style("font-family", t.fontFamily), s !== void 0 && a.style("font-size", s), t.fontWeight !== void 0 && a.style("font-weight", t.fontWeight), t.fill !== void 0 && a.attr("fill", t.fill), t.class !== void 0 && a.attr("class", t.class), t.dy === void 0 ? l !== 0 && a.attr("dy", l) : a.attr("dy", t.dy);
		let f = d || "​";
		if (t.tspan) {
			let e = a.append("tspan");
			e.attr("x", t.x), t.fill !== void 0 && e.attr("fill", t.fill), e.text(f);
		} else a.text(f);
		t.valign !== void 0 && t.textMargin !== void 0 && t.textMargin > 0 && (r += (a._groups || a)[0][0].getBBox().height, n = r), c.push(a);
	}
	return c;
}, "drawText"), se = /* @__PURE__ */ w(function(e, t) {
	function n(e, t, n, r, i) {
		return e + "," + t + " " + (e + n) + "," + t + " " + (e + n) + "," + (t + r - i) + " " + (e + n - i * 1.2) + "," + (t + r) + " " + e + "," + (t + r);
	}
	w(n, "genPoints");
	let r = e.append("polygon");
	return r.attr("points", n(t.x, t.y, t.width, t.height, 7)), r.attr("class", "labelBox"), t.y += t.height / 2, G(e, t), r;
}, "drawLabel"), K = -1, ce = /* @__PURE__ */ w((e, t, n, r) => {
	e.select && n.forEach((n) => {
		let i = t.get(n), a = e.select("#actor" + i.actorCnt);
		!r.mirrorActors && i.stopy ? a.attr("y2", i.stopy + i.height / 2) : r.mirrorActors && a.attr("y2", i.stopy);
	});
}, "fixLifeLineHeights"), le = /* @__PURE__ */ w(function(e, t, n, r, i) {
	let a = r ? t.stopy : t.starty, o = t.x + t.width / 2, c = a + t.height, { look: l, theme: u, themeVariables: d } = n, { bkgColorArray: f, borderColorArray: p } = d, m = e.append("g").lower();
	var h = m;
	r || (K++, Object.keys(t.links || {}).length && !n.forceMenus && h.attr("onclick", ae(`actor${K}_popup`)).attr("cursor", "pointer"), h.append("line").attr("id", "actor" + K).attr("x1", o).attr("y1", c).attr("x2", o).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), h = m.append("g"), t.actorCnt = K, t.links != null && h.attr("id", "root-" + K), l === "neo" && h.attr("data-look", "neo"));
	let g = k();
	var _ = "actor";
	t.properties?.class ? _ = t.properties.class : g.fill = "#eaeaea", _ += r ? ` ${V}` : ` ${B}`, g.x = t.x, g.y = a, g.width = t.width, g.height = t.height, g.class = _, g.rx = 3, g.ry = 3, g.name = t.name, l === "neo" && (g.rx = 6, g.ry = 6);
	let v = W(h, g), y = i.get(t.name) ?? 0;
	if (U.has(u) && (v.style("stroke", p[y % p.length]), v.style("fill", f[y % p.length])), l === "neo" && v.attr("filter", "url(#drop-shadow)"), t.rectData = g, t.properties?.icon) {
		let e = t.properties.icon.trim();
		e.charAt(0) === "@" ? j(h, g.x + g.width - 20, g.y + 10, e.substr(1)) : D(h, g.x + g.width - 20, g.y + 10, e);
	}
	r || (h.attr("data-et", "participant"), h.attr("data-type", "participant"), h.attr("data-id", t.name)), Y(n, s(t.description))(t.description, h, g.x, g.y, g.width, g.height, { class: `actor ${re}` }, n);
	let b = t.height;
	if (v.node) {
		let e = v.node().getBBox();
		t.height = e.height, b = e.height;
	}
	return b;
}, "drawActorTypeParticipant"), ue = /* @__PURE__ */ w(function(e, t, n, r, i) {
	let a = r ? t.stopy : t.starty, o = t.x + t.width / 2, c = a + t.height, { look: l, theme: u, themeVariables: d } = n, { bkgColorArray: f, borderColorArray: p } = d, m = e.append("g").lower();
	var h = m;
	r || (K++, Object.keys(t.links || {}).length && !n.forceMenus && h.attr("onclick", ae(`actor${K}_popup`)).attr("cursor", "pointer"), h.append("line").attr("id", "actor" + K).attr("x1", o).attr("y1", c).attr("x2", o).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), h = m.append("g"), t.actorCnt = K, t.links != null && h.attr("id", "root-" + K), l === "neo" && h.attr("data-look", "neo"));
	let g = k();
	var _ = "actor";
	t.properties?.class ? _ = t.properties.class : g.fill = "#eaeaea", _ += r ? ` ${V}` : ` ${B}`, g.x = t.x, g.y = a, g.width = t.width, g.height = t.height, g.class = _, g.name = t.name;
	let v = {
		...g,
		x: g.x + -6,
		y: g.y + 6,
		class: "actor"
	}, y = W(h, g), b = W(h, v);
	t.rectData = g, l === "neo" && h.attr("filter", "url(#drop-shadow)");
	let x = i.get(t.name) ?? 0;
	if (U.has(u) && (y.style("stroke", p[x % p.length]), y.style("fill", f[x % p.length]), b.style("stroke", p[x % p.length]), b.style("fill", f[x % p.length])), t.properties?.icon) {
		let e = t.properties.icon.trim();
		e.charAt(0) === "@" ? j(h, g.x + g.width - 20, g.y + 10, e.substr(1)) : D(h, g.x + g.width - 20, g.y + 10, e);
	}
	Y(n, s(t.description))(t.description, h, g.x - 6, g.y + 6, g.width, g.height, { class: `actor ${re}` }, n);
	let S = t.height;
	if (y.node) {
		let e = y.node().getBBox();
		t.height = e.height, S = e.height;
	}
	return r || (h.attr("data-et", "participant"), h.attr("data-type", "collections"), h.attr("data-id", t.name)), S;
}, "drawActorTypeCollections"), de = /* @__PURE__ */ w(function(e, t, n, r, i) {
	let a = r ? t.stopy : t.starty, o = t.x + t.width / 2, c = a + t.height, { look: l, theme: u, themeVariables: d } = n, { bkgColorArray: f, borderColorArray: p } = d, m = e.append("g").lower(), h = m;
	r || (K++, Object.keys(t.links || {}).length && !n.forceMenus && h.attr("onclick", ae(`actor${K}_popup`)).attr("cursor", "pointer"), h.append("line").attr("id", "actor" + K).attr("x1", o).attr("y1", c).attr("x2", o).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), h = m.append("g"), t.actorCnt = K, t.links != null && h.attr("id", "root-" + K), l === "neo" && h.attr("data-look", "neo"));
	let g = k(), _ = "actor";
	t.properties?.class ? _ = t.properties.class : g.fill = "#eaeaea", _ += r ? ` ${V}` : ` ${B}`, h.attr("class", _), g.x = t.x, g.y = a, g.width = t.width, g.height = t.height, g.name = t.name;
	let v = g.height / 2, y = v / (2.5 + g.height / 50), b = h.append("g"), x = h.append("g"), S = `M ${g.x},${g.y + v}
    a ${y},${v} 0 0 0 0,${g.height}
    h ${g.width - 2 * y}
    a ${y},${v} 0 0 0 0,-${g.height}
    Z
  `;
	b.append("path").attr("d", S), x.append("path").attr("d", `M ${g.x},${g.y + v}
      a ${y},${v} 0 0 0 0,${g.height}`), b.attr("transform", `translate(${y}, ${-(g.height / 2)})`), x.attr("transform", `translate(${g.width - y}, ${-g.height / 2})`), t.rectData = g, l === "neo" && b.attr("filter", "url(#drop-shadow)");
	let C = i.get(t.name) ?? 0;
	if (U.has(u) && (b.style("stroke", p[C % p.length]), b.style("fill", f[C % p.length]), x.style("stroke", p[C % p.length]), x.style("fill", f[C % p.length])), t.properties?.icon) {
		let e = t.properties.icon.trim(), n = g.x + g.width - 20, r = g.y + 10;
		e.charAt(0) === "@" ? j(h, n, r, e.substr(1)) : D(h, n, r, e);
	}
	Y(n, s(t.description))(t.description, h, g.x, g.y, g.width, g.height, { class: `actor ${re}` }, n);
	let w = t.height, T = b.select("path:last-child");
	if (T.node()) {
		let e = T.node().getBBox();
		t.height = e.height, w = e.height;
	}
	return r || (h.attr("data-et", "participant"), h.attr("data-type", "queue"), h.attr("data-id", t.name)), w;
}, "drawActorTypeQueue"), fe = /* @__PURE__ */ w(function(e, t, n, r, i, a) {
	let o = r ? t.stopy : t.starty, c = t.x + t.width / 2, l = o + 75, { look: u, theme: d, themeVariables: f } = n, { bkgColorArray: p, borderColorArray: m, actorBorder: h, actorBkg: g } = f, _ = e.append("g").lower();
	r || (K++, _.append("line").attr("id", "actor" + K).attr("x1", c).attr("y1", l).attr("x2", c).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), t.actorCnt = K);
	let v = e.append("g"), y = H;
	y += r ? ` ${V}` : ` ${B}`, v.attr("class", y), v.attr("name", t.name);
	let b = k();
	b.x = t.x, b.y = o, b.fill = "#eaeaea", b.width = t.width, b.height = t.height, b.class = "actor";
	let x = t.x + t.width / 2, S = o + 32;
	v.append("defs").append("marker").attr("id", i + "-filled-head-control").attr("refX", 11).attr("refY", 5.8).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "172.5").attr("stroke-width", 1.2).append("path").attr("d", "M 14.4 5.6 L 7.2 10.4 L 8.8 5.6 L 7.2 0.8 Z"), v.append("circle").attr("cx", x).attr("cy", S).attr("r", 22).attr("filter", `${u === "neo" ? "url(#drop-shadow)" : ""}`), v.append("line").attr("marker-end", "url(#" + i + "-filled-head-control)").attr("transform", `translate(${x}, ${S - 22})`);
	let C = a.get(t.name) ?? 0;
	return U.has(d) ? (v.style("stroke", m[C % m.length]), v.style("fill", p[C % m.length])) : (v.style("stroke", h), v.style("fill", g)), t.height = v.node().getBBox().height + 2 * (n?.sequence?.labelBoxHeight ?? 0), Y(n, s(t.description))(t.description, v, b.x, b.y + 22 + (r ? 5 : 12), b.width, b.height, { class: `actor ${H}` }, n), r || (v.attr("data-et", "participant"), v.attr("data-type", "control"), v.attr("data-id", t.name)), t.height;
}, "drawActorTypeControl"), pe = /* @__PURE__ */ w(function(e, t, n, r, i) {
	let a = r ? t.stopy : t.starty, o = t.x + t.width / 2, c = a + 75, { look: l, theme: u, themeVariables: d } = n, { bkgColorArray: f, borderColorArray: p } = d, m = e.append("g").lower(), h = e.append("g"), g = "actor";
	g += r ? ` ${V}` : ` ${B}`, h.attr("class", g), h.attr("name", t.name);
	let _ = k();
	_.x = t.x, _.y = a, _.fill = "#eaeaea", _.width = t.width, _.height = t.height, _.class = "actor";
	let v = t.x + t.width / 2, y = a + (r ? 10 : 25);
	h.append("circle").attr("cx", v).attr("cy", y).attr("r", 22).attr("width", t.width).attr("height", t.height), h.append("line").attr("x1", v - 22).attr("x2", v + 22).attr("y1", y + 22).attr("y2", y + 22).attr("stroke-width", 2), l === "neo" && h.attr("filter", "url(#drop-shadow)");
	let b = i.get(t.name) ?? 0;
	return U.has(u) && (h.style("stroke", p[b % p.length]), h.style("fill", f[b % p.length])), t.height = h.node().getBBox().height + (n?.sequence?.labelBoxHeight ?? 0), r || (K++, m.append("line").attr("id", "actor" + K).attr("x1", o).attr("y1", c).attr("x2", o).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), t.actorCnt = K), Y(n, s(t.description))(t.description, h, _.x, _.y + (r ? 15 : 30), _.width, _.height, { class: `actor ${H}` }, n), r ? h.attr("transform", "translate(0, 22)") : (h.attr("transform", "translate(0, 6)"), h.attr("data-et", "participant"), h.attr("data-type", "entity"), h.attr("data-id", t.name)), t.height;
}, "drawActorTypeEntity"), me = /* @__PURE__ */ w(function(e, t, n, r, i) {
	let a = r ? t.stopy : t.starty, o = t.x + t.width / 2, c = a + t.height + 2 * n.boxTextMargin, { theme: l, themeVariables: u, look: d } = n, { bkgColorArray: f, borderColorArray: p, actorBorder: m } = u, h = e.append("g").lower(), g = h;
	r || (K++, Object.keys(t.links || {}).length && !n.forceMenus && g.attr("onclick", ae(`actor${K}_popup`)).attr("cursor", "pointer"), g.append("line").attr("id", "actor" + K).attr("x1", o).attr("y1", c).attr("x2", o).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), g = h.append("g"), t.actorCnt = K, t.links != null && g.attr("id", "root-" + K), d === "neo" && g.attr("data-look", "neo"));
	let _ = k(), v = "actor";
	t.properties?.class ? v = t.properties.class : _.fill = "#eaeaea", v += r ? ` ${V}` : ` ${B}`, _.x = t.x, _.y = a, _.width = t.width, _.height = t.height, _.class = v, _.name = t.name, _.x = t.x, _.y = a;
	let y = _.width / 3, b = _.width / 3, x = y / 2, S = x / (2.5 + y / 50), C = g.append("g");
	C.attr("class", v);
	let w = `
  M ${_.x},${_.y + S}
  a ${x},${S} 0 0 0 ${y},0
  a ${x},${S} 0 0 0 -${y},0
  l 0,${b - 2 * S}
  a ${x},${S} 0 0 0 ${y},0
  l 0,-${b - 2 * S}
`;
	C.append("path").attr("d", w), d === "neo" && C.attr("filter", "url(#drop-shadow)");
	let T = i.get(t.name) ?? 0;
	U.has(l) ? (C.style("stroke", p[T % p.length]), C.style("fill", f[T % p.length])) : C.style("stroke", m), C.attr("transform", `translate(${y}, ${S})`), t.rectData = _, Y(n, s(t.description))(t.description, g, _.x, _.y + 35, _.width, _.height, { class: `actor ${re}` }, n);
	let E = C.select("path:last-child");
	return E.node() && (t.height = E.node().getBBox().height + (n.sequence.labelBoxHeight ?? 0)), r || (g.attr("data-et", "participant"), g.attr("data-type", "database"), g.attr("data-id", t.name)), t.height;
}, "drawActorTypeDatabase"), he = /* @__PURE__ */ w(function(e, t, n, r, i) {
	let a = r ? t.stopy : t.starty, o = t.x + t.width / 2, c = a + 80, l = e.append("g").lower(), { look: u, theme: d, themeVariables: f } = n, { bkgColorArray: p, borderColorArray: m, actorBorder: h } = f;
	r || (K++, l.append("line").attr("id", "actor" + K).attr("x1", o).attr("y1", c).attr("x2", o).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), t.actorCnt = K);
	let g = e.append("g"), _ = H;
	_ += r ? ` ${V}` : ` ${B}`, g.attr("class", _), g.attr("name", t.name);
	let v = k();
	v.x = t.x, v.y = a, v.fill = "#eaeaea", v.width = t.width, v.height = t.height, v.class = "actor", g.append("line").attr("id", "actor-man-torso" + K).attr("x1", t.x + t.width / 2 - 55).attr("y1", a + 12).attr("x2", t.x + t.width / 2 - 15).attr("y2", a + 12), g.append("line").attr("id", "actor-man-arms" + K).attr("x1", t.x + t.width / 2 - 55).attr("y1", a + 2).attr("x2", t.x + t.width / 2 - 55).attr("y2", a + 22), g.append("circle").attr("cx", t.x + t.width / 2).attr("cy", a + 12).attr("r", 22), u === "neo" && g.attr("filter", "url(#drop-shadow)");
	let y = i.get(t.name) ?? 0;
	return U.has(d) ? (g.style("stroke", m[y % m.length]), g.style("fill", p[y % m.length])) : g.style("stroke", h), t.height = g.node().getBBox().height + (n.sequence.labelBoxHeight ?? 0), Y(n, s(t.description))(t.description, g, v.x, v.y + 15, v.width, v.height, { class: `actor ${H}` }, n), g.attr("transform", "translate(0,21)"), r || (g.attr("data-et", "participant"), g.attr("data-type", "boundary"), g.attr("data-id", t.name)), t.height;
}, "drawActorTypeBoundary"), ge = /* @__PURE__ */ w(function(e, t, n, r, i) {
	let a = r ? t.stopy : t.starty, o = t.x + t.width / 2, c = a + 80, { look: l, theme: u, themeVariables: d } = n, { bkgColorArray: f, borderColorArray: p, actorBorder: m } = d, h = e.append("g").lower();
	r || (K++, h.append("line").attr("id", "actor" + K).attr("x1", o).attr("y1", c).attr("x2", o).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), t.actorCnt = K);
	let g = e.append("g"), _ = H;
	_ += r ? ` ${V}` : ` ${B}`, g.attr("class", _), g.attr("name", t.name), r || g.attr("data-et", "participant").attr("data-type", "actor").attr("data-id", t.name);
	let v = l === "neo" ? .5 : 1, y = l === "neo" ? a + (1 - v) * 30 : a;
	g.append("line").attr("id", "actor-man-torso" + K).attr("x1", o).attr("y1", y + 25 * v).attr("x2", o).attr("y2", y + 45 * v), g.append("line").attr("id", "actor-man-arms" + K).attr("x1", o - z / 2 * v).attr("y1", y + 33 * v).attr("x2", o + z / 2 * v).attr("y2", y + 33 * v), g.append("line").attr("x1", o - z / 2 * v).attr("y1", y + 60 * v).attr("x2", o).attr("y2", y + 45 * v), g.append("line").attr("x1", o).attr("y1", y + 45 * v).attr("x2", o + (z / 2 - 2) * v).attr("y2", y + 60 * v);
	let b = g.append("circle");
	b.attr("cx", t.x + t.width / 2), b.attr("cy", y + 10 * v), b.attr("r", 15 * v), b.attr("width", t.width * v), b.attr("height", t.height * v), t.height = g.node().getBBox().height;
	let x = k();
	x.x = t.x, x.y = y, x.fill = "#eaeaea", x.width = t.width, x.height = t.height / v, x.class = "actor", x.rx = 3, x.ry = 3;
	let S = i.get(t.name) ?? 0;
	return U.has(u) ? (g.style("stroke", p[S % p.length]), g.style("fill", f[S % p.length])) : g.style("stroke", m), Y(n, s(t.description))(t.description, g, x.x, y + 35 * v - (l === "neo" ? 10 : 0), x.width, x.height, { class: `actor ${H}` }, n), t.height;
}, "drawActorTypeActor"), _e = /* @__PURE__ */ w(async function(e, t, n, r, i, a, o) {
	let s = o ?? new Map([...a.db.getActors().values()].map((e, t) => [e.name, t]));
	switch (t.type) {
		case "actor": return await ge(e, t, n, r, s);
		case "participant": return await le(e, t, n, r, s);
		case "boundary": return await he(e, t, n, r, s);
		case "control": return await fe(e, t, n, r, i, s);
		case "entity": return await pe(e, t, n, r, s);
		case "database": return await me(e, t, n, r, s);
		case "collections": return await ue(e, t, n, r, s);
		case "queue": return await de(e, t, n, r, s);
	}
}, "drawActor"), ve = /* @__PURE__ */ w(function(e, t, n) {
	let r = e.append("g");
	Se(r, t), t.name && Y(n)(t.name, r, t.x, t.y + n.boxTextMargin + (t.textMaxHeight || 0) / 2, t.width, 0, { class: "text" }, n), r.lower();
}, "drawBox"), ye = /* @__PURE__ */ w(function(e) {
	return e.append("g");
}, "anchorElement"), be = /* @__PURE__ */ w(function(e, t, n, r, i, a, o) {
	let { theme: s, themeVariables: c } = r, { bkgColorArray: l, borderColorArray: u, mainBkg: d } = c, f = k(), p = t.anchored, m = t.actor;
	f.x = t.startx, f.y = t.starty, f.class = "activation" + i % 3, f.width = t.stopx - t.startx, f.height = n - t.starty;
	let h = W(p, f), g = (o ?? new Map([...a.db.getActors().values()].map((e, t) => [e.name, t]))).get(m) ?? 0;
	U.has(s) && (h.style("stroke", u[g % u.length]), h.style("fill", l[g % u.length] ?? d));
}, "drawActivation"), xe = /* @__PURE__ */ w(async function(e, t, n, r, i) {
	let { boxMargin: a, boxTextMargin: o, labelBoxHeight: c, labelBoxWidth: l, messageFontFamily: u, messageFontSize: d, messageFontWeight: f } = r, p = e.append("g").attr("data-et", "control-structure").attr("data-id", "i" + i.id), m = /* @__PURE__ */ w(function(e, t, n, r) {
		return p.append("line").attr("x1", e).attr("y1", t).attr("x2", n).attr("y2", r).attr("class", "loopLine");
	}, "drawLoopLine");
	m(t.startx, t.starty, t.stopx, t.starty), m(t.stopx, t.starty, t.stopx, t.stopy), m(t.startx, t.stopy, t.stopx, t.stopy), m(t.startx, t.starty, t.startx, t.stopy), t.sections !== void 0 && t.sections.forEach(function(e) {
		m(t.startx, e.y, t.stopx, e.y).style("stroke-dasharray", "3, 3");
	});
	let h = O();
	h.text = n, h.x = t.startx, h.y = t.starty, h.fontFamily = u, h.fontSize = d, h.fontWeight = f, h.anchor = "middle", h.valign = "middle", h.tspan = !1, h.width = Math.max(l ?? 0, 50), h.height = c + (r.look === "neo" ? 15 : 0) || 20, h.textMargin = o, h.class = "labelText", se(p, h), h = ke(), h.text = t.title, h.x = t.startx + l / 2 + (t.stopx - t.startx) / 2, h.y = t.starty + a + o, h.anchor = "middle", h.valign = "middle", h.textMargin = o, h.class = "loopText", h.fontFamily = u, h.fontSize = d, h.fontWeight = f, h.wrap = !0;
	let g = s(h.text) ? await oe(p, h, t) : G(p, h);
	if (t.sectionTitles !== void 0) {
		for (let [e, n] of Object.entries(t.sectionTitles)) if (n.message) {
			h.text = n.message, h.x = t.startx + (t.stopx - t.startx) / 2, h.y = t.sections[e].y + a + o, h.class = "sectionTitle", h.anchor = "middle", h.valign = "middle", h.tspan = !1, h.fontFamily = u, h.fontSize = d, h.fontWeight = f, h.wrap = t.wrap, s(h.text) ? (t.starty = t.sections[e].y, await oe(p, h, t)) : G(p, h);
			let r = Math.round(g.map((e) => (e._groups || e)[0][0].getBBox().height).reduce((e, t) => e + t));
			t.sections[e].height += r - (a + o);
		}
	}
	return t.height = Math.round(t.stopy - t.starty), p;
}, "drawLoop"), Se = /* @__PURE__ */ w(function(e, t) {
	E(e, t);
}, "drawBackgroundRect"), Ce = /* @__PURE__ */ w(function(e, t) {
	e.append("defs").append("symbol").attr("id", t + "-database").attr("fill-rule", "evenodd").attr("clip-rule", "evenodd").append("path").attr("transform", "scale(.5)").attr("d", "M12.258.001l.256.004.255.005.253.008.251.01.249.012.247.015.246.016.242.019.241.02.239.023.236.024.233.027.231.028.229.031.225.032.223.034.22.036.217.038.214.04.211.041.208.043.205.045.201.046.198.048.194.05.191.051.187.053.183.054.18.056.175.057.172.059.168.06.163.061.16.063.155.064.15.066.074.033.073.033.071.034.07.034.069.035.068.035.067.035.066.035.064.036.064.036.062.036.06.036.06.037.058.037.058.037.055.038.055.038.053.038.052.038.051.039.05.039.048.039.047.039.045.04.044.04.043.04.041.04.04.041.039.041.037.041.036.041.034.041.033.042.032.042.03.042.029.042.027.042.026.043.024.043.023.043.021.043.02.043.018.044.017.043.015.044.013.044.012.044.011.045.009.044.007.045.006.045.004.045.002.045.001.045v17l-.001.045-.002.045-.004.045-.006.045-.007.045-.009.044-.011.045-.012.044-.013.044-.015.044-.017.043-.018.044-.02.043-.021.043-.023.043-.024.043-.026.043-.027.042-.029.042-.03.042-.032.042-.033.042-.034.041-.036.041-.037.041-.039.041-.04.041-.041.04-.043.04-.044.04-.045.04-.047.039-.048.039-.05.039-.051.039-.052.038-.053.038-.055.038-.055.038-.058.037-.058.037-.06.037-.06.036-.062.036-.064.036-.064.036-.066.035-.067.035-.068.035-.069.035-.07.034-.071.034-.073.033-.074.033-.15.066-.155.064-.16.063-.163.061-.168.06-.172.059-.175.057-.18.056-.183.054-.187.053-.191.051-.194.05-.198.048-.201.046-.205.045-.208.043-.211.041-.214.04-.217.038-.22.036-.223.034-.225.032-.229.031-.231.028-.233.027-.236.024-.239.023-.241.02-.242.019-.246.016-.247.015-.249.012-.251.01-.253.008-.255.005-.256.004-.258.001-.258-.001-.256-.004-.255-.005-.253-.008-.251-.01-.249-.012-.247-.015-.245-.016-.243-.019-.241-.02-.238-.023-.236-.024-.234-.027-.231-.028-.228-.031-.226-.032-.223-.034-.22-.036-.217-.038-.214-.04-.211-.041-.208-.043-.204-.045-.201-.046-.198-.048-.195-.05-.19-.051-.187-.053-.184-.054-.179-.056-.176-.057-.172-.059-.167-.06-.164-.061-.159-.063-.155-.064-.151-.066-.074-.033-.072-.033-.072-.034-.07-.034-.069-.035-.068-.035-.067-.035-.066-.035-.064-.036-.063-.036-.062-.036-.061-.036-.06-.037-.058-.037-.057-.037-.056-.038-.055-.038-.053-.038-.052-.038-.051-.039-.049-.039-.049-.039-.046-.039-.046-.04-.044-.04-.043-.04-.041-.04-.04-.041-.039-.041-.037-.041-.036-.041-.034-.041-.033-.042-.032-.042-.03-.042-.029-.042-.027-.042-.026-.043-.024-.043-.023-.043-.021-.043-.02-.043-.018-.044-.017-.043-.015-.044-.013-.044-.012-.044-.011-.045-.009-.044-.007-.045-.006-.045-.004-.045-.002-.045-.001-.045v-17l.001-.045.002-.045.004-.045.006-.045.007-.045.009-.044.011-.045.012-.044.013-.044.015-.044.017-.043.018-.044.02-.043.021-.043.023-.043.024-.043.026-.043.027-.042.029-.042.03-.042.032-.042.033-.042.034-.041.036-.041.037-.041.039-.041.04-.041.041-.04.043-.04.044-.04.046-.04.046-.039.049-.039.049-.039.051-.039.052-.038.053-.038.055-.038.056-.038.057-.037.058-.037.06-.037.061-.036.062-.036.063-.036.064-.036.066-.035.067-.035.068-.035.069-.035.07-.034.072-.034.072-.033.074-.033.151-.066.155-.064.159-.063.164-.061.167-.06.172-.059.176-.057.179-.056.184-.054.187-.053.19-.051.195-.05.198-.048.201-.046.204-.045.208-.043.211-.041.214-.04.217-.038.22-.036.223-.034.226-.032.228-.031.231-.028.234-.027.236-.024.238-.023.241-.02.243-.019.245-.016.247-.015.249-.012.251-.01.253-.008.255-.005.256-.004.258-.001.258.001zm-9.258 20.499v.01l.001.021.003.021.004.022.005.021.006.022.007.022.009.023.01.022.011.023.012.023.013.023.015.023.016.024.017.023.018.024.019.024.021.024.022.025.023.024.024.025.052.049.056.05.061.051.066.051.07.051.075.051.079.052.084.052.088.052.092.052.097.052.102.051.105.052.11.052.114.051.119.051.123.051.127.05.131.05.135.05.139.048.144.049.147.047.152.047.155.047.16.045.163.045.167.043.171.043.176.041.178.041.183.039.187.039.19.037.194.035.197.035.202.033.204.031.209.03.212.029.216.027.219.025.222.024.226.021.23.02.233.018.236.016.24.015.243.012.246.01.249.008.253.005.256.004.259.001.26-.001.257-.004.254-.005.25-.008.247-.011.244-.012.241-.014.237-.016.233-.018.231-.021.226-.021.224-.024.22-.026.216-.027.212-.028.21-.031.205-.031.202-.034.198-.034.194-.036.191-.037.187-.039.183-.04.179-.04.175-.042.172-.043.168-.044.163-.045.16-.046.155-.046.152-.047.148-.048.143-.049.139-.049.136-.05.131-.05.126-.05.123-.051.118-.052.114-.051.11-.052.106-.052.101-.052.096-.052.092-.052.088-.053.083-.051.079-.052.074-.052.07-.051.065-.051.06-.051.056-.05.051-.05.023-.024.023-.025.021-.024.02-.024.019-.024.018-.024.017-.024.015-.023.014-.024.013-.023.012-.023.01-.023.01-.022.008-.022.006-.022.006-.022.004-.022.004-.021.001-.021.001-.021v-4.127l-.077.055-.08.053-.083.054-.085.053-.087.052-.09.052-.093.051-.095.05-.097.05-.1.049-.102.049-.105.048-.106.047-.109.047-.111.046-.114.045-.115.045-.118.044-.12.043-.122.042-.124.042-.126.041-.128.04-.13.04-.132.038-.134.038-.135.037-.138.037-.139.035-.142.035-.143.034-.144.033-.147.032-.148.031-.15.03-.151.03-.153.029-.154.027-.156.027-.158.026-.159.025-.161.024-.162.023-.163.022-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.011-.178.01-.179.008-.179.008-.181.006-.182.005-.182.004-.184.003-.184.002h-.37l-.184-.002-.184-.003-.182-.004-.182-.005-.181-.006-.179-.008-.179-.008-.178-.01-.176-.011-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.022-.162-.023-.161-.024-.159-.025-.157-.026-.156-.027-.155-.027-.153-.029-.151-.03-.15-.03-.148-.031-.146-.032-.145-.033-.143-.034-.141-.035-.14-.035-.137-.037-.136-.037-.134-.038-.132-.038-.13-.04-.128-.04-.126-.041-.124-.042-.122-.042-.12-.044-.117-.043-.116-.045-.113-.045-.112-.046-.109-.047-.106-.047-.105-.048-.102-.049-.1-.049-.097-.05-.095-.05-.093-.052-.09-.051-.087-.052-.085-.053-.083-.054-.08-.054-.077-.054v4.127zm0-5.654v.011l.001.021.003.021.004.021.005.022.006.022.007.022.009.022.01.022.011.023.012.023.013.023.015.024.016.023.017.024.018.024.019.024.021.024.022.024.023.025.024.024.052.05.056.05.061.05.066.051.07.051.075.052.079.051.084.052.088.052.092.052.097.052.102.052.105.052.11.051.114.051.119.052.123.05.127.051.131.05.135.049.139.049.144.048.147.048.152.047.155.046.16.045.163.045.167.044.171.042.176.042.178.04.183.04.187.038.19.037.194.036.197.034.202.033.204.032.209.03.212.028.216.027.219.025.222.024.226.022.23.02.233.018.236.016.24.014.243.012.246.01.249.008.253.006.256.003.259.001.26-.001.257-.003.254-.006.25-.008.247-.01.244-.012.241-.015.237-.016.233-.018.231-.02.226-.022.224-.024.22-.025.216-.027.212-.029.21-.03.205-.032.202-.033.198-.035.194-.036.191-.037.187-.039.183-.039.179-.041.175-.042.172-.043.168-.044.163-.045.16-.045.155-.047.152-.047.148-.048.143-.048.139-.05.136-.049.131-.05.126-.051.123-.051.118-.051.114-.052.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.051.07-.052.065-.051.06-.05.056-.051.051-.049.023-.025.023-.024.021-.025.02-.024.019-.024.018-.024.017-.024.015-.023.014-.023.013-.024.012-.022.01-.023.01-.023.008-.022.006-.022.006-.022.004-.021.004-.022.001-.021.001-.021v-4.139l-.077.054-.08.054-.083.054-.085.052-.087.053-.09.051-.093.051-.095.051-.097.05-.1.049-.102.049-.105.048-.106.047-.109.047-.111.046-.114.045-.115.044-.118.044-.12.044-.122.042-.124.042-.126.041-.128.04-.13.039-.132.039-.134.038-.135.037-.138.036-.139.036-.142.035-.143.033-.144.033-.147.033-.148.031-.15.03-.151.03-.153.028-.154.028-.156.027-.158.026-.159.025-.161.024-.162.023-.163.022-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.011-.178.009-.179.009-.179.007-.181.007-.182.005-.182.004-.184.003-.184.002h-.37l-.184-.002-.184-.003-.182-.004-.182-.005-.181-.007-.179-.007-.179-.009-.178-.009-.176-.011-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.022-.162-.023-.161-.024-.159-.025-.157-.026-.156-.027-.155-.028-.153-.028-.151-.03-.15-.03-.148-.031-.146-.033-.145-.033-.143-.033-.141-.035-.14-.036-.137-.036-.136-.037-.134-.038-.132-.039-.13-.039-.128-.04-.126-.041-.124-.042-.122-.043-.12-.043-.117-.044-.116-.044-.113-.046-.112-.046-.109-.046-.106-.047-.105-.048-.102-.049-.1-.049-.097-.05-.095-.051-.093-.051-.09-.051-.087-.053-.085-.052-.083-.054-.08-.054-.077-.054v4.139zm0-5.666v.011l.001.02.003.022.004.021.005.022.006.021.007.022.009.023.01.022.011.023.012.023.013.023.015.023.016.024.017.024.018.023.019.024.021.025.022.024.023.024.024.025.052.05.056.05.061.05.066.051.07.051.075.052.079.051.084.052.088.052.092.052.097.052.102.052.105.051.11.052.114.051.119.051.123.051.127.05.131.05.135.05.139.049.144.048.147.048.152.047.155.046.16.045.163.045.167.043.171.043.176.042.178.04.183.04.187.038.19.037.194.036.197.034.202.033.204.032.209.03.212.028.216.027.219.025.222.024.226.021.23.02.233.018.236.017.24.014.243.012.246.01.249.008.253.006.256.003.259.001.26-.001.257-.003.254-.006.25-.008.247-.01.244-.013.241-.014.237-.016.233-.018.231-.02.226-.022.224-.024.22-.025.216-.027.212-.029.21-.03.205-.032.202-.033.198-.035.194-.036.191-.037.187-.039.183-.039.179-.041.175-.042.172-.043.168-.044.163-.045.16-.045.155-.047.152-.047.148-.048.143-.049.139-.049.136-.049.131-.051.126-.05.123-.051.118-.052.114-.051.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.052.07-.051.065-.051.06-.051.056-.05.051-.049.023-.025.023-.025.021-.024.02-.024.019-.024.018-.024.017-.024.015-.023.014-.024.013-.023.012-.023.01-.022.01-.023.008-.022.006-.022.006-.022.004-.022.004-.021.001-.021.001-.021v-4.153l-.077.054-.08.054-.083.053-.085.053-.087.053-.09.051-.093.051-.095.051-.097.05-.1.049-.102.048-.105.048-.106.048-.109.046-.111.046-.114.046-.115.044-.118.044-.12.043-.122.043-.124.042-.126.041-.128.04-.13.039-.132.039-.134.038-.135.037-.138.036-.139.036-.142.034-.143.034-.144.033-.147.032-.148.032-.15.03-.151.03-.153.028-.154.028-.156.027-.158.026-.159.024-.161.024-.162.023-.163.023-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.01-.178.01-.179.009-.179.007-.181.006-.182.006-.182.004-.184.003-.184.001-.185.001-.185-.001-.184-.001-.184-.003-.182-.004-.182-.006-.181-.006-.179-.007-.179-.009-.178-.01-.176-.01-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.023-.162-.023-.161-.024-.159-.024-.157-.026-.156-.027-.155-.028-.153-.028-.151-.03-.15-.03-.148-.032-.146-.032-.145-.033-.143-.034-.141-.034-.14-.036-.137-.036-.136-.037-.134-.038-.132-.039-.13-.039-.128-.041-.126-.041-.124-.041-.122-.043-.12-.043-.117-.044-.116-.044-.113-.046-.112-.046-.109-.046-.106-.048-.105-.048-.102-.048-.1-.05-.097-.049-.095-.051-.093-.051-.09-.052-.087-.052-.085-.053-.083-.053-.08-.054-.077-.054v4.153zm8.74-8.179l-.257.004-.254.005-.25.008-.247.011-.244.012-.241.014-.237.016-.233.018-.231.021-.226.022-.224.023-.22.026-.216.027-.212.028-.21.031-.205.032-.202.033-.198.034-.194.036-.191.038-.187.038-.183.04-.179.041-.175.042-.172.043-.168.043-.163.045-.16.046-.155.046-.152.048-.148.048-.143.048-.139.049-.136.05-.131.05-.126.051-.123.051-.118.051-.114.052-.11.052-.106.052-.101.052-.096.052-.092.052-.088.052-.083.052-.079.052-.074.051-.07.052-.065.051-.06.05-.056.05-.051.05-.023.025-.023.024-.021.024-.02.025-.019.024-.018.024-.017.023-.015.024-.014.023-.013.023-.012.023-.01.023-.01.022-.008.022-.006.023-.006.021-.004.022-.004.021-.001.021-.001.021.001.021.001.021.004.021.004.022.006.021.006.023.008.022.01.022.01.023.012.023.013.023.014.023.015.024.017.023.018.024.019.024.02.025.021.024.023.024.023.025.051.05.056.05.06.05.065.051.07.052.074.051.079.052.083.052.088.052.092.052.096.052.101.052.106.052.11.052.114.052.118.051.123.051.126.051.131.05.136.05.139.049.143.048.148.048.152.048.155.046.16.046.163.045.168.043.172.043.175.042.179.041.183.04.187.038.191.038.194.036.198.034.202.033.205.032.21.031.212.028.216.027.22.026.224.023.226.022.231.021.233.018.237.016.241.014.244.012.247.011.25.008.254.005.257.004.26.001.26-.001.257-.004.254-.005.25-.008.247-.011.244-.012.241-.014.237-.016.233-.018.231-.021.226-.022.224-.023.22-.026.216-.027.212-.028.21-.031.205-.032.202-.033.198-.034.194-.036.191-.038.187-.038.183-.04.179-.041.175-.042.172-.043.168-.043.163-.045.16-.046.155-.046.152-.048.148-.048.143-.048.139-.049.136-.05.131-.05.126-.051.123-.051.118-.051.114-.052.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.051.07-.052.065-.051.06-.05.056-.05.051-.05.023-.025.023-.024.021-.024.02-.025.019-.024.018-.024.017-.023.015-.024.014-.023.013-.023.012-.023.01-.023.01-.022.008-.022.006-.023.006-.021.004-.022.004-.021.001-.021.001-.021-.001-.021-.001-.021-.004-.021-.004-.022-.006-.021-.006-.023-.008-.022-.01-.022-.01-.023-.012-.023-.013-.023-.014-.023-.015-.024-.017-.023-.018-.024-.019-.024-.02-.025-.021-.024-.023-.024-.023-.025-.051-.05-.056-.05-.06-.05-.065-.051-.07-.052-.074-.051-.079-.052-.083-.052-.088-.052-.092-.052-.096-.052-.101-.052-.106-.052-.11-.052-.114-.052-.118-.051-.123-.051-.126-.051-.131-.05-.136-.05-.139-.049-.143-.048-.148-.048-.152-.048-.155-.046-.16-.046-.163-.045-.168-.043-.172-.043-.175-.042-.179-.041-.183-.04-.187-.038-.191-.038-.194-.036-.198-.034-.202-.033-.205-.032-.21-.031-.212-.028-.216-.027-.22-.026-.224-.023-.226-.022-.231-.021-.233-.018-.237-.016-.241-.014-.244-.012-.247-.011-.25-.008-.254-.005-.257-.004-.26-.001-.26.001z");
}, "insertDatabaseIcon"), q = /* @__PURE__ */ w(function(e, t) {
	e.append("defs").append("symbol").attr("id", t + "-computer").attr("width", "24").attr("height", "24").append("path").attr("transform", "scale(.5)").attr("d", "M2 2v13h20v-13h-20zm18 11h-16v-9h16v9zm-10.228 6l.466-1h3.524l.467 1h-4.457zm14.228 3h-24l2-6h2.104l-1.33 4h18.45l-1.297-4h2.073l2 6zm-5-10h-14v-7h14v7z");
}, "insertComputerIcon"), J = /* @__PURE__ */ w(function(e, t) {
	e.append("defs").append("symbol").attr("id", t + "-clock").attr("width", "24").attr("height", "24").append("path").attr("transform", "scale(.5)").attr("d", "M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm5.848 12.459c.202.038.202.333.001.372-1.907.361-6.045 1.111-6.547 1.111-.719 0-1.301-.582-1.301-1.301 0-.512.77-5.447 1.125-7.445.034-.192.312-.181.343.014l.985 6.238 5.394 1.011z");
}, "insertClockIcon"), we = /* @__PURE__ */ w(function(e, t) {
	e.append("defs").append("marker").attr("id", t + "-arrowhead").attr("refX", 7.9).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M -1 0 L 10 5 L 0 10 z");
}, "insertArrowHead"), Te = /* @__PURE__ */ w(function(e, t) {
	e.append("defs").append("marker").attr("id", t + "-filled-head").attr("refX", 15.5).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "insertArrowFilledHead"), Ee = /* @__PURE__ */ w(function(e, t) {
	e.append("defs").append("marker").attr("id", t + "-sequencenumber").attr("refX", 15).attr("refY", 15).attr("markerWidth", 60).attr("markerHeight", 40).attr("orient", "auto").append("circle").attr("cx", 15).attr("cy", 15).attr("r", 6);
}, "insertSequenceNumber"), De = /* @__PURE__ */ w(function(e, t) {
	e.append("defs").append("marker").attr("id", t + "-crosshead").attr("markerWidth", 15).attr("markerHeight", 8).attr("orient", "auto").attr("refX", 4).attr("refY", 4.5).append("path").attr("fill", "none").attr("stroke", "#000000").style("stroke-dasharray", "0, 0").attr("stroke-width", "1pt").attr("d", "M 1,2 L 6,7 M 6,2 L 1,7");
}, "insertArrowCrossHead"), Oe = /* @__PURE__ */ w(function(e, t) {
	let { theme: n } = t;
	e.append("defs").append("filter").attr("id", "drop-shadow").attr("height", "130%").attr("width", "130%").append("feDropShadow").attr("dx", "4").attr("dy", "4").attr("stdDeviation", 0).attr("flood-opacity", "0.06").attr("flood-color", `${n === "redux" || n === "redux-color" ? "#000000" : "#FFFFFF"}`);
}, "insertDropShadow"), ke = /* @__PURE__ */ w(function() {
	return {
		x: 0,
		y: 0,
		fill: void 0,
		anchor: void 0,
		style: "#666",
		width: void 0,
		height: void 0,
		textMargin: 0,
		rx: 0,
		ry: 0,
		tspan: !0,
		valign: void 0
	};
}, "getTextObj"), Ae = /* @__PURE__ */ w(function() {
	return {
		x: 0,
		y: 0,
		fill: "#EDF2AE",
		stroke: "#666",
		width: 100,
		anchor: "start",
		height: 100,
		rx: 0,
		ry: 0
	};
}, "getNoteRect"), Y = /* @__PURE__ */ function() {
	function e(e, t, n, r, i, a, s) {
		o(t.append("text").attr("x", n + i / 2).attr("y", r + a / 2 + 5).style("text-anchor", "middle").text(e), s);
	}
	w(e, "byText");
	function n(e, t, n, r, a, s, c, l) {
		let { actorFontSize: u, actorFontFamily: d, actorFontWeight: f } = l, [p, m] = y(u), h = e.split(i.lineBreakRegex);
		for (let e = 0; e < h.length; e++) {
			let i = e * p - p * (h.length - 1) / 2, l = t.append("text").attr("x", n + a / 2).attr("y", r).style("text-anchor", "middle").style("font-size", m).style("font-weight", f).style("font-family", d);
			l.append("tspan").attr("x", n + a / 2).attr("dy", i).text(h[e]), l.attr("y", r + s / 2).attr("dominant-baseline", "central").attr("alignment-baseline", "central"), o(l, c);
		}
	}
	w(n, "byTspan");
	function r(e, t, r, i, a, s, c, l) {
		let u = t.append("switch"), d = u.append("foreignObject").attr("x", r).attr("y", i).attr("width", a).attr("height", s).append("xhtml:div").style("display", "table").style("height", "100%").style("width", "100%");
		d.append("div").style("display", "table-cell").style("text-align", "center").style("vertical-align", "middle").text(e), n(e, u, r, i, a, s, c, l), o(d, c);
	}
	w(r, "byFo");
	async function a(e, r, i, a, s, c, l, d) {
		let f = await t(e, u()), p = r.append("switch"), m = p.append("foreignObject").attr("x", i + s / 2 - f.width / 2).attr("y", a + c / 2 - f.height / 2).attr("width", f.width).attr("height", f.height).append("xhtml:div").style("height", "100%").style("width", "100%");
		m.append("div").style("text-align", "center").style("vertical-align", "middle").html(await b(e, u())), n(e, p, i, a, s, c, l, d), o(m, l);
	}
	w(a, "byKatex");
	function o(e, t) {
		for (let n in t) t.hasOwnProperty(n) && e.attr(n, t[n]);
	}
	return w(o, "_setTextAttrs"), function(t, i = !1) {
		return i ? a : t.textPlacement === "fo" ? r : t.textPlacement === "old" ? e : n;
	};
}(), je = /* @__PURE__ */ function() {
	function e(e, t, n, i, a, o, s) {
		r(t.append("text").attr("x", n).attr("y", i).style("text-anchor", "start").text(e), s);
	}
	w(e, "byText");
	function t(e, t, n, a, o, s, c, l) {
		let { actorFontSize: u, actorFontFamily: d, actorFontWeight: f } = l, p = e.split(i.lineBreakRegex);
		for (let e = 0; e < p.length; e++) {
			let i = e * u - u * (p.length - 1) / 2, o = t.append("text").attr("x", n).attr("y", a).style("text-anchor", "start").style("font-size", u).style("font-weight", f).style("font-family", d);
			o.append("tspan").attr("x", n).attr("dy", i).text(p[e]), o.attr("y", a + s / 2).attr("dominant-baseline", "central").attr("alignment-baseline", "central"), r(o, c);
		}
	}
	w(t, "byTspan");
	function n(e, n, i, a, o, s, c, l) {
		let u = n.append("switch"), d = u.append("foreignObject").attr("x", i).attr("y", a).attr("width", o).attr("height", s).append("xhtml:div").style("display", "table").style("height", "100%").style("width", "100%");
		d.append("div").style("display", "table-cell").style("text-align", "center").style("vertical-align", "middle").text(e), t(e, u, i, a, o, s, c, l), r(d, c);
	}
	w(n, "byFo");
	function r(e, t) {
		for (let n in t) t.hasOwnProperty(n) && e.attr(n, t[n]);
	}
	return w(r, "_setTextAttrs"), function(r) {
		return r.textPlacement === "fo" ? n : r.textPlacement === "old" ? e : t;
	};
}(), Me = /* @__PURE__ */ w(function(e, t) {
	e.append("defs").append("marker").attr("id", t + "-solidTopArrowHead").attr("refX", 7.9).attr("refY", 7.25).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 0 L 10 8 L 0 8 z");
}, "insertSolidTopArrowHead"), Ne = /* @__PURE__ */ w(function(e, t) {
	e.append("defs").append("marker").attr("id", t + "-solidBottomArrowHead").attr("refX", 7.9).attr("refY", .75).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 0 L 10 0 L 0 8 z");
}, "insertSolidBottomArrowHead"), Pe = /* @__PURE__ */ w(function(e, t) {
	e.append("defs").append("marker").attr("id", t + "-stickTopArrowHead").attr("refX", 7.5).attr("refY", 7).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 0 L 7 7").attr("stroke", "black").attr("stroke-width", 1.5).attr("fill", "none");
}, "insertStickTopArrowHead"), Fe = /* @__PURE__ */ w(function(e, t) {
	e.append("defs").append("marker").attr("id", t + "-stickBottomArrowHead").attr("refX", 7.5).attr("refY", 0).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 7 L 7 0").attr("stroke", "black").attr("stroke-width", 1.5).attr("fill", "none");
}, "insertStickBottomArrowHead"), X = {
	drawRect: W,
	drawText: G,
	drawLabel: se,
	drawActor: _e,
	drawBox: ve,
	drawPopup: ie,
	anchorElement: ye,
	drawActivation: be,
	drawLoop: xe,
	drawBackgroundRect: Se,
	insertArrowHead: we,
	insertArrowFilledHead: Te,
	insertSequenceNumber: Ee,
	insertArrowCrossHead: De,
	insertDatabaseIcon: Ce,
	insertComputerIcon: q,
	insertClockIcon: J,
	getTextObj: ke,
	getNoteRect: Ae,
	fixLifeLineHeights: ce,
	sanitizeUrl: o.sanitizeUrl,
	insertDropShadow: Oe,
	insertSolidTopArrowHead: Me,
	insertSolidBottomArrowHead: Ne,
	insertStickTopArrowHead: Pe,
	insertStickBottomArrowHead: Fe
}, Z = {}, Q = {
	data: {
		startx: void 0,
		stopx: void 0,
		starty: void 0,
		stopy: void 0
	},
	verticalPos: 0,
	sequenceItems: [],
	activations: [],
	models: {
		getHeight: /* @__PURE__ */ w(function() {
			return Math.max.apply(null, this.actors.length === 0 ? [0] : this.actors.map((e) => e.height || 0)) + (this.loops.length === 0 ? 0 : this.loops.map((e) => e.height || 0).reduce((e, t) => e + t)) + (this.messages.length === 0 ? 0 : this.messages.map((e) => e.height || 0).reduce((e, t) => e + t)) + (this.notes.length === 0 ? 0 : this.notes.map((e) => e.height || 0).reduce((e, t) => e + t));
		}, "getHeight"),
		clear: /* @__PURE__ */ w(function() {
			this.actors = [], this.boxes = [], this.loops = [], this.messages = [], this.notes = [];
		}, "clear"),
		addBox: /* @__PURE__ */ w(function(e) {
			this.boxes.push(e);
		}, "addBox"),
		addActor: /* @__PURE__ */ w(function(e) {
			this.actors.push(e);
		}, "addActor"),
		addLoop: /* @__PURE__ */ w(function(e) {
			this.loops.push(e);
		}, "addLoop"),
		addMessage: /* @__PURE__ */ w(function(e) {
			this.messages.push(e);
		}, "addMessage"),
		addNote: /* @__PURE__ */ w(function(e) {
			this.notes.push(e);
		}, "addNote"),
		lastActor: /* @__PURE__ */ w(function() {
			return this.actors[this.actors.length - 1];
		}, "lastActor"),
		lastLoop: /* @__PURE__ */ w(function() {
			return this.loops[this.loops.length - 1];
		}, "lastLoop"),
		lastMessage: /* @__PURE__ */ w(function() {
			return this.messages[this.messages.length - 1];
		}, "lastMessage"),
		lastNote: /* @__PURE__ */ w(function() {
			return this.notes[this.notes.length - 1];
		}, "lastNote"),
		actors: [],
		boxes: [],
		loops: [],
		messages: [],
		notes: []
	},
	init: /* @__PURE__ */ w(function() {
		this.sequenceItems = [], this.activations = [], this.models.clear(), this.data = {
			startx: void 0,
			stopx: void 0,
			starty: void 0,
			stopy: void 0
		}, this.verticalPos = 0, Ke(d());
	}, "init"),
	updateVal: /* @__PURE__ */ w(function(e, t, n, r) {
		e[t] = e[t] === void 0 ? n : r(n, e[t]);
	}, "updateVal"),
	updateBounds: /* @__PURE__ */ w(function(e, t, n, r) {
		let i = this, a = 0;
		function o(o) {
			return /* @__PURE__ */ w(function(s) {
				a++;
				let c = i.sequenceItems.length - a + 1;
				i.updateVal(s, "starty", t - c * Z.boxMargin, Math.min), i.updateVal(s, "stopy", r + c * Z.boxMargin, Math.max), i.updateVal(Q.data, "startx", e - c * Z.boxMargin, Math.min), i.updateVal(Q.data, "stopx", n + c * Z.boxMargin, Math.max), o !== "activation" && (i.updateVal(s, "startx", e - c * Z.boxMargin, Math.min), i.updateVal(s, "stopx", n + c * Z.boxMargin, Math.max), i.updateVal(Q.data, "starty", t - c * Z.boxMargin, Math.min), i.updateVal(Q.data, "stopy", r + c * Z.boxMargin, Math.max));
			}, "updateItemBounds");
		}
		w(o, "updateFn"), this.sequenceItems.forEach(o()), this.activations.forEach(o("activation"));
	}, "updateBounds"),
	insert: /* @__PURE__ */ w(function(e, t, n, r) {
		let a = i.getMin(e, n), o = i.getMax(e, n), s = i.getMin(t, r), c = i.getMax(t, r);
		this.updateVal(Q.data, "startx", a, Math.min), this.updateVal(Q.data, "starty", s, Math.min), this.updateVal(Q.data, "stopx", o, Math.max), this.updateVal(Q.data, "stopy", c, Math.max), this.updateBounds(a, s, o, c);
	}, "insert"),
	newActivation: /* @__PURE__ */ w(function(e, t, n) {
		let r = n.get(e.from), i = qe(e.from).length || 0, a = r.x + r.width / 2 + (i - 1) * Z.activationWidth / 2;
		this.activations.push({
			startx: a,
			starty: this.verticalPos + 2,
			stopx: a + Z.activationWidth,
			stopy: void 0,
			actor: e.from,
			anchored: X.anchorElement(t)
		});
	}, "newActivation"),
	endActivation: /* @__PURE__ */ w(function(e) {
		let t = this.activations.map(function(e) {
			return e.actor;
		}).lastIndexOf(e.from);
		return this.activations.splice(t, 1)[0];
	}, "endActivation"),
	createLoop: /* @__PURE__ */ w(function(e = {
		message: void 0,
		wrap: !1,
		width: void 0
	}, t) {
		return {
			startx: void 0,
			starty: this.verticalPos,
			stopx: void 0,
			stopy: void 0,
			title: e.message,
			wrap: e.wrap,
			width: e.width,
			height: 0,
			fill: t
		};
	}, "createLoop"),
	newLoop: /* @__PURE__ */ w(function(e = {
		message: void 0,
		wrap: !1,
		width: void 0
	}, t) {
		this.sequenceItems.push(this.createLoop(e, t));
	}, "newLoop"),
	endLoop: /* @__PURE__ */ w(function() {
		return this.sequenceItems.pop();
	}, "endLoop"),
	isLoopOverlap: /* @__PURE__ */ w(function() {
		return this.sequenceItems.length ? this.sequenceItems[this.sequenceItems.length - 1].overlap : !1;
	}, "isLoopOverlap"),
	addSectionToLoop: /* @__PURE__ */ w(function(e) {
		let t = this.sequenceItems.pop();
		t.sections = t.sections || [], t.sectionTitles = t.sectionTitles || [], t.sections.push({
			y: Q.getVerticalPos(),
			height: 0
		}), t.sectionTitles.push(e), this.sequenceItems.push(t);
	}, "addSectionToLoop"),
	saveVerticalPos: /* @__PURE__ */ w(function() {
		this.isLoopOverlap() && (this.savedVerticalPos = this.verticalPos);
	}, "saveVerticalPos"),
	resetVerticalPos: /* @__PURE__ */ w(function() {
		this.isLoopOverlap() && (this.verticalPos = this.savedVerticalPos);
	}, "resetVerticalPos"),
	bumpVerticalPos: /* @__PURE__ */ w(function(e) {
		this.verticalPos += e, this.data.stopy = i.getMax(this.data.stopy, this.verticalPos);
	}, "bumpVerticalPos"),
	getVerticalPos: /* @__PURE__ */ w(function() {
		return this.verticalPos;
	}, "getVerticalPos"),
	getBounds: /* @__PURE__ */ w(function() {
		return {
			bounds: this.data,
			models: this.models
		};
	}, "getBounds")
}, Ie = /* @__PURE__ */ w(async function(e, t, n) {
	Q.bumpVerticalPos(Z.boxMargin), t.height = Z.boxMargin, t.starty = Q.getVerticalPos();
	let r = k();
	r.x = t.startx, r.y = t.starty, r.width = t.width || Z.width, r.class = "note";
	let i = e.append("g");
	i.attr("data-et", "note"), i.attr("data-id", "i" + n);
	let a = X.drawRect(i, r), o = O();
	o.x = t.startx, o.y = t.starty, o.width = r.width, o.dy = "1em", o.text = t.message, o.class = "noteText", o.fontFamily = Z.noteFontFamily, o.fontSize = Z.noteFontSize, o.fontWeight = Z.noteFontWeight, o.anchor = Z.noteAlign, o.textMargin = Z.noteMargin, o.valign = "center";
	let c = s(o.text) ? await oe(i, o) : G(i, o), l = Math.round(c.map((e) => (e._groups || e)[0][0].getBBox().height).reduce((e, t) => e + t));
	a.attr("height", l + 2 * Z.noteMargin), t.height += l + 2 * Z.noteMargin, Q.bumpVerticalPos(l + 2 * Z.noteMargin), t.stopy = t.starty + l + 2 * Z.noteMargin, t.stopx = t.startx + r.width, Q.insert(t.startx, t.starty, t.stopx, t.stopy), Q.models.addNote(t);
}, "drawNote"), Le = /* @__PURE__ */ w(function(e, t, n, r, i, a, o) {
	let s = r.db.getActors(), c = s.get(t.from), l = s.get(t.to), u = n.sequenceVisible, d = c.x + c.width / 2, f = l.x + l.width / 2, p = d <= f, m = it(t, r), h = e.append("g"), g = /* @__PURE__ */ w((e, t) => {
		let n = e ? 16.5 : -16.5;
		return t ? -n : n;
	}, "getCircleOffset"), _ = /* @__PURE__ */ w((e) => {
		h.append("circle").attr("cx", e).attr("cy", o).attr("r", 5).attr("width", 10).attr("height", 10);
	}, "drawCircle"), { CENTRAL_CONNECTION: v, CENTRAL_CONNECTION_REVERSE: y, CENTRAL_CONNECTION_DUAL: b } = r.db.LINETYPE;
	if (u) switch (t.centralConnection) {
		case v:
			m && (f += g(p, !0));
			break;
		case y:
			m || (d += g(p, !1));
			break;
		case b: m ? f += g(p, !0) : d += g(p, !1);
	}
	switch (t.centralConnection) {
		case v:
			_(f);
			break;
		case y:
			_(d);
			break;
		case b: _(d), _(f);
	}
}, "drawCentralConnection"), Re = /* @__PURE__ */ w((e) => ({
	fontFamily: e.messageFontFamily,
	fontSize: e.messageFontSize,
	fontWeight: e.messageFontWeight
}), "messageFont"), ze = /* @__PURE__ */ w((e) => ({
	fontFamily: e.noteFontFamily,
	fontSize: e.noteFontSize,
	fontWeight: e.noteFontWeight
}), "noteFont"), Be = /* @__PURE__ */ w((e) => ({
	fontFamily: e.actorFontFamily,
	fontSize: e.actorFontSize,
	fontWeight: e.actorFontWeight
}), "actorFont");
async function Ve(e, n) {
	Q.bumpVerticalPos(10);
	let { startx: r, stopx: a, message: o } = n, c = i.splitBreaks(o).length, l = s(o), u = l ? await t(o, d()) : v.calculateTextDimensions(o, Re(Z));
	if (!l) {
		let e = u.height / c;
		n.height += e, Q.bumpVerticalPos(e);
	}
	let f, p = u.height - 10, m = u.width;
	if (r === a) {
		f = Q.getVerticalPos() + p, Z.rightAngles || (p += Z.boxMargin, f = Q.getVerticalPos() + p), p += 30;
		let e = i.getMax(m / 2, Z.width / 2);
		Q.insert(r - e, Q.getVerticalPos() - 10 + p, a + e, Q.getVerticalPos() + 30 + p);
	} else p += Z.boxMargin, f = Q.getVerticalPos() + p, Q.insert(r, f - 10, a, f);
	return Q.bumpVerticalPos(p), n.height += p, n.stopy = n.starty + n.height, Q.insert(n.fromBounds, n.starty, n.toBounds, n.stopy), f;
}
w(Ve, "boundMessage");
var He = /* @__PURE__ */ w(async function(e, t, n, r, a, o) {
	let { startx: c, stopx: l, starty: u, message: d, type: f, sequenceIndex: m, sequenceVisible: h } = t, g = v.calculateTextDimensions(d, Re(Z)), _ = O();
	_.x = Math.min(c, l), _.y = u + 10, _.width = Math.abs(l - c), _.class = "messageText", _.dy = "1em", _.text = d, _.fontFamily = Z.messageFontFamily, _.fontSize = Z.messageFontSize, _.fontWeight = Z.messageFontWeight, _.anchor = Z.messageAlign, _.valign = "center", _.textMargin = Z.wrapPadding, _.tspan = !1, s(_.text) ? await oe(e, _, {
		startx: c,
		stopx: l,
		starty: n
	}) : G(e, _);
	let y = g.width, b;
	if (c === l) {
		let o = h || Z.showSequenceNumbers, s = it(a, r), u = at(a, r), d = c + (o && (s || u) ? 10 : 0);
		b = Z.rightAngles ? e.append("path").attr("d", `M  ${d},${n} H ${c + i.getMax(Z.width / 2, y / 2)} V ${n + 25} H ${c}`) : e.append("path").attr("d", "M " + d + "," + n + " C " + (d + 60) + "," + (n - 10) + " " + (c + 60) + "," + (n + 30) + " " + c + "," + (n + 20)), nt(a, r) && Le(e, a, t, r, c, l, n);
	} else b = e.append("line"), b.attr("x1", c), b.attr("y1", n), b.attr("x2", l), b.attr("y2", n), nt(a, r) && Le(e, a, t, r, c, l, n);
	f === r.db.LINETYPE.DOTTED || f === r.db.LINETYPE.DOTTED_CROSS || f === r.db.LINETYPE.DOTTED_POINT || f === r.db.LINETYPE.DOTTED_OPEN || f === r.db.LINETYPE.BIDIRECTIONAL_DOTTED || f === r.db.LINETYPE.SOLID_TOP_DOTTED || f === r.db.LINETYPE.SOLID_BOTTOM_DOTTED || f === r.db.LINETYPE.STICK_TOP_DOTTED || f === r.db.LINETYPE.STICK_BOTTOM_DOTTED || f === r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED || f === r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED || f === r.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED || f === r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED ? (b.style("stroke-dasharray", "3, 3"), b.attr("class", "messageLine1")) : b.attr("class", "messageLine0"), b.attr("data-et", "message"), b.attr("data-id", "i" + t.id), b.attr("data-from", t.from), b.attr("data-to", t.to);
	let x = "";
	if (Z.arrowMarkerAbsolute && (x = p(!0)), b.attr("stroke-width", 2), b.attr("stroke", "none"), b.style("fill", "none"), (f === r.db.LINETYPE.SOLID_TOP || f === r.db.LINETYPE.SOLID_TOP_DOTTED) && b.attr("marker-end", "url(" + x + "#" + o + "-solidTopArrowHead)"), (f === r.db.LINETYPE.SOLID_BOTTOM || f === r.db.LINETYPE.SOLID_BOTTOM_DOTTED) && b.attr("marker-end", "url(" + x + "#" + o + "-solidBottomArrowHead)"), (f === r.db.LINETYPE.STICK_TOP || f === r.db.LINETYPE.STICK_TOP_DOTTED) && b.attr("marker-end", "url(" + x + "#" + o + "-stickTopArrowHead)"), (f === r.db.LINETYPE.STICK_BOTTOM || f === r.db.LINETYPE.STICK_BOTTOM_DOTTED) && b.attr("marker-end", "url(" + x + "#" + o + "-stickBottomArrowHead)"), (f === r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE || f === r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED) && b.attr("marker-start", "url(" + x + "#" + o + "-solidBottomArrowHead)"), (f === r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE || f === r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED) && b.attr("marker-start", "url(" + x + "#" + o + "-solidTopArrowHead)"), (f === r.db.LINETYPE.STICK_ARROW_TOP_REVERSE || f === r.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED) && b.attr("marker-start", "url(" + x + "#" + o + "-stickBottomArrowHead)"), (f === r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE || f === r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED) && b.attr("marker-start", "url(" + x + "#" + o + "-stickTopArrowHead)"), (f === r.db.LINETYPE.SOLID || f === r.db.LINETYPE.DOTTED) && b.attr("marker-end", "url(" + x + "#" + o + "-arrowhead)"), (f === r.db.LINETYPE.BIDIRECTIONAL_SOLID || f === r.db.LINETYPE.BIDIRECTIONAL_DOTTED) && (b.attr("marker-start", "url(" + x + "#" + o + "-arrowhead)"), b.attr("marker-end", "url(" + x + "#" + o + "-arrowhead)")), (f === r.db.LINETYPE.SOLID_POINT || f === r.db.LINETYPE.DOTTED_POINT) && b.attr("marker-end", "url(" + x + "#" + o + "-filled-head)"), (f === r.db.LINETYPE.SOLID_CROSS || f === r.db.LINETYPE.DOTTED_CROSS) && b.attr("marker-end", "url(" + x + "#" + o + "-crosshead)"), h || Z.showSequenceNumbers) {
		let i = f === r.db.LINETYPE.BIDIRECTIONAL_SOLID || f === r.db.LINETYPE.BIDIRECTIONAL_DOTTED, s = f === r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE || f === r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED || f === r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE || f === r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED || f === r.db.LINETYPE.STICK_ARROW_TOP_REVERSE || f === r.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED || f === r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE || f === r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED, u = nt(a, r), d = c, p = l;
		i ? (c < l ? d = c + 12 : (d = c - 6 + (u ? -5 : 0), d += a?.centralConnection === r.db.LINETYPE.CENTRAL_CONNECTION_DUAL || a?.centralConnection === r.db.LINETYPE.CENTRAL_CONNECTION_REVERSE ? -7.5 : 0), b.attr("x1", d)) : s ? (l > c ? p = l - 12 : (p = l - 6, d += a?.centralConnection === r.db.LINETYPE.CENTRAL_CONNECTION_DUAL || a?.centralConnection === r.db.LINETYPE.CENTRAL_CONNECTION_REVERSE ? -7.5 : 0), p += u ? 15 : 0, b.attr("x2", p), b.attr("x1", d)) : b.attr("x1", c + 6);
		let h = 0, g = c === l, _ = c <= l;
		h = g ? t.fromBounds + 1 : s ? _ ? t.toBounds - 1 : t.fromBounds + 1 : _ ? t.fromBounds + 1 : t.toBounds - 1;
		let v = "12px", y = m.toString().length;
		y > 5 ? v = "7px" : y > 3 && (v = "9px"), e.append("line").attr("x1", h).attr("y1", n).attr("x2", h).attr("y2", n).attr("stroke-width", 0).attr("marker-start", "url(" + x + "#" + o + "-sequencenumber)"), e.append("text").attr("x", h).attr("y", n + 4).attr("font-family", "sans-serif").attr("font-size", v).attr("text-anchor", "middle").attr("class", "sequenceNumber").text(m);
	}
}, "drawMessage"), Ue = /* @__PURE__ */ w(function(e, t, n, r, a, o, s) {
	let c = 0, l = 0, u, d = 0;
	for (let e of r) {
		let r = t.get(e), o = r.box;
		u && u != o && (s || Q.models.addBox(u), l += Z.boxMargin + u.margin), o && o != u && (s || (o.x = c + l, o.y = a), l += o.margin), r.width = i.getMax(r.width || Z.width, Z.width), r.height = i.getMax(r.height || Z.height, Z.height), r.margin = r.margin || Z.actorMargin, d = i.getMax(d, r.height), n.get(r.name) && (l += r.width / 2), r.x = c + l, r.starty = Q.getVerticalPos(), Q.insert(r.x, a, r.x + r.width, r.height), c += r.width + l, r.box && (r.box.width = c + o.margin - r.box.x), l = r.margin, u = r.box, Q.models.addActor(r);
	}
	u && !s && Q.models.addBox(u), Q.bumpVerticalPos(d);
}, "addActorRenderingData"), We = /* @__PURE__ */ w(async function(e, t, n, r, a, o, s) {
	if (r) {
		let r = 0;
		Q.bumpVerticalPos(Z.boxMargin * 2);
		for (let c of n) {
			let n = t.get(c);
			n.stopy ||= Q.getVerticalPos();
			let l = await X.drawActor(e, n, Z, !0, a, o, s);
			r = i.getMax(r, l);
		}
		Q.bumpVerticalPos(r + Z.boxMargin);
	} else for (let r of n) {
		let n = t.get(r);
		await X.drawActor(e, n, Z, !1, a, o, s);
	}
}, "drawActors"), Ge = /* @__PURE__ */ w(function(e, t, n, r) {
	let i = 0, a = 0;
	for (let o of n) {
		let n = t.get(o), s = Qe(n), c = X.drawPopup(e, n, s, Z, Z.forceMenus, r);
		c.height > i && (i = c.height), c.width + n.x > a && (a = c.width + n.x);
	}
	return {
		maxHeight: i,
		maxWidth: a
	};
}, "drawActorsPopup"), Ke = /* @__PURE__ */ w(function(e) {
	T(Z, e), e.fontFamily && (Z.actorFontFamily = Z.noteFontFamily = Z.messageFontFamily = e.fontFamily), e.fontSize && (Z.actorFontSize = Z.noteFontSize = Z.messageFontSize = e.fontSize), e.fontWeight && (Z.actorFontWeight = Z.noteFontWeight = Z.messageFontWeight = e.fontWeight);
}, "setConf"), qe = /* @__PURE__ */ w(function(e) {
	return Q.activations.filter(function(t) {
		return t.actor === e;
	});
}, "actorActivations"), Je = /* @__PURE__ */ w(function(e, t) {
	let n = t.get(e), r = qe(e);
	return [r.reduce(function(e, t) {
		return i.getMin(e, t.startx);
	}, n.x + n.width / 2 - 1), r.reduce(function(e, t) {
		return i.getMax(e, t.stopx);
	}, n.x + n.width / 2 + 1)];
}, "activationBounds");
function $(e, t, n, r, a) {
	Q.bumpVerticalPos(n);
	let o = r;
	if (t.id && t.message && e[t.id]) {
		let n = e[t.id].width, a = Re(Z);
		t.message = v.wrapLabel(`[${t.message}]`, n - 2 * Z.wrapPadding, a), t.width = n, t.wrap = !0;
		let s = v.calculateTextDimensions(t.message, a), c = i.getMax(s.height, Z.labelBoxHeight);
		o = r + c, h.debug(`${c} - ${t.message}`);
	}
	a(t), Q.bumpVerticalPos(o);
}
w($, "adjustLoopHeightForWrap");
function Ye(e, t, n, r, i, a, o) {
	function s(n, r) {
		n.x < i.get(e.from).x ? (Q.insert(t.stopx - r, t.starty, t.startx, t.stopy + n.height / 2 + Z.noteMargin), t.stopx += r) : (Q.insert(t.startx, t.starty, t.stopx + r, t.stopy + n.height / 2 + Z.noteMargin), t.stopx -= r);
	}
	w(s, "receiverAdjustment");
	function c(n, r) {
		n.x < i.get(e.to).x ? (Q.insert(t.startx - r, t.starty, t.stopx, t.stopy + n.height / 2 + Z.noteMargin), t.startx += r) : (Q.insert(t.stopx, t.starty, t.startx + r, t.stopy + n.height / 2 + Z.noteMargin), t.startx -= r);
	}
	w(c, "senderAdjustment");
	let l = [
		L.ACTOR,
		L.CONTROL,
		L.ENTITY,
		L.DATABASE
	];
	if (a.get(e.to) == r) {
		let t = i.get(e.to);
		s(t, l.includes(t.type) ? z / 2 + 3 : t.width / 2 + 3), t.starty = n - t.height / 2, Q.bumpVerticalPos(t.height / 2);
	} else if (o.get(e.from) == r) {
		let t = i.get(e.from);
		Z.mirrorActors && c(t, l.includes(t.type) ? z / 2 : t.width / 2), t.stopy = n - t.height / 2, Q.bumpVerticalPos(t.height / 2);
	} else if (o.get(e.to) == r) {
		let t = i.get(e.to);
		Z.mirrorActors && s(t, l.includes(t.type) ? z / 2 + 3 : t.width / 2 + 3), t.stopy = n - t.height / 2, Q.bumpVerticalPos(t.height / 2);
	}
}
w(Ye, "adjustCreatedDestroyedData");
var Xe = /* @__PURE__ */ w(async function(t, n, r, i) {
	let { securityLevel: o, sequence: s, look: c, themeVariables: l } = d();
	Z = s;
	let u;
	o === "sandbox" && (u = e("#i" + n));
	let f = e(o === "sandbox" ? u.nodes()[0].contentDocument.body : "body"), p = o === "sandbox" ? u.nodes()[0].contentDocument : document;
	Q.init(), h.debug(i.db);
	let m = o === "sandbox" ? f.select(`[id="${n}"]`) : e(`[id="${n}"]`), g = i.db.getActors(), _ = i.db.getCreatedActors(), v = i.db.getDestroyedActors(), y = i.db.getBoxes(), b = i.db.getActorKeys(), x = i.db.getMessages(), S = i.db.getDiagramTitle(), C = i.db.hasAtLeastOneBox(), T = i.db.hasAtLeastOneBoxWithTitle(), E = await Ze(g, x, i);
	if (Z.height = await $e(g, E, y), X.insertComputerIcon(m, n), X.insertDatabaseIcon(m, n), X.insertClockIcon(m, n), C && (Q.bumpVerticalPos(Z.boxMargin), T && Q.bumpVerticalPos(y[0].textMaxHeight)), Z.hideUnusedParticipants === !0) {
		let e = /* @__PURE__ */ new Set();
		x.forEach((t) => {
			e.add(t.from), e.add(t.to);
		}), b = b.filter((t) => e.has(t));
	}
	let D = new Map(b.map((e, t) => [g.get(e)?.name ?? e, t]));
	Ue(m, g, _, b, 0, x, !1);
	let O = await st(x, g, E, i);
	X.insertArrowHead(m, n), X.insertArrowCrossHead(m, n), X.insertArrowFilledHead(m, n), X.insertSequenceNumber(m, n), X.insertSolidTopArrowHead(m, n), X.insertSolidBottomArrowHead(m, n), X.insertStickTopArrowHead(m, n), X.insertStickBottomArrowHead(m, n), c === "neo" && X.insertDropShadow(m, Z);
	function k(e, t) {
		let n = Q.endActivation(e);
		n.starty + 18 > t && (n.starty = t - 6, t += 12), X.drawActivation(m, n, t, Z, qe(e.from).length, i, D), Q.insert(n.startx, t - 10, n.stopx, t);
	}
	w(k, "activeEnd");
	let A = 1, j = 1, M = [], N = [], P = 0;
	for (let e of x) {
		let t, n, r;
		switch (e.type) {
			case i.db.LINETYPE.NOTE:
				Q.resetVerticalPos(), n = e.noteModel, await Ie(m, n, e.id);
				break;
			case i.db.LINETYPE.ACTIVE_START:
				Q.newActivation(e, m, g);
				break;
			case i.db.LINETYPE.CENTRAL_CONNECTION:
				Q.newActivation(e, m, g);
				break;
			case i.db.LINETYPE.CENTRAL_CONNECTION_REVERSE:
				Q.newActivation(e, m, g);
				break;
			case i.db.LINETYPE.ACTIVE_END:
				k(e, Q.getVerticalPos());
				break;
			case i.db.LINETYPE.LOOP_START:
				$(O, e, Z.boxMargin, Z.boxMargin + Z.boxTextMargin, (e) => Q.newLoop(e));
				break;
			case i.db.LINETYPE.LOOP_END:
				t = Q.endLoop(), await X.drawLoop(m, t, "loop", Z, e), Q.bumpVerticalPos(t.stopy - Q.getVerticalPos()), Q.models.addLoop(t);
				break;
			case i.db.LINETYPE.RECT_START:
				$(O, e, Z.boxMargin, Z.boxMargin, (e) => {
					let t = e.message;
					t ||= l?.rectBkgColor || l?.actorBkg || "rgba(128, 128, 128, 0.5)", Q.newLoop(void 0, t);
				});
				break;
			case i.db.LINETYPE.RECT_END:
				t = Q.endLoop(), N.push(t), Q.models.addLoop(t), Q.bumpVerticalPos(t.stopy - Q.getVerticalPos());
				break;
			case i.db.LINETYPE.OPT_START:
				$(O, e, Z.boxMargin, Z.boxMargin + Z.boxTextMargin, (e) => Q.newLoop(e));
				break;
			case i.db.LINETYPE.OPT_END:
				t = Q.endLoop(), await X.drawLoop(m, t, "opt", Z, e), Q.bumpVerticalPos(t.stopy - Q.getVerticalPos()), Q.models.addLoop(t);
				break;
			case i.db.LINETYPE.ALT_START:
				$(O, e, Z.boxMargin, Z.boxMargin + Z.boxTextMargin, (e) => Q.newLoop(e));
				break;
			case i.db.LINETYPE.ALT_ELSE:
				$(O, e, Z.boxMargin + Z.boxTextMargin, Z.boxMargin, (e) => Q.addSectionToLoop(e));
				break;
			case i.db.LINETYPE.ALT_END:
				t = Q.endLoop(), await X.drawLoop(m, t, "alt", Z, e), Q.bumpVerticalPos(t.stopy - Q.getVerticalPos()), Q.models.addLoop(t);
				break;
			case i.db.LINETYPE.PAR_START:
			case i.db.LINETYPE.PAR_OVER_START:
				$(O, e, Z.boxMargin, Z.boxMargin + Z.boxTextMargin, (e) => Q.newLoop(e)), Q.saveVerticalPos();
				break;
			case i.db.LINETYPE.PAR_AND:
				$(O, e, Z.boxMargin + Z.boxTextMargin, Z.boxMargin, (e) => Q.addSectionToLoop(e));
				break;
			case i.db.LINETYPE.PAR_END:
				t = Q.endLoop(), await X.drawLoop(m, t, "par", Z, e), Q.bumpVerticalPos(t.stopy - Q.getVerticalPos()), Q.models.addLoop(t);
				break;
			case i.db.LINETYPE.AUTONUMBER:
				A = e.message.start || A, j = e.message.step || j, e.message.visible ? i.db.enableSequenceNumbers() : i.db.disableSequenceNumbers();
				break;
			case i.db.LINETYPE.CRITICAL_START:
				$(O, e, Z.boxMargin, Z.boxMargin + Z.boxTextMargin, (e) => Q.newLoop(e));
				break;
			case i.db.LINETYPE.CRITICAL_OPTION:
				$(O, e, Z.boxMargin + Z.boxTextMargin, Z.boxMargin, (e) => Q.addSectionToLoop(e));
				break;
			case i.db.LINETYPE.CRITICAL_END:
				t = Q.endLoop(), await X.drawLoop(m, t, "critical", Z, e), Q.bumpVerticalPos(t.stopy - Q.getVerticalPos()), Q.models.addLoop(t);
				break;
			case i.db.LINETYPE.BREAK_START:
				$(O, e, Z.boxMargin, Z.boxMargin + Z.boxTextMargin, (e) => Q.newLoop(e));
				break;
			case i.db.LINETYPE.BREAK_END:
				t = Q.endLoop(), await X.drawLoop(m, t, "break", Z, e), Q.bumpVerticalPos(t.stopy - Q.getVerticalPos()), Q.models.addLoop(t);
				break;
			default: try {
				r = e.msgModel, r.starty = Q.getVerticalPos(), r.sequenceIndex = A, r.sequenceVisible = i.db.showSequenceNumbers(), r.id = e.id, r.from = e.from, r.to = e.to;
				let t = await Ve(m, r);
				Ye(e, r, t, P, g, _, v), M.push({
					messageModel: r,
					lineStartY: t,
					msg: e
				}), Q.models.addMessage(r);
			} catch (e) {
				h.error("error while drawing message", e);
			}
		}
		[
			i.db.LINETYPE.SOLID_OPEN,
			i.db.LINETYPE.DOTTED_OPEN,
			i.db.LINETYPE.SOLID,
			i.db.LINETYPE.SOLID_TOP,
			i.db.LINETYPE.SOLID_BOTTOM,
			i.db.LINETYPE.STICK_TOP,
			i.db.LINETYPE.STICK_BOTTOM,
			i.db.LINETYPE.SOLID_TOP_DOTTED,
			i.db.LINETYPE.SOLID_BOTTOM_DOTTED,
			i.db.LINETYPE.STICK_TOP_DOTTED,
			i.db.LINETYPE.STICK_BOTTOM_DOTTED,
			i.db.LINETYPE.SOLID_ARROW_TOP_REVERSE,
			i.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE,
			i.db.LINETYPE.STICK_ARROW_TOP_REVERSE,
			i.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE,
			i.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED,
			i.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED,
			i.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED,
			i.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED,
			i.db.LINETYPE.DOTTED,
			i.db.LINETYPE.SOLID_CROSS,
			i.db.LINETYPE.DOTTED_CROSS,
			i.db.LINETYPE.SOLID_POINT,
			i.db.LINETYPE.DOTTED_POINT,
			i.db.LINETYPE.BIDIRECTIONAL_SOLID,
			i.db.LINETYPE.BIDIRECTIONAL_DOTTED
		].includes(e.type) && (A = Math.round((A + j) * 100) / 100), P++;
	}
	h.debug("createdActors", _), h.debug("destroyedActors", v), await We(m, g, b, !1, n, i, D);
	for (let e of M) await He(m, e.messageModel, e.lineStartY, i, e.msg, n);
	Z.mirrorActors && await We(m, g, b, !0, n, i, D), N.forEach((e) => X.drawBackgroundRect(m, e)), ce(m, g, b, Z);
	for (let e of Q.models.boxes) {
		e.height = Q.getVerticalPos() - e.y, Q.insert(e.x, e.y, e.x + e.width, e.height);
		let t = Z.boxMargin * 2;
		e.startx = e.x - t, e.starty = e.y - t * .25, e.stopx = e.startx + e.width + 2 * t, e.stopy = e.starty + e.height + t * .75, e.stroke = "rgb(0,0,0, 0.5)", X.drawBox(m, e, Z);
	}
	C && Q.bumpVerticalPos(Z.boxMargin);
	let F = Ge(m, g, b, p), { bounds: I } = Q.getBounds();
	I.startx === void 0 && (I.startx = 0), I.starty === void 0 && (I.starty = 0), I.stopx === void 0 && (I.stopx = 0), I.stopy === void 0 && (I.stopy = 0);
	let ee = I.stopy - I.starty;
	ee < F.maxHeight && (ee = F.maxHeight);
	let L = ee + 2 * Z.diagramMarginY;
	Z.mirrorActors && (L = L - Z.boxMargin + Z.bottomMarginAdj);
	let R = I.stopx - I.startx;
	R < F.maxWidth && (R = F.maxWidth);
	let te = R + 2 * Z.diagramMarginX;
	S && m.append("text").text(S).attr("x", (I.stopx - I.startx) / 2 - 2 * Z.diagramMarginX).attr("y", -25), a(m, L, te, Z.useMaxWidth);
	let ne = S ? 40 : 0, z = g.size && c === "neo" ? 30 : 0;
	m.attr("viewBox", I.startx - Z.diagramMarginX + " -" + (Z.diagramMarginY + ne) + " " + te + " " + (L + ne + z)), h.debug("models:", Q.models);
}, "draw");
async function Ze(e, n, r) {
	let a = {};
	for (let o of n) if (e.get(o.to) && e.get(o.from)) {
		let n = e.get(o.to);
		if (o.placement === r.db.PLACEMENT.LEFTOF && !n.prevActor || o.placement === r.db.PLACEMENT.RIGHTOF && !n.nextActor) continue;
		let c = o.placement !== void 0, l = !c, u = c ? ze(Z) : Re(Z), f = o.wrap ? v.wrapLabel(o.message, Z.width - 2 * Z.wrapPadding, u) : o.message, p = (s(f) ? await t(o.message, d()) : v.calculateTextDimensions(f, u)).width + 2 * Z.wrapPadding;
		l && o.from === n.nextActor ? a[o.to] = i.getMax(a[o.to] || 0, p) : l && o.from === n.prevActor ? a[o.from] = i.getMax(a[o.from] || 0, p) : l && o.from === o.to ? (a[o.from] = i.getMax(a[o.from] || 0, p / 2), a[o.to] = i.getMax(a[o.to] || 0, p / 2)) : o.placement === r.db.PLACEMENT.RIGHTOF ? a[o.from] = i.getMax(a[o.from] || 0, p) : o.placement === r.db.PLACEMENT.LEFTOF ? a[n.prevActor] = i.getMax(a[n.prevActor] || 0, p) : o.placement === r.db.PLACEMENT.OVER && (n.prevActor && (a[n.prevActor] = i.getMax(a[n.prevActor] || 0, p / 2)), n.nextActor && (a[o.from] = i.getMax(a[o.from] || 0, p / 2)));
	}
	return h.debug("maxMessageWidthPerActor:", a), a;
}
w(Ze, "getMaxMessageWidthPerActor");
var Qe = /* @__PURE__ */ w(function(e) {
	let t = 0, n = Be(Z);
	for (let r in e.links) {
		let e = v.calculateTextDimensions(r, n).width + 2 * Z.wrapPadding + 2 * Z.boxMargin;
		t < e && (t = e);
	}
	return t;
}, "getRequiredPopupWidth");
async function $e(e, n, r) {
	let a = 0;
	for (let n of e.keys()) {
		let r = e.get(n);
		r.wrap && (r.description = v.wrapLabel(r.description, Z.width - 2 * Z.wrapPadding, Be(Z)));
		let o = s(r.description) ? await t(r.description, d()) : v.calculateTextDimensions(r.description, Be(Z));
		r.width = r.wrap ? Z.width : i.getMax(Z.width, o.width + 2 * Z.wrapPadding), r.height = r.wrap ? i.getMax(o.height, Z.height) : Z.height, a = i.getMax(a, r.height);
	}
	for (let t in n) {
		let r = e.get(t);
		if (!r) continue;
		let a = e.get(r.nextActor);
		if (!a) {
			let e = n[t] + Z.actorMargin - r.width / 2;
			r.margin = i.getMax(e, Z.actorMargin);
			continue;
		}
		let o = n[t] + Z.actorMargin - r.width / 2 - a.width / 2;
		r.margin = i.getMax(o, Z.actorMargin);
	}
	let o = 0;
	return r.forEach((t) => {
		let n = Re(Z), r = t.actorKeys.reduce((t, n) => t += e.get(n).width + (e.get(n).margin || 0), 0), a = Z.boxMargin * 8;
		r += a, r -= 2 * Z.boxTextMargin, t.wrap && (t.name = v.wrapLabel(t.name, r - 2 * Z.wrapPadding, n));
		let s = v.calculateTextDimensions(t.name, n);
		o = i.getMax(s.height, o);
		let c = i.getMax(r, s.width + 2 * Z.wrapPadding);
		if (t.margin = Z.boxTextMargin, r < c) {
			let e = (c - r) / 2;
			t.margin += e;
		}
	}), r.forEach((e) => e.textMaxHeight = o), i.getMax(a, Z.height);
}
w($e, "calculateActorMargins");
var et = /* @__PURE__ */ w(async function(e, n, r) {
	let a = n.get(e.from), o = n.get(e.to), c = a.x, l = o.x, u = e.wrap && e.message, f = s(e.message) ? await t(e.message, d()) : v.calculateTextDimensions(u ? v.wrapLabel(e.message, Z.width, ze(Z)) : e.message, ze(Z)), p = {
		width: u ? Z.width : i.getMax(Z.width, f.width + 2 * Z.noteMargin),
		height: 0,
		startx: a.x,
		stopx: 0,
		starty: 0,
		stopy: 0,
		message: e.message
	};
	return e.placement === r.db.PLACEMENT.RIGHTOF ? (p.width = u ? i.getMax(Z.width, f.width) : i.getMax(a.width / 2 + o.width / 2, f.width + 2 * Z.noteMargin), p.startx = c + (a.width + Z.actorMargin) / 2) : e.placement === r.db.PLACEMENT.LEFTOF ? (p.width = u ? i.getMax(Z.width, f.width + 2 * Z.noteMargin) : i.getMax(a.width / 2 + o.width / 2, f.width + 2 * Z.noteMargin), p.startx = c - p.width + (a.width - Z.actorMargin) / 2) : e.to === e.from ? (f = v.calculateTextDimensions(u ? v.wrapLabel(e.message, i.getMax(Z.width, a.width), ze(Z)) : e.message, ze(Z)), p.width = u ? i.getMax(Z.width, a.width) : i.getMax(a.width, Z.width, f.width + 2 * Z.noteMargin), p.startx = c + (a.width - p.width) / 2) : (p.width = Math.abs(c + a.width / 2 - (l + o.width / 2)) + Z.actorMargin, p.startx = c < l ? c + a.width / 2 - Z.actorMargin / 2 : l + o.width / 2 - Z.actorMargin / 2), u && (p.message = v.wrapLabel(e.message, p.width - 2 * Z.wrapPadding, ze(Z))), h.debug(`NM:[${p.startx},${p.stopx},${p.starty},${p.stopy}:${p.width},${p.height}=${e.message}]`), p;
}, "buildNoteModel"), tt = 4, nt = /* @__PURE__ */ w(function(e, t) {
	let { CENTRAL_CONNECTION: n, CENTRAL_CONNECTION_REVERSE: r, CENTRAL_CONNECTION_DUAL: i } = t.db.LINETYPE;
	return [
		n,
		r,
		i
	].includes(e.centralConnection);
}, "hasCentralConnection"), rt = /* @__PURE__ */ w(function(e, t, n) {
	let { CENTRAL_CONNECTION_REVERSE: r, CENTRAL_CONNECTION_DUAL: i, BIDIRECTIONAL_SOLID: a, BIDIRECTIONAL_DOTTED: o } = t.db.LINETYPE, s = 0;
	return (e.centralConnection === r || e.centralConnection === i) && (s += tt), (e.centralConnection === r || e.centralConnection === i) && (e.type === a || e.type === o) && (s += n ? 0 : -6), s;
}, "calculateCentralConnectionOffset"), it = /* @__PURE__ */ w(function(e, t) {
	let { SOLID_ARROW_TOP_REVERSE: n, SOLID_ARROW_TOP_REVERSE_DOTTED: r, SOLID_ARROW_BOTTOM_REVERSE: i, SOLID_ARROW_BOTTOM_REVERSE_DOTTED: a, STICK_ARROW_TOP_REVERSE: o, STICK_ARROW_TOP_REVERSE_DOTTED: s, STICK_ARROW_BOTTOM_REVERSE: c, STICK_ARROW_BOTTOM_REVERSE_DOTTED: l } = t.db.LINETYPE;
	return [
		n,
		r,
		i,
		a,
		o,
		s,
		c,
		l
	].includes(e.type);
}, "isReverseArrowType"), at = /* @__PURE__ */ w(function(e, t) {
	let { BIDIRECTIONAL_SOLID: n, BIDIRECTIONAL_DOTTED: r } = t.db.LINETYPE;
	return [n, r].includes(e.type);
}, "isBidirectionalArrowType"), ot = /* @__PURE__ */ w(function(e, t, n) {
	let { look: r } = d();
	if (![
		n.db.LINETYPE.SOLID_OPEN,
		n.db.LINETYPE.DOTTED_OPEN,
		n.db.LINETYPE.SOLID,
		n.db.LINETYPE.SOLID_TOP,
		n.db.LINETYPE.SOLID_BOTTOM,
		n.db.LINETYPE.STICK_TOP,
		n.db.LINETYPE.STICK_BOTTOM,
		n.db.LINETYPE.SOLID_TOP_DOTTED,
		n.db.LINETYPE.SOLID_BOTTOM_DOTTED,
		n.db.LINETYPE.STICK_TOP_DOTTED,
		n.db.LINETYPE.STICK_BOTTOM_DOTTED,
		n.db.LINETYPE.SOLID_ARROW_TOP_REVERSE,
		n.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE,
		n.db.LINETYPE.STICK_ARROW_TOP_REVERSE,
		n.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE,
		n.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED,
		n.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED,
		n.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED,
		n.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED,
		n.db.LINETYPE.DOTTED,
		n.db.LINETYPE.SOLID_CROSS,
		n.db.LINETYPE.DOTTED_CROSS,
		n.db.LINETYPE.SOLID_POINT,
		n.db.LINETYPE.DOTTED_POINT,
		n.db.LINETYPE.BIDIRECTIONAL_SOLID,
		n.db.LINETYPE.BIDIRECTIONAL_DOTTED
	].includes(e.type)) return {};
	let [a, o] = Je(e.from, t), [s, c] = Je(e.to, t), l = a <= s, u = l ? o : a, f = l ? s : c;
	r === "neo" && (e.type !== n.db.LINETYPE.SOLID_OPEN && (f += l ? -3 : 3), (e.type === n.db.LINETYPE.BIDIRECTIONAL_SOLID || e.type === n.db.LINETYPE.BIDIRECTIONAL_DOTTED) && (u += l ? 3 : -3)), u += rt(e, n, l);
	let p = Math.abs(s - c) > 2, m = /* @__PURE__ */ w((e) => l ? -e : e, "adjustValue");
	e.from === e.to ? f = u : (e.activate && !p && (f += m(Z.activationWidth / 2 - 1)), [
		n.db.LINETYPE.SOLID_OPEN,
		n.db.LINETYPE.DOTTED_OPEN,
		n.db.LINETYPE.STICK_TOP,
		n.db.LINETYPE.STICK_BOTTOM,
		n.db.LINETYPE.STICK_TOP_DOTTED,
		n.db.LINETYPE.STICK_BOTTOM_DOTTED,
		n.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED,
		n.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED,
		n.db.LINETYPE.STICK_ARROW_TOP_REVERSE,
		n.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE,
		n.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED,
		n.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED,
		n.db.LINETYPE.SOLID_ARROW_TOP_REVERSE,
		n.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE
	].includes(e.type) || (f += m(3)), [
		n.db.LINETYPE.BIDIRECTIONAL_SOLID,
		n.db.LINETYPE.BIDIRECTIONAL_DOTTED,
		n.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED,
		n.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED,
		n.db.LINETYPE.SOLID_ARROW_TOP_REVERSE,
		n.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE
	].includes(e.type) && (u -= m(3)));
	let h = [
		a,
		o,
		s,
		c
	], g = Math.abs(u - f);
	e.wrap && e.message && (e.message = v.wrapLabel(e.message, i.getMax(g + 2 * Z.wrapPadding, Z.width), Re(Z)));
	let _ = v.calculateTextDimensions(e.message, Re(Z));
	return {
		width: i.getMax(e.wrap ? 0 : _.width + 2 * Z.wrapPadding, g + 2 * Z.wrapPadding, Z.width),
		height: 0,
		startx: u,
		stopx: f,
		starty: 0,
		stopy: 0,
		message: e.message,
		type: e.type,
		wrap: e.wrap,
		fromBounds: Math.min.apply(null, h),
		toBounds: Math.max.apply(null, h)
	};
}, "buildMessageModel"), st = /* @__PURE__ */ w(async function(e, t, n, r) {
	let a = {}, o = [], s, c, l;
	for (let n of e) {
		switch (n.type) {
			case r.db.LINETYPE.LOOP_START:
			case r.db.LINETYPE.ALT_START:
			case r.db.LINETYPE.OPT_START:
			case r.db.LINETYPE.PAR_START:
			case r.db.LINETYPE.PAR_OVER_START:
			case r.db.LINETYPE.CRITICAL_START:
			case r.db.LINETYPE.BREAK_START:
				o.push({
					id: n.id,
					msg: n.message,
					from: 2 ** 53 - 1,
					to: -(2 ** 53 - 1),
					width: 0
				});
				break;
			case r.db.LINETYPE.ALT_ELSE:
			case r.db.LINETYPE.PAR_AND:
			case r.db.LINETYPE.CRITICAL_OPTION:
				n.message && (s = o.pop(), a[s.id] = s, a[n.id] = s, o.push(s));
				break;
			case r.db.LINETYPE.LOOP_END:
			case r.db.LINETYPE.ALT_END:
			case r.db.LINETYPE.OPT_END:
			case r.db.LINETYPE.PAR_END:
			case r.db.LINETYPE.CRITICAL_END:
			case r.db.LINETYPE.BREAK_END:
				s = o.pop(), a[s.id] = s;
				break;
			case r.db.LINETYPE.ACTIVE_START:
				{
					let e = t.get(n.from ? n.from : n.to.actor), r = qe(n.from ? n.from : n.to.actor).length, i = e.x + e.width / 2 + (r - 1) * Z.activationWidth / 2, a = {
						startx: i,
						stopx: i + Z.activationWidth,
						actor: n.from,
						enabled: !0
					};
					Q.activations.push(a);
				}
				break;
			case r.db.LINETYPE.ACTIVE_END: {
				let e = Q.activations.map((e) => e.actor).lastIndexOf(n.from);
				Q.activations.splice(e, 1).splice(0, 1);
			}
		}
		n.placement === void 0 ? (l = ot(n, t, r), n.msgModel = l, l.startx && l.stopx && o.length > 0 && o.forEach((e) => {
			if (s = e, l.startx === l.stopx) {
				let e = t.get(n.from), r = t.get(n.to);
				s.from = i.getMin(e.x - l.width / 2, e.x - e.width / 2, s.from), s.to = i.getMax(r.x + l.width / 2, r.x + e.width / 2, s.to), s.width = i.getMax(s.width, Math.abs(s.to - s.from)) - Z.labelBoxWidth;
			} else s.from = i.getMin(l.startx, s.from), s.to = i.getMax(l.stopx, s.to), s.width = i.getMax(s.width, l.width) - Z.labelBoxWidth;
		})) : (c = await et(n, t, r), n.noteModel = c, o.forEach((e) => {
			s = e, s.from = i.getMin(s.from, c.startx), s.to = i.getMax(s.to, c.startx + c.width), s.width = i.getMax(s.width, Math.abs(s.from - s.to)) - Z.labelBoxWidth;
		}));
	}
	return Q.activations = [], h.debug("Loop type widths:", a), a;
}, "calculateLoopBounds"), ct = {
	parser: P,
	get db() {
		return new te();
	},
	renderer: {
		bounds: Q,
		drawActors: We,
		drawActorsPopup: Ge,
		setConf: Ke,
		draw: Xe
	},
	styles: ne,
	init: /* @__PURE__ */ w((e) => {
		e.sequence ||= {}, e.wrap && (e.sequence.wrap = e.wrap, g({ sequence: { wrap: e.wrap } }));
	}, "init")
};
//#endregion
export { ct as diagram };

//# sourceMappingURL=sequenceDiagram-WJ2MYXX4-DQ5hfP2m-DVNNmsSI.js.map