import { Ma as e } from "./index-B1FrxEMd-BsPMjC5n.js";
//#region ../react/build/sprintfjs-CjmCzARP.js
var t = {
	not_type: /[^T]/,
	not_primitive: /[^v]/,
	number: /[diefg]/,
	decimal_number: /[diefgu]/,
	numeric_arg: /[bcdiefguxX]/,
	json: /[j]/,
	text: /^[^\x25]+/,
	modulo: /^\x25{2}/,
	placeholder: /^\x25(?:([1-9]\d*)\$|\(([^)]+)\))?(\+)?(0|'[^$])?(-)?(,|_)?(\d+)?(?:\.(\d+))?([b-gijostTuvxX])/,
	key: /^([a-z_][a-z_\d]*)/i,
	key_access: /^\.([a-z_][a-z_\d]*)/i,
	index_access: /^\[(\d+)\]/,
	sign: /^[+-]/
}, n = /* @__PURE__ */ Object.create(null);
function r(e, t = ",") {
	let n = "", r = e;
	(r.startsWith("-") || r.startsWith("+")) && (n = r[0], r = r.slice(1));
	let i = r.indexOf("."), a, o;
	i === -1 ? a = r : (a = r.slice(0, i), o = r.slice(i));
	let s = a.replace(/\B(?=(\d{3})+(?!\d))/g, t);
	return n + s + (o ?? "");
}
function i(n, i) {
	let a = 1, o = n.length, s = "";
	for (let c = 0; c < o; c++) {
		let o = n[c];
		if (typeof o == "string") {
			s += o;
			continue;
		}
		let l = o, u;
		if (l.keys) {
			u = i[a];
			for (let t = 0; t < l.keys.length; t++) {
				if (e(u)) throw Error(`[sprintf] Cannot access property "${l.keys[t]}" of undefined value "${l.keys[t - 1]}"`);
				u = u[l.keys[t]];
			}
		} else u = l.param_no ? i[parseInt(l.param_no, 10)] : i[a++];
		if (t.not_type.test(l.type) && t.not_primitive.test(l.type) && typeof u == "function" && (u = u()), t.numeric_arg.test(l.type) && typeof u != "number" && isNaN(u)) throw TypeError(`[sprintf] expecting number but found ${Object.prototype.toString.call(u)}`);
		let d = !0;
		t.number.test(l.type) && (d = u >= 0);
		let f;
		switch (l.type) {
			case "b":
				f = parseInt(String(u), 10).toString(2);
				break;
			case "c":
				f = String.fromCharCode(parseInt(String(u), 10));
				break;
			case "d":
			case "i":
				f = String(parseInt(String(u), 10));
				break;
			case "j":
				f = JSON.stringify(u, null, l.width ? parseInt(l.width) : 0);
				break;
			case "e":
				f = l.precision ? parseFloat(String(u)).toExponential(parseInt(l.precision, 10)) : parseFloat(String(u)).toExponential();
				break;
			case "f":
				f = l.precision ? parseFloat(String(u)).toFixed(parseInt(l.precision, 10)) : String(parseFloat(String(u)));
				break;
			case "g":
				f = l.precision ? String(Number(u.toPrecision(parseInt(l.precision, 10)))) : String(parseFloat(String(u)));
				break;
			case "o":
				f = (parseInt(String(u), 10) >>> 0).toString(8);
				break;
			case "s":
				f = String(u), f = l.precision ? f.substring(0, parseInt(l.precision, 10)) : f;
				break;
			case "t":
				f = String(!!u), f = l.precision ? f.substring(0, parseInt(l.precision, 10)) : f;
				break;
			case "T":
				f = Object.prototype.toString.call(u).slice(8, -1).toLowerCase(), f = l.precision ? f.substring(0, parseInt(l.precision, 10)) : f;
				break;
			case "u":
				f = String(parseInt(String(u), 10) >>> 0);
				break;
			case "v":
				f = String(u.valueOf()), f = l.precision ? f.substring(0, parseInt(l.precision, 10)) : f;
				break;
			case "x":
				f = (parseInt(String(u), 10) >>> 0).toString(16);
				break;
			case "X":
				f = (parseInt(String(u), 10) >>> 0).toString(16).toUpperCase();
				break;
			default: f = String(u);
		}
		if (t.json.test(l.type)) s += f;
		else {
			let e = "";
			if (t.number.test(l.type) && (!d || l.sign) && (e = d ? "+" : "-", f = f.replace(t.sign, "")), l.thousand_sep && t.decimal_number.test(l.type)) {
				let e;
				e = l.thousand_sep === "_" ? "_" : l.pad_char?.startsWith("'") ? l.pad_char.charAt(1) : ",", f = r(f, e);
			}
			let n = l.pad_char ? l.pad_char === "0" ? "0" : l.pad_char.charAt(1) : " ", i = l.width ? parseInt(l.width, 10) : 0, a = i - (e + f).length, o = i && a > 0 ? n.repeat(a) : "";
			s += l.align ? e + f + o : n === "0" ? e + o + f : o + e + f;
		}
	}
	return s;
}
function a(e) {
	if (n[e]) return n[e];
	let r = e, i, a = [], o = 0;
	for (; r;) {
		if ((i = t.text.exec(r)) !== null) a.push(i[0]);
		else if ((i = t.modulo.exec(r)) !== null) a.push("%");
		else if ((i = t.placeholder.exec(r)) !== null) {
			if (i[2]) {
				o |= 1;
				let e = [], n = i[2], r;
				if ((r = t.key.exec(n)) !== null) for (e.push(r[1]); (n = n.substring(r[0].length)) !== "";) if ((r = t.key_access.exec(n)) !== null) e.push(r[1]);
				else if ((r = t.index_access.exec(n)) !== null) e.push(r[1]);
				else throw SyntaxError("[sprintf] failed to parse named argument key");
				else throw SyntaxError("[sprintf] failed to parse named argument key");
				i[2] = e.join(".");
			} else o |= 2;
			if (o === 3) throw Error("[sprintf] mixing positional and named placeholders is not (yet) supported");
			a.push({
				placeholder: i[0],
				param_no: i[1],
				keys: i[2] ? i[2].split(".") : void 0,
				sign: i[3],
				pad_char: i[4],
				align: i[5],
				thousand_sep: i[6],
				width: i[7],
				precision: i[8],
				type: i[9]
			});
		} else throw SyntaxError("[sprintf] unexpected placeholder");
		r = r.substring(i[0].length);
	}
	return n[e] = a, a;
}
function o(e, ...t) {
	return i(a(e), [e, ...t]);
}
//#endregion
export { o as t };

//# sourceMappingURL=sprintfjs-CjmCzARP-HuCjLGam.js.map