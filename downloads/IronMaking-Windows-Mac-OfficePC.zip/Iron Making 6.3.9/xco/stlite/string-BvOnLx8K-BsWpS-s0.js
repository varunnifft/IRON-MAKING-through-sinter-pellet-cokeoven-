//#region ../react/build/string-BvOnLx8K.js
function e(e, t, n) {
	e.prototype = t.prototype = n, n.constructor = e;
}
function t(e, t) {
	var n = Object.create(e.prototype);
	for (var r in t) n[r] = t[r];
	return n;
}
function n() {}
var r = .7, i = 1 / r, a = "\\s*([+-]?\\d+)\\s*", o = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*", s = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*", c = /^#([0-9a-f]{3,8})$/, l = RegExp(`^rgb\\(${a},${a},${a}\\)$`), u = RegExp(`^rgb\\(${s},${s},${s}\\)$`), d = RegExp(`^rgba\\(${a},${a},${a},${o}\\)$`), ee = RegExp(`^rgba\\(${s},${s},${s},${o}\\)$`), f = RegExp(`^hsl\\(${o},${s},${s}\\)$`), p = RegExp(`^hsla\\(${o},${s},${s},${o}\\)$`), m = {
	aliceblue: 15792383,
	antiquewhite: 16444375,
	aqua: 65535,
	aquamarine: 8388564,
	azure: 15794175,
	beige: 16119260,
	bisque: 16770244,
	black: 0,
	blanchedalmond: 16772045,
	blue: 255,
	blueviolet: 9055202,
	brown: 10824234,
	burlywood: 14596231,
	cadetblue: 6266528,
	chartreuse: 8388352,
	chocolate: 13789470,
	coral: 16744272,
	cornflowerblue: 6591981,
	cornsilk: 16775388,
	crimson: 14423100,
	cyan: 65535,
	darkblue: 139,
	darkcyan: 35723,
	darkgoldenrod: 12092939,
	darkgray: 11119017,
	darkgreen: 25600,
	darkgrey: 11119017,
	darkkhaki: 12433259,
	darkmagenta: 9109643,
	darkolivegreen: 5597999,
	darkorange: 16747520,
	darkorchid: 10040012,
	darkred: 9109504,
	darksalmon: 15308410,
	darkseagreen: 9419919,
	darkslateblue: 4734347,
	darkslategray: 3100495,
	darkslategrey: 3100495,
	darkturquoise: 52945,
	darkviolet: 9699539,
	deeppink: 16716947,
	deepskyblue: 49151,
	dimgray: 6908265,
	dimgrey: 6908265,
	dodgerblue: 2003199,
	firebrick: 11674146,
	floralwhite: 16775920,
	forestgreen: 2263842,
	fuchsia: 16711935,
	gainsboro: 14474460,
	ghostwhite: 16316671,
	gold: 16766720,
	goldenrod: 14329120,
	gray: 8421504,
	green: 32768,
	greenyellow: 11403055,
	grey: 8421504,
	honeydew: 15794160,
	hotpink: 16738740,
	indianred: 13458524,
	indigo: 4915330,
	ivory: 16777200,
	khaki: 15787660,
	lavender: 15132410,
	lavenderblush: 16773365,
	lawngreen: 8190976,
	lemonchiffon: 16775885,
	lightblue: 11393254,
	lightcoral: 15761536,
	lightcyan: 14745599,
	lightgoldenrodyellow: 16448210,
	lightgray: 13882323,
	lightgreen: 9498256,
	lightgrey: 13882323,
	lightpink: 16758465,
	lightsalmon: 16752762,
	lightseagreen: 2142890,
	lightskyblue: 8900346,
	lightslategray: 7833753,
	lightslategrey: 7833753,
	lightsteelblue: 11584734,
	lightyellow: 16777184,
	lime: 65280,
	limegreen: 3329330,
	linen: 16445670,
	magenta: 16711935,
	maroon: 8388608,
	mediumaquamarine: 6737322,
	mediumblue: 205,
	mediumorchid: 12211667,
	mediumpurple: 9662683,
	mediumseagreen: 3978097,
	mediumslateblue: 8087790,
	mediumspringgreen: 64154,
	mediumturquoise: 4772300,
	mediumvioletred: 13047173,
	midnightblue: 1644912,
	mintcream: 16121850,
	mistyrose: 16770273,
	moccasin: 16770229,
	navajowhite: 16768685,
	navy: 128,
	oldlace: 16643558,
	olive: 8421376,
	olivedrab: 7048739,
	orange: 16753920,
	orangered: 16729344,
	orchid: 14315734,
	palegoldenrod: 15657130,
	palegreen: 10025880,
	paleturquoise: 11529966,
	palevioletred: 14381203,
	papayawhip: 16773077,
	peachpuff: 16767673,
	peru: 13468991,
	pink: 16761035,
	plum: 14524637,
	powderblue: 11591910,
	purple: 8388736,
	rebeccapurple: 6697881,
	red: 16711680,
	rosybrown: 12357519,
	royalblue: 4286945,
	saddlebrown: 9127187,
	salmon: 16416882,
	sandybrown: 16032864,
	seagreen: 3050327,
	seashell: 16774638,
	sienna: 10506797,
	silver: 12632256,
	skyblue: 8900331,
	slateblue: 6970061,
	slategray: 7372944,
	slategrey: 7372944,
	snow: 16775930,
	springgreen: 65407,
	steelblue: 4620980,
	tan: 13808780,
	teal: 32896,
	thistle: 14204888,
	tomato: 16737095,
	turquoise: 4251856,
	violet: 15631086,
	wheat: 16113331,
	white: 16777215,
	whitesmoke: 16119285,
	yellow: 16776960,
	yellowgreen: 10145074
};
e(n, y, {
	copy(e) {
		return Object.assign(new this.constructor(), this, e);
	},
	displayable() {
		return this.rgb().displayable();
	},
	hex: h,
	formatHex: h,
	formatHex8: g,
	formatHsl: _,
	formatRgb: v,
	toString: v
});
function h() {
	return this.rgb().formatHex();
}
function g() {
	return this.rgb().formatHex8();
}
function _() {
	return M(this).formatHsl();
}
function v() {
	return this.rgb().formatRgb();
}
function y(e) {
	var t, n;
	return e = (e + "").trim().toLowerCase(), (t = c.exec(e)) ? (n = t[1].length, t = parseInt(t[1], 16), n === 6 ? b(t) : n === 3 ? new w(t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, (t & 15) << 4 | t & 15, 1) : n === 8 ? x(t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, (t & 255) / 255) : n === 4 ? x(t >> 12 & 15 | t >> 8 & 240, t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, ((t & 15) << 4 | t & 15) / 255) : null) : (t = l.exec(e)) ? new w(t[1], t[2], t[3], 1) : (t = u.exec(e)) ? new w(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, 1) : (t = d.exec(e)) ? x(t[1], t[2], t[3], t[4]) : (t = ee.exec(e)) ? x(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, t[4]) : (t = f.exec(e)) ? j(t[1], t[2] / 100, t[3] / 100, 1) : (t = p.exec(e)) ? j(t[1], t[2] / 100, t[3] / 100, t[4]) : m.hasOwnProperty(e) ? b(m[e]) : e === "transparent" ? new w(NaN, NaN, NaN, 0) : null;
}
function b(e) {
	return new w(e >> 16 & 255, e >> 8 & 255, e & 255, 1);
}
function x(e, t, n, r) {
	return r <= 0 && (e = t = n = NaN), new w(e, t, n, r);
}
function S(e) {
	return e instanceof n || (e = y(e)), e ? (e = e.rgb(), new w(e.r, e.g, e.b, e.opacity)) : new w();
}
function C(e, t, n, r) {
	return arguments.length === 1 ? S(e) : new w(e, t, n, r ?? 1);
}
function w(e, t, n, r) {
	this.r = +e, this.g = +t, this.b = +n, this.opacity = +r;
}
e(w, C, t(n, {
	brighter(e) {
		return e = e == null ? i : i ** +e, new w(this.r * e, this.g * e, this.b * e, this.opacity);
	},
	darker(e) {
		return e = e == null ? r : r ** +e, new w(this.r * e, this.g * e, this.b * e, this.opacity);
	},
	rgb() {
		return this;
	},
	clamp() {
		return new w(k(this.r), k(this.g), k(this.b), O(this.opacity));
	},
	displayable() {
		return -.5 <= this.r && this.r < 255.5 && -.5 <= this.g && this.g < 255.5 && -.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1;
	},
	hex: T,
	formatHex: T,
	formatHex8: E,
	formatRgb: D,
	toString: D
}));
function T() {
	return `#${A(this.r)}${A(this.g)}${A(this.b)}`;
}
function E() {
	return `#${A(this.r)}${A(this.g)}${A(this.b)}${A((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
}
function D() {
	let e = O(this.opacity);
	return `${e === 1 ? "rgb(" : "rgba("}${k(this.r)}, ${k(this.g)}, ${k(this.b)}${e === 1 ? ")" : `, ${e})`}`;
}
function O(e) {
	return isNaN(e) ? 1 : Math.max(0, Math.min(1, e));
}
function k(e) {
	return Math.max(0, Math.min(255, Math.round(e) || 0));
}
function A(e) {
	return e = k(e), (e < 16 ? "0" : "") + e.toString(16);
}
function j(e, t, n, r) {
	return r <= 0 ? e = t = n = NaN : n <= 0 || n >= 1 ? e = t = NaN : t <= 0 && (e = NaN), new P(e, t, n, r);
}
function M(e) {
	if (e instanceof P) return new P(e.h, e.s, e.l, e.opacity);
	if (e instanceof n || (e = y(e)), !e) return new P();
	if (e instanceof P) return e;
	e = e.rgb();
	var t = e.r / 255, r = e.g / 255, i = e.b / 255, a = Math.min(t, r, i), o = Math.max(t, r, i), s = NaN, c = o - a, l = (o + a) / 2;
	return c ? (s = t === o ? (r - i) / c + (r < i) * 6 : r === o ? (i - t) / c + 2 : (t - r) / c + 4, c /= l < .5 ? o + a : 2 - o - a, s *= 60) : c = l > 0 && l < 1 ? 0 : s, new P(s, c, l, e.opacity);
}
function N(e, t, n, r) {
	return arguments.length === 1 ? M(e) : new P(e, t, n, r ?? 1);
}
function P(e, t, n, r) {
	this.h = +e, this.s = +t, this.l = +n, this.opacity = +r;
}
e(P, N, t(n, {
	brighter(e) {
		return e = e == null ? i : i ** +e, new P(this.h, this.s, this.l * e, this.opacity);
	},
	darker(e) {
		return e = e == null ? r : r ** +e, new P(this.h, this.s, this.l * e, this.opacity);
	},
	rgb() {
		var e = this.h % 360 + (this.h < 0) * 360, t = isNaN(e) || isNaN(this.s) ? 0 : this.s, n = this.l, r = n + (n < .5 ? n : 1 - n) * t, i = 2 * n - r;
		return new w(L(e >= 240 ? e - 240 : e + 120, i, r), L(e, i, r), L(e < 120 ? e + 240 : e - 120, i, r), this.opacity);
	},
	clamp() {
		return new P(F(this.h), I(this.s), I(this.l), O(this.opacity));
	},
	displayable() {
		return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1;
	},
	formatHsl() {
		let e = O(this.opacity);
		return `${e === 1 ? "hsl(" : "hsla("}${F(this.h)}, ${I(this.s) * 100}%, ${I(this.l) * 100}%${e === 1 ? ")" : `, ${e})`}`;
	}
}));
function F(e) {
	return e = (e || 0) % 360, e < 0 ? e + 360 : e;
}
function I(e) {
	return Math.max(0, Math.min(1, e || 0));
}
function L(e, t, n) {
	return (e < 60 ? t + (n - t) * e / 60 : e < 180 ? n : e < 240 ? t + (n - t) * (240 - e) / 60 : t) * 255;
}
function R(e, t, n, r, i) {
	var a = e * e, o = a * e;
	return ((1 - 3 * e + 3 * a - o) * t + (4 - 6 * a + 3 * o) * n + (1 + 3 * e + 3 * a - 3 * o) * r + o * i) / 6;
}
function z(e) {
	var t = e.length - 1;
	return function(n) {
		var r = n <= 0 ? n = 0 : n >= 1 ? (n = 1, t - 1) : Math.floor(n * t), i = e[r], a = e[r + 1], o = r > 0 ? e[r - 1] : 2 * i - a, s = r < t - 1 ? e[r + 2] : 2 * a - i;
		return R((n - r / t) * t, o, i, a, s);
	};
}
function B(e) {
	var t = e.length;
	return function(n) {
		var r = Math.floor(((n %= 1) < 0 ? ++n : n) * t), i = e[(r + t - 1) % t], a = e[r % t], o = e[(r + 1) % t], s = e[(r + 2) % t];
		return R((n - r / t) * t, i, a, o, s);
	};
}
var V = (e) => () => e;
function H(e, t) {
	return function(n) {
		return e + n * t;
	};
}
function U(e, t, n) {
	return e **= +n, t = t ** +n - e, n = 1 / n, function(r) {
		return (e + r * t) ** +n;
	};
}
function W(e, t) {
	var n = t - e;
	return n ? H(e, n > 180 || n < -180 ? n - 360 * Math.round(n / 360) : n) : V(isNaN(e) ? t : e);
}
function G(e) {
	return (e = +e) == 1 ? K : function(t, n) {
		return n - t ? U(t, n, e) : V(isNaN(t) ? n : t);
	};
}
function K(e, t) {
	var n = t - e;
	return n ? H(e, n) : V(isNaN(e) ? t : e);
}
var q = function e(t) {
	var n = G(t);
	function r(e, t) {
		var r = n((e = C(e)).r, (t = C(t)).r), i = n(e.g, t.g), a = n(e.b, t.b), o = K(e.opacity, t.opacity);
		return function(t) {
			return e.r = r(t), e.g = i(t), e.b = a(t), e.opacity = o(t), e + "";
		};
	}
	return r.gamma = e, r;
}(1);
function J(e) {
	return function(t) {
		var n = t.length, r = Array(n), i = Array(n), a = Array(n), o, s;
		for (o = 0; o < n; ++o) s = C(t[o]), r[o] = s.r || 0, i[o] = s.g || 0, a[o] = s.b || 0;
		return r = e(r), i = e(i), a = e(a), s.opacity = 1, function(e) {
			return s.r = r(e), s.g = i(e), s.b = a(e), s + "";
		};
	};
}
var Y = J(z), X = J(B);
function Z(e, t) {
	return e = +e, t = +t, function(n) {
		return e * (1 - n) + t * n;
	};
}
var Q = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g, $ = new RegExp(Q.source, "g");
function te(e) {
	return function() {
		return e;
	};
}
function ne(e) {
	return function(t) {
		return e(t) + "";
	};
}
function re(e, t) {
	var n = Q.lastIndex = $.lastIndex = 0, r, i, a, o = -1, s = [], c = [];
	for (e += "", t += ""; (r = Q.exec(e)) && (i = $.exec(t));) (a = i.index) > n && (a = t.slice(n, a), s[o] ? s[o] += a : s[++o] = a), (r = r[0]) === (i = i[0]) ? s[o] ? s[o] += i : s[++o] = i : (s[++o] = null, c.push({
		i: o,
		x: Z(r, i)
	})), n = $.lastIndex;
	return n < t.length && (a = t.slice(n), s[o] ? s[o] += a : s[++o] = a), s.length < 2 ? c[0] ? ne(c[0].x) : te(t) : (t = c.length, function(e) {
		for (var n = 0, r; n < t; ++n) s[(r = c[n]).i] = r.x(e);
		return s.join("");
	});
}
//#endregion
export { S as _, K as a, Z as b, W as c, re as d, Y as f, e as g, w as h, t as i, X as l, n as m, V as n, C as o, B as p, y as r, r as s, i as t, z as u, N as v, q as y };

//# sourceMappingURL=string-BvOnLx8K-BsWpS-s0.js.map