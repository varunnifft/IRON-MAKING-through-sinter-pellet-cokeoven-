import "./transform-B2AI7qp--hg0kwf7R.js";
import { Y as e, b6 as t, b8 as n, c as r } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
//#region ../react/build/swimlanes-42K2YHIH-BxH86fKc.js
var i = 5, a = 1e-5, o = 1e-6;
function s(e) {
	let t = [];
	for (let n = 0; n < e.length - 1; n++) t.push({
		a: e[n],
		b: e[n + 1]
	});
	return t;
}
r(s, "buildSegmentList");
function c(e, t, n, r) {
	let i = t.x - e.x, a = t.y - e.y, s = r.x - n.x, c = r.y - n.y, l = i * c - a * s;
	if (l === 0) return null;
	let u = n.x - e.x, d = n.y - e.y, f = (u * c - d * s) / l, p = (u * a - d * i) / l;
	return f <= o || f >= 1 - o || p <= o || p >= 1 - o ? null : {
		point: {
			x: e.x + f * i,
			y: e.y + f * a
		},
		tA: f,
		tB: p
	};
}
r(c, "segmentIntersection");
function l(e) {
	return Math.abs(e.b.x - e.a.x) >= Math.abs(e.b.y - e.a.y);
}
r(l, "isHorizontalSeg");
function u(e) {
	let t = [];
	for (let n = 0; n < e.length; n++) {
		let r = e[n], i = s(r.points);
		for (let a = n + 1; a < e.length; a++) {
			let n = e[a], o = s(n.points);
			for (let [e, a] of i.entries()) for (let [i, s] of o.entries()) {
				let o = c(a.a, a.b, s.a, s.b);
				if (!o) continue;
				let u = l(a);
				u !== l(s) && u ? t.push({
					jumpEdgeId: r.id,
					otherEdgeId: n.id,
					segIndex: e,
					t: o.tA,
					point: o.point
				}) : t.push({
					jumpEdgeId: n.id,
					otherEdgeId: r.id,
					segIndex: i,
					t: o.tB,
					point: o.point
				});
			}
		}
	}
	return t;
}
r(u, "findEdgeIntersections");
function d(e) {
	return `${Math.round(e * 1e3) / 1e3}`;
}
r(d, "fmt");
function f(e) {
	return `${d(e.x)},${d(e.y)}`;
}
r(f, "pointToString");
function p(e) {
	let t = e.b.x - e.a.x, n = e.b.y - e.a.y;
	return Math.abs(t) >= Math.abs(n) ? +(t >= 0) : +(n >= 0);
}
r(p, "getArcSweepFlag");
var m = .001;
function h(e, t) {
	if (e.length < 2) return e.map((e) => ({ ...e }));
	let r = e.map((e) => ({ ...e })), i = t.arrowTypeStart && n[t.arrowTypeStart];
	if (i) {
		let t = e[0], n = e[1], a = Math.atan2(n.y - t.y, n.x - t.x);
		r[0].x = t.x + i * Math.cos(a), r[0].y = t.y + i * Math.sin(a);
	}
	let a = t.arrowTypeEnd && n[t.arrowTypeEnd];
	if (a) {
		let t = e.length, n = e[t - 2], i = e[t - 1], o = Math.atan2(i.y - n.y, i.x - n.x);
		r[t - 1].x = i.x - a * Math.cos(o), r[t - 1].y = i.y - a * Math.sin(o);
	}
	return r;
}
r(h, "applyMarkerOffsets");
function g(e, t, n, r, i) {
	let a = e.point.x, o = e.point.y, s = {
		x: a - t * e.r,
		y: o - n * e.r
	}, c = {
		x: a + t * e.r,
		y: o + n * e.r
	}, l = [`L${f(s)}`];
	return i === "arc" ? l.push(`A${d(e.r)},${d(e.r)} 0 0 ${r} ${f(c)}`) : l.push(`M${f(c)}`), l;
}
r(g, "emitJump");
function _(e, t, n, r) {
	let i = t.x - e.x, o = t.y - e.y, s = n.x - t.x, c = n.y - t.y, l = Math.hypot(i, o), u = Math.hypot(s, c);
	if (l < a || u < a) return null;
	let d = i / l, f = o / l, p = s / u, m = c / u, h = d * p + f * m, g = Math.acos(Math.max(-1, Math.min(1, h)));
	if (g < a || Math.abs(Math.PI - g) < a) return null;
	let _ = Math.min(r / Math.sin(g / 2), l / 2, u / 2);
	return {
		startX: t.x - d * _,
		startY: t.y - f * _,
		endX: t.x + p * _,
		endY: t.y + m * _,
		ctrlX: t.x,
		ctrlY: t.y,
		cutLen: _
	};
}
r(_, "computeRoundedCorner");
function v(e, t, n) {
	let r = e.points;
	if (r.length < 2) return "";
	let a = h(r, e), o = e.curve === "rounded", c = s(a), l = /* @__PURE__ */ new Map();
	for (let e of t) {
		let t = c[e.segIndex];
		if (!t) continue;
		let r = Math.hypot(t.b.x - t.a.x, t.b.y - t.a.y), i = l.get(e.segIndex) ?? [];
		i.push({
			t: e.t,
			point: e.point,
			d: e.t * r,
			r: n.jumpRadius
		}), l.set(e.segIndex, i);
	}
	let u = [`M${f(a[0])}`];
	for (let e = 0; e < c.length; e++) {
		let t = c[e], r = Math.hypot(t.b.x - t.a.x, t.b.y - t.a.y), s = r === 0 ? 0 : (t.b.x - t.a.x) / r, h = r === 0 ? 0 : (t.b.y - t.a.y) / r, v = p(t), y = 0;
		if (o && e > 0) {
			let t = _(a[e - 1], a[e], a[e + 1] ?? a[e], i);
			t && (y = t.cutLen);
		}
		let b = r, x = null;
		o && e < c.length - 1 && (x = _(a[e], a[e + 1], a[e + 2] ?? a[e + 1], i), x && (b = r - x.cutLen));
		let S = [...l.get(e) ?? []].sort((e, t) => e.t - t.t);
		for (let e of S) e.r = Math.min(e.r, e.d - y, b - e.d);
		for (let e = 0; e < S.length - 1; e++) {
			let t = S[e + 1].d - S[e].d;
			if (S[e].r + S[e + 1].r > t) {
				let n = t / 2;
				S[e].r = Math.min(S[e].r, n), S[e + 1].r = Math.min(S[e + 1].r, n);
			}
		}
		for (let e of S) e.r < m || u.push(...g(e, s, h, v, n.jumpStyle));
		o && x ? (u.push(`L${d(x.startX)},${d(x.startY)}`), u.push(`Q${d(x.ctrlX)},${d(x.ctrlY)} ${d(x.endX)},${d(x.endY)}`)) : u.push(`L${f(t.b)}`);
	}
	return u.join(" ");
}
r(v, "rewriteEdgePath");
function y(e) {
	return /^[\d\s+,.LMelm-]*$/.test(e);
}
r(y, "isStraightPath");
function b(e) {
	return !e || e === "linear" || e === "rounded" || e === "step" || e === "stepBefore" || e === "stepAfter";
}
r(b, "curveSupportsLineHops");
function x(e) {
	if (!e) return null;
	try {
		let t = typeof atob == "function" ? atob(e) : Buffer.from(e, "base64").toString(), n = JSON.parse(t);
		if (!Array.isArray(n)) return null;
		let r = [];
		for (let e of n) e && typeof e.x == "number" && typeof e.y == "number" && r.push({
			x: e.x,
			y: e.y
		});
		return r.length >= 2 ? r : null;
	} catch {
		return null;
	}
}
r(x, "decodeDataPoints");
function S(e, t, n) {
	if (!n.enabled) return;
	let r = e.node();
	if (!r) return;
	let i = /* @__PURE__ */ new Map();
	for (let e of t) i.set(e.id, e);
	let a = [], o = /* @__PURE__ */ new Map();
	for (let e of t) {
		let t = typeof CSS < "u" && CSS.escape ? CSS.escape(e.id) : e.id, n = r.querySelector(`path[data-id="${t}"]`);
		if (!n) continue;
		o.set(e.id, n);
		let i = x(n.getAttribute("data-points")) ?? e.points;
		a.push({
			...e,
			points: i
		});
	}
	let s = u(a);
	if (s.length === 0) return;
	let c = /* @__PURE__ */ new Map();
	for (let e of s) {
		let t = c.get(e.jumpEdgeId) ?? [];
		t.push(e), c.set(e.jumpEdgeId, t);
	}
	for (let e of a) {
		let t = c.get(e.id);
		if (!t || t.length === 0) continue;
		let r = i.get(e.id)?.curve;
		if (r !== void 0 && !b(r)) continue;
		let a = o.get(e.id);
		if (!a || r === void 0 && !y(a.getAttribute("d") ?? "")) continue;
		let s = a.getAttribute("style") ?? "", l = /stroke-dasharray\s*:\s*0\s+([\d.]+)\s+[\d.]+\s+([\d.]+)/.exec(s), u = l ? Number.parseFloat(l[1]) : null, d = l ? Number.parseFloat(l[2]) : null, f = v(e, t, n);
		if (a.setAttribute("d", f), u !== null && d !== null && typeof a.getTotalLength == "function") {
			let e = a.getTotalLength(), t = `0 ${u} ${Math.max(0, e - u - d)} ${d}`, n = s.replace(/stroke-dasharray\s*:[^;]*;?/g, `stroke-dasharray: ${t};`).replace(/;\s*;+/g, ";");
			a.setAttribute("style", n);
		}
	}
}
r(S, "applyLineJumpsToSvg");
function C(e, { measure: t }) {
	let n = e.config?.swimlane?.lineHops;
	if (n === !1) return;
	let r = n === "gap" ? "gap" : "arc", i = e.edges.filter((e) => Array.isArray(e.points) && e.points.length >= 2).map((e) => ({
		id: e.id,
		points: e.points,
		curve: e.curve,
		arrowTypeStart: e.arrowTypeStart,
		arrowTypeEnd: e.arrowTypeEnd
	}));
	S(t.groups.edgePaths, i, {
		enabled: !0,
		jumpRadius: 6,
		jumpStyle: r
	});
}
r(C, "applySwimlaneLineJumps");
var w = "__swimlane_default__", T = 21, E = 20;
function D(e) {
	return Math.max(e.padding ?? E, E);
}
r(D, "topLaneHorizontalPadding");
function O(e) {
	let { x: t, y: n, width: r, height: i } = e, a = e.swimlaneContentTop;
	if (typeof t != "number" || typeof n != "number" || typeof r != "number" || typeof i != "number" || typeof a != "number" || !Number.isFinite(t) || !Number.isFinite(n) || !Number.isFinite(r) || !Number.isFinite(i) || !Number.isFinite(a) || r <= 0 || i <= 0) {
		delete e.groupTitleRect;
		return;
	}
	let o = n - i / 2, s = Math.min(a, n + i / 2), c = o + Math.min(T, Math.max(0, s - o));
	if (c <= o) {
		delete e.groupTitleRect;
		return;
	}
	e.groupTitleRect = {
		left: t - r / 2,
		right: t + r / 2,
		top: o,
		bottom: c
	};
}
r(O, "assignTopLaneTitleRect");
function k(e) {
	let t = e.direction, n = e.nodes ??= [];
	for (let n of e.nodes ?? []) n.isGroup && !n.parentId && (n.shape = "swimlane", t && (n.direction = t));
	let r = n.filter((e) => !e.isGroup && !e.parentId);
	if (r.length === 0) return;
	let i = n.find((e) => e.id === w);
	i ? i.isGroup && (i.shape = "swimlane", t && (i.direction = t)) : (i = {
		id: w,
		label: "",
		isGroup: !0,
		shape: "swimlane",
		padding: 20,
		...t ? { direction: t } : {}
	}, n.push(i));
	for (let e of r) e.parentId = w;
}
r(k, "prepareLayoutForSwimlanes");
function A(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.nodes ?? []) t.set(n.id, n);
	let n = [];
	for (let t of e.edges ?? []) {
		let e = typeof t.start == "string" ? t.start : void 0, r = typeof t.end == "string" ? t.end : void 0;
		!e || !r || t.labelNodeId || n.push({
			id: t.id,
			src: e,
			dst: r,
			ref: t
		});
	}
	let r = e.nodes ?? [], i = r.filter((e) => e.isGroup), a = r.filter((e) => !e.isGroup);
	return {
		nodes: [...[...i].reverse(), ...a].map((e) => e.id),
		edges: n,
		layout: e,
		nodeById: t
	};
}
r(A, "toGraphView");
function j(e, t, n, r) {
	let { layout: i } = e, a = e.nodeById, o = r?.layerGap ?? 100, s = r?.nodeGap ?? 40, c = 0;
	for (let e of t.layers) {
		let t = 0;
		for (let r of e) {
			let e = a.get(r);
			if (!e) {
				t++;
				continue;
			}
			e.layer = c, e.order = t;
			let i = n.x[r] ?? t * s, l = n.y[r] ?? c * o;
			e.x = i, e.y = l, t++;
		}
		c++;
	}
	let l = i.nodes ?? [], u = /* @__PURE__ */ new Map(), d = [];
	for (let e of l) {
		if (!e?.isGroup) continue;
		e.parentId || d.push(e);
		let t = l.filter((t) => t.parentId === e.id), r = 1 / 0, i = -1 / 0, a = 1 / 0, o = -1 / 0;
		for (let e of t) {
			let t = e.x ?? n.x[e.id], s = e.y ?? n.y[e.id], c = e.width ?? 0, l = e.height ?? 0;
			t != null && s != null && (r = Math.min(r, t - c / 2), i = Math.max(i, t + c / 2), a = Math.min(a, s - l / 2), o = Math.max(o, s + l / 2));
		}
		if (r === 1 / 0 || a === 1 / 0) e.x = e.x ?? 0, e.y = e.y ?? 0, e.width = e.width ?? 0, e.height = e.height ?? 0;
		else {
			let t = e.padding ?? 20, n = e.parentId ? t : 2 * D(e), s = t, c = Math.max(0, i - r) + n, l = Math.max(0, o - a) + s, d = (r + i) / 2, f = (a + o) / 2;
			e.x = d, e.y = f, e.width = c, e.height = l, u.set(e.id, {
				minX: r,
				maxX: i,
				minY: a,
				maxY: o
			});
		}
	}
	if (d.length > 0 && u.size > 0) {
		let e = 1 / 0, t = -1 / 0, n = 0;
		for (let r of d) {
			let i = r.padding ?? 20;
			i > n && (n = i);
			let a = u.get(r.id);
			a && (e = Math.min(e, a.minY), t = Math.max(t, a.maxY));
		}
		if (e !== 1 / 0 && t !== -1 / 0) {
			let r = Math.max(0, t - e) + 2 * Math.max(n, 36), i = (e + t) / 2;
			for (let t of d) t.y = i, t.height = r, t.swimlaneContentTop = e;
			let a = [...d].sort((e, t) => (e.x ?? 0) - (t.x ?? 0)), o = [], s = [], c = [];
			for (let e of a) {
				let t = u.get(e.id);
				if (!t) continue;
				let n = Math.max(0, t.maxX - t.minX) + 2 * D(e), r = (t.minX + t.maxX) / 2;
				o.push(e.id), s.push(r), c.push(n);
			}
			let l = o.length;
			if (l > 0) {
				let e = /* @__PURE__ */ new Map();
				if (l === 1) e.set(o[0], c[0]);
				else {
					let t = [];
					for (let e = 0; e < l - 1; e++) t.push(s[e + 1] - s[e]);
					let n = Array(l);
					n[0] = 0;
					for (let e = 0; e < l - 1; e++) n[e + 1] = 2 * t[e] - n[e];
					let r = 0, i = Infinity;
					for (let e = 0; e < l; e++) {
						let t = c[e];
						e % 2 == 0 ? r = Math.max(r, t - n[e]) : i = Math.min(i, n[e] - t);
					}
					let a = r;
					a = r <= i ? (r + i) / 2 : r;
					for (let t = 0; t < l; t++) {
						let r = n[t] + (t % 2 == 0 ? a : -a), i = Math.max(c[t], r);
						e.set(o[t], i);
					}
				}
				for (let t of d) {
					let n = e.get(t.id);
					n != null && (t.width = n), O(t);
				}
			}
		}
	}
}
r(j, "writeBackToLayoutData");
var ee = "[EdgeLabelNodes]";
function te(e) {
	let n = [], r = [], i = /* @__PURE__ */ new Map();
	for (let t of e.nodes) i.set(t.id, t);
	for (let a of e.edges) {
		if (!a.label || a.label.length === 0 || a.isLayoutOnly || a.labelNodeId) continue;
		let e = a.start ? i.get(a.start) : void 0, o = a.end ? i.get(a.end) : void 0;
		if (!e || !o) {
			t.warn(ee, `Edge ${a.id} has missing source or target node`);
			continue;
		}
		let s = `edge-label-${a.start}-${a.end}-${a.id}`, c = e.parentId === o.parentId ? e.parentId : o.parentId, l = {
			id: s,
			label: a.label,
			edgeStart: a.start ?? "",
			edgeEnd: a.end ?? "",
			shape: "labelRect",
			width: 0,
			height: 0,
			isEdgeLabel: !0,
			isDummy: !0,
			parentId: c,
			isGroup: !1,
			labelStyle: Array.isArray(a.labelStyle) ? a.labelStyle[0] : a.labelStyle ?? "",
			...e.dir ? { dir: e.dir } : {}
		};
		n.push(l), a.labelNodeId = s, a.label = void 0, a.text = void 0;
		let u = {
			id: `${a.id}-to-label`,
			start: a.start,
			end: s,
			type: "normal",
			isLayoutOnly: !0
		}, d = {
			id: `${a.id}-from-label`,
			start: s,
			end: a.end,
			type: "normal",
			isLayoutOnly: !0
		};
		r.push(u, d);
	}
	let a = [...e.nodes, ...n], o = [...e.edges, ...r];
	return {
		...e,
		nodes: a,
		edges: o
	};
}
r(te, "createEdgeLabelNodes");
var M = .001;
function ne(e) {
	let t = e.x ?? 0, n = e.y ?? 0, r = e.width ?? 0, i = e.height ?? 0;
	return r > 0 && i > 0 ? {
		cx: t,
		cy: n,
		rect: ce(t, n, r, i)
	} : void 0;
}
r(ne, "measuredNodeRect");
function re(e) {
	if (e.isGroup) return;
	let t = ne(e);
	return t ? {
		id: String(e.id ?? ""),
		cx: t.cx,
		cy: t.cy,
		rect: t.rect
	} : void 0;
}
r(re, "nodeBoundsInfoFor");
function N(e, t, n = M) {
	return Math.abs(e.x - t.x) < n && Math.abs(e.y - t.y) < n;
}
r(N, "samePoint");
function P(e, t, n = M) {
	return Math.abs(e.x - t.x) < n;
}
r(P, "sameX");
function F(e, t, n = M) {
	return Math.abs(e.y - t.y) < n;
}
r(F, "sameY");
function I(e, t, n = M) {
	return F(e, t, n) && Math.abs(e.x - t.x) > n;
}
r(I, "isHorizontalSegment");
function L(e, t, n = M) {
	return P(e, t, n) && Math.abs(e.y - t.y) > n;
}
r(L, "isVerticalSegment");
function R(e, t, n, r) {
	return Math.max(0, Math.min(Math.max(e, t), Math.max(n, r)) - Math.max(Math.min(e, t), Math.min(n, r)));
}
r(R, "overlapLength");
function z(e, t, n = M) {
	return e.horizontal && t.horizontal && F(e.a, t.a, n) ? R(e.a.x, e.b.x, t.a.x, t.b.x) : e.vertical && t.vertical && P(e.a, t.a, n) ? R(e.a.y, e.b.y, t.a.y, t.b.y) : 0;
}
r(z, "sameAxisSegmentOverlapLength");
function ie(e, t = M) {
	let n = [];
	for (let r = 0; r < e.length - 1; r++) {
		let i = e[r], a = e[r + 1], o = I(i, a, t), s = L(i, a, t);
		(o || s) && n.push({
			index: r,
			a: i,
			b: a,
			horizontal: o,
			vertical: s
		});
	}
	return n;
}
r(ie, "orthogonalSegmentsForPoints");
function B(e, t = M) {
	let n = ie(e, t), r = 0;
	for (let e = 1; e < n.length; e++) n[e - 1].horizontal !== n[e].horizontal && r++;
	return r;
}
r(B, "countOrthogonalBends");
function V(e, t = M) {
	let n = [];
	for (let r of e) {
		let e = n.length > 0 ? n[n.length - 1] : void 0;
		(!e || !N(e, r, t)) && n.push({
			x: r.x,
			y: r.y
		});
	}
	return n;
}
r(V, "dedupeConsecutivePoints");
function ae(e, t = M) {
	if (!e || e.length !== 4) return;
	let [n, r, i, a] = e;
	return I(n, r, t) && L(r, i, t) && I(i, a, t) ? {
		kind: "HVH",
		p0: n,
		p1: r,
		p2: i,
		p3: a
	} : L(n, r, t) && I(r, i, t) && L(i, a, t) ? {
		kind: "VHV",
		p0: n,
		p1: r,
		p2: i,
		p3: a
	} : void 0;
}
r(ae, "classifyThreeSegmentRoute");
function oe(e, t, n, r = 0) {
	let i = Math.min(e.x, t.x), a = Math.max(e.x, t.x), o = Math.min(e.y, t.y), s = Math.max(e.y, t.y);
	return a > n.left - r && i < n.right + r && s > n.top - r && o < n.bottom + r;
}
r(oe, "segmentBoundsOverlapRect");
function H(e, t, n = 0) {
	return e.x > t.left + n && e.x < t.right - n && e.y > t.top + n && e.y < t.bottom - n;
}
r(H, "pointInsideRect");
function U(e, t) {
	return e.left <= t.left && e.right >= t.right && e.top <= t.top && e.bottom >= t.bottom;
}
r(U, "rectContainsRect");
function W(e, t) {
	return e.left < t.right && e.right > t.left && e.top < t.bottom && e.bottom > t.top;
}
r(W, "rectsOverlap");
function se(e, t) {
	return {
		left: e.left - t,
		right: e.right + t,
		top: e.top - t,
		bottom: e.bottom + t
	};
}
r(se, "inflateRect");
function ce(e, t, n, r) {
	return {
		left: e - n / 2,
		right: e + n / 2,
		top: t - r / 2,
		bottom: t + r / 2
	};
}
r(ce, "rectFromCenterSize");
function G(e) {
	return ne(e)?.rect;
}
r(G, "rectOfNodeBounds");
function le(e, t) {
	switch (t) {
		case "top": return {
			x: e.cx,
			y: e.rect.top
		};
		case "bottom": return {
			x: e.cx,
			y: e.rect.bottom
		};
		case "left": return {
			x: e.rect.left,
			y: e.cy
		};
		case "right": return {
			x: e.rect.right,
			y: e.cy
		};
	}
}
r(le, "portForRectSide");
function ue(e, t, n, r, i, a = M) {
	let o = t === "left" || t === "right", s = r === "left" || r === "right";
	if (o && s) {
		if (t === "right" && r === "left" && e.x < n.x || t === "left" && r === "right" && e.x > n.x) {
			if (F(e, n, a)) return [e, n];
			let t = (e.x + n.x) / 2;
			return [
				e,
				{
					x: t,
					y: e.y
				},
				{
					x: t,
					y: n.y
				},
				n
			];
		}
		if (t === r) {
			if (F(e, n, a)) return;
			let r = t === "left" ? Math.min(e.x, n.x) - i : Math.max(e.x, n.x) + i;
			return [
				e,
				{
					x: r,
					y: e.y
				},
				{
					x: r,
					y: n.y
				},
				n
			];
		}
		return;
	}
	if (!o && !s) {
		if (t === r) {
			if (P(e, n, a)) return;
			let r = t === "top" ? Math.min(e.y, n.y) - i : Math.max(e.y, n.y) + i;
			return [
				e,
				{
					x: e.x,
					y: r
				},
				{
					x: n.x,
					y: r
				},
				n
			];
		}
		if (!(t === "bottom" && r === "top" && e.y < n.y || t === "top" && r === "bottom" && e.y > n.y)) return;
		if (P(e, n, a)) return [e, n];
		let o = (e.y + n.y) / 2;
		return [
			e,
			{
				x: e.x,
				y: o
			},
			{
				x: n.x,
				y: o
			},
			n
		];
	}
	if (o && !s) {
		let i = t === "right" && n.x > e.x || t === "left" && n.x < e.x, a = r === "top" && e.y < n.y || r === "bottom" && e.y > n.y;
		return i && a ? [
			e,
			{
				x: n.x,
				y: e.y
			},
			n
		] : void 0;
	}
	let c = t === "bottom" && n.y > e.y || t === "top" && n.y < e.y, l = r === "left" && e.x < n.x || r === "right" && e.x > n.x;
	return c && l ? [
		e,
		{
			x: e.x,
			y: n.y
		},
		n
	] : void 0;
}
r(ue, "buildOrthogonalPortPath");
function de(e, t, n, r) {
	return t === "left" || t === "right" ? [
		e,
		{
			x: r,
			y: e.y
		},
		{
			x: r,
			y: n.y
		},
		n
	] : [
		e,
		{
			x: e.x,
			y: r
		},
		{
			x: n.x,
			y: r
		},
		n
	];
}
r(de, "buildSameSideTrackPath");
function fe(e) {
	let t = /* @__PURE__ */ new Map(), n = [];
	for (let r of e) {
		if (r.isEdgeLabel) continue;
		let e = re(r);
		e && (t.set(e.id, e), n.push({
			id: e.id,
			rect: e.rect
		}));
	}
	return {
		nodeInfoById: t,
		realNodeRects: n
	};
}
r(fe, "collectRealNodeBounds");
function K(e) {
	let t = [], n = [];
	for (let r of e) {
		let e = re(r);
		if (!e) continue;
		let i = {
			id: e.id,
			rect: e.rect
		};
		r.isEdgeLabel ? n.push(i) : t.push(i);
	}
	return {
		realNodeRects: t,
		labelNodeRects: n
	};
}
r(K, "collectNodeRectEntries");
function pe(e, { includeEdgeLabels: t = !0 } = {}) {
	let n = [];
	for (let r of e) {
		if (r.isGroup || !t && r.isEdgeLabel) continue;
		let e = r.x ?? 0, i = r.y ?? 0, a = r.width ?? 0, o = r.height ?? 0;
		n.push({
			nodeId: r.id,
			...ce(e, i, a, o)
		});
	}
	return n;
}
r(pe, "collectLayoutNodeRects");
function me(e, t, n = M) {
	let r = e.start, i = e.end;
	if (!r || !i) return;
	let a = t.get(r), o = t.get(i);
	if (!(!a || !o)) return {
		srcId: r,
		dstId: i,
		srcInfo: a,
		dstInfo: o,
		collinearX: Math.abs(a.cx - o.cx) < n,
		collinearY: Math.abs(a.cy - o.cy) < n
	};
}
r(me, "getNodePairGeometry");
function q(e, t, n, r = [], i = 0) {
	for (let a of n) if (!r.includes(a.id) && oe(e, t, a.rect, -i)) return !0;
	return !1;
}
r(q, "segmentHitsAnyRect");
function he(e, t, n, r, i = M, a = 1e-6) {
	let o = F(e, t, i), s = P(e, t, i), c = F(n, r, i), l = P(n, r, i);
	if (o && c || s && l || !(o || s) || !(c || l)) return !1;
	let u = o ? {
		a: e,
		b: t
	} : {
		a: n,
		b: r
	}, d = s ? {
		a: e,
		b: t
	} : {
		a: n,
		b: r
	}, f = u.a.y, p = Math.min(u.a.x, u.b.x), m = Math.max(u.a.x, u.b.x), h = d.a.x, g = Math.min(d.a.y, d.b.y), _ = Math.max(d.a.y, d.b.y);
	if (h < p || h > m || f < g || f > _) return !1;
	let v = Math.abs(h - u.a.x) < a && Math.abs(f - u.a.y) < a || Math.abs(h - u.b.x) < a && Math.abs(f - u.b.y) < a, y = Math.abs(h - d.a.x) < a && Math.abs(f - d.a.y) < a || Math.abs(h - d.b.x) < a && Math.abs(f - d.b.y) < a;
	return !(v && y);
}
r(he, "orthogonalSegmentsCross");
function ge(e, t, n, r, i = M) {
	let a = F(e, t, i), o = P(e, t, i), s = F(n, r, i), c = P(n, r, i);
	return o && c && P(e, n, i) ? R(e.y, t.y, n.y, r.y) > i : a && s && F(e, n, i) ? R(e.x, t.x, n.x, r.x) > i : !1;
}
r(ge, "sameAxisSegmentsOverlap");
function _e(e, t, n, r, { epsilon: i = M, skipDegenerateOther: a = !1 } = {}) {
	for (let o of n) {
		if (o === r || o.isLayoutOnly) continue;
		let n = o.points;
		if (!(!n || n.length < 2)) for (let r = 0; r < n.length - 1; r++) {
			let o = n[r], s = n[r + 1];
			if (!(a && N(o, s, i)) && (he(e, t, o, s, i) || ge(e, t, o, s, i))) return !0;
		}
	}
	return !1;
}
r(_e, "segmentConflictsWithAnyEdge");
function ve(e, t, n, r, i = M) {
	let a = F(e, t, i), o = P(e, t, i), s = F(n, r, i), c = P(n, r, i);
	if (!(a && c || o && s)) return !1;
	let l = a ? {
		a: e,
		b: t
	} : {
		a: n,
		b: r
	}, u = a ? {
		a: n,
		b: r
	} : {
		a: e,
		b: t
	}, d = l.a.y, f = Math.min(l.a.x, l.b.x), p = Math.max(l.a.x, l.b.x), m = u.a.x, h = Math.min(u.a.y, u.b.y), g = Math.max(u.a.y, u.b.y);
	return m > f + i && m < p - i && d > h + i && d < g - i;
}
r(ve, "orthogonalSegmentsStrictlyCross");
function ye(e, t, n) {
	let r = Math.min(t, n), i = Math.max(t, n);
	return e > r + M && e < i - M;
}
r(ye, "strictlyBetween");
function be(e, t, n) {
	return P(e, t) && P(t, n) ? ye(t.y, e.y, n.y) : F(e, t) && F(t, n) ? ye(t.x, e.x, n.x) : !1;
}
r(be, "isCollinearIntermediate");
function xe(e) {
	let t = !1, n = [];
	for (let r = 0; r < e.length; r++) {
		let i = n[n.length - 1], a = e[r], o = r + 1 < e.length ? e[r + 1] : void 0;
		if (i && o) {
			if (N(i, o)) {
				r++, t = !0;
				continue;
			}
			if (be(i, a, o)) {
				t = !0;
				continue;
			}
		}
		n.push(a);
	}
	return {
		points: n,
		changed: t
	};
}
r(xe, "simplifyPolylineOnce");
function Se(e) {
	let t = [e[0]];
	for (let n = 1; n < e.length; n++) {
		let r = t[t.length - 1], i = e[n];
		if (!P(r, i) && !F(r, i)) {
			let e = t.length >= 2 ? t[t.length - 2] : void 0, n = e && P(e, r) ? {
				x: r.x,
				y: i.y
			} : {
				x: i.x,
				y: r.y
			};
			t.push(n);
		}
		t.push(i);
	}
	let n = [];
	for (let e of t) {
		let t = n[n.length - 1];
		(!t || !N(t, e)) && n.push(e);
	}
	return n;
}
r(Se, "orthogonalizePolyline");
function Ce(e) {
	if (e.length < 3) return e;
	let t = [...e];
	for (let e = 0; e < 32; e++) {
		let e = xe(t);
		if (t = e.points, !e.changed) break;
	}
	return t;
}
r(Ce, "simplifyPolyline");
var J = .001, we = .5, Te = 4;
function Ee(e, t, n) {
	let r = e;
	if (r.isLayoutOnly || !r.points || r.points.length < n) return;
	let i = r.start ? t.get(r.start) : void 0, a = r.end ? t.get(r.end) : void 0;
	return {
		edge: r,
		points: r.points,
		srcRect: i ? G(i) : void 0,
		dstRect: a ? G(a) : void 0
	};
}
r(Ee, "endpointContextFor");
function De(e, t, n) {
	if (F(e, t, J)) return {
		x: e.x < n.left ? n.left : n.right,
		y: e.y
	};
	if (P(e, t, J)) {
		let t = e.y < n.top ? n.top : n.bottom;
		return {
			x: e.x,
			y: t
		};
	}
	return {
		x: Math.min(n.right, Math.max(n.left, e.x)),
		y: Math.min(n.bottom, Math.max(n.top, e.y))
	};
}
r(De, "segmentEnterPoint");
function Oe(e, t, n) {
	let r = n ? 1 : -1, i = n ? 0 : e.length - 1;
	for (; i >= 0 && i < e.length && H(e[i], t, we);) i += r;
	if (i < 0 || i >= e.length) return e;
	let a = i - r;
	if (a < 0 || a >= e.length) return e;
	let o = De(e[i], e[a], t);
	return n ? [o, ...e.slice(i)] : [...e.slice(0, i + 1), o];
}
r(Oe, "clipEndpoint");
function ke(e, t) {
	for (let n of e) {
		let e = Ee(n, t, 2);
		if (!e) continue;
		let r = [...e.points];
		e.srcRect && (r = Oe(r, e.srcRect, !0)), e.dstRect && (r = Oe(r, e.dstRect, !1)), r = Ce(Se(r)), r = Be(r, e.srcRect, e.dstRect), e.edge.points = Ce(Se(r));
	}
}
r(ke, "clipEdgeEndpointsToNodeBoundaries");
function Ae(e, t, n, r = !1) {
	if (F(e, t, J)) {
		if (t.y < n.top - J || t.y > n.bottom + J) return t;
		if (r) {
			if (e.x < n.left - J) return {
				x: n.left,
				y: e.y
			};
			if (e.x > n.right + J) return {
				x: n.right,
				y: e.y
			};
		}
		return {
			x: Math.abs(t.x - n.left) <= Math.abs(t.x - n.right) ? n.left : n.right,
			y: e.y
		};
	}
	if (P(e, t, J)) {
		if (t.x < n.left - J || t.x > n.right + J) return t;
		if (r) {
			if (e.y < n.top - J) return {
				x: e.x,
				y: n.top
			};
			if (e.y > n.bottom + J) return {
				x: e.x,
				y: n.bottom
			};
		}
		let i = Math.abs(t.y - n.top) <= Math.abs(t.y - n.bottom);
		return {
			x: e.x,
			y: i ? n.top : n.bottom
		};
	}
	return t;
}
r(Ae, "snapEndpointToBoundary");
function je(e, t, n) {
	let r = e[t];
	for (let i = t + n; i >= 0 && i < e.length; i += n) {
		let t = e[i];
		if (!N(t, r, J)) return t;
	}
	return e[t + n];
}
r(je, "firstDistinctAdjacent");
function Me(e, t) {
	let n = e + Te, r = t - Te;
	return n <= r ? {
		lo: n,
		hi: r
	} : {
		lo: (e + t) / 2,
		hi: (e + t) / 2
	};
}
r(Me, "cornerClearanceRange");
function Ne(e, t, n) {
	let { lo: r, hi: i } = Me(t, n);
	return Math.min(i, Math.max(r, e));
}
r(Ne, "clampToCornerClearance");
function Pe(e) {
	let t = Math.max(...e.map((e) => e.lo)), n = Math.min(...e.map((e) => e.hi));
	if (!(t > n)) return {
		lo: t,
		hi: n
	};
}
r(Pe, "intersectRanges");
function Fe(e, t) {
	return t === "left" || t === "right" ? Me(e.top, e.bottom) : Me(e.left, e.right);
}
r(Fe, "clearanceRangeForSide");
function Ie(e, t, n) {
	let r = e.y >= n.top - J && e.y <= n.bottom + J, i = e.x >= n.left - J && e.x <= n.right + J;
	if (F(e, t, J) && r) {
		if (Math.abs(e.x - n.left) < J) return "left";
		if (Math.abs(e.x - n.right) < J) return "right";
	}
	if (P(e, t, J) && i) {
		if (Math.abs(e.y - n.top) < J) return "top";
		if (Math.abs(e.y - n.bottom) < J) return "bottom";
	}
}
r(Ie, "terminalSideForSegment");
function Le(e) {
	return e === "left" || e === "right";
}
r(Le, "isHorizontalSide");
function Re(e, t, n, r, i) {
	let a = [], o = n ? Ie(e, t, n) : void 0, s = r ? Ie(t, e, r) : void 0;
	return n && o && Le(o) === i && a.push(Fe(n, o)), r && s && Le(s) === i && a.push(Fe(r, s)), a.length > 0 ? Pe(a) : void 0;
}
r(Re, "straightClearanceRange");
function ze(e, t, n, r, i) {
	let a = Re(e, t, n, r, i);
	if (!a) return;
	let o = i ? e.y : e.x, s = Math.min(a.hi, Math.max(a.lo, o));
	if (!(Math.abs(s - o) < J)) return i ? [{
		x: e.x,
		y: s
	}, {
		x: t.x,
		y: s
	}] : [{
		x: s,
		y: e.y
	}, {
		x: s,
		y: t.y
	}];
}
r(ze, "clearStraightEndpointCornerAxis");
function Be(e, t, n) {
	if (e.length !== 2) return e;
	let [r, i] = e;
	return F(r, i, J) ? ze(r, i, t, n, !0) ?? e : P(r, i, J) ? ze(r, i, t, n, !1) ?? e : e;
}
r(Be, "clearStraightEndpointCornerConnections");
function Ve(e, t, n) {
	return Le(n) ? {
		x: e.x,
		y: Ne(e.y, t.top, t.bottom)
	} : {
		x: Ne(e.x, t.left, t.right),
		y: e.y
	};
}
r(Ve, "cornerClearedEndpoint");
function He(e, t, n, r, i, a) {
	let o = e.map((e) => ({ ...e }));
	for (let s = t; s >= 0 && s < e.length; s += n) {
		let t = e[s];
		if (a && !F(t, r, J) || !a && !P(t, r, J)) break;
		a ? o[s].y = i.y : o[s].x = i.x;
	}
	return o;
}
r(He, "moveCollinearEndpointRun");
function Ue(e, t, n) {
	if (e.length < 2) return e;
	let r = n ? 0 : e.length - 1, i = n ? 1 : -1, a = e[r], o = je(e, r, i);
	if (!o) return e;
	let s = Ie(a, o, t);
	if (!s) return e;
	let c = Le(s), l = Ve(a, t, s);
	return N(a, l, J) ? e : He(e, r, i, a, l, c);
}
r(Ue, "clearEndpointCornerConnection");
function We(e, t, n) {
	let r = Math.min(e.x, t.x) >= n.left - J && Math.max(e.x, t.x) <= n.right + J, i = Math.min(e.y, t.y) >= n.top - J && Math.max(e.y, t.y) <= n.bottom + J;
	if (Math.abs(e.y - n.top) < J && Math.abs(t.y - n.top) < J && r) return "top";
	if (Math.abs(e.y - n.bottom) < J && Math.abs(t.y - n.bottom) < J && r) return "bottom";
	if (Math.abs(e.x - n.left) < J && Math.abs(t.x - n.left) < J && i) return "left";
	if (Math.abs(e.x - n.right) < J && Math.abs(t.x - n.right) < J && i) return "right";
}
r(We, "borderSideForSegment");
function Ge(e, t, n, r) {
	switch (e) {
		case "top": return P(t, n, J) && n.y < r.top - J;
		case "bottom": return P(t, n, J) && n.y > r.bottom + J;
		case "left": return F(t, n, J) && n.x < r.left - J;
		case "right": return F(t, n, J) && n.x > r.right + J;
	}
}
r(Ge, "leavesOutward");
function Ke(e, t, n) {
	if (e.length < 3) return e;
	if (n) {
		let n = We(e[0], e[1], t);
		return n && Ge(n, e[1], e[2], t) ? e.slice(1) : e;
	}
	let r = e.length - 1, i = We(e[r - 1], e[r], t);
	return i && Ge(i, e[r - 1], e[r - 2], t) ? e.slice(0, r) : e;
}
r(Ke, "collapseOwnBorderStub");
function qe(e, t, n) {
	let r = e;
	if (t) {
		let e = je(r, 0, 1);
		if (e) {
			let n = Ae(e, r[0], t);
			n !== r[0] && (r = [n, ...r.slice(1)]);
		}
		r = Ke(r, t, !0);
	}
	if (n) {
		let e = r.length - 1, t = je(r, e, -1);
		if (t) {
			let i = Ae(t, r[e], n, !0);
			i !== r[e] && (r = [...r.slice(0, e), i]);
		}
		r = Ke(r, n, !1);
	}
	let i = Be(r, t, n);
	return i !== r || r.length === 2 ? i : (t && (r = Ue(r, t, !0)), n && (r = Ue(r, n, !1)), r);
}
r(qe, "snapAndCollapseEndpoints");
function Je(e, t) {
	for (let n of e) {
		let e = Ee(n, t, 2);
		if (!e) continue;
		let r = qe(V(e.points, J), e.srcRect, e.dstRect);
		if (r.length < 3) {
			e.edge.points = r;
			continue;
		}
		let i = [
			r[0],
			{ ...r[0] },
			...r.slice(1, -1),
			r[r.length - 1],
			{ ...r[r.length - 1] }
		];
		e.edge.points = i;
	}
}
r(Je, "prepareEdgeEndpointsForRenderer");
function Ye(e) {
	return new Map(e.map((e) => [e.id, e]));
}
r(Ye, "buildNodeMap");
function Xe(e, t) {
	let n = e.parentId, r = null;
	for (; n;) {
		let e = t.get(n);
		if (!e?.isGroup) break;
		r = e.id, n = e.parentId;
	}
	return r;
}
r(Xe, "resolveTopLevelGroupId");
function Ze(e, t) {
	let n = 0, r = e.parentId;
	for (; r;) {
		let e = t.get(r);
		if (!e?.isGroup) break;
		n++, r = e.parentId;
	}
	return n;
}
r(Ze, "groupDepth");
function Qe(e) {
	let t = 1 / 0, n = -1 / 0, r = 1 / 0, i = -1 / 0;
	for (let a of e) {
		let e = a.x, o = a.y;
		if (typeof e != "number" || typeof o != "number") continue;
		let s = a.width ?? 0, c = a.height ?? 0;
		t = Math.min(t, e - s / 2), n = Math.max(n, e + s / 2), r = Math.min(r, o - c / 2), i = Math.max(i, o + c / 2);
	}
	return t === 1 / 0 || r === 1 / 0 ? null : {
		minX: t,
		maxX: n,
		minY: r,
		maxY: i
	};
}
r(Qe, "boundsForChildren");
function $e(e, t) {
	let n = e.padding ?? 20;
	e.x = (t.minX + t.maxX) / 2, e.y = (t.minY + t.maxY) / 2, e.width = Math.max(0, t.maxX - t.minX) + n, e.height = Math.max(0, t.maxY - t.minY) + n;
}
r($e, "applyGroupBounds");
function et(e) {
	let t = Ye(e), n = e.filter((e) => e.isGroup && e.parentId).sort((e, n) => Ze(n, t) - Ze(e, t));
	for (let t of n) {
		let n = Qe(e.filter((e) => e.parentId === t.id));
		n && $e(t, n);
	}
}
r(et, "recomputeNestedGroupBounds");
function tt(e, t) {
	let n = e.nodes ?? [], i = e.edges ?? [], a = n.filter((e) => !e.isGroup), o = 1 / 0, s = -1 / 0;
	for (let e of a) {
		let n = e[t];
		typeof n == "number" && (o = Math.min(o, n), s = Math.max(s, n));
	}
	if (!Number.isFinite(o) || !Number.isFinite(s)) return !1;
	let c = /* @__PURE__ */ r((e) => o + s - e, "mirror");
	for (let e of n) {
		let n = e[t];
		typeof n == "number" && (e[t] = c(n));
		let r = e.groupTitleRect;
		r && (e.groupTitleRect = t === "x" ? {
			...r,
			left: c(r.right),
			right: c(r.left)
		} : {
			...r,
			top: c(r.bottom),
			bottom: c(r.top)
		});
	}
	for (let e of i) for (let n of e.points ?? []) n[t] = c(n[t]);
	return !0;
}
r(tt, "mirrorAxis");
function nt(e) {
	return !(e.nodes ?? []).some((e) => !e.isGroup) || tt(e, "y");
}
r(nt, "applyBtDirectionTransform");
function rt(e, t = "LR") {
	let n = e.nodes ?? [], r = e.edges ?? [], i = n.filter((e) => !e.isGroup), a = 1 / 0, o = 1 / 0;
	for (let e of i) {
		let t = e.x ?? 0, n = e.y ?? 0;
		t < a && (a = t), n < o && (o = n);
	}
	if (!Number.isFinite(a) || !Number.isFinite(o)) return !1;
	let s = 0, c = 0;
	for (let e of i) s += e.width ?? 0, c += e.height ?? 0;
	let l = s / i.length, u = c / i.length, d = u > 0 ? Math.max(1, l / u) : 1;
	for (let e of i) {
		let t = e.x ?? 0, n = ((e.y ?? 0) - o) * d + 36, r = t - a;
		e.x = n, e.y = r;
	}
	for (let e of r) if (e.points) for (let t of e.points) {
		let e = t.x, n = (t.y - o) * d + 36, r = e - a;
		t.x = n, t.y = r;
	}
	et(n);
	let f = n.filter((e) => e.isGroup && !e.parentId);
	if (f.length === 0) return t === "RL" && tt(e, "x"), !0;
	let p = Ye(n), m = /* @__PURE__ */ new Map();
	for (let e of n) {
		if (e.isGroup) continue;
		let t = Xe(e, p);
		if (!t) continue;
		let n = m.get(t) ?? [];
		n.push(e), m.set(t, n);
	}
	let h = 0;
	for (let e of f) {
		let t = e.padding ?? 0;
		t > h && (h = t);
	}
	let g = [], _ = 1 / 0, v = -1 / 0;
	for (let e of f) {
		let t = Qe(m.get(e.id) ?? []);
		t && (_ = Math.min(_, t.minX), v = Math.max(v, t.maxX), g.push({
			lane: e,
			contentTop: t.minY,
			contentBottom: t.maxY,
			centerY: (t.minY + t.maxY) / 2
		}));
	}
	if (_ === 1 / 0 || v === -1 / 0) return !0;
	let y = Math.max(0, v - _) + 2 * Math.max(h, 10), b = 36 + y, x = (_ + v) / 2 - y / 2 - 36, S = x + b / 2, C = Math.max(h, 36);
	g.sort((e, t) => e.centerY - t.centerY);
	for (let e = 0; e < g.length; e++) {
		let t = g[e], n, r;
		if (n = e === 0 ? t.contentTop - C : (g[e - 1].contentBottom + t.contentTop) / 2, e === g.length - 1) r = t.contentBottom + C;
		else {
			let n = g[e + 1];
			r = (t.contentBottom + n.contentTop) / 2;
		}
		let i = Math.max(0, r - n), a = (n + r) / 2;
		t.lane.x = S, t.lane.y = a, t.lane.width = b, t.lane.height = i, t.lane.swimlaneContentTop = t.contentTop, t.lane.groupTitleRect = {
			left: x,
			right: x + 36,
			top: n,
			bottom: r
		};
	}
	return t === "RL" && tt(e, "x"), !0;
}
r(rt, "applyLrDirectionTransform");
var it = 1e-6, at = 8, ot = [
	0,
	at,
	-at,
	2 * at,
	-2 * at
];
function st(e, t) {
	let { nodeInfoById: n, realNodeRects: r } = fe(t);
	for (let t of e) {
		if (t.isLayoutOnly) continue;
		let i = t.points;
		if (!i || i.length < 4) continue;
		let a = ae(V(i, it), it);
		if (!a) continue;
		let { p3: o } = a, s = a.kind === "HVH", c = me(t, n, it);
		if (!c) continue;
		let { srcId: l, dstId: u, srcInfo: d, dstInfo: f, collinearX: p, collinearY: m } = c;
		if (p || m) continue;
		let h, g = d.rect;
		for (let n of ot) {
			let i, a, c;
			if (s) {
				let e = f.cy > d.cy ? g.bottom : g.top, t = d.cx + n;
				if (t <= g.left + it || t >= g.right - it) continue;
				i = {
					x: t,
					y: e
				}, a = {
					x: t,
					y: o.y
				}, c = {
					x: o.x,
					y: o.y
				};
			} else {
				let e = f.cx > d.cx ? g.right : g.left, t = d.cy + n;
				if (t <= g.top + it || t >= g.bottom - it) continue;
				i = {
					x: e,
					y: t
				}, a = {
					x: o.x,
					y: t
				}, c = {
					x: o.x,
					y: o.y
				};
			}
			let p = N(i, a, it), m = N(a, c, it);
			if (p && m || !p && q(i, a, r, [l], 1) || !m && q(a, c, r, [u], 1)) continue;
			let _ = !p && _e(i, a, e, t, {
				epsilon: it,
				skipDegenerateOther: !0
			}), v = !m && _e(a, c, e, t, {
				epsilon: it,
				skipDegenerateOther: !0
			});
			if (!(_ || v)) {
				h = p ? [a, c] : m ? [i, a] : [
					i,
					a,
					c
				];
				break;
			}
		}
		h && (t.points = h);
	}
}
r(st, "portSwapToLShape");
function ct(e, t) {
	let { realNodeRects: n, labelNodeRects: i } = K(t.values());
	for (let a of e) {
		if (a.isLayoutOnly) continue;
		let o = a.points;
		if (!o || o.length < 4) continue;
		let s = V(o, .001);
		if (s.length < 4) continue;
		let c = s.length - 1, l = s[c], u = s[c - 1], d = s[c - 2], f = l.x - u.x, p = l.y - u.y, m = Math.hypot(f, p);
		if (m >= 10 || m < .001) continue;
		let h = u.x - d.x, g = u.y - d.y;
		if (Math.hypot(h, g) < .001) continue;
		let _ = I(u, l, .001), v = L(u, l, .001), y = I(d, u, .001), b = L(d, u, .001);
		if (!(_ && b || v && y)) continue;
		let x = a.end, S = a.start, C = x ? t.get(x) : void 0;
		if (!C) continue;
		let w = C.x ?? 0, T = C.y ?? 0, E = G(C);
		if (!E) continue;
		let D, O;
		if (b) {
			let e = g < 0;
			D = {
				x: w,
				y: d.y
			}, O = {
				x: w,
				y: e ? E.bottom : E.top
			};
		} else {
			let e = h > 0;
			D = {
				x: d.x,
				y: T
			}, O = {
				x: e ? E.right : E.left,
				y: T
			};
		}
		if (q(D, O, n, x ? [x] : [], -2) || q(D, O, i, [], -2)) continue;
		if (S) {
			let e = t.get(S), n = e ? G(e) : void 0;
			if (n && H(D, n, 2)) continue;
		}
		let k = /* @__PURE__ */ r((e, t) => `${e.x.toFixed(3)},${e.y.toFixed(3)}|${t.x.toFixed(3)},${t.y.toFixed(3)}`, "ownSegmentKey"), A = /* @__PURE__ */ new Set();
		for (let e = 0; e < s.length - 1; e++) A.add(k(s[e], s[e + 1]));
		let j = /* @__PURE__ */ r((t, n) => {
			for (let r of e) {
				if (r === a || r.isLayoutOnly) continue;
				let e = r.points;
				if (!(!e || e.length < 2)) for (let r = 0; r < e.length - 1; r++) {
					let i = e[r], a = e[r + 1];
					if (!A.has(k(i, a)) && ve(t, n, i, a, .001)) return !0;
				}
			}
			return !1;
		}, "segmentCrossesOtherEdge");
		if (j(D, O)) continue;
		if (c - 3 >= 0) {
			let e = s[c - 3], t = [S, x].filter((e) => !!e);
			if (q(e, D, n, t, -2) || j(e, D)) continue;
		}
		let ee = [
			...s.slice(0, c - 2),
			D,
			O
		];
		a.points = ee;
		let te = a.labelNodeId;
		if (te) {
			let e = t.get(te);
			if (e) {
				let t = e.width ?? 0, n = e.height ?? 0;
				if (t > 0 && n > 0) {
					let r, i, a = -1;
					for (let e = 0; e < ee.length - 1; e++) {
						let o = ee[e], s = ee[e + 1], c = Math.hypot(s.x - o.x, s.y - o.y), l = F(o, s, .001), u = P(o, s, .001);
						(l && c >= t + 2 || u && c >= n + 2) && c > a && (a = c, r = (o.x + s.x) / 2, i = (o.y + s.y) / 2);
					}
					r !== void 0 && i !== void 0 && (e.x = r, e.y = i);
				}
			}
		}
	}
}
r(ct, "collapseShortTerminalStub");
var Y = .001, X = 8, Z = ie, lt = /* @__PURE__ */ r((e, t) => P(e, t, Y) || F(e, t, Y), "orthogonallyAligned");
function ut(e, t) {
	let n = /* @__PURE__ */ r((e, t) => {
		let n = e.x ?? 0, r = e.y ?? 0, i = t.x - n, a = t.y - r, o = (e.width ?? 0) / 2, s = (e.height ?? 0) / 2;
		return Math.abs(a) * o > Math.abs(i) * s ? (a < 0 && (s = -s), {
			x: n + (a === 0 ? 0 : s * i / a),
			y: r + s
		}) : (i < 0 && (o = -o), {
			x: n + o,
			y: r + (i === 0 ? 0 : o * a / i)
		});
	}, "rectIntersect"), i = /* @__PURE__ */ r((e, r) => {
		let i = V(e.points ?? []);
		if (i.length < 2) return;
		let a = r ? e.start : e.end, o = a ? t.get(a) : void 0, s = o ? G(o) : void 0;
		if (!o || !a || !s) return;
		let c = r ? i[0] : i[i.length - 1], l = r ? i[1] : i[i.length - 2], u = n(o, c), d = c;
		if (lt(l, u) && (d = l), P(u, d, Y)) return {
			edge: e,
			edgeId: String(e.id ?? ""),
			nodeId: a,
			atStart: r,
			orientation: "V",
			coord: u.x,
			min: Math.min(u.y, d.y),
			max: Math.max(u.y, d.y),
			boundary: u,
			railEnd: d,
			rect: s
		};
		if (F(u, d, Y)) return {
			edge: e,
			edgeId: String(e.id ?? ""),
			nodeId: a,
			atStart: r,
			orientation: "H",
			coord: u.y,
			min: Math.min(u.x, d.x),
			max: Math.max(u.x, d.x),
			boundary: u,
			railEnd: d,
			rect: s
		};
	}, "terminalLaneFor"), a = /* @__PURE__ */ r((e, t) => Math.max(0, Math.min(e.max, t.max) - Math.max(e.min, t.min)), "projectedOverlapLength"), o = /* @__PURE__ */ r((e, t) => e.nodeId !== t.nodeId || e.orientation !== t.orientation ? !1 : e.orientation === "H" ? (Math.abs(e.boundary.x - e.rect.left) < 1 || Math.abs(e.boundary.x - e.rect.right) < 1) && P(e.boundary, t.boundary, 1) : (Math.abs(e.boundary.y - e.rect.top) < 1 || Math.abs(e.boundary.y - e.rect.bottom) < 1) && F(e.boundary, t.boundary, 1), "sameTerminalFace"), s = /* @__PURE__ */ r((e, t) => e.nodeId !== t.nodeId || e.orientation !== t.orientation ? !1 : a(e, t) >= X && Math.abs(e.coord - t.coord) < .5, "exactTerminalLaneConflict"), c = /* @__PURE__ */ r((e, t) => {
		if (e.nodeId !== t.nodeId || e.orientation !== t.orientation || e.orientation !== "H" || e.atStart === t.atStart) return !1;
		let n = a(e, t);
		if (n < X) return !1;
		let r = e.rect.bottom - e.rect.top;
		return n < r || n > 2 * r ? !1 : o(e, t) && Math.abs(e.coord - t.coord) < 16;
	}, "nearTerminalLaneConflict"), l = /* @__PURE__ */ r((e, t) => {
		let n = V(e.edge.points ?? []);
		if (n.length < 2) return;
		let i = e.orientation === "V" ? {
			x: e.boundary.x + t,
			y: e.boundary.y
		} : {
			x: e.boundary.x,
			y: e.boundary.y + t
		}, a = e.orientation === "V" ? {
			x: e.railEnd.x + t,
			y: e.railEnd.y
		} : {
			x: e.railEnd.x,
			y: e.railEnd.y + t
		};
		if (!(/* @__PURE__ */ r(() => Math.abs(e.boundary.y - e.rect.top) < 1 || Math.abs(e.boundary.y - e.rect.bottom) < 1 ? F(i, e.boundary, Y) && i.x >= e.rect.left + 1 && i.x <= e.rect.right - 1 : Math.abs(e.boundary.x - e.rect.left) < 1 || Math.abs(e.boundary.x - e.rect.right) < 1 ? P(i, e.boundary, Y) && i.y >= e.rect.top + 1 && i.y <= e.rect.bottom - 1 : !1, "boundaryStaysOnSameFace"))()) return;
		if (e.atStart) {
			let t = n.length > 1 && N(n[1], e.railEnd, Y), r = n.slice(t ? 2 : 1), o = r[0];
			return o && !lt(o, a) ? void 0 : [
				i,
				a,
				...r
			];
		}
		let o = n.length > 1 && N(n[n.length - 2], e.railEnd, Y), s = n.slice(0, o ? -2 : -1), c = s[s.length - 1];
		if (!(c && !lt(c, a))) return [
			...s,
			a,
			i
		];
	}, "shiftedCandidate"), u = /* @__PURE__ */ r((e) => {
		let n = e.edge, r = V(n.points ?? []);
		if (r.length !== 2) return !1;
		let i = n.start, a = n.end, o = i ? t.get(i) : void 0, s = a ? t.get(a) : void 0;
		if (!o || !s) return !1;
		let c = o.x ?? 0, l = o.y ?? 0, u = s.x ?? 0, d = s.y ?? 0, [f, p] = r;
		return F(f, p, Y) && Math.abs(l - d) < 1 && Math.abs(c - u) > 1 || P(f, p, Y) && Math.abs(c - u) < 1 && Math.abs(l - d) > 1;
	}, "laneIsStraightCollinearConnector"), d = [
		-7,
		7,
		-14,
		14,
		-21,
		21
	];
	for (let t = 0; t < 8; t++) {
		let t = e.filter((e) => !e.isLayoutOnly).flatMap((e) => [i(e, !0), i(e, !1)]).filter((e) => !!e), n = !1;
		for (let e = 0; e < t.length && !n; e++) for (let r = e + 1; r < t.length && !n; r++) {
			let a = t[e], o = t[r];
			if (a.edge === o.edge || !(s(a, o) || c(a, o))) continue;
			let f = !s(a, o), p = [a, o].sort((e, t) => {
				let n = u(e), r = u(t);
				return n === r ? +!t.atStart - !e.atStart : Number(n) - Number(r);
			});
			for (let e of p) {
				for (let r of d) {
					let a = l(e, r);
					if (!a) continue;
					let o = i({
						...e.edge,
						points: a
					}, e.atStart);
					if (!(!o || t.some((t) => t.edge !== e.edge && (s(o, t) || f && c(o, t))))) {
						e.edge.points = a, n = !0;
						break;
					}
				}
				if (n) break;
			}
		}
		if (!n) return;
	}
}
r(ut, "separateSharedRenderedTerminalLanes");
function dt(e, t) {
	let { realNodeRects: n, labelNodeRects: i } = K(t.values()), a = /* @__PURE__ */ r((t, r) => {
		let a = t.start, o = t.end, s = Z(r);
		if (s.length !== r.length - 1) return !1;
		let c = [a, o].filter((e) => !!e);
		for (let e of s) if (q(e.a, e.b, n, c, -2) || q(e.a, e.b, i, [], -2)) return !1;
		for (let n of e) {
			if (n === t || n.isLayoutOnly) continue;
			let e = n.points;
			if (!(!e || e.length < 2)) {
				for (let t of s) for (let n of Z(V(e))) if (z(t, n, .5) >= X || ve(t.a, t.b, n.a, n.b, Y)) return !1;
			}
		}
		return !0;
	}, "candidateIsSafe"), o = /* @__PURE__ */ r((e, t) => {
		if (t + 4 >= e.length) return;
		let n = e[t], r = e[t + 1], i = e[t + 2], a = e[t + 3], o = e[t + 4], s = I(n, r) && L(r, i) && I(i, a) && L(a, o) && P(n, a, Y) && P(n, o, Y) && P(r, i, Y) && (r.x - n.x) * (a.x - i.x) < 0, c = L(n, r) && I(r, i) && L(i, a) && I(a, o) && F(n, a, Y) && F(n, o, Y) && F(r, i, Y) && (r.y - n.y) * (a.y - i.y) < 0;
		if (s || c) return V([
			...e.slice(0, t + 1),
			o,
			...e.slice(t + 5)
		]);
		if (t + 5 >= e.length) return;
		let l = e[t + 5], u = L(n, r) && I(r, i) && L(i, a) && I(a, o) && L(o, l) && P(n, o, Y) && P(n, l, Y) && P(i, a, Y) && (i.x - r.x) * (o.x - a.x) < 0, d = I(n, r) && L(r, i) && I(i, a) && L(a, o) && I(o, l) && F(n, o, Y) && F(n, l, Y) && F(i, a, Y) && (i.y - r.y) * (o.y - a.y) < 0;
		if (!(!u && !d)) return V([
			...e.slice(0, t + 1),
			l,
			...e.slice(t + 6)
		]);
	}, "withoutDogleg");
	for (let t = 0; t < 8; t++) {
		let t = !1;
		for (let n of e) {
			if (n.isLayoutOnly) continue;
			let e = V(n.points ?? []);
			for (let r = 0; r <= e.length - 5; r++) {
				let i = o(e, r);
				if (!(!i || !a(n, i))) {
					n.points = i, t = !0;
					break;
				}
			}
			if (t) break;
		}
		if (!t) return;
	}
}
r(dt, "collapseRedundantRectangularDoglegs");
function ft(e, t) {
	let { realNodeRects: n, labelNodeRects: i } = K(t.values()), a = e.filter((e) => !e.isLayoutOnly), o = /* @__PURE__ */ r((e, t, n) => V(e === t ? n ?? [] : e.points ?? []), "pointsFor"), s = /* @__PURE__ */ r((e, t) => {
		let n = 0;
		for (let r = 0; r < a.length; r++) {
			let i = Z(o(a[r], e, t));
			for (let s = r + 1; s < a.length; s++) {
				let r = Z(o(a[s], e, t));
				for (let e of i) for (let t of r) ve(e.a, e.b, t.a, t.b, Y) && n++;
			}
		}
		return n;
	}, "strictCrossingCount"), c = /* @__PURE__ */ r((e) => {
		let t = Z(e);
		if (t.length !== 3) return;
		let n = t[1];
		if (t[0].horizontal !== n.horizontal && t[2].horizontal !== n.horizontal) return {
			index: n.index,
			horizontal: n.horizontal,
			vertical: n.vertical,
			segment: n
		};
	}, "middleRail"), l = /* @__PURE__ */ r((e, t) => {
		let r = [e.start, e.end].filter((e) => !!e);
		return n.filter((e) => {
			if (r.includes(e.id)) return !1;
			let n = e.rect;
			return t.horizontal ? R(t.a.x, t.b.x, n.left, n.right) >= X && t.a.y >= n.top - 2 && t.a.y <= n.bottom + 2 : R(t.a.y, t.b.y, n.top, n.bottom) >= X && t.a.x >= n.left - 2 && t.a.x <= n.right + 2;
		});
	}, "blockingRectsFor"), u = /* @__PURE__ */ r((e, t, n) => {
		let r = e.map((e) => ({ ...e }));
		if (t.horizontal) r[t.index].y = n, r[t.index + 1].y = n;
		else if (t.vertical) r[t.index].x = n, r[t.index + 1].x = n;
		else return;
		let i = Ce(V(r));
		return Z(i).length === i.length - 1 ? i : void 0;
	}, "candidateByMovingRail"), d = /* @__PURE__ */ r((e, t, r) => {
		let c = [e.start, e.end].filter((e) => !!e), l = Z(t);
		if (l.length !== t.length - 1) return !1;
		for (let e of l) if (q(e.a, e.b, n, c, -2) || q(e.a, e.b, i, [], -2)) return !1;
		for (let t of a) if (t !== e) {
			for (let e of l) for (let n of Z(o(t))) if (z(e, n, .5) >= X) return !1;
		}
		return s(e, t) <= r;
	}, "candidateIsSafe");
	for (let e = 0; e < 8; e++) {
		let e = s(), t = !1;
		for (let n of a) {
			let r = o(n), i = c(r);
			if (!i) continue;
			let a = l(n, i.segment);
			if (a.length === 0) continue;
			let s = i.horizontal ? [Math.min(...a.map((e) => e.rect.top)) - 20, Math.max(...a.map((e) => e.rect.bottom)) + 20] : [Math.min(...a.map((e) => e.rect.left)) - 20, Math.max(...a.map((e) => e.rect.right)) + 20];
			for (let a of s) {
				let o = u(r, i.segment, a);
				if (!(!o || !d(n, o, e))) {
					n.points = o, t = !0;
					break;
				}
			}
			if (t) break;
		}
		if (!t) return;
	}
}
r(ft, "liftObstacleHuggingSameSideRails");
function pt(e, t) {
	let n = /* @__PURE__ */ r((e) => {
		let t = e.groupTitleRect;
		if (!(!t || typeof t.left != "number" || typeof t.right != "number" || typeof t.top != "number" || typeof t.bottom != "number" || !Number.isFinite(t.left) || !Number.isFinite(t.right) || !Number.isFinite(t.top) || !Number.isFinite(t.bottom) || t.right <= t.left || t.bottom <= t.top)) return {
			left: t.left,
			right: t.right,
			top: t.top,
			bottom: t.bottom
		};
	}, "validTitleRect"), i = /* @__PURE__ */ r((e) => {
		if (!e.isGroup || e.parentId) return;
		let t = e.direction, r = typeof t == "string" ? t.toUpperCase() : "";
		if (r === "LR" || r === "RL" || r === "BT") return;
		let i = n(e), a = e.y, o = e.height;
		if (!i || typeof a != "number" || typeof o != "number" || !Number.isFinite(a) || !Number.isFinite(o) || o <= 0) return;
		let s = i.right - i.left, c = i.bottom - i.top;
		if (!(c <= 0 || s < c)) return {
			node: e,
			rect: i
		};
	}, "topLaneTitleFor"), a = /* @__PURE__ */ r((e, t) => {
		if (!e.horizontal) return !1;
		let n = e.a.y;
		return n <= t.top + Y || n >= t.bottom - Y ? !1 : R(e.a.x, e.b.x, t.left, t.right) >= X;
	}, "horizontalSegmentIntersectsTitle"), o = [...t.values()].map(i).filter((e) => !!e);
	if (o.length === 0) return;
	let s = 0;
	for (let t of e) {
		if (t.isLayoutOnly) continue;
		let e = V(t.points ?? []);
		for (let t of Z(e)) for (let e of o) a(t, e.rect) && (s = Math.max(s, e.rect.bottom - t.a.y + 4));
	}
	if (!(s <= Y)) for (let e of o) {
		let t = e.node.y, n = e.node.height;
		typeof t != "number" || typeof n != "number" || !Number.isFinite(t) || !Number.isFinite(n) || n <= 0 || (e.node.y = t - s / 2, e.node.height = n + s, e.node.groupTitleRect = {
			...e.rect,
			top: e.rect.top - s,
			bottom: e.rect.bottom - s
		});
	}
}
r(pt, "liftTopLaneTitleBandsAboveRails");
function mt(e, t) {
	let n = /* @__PURE__ */ r((e) => {
		let t = e.groupTitleRect;
		if (!(!t || typeof t.left != "number" || typeof t.right != "number" || typeof t.top != "number" || typeof t.bottom != "number" || !Number.isFinite(t.left) || !Number.isFinite(t.right) || !Number.isFinite(t.top) || !Number.isFinite(t.bottom) || t.right <= t.left || t.bottom <= t.top)) return {
			left: t.left,
			right: t.right,
			top: t.top,
			bottom: t.bottom
		};
	}, "validTitleRect"), i = /* @__PURE__ */ r((e) => {
		if (!e.isGroup || e.parentId || e.direction !== "LR") return;
		let t = n(e), r = e.x, i = e.width;
		if (!t || typeof r != "number" || typeof i != "number" || !Number.isFinite(r) || !Number.isFinite(i) || i <= 0) return;
		let a = t.right - t.left, o = t.bottom - t.top;
		if (!(a <= 0 || o < a)) return {
			node: e,
			rect: t
		};
	}, "leftLaneTitleFor"), a = /* @__PURE__ */ r((e, t) => {
		if (!e.vertical) return !1;
		let n = e.a.x;
		return n <= t.left + Y || n >= t.right - Y ? !1 : R(e.a.y, e.b.y, t.top, t.bottom) >= X;
	}, "verticalSegmentIntersectsTitle"), o = /* @__PURE__ */ r((e, t) => {
		if (!e.horizontal) return !1;
		let n = e.a.y;
		return n <= t.top + Y || n >= t.bottom - Y ? !1 : R(e.a.x, e.b.x, t.left, t.right) >= X;
	}, "horizontalSegmentIntersectsTitle"), s = [...t.values()].map(i).filter((e) => !!e);
	if (s.length === 0) return;
	let c = 0;
	for (let t of e) {
		if (t.isLayoutOnly) continue;
		let e = V(t.points ?? []);
		for (let t of Z(e)) for (let e of s) if (a(t, e.rect)) c = Math.max(c, e.rect.right - t.a.x + 4);
		else if (o(t, e.rect)) {
			let n = Math.min(t.a.x, t.b.x);
			c = Math.max(c, e.rect.right - n + 4);
		}
	}
	if (!(c <= Y)) for (let e of s) {
		let t = e.node.x, n = e.node.width;
		typeof t != "number" || typeof n != "number" || !Number.isFinite(t) || !Number.isFinite(n) || n <= 0 || (e.node.x = t - c / 2, e.node.width = n + c, e.node.groupTitleRect = {
			...e.rect,
			left: e.rect.left - c,
			right: e.rect.right - c
		});
	}
}
r(mt, "shiftLeftLaneTitleBandsLeftOfRails");
function ht(e, t) {
	let { realNodeRects: n } = K(t.values()), i = e.filter((e) => !e.isLayoutOnly), a = /* @__PURE__ */ r((e, t = /* @__PURE__ */ new Map()) => V(t.get(e) ?? e.points ?? []), "replacementPointsFor"), o = /* @__PURE__ */ r((e = /* @__PURE__ */ new Map()) => {
		let t = 0;
		for (let n = 0; n < i.length; n++) {
			let r = Z(a(i[n], e));
			for (let o = n + 1; o < i.length; o++) {
				let n = Z(a(i[o], e));
				for (let e of r) for (let r of n) ve(e.a, e.b, r.a, r.b, Y) && t++;
			}
		}
		return t;
	}, "crossingCount"), s = /* @__PURE__ */ r((e = /* @__PURE__ */ new Map()) => i.reduce((t, n) => t + B(a(n, e)), 0), "totalBends"), c = /* @__PURE__ */ r((e) => {
		let t = a(e);
		if (t.length < 4) return;
		let n = t[t.length - 2], r = t[t.length - 1];
		if (!(!I(n, r, Y) && !L(n, r, Y))) return {
			tailStart: n,
			terminal: r
		};
	}, "terminalTailFor"), l = /* @__PURE__ */ r((e, t) => {
		let n = a(e);
		if (n.length < 3) return;
		let r = n[0], i = n[1], o;
		if (I(r, i, Y)) o = {
			x: i.x,
			y: t.tailStart.y
		};
		else if (L(r, i, Y)) o = {
			x: t.tailStart.x,
			y: i.y
		};
		else return;
		let s = Ce(V([
			r,
			i,
			o,
			t.tailStart,
			t.terminal
		]));
		return Z(s).length === s.length - 1 ? s : void 0;
	}, "candidateWithDestinationTail"), u = /* @__PURE__ */ r((e, t) => {
		let r = [e.start, e.end].filter((e) => !!e);
		for (let e of Z(t)) if (q(e.a, e.b, n, r, -2)) return !0;
		return !1;
	}, "pathHasNodeHit"), d = /* @__PURE__ */ r((e, t, n) => {
		for (let r of i) if (r !== e) {
			for (let e of Z(t)) for (let t of Z(a(r, n))) if (z(e, t, .5) >= X) return !0;
		}
		return !1;
	}, "pathHasSharedTrack"), f = /* @__PURE__ */ r((e, t, n) => !u(e, t) && !d(e, t, n), "candidateIsSafe"), p = /* @__PURE__ */ r(() => {
		let e = /* @__PURE__ */ new Map();
		for (let n of i) {
			let r = n.end;
			if (!r || !t.has(r) || a(n).length < 4) continue;
			let i = e.get(r) ?? [];
			i.push(n), e.set(r, i);
		}
		return e;
	}, "edgesByDestination");
	for (let e = 0; e < 4; e++) {
		let e = o();
		if (e === 0) return;
		let t = s(), n, r = e, i = t;
		for (let t of p().values()) for (let a = 0; a < t.length; a++) for (let u = a + 1; u < t.length; u++) {
			let d = t[a], p = t[u], m = c(d), h = c(p);
			if (!m || !h) continue;
			let g = l(d, h), _ = l(p, m);
			if (!g || !_) continue;
			let v = /* @__PURE__ */ new Map([[d, g], [p, _]]);
			if (!f(d, g, v) || !f(p, _, v)) continue;
			let y = o(v), b = s(v);
			y >= e || y > r || y === r && b >= i || (n = v, r = y, i = b);
		}
		if (!n) return;
		for (let [e, t] of n) e.points = t;
	}
}
r(ht, "swapDestinationTerminalTailsToReduceCrossings");
function gt(e, t) {
	let { realNodeRects: n, labelNodeRects: i } = K(t.values()), a = e.filter((e) => !e.isLayoutOnly), o = /* @__PURE__ */ r((e, t = /* @__PURE__ */ new Map()) => V(t.get(e) ?? e.points ?? []), "replacementPointsFor"), s = /* @__PURE__ */ r((e = /* @__PURE__ */ new Map()) => {
		let t = 0;
		for (let n = 0; n < a.length; n++) {
			let r = Z(o(a[n], e));
			for (let i = n + 1; i < a.length; i++) {
				let n = Z(o(a[i], e));
				for (let e of r) for (let r of n) ve(e.a, e.b, r.a, r.b, Y) && t++;
			}
		}
		return t;
	}, "strictCrossingCount"), c = /* @__PURE__ */ r((e = /* @__PURE__ */ new Map()) => a.reduce((t, n) => t + B(o(n, e)), 0), "totalBends"), l = /* @__PURE__ */ r((e) => {
		let n = e.start, r = e.end, i = n ? t.get(n) : void 0, a = r ? t.get(r) : void 0, o = i ? G(i) : void 0, s = a ? G(a) : void 0;
		return o && s ? {
			src: o,
			dst: s
		} : void 0;
	}, "endpointRectsFor"), u = /* @__PURE__ */ r((e, t, n) => {
		if (n.index <= 0 || n.index + 1 >= t.length - 1) return;
		let r = l(e);
		if (r) {
			if (n.vertical) {
				let i = n.a.x, a = Math.min(r.src.left, r.dst.left), o = Math.max(r.src.right, r.dst.right), s = i < a - Y ? "left" : i > o + Y ? "right" : void 0;
				return s ? {
					edge: e,
					points: t,
					segmentIndex: n.index,
					axis: "vertical",
					side: s,
					coord: i,
					min: Math.min(n.a.y, n.b.y),
					max: Math.max(n.a.y, n.b.y)
				} : void 0;
			}
			if (n.horizontal) {
				let i = n.a.y, a = Math.min(r.src.top, r.dst.top), o = Math.max(r.src.bottom, r.dst.bottom), s = i < a - Y ? "top" : i > o + Y ? "bottom" : void 0;
				return s ? {
					edge: e,
					points: t,
					segmentIndex: n.index,
					axis: "horizontal",
					side: s,
					coord: i,
					min: Math.min(n.a.x, n.b.x),
					max: Math.max(n.a.x, n.b.x)
				} : void 0;
			}
		}
	}, "externalRailForSegment"), d = /* @__PURE__ */ r(() => {
		let e = [];
		for (let t of a) {
			let n = o(t);
			for (let r of Z(n)) {
				let i = u(t, n, r);
				i && e.push(i);
			}
		}
		return e;
	}, "collectExternalRails"), f = /* @__PURE__ */ r((e, t) => e.edge !== t.edge && e.axis === t.axis && e.side === t.side && R(e.min, e.max, t.min, t.max) >= X, "railsInteract"), p = /* @__PURE__ */ r((e) => {
		let t = [], n = /* @__PURE__ */ new Set();
		for (let r of e) {
			if (n.has(r)) continue;
			let i = [r], a = [];
			for (n.add(r); i.length > 0;) {
				let t = i.pop();
				a.push(t);
				for (let r of e) !n.has(r) && f(t, r) && (n.add(r), i.push(r));
			}
			a.length > 1 && t.push(a);
		}
		return t;
	}, "connectedComponents"), m = /* @__PURE__ */ r((e) => {
		let t = [];
		for (let n of e) t.some((e) => Math.abs(e - n.coord) < Y) || t.push(n.coord);
		for (; t.length < e.length;) {
			let n = Math.min(...t), r = Math.max(...t), i = e[0].side;
			t.push(i === "left" || i === "top" ? n - 12 * (e.length - t.length) : r + 12 * (e.length - t.length));
		}
		return t;
	}, "uniqueCoordsFor"), h = /* @__PURE__ */ r((e) => {
		let t = e.map((e) => e.coord), n = m(e), i = [];
		if (e.length <= 6) {
			let a = Array(n.length).fill(!1), o = [], s = /* @__PURE__ */ r(() => {
				if (o.length === e.length) {
					o.some((e, n) => Math.abs(e - t[n]) >= Y) && i.push([...o]);
					return;
				}
				for (let [e, t] of n.entries()) a[e] || (a[e] = !0, o.push(t), s(), o.pop(), a[e] = !1);
			}, "visit");
			return s(), i;
		}
		for (let e = 0; e < t.length; e++) for (let n = e + 1; n < t.length; n++) {
			let r = [...t];
			[r[e], r[n]] = [r[n], r[e]], i.push(r);
		}
		return i;
	}, "coordinateAssignmentsFor"), g = /* @__PURE__ */ r((e, t) => {
		let n = /* @__PURE__ */ new Map();
		for (let [r, i] of e.entries()) {
			let e = t[r], a = n.get(i.edge) ?? i.points.map((e) => ({
				x: e.x,
				y: e.y
			}));
			i.axis === "vertical" ? (a[i.segmentIndex].x = e, a[i.segmentIndex + 1].x = e) : (a[i.segmentIndex].y = e, a[i.segmentIndex + 1].y = e), n.set(i.edge, a);
		}
		let r = /* @__PURE__ */ new Map();
		for (let [e, t] of n) {
			let n = Ce(V(t));
			if (Z(n).length !== n.length - 1) return;
			r.set(e, n);
		}
		return r;
	}, "replacementsForAssignment"), _ = /* @__PURE__ */ r((e) => {
		for (let [t, r] of e) {
			let e = [t.start, t.end].filter((e) => !!e);
			for (let t of Z(r)) if (q(t.a, t.b, n, e, -2) || q(t.a, t.b, i, [], -2)) return !1;
		}
		for (let t = 0; t < a.length; t++) {
			let n = a[t], r = e.has(n), i = Z(o(n, e));
			for (let n = t + 1; n < a.length; n++) {
				let t = a[n];
				if (!r && !e.has(t)) continue;
				let s = Z(o(t, e));
				for (let e of i) for (let t of s) if (z(e, t, .5) >= X) return !1;
			}
		}
		return !0;
	}, "candidateIsSafe");
	for (let e = 0; e < 4; e++) {
		let e = s();
		if (e === 0) return;
		let t, n = e, r = c(), i = Infinity;
		for (let a of p(d())) for (let o of h(a)) {
			let l = g(a, o);
			if (!l || !_(l)) continue;
			let u = s(l);
			if (u >= e) continue;
			let d = c(l), f = a.reduce((e, t, n) => e + Math.abs(o[n] - t.coord), 0);
			u > n || u === n && (d > r || d === r && f >= i) || (t = l, n = u, r = d, i = f);
		}
		if (!t) return;
		for (let [e, n] of t) e.points = n;
	}
}
r(gt, "reassignCrossingExternalRailChannels");
function _t(e, t) {
	let { realNodeRects: n, labelNodeRects: i } = K(t.values()), a = e.filter((e) => !e.isLayoutOnly), o = /* @__PURE__ */ r((e, t, n) => V(e === t ? n ?? [] : e.points ?? []), "pointsFor"), s = /* @__PURE__ */ r((e) => Z(e).reduce((e, t) => {
		let n = t.a.x - t.b.x, r = t.a.y - t.b.y;
		return e + Math.hypot(n, r);
	}, 0), "pathLength"), c = /* @__PURE__ */ r((e, t) => {
		let n = 0;
		for (let r = 0; r < a.length; r++) {
			let i = Z(o(a[r], e, t));
			for (let s = r + 1; s < a.length; s++) {
				let r = Z(o(a[s], e, t));
				for (let e of i) for (let t of r) ve(e.a, e.b, t.a, t.b, Y) && n++;
			}
		}
		return n;
	}, "strictCrossingCount"), l = /* @__PURE__ */ r((e, t) => {
		if (e.horizontal) {
			let n = e.a.y;
			return (Math.abs(n - t.top) < 1 || Math.abs(n - t.bottom) < 1) && R(e.a.x, e.b.x, t.left, t.right) >= X;
		}
		if (e.vertical) {
			let n = e.a.x;
			return (Math.abs(n - t.left) < 1 || Math.abs(n - t.right) < 1) && R(e.a.y, e.b.y, t.top, t.bottom) >= X;
		}
		return !1;
	}, "segmentRunsAlongRectBorder"), u = /* @__PURE__ */ r((e) => {
		let n = [e.start, e.end].filter((e) => !!e), r = [];
		for (let e of n) {
			let n = t.get(e), i = n ? G(n) : void 0;
			i && r.push(i);
		}
		return r;
	}, "endpointRectsFor"), d = /* @__PURE__ */ r((e, t) => {
		if (t + 3 >= e.length) return [];
		let n = e[t], r = e[t + 1], i = e[t + 2], a = e[t + 3], o = I(n, r, Y) && L(r, i, Y) && I(i, a, Y), s = L(n, r, Y) && I(r, i, Y) && L(i, a, Y);
		if (!o && !s || !(o ? Math.sign(r.x - n.x) !== Math.sign(a.x - i.x) : Math.sign(r.y - n.y) !== Math.sign(a.y - i.y))) return [];
		let c = P(n, a, Y) || F(n, a, Y) ? [] : [{
			x: n.x,
			y: a.y
		}, {
			x: a.x,
			y: n.y
		}], l = c.length === 0 ? [[...e.slice(0, t + 1), ...e.slice(t + 3)]] : c.map((n) => [
			...e.slice(0, t + 1),
			n,
			...e.slice(t + 3)
		]), u = /* @__PURE__ */ new Set();
		return l.map((e) => Ce(V(e))).filter((e) => {
			if (Z(e).length !== e.length - 1 || !e.some((e) => N(e, a, Y))) return !1;
			let t = e.map((e) => `${e.x.toFixed(3)},${e.y.toFixed(3)}`).join("|");
			return !u.has(t) && (u.add(t), !0);
		});
	}, "shortcutCandidatesAt"), f = /* @__PURE__ */ r((e, t, r) => {
		let s = [e.start, e.end].filter((e) => !!e), d = u(e);
		for (let e of Z(t)) if (q(e.a, e.b, n, s, -2) || q(e.a, e.b, i, [], -2) || d.some((t) => l(e, t))) return !1;
		for (let n of a) if (n !== e) {
			for (let e of Z(t)) for (let t of Z(o(n))) if (z(e, t, .5) >= X) return !1;
		}
		return c(e, t) <= r;
	}, "candidateIsSafe");
	for (let e = 0; e < 8; e++) {
		let e = c(), t, n, r = e, i = Infinity, l = Infinity;
		for (let u of a) {
			let a = o(u), p = B(a, Y), m = s(a);
			for (let o = 0; o <= a.length - 4; o++) for (let h of d(a, o)) {
				let a = B(h, Y), o = s(h);
				if (!(a < p || a === p && o < m - Y) || !f(u, h, e)) continue;
				let d = c(u, h);
				d > r || d === r && (a > i || a === i && o >= l) || (t = u, n = h, r = d, i = a, l = o);
			}
		}
		if (!t || !n) return;
		t.points = n;
	}
}
r(_t, "shortcutRedundantOrthogonalJogs");
function vt(e, t) {
	let n = [];
	for (let e of t.values()) {
		if (e.isGroup || e.isEdgeLabel) continue;
		let t = e.x ?? 0, r = e.y ?? 0, i = G(e);
		i && n.push({
			id: String(e.id ?? ""),
			cx: t,
			cy: r,
			rect: i
		});
	}
	if (n.length === 0) return;
	let i = new Map(n.map((e) => [e.id, e])), a = n.map((e) => ({
		id: e.id,
		rect: e.rect
	})), o = [
		"top",
		"bottom",
		"left",
		"right"
	], s = {
		top: Math.min(...n.map((e) => e.rect.top)) - 20,
		bottom: Math.max(...n.map((e) => e.rect.bottom)) + 20,
		left: Math.min(...n.map((e) => e.rect.left)) - 20,
		right: Math.max(...n.map((e) => e.rect.right)) + 20
	}, c = e.filter((e) => !e.isLayoutOnly), l = new Map(c.map((e, t) => [e, t])), u = /* @__PURE__ */ r((e) => {
		let t = e === "left" || e === "top" ? -1 : 1, n = [];
		for (let r = 0; r <= 2; r++) n.push(s[e] + t * 20 * r);
		return n;
	}, "outwardTracksForSide"), d = /* @__PURE__ */ r((e, t = /* @__PURE__ */ new Map()) => V(t.get(e) ?? e.points ?? []), "replacementPointsFor"), f = /* @__PURE__ */ r((e, t) => {
		let n = 0;
		for (let r of e) for (let e of t) ve(r.a, r.b, e.a, e.b, Y) && n++;
		return n;
	}, "crossingCountBetweenSegments"), p = /* @__PURE__ */ r((e, t) => f(Z(e), Z(t)), "crossingCountBetweenPaths"), m = /* @__PURE__ */ r((e = /* @__PURE__ */ new Map()) => {
		let t = 0, n = [], i = /* @__PURE__ */ new Set(), a = [], o = /* @__PURE__ */ r((e) => {
			i.has(e) || (i.add(e), a.push(e));
		}, "addEdge");
		for (let r = 0; r < c.length; r++) {
			let i = c[r], a = d(i, e);
			for (let s = r + 1; s < c.length; s++) {
				let r = c[s], l = p(a, d(r, e));
				l > 0 && (t += l, n.push({
					first: i,
					second: r,
					count: l
				}), o(i), o(r));
			}
		}
		return a.sort((e, t) => (l.get(e) ?? 0) - (l.get(t) ?? 0)), {
			count: t,
			pairs: n,
			edgeSet: i,
			edges: a
		};
	}, "crossingSnapshot"), h = /* @__PURE__ */ r((e, t) => {
		let n = new Set(t.keys());
		if (n.size === 0) return e.count;
		let r = 0;
		for (let t of e.pairs) (n.has(t.first) || n.has(t.second)) && (r += t.count);
		let i = 0;
		for (let e = 0; e < c.length; e++) {
			let r = c[e], a = n.has(r), o = d(r, t);
			for (let r = e + 1; r < c.length; r++) {
				let e = c[r];
				!a && !n.has(e) || (i += p(o, d(e, t)));
			}
		}
		return e.count - r + i;
	}, "crossingCountWithReplacements"), g = /* @__PURE__ */ r((e) => {
		let t = /* @__PURE__ */ new Map();
		for (let n of e.pairs) {
			let e = t.get(n.first) ?? /* @__PURE__ */ new Set();
			e.add(n.second), t.set(n.first, e);
			let r = t.get(n.second) ?? /* @__PURE__ */ new Set();
			r.add(n.first), t.set(n.second, r);
		}
		let n = [], r = /* @__PURE__ */ new Set();
		for (let i of e.edges) {
			if (r.has(i)) continue;
			let e = [i], a = [];
			for (r.add(i); e.length > 0;) {
				let n = e.pop();
				a.push(n);
				for (let i of t.get(n) ?? []) r.has(i) || (r.add(i), e.push(i));
			}
			a.sort((e, t) => (l.get(e) ?? 0) - (l.get(t) ?? 0)), a.length > 1 && n.push(a);
		}
		return n;
	}, "crossingComponents"), _ = /* @__PURE__ */ r((e) => [e.start, e.end].filter((e) => !!e), "endpointIdsFor"), v = /* @__PURE__ */ r((e) => {
		let t = [];
		for (let n of g(e)) {
			let e = new Set(n), r = new Set(n.flatMap((e) => _(e))), i = [...n];
			for (let t of c) e.has(t) || _(t).some((e) => r.has(e)) && i.push(t);
			i.sort((e, t) => (l.get(e) ?? 0) - (l.get(t) ?? 0)), t.push(i);
		}
		return t;
	}, "pairSearchGroups"), y = /* @__PURE__ */ r((e, t, n) => h(e, /* @__PURE__ */ new Map([[t, n]])), "crossingCountWithSingleReplacement"), b = /* @__PURE__ */ r((e) => {
		let t = /* @__PURE__ */ new Map();
		for (let n of e.pairs) t.set(n.first, (t.get(n.first) ?? 0) + n.count), t.set(n.second, (t.get(n.second) ?? 0) + n.count);
		return t;
	}, "currentCrossingsByEdge"), x = /* @__PURE__ */ r((e) => e.slice(1).reduce((t, n, r) => {
		let i = e[r];
		return t + Math.abs(n.x - i.x) + Math.abs(n.y - i.y);
	}, 0), "pathLength"), S = /* @__PURE__ */ r((e = /* @__PURE__ */ new Map()) => c.reduce((t, n) => t + B(d(n, e)), 0), "totalBends"), C = /* @__PURE__ */ r((e = /* @__PURE__ */ new Map()) => c.reduce((t, n) => t + x(d(n, e)), 0), "totalLength"), w = /* @__PURE__ */ r((e, t, n = /* @__PURE__ */ new Map()) => {
		let r = Z(t);
		for (let t of c) if (t !== e) {
			for (let e of r) for (let r of Z(d(t, n))) if (z(e, r, .5) >= X) return !0;
		}
		return !1;
	}, "pathHasSegmentConflict"), T = /* @__PURE__ */ r((e, t) => {
		let n = [e.start, e.end].filter((e) => !!e);
		for (let e of Z(t)) if (q(e.a, e.b, a, n, -2)) return !0;
		return !1;
	}, "pathHitsNode"), E = /* @__PURE__ */ r((e, t) => {
		let n = Ce(V(t));
		Z(n).length === n.length - 1 && e.push(n);
	}, "pushOrthogonalCandidate"), D = /* @__PURE__ */ r((e) => e === "left" || e === "right", "sideIsHorizontal"), O = /* @__PURE__ */ r((e, t, n) => {
		switch (t) {
			case "left": return Math.min(e.x, n.x) - 20;
			case "right": return Math.max(e.x, n.x) + 20;
			case "top": return Math.min(e.y, n.y) - 20;
			case "bottom": return Math.max(e.y, n.y) + 20;
		}
	}, "localTrackForSameSide"), k = /* @__PURE__ */ r((e, t, n, r) => {
		let i = n === "left" || n === "top" ? -1 : 1, a = [O(t, n, r), s[n]];
		for (let o of a) for (let a = 0; a <= 2; a++) E(e, de(t, n, r, o + i * 20 * a));
	}, "addSameSideCandidates"), A = /* @__PURE__ */ r((e, t, n, r, i) => {
		for (let a of u(n)) for (let n of u(i)) E(e, [
			t,
			{
				x: a,
				y: t.y
			},
			{
				x: a,
				y: n
			},
			{
				x: r.x,
				y: n
			},
			r
		]);
	}, "addHorizontalToVerticalCandidates"), j = /* @__PURE__ */ r((e, t, n, r, i) => {
		for (let a of u(n)) for (let n of u(i)) E(e, [
			t,
			{
				x: t.x,
				y: a
			},
			{
				x: n,
				y: a
			},
			{
				x: n,
				y: r.y
			},
			r
		]);
	}, "addVerticalToHorizontalCandidates"), ee = /* @__PURE__ */ r((e, t, n, r, i) => {
		let a = [...u("top"), ...u("bottom")];
		for (let o of u(n)) for (let n of u(i)) for (let i of a) E(e, [
			t,
			{
				x: o,
				y: t.y
			},
			{
				x: o,
				y: i
			},
			{
				x: n,
				y: i
			},
			{
				x: n,
				y: r.y
			},
			r
		]);
	}, "addHorizontalPairCandidates"), te = /* @__PURE__ */ r((e, t, n, r, i) => {
		let a = [...u("left"), ...u("right")];
		for (let o of u(n)) for (let n of u(i)) for (let i of a) E(e, [
			t,
			{
				x: t.x,
				y: o
			},
			{
				x: i,
				y: o
			},
			{
				x: i,
				y: n
			},
			{
				x: r.x,
				y: n
			},
			r
		]);
	}, "addVerticalPairCandidates"), M = /* @__PURE__ */ r((e) => {
		let t = /* @__PURE__ */ new Set();
		return e.map((e) => V(e)).filter((e) => {
			let n = e.map((e) => `${e.x.toFixed(3)},${e.y.toFixed(3)}`).join("|");
			return t.has(n) || e.length < 2 ? !1 : (t.add(n), !0);
		});
	}, "dedupeCandidatePaths"), ne = /* @__PURE__ */ r((e, t, n, r) => {
		let i = [], a = ue(e, t, n, r, 20, Y);
		a && E(i, a), t === r && k(i, e, t, n);
		let o = D(t), s = D(r);
		return o && !s ? A(i, e, t, n, r) : !o && s ? j(i, e, t, n, r) : o ? ee(i, e, t, n, r) : te(i, e, t, n, r), M(i);
	}, "buildCandidatesForSides"), re = /* @__PURE__ */ r((e, t, n, r) => {
		let i = [...u("left"), ...u("right")], a = [...u("top"), ...u("bottom")];
		for (let s of o) {
			let o = le(r, s), c = s === "top" || s === "bottom" ? u(s) : a;
			for (let r of i) {
				E(e, [
					t,
					n,
					{
						x: r,
						y: n.y
					},
					{
						x: r,
						y: o.y
					},
					o
				]);
				for (let i of c) E(e, [
					t,
					n,
					{
						x: r,
						y: n.y
					},
					{
						x: r,
						y: i
					},
					{
						x: o.x,
						y: i
					},
					o
				]);
			}
		}
	}, "addVerticalDepartureOuterTrackCandidates"), N = /* @__PURE__ */ r((e, t, n, r) => {
		let i = [...u("left"), ...u("right")], a = [...u("top"), ...u("bottom")];
		for (let s of o) {
			let o = le(r, s), c = s === "left" || s === "right" ? u(s) : i;
			for (let r of a) {
				E(e, [
					t,
					n,
					{
						x: n.x,
						y: r
					},
					{
						x: o.x,
						y: r
					},
					o
				]);
				for (let i of c) E(e, [
					t,
					n,
					{
						x: n.x,
						y: r
					},
					{
						x: i,
						y: r
					},
					{
						x: i,
						y: o.y
					},
					o
				]);
			}
		}
	}, "addHorizontalDepartureOuterTrackCandidates"), P = /* @__PURE__ */ r((e) => {
		let t = e.start, n = e.end, r = n ? i.get(n) : void 0;
		if (!t || !r) return [];
		let a = V(e.points ?? []);
		if (a.length < 4) return [];
		let o = a[0], s = a[1], c = [];
		return L(o, s, Y) ? re(c, o, s, r) : I(o, s, Y) && N(c, o, s, r), c;
	}, "terminalPreservingOuterTrackCandidates"), F = /* @__PURE__ */ r((e) => {
		let t = e.start, n = e.end, r = t ? i.get(t) : void 0, a = n ? i.get(n) : void 0;
		if (!r || !a) return [];
		let s = [];
		for (let e of o) {
			let t = le(r, e);
			for (let n of o) s.push(...ne(t, e, le(a, n), n));
		}
		return s.push(...P(e)), s;
	}, "candidatePathsFor"), R = /* @__PURE__ */ r(() => new Map(c.map((e) => [e, Z(d(e))])), "currentSegmentsByEdge"), ie = /* @__PURE__ */ r((e, t, n) => {
		let r = /* @__PURE__ */ new Set();
		for (let i of c) {
			if (i === e) continue;
			let a = n.get(i) ?? Z(d(i));
			t.some((e) => a.some((t) => z(e, t, .5) >= X)) && r.add(i);
		}
		return r;
	}, "sharedTrackConflictsFor"), ae = /* @__PURE__ */ r((e, t, n, r) => {
		let i = /* @__PURE__ */ new Set();
		return F(e).map((e) => Ce(V(e))).filter((t) => {
			if (T(e, t)) return !1;
			let n = t.map((e) => `${e.x.toFixed(3)},${e.y.toFixed(3)}`).join("|");
			return i.has(n) || t.length < 2 ? !1 : (i.add(n), !0);
		}).map((i) => {
			let a = Z(i), o = 0;
			for (let t of c) t !== e && (o += f(a, n.get(t) ?? Z(d(t))));
			return {
				candidate: i,
				candidateSegments: a,
				crossings: t.count - (r.get(e) ?? 0) + o,
				bends: B(i, Y),
				totalBends: B(i),
				length: x(i)
			};
		}).filter(({ crossings: e }) => e <= t.count).sort((e, t) => e.crossings - t.crossings || e.bends - t.bends || e.length - t.length).slice(0, 48).map((t) => ({
			path: t.candidate,
			segments: t.candidateSegments,
			sharedTrackConflicts: ie(e, t.candidateSegments, n),
			totalBends: t.totalBends,
			length: t.length
		}));
	}, "pairCandidatesFor"), oe = /* @__PURE__ */ r((e, t, n, r, i, a) => {
		let o = 0;
		for (let n of e.pairs) (n.first === t || n.second === t || n.first === r || n.second === r) && (o += n.count);
		let s = f(n.segments, i.segments);
		for (let e of c) {
			if (e === t || e === r) continue;
			let o = a.get(e) ?? Z(d(e));
			s += f(n.segments, o) + f(i.segments, o);
		}
		return e.count - o + s;
	}, "pairCrossingCount"), H = /* @__PURE__ */ r((e, t) => {
		for (let n of e.sharedTrackConflicts) if (n !== t) return !1;
		return !0;
	}, "conflictsOnlyWith"), U = /* @__PURE__ */ r((e, t) => e.segments.some((e) => t.segments.some((t) => z(e, t, .5) >= X)), "candidatesShareTrack"), W = /* @__PURE__ */ r((e, t, n, r) => H(t, n.edge) && H(r, e.edge) && !U(t, r), "pairCandidatesAreCompatible"), se = /* @__PURE__ */ r((e, t, n, r, i) => {
		let a = oe(e.current, t.edge, n, r.edge, i, e.baseSegments);
		if (!(a >= e.current.count)) return {
			replacements: /* @__PURE__ */ new Map([[t.edge, n.path], [r.edge, i.path]]),
			crossings: a,
			bends: e.currentBends - (e.baseBendsByEdge.get(t.edge) ?? 0) - (e.baseBendsByEdge.get(r.edge) ?? 0) + n.totalBends + i.totalBends,
			length: e.currentLength - (e.baseLengthByEdge.get(t.edge) ?? 0) - (e.baseLengthByEdge.get(r.edge) ?? 0) + n.length + i.length
		};
	}, "scorePairReplacement"), ce = /* @__PURE__ */ r((e, t) => e.crossings < t.crossings || e.crossings === t.crossings && (e.bends < t.bends || e.bends === t.bends && e.length < t.length), "pairScoreIsBetter"), fe = /* @__PURE__ */ r((e, t, n, r) => {
		let i = r;
		for (let r of t.candidates) for (let a of n.candidates) {
			if (!W(t, r, n, a)) continue;
			let o = se(e, t, r, n, a);
			o && ce(o, i) && (i = o);
		}
		return i;
	}, "bestScoreForOptionPair"), K = /* @__PURE__ */ r((e) => {
		let t = S(), n = C(), r = R(), i = b(e), a = new Map(c.map((e) => [e, B(d(e))])), o = new Map(c.map((e) => [e, x(d(e))])), s = /* @__PURE__ */ new Map(), l = v(e);
		for (let t of l) for (let n of t) {
			if (s.has(n)) continue;
			let t = ae(n, e, r, i);
			t.length > 0 && s.set(n, {
				edge: n,
				candidates: t
			});
		}
		let u = {
			replacements: /* @__PURE__ */ new Map(),
			crossings: e.count,
			bends: t,
			length: n
		}, f = {
			current: e,
			currentBends: t,
			currentLength: n,
			baseBendsByEdge: a,
			baseLengthByEdge: o,
			baseSegments: r
		};
		for (let t of l) {
			let n = new Set(t.filter((t) => e.edgeSet.has(t))), r = t.map((e) => s.get(e)).filter((e) => !!e);
			for (let e = 0; e < r.length; e++) {
				let t = r[e];
				for (let i = e + 1; i < r.length; i++) {
					let e = r[i];
					!n.has(t.edge) && !n.has(e.edge) || (u = fe(f, t, e, u));
				}
			}
		}
		return u.replacements.size > 0 ? u.replacements : void 0;
	}, "bestPairedReplacement");
	for (let e = 0; e < 4; e++) {
		let e = m(), t = e.count;
		if (t === 0) return;
		let n, r, i = t, a = Infinity;
		for (let o of e.edges) {
			let s = B(d(o), Y);
			for (let c of F(o)) {
				let l = T(o, c), u = !l && w(o, c), d = y(e, o, c), f = B(c, Y);
				l || u || !(d < t || d === t && f < s) || d > i || d === i && f >= a || (n = o, r = c, i = d, a = f);
			}
		}
		if (n && r) {
			n.points = r;
			continue;
		}
		let o = K(e);
		if (!o) return;
		for (let [e, t] of o) e.points = t;
	}
}
r(vt, "resolveRenderedOrthogonalCrossings");
var yt = .001, bt = 8;
function xt(e, t) {
	let { nodeInfoById: n, realNodeRects: i } = fe(t), a = [
		"top",
		"bottom",
		"left",
		"right"
	], o = {
		top: Math.min(...i.map((e) => e.rect.top)) - 20,
		bottom: Math.max(...i.map((e) => e.rect.bottom)) + 20,
		left: Math.min(...i.map((e) => e.rect.left)) - 20,
		right: Math.max(...i.map((e) => e.rect.right)) + 20
	}, s = /* @__PURE__ */ r((e, t, n, r) => {
		let i = [], a = ue(e, t, n, r, 20, yt);
		return a && i.push(a), t === r && i.push(de(e, t, n, o[t])), i;
	}, "buildOrthogonalPathCandidates"), c = /* @__PURE__ */ r((e, t) => {
		for (let n = 0; n < e.length - 1; n++) {
			let r = e[n], a = e[n + 1];
			if (q(r, a, i, t, 1)) return !0;
		}
		return !1;
	}, "pathHitsNode"), l = /* @__PURE__ */ r((t, n, r = !1) => {
		let i = 0, a = ie(t, yt), o = n.start, s = n.end;
		for (let t of e) {
			if (t === n || t.isLayoutOnly) continue;
			let e = t.start, c = t.end;
			if (!r && o && s && (e === o || e === s || c === o || c === s)) continue;
			let l = t.points;
			if (!(!l || l.length < 2)) for (let e of a) for (let t of ie(l, yt)) {
				if (he(e.a, e.b, t.a, t.b, yt, yt)) {
					i++;
					continue;
				}
				z(e, t, yt) >= bt && i++;
			}
		}
		return i;
	}, "pathConflictCount"), u = /* @__PURE__ */ r((e, t) => {
		let n = Math.abs(e.y - t.rect.top), r = Math.abs(e.y - t.rect.bottom), i = Math.abs(e.x - t.rect.left), a = Math.abs(e.x - t.rect.right), o = "top", s = n;
		return r < s && (o = "bottom", s = r), i < s && (o = "left", s = i), a < s && (o = "right", s = a), o;
	}, "nearestSideOfRect"), d = /* @__PURE__ */ new Map(), f = /* @__PURE__ */ r((e, t, n) => {
		let r = d.get(e) ?? [];
		r.push({
			side: t,
			edgeId: n
		}), d.set(e, r);
	}, "addFaceClaim");
	for (let t of e) {
		if (t.isLayoutOnly) continue;
		let e = t.points ?? [];
		if (e.length < 1) continue;
		let r = t.id ?? "", i = t.start, a = t.end;
		if (i) {
			let t = n.get(i);
			t && f(i, u(e[0], t), r);
		}
		if (a) {
			let t = n.get(a);
			t && f(a, u(e[e.length - 1], t), r);
		}
	}
	let p = /* @__PURE__ */ r((e, t, n) => d.get(e)?.some((e) => e.edgeId !== n && e.side === t) ?? !1, "faceIsClaimed");
	for (let t of e) {
		if (t.isLayoutOnly) continue;
		let e = t.points;
		if (!e || e.length < 2) continue;
		let r = B(e, yt);
		if (r < 4) continue;
		let i = t.start, o = t.end;
		if (!i || !o) continue;
		let m = n.get(i), h = n.get(o);
		if (!m || !h) continue;
		let g = t.id ?? "", _ = l(e, t, !0), v = l(e, t), y, b = _, x = r;
		for (let e of a) {
			if (p(i, e, g)) continue;
			let n = le(m, e);
			for (let r of a) {
				if (p(o, r, g)) continue;
				let a = le(h, r);
				for (let u of s(n, e, a, r)) {
					if (c(u, [i, o])) continue;
					let e = B(u, yt);
					if (_ > 0) {
						let n = l(u, t, !0);
						if (n > b || n === b && e >= x) continue;
						b = n, x = e, y = u;
						continue;
					}
					l(u, t) > v || e < x && (x = e, y = u);
				}
			}
		}
		if (y) {
			t.points = y;
			let e = d.get(i);
			e && d.set(i, e.filter((e) => e.edgeId !== g));
			let n = d.get(o);
			n && d.set(o, n.filter((e) => e.edgeId !== g)), f(i, u(y[0], m), g), f(o, u(y[y.length - 1], h), g);
		}
	}
}
r(xt, "simplifyDetouredEdges");
var Q = .001, St = 10, Ct = 7;
function wt(e, t) {
	let n = t ? 0 : e.length - 1, r = t ? 1 : -1, i = e[n], a = e[n + r];
	if (!i || !a) return;
	let o = a.x - i.x, s = a.y - i.y;
	if (!(Math.abs(o) + Math.abs(s) < Q)) {
		if (Math.abs(s) <= Q) {
			let e = i.x + Math.sign(o) * St;
			return {
				left: Math.min(i.x, e),
				right: Math.max(i.x, e),
				top: i.y - Ct,
				bottom: i.y + Ct
			};
		}
		if (Math.abs(o) <= Q) {
			let e = i.y + Math.sign(s) * St;
			return {
				left: i.x - Ct,
				right: i.x + Ct,
				top: Math.min(i.y, e),
				bottom: Math.max(i.y, e)
			};
		}
		return {
			left: Math.min(i.x, a.x),
			right: Math.max(i.x, a.x),
			top: Math.min(i.y, a.y),
			bottom: Math.max(i.y, a.y)
		};
	}
}
r(wt, "markerClearanceRectFor");
function Tt(e) {
	return {
		left: Math.min(e.left, e.right),
		right: Math.max(e.left, e.right),
		top: Math.min(e.top, e.bottom),
		bottom: Math.max(e.top, e.bottom)
	};
}
r(Tt, "normalizeRect");
function Et(e, t) {
	let n = V(t);
	return [wt(n, !0), wt(n, !1)].some((t) => t && W(e, Tt(t)));
}
r(Et, "labelOverlapsOwnMarker");
function Dt(e, t) {
	let n = [];
	for (let t of e) {
		if (t.isLayoutOnly) continue;
		let e = t.points;
		if (!(!e || e.length < 2)) for (let r = 0; r < e.length - 1; r++) n.push({
			edgeId: t.id,
			p1: e[r],
			p2: e[r + 1]
		});
	}
	let i = [], a = [];
	for (let e of t.values()) {
		let t = e.isGroup, n = e.parentId;
		if (t && !n) {
			let t = G(e);
			t && a.push({
				id: e.id,
				rect: t
			});
			continue;
		}
		if (t || e.isEdgeLabel) continue;
		let r = G(e);
		r && i.push({
			nodeId: e.id,
			rect: r
		});
	}
	let o = /* @__PURE__ */ r((e, t) => {
		let n = se(t, 3);
		for (let { nodeId: t, rect: r } of i) if (t !== e && W(n, r)) return !0;
		return !1;
	}, "labelOverlapsForeignNode"), s = /* @__PURE__ */ r((e, t) => {
		let r = se(t, 3);
		for (let t of n) if (t.edgeId !== e && oe(t.p1, t.p2, r)) return !0;
		return !1;
	}, "labelOverlapsForeignEdge"), c = /* @__PURE__ */ r((e, t, n) => o(e, n) || s(t, n), "labelOverlapsAnything"), l = [], u = /* @__PURE__ */ r((e) => {
		for (let { id: t, rect: n } of a) if (U(n, e)) return t;
	}, "findContainingLane"), d = /* @__PURE__ */ r((e, t) => l.some((n) => n.labelId !== e && W(t, n.rect)), "overlapsPlacedLabel");
	for (let n of e) {
		if (n.isLayoutOnly) continue;
		let e = n.labelNodeId;
		if (!e) continue;
		let i = t.get(e);
		if (!i) continue;
		let f = n.points;
		if (!f || f.length < 2) continue;
		let p = i.width ?? 0, m = i.height ?? 0;
		if (p <= 0 || m <= 0) continue;
		let h = [];
		for (let e = 0; e < f.length - 1; e++) {
			let t = f[e], n = f[e + 1], r = Math.abs(t.x - n.x), i = Math.abs(t.y - n.y);
			r < Q && i < Q || r >= Q && i >= Q || h.push({
				idx: e,
				length: r + i,
				orientation: r >= Q ? "horizontal" : "vertical",
				midX: (t.x + n.x) / 2,
				midY: (t.y + n.y) / 2
			});
		}
		if (h.length === 0) continue;
		let g = h.length >= 3 ? h.filter((e) => e.idx > 0 && e.idx < h.length - 1) : h, _ = g.length > 0 ? g : h, v = p >= m ? "horizontal" : "vertical", y = /* @__PURE__ */ r((e) => [...e].sort((e, t) => {
			let n = e.orientation === v;
			if (n !== (t.orientation === v)) return n ? -1 : 1;
			let r = e.length >= (e.orientation === "horizontal" ? p : m) + 2;
			return r === t.length >= (t.orientation === "horizontal" ? p : m) + 2 ? t.length - e.length : r ? -1 : 1;
		}), "rankSegments"), b = h[0], x = h[h.length - 1], S = [
			.5,
			.25,
			.75,
			.05,
			.95,
			.15,
			.85,
			.1,
			.9
		], C = /* @__PURE__ */ r((e, t) => {
			let n = f[e.idx], r = f[e.idx + 1];
			return {
				midX: n.x + (r.x - n.x) * t,
				midY: n.y + (r.y - n.y) * t
			};
		}, "anchorAtT"), w = /* @__PURE__ */ r((e, t, n) => Math.min(n, Math.max(t, e)), "clamp"), T = /* @__PURE__ */ r((e, t) => e.midX >= t.left - Q && e.midX <= t.right + Q && e.midY >= t.top - Q && e.midY <= t.bottom + Q, "pointInsideRectInclusive"), E = /* @__PURE__ */ r((e) => {
			let t = ce(e.midX, e.midY, p, m), n = u(t);
			if (n) return {
				laneId: n,
				anchor: e,
				rect: t
			};
			let r = a.find(({ rect: t }) => T(e, t));
			if (!r) return;
			let i = r.rect.left + p / 2 + 1, o = r.rect.right - p / 2 - 1, s = r.rect.top + m / 2 + 1, c = r.rect.bottom - m / 2 - 1;
			if (i > o || s > c) return;
			let l = {
				midX: w(e.midX, i, o),
				midY: w(e.midY, s, c)
			}, d = ce(l.midX, l.midY, p, m);
			return T(e, d) ? {
				laneId: r.id,
				anchor: l,
				rect: d
			} : void 0;
		}, "placementForAnchor"), D = /* @__PURE__ */ r((e, t, n) => e.orientation === "horizontal" ? Math.abs(t.midX - n.x) : Math.abs(t.midY - n.y), "distanceAlongSegment"), O = /* @__PURE__ */ r((e, t) => {
			let n = (e.orientation === "horizontal" ? p / 2 : m / 2) + 12;
			if (e === b) {
				let r = f[e.idx];
				if (D(e, t, r) + Q < n) return !1;
			}
			if (e === x) {
				let r = f[e.idx + 1];
				if (D(e, t, r) + Q < n) return !1;
			}
			return !0;
		}, "labelClearsTerminalEndpoints"), k = /* @__PURE__ */ r((t) => {
			let r = y(t);
			for (let t of r) for (let r of S) {
				let i = C(t, r);
				if (!O(t, i)) continue;
				let a = E(i);
				if (a && !Et(a.rect, f) && !d(e, a.rect) && !c(e, n.id, a.rect)) return {
					laneId: a.laneId,
					anchor: a.anchor
				};
			}
		}, "tryPool"), A = /* @__PURE__ */ r((t, r, i = !1) => {
			let a = y(t);
			for (let t of a) {
				let a = {
					midX: t.midX,
					midY: t.midY
				};
				if (r && !O(t, a)) continue;
				let c = E(a);
				if (c && !Et(c.rect, f) && !d(e, c.rect) && !o(e, c.rect) && (i || !s(n.id, c.rect))) return {
					laneId: c.laneId,
					anchor: c.anchor
				};
			}
		}, "findLaneContainingFallback"), j = k(_) ?? (_.length < h.length ? k(h) : void 0) ?? A(h, !0) ?? A(h, !1) ?? A(h, !1, !0);
		if (j) {
			i.x = j.anchor.midX, i.y = j.anchor.midY, i.parentId = j.laneId;
			let t = ce(j.anchor.midX, j.anchor.midY, p, m), n = l.findIndex((t) => t.labelId === e);
			n >= 0 ? l[n] = {
				labelId: e,
				rect: t
			} : l.push({
				labelId: e,
				rect: t
			});
		}
	}
}
r(Dt, "anchorLabelsToPolyline");
var Ot = 1e-6, kt = 4, At = 3;
function jt(e, t) {
	return e < t ? `${e}::${t}` : `${t}::${e}`;
}
r(jt, "pairKey");
function Mt(e, t) {
	let { nodeInfoById: n, realNodeRects: i } = fe(t), a = /* @__PURE__ */ new Map();
	for (let e of t) {
		let t = e.id;
		if (!e.isGroup && e.isEdgeLabel) {
			a.set(t, {
				w: e.width ?? 0,
				h: e.height ?? 0
			});
			continue;
		}
	}
	let o = /* @__PURE__ */ r((t, n, i, o) => {
		let s = jt(n, i), c = 0, l = /* @__PURE__ */ r((e) => {
			if (!e) return;
			let t = a.get(e);
			if (!t) return;
			let n = o === "x" ? t.w / 2 : t.h / 2;
			n > c && (c = n);
		}, "consider");
		l(t.labelNodeId);
		for (let n of e) {
			if (n === t || n.isLayoutOnly) continue;
			let e = n.start, r = n.end;
			!e || !r || jt(e, r) === s && l(n.labelNodeId);
		}
		return c > 0 ? c + At : 0;
	}, "labelClearanceFor");
	for (let t of e) {
		if (t.isLayoutOnly) continue;
		let r = t.points;
		if (!ae(r, Ot)) continue;
		let a = me(t, n, Ot);
		if (!a) continue;
		let { srcId: s, dstId: c, srcInfo: l, dstInfo: u, collinearX: d, collinearY: f } = a;
		if (d === f) continue;
		let p, m;
		if (d) {
			let e = u.cy > l.cy;
			p = {
				x: l.cx,
				y: e ? l.rect.bottom : l.rect.top
			}, m = {
				x: u.cx,
				y: e ? u.rect.top : u.rect.bottom
			};
		} else {
			let e = u.cx > l.cx;
			p = {
				x: e ? l.rect.right : l.rect.left,
				y: l.cy
			}, m = {
				x: e ? u.rect.left : u.rect.right,
				y: u.cy
			};
		}
		if (q(p, m, i, [s, c], 1)) continue;
		let h = o(t, s, c, d ? "x" : "y"), g = h > kt ? h : kt, _ = [
			0,
			g,
			-g
		];
		for (let n of _) {
			let r = { ...p }, a = { ...m };
			if (d) {
				if (r.x += n, a.x += n, r.x <= l.rect.left || r.x >= l.rect.right || a.x <= u.rect.left || a.x >= u.rect.right) continue;
			} else if (r.y += n, a.y += n, r.y <= l.rect.top || r.y >= l.rect.bottom || a.y <= u.rect.top || a.y >= u.rect.bottom) continue;
			if (!q(r, a, i, [s, c], 1) && !_e(r, a, e, t, { epsilon: Ot })) {
				t.points = [r, a];
				break;
			}
		}
	}
}
r(Mt, "straightenCollinearSiblingDetours");
function Nt(e, t) {
	let { realNodeRects: n, labelNodeRects: i } = K(t.values()), a = /* @__PURE__ */ r((e, t) => ie(t, .001).map((n) => ({
		...n,
		edge: e,
		interior: n.index >= 1 && n.index <= t.length - 3
	})), "segmentsFor"), o = /* @__PURE__ */ r(() => {
		let t = [];
		for (let n of e) {
			if (n.isLayoutOnly) continue;
			let e = n.points;
			!e || e.length < 2 || t.push(...a(n, V(e)));
		}
		return t;
	}, "allSegments"), s = /* @__PURE__ */ r((e, t) => e.horizontal && t.horizontal ? R(e.a.x, e.b.x, t.a.x, t.b.x) >= 8 && Math.abs(e.a.y - t.a.y) < 7 : e.vertical && t.vertical ? R(e.a.y, e.b.y, t.a.y, t.b.y) >= 8 && Math.abs(e.a.x - t.a.x) < 7 : !1, "hasCrowdedParallelTrack"), c = /* @__PURE__ */ r((t, r) => {
		let o = t.start, c = t.end, l = a(t, r);
		if (l.length !== r.length - 1) return !1;
		let u = [o, c].filter((e) => !!e), d = t.labelNodeId ? [t.labelNodeId] : [];
		for (let e of l) if (q(e.a, e.b, n, u, -2) || q(e.a, e.b, i, d, -2)) return !1;
		for (let n of e) {
			if (n === t || n.isLayoutOnly) continue;
			let e = n.points;
			if (!(!e || e.length < 2)) {
				for (let t of l) for (let r of a(n, V(e))) if (s(t, r) || ve(t.a, t.b, r.a, r.b, .001)) return !1;
			}
		}
		return !0;
	}, "candidateIsSafe"), l = /* @__PURE__ */ r((e, t) => {
		let n = V(e.edge.points ?? []);
		if (n.length < 4 || e.index >= n.length - 1) return;
		let r = n.map((e) => ({ ...e }));
		if (e.horizontal) r[e.index].y += t, r[e.index + 1].y += t;
		else if (e.vertical) r[e.index].x += t, r[e.index + 1].x += t;
		else return;
		return a(e.edge, r).length === r.length - 1 ? r : void 0;
	}, "shiftedCandidate"), u = /* @__PURE__ */ r((e, t) => ({
		x: e.x ?? (t.left + t.right) / 2,
		y: e.y ?? (t.top + t.bottom) / 2
	}), "nodeCenter"), d = /* @__PURE__ */ r((e) => {
		let n = e.edge, r = V(n.points ?? []);
		if (r.length !== 4 || e.index !== 1) return;
		let i = n.start ? t.get(n.start) : void 0, a = n.end ? t.get(n.end) : void 0, o = i ? G(i) : void 0, s = a ? G(a) : void 0, c = r.slice(e.index + 2);
		if (!(!i || !a || !o || !s || c.length === 0)) return {
			sourceCenter: u(i, o),
			targetCenter: u(a, s),
			sourceRect: o,
			tail: c
		};
	}, "sourceDetourContextFor"), f = /* @__PURE__ */ r((e, t, n, r, i, a) => {
		let o = r.y >= n.y, s = o ? i.bottom : i.top, c = s + (o ? 20 : -20);
		if (o && e.b.y <= c + .001 || !o && e.b.y >= c - .001) return;
		let l = e.a.x + t;
		return V([
			{
				x: n.x,
				y: s
			},
			{
				x: n.x,
				y: c
			},
			{
				x: l,
				y: c
			},
			{
				x: l,
				y: e.b.y
			},
			...a
		], .001);
	}, "verticalSourceDetour"), p = /* @__PURE__ */ r((e, t, n, r, i, a) => {
		let o = r.x >= n.x, s = o ? i.right : i.left, c = s + (o ? 20 : -20);
		if (o && e.b.x <= c + .001 || !o && e.b.x >= c - .001) return;
		let l = e.a.y + t;
		return V([
			{
				x: s,
				y: n.y
			},
			{
				x: c,
				y: n.y
			},
			{
				x: c,
				y: l
			},
			{
				x: e.b.x,
				y: l
			},
			...a
		], .001);
	}, "horizontalSourceDetour"), m = /* @__PURE__ */ r((e, t) => {
		let n = d(e);
		if (n) {
			if (e.vertical) return f(e, t, n.sourceCenter, n.targetCenter, n.sourceRect, n.tail);
			if (e.horizontal) return p(e, t, n.sourceCenter, n.targetCenter, n.sourceRect, n.tail);
		}
	}, "sourceDetourCandidate"), h = [
		-7,
		7,
		-14,
		14,
		-21,
		21
	];
	for (let e = 0; e < 12; e++) {
		let e = o(), t = !1;
		for (let n = 0; n < e.length && !t; n++) for (let r = n + 1; r < e.length && !t; r++) {
			let i = e[n], a = e[r];
			if (i.edge === a.edge || !s(i, a)) continue;
			let o = [i, a].filter((e) => e.interior);
			for (let e of o) {
				for (let n of h) {
					let r = l(e, n);
					if (r && c(e.edge, r)) {
						e.edge.points = r, t = !0;
						break;
					}
					let i = m(e, n);
					if (i && c(e.edge, i)) {
						e.edge.points = i, t = !0;
						break;
					}
				}
				if (t) break;
			}
		}
		if (!t) return;
	}
}
r(Nt, "nudgeSharedInteriorSubpaths");
function Pt(e, t, n, r) {
	let i = t.x - e.x, a = t.y - e.y, o = r.x - n.x, s = r.y - n.y, c = i * s - a * o;
	if (Math.abs(c) < 1e-10) return !1;
	let l = n.x - e.x, u = n.y - e.y, d = (l * s - u * o) / c, f = (l * a - u * i) / c, p = .01;
	return d > p && d < .99 && f > p && f < .99;
}
r(Pt, "segmentsIntersect");
function Ft(e) {
	let n = e.nodes ?? [], r = e.edges ?? [], i = [];
	if (!r.length || !n.length) return i;
	let a = pe(n), o = [];
	for (let e of r) {
		if (e.isLayoutOnly) continue;
		let t = e.points;
		if (!t || t.length < 2) continue;
		let n = e.start, r = e.end, s = e.labelNodeId, c = e.id ?? `${n}->${r}`;
		for (let e of a) if (e.nodeId !== n && e.nodeId !== r && !(s && e.nodeId === s)) {
			for (let n = 0; n < t.length - 1; n++) if (oe(t[n], t[n + 1], e, -1)) {
				i.push({
					type: "edge-node-overlap",
					edgeId: c,
					targetId: e.nodeId,
					detail: `segment ${n} passes through node "${e.nodeId}"`
				});
				break;
			}
		}
		for (let e = 0; e < t.length - 1; e++) o.push({
			edgeId: c,
			start: n,
			end: r,
			p1: t[e],
			p2: t[e + 1]
		});
	}
	let s = /* @__PURE__ */ new Set();
	for (let e = 0; e < o.length; e++) for (let t = e + 1; t < o.length; t++) {
		let n = o[e], r = o[t];
		if (n.edgeId !== r.edgeId && n.start !== r.start && n.start !== r.end && n.end !== r.start && n.end !== r.end && Pt(n.p1, n.p2, r.p1, r.p2)) {
			let e = n.edgeId < r.edgeId ? `${n.edgeId}|${r.edgeId}` : `${r.edgeId}|${n.edgeId}`;
			s.has(e) || (s.add(e), i.push({
				type: "edge-edge-crossing",
				edgeId: n.edgeId,
				targetId: r.edgeId,
				detail: `edges "${n.edgeId}" and "${r.edgeId}" cross`
			}));
		}
	}
	if (i.length > 0) {
		let e = i.filter((e) => e.type === "edge-node-overlap").length, n = i.filter((e) => e.type === "edge-edge-crossing").length;
		t.warn(`[SWIMLANE_VALIDATE] ${i.length} issue(s) detected: ${e} edge-node overlap(s), ${n} edge crossing(s)`);
		for (let e of i) t.warn(`[SWIMLANE_VALIDATE]   ${e.type}: ${e.detail}`);
	}
	return i;
}
r(Ft, "validateSwimlanesLayout");
function It(e, t) {
	let n = e.nodes ?? [], i = e.edges ?? [], a = n.filter((e) => !e.isGroup);
	if ((t === "LR" || t === "RL") && a.length > 0 && !rt(e, t) || t === "BT" && a.length > 0 && !nt(e)) return;
	for (let e of i) {
		if (e.isLayoutOnly) continue;
		let t = e.points;
		!t || t.length < 2 || (e.points = Ce(Se(t)));
	}
	xt(i, n), Mt(i, n), st(i, n);
	let o = /* @__PURE__ */ new Map();
	for (let e of n) o.set(String(e.id), e);
	Dt(i, o), ke(i, o), ct(i, o), Nt(i, o), ut(i, o), dt(i, o), ft(i, o), ht(i, o);
	let s = /* @__PURE__ */ r(() => {
		vt(i, o), gt(i, o), _t(i, o), Dt(i, o), Je(i, o), ft(i, o), Dt(i, o), Je(i, o);
	}, "finalizeRenderedEdges");
	s(), Nt(i, o), s(), pt(i, o), mt(i, o), pt(i, o), mt(i, o);
}
r(It, "postProcessSwimlaneLayout");
function Lt(e) {
	let t = new Map(e.nodeById), n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e.edges) {
		if (!t.has(i.src) || !t.has(i.dst)) continue;
		let e = `${i.id}:${i.src}->${i.dst}`;
		n.has(e) || (n.add(e), r.push(i));
	}
	return {
		nodes: [...t.keys()],
		edges: r,
		layout: e.layout,
		nodeById: t
	};
}
r(Lt, "normalizeGraph");
function Rt(e, t) {
	return e.edges.filter((e) => e.dst === t);
}
r(Rt, "incoming");
function zt(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.nodes) t.set(n, []);
	for (let n of e.edges) t.get(n.src).push(n.dst);
	return t;
}
r(zt, "buildSuccessorMap");
function Bt(e) {
	let t = zt(e);
	for (let e of t.values()) e.sort((e, t) => e.localeCompare(t));
	return t;
}
r(Bt, "buildSortedSuccessorMap");
function Vt(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.nodes) t.set(n, 0);
	for (let n of e.edges) t.set(n.dst, (t.get(n.dst) ?? 0) + 1);
	return t;
}
r(Vt, "buildInDegreeMap");
function Ht(e) {
	return [...e.entries()].filter(([, e]) => e === 0).map(([e]) => e).sort((e, t) => e.localeCompare(t));
}
r(Ht, "sortedZeroInDegreeNodes");
function Ut(e, t = () => !0) {
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
	for (let t of e.nodes) n.set(t, []), r.set(t, []);
	for (let i of e.edges) t(i) && (r.get(i.src).push(i.dst), n.get(i.dst).push(i.src));
	return {
		preds: n,
		succs: r
	};
}
r(Ut, "buildPredecessorSuccessorMaps");
function Wt(e, t, n, r) {
	let i = 0;
	for (let t of e.nodes) r?.skipGroups && e.nodeById.get(t)?.isGroup || (i = Math.max(i, n[t] ?? 0));
	let a = Array.from({ length: i + 1 }, () => []);
	for (let i of t) r?.skipGroups && e.nodeById.get(i)?.isGroup || a[Math.max(0, n[i] ?? 0)].push(i);
	return a;
}
r(Wt, "buildLayersFromRanks");
function Gt(e) {
	let t = Vt(e), n = Ht(t), r = [], i = Bt(e);
	for (; n.length;) {
		let e = n.shift();
		r.push(e);
		for (let r of i.get(e) ?? []) if (t.set(r, (t.get(r) ?? 0) - 1), (t.get(r) ?? 0) === 0) {
			let e = 0;
			for (; e < n.length && n[e] < r;) e++;
			n.splice(e, 0, r);
		}
	}
	return r.length === e.nodes.length ? r : null;
}
r(Gt, "topoSortIfAcyclic");
function Kt(e) {
	let t = /* @__PURE__ */ new Map(), n = 0;
	for (let r of e) t.set(r, n), n++;
	return t;
}
r(Kt, "buildLayerIndex");
function qt(e) {
	let t = Array(e.length), n = /* @__PURE__ */ r((r, i) => {
		if (i - r <= 1) return 0;
		let a = r + i >> 1, o = n(r, a) + n(a, i), s = r, c = a, l = r;
		for (; s < a || c < i;) c >= i || s < a && e[s] <= e[c] ? t[l++] = e[s++] : (t[l++] = e[c++], o += a - s);
		for (let n = r; n < i; n++) e[n] = t[n];
		return o;
	}, "count");
	return n(0, e.length);
}
r(qt, "countInversions");
function Jt(e) {
	let t = Lt(e), n = /* @__PURE__ */ new Map();
	for (let e of t.nodes) n.set(e, []);
	for (let e of t.edges) n.get(e.src).push(e);
	for (let e of n.values()) e.sort((e, t) => e.dst === t.dst ? e.id.localeCompare(t.id) : e.dst.localeCompare(t.dst));
	let i = /* @__PURE__ */ Object.create(null);
	for (let e of t.nodes) i[e] = 0;
	let a = [], o = /* @__PURE__ */ r((e) => {
		i[e] = 1;
		for (let t of n.get(e) ?? []) {
			let e = t.dst;
			i[e] === 0 ? o(e) : i[e] === 1 && a.push(t);
		}
		i[e] = 2;
	}, "dfs"), s = [...t.nodes].sort((e, t) => e.localeCompare(t));
	for (let e of s) i[e] === 0 && o(e);
	let c = new Set(a.map((e) => `${e.id}:${e.src}->${e.dst}`)), l = t.edges.map((e) => c.has(`${e.id}:${e.src}->${e.dst}`) ? {
		id: e.id,
		src: e.dst,
		dst: e.src,
		weight: e.weight,
		ref: e.ref
	} : e);
	return {
		acyclic: {
			nodes: [...t.nodes],
			edges: l,
			layout: t.layout,
			nodeById: new Map(t.nodeById)
		},
		reversed: a
	};
}
r(Jt, "removeCycles_DFS");
function Yt(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ r((r) => {
		if (t.has(r)) return t.get(r);
		let i = e.nodeById.get(r);
		if (!i) return t.set(r, null), null;
		let a = i.parentId;
		if (!a) return t.set(r, null), null;
		let o = n(a) ?? a;
		return t.set(r, o), o;
	}, "resolve");
	for (let t of e.nodes) n(t);
	return t;
}
r(Yt, "buildTopLaneMap");
function Xt(e) {
	let t = Yt(e);
	return (e) => t.get(e) ?? null;
}
r(Xt, "createTopLaneResolver");
function Zt(e) {
	let t = [];
	for (let n of e.layout.nodes ?? []) n.isGroup && !n.parentId && t.push(n.id);
	return [...new Set(t)].reverse();
}
r(Zt, "buildTopLaneOrder");
function Qt(e, t) {
	let n = Zt(e);
	if (!t || t.length === 0) return n;
	let r = new Set(n), i = /* @__PURE__ */ new Set(), a = [];
	for (let e of t) !r.has(e) || i.has(e) || (i.add(e), a.push(e));
	for (let e of n) i.has(e) || a.push(e);
	return a;
}
r(Qt, "resolveTopLaneOrder");
var $t = { EPSILON: 1e-6 }, en = {
	GRAVITY_ITERATIONS: 8,
	MAX_CROSSING_OPTIMIZATION_PASSES: 4,
	DEFAULT_COMPACT_SINGLE_INPUT: !0
}, tn = {
	DEFAULT_LAYER_GAP: 100,
	DEFAULT_NODE_GAP: 40
};
function nn(e, t) {
	let n = Lt(e), i = t?.laneOf ?? (() => null), a = t?.rankHint, { preds: o } = Ut(n);
	for (let e of o.values()) e.sort((e, t) => e.localeCompare(t));
	let s = Gt(n) ?? [...n.nodes].sort((e, t) => e.localeCompare(t)), c = /* @__PURE__ */ new Map();
	for (let [e, t] of s.entries()) c.set(t, e);
	let l = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new Map();
	for (let e of n.nodes) u.set(e, []);
	for (let e of s) {
		let t = (o.get(e) ?? []).filter((e) => l.has(e));
		if (t.length > 0) {
			let n = rn(e, t, {
				laneOf: i,
				rankHint: a,
				topoIndex: c
			});
			l.set(e, n), u.get(n).push(e);
		} else l.has(e) || l.set(e, null);
	}
	for (let e of n.nodes) l.has(e) || l.set(e, null);
	let d = /* @__PURE__ */ new Set();
	for (let e of n.nodes) (l.get(e) ?? null) === null && d.add(e);
	let f = [...d].sort((e, t) => {
		let n = c.get(e) ?? 0, r = c.get(t) ?? 0;
		return n === r ? e.localeCompare(t) : n - r;
	}), p = an(n), m = /* @__PURE__ */ new Map();
	for (let [e, t] of p.entries()) m.set(e, [...t].sort((e, t) => e.localeCompare(t)));
	let h = on(m), g = sn(m), _ = /* @__PURE__ */ new Map();
	for (let e of n.nodes) _.set(e, []);
	for (let e of g) for (let t of e.nodes) {
		let n = _.get(t);
		n ? n.push(e.id) : _.set(t, [e.id]);
	}
	let v = [], y = [], b = /* @__PURE__ */ new Set(), x = /* @__PURE__ */ r((e) => {
		if (!b.has(e)) {
			b.add(e), v.push(e);
			for (let t of u.get(e) ?? []) x(t);
			y.push(e);
		}
	}, "walk");
	for (let e of f) x(e);
	for (let e of s) x(e);
	return {
		parent: l,
		children: u,
		roots: f,
		componentOf: h,
		blocks: g,
		nodeBlocks: _,
		adjacency: m,
		preorder: v,
		postorder: y,
		topologicalOrder: s
	};
}
r(nn, "buildDrivingTree");
function rn(e, t, n) {
	let r = n.laneOf(e);
	return [...t].sort((e, t) => {
		let i = n.laneOf(e), a = n.laneOf(t), o = i != null && i === r;
		if (o !== (a != null && a === r)) return o ? -1 : 1;
		let s = n.rankHint?.[e], c = n.rankHint?.[t];
		if (s != null && c != null && s !== c) return c - s;
		let l = n.topoIndex.get(e) ?? 0, u = n.topoIndex.get(t) ?? 0;
		return l === u ? e.localeCompare(t) : l - u;
	})[0];
}
r(rn, "chooseParent");
function an(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.nodes) t.set(n, /* @__PURE__ */ new Set());
	for (let n of e.edges) t.get(n.src).add(n.dst), t.get(n.dst).add(n.src);
	return t;
}
r(an, "buildAdjacency");
function on(e) {
	let t = /* @__PURE__ */ new Map(), n = 0;
	for (let r of e.keys()) {
		if (t.has(r)) continue;
		let i = [r];
		for (; i.length > 0;) {
			let r = i.pop();
			if (!t.has(r)) {
				t.set(r, n);
				for (let n of e.get(r) ?? []) t.has(n) || i.push(n);
			}
		}
		n++;
	}
	return t;
}
r(on, "assignComponents");
function sn(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), i = [], a = [], o = 0, s = /* @__PURE__ */ r((r, c) => {
		t.set(r, ++o), n.set(r, o);
		for (let l of e.get(r) ?? []) l !== c && (t.has(l) ? (t.get(l) ?? 0) < (t.get(r) ?? 0) && (i.push([r, l]), n.set(r, Math.min(n.get(r) ?? o, t.get(l) ?? o))) : (i.push([r, l]), s(l, r), n.set(r, Math.min(n.get(r) ?? o, n.get(l) ?? o)), (n.get(l) ?? 0) >= (t.get(r) ?? 0) && a.push(cn(r, l, i, a.length))));
	}, "visit");
	for (let n of e.keys()) t.has(n) || s(n, null);
	return a;
}
r(sn, "computeBlocks");
function cn(e, t, n, r) {
	let i = [], a = /* @__PURE__ */ new Set();
	for (; n.length > 0;) {
		let r = n.pop();
		if (i.push(r), a.add(r[0]), a.add(r[1]), r[0] === e && r[1] === t || r[0] === t && r[1] === e) break;
	}
	return {
		id: r,
		edges: i,
		nodes: [...a]
	};
}
r(cn, "popBlock");
function ln(e, t, n) {
	let i = [...e.nodes], a = /* @__PURE__ */ new Map();
	for (let [e, t] of i.entries()) a.set(t, e);
	let o = i.length, s = Array(o).fill(-1), c = Array(o).fill(0), l = [], u = /* @__PURE__ */ new Set();
	for (let e of i) {
		let t = n.parent.get(e) ?? null, r = a.get(e);
		r != null && t == null && (s[r] = -1, c[r] = 0, u.has(e) || (u.add(e), l.push(e)));
	}
	for (; l.length > 0;) {
		let e = l.shift(), t = a.get(e);
		if (t == null) continue;
		let r = n.children.get(e) ?? [];
		for (let e of r) {
			if (u.has(e)) continue;
			let n = a.get(e);
			n != null && (s[n] = t, c[n] = c[t] + 1, u.add(e), l.push(e));
		}
	}
	for (let e of i) {
		if (u.has(e)) continue;
		let t = a.get(e);
		t != null && (s[t] = -1, c[t] = 0, u.add(e));
	}
	let d = Math.max(1, Math.ceil(Math.log2(Math.max(1, o))) + 1), f = Array.from({ length: d }, () => Array(o).fill(-1));
	for (let e = 0; e < o; e++) f[0][e] = s[e];
	for (let e = 1; e < d; e++) for (let t = 0; t < o; t++) {
		let n = f[e - 1][t];
		f[e][t] = n === -1 ? -1 : f[e - 1][n];
	}
	let p = /* @__PURE__ */ r((e, t) => {
		if (e === -1 || t === -1) return -1;
		c[e] < c[t] && ([e, t] = [t, e]);
		let n = c[e] - c[t];
		for (let t = 0; t < d; t++) if (n >> t & 1 && (e = f[t][e], e === -1)) return -1;
		if (e === t) return e;
		for (let n = d - 1; n >= 0; n--) {
			let r = f[n][e], i = f[n][t];
			r === -1 || i === -1 || r !== i && (e = r, t = i);
		}
		return f[0][e];
	}, "lcaIndex"), m = Array.from({ length: o }, () => /* @__PURE__ */ new Map());
	for (let n of e.edges) {
		let e = n.src, r = n.dst, i = t[e], o = t[r];
		if (i == null || o == null || (i > o && ([e, r] = [r, e], [i, o] = [o, i]), i == null || o == null || i === o)) continue;
		let s = a.get(e), c = a.get(r);
		if (s == null || c == null) continue;
		let l = p(s, c);
		if (l === -1) continue;
		let u = m[l];
		for (let e = i; e < o; e++) u.set(e, (u.get(e) ?? 0) + 1);
	}
	let h = /* @__PURE__ */ new Map(), g = /* @__PURE__ */ r((e, t) => {
		if (t.size !== 0) for (let [n, r] of t) e.set(n, (e.get(n) ?? 0) + r);
	}, "mergeInto"), _ = /* @__PURE__ */ new Set(), v = /* @__PURE__ */ r((e) => {
		let r = a.get(e);
		_.add(e);
		let i = r == null ? void 0 : m[r], o = i ? new Map(i) : /* @__PURE__ */ new Map(), s = n.children.get(e) ?? [];
		for (let n of s) {
			let r = v(n), i = t[e];
			if (i != null) {
				let a = h.get(e);
				a || (a = /* @__PURE__ */ new Map(), h.set(e, a));
				let o = r.get(i) ?? 0, s = t[n];
				s != null && s > i && (o += 1), a.set(n, o);
			}
			g(o, r);
		}
		return o;
	}, "dfs");
	for (let e of n.roots) _.has(e) || v(e);
	for (let e of i) _.has(e) || v(e);
	return h;
}
r(ln, "computeSubtreeCrossCounts");
function un(e, t, n) {
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ r((e) => {
		let r = n[e] ?? 0, o = [...t.get(e) ?? []];
		o.sort(dn(n));
		for (let e of o) {
			a(e);
			let t = i.get(e);
			t != null && (r = Math.min(r, t));
		}
		i.set(e, r);
	}, "annotate");
	for (let t of e) a(t);
	return i;
}
r(un, "annotateMinimumLayers");
function dn(e) {
	return (t, n) => {
		let r = e[t] ?? 0, i = e[n] ?? 0;
		return r === i ? t.localeCompare(n) : r - i;
	};
}
r(dn, "compareByRankThenId");
function fn(e, t, n, i) {
	let a = 0;
	for (let e of t) {
		let t = n[e] ?? 0;
		t > a && (a = t);
	}
	let o = Array.from({ length: a + 1 }, () => []), s = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ r((e) => {
		if (s.has(e)) return;
		s.add(e);
		let t = n[e] ?? 0;
		o[t] || (o[t] = []), o[t].push(e);
		for (let t of i(e)) c(t);
	}, "emit");
	for (let t of e) c(t);
	for (let e of t) if (!s.has(e)) {
		let t = n[e] ?? 0;
		o[t] || (o[t] = []), o[t].push(e), s.add(e);
	}
	return o;
}
r(fn, "emitNodesInTreeOrder");
function pn(e) {
	let t = [];
	for (let n of e) {
		let e = /* @__PURE__ */ new Set(), r = [];
		for (let t of n) e.has(t) || (e.add(t), r.push(t));
		t.push(r);
	}
	return t;
}
r(pn, "deduplicateLayers");
function mn(e, t, n, r) {
	return (i) => {
		let a = e.get(i) ?? [];
		if (a.length === 0) return [];
		let o = t[i] ?? 0, s = [], c = [], l = n.get(i);
		for (let e of a) {
			let t = r.get(e) ?? o;
			t > o ? s.push({
				child: e,
				min: t
			}) : c.push(e);
		}
		return s.sort((e, t) => e.min === t.min ? e.child.localeCompare(t.child) : e.min - t.min), c.sort((e, t) => {
			let n = l?.get(e) ?? 0, i = l?.get(t) ?? 0;
			if (n !== i) return n - i;
			let a = r.get(e) ?? o, s = r.get(t) ?? o;
			return a === s ? e.localeCompare(t) : a - s;
		}), [...s.map((e) => e.child), ...c];
	};
}
r(mn, "createChildOrderer");
function hn(e, t, n) {
	let r = nn(e, {
		rankHint: t,
		laneOf: n
	}), { children: i, roots: a } = r;
	for (let t of e.nodes) i.has(t) || i.set(t, []);
	let o = ln(e, t, r), s = [...a].sort(dn(t)), c = mn(i, t, o, un(s, i, t)), l = fn(s, e.nodes, t, c);
	return l = pn(l), l;
}
r(hn, "buildMultitreeLayerOrder");
function gn(e, t, n) {
	let r = new Set(e), i = new Set(t), a = Kt(t), o = [];
	for (let e of n) r.has(e.src) && i.has(e.dst) && o.push(a.get(e.dst));
	return qt(o);
}
r(gn, "countCrossingsBetweenAdjacent");
function _n(e, t, n) {
	let r = [];
	for (let e of t) {
		let t = n[e.src], i = n[e.dst];
		if (t == null || i == null || t === i) continue;
		let a = e.src, o = e.dst, s = t, c = i;
		t > i && (a = e.dst, o = e.src, s = i, c = t);
		for (let t = s; t < c; t++) r.push({
			id: `${e.id}@${t}`,
			src: a,
			dst: o,
			ref: e.ref
		});
	}
	let i = 0;
	for (let t = 0; t + 1 < e.length; t++) i += gn(e[t], e[t + 1], r);
	return i;
}
r(_n, "totalCrossings");
function vn(e, t) {
	let n = { ...t }, { preds: r } = Ut(e), i = Xt(e), a = _n(hn(e, n, i), e.edges, n), o = en.MAX_CROSSING_OPTIMIZATION_PASSES;
	for (let t = 0; t < o; t++) {
		let t = !1, o = [...e.nodes].sort((e, t) => (n[t] ?? 0) - (n[e] ?? 0));
		for (let s of o) {
			let o = n[s] ?? 0;
			if (o === 0) continue;
			let c = 0;
			for (let e of r.get(s) ?? []) c = Math.max(c, (n[e] ?? 0) + 1);
			if (c >= o) continue;
			let l = o;
			n[s] = c;
			let u = _n(hn(e, n, i), e.edges, n);
			u < a ? (a = u, t = !0) : n[s] = l;
		}
		if (!t) break;
	}
	return n;
}
r(vn, "optimizeRanksByCrossings");
function yn(e, t) {
	let n = Xt(e), r = [...e.nodes].sort((e, n) => (t[e] ?? 0) - (t[n] ?? 0) || e.localeCompare(n));
	for (let i of r) {
		let r = n(i);
		if (!r) continue;
		let a = e.edges.filter((e) => e.src === i);
		if (a.length === 0) continue;
		let o = !1, s = 0;
		for (let e of a) {
			let t = n(e.dst);
			t == null || t === r ? o = !0 : s++;
		}
		if (s === 0 || o) continue;
		let c = 0, l = !1;
		for (let t of e.edges) {
			if (t.dst !== i) continue;
			let e = n(t.src);
			e && (e === r ? l = !0 : c++);
		}
		if (c > 0 || !l) continue;
		let u = t[i] ?? 0, d = u + s, f = 0;
		for (let n of e.edges) n.dst === i && (f = Math.max(f, (t[n.src] ?? 0) + 1));
		let p = Math.max(u, f, d);
		p !== u && (t[i] = p);
	}
}
r(yn, "adjustCrossLaneSources");
function bn(e, t) {
	let n = Lt(e), r = Gt(n) ?? [...n.nodes].sort(), i = t?.compactSingleInput ?? !1, a = Xt(n), o = /* @__PURE__ */ Object.create(null);
	for (let e of r) {
		let r = Rt(n, e), s = t?.ignoreCrossLaneEdges ? r.filter((t) => {
			let n = a(t.src), r = a(e);
			return !n || !r || n === r;
		}) : r;
		if (s.length === 0) o[e] = 0;
		else if (i && s.length === 1) {
			let t = s[0].src;
			a(t) === a(e) ? o[e] = (o[t] ?? 0) + 1 : o[e] = o[t] ?? 0;
		} else {
			let t = -1 / 0;
			for (let e of s) t = Math.max(t, (o[e.src] ?? 0) + 1);
			o[e] = t === -1 / 0 ? 0 : t;
		}
	}
	return (t?.optimizeRanksByCrossings ?? !1) && (o = vn(n, o)), t?.ignoreCrossLaneEdges && yn(n, o), {
		layers: hn(n, o, a),
		rankOf: o,
		dummy: /* @__PURE__ */ new Set()
	};
}
r(bn, "assignLayers_LongestPath");
function xn(e, t) {
	let n = Lt(e), i = { ...bn(n, {
		compactSingleInput: t?.compactSingleInput,
		ignoreCrossLaneEdges: t?.ignoreCrossLaneEdges,
		optimizeRanksByCrossings: t?.optimizeRanksByCrossings
	}).rankOf }, a = Xt(n), { preds: o, succs: s } = Ut(n, (e) => {
		if (t?.ignoreCrossLaneEdges) {
			let t = a(e.src), n = a(e.dst);
			if (t && n && t !== n) return !1;
		}
		return !0;
	}), c = Gt(n) ?? [...n.nodes], l = [...c].reverse(), u = /* @__PURE__ */ r((e, t) => {
		let n = 0;
		for (let t of o.get(e) ?? []) n = Math.max(n, (i[t] ?? 0) + 1);
		let r = Infinity, a = s.get(e) ?? [];
		return a.length > 0 && (r = Math.min(...a.map((e) => (i[e] ?? 0) - 1))), Number.isFinite(r) || (r = Math.max(n, t)), Math.min(Math.max(t, n), r);
	}, "clampFeasible"), d = en.GRAVITY_ITERATIONS, f = /* @__PURE__ */ r((e) => {
		let t = !1;
		for (let n of e) {
			let e = o.get(n) ?? [], r = s.get(n) ?? [];
			if (e.length === 0 && r.length === 0) continue;
			let a = e.length > 0 ? e.reduce((e, t) => e + (i[t] ?? 0) + 1, 0) / e.length : i[n] ?? 0, c = r.length > 0 ? r.reduce((e, t) => e + (i[t] ?? 0) - 1, 0) / r.length : i[n] ?? 0, l = Math.round((a + c) / 2), d = u(n, l);
			d !== i[n] && (i[n] = d, t = !0);
		}
		return t;
	}, "relaxOrder");
	for (let e = 0; e < d; e++) {
		let e = f(c), t = f(l);
		if (!e && !t) break;
	}
	for (let e of c) {
		let t = 0;
		for (let n of o.get(e) ?? []) t = Math.max(t, (i[n] ?? 0) + 1);
		(i[e] ?? 0) < t && (i[e] = t);
	}
	for (let e of l) {
		let t = s.get(e) ?? [];
		if (t.length > 0) {
			let n = Math.min(...t.map((e) => (i[e] ?? 0) - 1));
			(i[e] ?? 0) > n && (i[e] = n);
		}
	}
	return {
		layers: Wt(n, c, i),
		rankOf: i,
		dummy: /* @__PURE__ */ new Set()
	};
}
r(xn, "assignLayers_Gravity");
function Sn(e) {
	let t = Vt(e), n = Bt(e), r = Ht(t), i = [];
	for (; r.length > 0;) {
		let e = [];
		for (let a of r) {
			i.push(a);
			for (let r of n.get(a) ?? []) t.set(r, (t.get(r) ?? 0) - 1), (t.get(r) ?? 0) === 0 && e.push(r);
		}
		r = e.sort((e, t) => e.localeCompare(t));
	}
	return i.length === e.nodes.length ? i : null;
}
r(Sn, "topoSortByGenerationIfAcyclic");
function Cn(e, t) {
	let n = Lt(e), i = t?.direction === "LR" ? Sn(n) ?? [...n.nodes].sort() : Gt(n) ?? [...n.nodes].sort(), a = Xt(n), o = /* @__PURE__ */ r((e) => a(e) ?? e, "laneOf"), s = /* @__PURE__ */ Object.create(null), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ r((e, n) => t?.ignoreCrossLaneEdges ?? !0 ? +(o(e) === o(n)) : 1, "edgeWeight");
	for (let e of i) {
		if (n.nodeById.get(e)?.isGroup) continue;
		let t = Rt(n, e), r = 0;
		if (t.length > 0) for (let n of t) {
			let t = n.src, i = s[t] ?? 0;
			r = Math.max(r, i + l(t, e));
		}
		let i = o(e), a = c.get(i) ?? 0, u = Math.max(r, a);
		s[e] = u, c.set(i, u + 1);
	}
	return {
		layers: Wt(n, i, s, { skipGroups: !0 }),
		rankOf: s,
		dummy: /* @__PURE__ */ new Set()
	};
}
r(Cn, "assignLayers_LaneAwareCompact");
function wn(e, t) {
	let n = Lt(t), { rankOf: i } = e, a = e.layers.map((e) => [...e]), o = new Set(e.dummy ? [...e.dummy] : []), s = 0, c = new Map(n.nodeById), l = /* @__PURE__ */ r((e) => {
		let t = `placeholder-${s++}`, n = {
			id: t,
			isGroup: !1,
			isDummy: !0,
			width: 0,
			height: 0
		};
		for (c.set(t, n), o.add(t); a.length <= e;) a.push([]);
		return a[e].push(t), i[t] = e, t;
	}, "addDummyAt"), u = [...n.edges].sort((e, t) => e.id === t.id ? e.src === t.src ? e.dst.localeCompare(t.dst) : e.src.localeCompare(t.src) : e.id.localeCompare(t.id)), d = [];
	for (let e of u) {
		let t = i[e.src] ?? 0, n = i[e.dst] ?? 0;
		if (n - t <= 1) {
			d.push(e);
			continue;
		}
		let r = e.src;
		for (let i = t + 1, a = 0; i < n; i++, a++) {
			let t = l(i);
			d.push({
				id: `${e.id}#${a}`,
				src: r,
				dst: t,
				weight: e.weight,
				ref: e.ref
			}), r = t;
		}
		let a = n - t - 2;
		d.push({
			id: `${e.id}#${Math.max(a + 1, 0)}`,
			src: r,
			dst: e.dst,
			weight: e.weight,
			ref: e.ref
		});
	}
	let f = {
		nodes: [...n.nodes, ...[...o].filter((e) => !n.nodes.includes(e))],
		edges: d,
		layout: n.layout,
		nodeById: c
	};
	return {
		layering: {
			layers: a,
			rankOf: i,
			dummy: o
		},
		graphWithDummies: f
	};
}
r(wn, "makeProperLayering");
function Tn(e) {
	let t = e.length;
	if (t === 0) return Infinity;
	let n = [...e].sort((e, t) => e - t);
	return t % 2 == 1 ? n[(t - 1) / 2] : .5 * (n[t / 2 - 1] + n[t / 2]);
}
r(Tn, "median");
function En(e) {
	return e.length === 0 ? Infinity : e.reduce((e, t) => e + t, 0) / e.length;
}
r(En, "barycenter");
function Dn(e, t, n, r) {
	let i = /* @__PURE__ */ new Map();
	for (let t of e) i.set(t, []);
	for (let e of n) r === "down" ? t.has(e.src) && i.has(e.dst) && i.get(e.dst).push(t.get(e.src)) : t.has(e.dst) && i.has(e.src) && i.get(e.src).push(t.get(e.dst));
	return i;
}
r(Dn, "neighborPositionsFor");
function On(e, t, n) {
	let r = n.get(e) ?? 0, i = n.get(t) ?? 0;
	return r === i ? e.localeCompare(t) : r - i;
}
r(On, "currentOrderTieBreak");
function kn(e, t, n) {
	let r = new Set(e), i = new Set(t), a = Kt(e), o = Kt(t), s = [];
	for (let e of n) r.has(e.src) && i.has(e.dst) && s.push({
		u: a.get(e.src),
		v: o.get(e.dst)
	});
	return s.sort((e, t) => e.u === t.u ? e.v - t.v : e.u - t.u), qt(s.map((e) => e.v));
}
r(kn, "countCrossingsBetweenAdjacent");
function An(e, t, n) {
	return [...e].sort((e, r) => {
		let i = Tn(t.get(e) ?? []), a = Tn(t.get(r) ?? []);
		return i === a ? On(e, r, n) : isFinite(i) ? isFinite(a) ? i - a : -1 : 1;
	});
}
r(An, "sortByHeuristic");
function jn(e, t, n, r, i, a) {
	let o = Kt(e), s = Kt(t), c = Dn(t, o, n, r);
	if (!i || !a || a.length === 0) return An(t, c, s);
	let l = /* @__PURE__ */ new Map();
	for (let e of t) {
		let t = i(e), n = l.get(t) ?? [];
		n.push(e), l.set(t, n);
	}
	let u = [];
	for (let e of a) {
		let t = l.get(e);
		if (!t || t.length === 0) continue;
		let n = An(t, c, s);
		u.push(...n);
	}
	let d = l.get(null);
	if (d && d.length > 0) {
		let e = An(d, c, s);
		for (let t of e) {
			let e = En(c.get(t) ?? []), n = u.length;
			if (isFinite(e)) {
				for (let [t, r] of u.entries()) if (e < En(c.get(r) ?? [])) {
					n = t;
					break;
				}
			}
			u.splice(n, 0, t);
		}
	}
	return u;
}
r(jn, "reorderLayer");
function Mn(e, t, n, i, a) {
	let o = [...t], s = new Set(e), c = new Set(t), l = i ? new Set(i) : null, u = n.filter((e) => s.has(e.src) && c.has(e.dst)), d = l ? n.filter((e) => c.has(e.src) && l.has(e.dst)) : void 0, f = /* @__PURE__ */ r((t) => {
		let n = kn(e, t, u);
		return d && i && (n += kn(t, i, d)), n;
	}, "crossingScore"), p = a ? /* @__PURE__ */ new Map() : null;
	if (a && p) for (let e of t) p.set(e, a(e));
	let m = !0, h = f(o);
	for (; m;) {
		m = !1;
		for (let e = 0; e + 1 < o.length; e++) {
			if (p && p.get(o[e]) !== p.get(o[e + 1])) continue;
			let t = h;
			[o[e], o[e + 1]] = [o[e + 1], o[e]];
			let n = f(o);
			n < t ? (h = n, m = !0) : [o[e], o[e + 1]] = [o[e + 1], o[e]];
		}
	}
	return o;
}
r(Mn, "transposeImprove");
function Nn(e, t, n) {
	let r = e.layers.map((e) => [...e]), i = t.edges, a = Xt(t), o = Qt(t, n?.laneOrder);
	for (let e = 0; e < 3; e++) {
		for (let e = 1; e < r.length; e++) r[e] = jn(r[e - 1], r[e], i, "down", a, o), r[e] = Mn(r[e - 1], r[e], i, r[e + 1], a);
		for (let e = r.length - 2; e >= 0; e--) r[e] = jn(r[e + 1], r[e], i, "up", a, o), r[e] = Mn(r[e + 1], r[e], i, r[e - 1], a);
	}
	return { layers: r };
}
r(Nn, "orderLayers");
function Pn(e, t, n) {
	let i = n?.layerGap ?? tn.DEFAULT_LAYER_GAP, a = n?.nodeGap ?? tn.DEFAULT_NODE_GAP, o = n?.laneGap ?? a * 2, s = n?.direction ?? "TB", c = s === "LR" || s === "RL", l = e.layers, u = /* @__PURE__ */ Object.create(null), d = /* @__PURE__ */ Object.create(null), f = /* @__PURE__ */ r((e) => t.nodeById.get(e), "getNode"), p = /* @__PURE__ */ r((e) => f(e)?.width ?? 0, "getWidth"), m = /* @__PURE__ */ r((e) => f(e)?.height ?? 0, "getHeight"), h = Xt(t), g = Qt(t, n?.laneOrder), _ = l.map((e) => e.reduce((e, t) => Math.max(e, m(t)), 0)), v = [];
	if (c) for (let e = 0; e + 1 < l.length; e++) {
		let t = l[e].reduce((e, t) => Math.max(e, p(t)), 0), n = l[e + 1].reduce((e, t) => Math.max(e, p(t)), 0), r = _[e], a = _[e + 1], o = r / 2 + a / 2, s = (t + n) / 2, c = Math.max(0, s - o - i);
		v.push(c);
	}
	let y = /* @__PURE__ */ new Set();
	for (let e of l) for (let t of e) y.add(h(t));
	let b = y.has(null), x = g.filter((e) => y.has(e)), S = [...b ? [null] : [], ...x], C = /* @__PURE__ */ Object.create(null);
	for (let e of x) C[e] = 0;
	b && (C.null = 0);
	for (let e of l) {
		let t = /* @__PURE__ */ Object.create(null), n = [];
		for (let r of e) {
			let e = h(r);
			e === null ? n.push(r) : (t[e] ||= []).push(r);
		}
		for (let [e, n] of Object.entries(t)) {
			let t = n.reduce((e, t) => e + p(t), 0) + a * Math.max(0, n.length - 1);
			C[e] = Math.max(C[e] ?? 0, t);
		}
		if (b && n.length) {
			let e = n.reduce((e, t) => e + p(t), 0) + a * Math.max(0, n.length - 1);
			C.null = Math.max(C.null ?? 0, e);
		}
	}
	let w = /* @__PURE__ */ new Map();
	{
		let e = S.map((e) => (e === null ? C.null : C[e]) ?? 0), t = -(e.reduce((e, t) => e + t, 0) + o * Math.max(0, S.length - 1)) / 2;
		for (let n = 0; n < S.length; n++) {
			let r = S[n], i = e[n] ?? 0, a = t + i / 2;
			w.set(r, a), t += i, n < S.length - 1 && (t += o);
		}
	}
	let T = 0;
	for (let [e, t] of l.entries()) {
		let n = _[e] ?? 0, r = /* @__PURE__ */ new Map();
		for (let e of t) {
			let t = h(e), n = r.get(t) ?? [];
			n.push(e), r.set(t, n);
		}
		for (let e of S) {
			let t = r.get(e) ?? [];
			if (t.length === 0) continue;
			let i = w.get(e);
			if (t.length === 1) {
				let e = t[0];
				u[e] = i, d[e] = T + n / 2;
			} else {
				let e = t.map((e) => p(e)), r = i - (e.reduce((e, t) => e + t, 0) + a * (t.length - 1)) / 2;
				for (let [i, o] of t.entries()) {
					let t = e[i];
					u[o] = r + t / 2, d[o] = T + n / 2, r += t + a;
				}
			}
		}
		let o = v[e] ?? 0;
		T += n + i + o;
	}
	let E = /* @__PURE__ */ new Map();
	for (let e of t.edges) {
		let t = e.ref.id;
		E.has(t) || E.set(t, []), E.get(t).push(e);
	}
	for (let [, e] of E) {
		if (e.length === 0) continue;
		let n = e[0].ref, r = n.start, i = n.end;
		if (r == null || i == null) continue;
		let a = Math.round(((u[r] ?? 0) + (u[i] ?? 0)) / 2), o = /* @__PURE__ */ new Set();
		for (let t of e) o.add(t.src), o.add(t.dst);
		for (let e of o) e !== r && e !== i && t.nodeById.get(e)?.isDummy && (u[e] = a);
	}
	return {
		x: u,
		y: d
	};
}
r(Pn, "assignCoordinates");
var Fn = 8;
function In(e) {
	let t = 2166136261;
	for (let n = 0; n < e.length; n++) t ^= e.charCodeAt(n), t = Math.imul(t, 16777619);
	return t >>> 0;
}
r(In, "hashString");
function Ln(e) {
	let t = e >>> 0;
	return () => {
		t += 1831565813;
		let e = t;
		return e = Math.imul(e ^ e >>> 15, e | 1), e ^= e + Math.imul(e ^ e >>> 7, e | 61), ((e ^ e >>> 14) >>> 0) / 4294967296;
	};
}
r(Ln, "mulberry32");
function Rn(e, t) {
	let n = [...e], r = Ln(t);
	for (let e = n.length - 1; e > 0; e--) {
		let t = Math.floor(r() * (e + 1));
		[n[e], n[t]] = [n[t], n[e]];
	}
	return n;
}
r(Rn, "deterministicShuffle");
function zn(e, t) {
	let n = 0;
	for (let [r, i] of e.entries()) n += Math.abs(r - (t.get(i) ?? r));
	return n;
}
r(zn, "sourceDistance");
function Bn(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let [t, r] of e.entries()) n.set(r, t);
	let r = 0;
	for (let { a: e, b: i, weight: a } of t) {
		let t = n.get(e), o = n.get(i);
		t == null || o == null || (r += a * Math.abs(t - o));
	}
	return r;
}
r(Bn, "laneArrangementCost");
function Vn(e) {
	let t = Zt(e);
	if (t.length < 2) return [];
	let n = new Map(t.map((e, t) => [e, t])), r = Xt(e), i = /* @__PURE__ */ new Map();
	for (let t of e.layout.edges ?? []) {
		if (t.isLayoutOnly) continue;
		let a = typeof t.start == "string" ? t.start : void 0, o = typeof t.end == "string" ? t.end : void 0;
		if (!a || !o || !e.nodeById.has(a) || !e.nodeById.has(o)) continue;
		let s = r(a), c = r(o);
		if (!s || !c || s === c) continue;
		let l = n.get(s), u = n.get(c);
		if (l == null || u == null) continue;
		let [d, f] = l <= u ? [s, c] : [c, s], p = `${d}\0${f}`, m = i.get(p);
		m ? m.weight++ : i.set(p, {
			a: d,
			b: f,
			weight: 1
		});
	}
	return [...i.values()];
}
r(Vn, "buildWeightedLaneEdges");
function Hn(e, t, n) {
	let r = [...e], i = Bn(r, t), a = !0, o = 0, s = Math.max(1, r.length);
	for (; a && o < s;) {
		a = !1, o++;
		for (let e = 0; e + 1 < r.length; e++) {
			[r[e], r[e + 1]] = [r[e + 1], r[e]];
			let n = Bn(r, t);
			n < i ? (i = n, a = !0) : [r[e], r[e + 1]] = [r[e + 1], r[e]];
		}
	}
	return {
		order: r,
		cost: i,
		sourceDistance: zn(r, n)
	};
}
r(Hn, "greedySwitch");
function Un(e, t) {
	return e.cost === t.cost ? e.sourceDistance < t.sourceDistance : e.cost < t.cost;
}
r(Un, "isBetterCandidate");
function Wn(e, t, n) {
	let r = [...t].sort((e, t) => e.a === t.a ? e.b.localeCompare(t.b) : e.a.localeCompare(t.a)).map(({ a: e, b: t, weight: n }) => `${e}:${t}:${n}`).join("|");
	return In(`${e.join("|")}#${r}#${n}`);
}
r(Wn, "seedForRestart");
function Gn(e, t = {}) {
	let n = Zt(e);
	if (n.length < 2) return n;
	let r = Vn(e);
	if (r.length === 0) return n;
	let i = new Map(n.map((e, t) => [e, t])), a = Hn(n, r, i), o = Math.max(0, t.restarts ?? Fn);
	for (let e = 0; e < o; e++) {
		let t = Hn(Rn(n, Wn(n, r, e)), r, i);
		Un(t, a) && (a = t);
	}
	return a.order;
}
r(Gn, "optimizeTopLaneOrder");
function Kn(e, t) {
	let n = t?.ignoreCrossLaneEdges ?? !0, r = t?.optimizeRanksByCrossings ?? !0, i = Lt(e), a = t?.automaticLaneOrdering ? Gn(i, { restarts: Fn }) : void 0, o = Jt(i), s = o.acyclic, { layering: c, graphWithDummies: l } = wn(n ? Cn(s, {
		compactSingleInput: t?.compactSingleInput ?? en.DEFAULT_COMPACT_SINGLE_INPUT,
		ignoreCrossLaneEdges: !0,
		direction: t?.direction
	}) : xn(s, {
		compactSingleInput: t?.compactSingleInput ?? en.DEFAULT_COMPACT_SINGLE_INPUT,
		ignoreCrossLaneEdges: !1,
		optimizeRanksByCrossings: r
	}), s), u = Nn(c, l, { laneOrder: a }), d = Pn(u, l, {
		layerGap: t?.layerGap,
		nodeGap: t?.nodeGap,
		direction: t?.direction,
		laneOrder: a
	});
	return {
		acyclic: s,
		reversed: o.reversed,
		layering: c,
		ordered: u,
		coordinates: d
	};
}
r(Kn, "sugiyamaLayout");
var $ = $t.EPSILON, qn = 8, Jn = 15, Yn = 15, Xn = 25, Zn = 20, Qn = 10;
function $n(e, t, n) {
	let r = e.x ?? 0, i = e.y ?? 0, a = t.x - r, o = t.y - i, s = Math.abs(a), c = Math.abs(o);
	return s < $ && c < $ ? n : c > $ && c * 3 >= s ? o > 0 ? "bottom" : "top" : s > $ ? a > 0 ? "right" : "left" : n;
}
r($n, "chooseOrthogonalSide");
function er(e, t) {
	return Math.abs(e.to - t.from) < $ || Math.abs(e.to - t.to) < $ ? e.to : e.from;
}
r(er, "sharedLineEndpointCoord");
function tr(e, t) {
	return e.orient === "vertical" ? {
		x: e.coord,
		y: t
	} : {
		x: t,
		y: e.coord
	};
}
r(tr, "pointOnLine");
function nr(e, t) {
	let n = e.nodes ?? [], i = e.edges ?? [], a = [];
	for (let e of i) e.isLayoutOnly || a.push({
		...e,
		__originalEdge: e
	});
	let o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), c = [], l = t === "LR";
	for (let e of n) o.set(e.id, e);
	let u = n.filter((e) => e.isGroup && !e.parentId);
	for (let e of u) {
		let t = { id: e.id }, i = /* @__PURE__ */ r((e) => {
			s.set(e.id, t), n.filter((t) => t.parentId === e.id).forEach(i);
		}, "assignLane");
		i(e);
	}
	let d = n.filter((e) => !e.isGroup && !e.isEdgeLabel).map((e) => {
		let t = e.width ?? 10, n = e.height ?? 10, r = e.x ?? 0, i = e.y ?? 0, a = qn;
		return {
			nodeId: e.id,
			minX: r - t / 2 - a,
			maxX: r + t / 2 + a,
			minY: i - n / 2 - a,
			maxY: i + n / 2 + a,
			visualXHalfExtent: l ? n / 2 + a : t / 2 + a
		};
	}), f = /* @__PURE__ */ r((e, t, n, r) => {
		let i = c.find((n) => n.orientation === e && Math.abs(n.coord - t) < 1);
		return i || (i = {
			id: `pipe-${e}-${t.toFixed(0)}`,
			orientation: e,
			coord: t,
			spanMin: n,
			spanMax: r,
			tracks: []
		}, c.push(i)), i.spanMin = Math.min(i.spanMin, n), i.spanMax = Math.max(i.spanMax, r), i;
	}, "getOrAddPipe"), p = /* @__PURE__ */ r((e, t) => {
		let n = e.width ?? 10, r = e.height ?? 10, i = e.x ?? 0, a = e.y ?? 0;
		switch (t) {
			case "top": return {
				x: i,
				y: a - r / 2
			};
			case "bottom": return {
				x: i,
				y: a + r / 2
			};
			case "left": return {
				x: i - n / 2,
				y: a
			};
			case "right": return {
				x: i + n / 2,
				y: a
			};
		}
	}, "portForSide"), m = /* @__PURE__ */ r((e, t, n) => p(e, $n(e, t, n ? "bottom" : "top")), "getOrthogonalPort"), h = [], g = [], _ = /* @__PURE__ */ new Set(), v = 1e3, y = /* @__PURE__ */ r((e, t, n) => {
		if (h.length === 0) return 0;
		let r = Math.abs(t.y - n.y) < $, i = Math.abs(t.x - n.x) < $;
		if (!r && !i) return 0;
		let a = 0;
		if (r) {
			let r = t.y, i = Math.min(t.x, n.x) - $, o = Math.max(t.x, n.x) + $;
			if (o <= i) return 0;
			for (let t of h) t.edgeIndex === e || t.orientation !== "vertical" || t.pipe.coord < i || t.pipe.coord > o || t.from - $ <= r && t.to + $ >= r && (a += v);
		} else if (i) {
			let r = t.x, i = Math.min(t.y, n.y) - $, o = Math.max(t.y, n.y) + $;
			if (o <= i) return 0;
			for (let t of h) t.edgeIndex === e || t.orientation !== "horizontal" || t.pipe.coord < i || t.pipe.coord > o || t.from - $ <= r && t.to + $ >= r && (a += v);
		}
		return a;
	}, "crossingPenalty"), b = a.map((e, t) => {
		if (!e.start || !e.end) return {
			idx: t,
			crossLane: 0,
			dx: 0,
			dy: 0
		};
		let n = o.get(e.start), r = o.get(e.end), i = s.get(e.start), a = s.get(e.end);
		return {
			idx: t,
			crossLane: i && a && i.id !== a.id ? 1 : 0,
			dx: n && r ? Math.abs((r.x ?? 0) - (n.x ?? 0)) : 0,
			dy: n && r ? Math.abs((r.y ?? 0) - (n.y ?? 0)) : 0
		};
	}).sort((e, t) => {
		if (e.crossLane !== t.crossLane) return t.crossLane - e.crossLane;
		let n = e.dx + e.dy, r = t.dx + t.dy;
		return Math.abs(n - r) > 1 ? n - r : e.idx - t.idx;
	}).map((e) => e.idx), x = /* @__PURE__ */ r((e, t, n, r) => {
		let i = Math.min(e.x, t.x), a = Math.max(e.x, t.x), o = Math.min(e.y, t.y), s = Math.max(e.y, t.y);
		return !!d.find((c) => n && c.nodeId === n || r && c.nodeId === r ? !1 : Math.abs(e.x - t.x) > $ ? c.minY < e.y && c.maxY > e.y && c.maxX > i && c.minX < a : c.minX < e.x && c.maxX > e.x && c.maxY > o && c.minY < s);
	}, "isSegmentBlocked"), S = /* @__PURE__ */ new Map(), C = /* @__PURE__ */ new Map();
	for (let e of a) !e.start || !e.end || e.start === e.end || (C.set(e.start, (C.get(e.start) ?? 0) + 1), C.set(e.end, (C.get(e.end) ?? 0) + 1));
	let w = /* @__PURE__ */ r((e, t) => $n(e, t, "bottom"), "determineSide"), T = /* @__PURE__ */ new Map();
	for (let [e, t] of a.entries()) {
		if (!t.start || !t.end || t.start === t.end || t.points && t.points.length > 0) continue;
		let n = o.get(t.start), r = o.get(t.end);
		if (!n || !r) continue;
		let i = (r.x ?? 0) - (n.x ?? 0), a = (r.y ?? 0) - (n.y ?? 0);
		T.set(e, {
			edgeIdx: e,
			srcId: t.start,
			dstId: t.end,
			srcSide: w(n, {
				x: r.x ?? 0,
				y: r.y ?? 0
			}),
			dstSide: w(r, {
				x: n.x ?? 0,
				y: n.y ?? 0
			}),
			absDx: Math.abs(i),
			absDy: Math.abs(a),
			dxSign: Math.sign(i),
			dySign: Math.sign(a)
		});
	}
	let E = /* @__PURE__ */ r((e) => e.srcSide === "top" || e.srcSide === "bottom" ? e.absDx === 0 ? 1 / 0 : e.absDy / e.absDx : e.absDy === 0 ? 1 / 0 : e.absDx / e.absDy, "preferenceStrength"), D = /* @__PURE__ */ r((e) => e.srcSide === "top" || e.srcSide === "bottom" ? e.dxSign >= 0 ? "right" : "left" : e.dySign >= 0 ? "bottom" : "top", "secondarySide"), O = /* @__PURE__ */ new Map();
	for (let e of T.values()) {
		let t = `${e.srcId}:${e.srcSide}`;
		O.has(t) || O.set(t, []), O.get(t).push(e);
	}
	let k = /* @__PURE__ */ new Map(), A = /* @__PURE__ */ r((e, t) => `${e}:${t}`, "loadKey");
	for (let e of T.values()) k.set(A(e.srcId, e.srcSide), (k.get(A(e.srcId, e.srcSide)) ?? 0) + 1), k.set(A(e.dstId, e.dstSide), (k.get(A(e.dstId, e.dstSide)) ?? 0) + 1);
	for (let e of O.values()) if (!(e.length < 2)) {
		e.sort((e, t) => {
			let n = E(e), r = E(t);
			return Math.abs(n - r) > 1e-9 ? r - n : e.edgeIdx - t.edgeIdx;
		});
		for (let t = 1; t < e.length; t++) {
			let n = e[t], r = D(n), i = k.get(A(n.srcId, n.srcSide)) ?? 0, a = k.get(A(n.srcId, r)) ?? 0;
			a >= i || (k.set(A(n.srcId, n.srcSide), i - 1), k.set(A(n.srcId, r), a + 1), n.srcSide = r);
		}
	}
	let j = /* @__PURE__ */ r((e) => {
		let t = e?.shape;
		return t === "question" || t === "diamond";
	}, "isDiamondNode"), ee = /* @__PURE__ */ new Map();
	for (let e of T.values()) ee.has(e.dstId) || ee.set(e.dstId, /* @__PURE__ */ new Set()), ee.get(e.dstId).add(e.dstSide);
	for (let e of T.values()) {
		if (!j(o.get(e.srcId))) continue;
		let t = ee.get(e.srcId);
		if (!t?.has(e.srcSide)) continue;
		let n = D(e);
		if (t.has(n) || (k.get(A(e.srcId, n)) ?? 0) > 0) continue;
		let r = k.get(A(e.srcId, e.srcSide)) ?? 0;
		k.set(A(e.srcId, e.srcSide), Math.max(0, r - 1)), k.set(A(e.srcId, n), 1), e.srcSide = n;
	}
	for (let e of T.values()) {
		let { edgeIdx: t, srcId: n, dstId: r, srcSide: i, dstSide: a } = e, s = o.get(n), c = o.get(r), l = `${n}:${i}:src`, u = i === "top" || i === "bottom" ? c.x ?? 0 : c.y ?? 0;
		S.has(l) || S.set(l, []), S.get(l).push({
			edgeIdx: t,
			oppositeCoord: u
		});
		let d = `${r}:${a}:dst`, f = a === "top" || a === "bottom" ? s.x ?? 0 : s.y ?? 0;
		S.has(d) || S.set(d, []), S.get(d).push({
			edgeIdx: t,
			oppositeCoord: f
		});
	}
	let te = /* @__PURE__ */ new Map();
	for (let [e, t] of S) {
		if (t.length < 2) continue;
		t.sort((e, t) => e.oppositeCoord - t.oppositeCoord);
		let n = e.split(":"), r = n.slice(0, -2).join(":"), i = n[n.length - 2], a = n[n.length - 1], s = o.get(r);
		if (!s) continue;
		let c = i === "left" || i === "right" ? s.height ?? 10 : s.width ?? 10, l = s.shape, u = l === "question" || l === "diamond" ? c * .3 : c, d = Math.min(20, Math.max(8, u / (t.length + 1))), f = -(d * (t.length - 1)) / 2;
		for (let [e, n] of t.entries()) {
			let t = f + e * d, r = `${n.edgeIdx}:${a}`;
			te.set(r, t);
		}
	}
	let M = /* @__PURE__ */ r((e) => !!a[e]?.labelNodeId, "edgeHasLabelNode"), ne = /* @__PURE__ */ r((e, t) => e ? (S.get(`${e}:${t}:src`) ?? []).some(({ edgeIdx: e }) => M(e)) || (S.get(`${e}:${t}:dst`) ?? []).some(({ edgeIdx: e }) => M(e)) : !1, "faceHasLabelNode"), re = /* @__PURE__ */ r((e, t, n) => t === "top" || t === "bottom" ? {
		x: e.x + n,
		y: e.y
	} : {
		x: e.x,
		y: e.y + n
	}, "applyPortOffset"), N = /* @__PURE__ */ r((e, t, n) => {
		let r = T.get(e), i = {
			x: n.x ?? 0,
			y: n.y ?? 0
		}, a = {
			x: t.x ?? 0,
			y: t.y ?? 0
		}, o = r?.srcSide ?? w(t, i), s = r?.dstSide ?? w(n, a), c = r ? p(t, r.srcSide) : m(t, i, !0), l = r ? p(n, r.dstSide) : m(n, a, !1), u = te.get(`${e}:src`), d = te.get(`${e}:dst`);
		return u !== void 0 && (c = re(c, o, u)), d !== void 0 && (l = re(l, s, d)), {
			pSrcPort: c,
			pDstPort: l,
			srcSide: o,
			dstSide: s
		};
	}, "portsForEdge");
	for (let e of b) {
		let t = a[e];
		if (g[e] = [], !t.start || !t.end || t.points && t.points.length > 0 || t.start === t.end) continue;
		let n = o.get(t.start), i = o.get(t.end);
		if (!n || !i) continue;
		let { pSrcPort: s, pDstPort: u, srcSide: p, dstSide: m } = N(e, n, i), v = { ...s }, b = { ...u }, w = p === "top" || p === "bottom", T = m === "top" || m === "bottom";
		w ? v.y = s.y > (n.y ?? 0) ? s.y + Zn : s.y - Zn : v.x = s.x > (n.x ?? 0) ? s.x + Zn : s.x - Zn, T ? b.y = u.y > (i.y ?? 0) ? u.y + Zn : u.y - Zn : b.x = u.x > (i.x ?? 0) ? u.x + Zn : u.x - Zn;
		let E = /* @__PURE__ */ r((e, t) => {
			for (let n of d) if (!t.includes(n.nodeId) && e.x > n.minX && e.x < n.maxX && e.y > n.minY && e.y < n.maxY) return {
				inside: !0,
				obstacle: n
			};
			return { inside: !1 };
		}, "isPointInObstacle"), D = /* @__PURE__ */ r((e, t, n, r, i) => {
			if (i) {
				let i = e.y > (t.y ?? 0);
				return {
					x: (n.x ?? 0) >= e.x ? r.maxX + Jn : r.minX - Jn,
					y: i ? r.maxY + Yn : r.minY - Yn,
					leavesPositiveSide: i
				};
			}
			let a = e.x > (t.x ?? 0), o = (n.y ?? 0) >= e.y;
			return {
				x: a ? r.maxX + Jn : r.minX - Jn,
				y: o ? r.maxY + Yn : r.minY - Yn,
				leavesPositiveSide: a
			};
		}, "obstacleDetour"), O = [], k = [t.start, t.end], A = E(v, k);
		if (A.inside && A.obstacle) {
			let e = A.obstacle;
			if (w) {
				let t = D(s, n, i, e, !0);
				v.x = t.x, v.y = t.y;
				let r = t.leavesPositiveSide ? Math.min(e.minY - 2, s.y + Zn) : Math.max(e.maxY + 2, s.y - Zn);
				O = [
					{
						x: s.x,
						y: r
					},
					{
						x: t.x,
						y: r
					},
					{
						x: t.x,
						y: t.y
					}
				];
			} else {
				let t = D(s, n, i, e, !1), r = t.leavesPositiveSide ? Math.min(e.minX - 2, s.x + Zn) : Math.max(e.maxX + 2, s.x - Zn);
				v.x = t.x, v.y = t.y, O = [
					{
						x: r,
						y: s.y
					},
					{
						x: r,
						y: t.y
					},
					{
						x: t.x,
						y: t.y
					}
				];
			}
		}
		let j = [], ee = E(b, k);
		if (ee.inside && ee.obstacle) {
			let e = ee.obstacle;
			if (T) {
				let t = D(u, i, n, e, !0);
				b.x = t.x, b.y = t.y, j = [{
					x: t.x,
					y: t.y
				}, {
					x: u.x,
					y: t.y
				}];
			} else {
				let t = D(u, i, n, e, !1);
				b.x = t.x, b.y = t.y, j = [{
					x: t.x,
					y: t.y
				}, {
					x: t.x,
					y: u.y
				}];
			}
		}
		if (O.length === 0 && j.length === 0) {
			let n = Jn, r = Math.abs(v.x - b.x) < n, i = Math.abs(v.y - b.y) < n, a = te.get(`${e}:src`) !== void 0 || te.get(`${e}:dst`) !== void 0, o = (S.get(`${t.start ?? ""}:${p}:src`)?.length ?? 0) + (S.get(`${t.start ?? ""}:${p}:dst`)?.length ?? 0), c = (S.get(`${t.end ?? ""}:${m}:src`)?.length ?? 0) + (S.get(`${t.end ?? ""}:${m}:dst`)?.length ?? 0), l = o > 1 || c > 1, d = C.get(t.start ?? "") ?? 0, f = C.get(t.end ?? "") ?? 0, g = o > 1 && ne(t.start, p) || c > 1 && ne(t.end, m);
			if ((r || i) && !a && (!l || l && !g && (o <= 1 || d <= 2) && (c <= 1 || f <= 2)) && !x(s, u, t.start, t.end)) {
				t.points = [
					{ ...s },
					{ ...v },
					{ ...b },
					{ ...u }
				], _.add(e);
				let n = i ? "horizontal" : "vertical", r = i ? s.y : s.x, a = i ? Math.min(s.x, u.x) : Math.min(s.y, u.y), o = i ? Math.max(s.x, u.x) : Math.max(s.y, u.y), c = {
					id: `fast-path-${n}-${r.toFixed(0)}-${e}`,
					orientation: n,
					coord: r,
					spanMin: a,
					spanMax: o,
					tracks: []
				};
				h.push({
					edgeIndex: e,
					segmentIndex: 0,
					orientation: n,
					pipe: c,
					trackIndex: 0,
					from: a,
					to: o
				});
				continue;
			}
		}
		v.x = f("vertical", v.x, v.y, v.y).coord, b.x = f("vertical", b.x, b.y, b.y).coord;
		let M = Math.min(v.x, b.x) - 50, re = Math.max(v.x, b.x) + 50, P = Math.min(v.y, b.y) - 50, F = Math.max(v.y, b.y) + 50;
		for (let e of d) {
			let t = Math.min(v.x, b.x), n = Math.max(v.x, b.x), r = Math.min(v.y, b.y), i = Math.max(v.y, b.y);
			e.minX < n && e.maxX > t && e.minY < i && e.maxY > r && (M = Math.min(M, e.minX - Xn), re = Math.max(re, e.maxX + Xn), P = Math.min(P, e.minY - Xn), F = Math.max(F, e.maxY + Xn));
		}
		for (let e of d) {
			if (e.maxX < M || e.minX > re || e.maxY < P || e.minY > F) continue;
			let t = Jn;
			f("horizontal", e.minY - t, M, re), f("horizontal", e.maxY + t, M, re);
			let n = Yn;
			f("vertical", e.minX - n, P, F), f("vertical", e.maxX + n, P, F);
		}
		f("horizontal", v.y, M, re), f("horizontal", b.y, M, re);
		let I = c.filter((e) => e.orientation === "horizontal" && e.coord >= P && e.coord <= F), L = c.filter((e) => e.orientation === "vertical" && e.coord >= M && e.coord <= re), R = /* @__PURE__ */ r((e, t) => `${e.toFixed(1)},${t.toFixed(1)}`, "getKey"), z = R(v.x, v.y), ie = R(b.x, b.y), B = /* @__PURE__ */ new Map(), V = /* @__PURE__ */ new Map(), ae = /* @__PURE__ */ new Map(), oe = /* @__PURE__ */ new Set(), H = [];
		B.set(z, 0), ae.set(z, "n"), H.push({
			key: z,
			f: Math.hypot(b.x - v.x, b.y - v.y),
			pt: v
		}), oe.add(z);
		let U = [], W = /* @__PURE__ */ r((e, n) => x(e, n, t.start, t.end), "checkSegmentBlocked"), se = {
			x: b.x,
			y: v.y
		}, ce = W(v, se), G = W(se, b), le = ce || G, ue = {
			x: v.x,
			y: b.y
		}, de = W(v, ue), fe = W(ue, b);
		if (le ? de || fe || (U = Math.abs(v.x - b.x) < $ ? [v, b] : [
			v,
			ue,
			b
		]) : U = Math.abs(v.y - b.y) < $ || Math.abs(v.x - b.x) < $ ? [v, b] : [
			v,
			se,
			b
		], U.length === 0) for (; H.length > 0;) {
			H.sort((e, t) => e.f - t.f);
			let n = H.shift();
			if (oe.delete(n.key), n.key === ie) {
				let e = ie, t = b;
				for (U = [t]; V.has(e);) {
					let n = V.get(e);
					U.unshift(n), t = n, e = R(n.x, n.y);
				}
				break;
			}
			let r = n.pt.x, i = n.pt.y, a = L.sort((e, t) => e.coord - t.coord), o = a.findIndex((e) => Math.abs(e.coord - r) < 1), s = I.sort((e, t) => e.coord - t.coord), c = s.findIndex((e) => Math.abs(e.coord - i) < 1), l = [];
			o > 0 && l.push({
				x: a[o - 1].coord,
				y: i
			}), o >= 0 && o < a.length - 1 && l.push({
				x: a[o + 1].coord,
				y: i
			}), c > 0 && l.push({
				x: r,
				y: s[c - 1].coord
			}), c >= 0 && c < s.length - 1 && l.push({
				x: r,
				y: s[c + 1].coord
			});
			for (let a of l) {
				let o = Math.min(r, a.x), s = Math.max(r, a.x), c = Math.min(i, a.y), l = Math.max(i, a.y);
				if (d.some((e) => e.nodeId === t.start || e.nodeId === t.end ? !1 : o === s ? e.minX < r && e.maxX > r && e.maxY > c && e.minY < l : e.minY < i && e.maxY > i && e.maxX > o && e.minX < s)) continue;
				let u = R(a.x, a.y), f = Math.abs(a.x - r) + Math.abs(a.y - i), p = y(e, n.pt, a), m = 0, h = b.x - v.x, g = b.y - v.y, _ = a.x - r, x = a.y - i;
				(g > 10 && x < -5 || g < -10 && x > 5) && (m = Math.abs(x) * 100), (h > 10 && _ < -5 || h < -10 && _ > 5) && (m += Math.abs(_) * 50);
				let S = 0, C = ae.get(n.key) ?? "n", w = Math.abs(_) > $ ? "h" : "v";
				C !== "n" && C !== w && (S = 50);
				let T = f + p + m + S, E = (B.get(n.key) ?? 1 / 0) + T, D = Math.abs(b.x - a.x) + Math.abs(b.y - a.y);
				if (E < (B.get(u) ?? 1 / 0)) {
					if (V.set(u, n.pt), B.set(u, E), ae.set(u, w), !oe.has(u)) H.push({
						key: u,
						f: E + D,
						pt: a
					}), oe.add(u);
					else {
						let e = H.findIndex((e) => e.key === u);
						e !== -1 && (H[e].f = E + D);
					}
				}
			}
		}
		if (U.length === 0 && (U = [
			v,
			{
				x: v.x,
				y: b.y
			},
			b
		]), U.length > 4) {
			let e = U[0], t = U[U.length - 1], n = Math.min(e.x, t.x), i = Math.max(e.x, t.x), a = Math.min(e.y, t.y), o = Math.max(e.y, t.y);
			for (let e of U) n = Math.min(n, e.x), i = Math.max(i, e.x), a = Math.min(a, e.y), o = Math.max(o, e.y);
			let s = i > Math.max(e.x, t.x), c = n < Math.min(e.x, t.x);
			if (l) {
				let r = Yn;
				if (s) {
					let n = Math.max(e.x, t.x), a = Math.min(e.y, t.y), o = Math.max(e.y, t.y), s = d.filter((e) => e.minX < n && e.maxX > n && e.minY < o && e.maxY > a);
					if (s.length > 0) {
						let n = Math.max(e.x, t.x);
						for (let e of s) {
							let t = (e.minX + e.maxX) / 2;
							if (e.visualXHalfExtent === void 0 || isNaN(e.visualXHalfExtent)) continue;
							let i = t + e.visualXHalfExtent + r;
							n = Math.max(n, i);
						}
						isNaN(n) || (i = n);
					}
				}
				if (c) {
					let i = d.filter((n) => n.minX < Math.min(e.x, t.x) + r && n.minY < Math.max(e.y, t.y) && n.maxY > Math.min(e.y, t.y));
					if (i.length > 0) {
						let a = Math.min(e.x, t.x);
						for (let e of i) {
							let t = (e.minX + e.maxX) / 2 - e.visualXHalfExtent - r;
							a = Math.min(a, t);
						}
						n = a;
					}
				}
			}
			let u = /* @__PURE__ */ r((n) => {
				let r = t.y > e.y, i = d.filter((n) => {
					let r = Math.min(e.x, t.x) < n.maxX && Math.max(e.x, t.x) > n.minX, i = Math.min(e.y, t.y) < n.maxY && Math.max(e.y, t.y) > n.minY;
					return r && i;
				}), a = i;
				if (l && i.length > 0) {
					let e = i.filter((e) => e.minX < n && e.maxX > n);
					e.length > 0 && (a = e);
				}
				if (a.length === 0) return t.y;
				let o = Jn;
				if (r) {
					let e = Math.max(...a.map((e) => e.maxY)) + o;
					if (e < t.y - $) return e;
				} else {
					let e = Math.min(...a.map((e) => e.minY)) - o;
					if (e > t.y + $) return e;
				}
				return t.y;
			}, "findBestReturnY"), f = /* @__PURE__ */ r((n) => {
				let r = u(n), i = {
					x: n,
					y: e.y
				}, a = {
					x: n,
					y: r
				}, o = {
					x: t.x,
					y: r
				}, s = W(e, i), c = W(i, a), l = W(a, o), d = r !== t.y && W(o, t);
				return !s && !c && !l && !d ? Math.abs(r - t.y) < $ ? [
					e,
					i,
					a,
					t
				] : [
					e,
					i,
					a,
					o,
					t
				] : null;
			}, "trySimplifyWithDetourX"), p = s && !c ? f(i) : c && !s ? f(n) : null;
			p && (U = p);
		}
		let K = [
			s,
			...O,
			...U,
			...j.reverse(),
			u
		];
		if (K.length >= 3) {
			let e = K[K.length - 1], t = K[K.length - 2], n = K[K.length - 3], r = Math.abs(n.y - t.y) < $ && Math.abs(t.y - e.y) < $, i = Math.abs(n.x - t.x) < $ && Math.abs(t.x - e.x) < $;
			if (r) {
				let r = Math.sign(t.x - n.x), i = Math.sign(e.x - n.x);
				r !== 0 && r === i && Math.abs(t.x - n.x) > Math.abs(e.x - n.x) && K.splice(-2, 1);
			} else if (i) {
				let r = Math.sign(t.y - n.y), i = Math.sign(e.y - n.y);
				r !== 0 && r === i && Math.abs(t.y - n.y) > Math.abs(e.y - n.y) && K.splice(-2, 1);
			}
		}
		let pe = [K[0]];
		for (let e = 1; e < K.length - 1; e++) {
			if (e === 1) {
				pe.push(K[e]);
				continue;
			}
			let t = pe[pe.length - 1], n = K[e], r = K[e + 1];
			if (Math.abs(t.y - n.y) < $ && Math.abs(n.y - r.y) < $) {
				if (n.x > t.x != r.x > n.x) {
					pe.push(n);
					continue;
				}
				continue;
			}
			if (Math.abs(t.x - n.x) < $ && Math.abs(n.x - r.x) < $) {
				if (n.y > t.y != r.y > n.y) {
					pe.push(n);
					continue;
				}
				continue;
			}
			pe.push(n);
		}
		pe.push(K[K.length - 1]);
		for (let t = 0; t < pe.length - 1; t++) {
			let n = pe[t], r = pe[t + 1], i = Math.abs(n.x - r.x) < $ ? "vertical" : "horizontal", a = i === "vertical" ? n.x : n.y, o = i === "vertical" ? Math.min(n.y, r.y) : Math.min(n.x, r.x), s = i === "vertical" ? Math.max(n.y, r.y) : Math.max(n.x, r.x), c = f(i, a, o, s), l = {
				edgeIndex: e,
				segmentIndex: t,
				orientation: i,
				pipe: c,
				trackIndex: 0,
				from: o,
				to: s
			};
			h.push(l), g[e].push(h.length - 1), c.tracks[0] || (c.tracks[0] = {
				index: 0,
				coord: c.coord,
				segments: []
			}), c.tracks[0].segments.push({
				edgeIndex: e,
				segmentIndex: t,
				from: o,
				to: s
			});
		}
	}
	let P = /* @__PURE__ */ r((e, t) => e.from < t.to && t.from < e.to, "segmentsOverlap"), F = /* @__PURE__ */ r((e, t, n, r) => {
		let i = !r.segments.some((n) => (n.edgeIndex !== t.edgeIndex || n.segmentIndex !== t.segmentIndex) && P(n, e)), a = !n.segments.some((n) => (n.edgeIndex !== e.edgeIndex || n.segmentIndex !== e.segmentIndex) && P(n, t));
		return i && a ? (e.trackIndex = r.index, t.trackIndex = n.index, n.segments = [...n.segments.filter((t) => t.edgeIndex !== e.edgeIndex || t.segmentIndex !== e.segmentIndex), {
			edgeIndex: t.edgeIndex,
			segmentIndex: t.segmentIndex,
			from: t.from,
			to: t.to
		}], r.segments = [...r.segments.filter((e) => e.edgeIndex !== t.edgeIndex || e.segmentIndex !== t.segmentIndex), {
			edgeIndex: e.edgeIndex,
			segmentIndex: e.segmentIndex,
			from: e.from,
			to: e.to
		}], !0) : !1;
	}, "trySwapSegmentsAcrossTracks"), I = /* @__PURE__ */ r((e) => {
		let t = e.tracks.length;
		return e.tracks[t] = {
			index: t,
			coord: e.coord,
			segments: []
		}, t;
	}, "createNewTrack"), L = /* @__PURE__ */ r((e, t) => {
		let n = e.pipe.tracks[e.trackIndex];
		n.segments = n.segments.filter((t) => t.edgeIndex !== e.edgeIndex || t.segmentIndex !== e.segmentIndex), e.trackIndex = t, e.pipe.tracks[t].segments.push({
			edgeIndex: e.edgeIndex,
			segmentIndex: e.segmentIndex,
			from: e.from,
			to: e.to
		});
	}, "moveSegmentToTrack"), R = /* @__PURE__ */ r((e, t) => {
		let n = g[e.edgeIndex];
		for (let r of n) {
			let n = h[r];
			n.pipe === e.pipe && L(n, t);
		}
	}, "moveSegmentChainToTrack"), z = /* @__PURE__ */ r((e) => {
		let t = g[e.edgeIndex], n = t.indexOf(h.indexOf(e)), r = [];
		return n > 0 && r.push(h[t[n - 1]]), n < t.length - 1 && r.push(h[t[n + 1]]), r;
	}, "getAdjacentSegmentsAlongEdge"), ie = /* @__PURE__ */ r((e, t) => {
		if (e.orientation === t.orientation) return !1;
		let n = e.orientation === "horizontal" ? e : t, r = e.orientation === "horizontal" ? t : e;
		return r.pipe.coord > n.from && r.pipe.coord < n.to && n.pipe.coord > r.from && n.pipe.coord < r.to;
	}, "haveAnyCrossing"), B = /* @__PURE__ */ r((e, t) => {
		for (let n of e.tracks) if (!n.segments.some((e) => (e.edgeIndex !== t.edgeIndex || e.segmentIndex !== t.segmentIndex) && P(e, t))) return n.index;
		return -1;
	}, "findAvailableTrack"), V = /* @__PURE__ */ r((e, t) => {
		if (e.trackIndex === t.trackIndex) return P(e, t);
		let n = z(e), r = z(t);
		return n.some((e) => r.some((t) => ie(e, t)));
	}, "segmentsConflict"), ae = /* @__PURE__ */ r((e, t, n) => {
		if (F(e, t, e.pipe.tracks[e.trackIndex], t.pipe.tracks[t.trackIndex])) return;
		let r = B(e.pipe, t);
		n(t, r === -1 ? I(e.pipe) : r);
	}, "resolveTrackConflict"), oe = /* @__PURE__ */ r((e) => {
		let t = 0;
		for (let n = 0; n < e.length; n++) for (let r = n + 1; r < e.length; r++) {
			let i = e[n], a = e[r];
			i.pipe === a.pipe && V(i, a) && (t++, ae(i, a, R));
		}
		return t;
	}, "resolveHandleConflicts"), H = /* @__PURE__ */ new Map(), U = /* @__PURE__ */ r((e) => {
		if (H.has(e)) return H.get(e);
		let t = g[e];
		if (t.length === 0) {
			let t = {
				dest: 0,
				deviation: 0,
				base: 0,
				delta: 0
			};
			return H.set(e, t), t;
		}
		let n = h[t[0]].pipe.coord, r = n;
		for (let e = 1; e < t.length; e++) {
			let i = h[t[e]];
			if (i.orientation === "horizontal") {
				let e = i.from, t = i.to;
				r = Math.abs(e - n) > Math.abs(t - n) ? e : t;
				break;
			}
		}
		let i = Math.abs(r - n), a = {
			dest: r,
			deviation: i,
			base: n,
			delta: r - n
		};
		return H.set(e, a), a;
	}, "getDestInfo"), W = /* @__PURE__ */ r(() => {
		let e = 0, t = /* @__PURE__ */ new Map();
		for (let [e, n] of a.entries()) g[e].length !== 0 && n.start && (t.has(n.start) || t.set(n.start, []), t.get(n.start).push(e));
		let n = /* @__PURE__ */ r((e) => {
			let t = a[e];
			if (!t.start || !t.end) return 0;
			let n = o.get(t.start), r = o.get(t.end);
			if (!n || !r) return 0;
			let i = (r.x ?? 0) - (n.x ?? 0), s = (r.y ?? 0) - (n.y ?? 0);
			return Math.abs(i) + Math.abs(s);
		}, "getEdgeDistance");
		for (let r of t.values()) {
			r.sort((e, t) => {
				let r = U(e), i = U(t);
				if (Math.abs(r.deviation - i.deviation) > 1) return r.deviation - i.deviation;
				if (Math.abs(r.dest - i.dest) > 1) return r.dest - i.dest;
				let a = n(e), o = n(t);
				if (Math.abs(a - o) > 1) return o - a;
				let s = g[e].length, c = g[t].length;
				if (s !== c) return s - c;
				if (s === 1) {
					let n = g[e][0], r = g[t][0];
					if (h[n] && h[r]) {
						let e = h[n], t = h[r], i = Math.abs(e.to - e.from), a = Math.abs(t.to - t.from);
						if (Math.abs(i - a) > 1) return i - a;
					}
				}
				return 0;
			});
			let t = r.map((e) => h[g[e][0]]);
			e += oe(t);
		}
		return e;
	}, "fixSourceHandleCrossings"), se = /* @__PURE__ */ r(() => {
		let e = 0, t = /* @__PURE__ */ new Map();
		for (let [e, n] of a.entries()) g[e].length !== 0 && n.end && (t.has(n.end) || t.set(n.end, []), t.get(n.end).push(e));
		for (let n of t.values()) {
			n.sort((e, t) => {
				let n = /* @__PURE__ */ r((e) => {
					let t = g[e];
					if (t.length < 2) return 0;
					let n = h[t[t.length - 2]];
					return Math.abs(n.to - n.from);
				}, "getDist"), i = n(e), a = n(t);
				return Math.abs(i - a) > .1 ? i - a : e - t;
			});
			let t = n.map((e) => h[g[e][g[e].length - 1]]);
			e += oe(t);
		}
		return e;
	}, "fixTargetHandleCrossings"), ce = /* @__PURE__ */ r(() => {
		let e = 0;
		for (let t of c) {
			let n = [];
			for (let e of t.tracks) for (let t of e.segments) {
				let e = g[t.edgeIndex].find((e) => h[e].segmentIndex === t.segmentIndex);
				e !== void 0 && n.push(h[e]);
			}
			n.sort((e, t) => e.edgeIndex - t.edgeIndex || e.segmentIndex - t.segmentIndex);
			for (let t = 0; t < n.length; t++) for (let r = t + 1; r < n.length; r++) {
				let i = n[t], a = n[r];
				V(i, a) && (e++, ae(i, a, L));
			}
		}
		return e;
	}, "fixPipeCrossings"), G = 0;
	for (; G < 10;) {
		let e = 0;
		if (e += W(), e += se(), e += ce(), e === 0) break;
		G++;
	}
	let le = /* @__PURE__ */ new Map();
	for (let e of c) {
		let t = [];
		e.tracks.forEach((e) => {
			e.segments.forEach((n) => {
				t.push({
					edgeIndex: n.edgeIndex,
					segmentIndex: n.segmentIndex,
					trackIndex: e.index,
					from: n.from,
					to: n.to
				});
			});
		}), t.sort((e, t) => e.from - t.from);
		let n = [];
		if (t.length > 0) {
			let e = [t[0]], r = t[0].to;
			for (let i = 1; i < t.length; i++) {
				let a = t[i];
				a.from < r ? (e.push(a), r = Math.max(r, a.to)) : (n.push(e), e = [a], r = a.to);
			}
			n.push(e);
		}
		for (let t of n) {
			let n = /* @__PURE__ */ new Set();
			t.forEach((e) => n.add(e.trackIndex));
			let i = /* @__PURE__ */ new Map();
			t.forEach((e) => {
				let t = U(e.edgeIndex);
				i.set(e.trackIndex, (i.get(e.trackIndex) ?? 0) + t.delta);
			});
			let a = [...n].filter((e) => (i.get(e) ?? 0) < -1), o = [...n].filter((e) => (i.get(e) ?? 0) > 1), s = [...n].filter((e) => Math.abs(i.get(e) ?? 0) <= 1);
			a.sort((e, t) => (i.get(t) ?? 0) - (i.get(e) ?? 0)), o.sort((e, t) => (i.get(e) ?? 0) - (i.get(t) ?? 0));
			let c = /* @__PURE__ */ r((n, r) => {
				t.filter((e) => e.trackIndex === n).forEach((t) => {
					let n = _.has(t.edgeIndex) ? e.coord : r;
					le.set(`${t.edgeIndex}-${t.segmentIndex}`, n);
				});
			}, "assignCoord"), l = 0;
			for (let t of a) l++, c(t, e.coord - l * Qn);
			if (s.length === 0 && n.size > 0) {
				let e = [...n].sort((e, t) => Math.abs(i.get(e) ?? 0) - Math.abs(i.get(t) ?? 0))[0], t = a.indexOf(e);
				t !== -1 && a.splice(t, 1);
				let r = o.indexOf(e);
				r !== -1 && o.splice(r, 1), s.push(e);
			}
			let u = 0;
			for (let t of s) {
				if (u === 0) c(t, e.coord);
				else {
					let n = u % 2 == 1 ? 1 : -1, r = Math.ceil(u / 2);
					c(t, e.coord + n * r * Qn * .5);
				}
				u++;
			}
			let d = 0;
			for (let t of o) d++, c(t, e.coord + d * Qn);
		}
	}
	for (let [e, t] of a.entries()) {
		let n = g[e] ?? [];
		if (n.length === 0) continue;
		let r = [], { pSrcPort: i, pDstPort: a } = N(e, o.get(t.start), o.get(t.end)), s = n.map((e) => {
			let t = h[e], n = le.get(`${t.edgeIndex}-${t.segmentIndex}`) ?? t.pipe.coord;
			return {
				orient: t.orientation,
				coord: n,
				from: t.from,
				to: t.to
			};
		});
		r.push(i);
		for (let e = 0; e < s.length; e++) {
			let t = s[e], n = r[r.length - 1], i = t.orient === "vertical" ? n.y : n.x, a = t.orient === "vertical" ? n.x : n.y, o = s[e + 1], c = e < s.length - 1;
			if (Math.abs(a - t.coord) > $ && r.push(tr(t, i)), c && o.orient === t.orient) {
				if (Math.abs(t.coord - o.coord) > $) {
					let e = t.orient === "vertical" ? (i + o.from) / 2 : er(t, o);
					r.push(tr(t, e), tr(o, e));
				} else (e === 0 || e === s.length - 2) && r.push(tr(t, er(t, o)));
			} else if (c) r.push(tr(t, o.coord));
			else {
				let e = Math.abs(t.from - i) < Math.abs(t.to - i) ? t.to : t.from;
				r.push(tr(t, e));
			}
		}
		let c = r[r.length - 1];
		(Math.abs(c.x - a.x) > $ || Math.abs(c.y - a.y) > $) && r.push(a);
		let l = [];
		r.length > 0 && l.push(r[0]);
		for (let e = 1; e < r.length; e++) {
			let t = r[e], n = l[l.length - 1];
			(Math.abs(t.x - n.x) > $ || Math.abs(t.y - n.y) > $) && l.push(t);
		}
		t.points = l;
	}
	for (let e of a) {
		let t = e.__originalEdge;
		t && e.points && (t.points = e.points);
	}
	e.edges = (e.edges ?? []).filter((e) => !e.isLayoutOnly);
	let ue = /* @__PURE__ */ r((e, t) => {
		let n = t.x ?? 0, r = t.y ?? 0, i = t.width ?? 0, a = t.height ?? 0;
		if (i <= 0 || a <= 0) return e;
		let o = n - i / 2, s = n + i / 2, c = r - a / 2, l = r + a / 2;
		if (e.x < o || e.x > s || e.y < c || e.y > l) return e;
		let u = e.x - o, d = s - e.x, f = e.y - c, p = l - e.y, m = Math.min(u, d, f, p);
		return m === u ? {
			x: o,
			y: e.y
		} : m === d ? {
			x: s,
			y: e.y
		} : m === f ? {
			x: e.x,
			y: c
		} : {
			x: e.x,
			y: l
		};
	}, "nodeBoundaryClamp");
	for (let t of e.edges) {
		let e = t.points;
		if (!e || e.length < 2) continue;
		let n = t.start, r = t.end, i = n ? o.get(n) : void 0, a = r ? o.get(r) : void 0;
		i && (e[0] = ue(e[0], i)), a && (e[e.length - 1] = ue(e[e.length - 1], a));
	}
	return e;
}
r(nr, "routeEdgesOrthogonal");
function rr(e) {
	return e.direction ?? "TB";
}
r(rr, "getSwimlaneDirection");
function ir(e) {
	let t = A(e), n = e.config.flowchart?.nodeSpacing ?? 40, r = e.config.flowchart?.rankSpacing ?? 100, i = e.config.swimlane?.ignoreCrossLaneEdges ?? !0, a = e.config.swimlane?.optimizeRanksByCrossings ?? !0, o = e.config.swimlane?.automaticLaneOrdering ?? !1, s = rr(e), { ordered: c, coordinates: l } = Kn(t, {
		nodeGap: n,
		layerGap: r,
		ignoreCrossLaneEdges: i,
		optimizeRanksByCrossings: a,
		automaticLaneOrdering: o,
		direction: s
	});
	j(t, c, l, {
		nodeGap: n,
		layerGap: r
	});
	for (let t of e.edges ?? []) delete t.points;
	nr(e, s);
	for (let t of e.edges ?? []) (!t.curve || t.curve === "basis") && (t.curve = "rounded");
	return It(e, s), Ft(e), s;
}
r(ir, "runSwimlaneLayoutCore");
function ar(e) {
	k(e);
	let t = te(e);
	e.nodes = t.nodes, e.edges = t.edges;
}
r(ar, "prepareSwimlaneLayout");
var or = e({
	prepareLayout: ar,
	runLayoutCore: ir,
	afterPaint: C
});
//#endregion
export { or as render };

//# sourceMappingURL=swimlanes-42K2YHIH-BxH86fKc-sygVt9_h.js.map