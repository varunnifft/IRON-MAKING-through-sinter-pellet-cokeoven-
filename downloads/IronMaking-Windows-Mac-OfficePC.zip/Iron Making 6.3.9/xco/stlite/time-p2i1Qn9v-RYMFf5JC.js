import { _ as e, a as t, c as n, g as r, h as i, i as a, m as o } from "./string-BvOnLx8K-BsWpS-s0.js";
import { t as s } from "./init-5BClRdiB-LyILMlTE.js";
import { c, o as l, p as u, t as d } from "./linear-CJvvCWKw-rrRTERsA.js";
//#region ../react/build/time-p2i1Qn9v.js
function f(e, t) {
	let n;
	if (t === void 0) for (let t of e) t != null && (n < t || n === void 0 && t >= t) && (n = t);
	else {
		let r = -1;
		for (let i of e) (i = t(i, ++r, e)) != null && (n < i || n === void 0 && i >= i) && (n = i);
	}
	return n;
}
function ee(e, t) {
	let n;
	if (t === void 0) for (let t of e) t != null && (n > t || n === void 0 && t >= t) && (n = t);
	else {
		let r = -1;
		for (let i of e) (i = t(i, ++r, e)) != null && (n > i || n === void 0 && i >= i) && (n = i);
	}
	return n;
}
var p = /* @__PURE__ */ new Date(), m = /* @__PURE__ */ new Date();
function h(e, t, n, r) {
	function i(t) {
		return e(t = arguments.length === 0 ? /* @__PURE__ */ new Date() : /* @__PURE__ */ new Date(+t)), t;
	}
	return i.floor = (t) => (e(t = /* @__PURE__ */ new Date(+t)), t), i.ceil = (n) => (e(n = /* @__PURE__ */ new Date(n - 1)), t(n, 1), e(n), n), i.round = (e) => {
		let t = i(e), n = i.ceil(e);
		return e - t < n - e ? t : n;
	}, i.offset = (e, n) => (t(e = /* @__PURE__ */ new Date(+e), n == null ? 1 : Math.floor(n)), e), i.range = (n, r, a) => {
		let o = [];
		if (n = i.ceil(n), a = a == null ? 1 : Math.floor(a), !(n < r) || !(a > 0)) return o;
		let s;
		do
			o.push(s = /* @__PURE__ */ new Date(+n)), t(n, a), e(n);
		while (s < n && n < r);
		return o;
	}, i.filter = (n) => h((t) => {
		if (t >= t) for (; e(t), !n(t);) t.setTime(t - 1);
	}, (e, r) => {
		if (e >= e) {
			if (r < 0) for (; ++r <= 0;) for (; t(e, -1), !n(e););
			else for (; --r >= 0;) for (; t(e, 1), !n(e););
		}
	}), n && (i.count = (t, r) => (p.setTime(+t), m.setTime(+r), e(p), e(m), Math.floor(n(p, m))), i.every = (e) => (e = Math.floor(e), !isFinite(e) || !(e > 0) ? null : e > 1 ? i.filter(r ? (t) => r(t) % e === 0 : (t) => i.count(0, t) % e === 0) : i)), i;
}
var g = h(() => {}, (e, t) => {
	e.setTime(+e + t);
}, (e, t) => t - e);
g.every = (e) => (e = Math.floor(e), !isFinite(e) || !(e > 0) ? null : e > 1 ? h((t) => {
	t.setTime(Math.floor(t / e) * e);
}, (t, n) => {
	t.setTime(+t + n * e);
}, (t, n) => (n - t) / e) : g), g.range;
var _ = 1e3, v = _ * 60, y = v * 60, b = y * 24, x = b * 7, S = b * 30, C = b * 365, w = h((e) => {
	e.setTime(e - e.getMilliseconds());
}, (e, t) => {
	e.setTime(+e + t * _);
}, (e, t) => (t - e) / _, (e) => e.getUTCSeconds());
w.range;
var T = h((e) => {
	e.setTime(e - e.getMilliseconds() - e.getSeconds() * _);
}, (e, t) => {
	e.setTime(+e + t * v);
}, (e, t) => (t - e) / v, (e) => e.getMinutes());
T.range;
var E = h((e) => {
	e.setUTCSeconds(0, 0);
}, (e, t) => {
	e.setTime(+e + t * v);
}, (e, t) => (t - e) / v, (e) => e.getUTCMinutes());
E.range;
var D = h((e) => {
	e.setTime(e - e.getMilliseconds() - e.getSeconds() * _ - e.getMinutes() * v);
}, (e, t) => {
	e.setTime(+e + t * y);
}, (e, t) => (t - e) / y, (e) => e.getHours());
D.range;
var O = h((e) => {
	e.setUTCMinutes(0, 0, 0);
}, (e, t) => {
	e.setTime(+e + t * y);
}, (e, t) => (t - e) / y, (e) => e.getUTCHours());
O.range;
var k = h((e) => e.setHours(0, 0, 0, 0), (e, t) => e.setDate(e.getDate() + t), (e, t) => (t - e - (t.getTimezoneOffset() - e.getTimezoneOffset()) * v) / b, (e) => e.getDate() - 1);
k.range;
var A = h((e) => {
	e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
	e.setUTCDate(e.getUTCDate() + t);
}, (e, t) => (t - e) / b, (e) => e.getUTCDate() - 1);
A.range;
var te = h((e) => {
	e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
	e.setUTCDate(e.getUTCDate() + t);
}, (e, t) => (t - e) / b, (e) => Math.floor(e / b));
te.range;
function j(e) {
	return h((t) => {
		t.setDate(t.getDate() - (t.getDay() + 7 - e) % 7), t.setHours(0, 0, 0, 0);
	}, (e, t) => {
		e.setDate(e.getDate() + t * 7);
	}, (e, t) => (t - e - (t.getTimezoneOffset() - e.getTimezoneOffset()) * v) / x);
}
var M = j(0), N = j(1), ne = j(2), re = j(3), P = j(4), ie = j(5), ae = j(6);
M.range, N.range, ne.range, re.range, P.range, ie.range, ae.range;
function F(e) {
	return h((t) => {
		t.setUTCDate(t.getUTCDate() - (t.getUTCDay() + 7 - e) % 7), t.setUTCHours(0, 0, 0, 0);
	}, (e, t) => {
		e.setUTCDate(e.getUTCDate() + t * 7);
	}, (e, t) => (t - e) / x);
}
var I = F(0), L = F(1), oe = F(2), se = F(3), R = F(4), ce = F(5), le = F(6);
I.range, L.range, oe.range, se.range, R.range, ce.range, le.range;
var z = h((e) => {
	e.setDate(1), e.setHours(0, 0, 0, 0);
}, (e, t) => {
	e.setMonth(e.getMonth() + t);
}, (e, t) => t.getMonth() - e.getMonth() + (t.getFullYear() - e.getFullYear()) * 12, (e) => e.getMonth());
z.range;
var ue = h((e) => {
	e.setUTCDate(1), e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
	e.setUTCMonth(e.getUTCMonth() + t);
}, (e, t) => t.getUTCMonth() - e.getUTCMonth() + (t.getUTCFullYear() - e.getUTCFullYear()) * 12, (e) => e.getUTCMonth());
ue.range;
var B = h((e) => {
	e.setMonth(0, 1), e.setHours(0, 0, 0, 0);
}, (e, t) => {
	e.setFullYear(e.getFullYear() + t);
}, (e, t) => t.getFullYear() - e.getFullYear(), (e) => e.getFullYear());
B.every = (e) => !isFinite(e = Math.floor(e)) || !(e > 0) ? null : h((t) => {
	t.setFullYear(Math.floor(t.getFullYear() / e) * e), t.setMonth(0, 1), t.setHours(0, 0, 0, 0);
}, (t, n) => {
	t.setFullYear(t.getFullYear() + n * e);
}), B.range;
var V = h((e) => {
	e.setUTCMonth(0, 1), e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
	e.setUTCFullYear(e.getUTCFullYear() + t);
}, (e, t) => t.getUTCFullYear() - e.getUTCFullYear(), (e) => e.getUTCFullYear());
V.every = (e) => !isFinite(e = Math.floor(e)) || !(e > 0) ? null : h((t) => {
	t.setUTCFullYear(Math.floor(t.getUTCFullYear() / e) * e), t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0);
}, (t, n) => {
	t.setUTCFullYear(t.getUTCFullYear() + n * e);
}), V.range;
function de(e, t, n, r, i, a) {
	let o = [
		[
			w,
			1,
			_
		],
		[
			w,
			5,
			5 * _
		],
		[
			w,
			15,
			15 * _
		],
		[
			w,
			30,
			30 * _
		],
		[
			a,
			1,
			v
		],
		[
			a,
			5,
			5 * v
		],
		[
			a,
			15,
			15 * v
		],
		[
			a,
			30,
			30 * v
		],
		[
			i,
			1,
			y
		],
		[
			i,
			3,
			3 * y
		],
		[
			i,
			6,
			6 * y
		],
		[
			i,
			12,
			12 * y
		],
		[
			r,
			1,
			b
		],
		[
			r,
			2,
			2 * b
		],
		[
			n,
			1,
			x
		],
		[
			t,
			1,
			S
		],
		[
			t,
			3,
			3 * S
		],
		[
			e,
			1,
			C
		]
	];
	function s(e, t, n) {
		let r = t < e;
		r && ([e, t] = [t, e]);
		let i = n && typeof n.range == "function" ? n : c(e, t, n), a = i ? i.range(e, +t + 1) : [];
		return r ? a.reverse() : a;
	}
	function c(t, n, r) {
		let i = Math.abs(n - t) / r, a = u(([, , e]) => e).right(o, i);
		if (a === o.length) return e.every(d(t / C, n / C, r));
		if (a === 0) return g.every(Math.max(d(t, n, r), 1));
		let [s, c] = o[i / o[a - 1][2] < o[a][2] / i ? a - 1 : a];
		return s.every(c);
	}
	return [s, c];
}
var [fe, pe] = de(V, ue, I, te, O, E), [me, he] = de(B, z, M, k, D, T);
function ge(e) {
	if (0 <= e.y && e.y < 100) {
		var t = new Date(-1, e.m, e.d, e.H, e.M, e.S, e.L);
		return t.setFullYear(e.y), t;
	}
	return new Date(e.y, e.m, e.d, e.H, e.M, e.S, e.L);
}
function _e(e) {
	if (0 <= e.y && e.y < 100) {
		var t = new Date(Date.UTC(-1, e.m, e.d, e.H, e.M, e.S, e.L));
		return t.setUTCFullYear(e.y), t;
	}
	return new Date(Date.UTC(e.y, e.m, e.d, e.H, e.M, e.S, e.L));
}
function H(e, t, n) {
	return {
		y: e,
		m: t,
		d: n,
		H: 0,
		M: 0,
		S: 0,
		L: 0
	};
}
function ve(e) {
	var t = e.dateTime, n = e.date, r = e.time, i = e.periods, a = e.days, o = e.shortDays, s = e.months, c = e.shortMonths, l = G(i), u = K(i), d = G(a), f = K(a), ee = G(o), p = K(o), m = G(s), h = K(s), g = G(c), _ = K(c), v = {
		a: ne,
		A: re,
		b: P,
		B: ie,
		c: null,
		d: Ue,
		e: Ue,
		f: Je,
		g: at,
		G: st,
		H: We,
		I: Ge,
		j: Ke,
		L: qe,
		m: Ye,
		M: Xe,
		p: ae,
		q: F,
		Q: At,
		s: jt,
		S: Ze,
		u: Qe,
		U: $e,
		V: tt,
		w: nt,
		W: rt,
		x: null,
		X: null,
		y: it,
		Y: ot,
		Z: ct,
		"%": kt
	}, y = {
		a: I,
		A: oe,
		b: se,
		B: R,
		c: null,
		d: lt,
		e: lt,
		f: mt,
		g: Tt,
		G: Dt,
		H: ut,
		I: dt,
		j: ft,
		L: pt,
		m: ht,
		M: gt,
		p: ce,
		q: le,
		Q: At,
		s: jt,
		S: _t,
		u: vt,
		U: yt,
		V: xt,
		w: St,
		W: Ct,
		x: null,
		X: null,
		y: wt,
		Y: Et,
		Z: Ot,
		"%": kt
	}, b = {
		a: T,
		A: E,
		b: D,
		B: O,
		c: te,
		d: Ne,
		e: Ne,
		f: ze,
		g: ke,
		G: Oe,
		H: Fe,
		I: Fe,
		j: Pe,
		L: Re,
		m: Me,
		M: Ie,
		p: w,
		q: je,
		Q: Ve,
		s: He,
		S: Le,
		u: we,
		U: Te,
		V: Ee,
		w: Ce,
		W: De,
		x: j,
		X: M,
		y: ke,
		Y: Oe,
		Z: Ae,
		"%": Be
	};
	v.x = x(n, v), v.X = x(r, v), v.c = x(t, v), y.x = x(n, y), y.X = x(r, y), y.c = x(t, y);
	function x(e, t) {
		return function(n) {
			var r = [], i = -1, a = 0, o = e.length, s, c, l;
			for (n instanceof Date || (n = /* @__PURE__ */ new Date(+n)); ++i < o;) e.charCodeAt(i) === 37 && (r.push(e.slice(a, i)), (c = ye[s = e.charAt(++i)]) == null ? c = s === "e" ? " " : "0" : s = e.charAt(++i), (l = t[s]) && (s = l(n, c)), r.push(s), a = i + 1);
			return r.push(e.slice(a, i)), r.join("");
		};
	}
	function S(e, t) {
		return function(n) {
			var r = H(1900, void 0, 1), i = C(r, e, n += "", 0), a, o;
			if (i != n.length) return null;
			if ("Q" in r) return new Date(r.Q);
			if ("s" in r) return new Date(r.s * 1e3 + ("L" in r ? r.L : 0));
			if (t && !("Z" in r) && (r.Z = 0), "p" in r && (r.H = r.H % 12 + r.p * 12), r.m === void 0 && (r.m = "q" in r ? r.q : 0), "V" in r) {
				if (r.V < 1 || r.V > 53) return null;
				"w" in r || (r.w = 1), "Z" in r ? (a = _e(H(r.y, 0, 1)), o = a.getUTCDay(), a = o > 4 || o === 0 ? L.ceil(a) : L(a), a = A.offset(a, (r.V - 1) * 7), r.y = a.getUTCFullYear(), r.m = a.getUTCMonth(), r.d = a.getUTCDate() + (r.w + 6) % 7) : (a = ge(H(r.y, 0, 1)), o = a.getDay(), a = o > 4 || o === 0 ? N.ceil(a) : N(a), a = k.offset(a, (r.V - 1) * 7), r.y = a.getFullYear(), r.m = a.getMonth(), r.d = a.getDate() + (r.w + 6) % 7);
			} else ("W" in r || "U" in r) && ("w" in r || (r.w = "u" in r ? r.u % 7 : +("W" in r)), o = "Z" in r ? _e(H(r.y, 0, 1)).getUTCDay() : ge(H(r.y, 0, 1)).getDay(), r.m = 0, r.d = "W" in r ? (r.w + 6) % 7 + r.W * 7 - (o + 5) % 7 : r.w + r.U * 7 - (o + 6) % 7);
			return "Z" in r ? (r.H += r.Z / 100 | 0, r.M += r.Z % 100, _e(r)) : ge(r);
		};
	}
	function C(e, t, n, r) {
		for (var i = 0, a = t.length, o = n.length, s, c; i < a;) {
			if (r >= o) return -1;
			if (s = t.charCodeAt(i++), s === 37) {
				if (s = t.charAt(i++), c = b[s in ye ? t.charAt(i++) : s], !c || (r = c(e, n, r)) < 0) return -1;
			} else if (s != n.charCodeAt(r++)) return -1;
		}
		return r;
	}
	function w(e, t, n) {
		var r = l.exec(t.slice(n));
		return r ? (e.p = u.get(r[0].toLowerCase()), n + r[0].length) : -1;
	}
	function T(e, t, n) {
		var r = ee.exec(t.slice(n));
		return r ? (e.w = p.get(r[0].toLowerCase()), n + r[0].length) : -1;
	}
	function E(e, t, n) {
		var r = d.exec(t.slice(n));
		return r ? (e.w = f.get(r[0].toLowerCase()), n + r[0].length) : -1;
	}
	function D(e, t, n) {
		var r = g.exec(t.slice(n));
		return r ? (e.m = _.get(r[0].toLowerCase()), n + r[0].length) : -1;
	}
	function O(e, t, n) {
		var r = m.exec(t.slice(n));
		return r ? (e.m = h.get(r[0].toLowerCase()), n + r[0].length) : -1;
	}
	function te(e, n, r) {
		return C(e, t, n, r);
	}
	function j(e, t, r) {
		return C(e, n, t, r);
	}
	function M(e, t, n) {
		return C(e, r, t, n);
	}
	function ne(e) {
		return o[e.getDay()];
	}
	function re(e) {
		return a[e.getDay()];
	}
	function P(e) {
		return c[e.getMonth()];
	}
	function ie(e) {
		return s[e.getMonth()];
	}
	function ae(e) {
		return i[+(e.getHours() >= 12)];
	}
	function F(e) {
		return 1 + ~~(e.getMonth() / 3);
	}
	function I(e) {
		return o[e.getUTCDay()];
	}
	function oe(e) {
		return a[e.getUTCDay()];
	}
	function se(e) {
		return c[e.getUTCMonth()];
	}
	function R(e) {
		return s[e.getUTCMonth()];
	}
	function ce(e) {
		return i[+(e.getUTCHours() >= 12)];
	}
	function le(e) {
		return 1 + ~~(e.getUTCMonth() / 3);
	}
	return {
		format: function(e) {
			var t = x(e += "", v);
			return t.toString = function() {
				return e;
			}, t;
		},
		parse: function(e) {
			var t = S(e += "", !1);
			return t.toString = function() {
				return e;
			}, t;
		},
		utcFormat: function(e) {
			var t = x(e += "", y);
			return t.toString = function() {
				return e;
			}, t;
		},
		utcParse: function(e) {
			var t = S(e += "", !0);
			return t.toString = function() {
				return e;
			}, t;
		}
	};
}
var ye = {
	"-": "",
	_: " ",
	0: "0"
}, U = /^\s*\d+/, be = /^%/, xe = /[\\^$*+?|[\]().{}]/g;
function W(e, t, n) {
	var r = e < 0 ? "-" : "", i = (r ? -e : e) + "", a = i.length;
	return r + (a < n ? Array(n - a + 1).join(t) + i : i);
}
function Se(e) {
	return e.replace(xe, "\\$&");
}
function G(e) {
	return RegExp("^(?:" + e.map(Se).join("|") + ")", "i");
}
function K(e) {
	return new Map(e.map((e, t) => [e.toLowerCase(), t]));
}
function Ce(e, t, n) {
	var r = U.exec(t.slice(n, n + 1));
	return r ? (e.w = +r[0], n + r[0].length) : -1;
}
function we(e, t, n) {
	var r = U.exec(t.slice(n, n + 1));
	return r ? (e.u = +r[0], n + r[0].length) : -1;
}
function Te(e, t, n) {
	var r = U.exec(t.slice(n, n + 2));
	return r ? (e.U = +r[0], n + r[0].length) : -1;
}
function Ee(e, t, n) {
	var r = U.exec(t.slice(n, n + 2));
	return r ? (e.V = +r[0], n + r[0].length) : -1;
}
function De(e, t, n) {
	var r = U.exec(t.slice(n, n + 2));
	return r ? (e.W = +r[0], n + r[0].length) : -1;
}
function Oe(e, t, n) {
	var r = U.exec(t.slice(n, n + 4));
	return r ? (e.y = +r[0], n + r[0].length) : -1;
}
function ke(e, t, n) {
	var r = U.exec(t.slice(n, n + 2));
	return r ? (e.y = +r[0] + (+r[0] > 68 ? 1900 : 2e3), n + r[0].length) : -1;
}
function Ae(e, t, n) {
	var r = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(t.slice(n, n + 6));
	return r ? (e.Z = r[1] ? 0 : -(r[2] + (r[3] || "00")), n + r[0].length) : -1;
}
function je(e, t, n) {
	var r = U.exec(t.slice(n, n + 1));
	return r ? (e.q = r[0] * 3 - 3, n + r[0].length) : -1;
}
function Me(e, t, n) {
	var r = U.exec(t.slice(n, n + 2));
	return r ? (e.m = r[0] - 1, n + r[0].length) : -1;
}
function Ne(e, t, n) {
	var r = U.exec(t.slice(n, n + 2));
	return r ? (e.d = +r[0], n + r[0].length) : -1;
}
function Pe(e, t, n) {
	var r = U.exec(t.slice(n, n + 3));
	return r ? (e.m = 0, e.d = +r[0], n + r[0].length) : -1;
}
function Fe(e, t, n) {
	var r = U.exec(t.slice(n, n + 2));
	return r ? (e.H = +r[0], n + r[0].length) : -1;
}
function Ie(e, t, n) {
	var r = U.exec(t.slice(n, n + 2));
	return r ? (e.M = +r[0], n + r[0].length) : -1;
}
function Le(e, t, n) {
	var r = U.exec(t.slice(n, n + 2));
	return r ? (e.S = +r[0], n + r[0].length) : -1;
}
function Re(e, t, n) {
	var r = U.exec(t.slice(n, n + 3));
	return r ? (e.L = +r[0], n + r[0].length) : -1;
}
function ze(e, t, n) {
	var r = U.exec(t.slice(n, n + 6));
	return r ? (e.L = Math.floor(r[0] / 1e3), n + r[0].length) : -1;
}
function Be(e, t, n) {
	var r = be.exec(t.slice(n, n + 1));
	return r ? n + r[0].length : -1;
}
function Ve(e, t, n) {
	var r = U.exec(t.slice(n));
	return r ? (e.Q = +r[0], n + r[0].length) : -1;
}
function He(e, t, n) {
	var r = U.exec(t.slice(n));
	return r ? (e.s = +r[0], n + r[0].length) : -1;
}
function Ue(e, t) {
	return W(e.getDate(), t, 2);
}
function We(e, t) {
	return W(e.getHours(), t, 2);
}
function Ge(e, t) {
	return W(e.getHours() % 12 || 12, t, 2);
}
function Ke(e, t) {
	return W(1 + k.count(B(e), e), t, 3);
}
function qe(e, t) {
	return W(e.getMilliseconds(), t, 3);
}
function Je(e, t) {
	return qe(e, t) + "000";
}
function Ye(e, t) {
	return W(e.getMonth() + 1, t, 2);
}
function Xe(e, t) {
	return W(e.getMinutes(), t, 2);
}
function Ze(e, t) {
	return W(e.getSeconds(), t, 2);
}
function Qe(e) {
	var t = e.getDay();
	return t === 0 ? 7 : t;
}
function $e(e, t) {
	return W(M.count(B(e) - 1, e), t, 2);
}
function et(e) {
	var t = e.getDay();
	return t >= 4 || t === 0 ? P(e) : P.ceil(e);
}
function tt(e, t) {
	return e = et(e), W(P.count(B(e), e) + (B(e).getDay() === 4), t, 2);
}
function nt(e) {
	return e.getDay();
}
function rt(e, t) {
	return W(N.count(B(e) - 1, e), t, 2);
}
function it(e, t) {
	return W(e.getFullYear() % 100, t, 2);
}
function at(e, t) {
	return e = et(e), W(e.getFullYear() % 100, t, 2);
}
function ot(e, t) {
	return W(e.getFullYear() % 1e4, t, 4);
}
function st(e, t) {
	var n = e.getDay();
	return e = n >= 4 || n === 0 ? P(e) : P.ceil(e), W(e.getFullYear() % 1e4, t, 4);
}
function ct(e) {
	var t = e.getTimezoneOffset();
	return (t > 0 ? "-" : (t *= -1, "+")) + W(t / 60 | 0, "0", 2) + W(t % 60, "0", 2);
}
function lt(e, t) {
	return W(e.getUTCDate(), t, 2);
}
function ut(e, t) {
	return W(e.getUTCHours(), t, 2);
}
function dt(e, t) {
	return W(e.getUTCHours() % 12 || 12, t, 2);
}
function ft(e, t) {
	return W(1 + A.count(V(e), e), t, 3);
}
function pt(e, t) {
	return W(e.getUTCMilliseconds(), t, 3);
}
function mt(e, t) {
	return pt(e, t) + "000";
}
function ht(e, t) {
	return W(e.getUTCMonth() + 1, t, 2);
}
function gt(e, t) {
	return W(e.getUTCMinutes(), t, 2);
}
function _t(e, t) {
	return W(e.getUTCSeconds(), t, 2);
}
function vt(e) {
	var t = e.getUTCDay();
	return t === 0 ? 7 : t;
}
function yt(e, t) {
	return W(I.count(V(e) - 1, e), t, 2);
}
function bt(e) {
	var t = e.getUTCDay();
	return t >= 4 || t === 0 ? R(e) : R.ceil(e);
}
function xt(e, t) {
	return e = bt(e), W(R.count(V(e), e) + (V(e).getUTCDay() === 4), t, 2);
}
function St(e) {
	return e.getUTCDay();
}
function Ct(e, t) {
	return W(L.count(V(e) - 1, e), t, 2);
}
function wt(e, t) {
	return W(e.getUTCFullYear() % 100, t, 2);
}
function Tt(e, t) {
	return e = bt(e), W(e.getUTCFullYear() % 100, t, 2);
}
function Et(e, t) {
	return W(e.getUTCFullYear() % 1e4, t, 4);
}
function Dt(e, t) {
	var n = e.getUTCDay();
	return e = n >= 4 || n === 0 ? R(e) : R.ceil(e), W(e.getUTCFullYear() % 1e4, t, 4);
}
function Ot() {
	return "+0000";
}
function kt() {
	return "%";
}
function At(e) {
	return +e;
}
function jt(e) {
	return Math.floor(e / 1e3);
}
var q, Mt, Nt, Pt, Ft;
It({
	dateTime: "%x, %X",
	date: "%-m/%-d/%Y",
	time: "%-I:%M:%S %p",
	periods: ["AM", "PM"],
	days: [
		"Sunday",
		"Monday",
		"Tuesday",
		"Wednesday",
		"Thursday",
		"Friday",
		"Saturday"
	],
	shortDays: [
		"Sun",
		"Mon",
		"Tue",
		"Wed",
		"Thu",
		"Fri",
		"Sat"
	],
	months: [
		"January",
		"February",
		"March",
		"April",
		"May",
		"June",
		"July",
		"August",
		"September",
		"October",
		"November",
		"December"
	],
	shortMonths: [
		"Jan",
		"Feb",
		"Mar",
		"Apr",
		"May",
		"Jun",
		"Jul",
		"Aug",
		"Sep",
		"Oct",
		"Nov",
		"Dec"
	]
});
function It(e) {
	return q = ve(e), Mt = q.format, Nt = q.parse, Pt = q.utcFormat, Ft = q.utcParse, q;
}
var Lt = Math.PI / 180, Rt = 180 / Math.PI, J = 18, zt = .96422, Bt = 1, Vt = .82521, Ht = 4 / 29, Y = 6 / 29, Ut = 3 * Y * Y, Wt = Y * Y * Y;
function Gt(t) {
	if (t instanceof X) return new X(t.l, t.a, t.b, t.opacity);
	if (t instanceof $) return Zt(t);
	t instanceof i || (t = e(t));
	var n = Yt(t.r), r = Yt(t.g), a = Yt(t.b), o = qt((.2225045 * n + .7168786 * r + .0606169 * a) / Bt), s, c;
	return n === r && r === a ? s = c = o : (s = qt((.4360747 * n + .3850649 * r + .1430804 * a) / zt), c = qt((.0139322 * n + .0971045 * r + .7141733 * a) / Vt)), new X(116 * o - 16, 500 * (s - o), 200 * (o - c), t.opacity);
}
function Kt(e, t, n, r) {
	return arguments.length === 1 ? Gt(e) : new X(e, t, n, r ?? 1);
}
function X(e, t, n, r) {
	this.l = +e, this.a = +t, this.b = +n, this.opacity = +r;
}
r(X, Kt, a(o, {
	brighter(e) {
		return new X(this.l + J * (e ?? 1), this.a, this.b, this.opacity);
	},
	darker(e) {
		return new X(this.l - J * (e ?? 1), this.a, this.b, this.opacity);
	},
	rgb() {
		var e = (this.l + 16) / 116, t = isNaN(this.a) ? e : e + this.a / 500, n = isNaN(this.b) ? e : e - this.b / 200;
		return t = zt * Jt(t), e = Bt * Jt(e), n = Vt * Jt(n), new i(Z(3.1338561 * t - 1.6168667 * e - .4906146 * n), Z(-.9787684 * t + 1.9161415 * e + .033454 * n), Z(.0719453 * t - .2289914 * e + 1.4052427 * n), this.opacity);
	}
}));
function qt(e) {
	return e > Wt ? e ** (1 / 3) : e / Ut + Ht;
}
function Jt(e) {
	return e > Y ? e * e * e : Ut * (e - Ht);
}
function Z(e) {
	return 255 * (e <= .0031308 ? 12.92 * e : 1.055 * e ** (1 / 2.4) - .055);
}
function Yt(e) {
	return (e /= 255) <= .04045 ? e / 12.92 : ((e + .055) / 1.055) ** 2.4;
}
function Xt(e) {
	if (e instanceof $) return new $(e.h, e.c, e.l, e.opacity);
	if (e instanceof X || (e = Gt(e)), e.a === 0 && e.b === 0) return new $(NaN, 0 < e.l && e.l < 100 ? 0 : NaN, e.l, e.opacity);
	var t = Math.atan2(e.b, e.a) * Rt;
	return new $(t < 0 ? t + 360 : t, Math.sqrt(e.a * e.a + e.b * e.b), e.l, e.opacity);
}
function Q(e, t, n, r) {
	return arguments.length === 1 ? Xt(e) : new $(e, t, n, r ?? 1);
}
function $(e, t, n, r) {
	this.h = +e, this.c = +t, this.l = +n, this.opacity = +r;
}
function Zt(e) {
	if (isNaN(e.h)) return new X(e.l, 0, 0, e.opacity);
	var t = e.h * Lt;
	return new X(e.l, Math.cos(t) * e.c, Math.sin(t) * e.c, e.opacity);
}
r($, Q, a(o, {
	brighter(e) {
		return new $(this.h, this.c, this.l + J * (e ?? 1), this.opacity);
	},
	darker(e) {
		return new $(this.h, this.c, this.l - J * (e ?? 1), this.opacity);
	},
	rgb() {
		return Zt(this).rgb();
	}
}));
function Qt(e) {
	return function(n, r) {
		var i = e((n = Q(n)).h, (r = Q(r)).h), a = t(n.c, r.c), o = t(n.l, r.l), s = t(n.opacity, r.opacity);
		return function(e) {
			return n.h = i(e), n.c = a(e), n.l = o(e), n.opacity = s(e), n + "";
		};
	};
}
var $t = Qt(n), en = Qt(t);
function tn(e, t) {
	e = e.slice();
	var n = 0, r = e.length - 1, i = e[n], a = e[r], o;
	return a < i && (o = n, n = r, r = o, o = i, i = a, a = o), e[n] = t.floor(i), e[r] = t.ceil(a), e;
}
function nn(e) {
	return new Date(e);
}
function rn(e) {
	return e instanceof Date ? +e : +/* @__PURE__ */ new Date(+e);
}
function an(e, t, n, r, i, a, o, s, u, d) {
	var f = c(), ee = f.invert, p = f.domain, m = d(".%L"), h = d(":%S"), g = d("%I:%M"), _ = d("%I %p"), v = d("%a %d"), y = d("%b %d"), b = d("%B"), x = d("%Y");
	function S(e) {
		return (u(e) < e ? m : s(e) < e ? h : o(e) < e ? g : a(e) < e ? _ : r(e) < e ? i(e) < e ? v : y : n(e) < e ? b : x)(e);
	}
	return f.invert = function(e) {
		return new Date(ee(e));
	}, f.domain = function(e) {
		return arguments.length ? p(Array.from(e, rn)) : p().map(nn);
	}, f.ticks = function(t) {
		var n = p();
		return e(n[0], n[n.length - 1], t ?? 10);
	}, f.tickFormat = function(e, t) {
		return t == null ? S : d(t);
	}, f.nice = function(e) {
		var n = p();
		return (!e || typeof e.range != "function") && (e = t(n[0], n[n.length - 1], e ?? 10)), e ? p(tn(n, e)) : f;
	}, f.copy = function() {
		return l(f, an(e, t, n, r, i, a, o, s, u, d));
	}, f;
}
function on() {
	return s.apply(an(me, he, B, z, M, k, D, T, w, Mt).domain([new Date(2e3, 0, 1), new Date(2e3, 0, 2)]), arguments);
}
//#endregion
export { A, g as C, on as D, ne as E, f as F, I, z as L, en as M, L as N, N as O, M as P, w as R, V as S, Rt as T, Lt as _, tn as a, ee as b, Q as c, ve as d, Nt as f, Pt as g, ue as h, D as i, E as j, fe as k, B as l, P as m, Kt as n, k as o, T as p, ae as r, re as s, Mt as t, ie as u, Ft as v, pe as w, $t as x, an as y, O as z };

//# sourceMappingURL=time-p2i1Qn9v-RYMFf5JC.js.map