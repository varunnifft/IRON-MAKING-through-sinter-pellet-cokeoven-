import { Ft as e, _t as t, ds as n, g as r, hn as i, ms as a } from "./index-B1FrxEMd-BsPMjC5n.js";
//#region ../react/build/useFormValidation-Cnit8K9v.js
var o = /* @__PURE__ */ a(n(), 1), s = /* @__PURE__ */ (0, o.createContext)(null), c = {
	badInput: !1,
	customError: !1,
	patternMismatch: !1,
	rangeOverflow: !1,
	rangeUnderflow: !1,
	stepMismatch: !1,
	tooLong: !1,
	tooShort: !1,
	typeMismatch: !1,
	valueMissing: !1,
	valid: !0
}, l = {
	...c,
	customError: !0,
	valid: !1
}, u = {
	isInvalid: !1,
	validationDetails: c,
	validationErrors: []
}, d = (0, o.createContext)({}), f = "__reactAriaFormValidationState";
function p(e) {
	if (e.__reactAriaFormValidationState) {
		let { realtimeValidation: t, displayValidation: n, updateValidation: r, resetValidation: i, commitValidation: a } = e[f];
		return {
			realtimeValidation: t,
			displayValidation: n,
			updateValidation: r,
			resetValidation: i,
			commitValidation: a
		};
	}
	return m(e);
}
function m(e) {
	let { isInvalid: t, validationState: n, name: r, value: i, builtinValidation: a, validate: s, validationBehavior: c = "aria" } = e;
	n && (t ||= n === "invalid");
	let f = t === void 0 ? null : {
		isInvalid: t,
		validationErrors: [],
		validationDetails: l
	}, p = (0, o.useMemo)(() => !s || i == null ? null : _(g(s, i)), [s, i]);
	a?.validationDetails.valid && (a = void 0);
	let m = (0, o.useContext)(d), y = (0, o.useMemo)(() => r ? Array.isArray(r) ? r.flatMap((e) => h(m[e])) : h(m[r]) : [], [m, r]), [b, x] = (0, o.useState)(m), [S, C] = (0, o.useState)(!1);
	m !== b && (x(m), C(!1));
	let w = (0, o.useMemo)(() => _(S ? [] : y), [S, y]), T = (0, o.useRef)(u), [E, D] = (0, o.useState)(u), O = (0, o.useRef)(u), k = () => {
		if (!A) return;
		j(!1);
		let e = p || a || T.current;
		v(e, O.current) || (O.current = e, D(e));
	}, [A, j] = (0, o.useState)(!1);
	return (0, o.useEffect)(k), {
		realtimeValidation: f || w || p || a || u,
		displayValidation: c === "native" ? f || w || E : f || w || p || a || E,
		updateValidation(e) {
			c === "aria" && !v(E, e) ? D(e) : T.current = e;
		},
		resetValidation() {
			let e = u;
			v(e, O.current) || (O.current = e, D(e)), c === "native" && j(!1), C(!0);
		},
		commitValidation() {
			c === "native" && j(!0), C(!0);
		}
	};
}
function h(e) {
	return e ? Array.isArray(e) ? e : [e] : [];
}
function g(e, t) {
	if (typeof e == "function") {
		let n = e(t);
		if (n && typeof n != "boolean") return h(n);
	}
	return [];
}
function _(e) {
	return e.length ? {
		isInvalid: !0,
		validationErrors: e,
		validationDetails: l
	} : null;
}
function v(e, t) {
	return e === t || !!e && !!t && e.isInvalid === t.isInvalid && e.validationErrors.length === t.validationErrors.length && e.validationErrors.every((e, n) => e === t.validationErrors[n]) && Object.entries(e.validationDetails).every(([e, n]) => t.validationDetails[e] === n);
}
var y = /* @__PURE__ */ (0, o.createContext)(null);
function b(n, a, s) {
	let { validationBehavior: c, focus: l } = n;
	e(() => {
		if (c === "native" && s?.current && "setCustomValidity" in s.current && !s.current.disabled) {
			let e = a.realtimeValidation.isInvalid ? a.realtimeValidation.validationErrors.join(" ") || "Invalid value." : "";
			s.current.setCustomValidity(e), s.current.hasAttribute("title") || (s.current.title = ""), a.realtimeValidation.isInvalid || a.updateValidation(S(s.current));
		}
	});
	let u = (0, o.useRef)(!1), d = i(() => {
		u.current || a.resetValidation();
	}), f = i((e) => {
		a.displayValidation.isInvalid || a.commitValidation();
		let n = s?.current?.form;
		!e.defaultPrevented && s && n && C(n) === s.current && (l ? l() : s.current?.focus(), t("keyboard")), e.preventDefault();
	}), p = i(() => {
		a.commitValidation();
	});
	(0, o.useEffect)(() => {
		let e = s?.current;
		if (!e) return;
		let t = e.form, n = t?.reset;
		return t && (t.reset = () => {
			u.current = !window.event || window.event.type === "message" && r(window.event) instanceof MessagePort, n?.call(t), u.current = !1;
		}), e.addEventListener("invalid", f), e.addEventListener("change", p), t?.addEventListener("reset", d), () => {
			e.removeEventListener("invalid", f), e.removeEventListener("change", p), t?.removeEventListener("reset", d), t && (t.reset = n);
		};
	}, [s, c]);
}
function x(e) {
	let t = e.validity;
	return {
		badInput: t.badInput,
		customError: t.customError,
		patternMismatch: t.patternMismatch,
		rangeOverflow: t.rangeOverflow,
		rangeUnderflow: t.rangeUnderflow,
		stepMismatch: t.stepMismatch,
		tooLong: t.tooLong,
		tooShort: t.tooShort,
		typeMismatch: t.typeMismatch,
		valueMissing: t.valueMissing,
		valid: t.valid
	};
}
function S(e) {
	return {
		isInvalid: !e.validity.valid,
		validationDetails: x(e),
		validationErrors: e.validationMessage ? [e.validationMessage] : []
	};
}
function C(e) {
	for (let t = 0; t < e.elements.length; t++) {
		let n = e.elements[t];
		if (n.validity?.valid === !1) return n;
	}
	return null;
}
//#endregion
export { y as a, b as i, s as n, u as o, p as r, f as t };

//# sourceMappingURL=useFormValidation-Cnit8K9v-CsmEyeH7.js.map