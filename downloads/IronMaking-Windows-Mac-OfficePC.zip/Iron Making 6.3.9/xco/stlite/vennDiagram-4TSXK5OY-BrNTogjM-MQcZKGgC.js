import { c as e } from "./transform-B2AI7qp--hg0kwf7R.js";
import { M as t, N as n, T as r, a2 as i, a7 as a, aQ as o, ai as s, aj as c, al as l, an as u, b2 as d, bB as f, bx as p, by as m, bz as h, c as g, f as _, q as v } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
//#region ../react/build/vennDiagram-4TSXK5OY-BrNTogjM.js
var y = (e, t) => _(e, "a", -t), b = 1e-10;
function x(e, t) {
	let n = C(e), r = n.filter((t) => S(t, e)), i = 0, a = 0, o = [];
	if (r.length > 1) {
		let t = O(r);
		for (let e = 0; e < r.length; ++e) {
			let n = r[e];
			n.angle = Math.atan2(n.x - t.x, n.y - t.y);
		}
		r.sort((e, t) => t.angle - e.angle);
		let n = r[r.length - 1];
		for (let t = 0; t < r.length; ++t) {
			let s = r[t];
			a += (n.x + s.x) * (s.y - n.y);
			let c = {
				x: (s.x + n.x) / 2,
				y: (s.y + n.y) / 2
			}, l = null;
			for (let t = 0; t < s.parentIndex.length; ++t) if (n.parentIndex.includes(s.parentIndex[t])) {
				let r = e[s.parentIndex[t]], i = Math.atan2(s.x - r.x, s.y - r.y), a = Math.atan2(n.x - r.x, n.y - r.y), o = a - i;
				o < 0 && (o += 2 * Math.PI);
				let u = a - o / 2, d = T(c, {
					x: r.x + r.radius * Math.sin(u),
					y: r.y + r.radius * Math.cos(u)
				});
				d > r.radius * 2 && (d = r.radius * 2), (l == null || l.width > d) && (l = {
					circle: r,
					width: d,
					p1: s,
					p2: n,
					large: d > r.radius,
					sweep: !0
				});
			}
			l != null && (o.push(l), i += w(l.circle.radius, l.width), n = s);
		}
	} else {
		let t = e[0];
		for (let n = 1; n < e.length; ++n) e[n].radius < t.radius && (t = e[n]);
		let n = !1;
		for (let r = 0; r < e.length; ++r) if (T(e[r], t) > Math.abs(t.radius - e[r].radius)) {
			n = !0;
			break;
		}
		n ? i = a = 0 : (i = t.radius * t.radius * Math.PI, o.push({
			circle: t,
			p1: {
				x: t.x,
				y: t.y + t.radius
			},
			p2: {
				x: t.x - b,
				y: t.y + t.radius
			},
			width: t.radius * 2,
			large: !0,
			sweep: !0
		}));
	}
	return a /= 2, t && (t.area = i + a, t.arcArea = i, t.polygonArea = a, t.arcs = o, t.innerPoints = r, t.intersectionPoints = n), i + a;
}
function S(e, t) {
	return t.every((t) => T(e, t) < t.radius + b);
}
function C(e) {
	let t = [];
	for (let n = 0; n < e.length; ++n) for (let r = n + 1; r < e.length; ++r) {
		let i = D(e[n], e[r]);
		for (let e of i) e.parentIndex = [n, r], t.push(e);
	}
	return t;
}
function w(e, t) {
	return e * e * Math.acos(1 - t / e) - (e - t) * Math.sqrt(t * (2 * e - t));
}
function T(e, t) {
	return Math.sqrt((e.x - t.x) * (e.x - t.x) + (e.y - t.y) * (e.y - t.y));
}
function E(e, t, n) {
	if (n >= e + t) return 0;
	if (n <= Math.abs(e - t)) return Math.PI * Math.min(e, t) * Math.min(e, t);
	let r = e - (n * n - t * t + e * e) / (2 * n), i = t - (n * n - e * e + t * t) / (2 * n);
	return w(e, r) + w(t, i);
}
function D(e, t) {
	let n = T(e, t), r = e.radius, i = t.radius;
	if (n >= r + i || n <= Math.abs(r - i)) return [];
	let a = (r * r - i * i + n * n) / (2 * n), o = Math.sqrt(r * r - a * a), s = e.x + a * (t.x - e.x) / n, c = e.y + a * (t.y - e.y) / n, l = -(t.y - e.y) * (o / n), u = -(t.x - e.x) * (o / n);
	return [{
		x: s + l,
		y: c - u
	}, {
		x: s - l,
		y: c + u
	}];
}
function O(e) {
	let t = {
		x: 0,
		y: 0
	};
	for (let n of e) t.x += n.x, t.y += n.y;
	return t.x /= e.length, t.y /= e.length, t;
}
function k(e, t, n, r) {
	r ||= {};
	let i = r.maxIterations || 100, a = r.tolerance || 1e-10, o = e(t), s = e(n), c = n - t;
	if (o * s > 0) throw "Initial bisect points must have opposite signs";
	if (o === 0) return t;
	if (s === 0) return n;
	for (let n = 0; n < i; ++n) {
		c /= 2;
		let n = t + c, r = e(n);
		if (r * o >= 0 && (t = n), Math.abs(c) < a || r === 0) return n;
	}
	return t + c;
}
function A(e) {
	let t = Array(e);
	for (let n = 0; n < e; ++n) t[n] = 0;
	return t;
}
function j(e, t) {
	return A(e).map(() => A(t));
}
function M(e, t) {
	let n = 0;
	for (let r = 0; r < e.length; ++r) n += e[r] * t[r];
	return n;
}
function N(e) {
	return Math.sqrt(M(e, e));
}
function P(e, t, n) {
	for (let r = 0; r < t.length; ++r) e[r] = t[r] * n;
}
function F(e, t, n, r, i) {
	for (let a = 0; a < e.length; ++a) e[a] = t * n[a] + r * i[a];
}
function I(e, t, n) {
	n ||= {};
	let r = n.maxIterations || t.length * 200, i = n.nonZeroDelta || 1.05, a = n.zeroDelta || .001, o = n.minErrorDelta || 1e-6, s = n.minErrorDelta || 1e-5, c = n.rho === void 0 ? 1 : n.rho, l = n.chi === void 0 ? 2 : n.chi, u = n.psi === void 0 ? -.5 : n.psi, d = n.sigma === void 0 ? .5 : n.sigma, f, p = t.length, m = Array(p + 1);
	m[0] = t, m[0].fx = e(t), m[0].id = 0;
	for (let n = 0; n < p; ++n) {
		let r = t.slice();
		r[n] = r[n] ? r[n] * i : a, m[n + 1] = r, m[n + 1].fx = e(r), m[n + 1].id = n + 1;
	}
	function h(e) {
		for (let t = 0; t < e.length; t++) m[p][t] = e[t];
		m[p].fx = e.fx;
	}
	let g = (e, t) => e.fx - t.fx, _ = t.slice(), v = t.slice(), y = t.slice(), b = t.slice();
	for (let t = 0; t < r; ++t) {
		if (m.sort(g), n.history) {
			let e = m.map((e) => {
				let t = e.slice();
				return t.fx = e.fx, t.id = e.id, t;
			});
			e.sort((e, t) => e.id - t.id), n.history.push({
				x: m[0].slice(),
				fx: m[0].fx,
				simplex: e
			});
		}
		f = 0;
		for (let e = 0; e < p; ++e) f = Math.max(f, Math.abs(m[0][e] - m[1][e]));
		if (Math.abs(m[0].fx - m[p].fx) < o && f < s) break;
		for (let e = 0; e < p; ++e) {
			_[e] = 0;
			for (let t = 0; t < p; ++t) _[e] += m[t][e];
			_[e] /= p;
		}
		let t = m[p];
		if (F(v, 1 + c, _, -c, t), v.fx = e(v), v.fx < m[0].fx) F(b, 1 + l, _, -l, t), b.fx = e(b), b.fx < v.fx ? h(b) : h(v);
		else if (v.fx >= m[p - 1].fx) {
			let n = !1;
			if (v.fx > t.fx ? (F(y, 1 + u, _, -u, t), y.fx = e(y), y.fx < t.fx ? h(y) : n = !0) : (F(y, 1 - u * c, _, u * c, t), y.fx = e(y), y.fx < v.fx ? h(y) : n = !0), n) {
				if (d >= 1) break;
				for (let t = 1; t < m.length; ++t) F(m[t], 1 - d, m[0], d, m[t]), m[t].fx = e(m[t]);
			}
		} else h(v);
	}
	return m.sort(g), {
		fx: m[0].fx,
		x: m[0]
	};
}
function L(e, t, n, r, i, a, o) {
	let s = n.fx, c = M(n.fxprime, t), l = s, u = s, d = c, f = 0;
	i ||= 1, a ||= 1e-6, o ||= .1;
	function p(u, f, p) {
		for (let m = 0; m < 16; ++m) if (i = (u + f) / 2, F(r.x, 1, n.x, i, t), l = r.fx = e(r.x, r.fxprime), d = M(r.fxprime, t), l > s + a * i * c || l >= p) f = i;
		else {
			if (Math.abs(d) <= -o * c) return i;
			d * (f - u) >= 0 && (f = u), u = i, p = l;
		}
		return 0;
	}
	for (let m = 0; m < 10; ++m) {
		if (F(r.x, 1, n.x, i, t), l = r.fx = e(r.x, r.fxprime), d = M(r.fxprime, t), l > s + a * i * c || m && l >= u) return p(f, i, u);
		if (Math.abs(d) <= -o * c) return i;
		if (d >= 0) return p(i, f, l);
		u = l, f = i, i *= 2;
	}
	return i;
}
function R(e, t, n) {
	let r = {
		x: t.slice(),
		fx: 0,
		fxprime: t.slice()
	}, i = {
		x: t.slice(),
		fx: 0,
		fxprime: t.slice()
	}, a = t.slice(), o, s, c = 1, l;
	n ||= {}, l = n.maxIterations || t.length * 20, r.fx = e(r.x, r.fxprime), o = r.fxprime.slice(), P(o, r.fxprime, -1);
	for (let t = 0; t < l; ++t) {
		if (c = L(e, o, r, i, c), n.history && n.history.push({
			x: r.x.slice(),
			fx: r.fx,
			fxprime: r.fxprime.slice(),
			alpha: c
		}), !c) P(o, r.fxprime, -1);
		else {
			F(a, 1, i.fxprime, -1, r.fxprime);
			let e = M(r.fxprime, r.fxprime), t = Math.max(0, M(a, i.fxprime) / e);
			F(o, t, o, -1, i.fxprime), s = r, r = i, i = s;
		}
		if (N(r.fxprime) <= 1e-5) break;
	}
	return n.history && n.history.push({
		x: r.x.slice(),
		fx: r.fx,
		fxprime: r.fxprime.slice(),
		alpha: c
	}), r;
}
function ee(e, t = {}) {
	t.maxIterations = t.maxIterations || 500;
	let n = t.initialLayout || ae, r = t.lossFunction || B, i = ne(e, t), a = n(i, t), o = Object.keys(a), s = [];
	for (let e of o) s.push(a[e].x), s.push(a[e].y);
	let c = I((e) => {
		let t = {};
		for (let n = 0; n < o.length; ++n) {
			let r = o[n];
			t[r] = {
				x: e[2 * n],
				y: e[2 * n + 1],
				radius: a[r].radius
			};
		}
		return r(t, i);
	}, s, t).x;
	for (let e = 0; e < o.length; ++e) {
		let t = o[e];
		a[t].x = c[2 * e], a[t].y = c[2 * e + 1];
	}
	return a;
}
var te = 1e-10;
function z(e, t, n) {
	return Math.min(e, t) * Math.min(e, t) * Math.PI <= n + te ? Math.abs(e - t) : k((r) => E(e, t, r) - n, 0, e + t);
}
function ne(e, t = {}) {
	let n = t.distinct, r = e.map((e) => Object.assign({}, e));
	function i(e) {
		return e.join(";");
	}
	if (n) {
		let e = /* @__PURE__ */ new Map();
		for (let t of r) for (let n = 0; n < t.sets.length; n++) {
			let r = String(t.sets[n]);
			e.set(r, t.size + (e.get(r) || 0));
			for (let i = n + 1; i < t.sets.length; i++) {
				let n = String(t.sets[i]), a = `${r};${n}`, o = `${n};${r}`;
				e.set(a, t.size + (e.get(a) || 0)), e.set(o, t.size + (e.get(o) || 0));
			}
		}
		for (let t of r) t.sets.length < 3 && (t.size = e.get(i(t.sets)));
	}
	let a = [], o = /* @__PURE__ */ new Set();
	for (let e of r) if (e.sets.length === 1) a.push(e.sets[0]);
	else if (e.sets.length === 2) {
		let t = e.sets[0], n = e.sets[1];
		o.add(i(e.sets)), o.add(i([n, t]));
	}
	a.sort((e, t) => e === t ? 0 : e < t ? -1 : 1);
	for (let e = 0; e < a.length; ++e) {
		let t = a[e];
		for (let n = e + 1; n < a.length; ++n) {
			let e = a[n];
			o.has(i([t, e])) || r.push({
				sets: [t, e],
				size: 0
			});
		}
	}
	return r;
}
function re(e, t, n) {
	let r = j(t.length, t.length), i = j(t.length, t.length);
	return e.filter((e) => e.sets.length === 2).forEach((e) => {
		let a = n[e.sets[0]], o = n[e.sets[1]], s = z(Math.sqrt(t[a].size / Math.PI), Math.sqrt(t[o].size / Math.PI), e.size);
		r[a][o] = r[o][a] = s;
		let c = 0;
		e.size + 1e-10 >= Math.min(t[a].size, t[o].size) ? c = 1 : e.size <= 1e-10 && (c = -1), i[a][o] = i[o][a] = c;
	}), {
		distances: r,
		constraints: i
	};
}
function ie(e, t, n, r) {
	for (let e = 0; e < t.length; ++e) t[e] = 0;
	let i = 0;
	for (let a = 0; a < n.length; ++a) {
		let o = e[2 * a], s = e[2 * a + 1];
		for (let c = a + 1; c < n.length; ++c) {
			let l = e[2 * c], u = e[2 * c + 1], d = n[a][c], f = r[a][c], p = (l - o) * (l - o) + (u - s) * (u - s), m = Math.sqrt(p), h = p - d * d;
			f > 0 && m <= d || f < 0 && m >= d || (i += 2 * h * h, t[2 * a] += 4 * h * (o - l), t[2 * a + 1] += 4 * h * (s - u), t[2 * c] += 4 * h * (l - o), t[2 * c + 1] += 4 * h * (u - s));
		}
	}
	return i;
}
function ae(e, t = {}) {
	let n = se(e, t), r = t.lossFunction || B;
	if (e.length >= 8) {
		let i = oe(e, t), a = r(i, e), o = r(n, e);
		a + 1e-8 < o && (n = i);
	}
	return n;
}
function oe(e, t = {}) {
	let n = t.restarts || 10, r = [], i = {};
	for (let t of e) t.sets.length === 1 && (i[t.sets[0]] = r.length, r.push(t));
	let { distances: a, constraints: o } = re(e, r, i), s = N(a.map(N)) / a.length;
	a = a.map((e) => e.map((e) => e / s));
	let c = (e, t) => ie(e, t, a, o), l = null;
	for (let e = 0; e < n; ++e) {
		let e = R(c, A(a.length * 2).map(Math.random), t);
		(!l || e.fx < l.fx) && (l = e);
	}
	let u = l.x, d = {};
	for (let e = 0; e < r.length; ++e) {
		let t = r[e];
		d[t.sets[0]] = {
			x: u[2 * e] * s,
			y: u[2 * e + 1] * s,
			radius: Math.sqrt(t.size / Math.PI)
		};
	}
	if (t.history) for (let e of t.history) P(e.x, s);
	return d;
}
function se(e, t) {
	let n = t && t.lossFunction ? t.lossFunction : B, r = {}, i = {};
	for (let t of e) if (t.sets.length === 1) {
		let e = t.sets[0];
		r[e] = {
			x: 1e10,
			y: 1e10,
			rowid: r.length,
			size: t.size,
			radius: Math.sqrt(t.size / Math.PI)
		}, i[e] = [];
	}
	e = e.filter((e) => e.sets.length === 2);
	for (let t of e) {
		let e = t.weight == null ? 1 : t.weight, n = t.sets[0], a = t.sets[1];
		t.size + te >= Math.min(r[n].size, r[a].size) && (e = 0), i[n].push({
			set: a,
			size: t.size,
			weight: e
		}), i[a].push({
			set: n,
			size: t.size,
			weight: e
		});
	}
	let a = [];
	Object.keys(i).forEach((e) => {
		let t = 0;
		for (let n = 0; n < i[e].length; ++n) t += i[e][n].size * i[e][n].weight;
		a.push({
			set: e,
			size: t
		});
	});
	function o(e, t) {
		return t.size - e.size;
	}
	a.sort(o);
	let s = {};
	function c(e) {
		return e.set in s;
	}
	function l(e, t) {
		r[t].x = e.x, r[t].y = e.y, s[t] = !0;
	}
	l({
		x: 0,
		y: 0
	}, a[0].set);
	for (let t = 1; t < a.length; ++t) {
		let s = a[t].set, d = i[s].filter(c), f = r[s];
		if (d.sort(o), d.length === 0) throw "ERROR: missing pairwise overlap information";
		let p = [];
		for (var u = 0; u < d.length; ++u) {
			let e = r[d[u].set], t = z(f.radius, e.radius, d[u].size);
			p.push({
				x: e.x + t,
				y: e.y
			}), p.push({
				x: e.x - t,
				y: e.y
			}), p.push({
				y: e.y + t,
				x: e.x
			}), p.push({
				y: e.y - t,
				x: e.x
			});
			for (let n = u + 1; n < d.length; ++n) {
				let i = r[d[n].set], a = z(f.radius, i.radius, d[n].size), o = D({
					x: e.x,
					y: e.y,
					radius: t
				}, {
					x: i.x,
					y: i.y,
					radius: a
				});
				p.push(...o);
			}
		}
		let m = 1e50, h = p[0];
		for (let t of p) {
			r[s].x = t.x, r[s].y = t.y;
			let i = n(r, e);
			i < m && (m = i, h = t);
		}
		l(h, s);
	}
	return r;
}
function B(e, t) {
	let n = 0;
	for (let r of t) {
		if (r.sets.length === 1) continue;
		let t;
		if (r.sets.length === 2) {
			let n = e[r.sets[0]], i = e[r.sets[1]];
			t = E(n.radius, i.radius, T(n, i));
		} else t = x(r.sets.map((t) => e[t]));
		let i = r.weight == null ? 1 : r.weight;
		n += i * (t - r.size) * (t - r.size);
	}
	return n;
}
function ce(e, t) {
	let n = 0;
	for (let r of t) {
		if (r.sets.length === 1) continue;
		let t;
		if (r.sets.length === 2) {
			let n = e[r.sets[0]], i = e[r.sets[1]];
			t = E(n.radius, i.radius, T(n, i));
		} else t = x(r.sets.map((t) => e[t]));
		let i = r.weight == null ? 1 : r.weight, a = Math.log((t + 1) / (r.size + 1));
		n += i * a * a;
	}
	return n;
}
function le(e, t, n) {
	if (n == null ? e.sort((e, t) => t.radius - e.radius) : e.sort(n), e.length > 0) {
		let t = e[0].x, n = e[0].y;
		for (let r of e) r.x -= t, r.y -= n;
	}
	if (e.length === 2 && T(e[0], e[1]) < Math.abs(e[1].radius - e[0].radius) && (e[1].x = e[0].x + e[0].radius - e[1].radius - 1e-10, e[1].y = e[0].y), e.length > 1) {
		let n = Math.atan2(e[1].x, e[1].y) - t, r = Math.cos(n), i = Math.sin(n);
		for (let t of e) {
			let e = t.x, n = t.y;
			t.x = r * e - i * n, t.y = i * e + r * n;
		}
	}
	if (e.length > 2) {
		let n = Math.atan2(e[2].x, e[2].y) - t;
		for (; n < 0;) n += 2 * Math.PI;
		for (; n > 2 * Math.PI;) n -= 2 * Math.PI;
		if (n > Math.PI) {
			let t = e[1].y / (1e-10 + e[1].x);
			for (let n of e) {
				var r = (n.x + t * n.y) / (1 + t * t);
				n.x = 2 * r - n.x, n.y = 2 * r * t - n.y;
			}
		}
	}
}
function ue(e) {
	e.forEach((e) => {
		e.parent = e;
	});
	function t(e) {
		return e.parent !== e && (e.parent = t(e.parent)), e.parent;
	}
	function n(e, n) {
		let r = t(e);
		r.parent = t(n);
	}
	for (let t = 0; t < e.length; ++t) for (let r = t + 1; r < e.length; ++r) {
		let i = e[t].radius + e[r].radius;
		T(e[t], e[r]) + 1e-10 < i && n(e[r], e[t]);
	}
	let r = /* @__PURE__ */ new Map();
	for (let n = 0; n < e.length; ++n) {
		let i = t(e[n]).parent.setid;
		r.has(i) || r.set(i, []), r.get(i).push(e[n]);
	}
	return e.forEach((e) => {
		delete e.parent;
	}), Array.from(r.values());
}
function V(e) {
	let t = (t) => ({
		max: e.reduce((e, n) => Math.max(e, n[t] + n.radius), -Infinity),
		min: e.reduce((e, n) => Math.min(e, n[t] - n.radius), Infinity)
	});
	return {
		xRange: t("x"),
		yRange: t("y")
	};
}
function de(e, t, n) {
	t ??= Math.PI / 2;
	let r = me(e).map((e) => Object.assign({}, e)), i = ue(r);
	for (let e of i) {
		le(e, t, n);
		let r = V(e);
		e.size = (r.xRange.max - r.xRange.min) * (r.yRange.max - r.yRange.min), e.bounds = r;
	}
	i.sort((e, t) => t.size - e.size), r = i[0];
	let a = r.bounds, o = (a.xRange.max - a.xRange.min) / 50;
	function s(e, t, n) {
		if (!e) return;
		let i = e.bounds, s, c;
		if (t) s = a.xRange.max - i.xRange.min + o;
		else {
			s = a.xRange.max - i.xRange.max;
			let e = (i.xRange.max - i.xRange.min) / 2 - (a.xRange.max - a.xRange.min) / 2;
			e < 0 && (s += e);
		}
		if (n) c = a.yRange.max - i.yRange.min + o;
		else {
			c = a.yRange.max - i.yRange.max;
			let e = (i.yRange.max - i.yRange.min) / 2 - (a.yRange.max - a.yRange.min) / 2;
			e < 0 && (c += e);
		}
		for (let t of e) t.x += s, t.y += c, r.push(t);
	}
	let c = 1;
	for (; c < i.length;) s(i[c], !0, !1), s(i[c + 1], !1, !0), s(i[c + 2], !0, !0), c += 3, a = V(r);
	return pe(r);
}
function fe(e, t, n, r, i) {
	let a = me(e);
	t -= 2 * r, n -= 2 * r;
	let { xRange: o, yRange: s } = V(a);
	if (o.max === o.min || s.max === s.min) return console.log("not scaling solution: zero size detected"), e;
	let c, l;
	if (i) {
		let e = Math.sqrt(i / Math.PI) * 2;
		c = t / e, l = n / e;
	} else c = t / (o.max - o.min), l = n / (s.max - s.min);
	let u = Math.min(l, c), d = (t - (o.max - o.min) * u) / 2, f = (n - (s.max - s.min) * u) / 2;
	return pe(a.map((e) => ({
		radius: u * e.radius,
		x: r + d + (e.x - o.min) * u,
		y: r + f + (e.y - s.min) * u,
		setid: e.setid
	})));
}
function pe(e) {
	let t = {};
	for (let n of e) t[n.setid] = n;
	return t;
}
function me(e) {
	return Object.keys(e).map((t) => Object.assign(e[t], { setid: t }));
}
function he(e = {}) {
	let t = !1, n = 600, r = 350, i = 15, a = 1e3, o = Math.PI / 2, s = !0, c = null, l = !0, u = !0, d = null, f = null, p = !1, m = null, h = e && e.symmetricalTextCentre ? e.symmetricalTextCentre : !1, g = {}, _ = e && e.colourScheme ? e.colourScheme : e && e.colorScheme ? e.colorScheme : [
		"#1f77b4",
		"#ff7f0e",
		"#2ca02c",
		"#d62728",
		"#9467bd",
		"#8c564b",
		"#e377c2",
		"#7f7f7f",
		"#bcbd22",
		"#17becf"
	], v = 0, y = function(e) {
		if (e in g) return g[e];
		var t = g[e] = _[v];
		return v += 1, v >= _.length && (v = 0), t;
	}, b = ee, x = B;
	function S(g) {
		let _ = g.datum(), v = /* @__PURE__ */ new Set();
		_.forEach((e) => {
			e.size == 0 && e.sets.length == 1 && v.add(e.sets[0]);
		}), _ = _.filter((e) => !e.sets.some((e) => v.has(e)));
		let S = {}, C = {};
		if (_.length > 0) {
			let e = b(_, {
				lossFunction: x,
				distinct: p
			});
			s && (e = de(e, o, f)), S = fe(e, n, r, i, c), C = ve(S, _, h);
		}
		let w = {};
		_.forEach((e) => {
			e.label && (w[e.sets] = e.label);
		});
		function T(e) {
			if (e.sets in w) return w[e.sets];
			if (e.sets.length == 1) return "" + e.sets[0];
		}
		g.selectAll("svg").data([S]).enter().append("svg");
		let E = g.select("svg");
		t ? E.attr("viewBox", `0 0 ${n} ${r}`) : E.attr("width", n).attr("height", r);
		let D = {}, O = !1;
		E.selectAll(".venn-area path").each(function(e) {
			let t = this.getAttribute("d");
			e.sets.length == 1 && t && !p && (O = !0, D[e.sets[0]] = be(t));
		});
		function k(e) {
			return (t) => Ce(e.sets.map((e) => {
				let i = D[e], a = S[e];
				return i ||= {
					x: n / 2,
					y: r / 2,
					radius: 1
				}, a ||= {
					x: n / 2,
					y: r / 2,
					radius: 1
				}, {
					x: i.x * (1 - t) + a.x * t,
					y: i.y * (1 - t) + a.y * t,
					radius: i.radius * (1 - t) + a.radius * t
				};
			}), m);
		}
		let A = E.selectAll(".venn-area").data(_, (e) => e.sets), j = A.enter().append("g").attr("class", (e) => `venn-area venn-${e.sets.length == 1 ? "circle" : "intersection"}${e.colour || e.color ? " venn-coloured" : ""}`).attr("data-venn-sets", (e) => e.sets.join("_")), M = j.append("path"), N = j.append("text").attr("class", "label").text((e) => T(e)).attr("text-anchor", "middle").attr("dy", ".35em").attr("x", n / 2).attr("y", r / 2);
		u && (M.style("fill-opacity", "0").filter((e) => e.sets.length == 1).style("fill", (e) => e.colour ? e.colour : e.color ? e.color : y(e.sets)).style("fill-opacity", ".25"), N.style("fill", (t) => t.colour || t.color ? "#FFF" : e.textFill ? e.textFill : t.sets.length == 1 ? y(t.sets) : "#444"));
		function P(e) {
			return typeof e.transition == "function" ? e.transition("venn").duration(a) : e;
		}
		let F = g;
		O && typeof F.transition == "function" ? (F = P(g), F.selectAll("path").attrTween("d", k)) : F.selectAll("path").attr("d", (e) => Ce(e.sets.map((e) => S[e])), m);
		let I = F.selectAll("text").filter((e) => e.sets in C).text((e) => T(e)).attr("x", (e) => Math.floor(C[e.sets].x)).attr("y", (e) => Math.floor(C[e.sets].y));
		l && (O ? "on" in I ? I.on("end", H(S, T)) : I.each("end", H(S, T)) : I.each(H(S, T)));
		let L = P(A.exit()).remove();
		typeof A.transition == "function" && L.selectAll("path").attrTween("d", k);
		let R = L.selectAll("text").attr("x", n / 2).attr("y", r / 2);
		return d !== null && (N.style("font-size", "0px"), I.style("font-size", d), R.style("font-size", "0px")), {
			circles: S,
			textCentres: C,
			nodes: A,
			enter: j,
			update: F,
			exit: L
		};
	}
	return S.wrap = function(e) {
		return arguments.length ? (l = e, S) : l;
	}, S.useViewBox = function() {
		return t = !0, S;
	}, S.width = function(e) {
		return arguments.length ? (n = e, S) : n;
	}, S.height = function(e) {
		return arguments.length ? (r = e, S) : r;
	}, S.padding = function(e) {
		return arguments.length ? (i = e, S) : i;
	}, S.distinct = function(e) {
		return arguments.length ? (p = e, S) : p;
	}, S.colours = function(e) {
		return arguments.length ? (y = e, S) : y;
	}, S.colors = function(e) {
		return arguments.length ? (y = e, S) : y;
	}, S.fontSize = function(e) {
		return arguments.length ? (d = e, S) : d;
	}, S.round = function(e) {
		return arguments.length ? (m = e, S) : m;
	}, S.duration = function(e) {
		return arguments.length ? (a = e, S) : a;
	}, S.layoutFunction = function(e) {
		return arguments.length ? (b = e, S) : b;
	}, S.normalize = function(e) {
		return arguments.length ? (s = e, S) : s;
	}, S.scaleToFit = function(e) {
		return arguments.length ? (c = e, S) : c;
	}, S.styled = function(e) {
		return arguments.length ? (u = e, S) : u;
	}, S.orientation = function(e) {
		return arguments.length ? (o = e, S) : o;
	}, S.orientationOrder = function(e) {
		return arguments.length ? (f = e, S) : f;
	}, S.lossFunction = function(e) {
		return arguments.length ? (x = e === "default" ? B : e === "logRatio" ? ce : e, S) : x;
	}, S;
}
function H(e, t) {
	return function(n) {
		let r = this, i = e[n.sets[0]].radius || 50, a = t(n) || "", o = a.split(/\s+/).reverse(), s = (a.length + o.length) / 3, c = o.pop(), l = [c], u = 0, d = 1.1;
		r.textContent = null;
		let f = [];
		function p(e) {
			let t = r.ownerDocument.createElementNS(r.namespaceURI, "tspan");
			return t.textContent = e, f.push(t), r.append(t), t;
		}
		let m = p(c);
		for (; c = o.pop(), c;) {
			l.push(c);
			let e = l.join(" ");
			m.textContent = e, e.length > s && m.getComputedTextLength() > i && (l.pop(), m.textContent = l.join(" "), l = [c], m = p(c), u++);
		}
		let h = .35 - u * d / 2, g = r.getAttribute("x"), _ = r.getAttribute("y");
		f.forEach((e, t) => {
			e.setAttribute("x", g), e.setAttribute("y", _), e.setAttribute("dy", `${h + t * d}em`);
		});
	};
}
function U(e, t, n) {
	let r = t[0].radius - T(t[0], e);
	for (let n = 1; n < t.length; ++n) {
		let i = t[n].radius - T(t[n], e);
		i <= r && (r = i);
	}
	for (let t = 0; t < n.length; ++t) {
		let i = T(n[t], e) - n[t].radius;
		i <= r && (r = i);
	}
	return r;
}
function ge(e, t, n) {
	let r = [];
	for (let t of e) r.push({
		x: t.x,
		y: t.y
	}), r.push({
		x: t.x + t.radius / 2,
		y: t.y
	}), r.push({
		x: t.x - t.radius / 2,
		y: t.y
	}), r.push({
		x: t.x,
		y: t.y + t.radius / 2
	}), r.push({
		x: t.x,
		y: t.y - t.radius / 2
	});
	let i = r[0], a = U(r[0], e, t);
	for (let n = 1; n < r.length; ++n) {
		let o = U(r[n], e, t);
		o >= a && (i = r[n], a = o);
	}
	let o = I((n) => -1 * U({
		x: n[0],
		y: n[1]
	}, e, t), [i.x, i.y], {
		maxIterations: 500,
		minErrorDelta: 1e-10
	}).x, s = {
		x: n ? 0 : o[0],
		y: o[1]
	}, c = !0;
	for (let t of e) if (T(s, t) > t.radius) {
		c = !1;
		break;
	}
	for (let e of t) if (T(s, e) < e.radius) {
		c = !1;
		break;
	}
	if (c) return s;
	if (e.length == 1) return {
		x: e[0].x,
		y: e[0].y
	};
	let l = {};
	return x(e, l), l.arcs.length === 0 ? {
		x: 0,
		y: -1e3,
		disjoint: !0
	} : l.arcs.length == 1 ? {
		x: l.arcs[0].circle.x,
		y: l.arcs[0].circle.y
	} : t.length ? ge(e, []) : O(l.arcs.map((e) => e.p1));
}
function _e(e) {
	let t = {}, n = Object.keys(e);
	for (let e of n) t[e] = [];
	for (let r = 0; r < n.length; r++) {
		let i = n[r], a = e[i];
		for (let o = r + 1; o < n.length; ++o) {
			let r = n[o], s = e[r], c = T(a, s);
			c + s.radius <= a.radius + 1e-10 ? t[r].push(i) : c + a.radius <= s.radius + 1e-10 && t[i].push(r);
		}
	}
	return t;
}
function ve(e, t, n) {
	let r = {}, i = _e(e);
	for (let a = 0; a < t.length; ++a) {
		let o = t[a].sets, s = {}, c = {};
		for (let e = 0; e < o.length; ++e) {
			s[o[e]] = !0;
			let t = i[o[e]];
			for (let e = 0; e < t.length; ++e) c[t[e]] = !0;
		}
		let l = [], u = [];
		for (let t in e) t in s ? l.push(e[t]) : t in c || u.push(e[t]);
		let d = ge(l, u, n);
		r[o] = d, d.disjoint && t[a].size > 0 && console.log("WARNING: area " + o + " not represented on screen");
	}
	return r;
}
function ye(e, t, n) {
	let r = [];
	return r.push("\nM", e, t), r.push("\nm", -n, 0), r.push("\na", n, n, 0, 1, 0, n * 2, 0), r.push("\na", n, n, 0, 1, 0, -n * 2, 0), r.join(" ");
}
function be(e) {
	let t = e.split(" ");
	return {
		x: Number.parseFloat(t[1]),
		y: Number.parseFloat(t[2]),
		radius: -Number.parseFloat(t[4])
	};
}
function xe(e) {
	if (e.length === 0) return [];
	let t = {};
	return x(e, t), t.arcs;
}
function Se(e, t) {
	if (e.length === 0) return "M 0 0";
	let n = 10 ** (t || 0), r = t == null ? (e) => e : (e) => Math.round(e * n) / n;
	if (e.length == 1) {
		let t = e[0].circle;
		return ye(r(t.x), r(t.y), r(t.radius));
	}
	let i = [
		"\nM",
		r(e[0].p2.x),
		r(e[0].p2.y)
	];
	for (let t of e) {
		let e = r(t.circle.radius);
		i.push("\nA", e, e, 0, +!!t.large, +!!t.sweep, r(t.p1.x), r(t.p1.y));
	}
	return i.join(" ");
}
function Ce(e, t) {
	return Se(xe(e), t);
}
function we(e, t = {}) {
	let { lossFunction: n, layoutFunction: r = ee, normalize: i = !0, orientation: a = Math.PI / 2, orientationOrder: o, width: s = 600, height: c = 350, padding: l = 15, scaleToFit: u = !1, symmetricalTextCentre: d = !1, distinct: f, round: p = 2 } = t, m = r(e, {
		lossFunction: n === "default" || !n ? B : n === "logRatio" ? ce : n,
		distinct: f
	});
	i && (m = de(m, a, o));
	let h = fe(m, s, c, l, u), g = ve(h, e, d), _ = new Map(Object.keys(h).map((e) => [e, {
		set: e,
		x: h[e].x,
		y: h[e].y,
		radius: h[e].radius
	}])), v = e.map((e) => {
		let t = e.sets.map((e) => _.get(e)), n = xe(t);
		return {
			circles: t,
			arcs: n,
			path: Se(n, p),
			area: e,
			has: new Set(e.sets)
		};
	});
	function y(e) {
		let t = "";
		for (let n of v) n.has.size > e.length && e.every((e) => n.has.has(e)) && (t += " " + n.path);
		return t;
	}
	return v.map(({ circles: e, arcs: t, path: n, area: r }) => ({
		data: r,
		text: g[r.sets],
		circles: e,
		arcs: t,
		path: n,
		distinctPath: n + y(r.sets)
	}));
}
var W = function() {
	var e = /* @__PURE__ */ g(function(e, t, n, r) {
		for (n ||= {}, r = e.length; r--; n[e[r]] = t);
		return n;
	}, "o"), t = [5, 8], n = [
		7,
		8,
		11,
		12,
		17,
		19,
		22,
		24
	], r = [1, 17], i = [1, 18], a = [
		7,
		8,
		11,
		12,
		14,
		15,
		16,
		17,
		19,
		20,
		21,
		22,
		24,
		27
	], o = [1, 31], s = [1, 39], c = [
		7,
		8,
		11,
		12,
		17,
		19,
		22,
		24,
		27
	], l = [1, 57], u = [1, 56], d = [1, 58], f = [1, 59], p = [1, 60], m = [
		7,
		8,
		11,
		12,
		16,
		17,
		19,
		20,
		22,
		24,
		27,
		31,
		32,
		33
	], h = {
		trace: /* @__PURE__ */ g(function() {}, "trace"),
		yy: {},
		symbols_: {
			error: 2,
			start: 3,
			optNewlines: 4,
			VENN: 5,
			document: 6,
			EOF: 7,
			NEWLINE: 8,
			line: 9,
			statement: 10,
			TITLE: 11,
			SET: 12,
			identifier: 13,
			BRACKET_LABEL: 14,
			COLON: 15,
			NUMERIC: 16,
			UNION: 17,
			identifierList: 18,
			TEXT: 19,
			IDENTIFIER: 20,
			STRING: 21,
			INDENT_TEXT: 22,
			indentedTextTail: 23,
			STYLE: 24,
			stylesOpt: 25,
			styleField: 26,
			COMMA: 27,
			styleValue: 28,
			valueTokens: 29,
			valueToken: 30,
			HEXCOLOR: 31,
			RGBCOLOR: 32,
			RGBACOLOR: 33,
			$accept: 0,
			$end: 1
		},
		terminals_: {
			2: "error",
			5: "VENN",
			7: "EOF",
			8: "NEWLINE",
			11: "TITLE",
			12: "SET",
			14: "BRACKET_LABEL",
			15: "COLON",
			16: "NUMERIC",
			17: "UNION",
			19: "TEXT",
			20: "IDENTIFIER",
			21: "STRING",
			22: "INDENT_TEXT",
			24: "STYLE",
			27: "COMMA",
			31: "HEXCOLOR",
			32: "RGBCOLOR",
			33: "RGBACOLOR"
		},
		productions_: [
			0,
			[3, 4],
			[4, 0],
			[4, 2],
			[6, 0],
			[6, 2],
			[9, 1],
			[9, 1],
			[10, 1],
			[10, 2],
			[10, 3],
			[10, 4],
			[10, 5],
			[10, 2],
			[10, 3],
			[10, 4],
			[10, 5],
			[10, 3],
			[10, 3],
			[10, 3],
			[10, 4],
			[10, 4],
			[10, 2],
			[10, 3],
			[23, 1],
			[23, 1],
			[23, 1],
			[23, 2],
			[23, 2],
			[25, 1],
			[25, 3],
			[26, 3],
			[28, 1],
			[28, 1],
			[29, 1],
			[29, 2],
			[30, 1],
			[30, 1],
			[30, 1],
			[30, 1],
			[30, 1],
			[18, 1],
			[18, 3],
			[13, 1],
			[13, 1]
		],
		performAction: /* @__PURE__ */ g(function(e, t, n, r, i, a, o) {
			var s = a.length - 1;
			switch (i) {
				case 1: return a[s - 1];
				case 2:
				case 3:
				case 4:
					this.$ = [];
					break;
				case 5:
					a[s - 1].push(a[s]), this.$ = a[s - 1];
					break;
				case 6:
					this.$ = [];
					break;
				case 7:
				case 22:
				case 32:
				case 36:
				case 37:
				case 38:
				case 39:
				case 40:
					this.$ = a[s];
					break;
				case 8:
					r.setDiagramTitle(a[s].substr(6)), this.$ = a[s].substr(6);
					break;
				case 9:
					r.addSubsetData([a[s]], void 0, void 0), r.setIndentMode && r.setIndentMode(!0);
					break;
				case 10:
					r.addSubsetData([a[s - 1]], a[s], void 0), r.setIndentMode && r.setIndentMode(!0);
					break;
				case 11:
					r.addSubsetData([a[s - 2]], void 0, parseFloat(a[s])), r.setIndentMode && r.setIndentMode(!0);
					break;
				case 12:
					r.addSubsetData([a[s - 3]], a[s - 2], parseFloat(a[s])), r.setIndentMode && r.setIndentMode(!0);
					break;
				case 13:
					if (a[s].length < 2) throw Error("union requires multiple identifiers");
					r.validateUnionIdentifiers && r.validateUnionIdentifiers(a[s]), r.addSubsetData(a[s], void 0, void 0), r.setIndentMode && r.setIndentMode(!0);
					break;
				case 14:
					if (a[s - 1].length < 2) throw Error("union requires multiple identifiers");
					r.validateUnionIdentifiers && r.validateUnionIdentifiers(a[s - 1]), r.addSubsetData(a[s - 1], a[s], void 0), r.setIndentMode && r.setIndentMode(!0);
					break;
				case 15:
					if (a[s - 2].length < 2) throw Error("union requires multiple identifiers");
					r.validateUnionIdentifiers && r.validateUnionIdentifiers(a[s - 2]), r.addSubsetData(a[s - 2], void 0, parseFloat(a[s])), r.setIndentMode && r.setIndentMode(!0);
					break;
				case 16:
					if (a[s - 3].length < 2) throw Error("union requires multiple identifiers");
					r.validateUnionIdentifiers && r.validateUnionIdentifiers(a[s - 3]), r.addSubsetData(a[s - 3], a[s - 2], parseFloat(a[s])), r.setIndentMode && r.setIndentMode(!0);
					break;
				case 17:
				case 18:
				case 19:
					r.addTextData(a[s - 1], a[s], void 0);
					break;
				case 20:
				case 21:
					r.addTextData(a[s - 2], a[s - 1], a[s]);
					break;
				case 23:
					r.addStyleData(a[s - 1], a[s]);
					break;
				case 24:
				case 25:
				case 26:
					var c = r.getCurrentSets();
					if (!c) throw Error("text requires set");
					r.addTextData(c, a[s], void 0);
					break;
				case 27:
				case 28:
					var c = r.getCurrentSets();
					if (!c) throw Error("text requires set");
					r.addTextData(c, a[s - 1], a[s]);
					break;
				case 29:
				case 41:
					this.$ = [a[s]];
					break;
				case 30:
				case 42:
					this.$ = [...a[s - 2], a[s]];
					break;
				case 31:
					this.$ = [a[s - 2], a[s]];
					break;
				case 33:
					this.$ = a[s].join(" ");
					break;
				case 34:
					this.$ = [a[s]];
					break;
				case 35:
					a[s - 1].push(a[s]), this.$ = a[s - 1];
					break;
				case 43:
				case 44: this.$ = a[s];
			}
		}, "anonymous"),
		table: [
			e(t, [2, 2], {
				3: 1,
				4: 2
			}),
			{ 1: [3] },
			{
				5: [1, 3],
				8: [1, 4]
			},
			e(n, [2, 4], { 6: 5 }),
			e(t, [2, 3]),
			{
				7: [1, 6],
				8: [1, 8],
				9: 7,
				10: 9,
				11: [1, 10],
				12: [1, 11],
				17: [1, 12],
				19: [1, 13],
				22: [1, 14],
				24: [1, 15]
			},
			{ 1: [2, 1] },
			e(n, [2, 5]),
			e(n, [2, 6]),
			e(n, [2, 7]),
			e(n, [2, 8]),
			{
				13: 16,
				20: r,
				21: i
			},
			{
				13: 20,
				18: 19,
				20: r,
				21: i
			},
			{
				13: 20,
				18: 21,
				20: r,
				21: i
			},
			{
				16: [1, 25],
				20: [1, 23],
				21: [1, 24],
				23: 22
			},
			{
				13: 20,
				18: 26,
				20: r,
				21: i
			},
			e(n, [2, 9], {
				14: [1, 27],
				15: [1, 28]
			}),
			e(a, [2, 43]),
			e(a, [2, 44]),
			e(n, [2, 13], {
				14: [1, 29],
				15: [1, 30],
				27: o
			}),
			e(a, [2, 41]),
			{
				16: [1, 34],
				20: [1, 32],
				21: [1, 33],
				27: o
			},
			e(n, [2, 22]),
			e(n, [2, 24], { 14: [1, 35] }),
			e(n, [2, 25], { 14: [1, 36] }),
			e(n, [2, 26]),
			{
				20: s,
				25: 37,
				26: 38,
				27: o
			},
			e(n, [2, 10], { 15: [1, 40] }),
			{ 16: [1, 41] },
			e(n, [2, 14], { 15: [1, 42] }),
			{ 16: [1, 43] },
			{
				13: 44,
				20: r,
				21: i
			},
			e(n, [2, 17], { 14: [1, 45] }),
			e(n, [2, 18], { 14: [1, 46] }),
			e(n, [2, 19]),
			e(n, [2, 27]),
			e(n, [2, 28]),
			e(n, [2, 23], { 27: [1, 47] }),
			e(c, [2, 29]),
			{ 15: [1, 48] },
			{ 16: [1, 49] },
			e(n, [2, 11]),
			{ 16: [1, 50] },
			e(n, [2, 15]),
			e(a, [2, 42]),
			e(n, [2, 20]),
			e(n, [2, 21]),
			{
				20: s,
				26: 51
			},
			{
				16: l,
				20: u,
				21: [1, 53],
				28: 52,
				29: 54,
				30: 55,
				31: d,
				32: f,
				33: p
			},
			e(n, [2, 12]),
			e(n, [2, 16]),
			e(c, [2, 30]),
			e(c, [2, 31]),
			e(c, [2, 32]),
			e(c, [2, 33], {
				30: 61,
				16: l,
				20: u,
				31: d,
				32: f,
				33: p
			}),
			e(m, [2, 34]),
			e(m, [2, 36]),
			e(m, [2, 37]),
			e(m, [2, 38]),
			e(m, [2, 39]),
			e(m, [2, 40]),
			e(m, [2, 35])
		],
		defaultActions: { 6: [2, 1] },
		parseError: /* @__PURE__ */ g(function(e, t) {
			if (t.recoverable) this.trace(e);
			else {
				var n = Error(e);
				throw n.hash = t, n;
			}
		}, "parseError"),
		parse: /* @__PURE__ */ g(function(e) {
			var t = this, n = [0], r = [], i = [null], a = [], o = this.table, s = "", c = 0, l = 0, u = 2, d = 1, f = a.slice.call(arguments, 1), p = Object.create(this.lexer), m = { yy: {} };
			for (var h in this.yy) Object.prototype.hasOwnProperty.call(this.yy, h) && (m.yy[h] = this.yy[h]);
			p.setInput(e, m.yy), m.yy.lexer = p, m.yy.parser = this, typeof p.yylloc > "u" && (p.yylloc = {});
			var _ = p.yylloc;
			a.push(_);
			var v = p.options && p.options.ranges;
			this.parseError = typeof m.yy.parseError == "function" ? m.yy.parseError : Object.getPrototypeOf(this).parseError;
			function y(e) {
				n.length -= 2 * e, i.length -= e, a.length -= e;
			}
			g(y, "popStack");
			function b() {
				var e;
				return e = r.pop() || p.lex() || d, typeof e != "number" && (e instanceof Array && (r = e, e = r.pop()), e = t.symbols_[e] || e), e;
			}
			g(b, "lex");
			for (var x, S, C, w, T = {}, E, D, O, k;;) {
				if (S = n[n.length - 1], this.defaultActions[S] ? C = this.defaultActions[S] : ((x === null || typeof x > "u") && (x = b()), C = o[S] && o[S][x]), typeof C > "u" || !C.length || !C[0]) {
					var A = "";
					for (E in k = [], o[S]) this.terminals_[E] && E > u && k.push("'" + this.terminals_[E] + "'");
					A = p.showPosition ? "Parse error on line " + (c + 1) + ":\n" + p.showPosition() + "\nExpecting " + k.join(", ") + ", got '" + (this.terminals_[x] || x) + "'" : "Parse error on line " + (c + 1) + ": Unexpected " + (x == d ? "end of input" : "'" + (this.terminals_[x] || x) + "'"), this.parseError(A, {
						text: p.match,
						token: this.terminals_[x] || x,
						line: p.yylineno,
						loc: _,
						expected: k
					});
				}
				if (C[0] instanceof Array && C.length > 1) throw Error("Parse Error: multiple actions possible at state: " + S + ", token: " + x);
				switch (C[0]) {
					case 1:
						n.push(x), i.push(p.yytext), a.push(p.yylloc), n.push(C[1]), x = null, l = p.yyleng, s = p.yytext, c = p.yylineno, _ = p.yylloc;
						break;
					case 2:
						if (D = this.productions_[C[1]][1], T.$ = i[i.length - D], T._$ = {
							first_line: a[a.length - (D || 1)].first_line,
							last_line: a[a.length - 1].last_line,
							first_column: a[a.length - (D || 1)].first_column,
							last_column: a[a.length - 1].last_column
						}, v && (T._$.range = [a[a.length - (D || 1)].range[0], a[a.length - 1].range[1]]), w = this.performAction.apply(T, [
							s,
							l,
							c,
							m.yy,
							C[1],
							i,
							a
						].concat(f)), typeof w < "u") return w;
						D && (n = n.slice(0, -1 * D * 2), i = i.slice(0, -1 * D), a = a.slice(0, -1 * D)), n.push(this.productions_[C[1]][0]), i.push(T.$), a.push(T._$), O = o[n[n.length - 2]][n[n.length - 1]], n.push(O);
						break;
					case 3: return !0;
				}
			}
			return !0;
		}, "parse")
	};
	h.lexer = /* @__PURE__ */ function() {
		return {
			EOF: 1,
			parseError: /* @__PURE__ */ g(function(e, t) {
				if (this.yy.parser) this.yy.parser.parseError(e, t);
				else throw Error(e);
			}, "parseError"),
			setInput: /* @__PURE__ */ g(function(e, t) {
				return this.yy = t || this.yy || {}, this._input = e, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
					first_line: 1,
					first_column: 0,
					last_line: 1,
					last_column: 0
				}, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
			}, "setInput"),
			input: /* @__PURE__ */ g(function() {
				var e = this._input[0];
				return this.yytext += e, this.yyleng++, this.offset++, this.match += e, this.matched += e, e.match(/(?:\r\n?|\n).*/g) ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), e;
			}, "input"),
			unput: /* @__PURE__ */ g(function(e) {
				var t = e.length, n = e.split(/(?:\r\n?|\n)/g);
				this._input = e + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - t), this.offset -= t;
				var r = this.match.split(/(?:\r\n?|\n)/g);
				this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), n.length - 1 && (this.yylineno -= n.length - 1);
				var i = this.yylloc.range;
				return this.yylloc = {
					first_line: this.yylloc.first_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.first_column,
					last_column: n ? (n.length === r.length ? this.yylloc.first_column : 0) + r[r.length - n.length].length - n[0].length : this.yylloc.first_column - t
				}, this.options.ranges && (this.yylloc.range = [i[0], i[0] + this.yyleng - t]), this.yyleng = this.yytext.length, this;
			}, "unput"),
			more: /* @__PURE__ */ g(function() {
				return this._more = !0, this;
			}, "more"),
			reject: /* @__PURE__ */ g(function() {
				if (this.options.backtrack_lexer) this._backtrack = !0;
				else return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
				return this;
			}, "reject"),
			less: /* @__PURE__ */ g(function(e) {
				this.unput(this.match.slice(e));
			}, "less"),
			pastInput: /* @__PURE__ */ g(function() {
				var e = this.matched.substr(0, this.matched.length - this.match.length);
				return (e.length > 20 ? "..." : "") + e.substr(-20).replace(/\n/g, "");
			}, "pastInput"),
			upcomingInput: /* @__PURE__ */ g(function() {
				var e = this.match;
				return e.length < 20 && (e += this._input.substr(0, 20 - e.length)), (e.substr(0, 20) + (e.length > 20 ? "..." : "")).replace(/\n/g, "");
			}, "upcomingInput"),
			showPosition: /* @__PURE__ */ g(function() {
				var e = this.pastInput(), t = Array(e.length + 1).join("-");
				return e + this.upcomingInput() + "\n" + t + "^";
			}, "showPosition"),
			test_match: /* @__PURE__ */ g(function(e, t) {
				var n, r, i;
				if (this.options.backtrack_lexer && (i = {
					yylineno: this.yylineno,
					yylloc: {
						first_line: this.yylloc.first_line,
						last_line: this.last_line,
						first_column: this.yylloc.first_column,
						last_column: this.yylloc.last_column
					},
					yytext: this.yytext,
					match: this.match,
					matches: this.matches,
					matched: this.matched,
					yyleng: this.yyleng,
					offset: this.offset,
					_more: this._more,
					_input: this._input,
					yy: this.yy,
					conditionStack: this.conditionStack.slice(0),
					done: this.done
				}, this.options.ranges && (i.yylloc.range = this.yylloc.range.slice(0))), r = e[0].match(/(?:\r\n?|\n).*/g), r && (this.yylineno += r.length), this.yylloc = {
					first_line: this.yylloc.last_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.last_column,
					last_column: r ? r[r.length - 1].length - r[r.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + e[0].length
				}, this.yytext += e[0], this.match += e[0], this.matches = e, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(e[0].length), this.matched += e[0], n = this.performAction.call(this, this.yy, this, t, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), n) return n;
				if (this._backtrack) {
					for (var a in i) this[a] = i[a];
					return !1;
				}
				return !1;
			}, "test_match"),
			next: /* @__PURE__ */ g(function() {
				if (this.done) return this.EOF;
				this._input || (this.done = !0);
				var e, t, n, r;
				this._more || (this.yytext = "", this.match = "");
				for (var i = this._currentRules(), a = 0; a < i.length; a++) if (n = this._input.match(this.rules[i[a]]), n && (!t || n[0].length > t[0].length)) {
					if (t = n, r = a, this.options.backtrack_lexer) {
						if (e = this.test_match(n, i[a]), e !== !1) return e;
						if (this._backtrack) {
							t = !1;
							continue;
						}
						return !1;
					}
					if (!this.options.flex) break;
				}
				return t ? (e = this.test_match(t, i[r]), e !== !1 && e) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
			}, "next"),
			lex: /* @__PURE__ */ g(function() {
				return this.next() || this.lex();
			}, "lex"),
			begin: /* @__PURE__ */ g(function(e) {
				this.conditionStack.push(e);
			}, "begin"),
			popState: /* @__PURE__ */ g(function() {
				return this.conditionStack.length - 1 > 0 ? this.conditionStack.pop() : this.conditionStack[0];
			}, "popState"),
			_currentRules: /* @__PURE__ */ g(function() {
				return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
			}, "_currentRules"),
			topState: /* @__PURE__ */ g(function(e) {
				return e = this.conditionStack.length - 1 - Math.abs(e || 0), e >= 0 ? this.conditionStack[e] : "INITIAL";
			}, "topState"),
			pushState: /* @__PURE__ */ g(function(e) {
				this.begin(e);
			}, "pushState"),
			stateStackSize: /* @__PURE__ */ g(function() {
				return this.conditionStack.length;
			}, "stateStackSize"),
			options: { "case-insensitive": !0 },
			performAction: /* @__PURE__ */ g(function(e, t, n, r) {
				switch (n) {
					case 0: break;
					case 1: break;
					case 2: break;
					case 3:
						if (e.getIndentMode && e.getIndentMode()) return e.consumeIndentText = !0, this.begin("INITIAL"), 22;
						break;
					case 4: break;
					case 5:
						e.setIndentMode && e.setIndentMode(!1), this.begin("INITIAL"), this.unput(t.yytext);
						break;
					case 6: return this.begin("bol"), 8;
					case 7: break;
					case 8: break;
					case 9: return 7;
					case 10: return 11;
					case 11: return 5;
					case 12: return 12;
					case 13: return 17;
					case 14:
						if (e.consumeIndentText) e.consumeIndentText = !1;
						else return 19;
						break;
					case 15: return 24;
					case 16: return t.yytext = t.yytext.slice(2, -2), 14;
					case 17: return t.yytext = t.yytext.slice(1, -1).trim(), 14;
					case 18: return 16;
					case 19: return 31;
					case 20: return 33;
					case 21: return 32;
					case 22: return 20;
					case 23: return 21;
					case 24: return 27;
					case 25: return 15;
				}
			}, "anonymous"),
			rules: [
				/^(?:%%(?!\{)[^\n]*)/i,
				/^(?:[^\}]%%[^\n]*)/i,
				/^(?:[ \t]+(?=[\n\r]))/i,
				/^(?:[ \t]+(?=text\b))/i,
				/^(?:[ \t]+)/i,
				/^(?:[^ \t\n\r])/i,
				/^(?:[\n\r]+)/i,
				/^(?:%%[^\n]*)/i,
				/^(?:[ \t]+)/i,
				/^(?:$)/i,
				/^(?:title\s[^#\n;]+)/i,
				/^(?:venn-beta\b)/i,
				/^(?:set\b)/i,
				/^(?:union\b)/i,
				/^(?:text\b)/i,
				/^(?:style\b)/i,
				/^(?:\["[^\"]*"\])/i,
				/^(?:\[[^\]\"]+\])/i,
				/^(?:[+-]?(\d+(\.\d+)?|\.\d+))/i,
				/^(?:#[0-9a-fA-F]{3,8})/i,
				/^(?:rgba\(\s*[0-9.]+\s*[,]\s*[0-9.]+\s*[,]\s*[0-9.]+\s*[,]\s*[0-9.]+\s*\))/i,
				/^(?:rgb\(\s*[0-9.]+\s*[,]\s*[0-9.]+\s*[,]\s*[0-9.]+\s*\))/i,
				/^(?:[A-Za-z_][A-Za-z0-9\-_]*)/i,
				/^(?:"[^\"]*")/i,
				/^(?:,)/i,
				/^(?::)/i
			],
			conditions: {
				bol: {
					rules: [
						0,
						1,
						2,
						3,
						4,
						5,
						6,
						7,
						8,
						9,
						10,
						11,
						12,
						13,
						14,
						15,
						16,
						17,
						18,
						19,
						20,
						21,
						22,
						23,
						24,
						25
					],
					inclusive: !0
				},
				INITIAL: {
					rules: [
						0,
						1,
						6,
						7,
						8,
						9,
						10,
						11,
						12,
						13,
						14,
						15,
						16,
						17,
						18,
						19,
						20,
						21,
						22,
						23,
						24,
						25
					],
					inclusive: !0
				}
			}
		};
	}();
	function _() {
		this.yy = {};
	}
	return g(_, "Parser"), _.prototype = h, h.Parser = _, new _();
}();
W.parser = W;
var Te = W, G = [], K = [], q = [], J = /* @__PURE__ */ new Set(), Y, X = !1, Ee = /* @__PURE__ */ g((e, t, n) => {
	let r = Q(e).sort(), i = n ?? 10 / e.length ** 2;
	Y = r, r.length === 1 && J.add(r[0]), G.push({
		sets: r,
		size: i,
		label: t ? Z(t) : void 0
	});
}, "addSubsetData"), De = /* @__PURE__ */ g(() => G, "getSubsetData"), Z = /* @__PURE__ */ g((e) => {
	let t = e.trim();
	return t.length >= 2 && t.startsWith("\"") && t.endsWith("\"") ? t.slice(1, -1) : t;
}, "normalizeText"), Oe = /* @__PURE__ */ g((e) => e && Z(e), "normalizeStyleValue"), ke = /* @__PURE__ */ g((e, t, n) => {
	let r = Z(t);
	K.push({
		sets: Q(e).sort(),
		id: r,
		label: n ? Z(n) : void 0
	});
}, "addTextData"), Ae = /* @__PURE__ */ g((e, t) => {
	let n = Q(e).sort(), r = {};
	for (let [e, n] of t) r[e] = Oe(n) ?? n;
	q.push({
		targets: n,
		styles: r
	});
}, "addStyleData"), je = /* @__PURE__ */ g(() => q, "getStyleData"), Q = /* @__PURE__ */ g((e) => e.map((e) => Z(e)), "normalizeIdentifierList"), Me = /* @__PURE__ */ g((e) => {
	let t = Q(e).filter((e) => !J.has(e));
	if (t.length > 0) throw Error(`unknown set identifier: ${t.join(", ")}`);
}, "validateUnionIdentifiers"), Ne = /* @__PURE__ */ g(() => K, "getTextData"), Pe = /* @__PURE__ */ g(() => Y, "getCurrentSets"), Fe = /* @__PURE__ */ g(() => X, "getIndentMode"), Ie = /* @__PURE__ */ g((e) => {
	X = e;
}, "setIndentMode"), Le = a.venn;
function Re() {
	return t(Le, l().venn);
}
g(Re, "getConfig");
var ze = {
	getConfig: Re,
	clear: /* @__PURE__ */ g(() => {
		n(), G.length = 0, K.length = 0, q.length = 0, J.clear(), Y = void 0, X = !1;
	}, "customClear"),
	setAccTitle: h,
	getAccTitle: c,
	setDiagramTitle: f,
	getDiagramTitle: u,
	getAccDescription: s,
	setAccDescription: m,
	addSubsetData: Ee,
	getSubsetData: De,
	addTextData: ke,
	addStyleData: Ae,
	validateUnionIdentifiers: Me,
	getTextData: Ne,
	getStyleData: je,
	getCurrentSets: Pe,
	getIndentMode: Fe,
	setIndentMode: Ie
}, Be = /* @__PURE__ */ g((e) => `
  .venn-title {
    font-size: 32px;
    fill: ${e.vennTitleTextColor};
    font-family: ${e.fontFamily};
  }

  .venn-circle text {
    font-size: 48px;
    font-family: ${e.fontFamily};
  }

  .venn-intersection text {
    font-size: 48px;
    fill: ${e.vennSetTextColor};
    font-family: ${e.fontFamily};
  }

  .venn-text-node {
    font-family: ${e.fontFamily};
    color: ${e.vennSetTextColor};
  }
`, "getStyles");
function Ve(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = n.targets.join("|"), r = t.get(e);
		r ? Object.assign(r, n.styles) : t.set(e, { ...n.styles });
	}
	return t;
}
g(Ve, "buildStyleByKey");
var He = /* @__PURE__ */ g((t, n, a, s) => {
	let c = s.db, u = c.getConfig?.(), { themeVariables: f, look: m, handDrawnSeed: h } = l(), g = m === "handDrawn", _ = [
		f.venn1,
		f.venn2,
		f.venn3,
		f.venn4,
		f.venn5,
		f.venn6,
		f.venn7,
		f.venn8
	].filter(Boolean), b = c.getDiagramTitle?.(), x = c.getSubsetData(), S = c.getTextData(), C = Ve(c.getStyleData()), w = We(x), T = u?.width ?? 800, E = u?.height ?? 450, D = T / 1600, O = b ? 48 * D : 0, k = f.primaryTextColor ?? f.textColor, A = p(n);
	A.attr("viewBox", `0 0 ${T} ${E}`), b && A.append("text").text(b).attr("class", "venn-title").attr("font-size", `${32 * D}px`).attr("text-anchor", "middle").attr("dominant-baseline", "middle").attr("x", "50%").attr("y", 32 * D).style("fill", f.vennTitleTextColor || f.titleColor);
	let j = e(document.createElement("div")), M = he().width(T).height(E - O);
	j.datum(w).call(M);
	let N = g ? v.svg(j.select("svg").node()) : void 0, P = we(w, {
		width: T,
		height: E - O,
		padding: u?.padding ?? 15
	}), F = /* @__PURE__ */ new Map();
	for (let e of P) {
		let t = $([...e.data.sets].sort());
		F.set(t, e);
	}
	S.length > 0 && Ue(u, F, j, S, D, C);
	let I = o(f.background || "#f4f4f4");
	j.selectAll(".venn-circle").each(function(t, n) {
		let r = e(this), a = $([...t.sets].sort()), o = C.get(a), s = o?.fill || _[n % _.length] || f.primaryColor;
		r.classed(`venn-set-${n % 8}`, !0);
		let c = o?.["fill-opacity"] ?? .1, l = o?.stroke || s, u = o?.["stroke-width"] || `${5 * D}`;
		if (g && N) {
			let e = F.get(a);
			if (e && e.circles.length > 0) {
				let t = e.circles[0], i = N.circle(t.x, t.y, t.radius * 2, {
					roughness: .7,
					seed: h,
					fill: y(s, .7),
					fillStyle: "hachure",
					fillWeight: 2,
					hachureGap: 8,
					hachureAngle: -41 + n * 60,
					stroke: l,
					strokeWidth: parseFloat(String(u))
				});
				r.select("path").remove(), r.node()?.insertBefore(i, r.select("text").node());
			}
		} else r.select("path").style("fill", s).style("fill-opacity", c).style("stroke", l).style("stroke-width", u).style("stroke-opacity", .95);
		let p = o?.color || (I ? d(s, 30) : i(s, 30));
		r.select("text").style("font-size", `${48 * D}px`).style("fill", p);
	}), g && N ? j.selectAll(".venn-intersection").each(function(t) {
		let n = e(this), r = $([...t.sets].sort()), i = C.get(r), a = i?.fill;
		if (a) {
			let e = n.select("path"), t = e.attr("d");
			if (t) {
				let n = N.path(t, {
					roughness: .7,
					seed: h,
					fill: y(a, .3),
					fillStyle: "cross-hatch",
					fillWeight: 2,
					hachureGap: 6,
					hachureAngle: 60,
					stroke: "none"
				}), r = e.node();
				r?.parentNode?.insertBefore(n, r), e.remove();
			}
		} else n.select("path").style("fill-opacity", 0);
		n.select("text").style("font-size", `${48 * D}px`).style("fill", i?.color ?? f.vennSetTextColor ?? k);
	}) : (j.selectAll(".venn-intersection text").style("font-size", `${48 * D}px`).style("fill", (e) => {
		let t = $([...e.sets].sort());
		return C.get(t)?.color ?? f.vennSetTextColor ?? k;
	}), j.selectAll(".venn-intersection path").style("fill-opacity", (e) => {
		let t = $([...e.sets].sort());
		return +!!C.get(t)?.fill;
	}).style("fill", (e) => {
		let t = $([...e.sets].sort());
		return C.get(t)?.fill ?? "transparent";
	}));
	let L = A.append("g").attr("transform", `translate(0, ${O})`), R = j.select("svg").node();
	if (R && "childNodes" in R) for (let e of [...R.childNodes]) L.node()?.appendChild(e);
	r(A, E, T, u?.useMaxWidth ?? !0);
}, "draw");
function $(e) {
	return e.join("|");
}
g($, "stableSetsKey");
function Ue(e, t, n, r, i, a) {
	let o = e?.useDebugLayout ?? !1, s = n.select("svg").append("g").attr("class", "venn-text-nodes"), c = /* @__PURE__ */ new Map();
	for (let e of r) {
		let t = $(e.sets), n = c.get(t);
		n ? n.push(e) : c.set(t, [e]);
	}
	for (let [e, n] of c.entries()) {
		let r = t.get(e);
		if (!r?.text) continue;
		let c = r.text.x, l = r.text.y, u = Math.min(...r.circles.map((e) => e.radius)), d = Math.min(...r.circles.map((e) => e.radius - Math.hypot(c - e.x, l - e.y))), f = Number.isFinite(d) ? Math.max(0, d) : 0;
		f === 0 && Number.isFinite(u) && (f = u * .6);
		let p = s.append("g").attr("class", "venn-text-area").attr("font-size", `${40 * i}px`);
		o && p.append("circle").attr("class", "venn-text-debug-circle").attr("cx", c).attr("cy", l).attr("r", f).attr("fill", "none").attr("stroke", "purple").attr("stroke-width", 1.5 * i).attr("stroke-dasharray", `${6 * i} ${4 * i}`);
		let m = Math.max(80 * i, f * 2 * .95), h = Math.max(60 * i, f * 2 * .95), g = (r.data.label && r.data.label.length > 0 ? Math.min(32 * i, f * .25) : 0) + (n.length <= 2 ? 30 * i : 0), _ = c - m / 2, v = l - h / 2 + g, y = Math.max(1, Math.ceil(Math.sqrt(n.length))), b = Math.max(1, Math.ceil(n.length / y)), x = m / y, S = h / b;
		for (let [e, t] of n.entries()) {
			let n = e % y, r = Math.floor(e / y), s = _ + x * (n + .5), c = v + S * (r + .5);
			o && p.append("rect").attr("class", "venn-text-debug-cell").attr("x", _ + x * n).attr("y", v + S * r).attr("width", x).attr("height", S).attr("fill", "none").attr("stroke", "teal").attr("stroke-width", 1 * i).attr("stroke-dasharray", `${4 * i} ${3 * i}`);
			let l = x * .9, u = S * .9, d = p.append("foreignObject").attr("class", "venn-text-node-fo").attr("width", l).attr("height", u).attr("x", s - l / 2).attr("y", c - u / 2).attr("overflow", "visible"), f = a.get(t.id)?.color, m = d.append("xhtml:span").attr("class", "venn-text-node").style("display", "flex").style("width", "100%").style("height", "100%").style("white-space", "normal").style("align-items", "center").style("justify-content", "center").style("text-align", "center").style("overflow-wrap", "normal").style("word-break", "normal").text(t.label ?? t.id);
			f && m.style("color", f);
		}
	}
}
g(Ue, "renderTextNodes");
function We(e) {
	let t = new Set(e.map((e) => [...e.sets].sort().join("|"))), n = new Map(e.filter((e) => e.sets.length === 1 && e.size !== void 0).map((e) => [e.sets[0], e.size])), r = [];
	for (let i of e) {
		if (i.sets.length < 3) continue;
		let e = [...i.sets].sort();
		for (let i = 0; i < e.length - 1; i++) for (let a = i + 1; a < e.length; a++) {
			let o = [e[i], e[a]], s = o.join("|");
			if (!t.has(s)) {
				t.add(s);
				let e = n.get(o[0]), i = n.get(o[1]), a = e !== void 0 && i !== void 0 ? Math.min(e, i) / 4 : 2.5;
				r.push({
					sets: o,
					size: a,
					label: ""
				});
			}
		}
	}
	return r.length > 0 ? [...e, ...r] : e;
}
g(We, "ensurePairwiseSubsets");
var Ge = {
	parser: Te,
	db: ze,
	renderer: { draw: He },
	styles: Be
};
//#endregion
export { Ge as diagram };

//# sourceMappingURL=vennDiagram-4TSXK5OY-BrNTogjM-MQcZKGgC.js.map