import { M as e, N as t, T as n, ai as r, aj as i, al as a, am as o, an as s, av as c, b6 as l, bB as u, bx as d, by as f, bz as p, c as m } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
import { t as h } from "./chunk-JWPE2WC7-BuMGiM24-C4YAbtTB.js";
import { i as g } from "./cynefin-OW5HDTMX--IlWkCwH-DhMvmN4k.js";
//#region ../react/build/wardleyDiagram-VM6X3IG4-B2PZkUwG.js
var _ = /* @__PURE__ */ m((e, t) => {
	let n = e <= 1 ? e * 100 : e;
	if (n < 0 || n > 100) throw Error(`${t} must be between 0-1 (decimal) or 0-100 (percentage). Received: ${e}`);
	return n;
}, "toPercent"), v = /* @__PURE__ */ m((e, t, n) => ({
	x: _(t, `${n} evolution`),
	y: _(e, `${n} visibility`)
}), "toCoordinates"), y = /* @__PURE__ */ m((e) => {
	if (e) {
		if (e === "+<>") return "bidirectional";
		if (e === "+<") return "backward";
		if (e === "+>") return "forward";
	}
}, "getFlowFromPort"), b = /* @__PURE__ */ m((e) => {
	if (!e?.startsWith("+")) return {};
	let t = /^\+'([^']*)'/.exec(e)?.[1];
	return e.includes("<>") ? {
		flow: "bidirectional",
		label: t
	} : e.includes("<") ? {
		flow: "backward",
		label: t
	} : e.includes(">") ? {
		flow: "forward",
		label: t
	} : { label: t };
}, "extractFlowFromArrow"), x = /* @__PURE__ */ m((e, t) => {
	if (h(e, t), e.size && t.setSize(e.size.width, e.size.height), e.evolution) {
		let n = e.evolution.stages.map((e) => e.secondName ? `${e.name.trim()} / ${e.secondName.trim()}` : e.name.trim()), r = e.evolution.stages.filter((e) => e.boundary !== void 0).map((e) => e.boundary);
		t.updateAxes({
			stages: n,
			stageBoundaries: r
		});
	}
	if (e.anchors.forEach((e) => {
		let n = v(e.visibility, e.evolution, `Anchor "${e.name}"`);
		t.addNode(e.name, e.name, n.x, n.y, "anchor");
	}), e.components.forEach((e) => {
		let n = v(e.visibility, e.evolution, `Component "${e.name}"`), r = e.label ? (e.label.negX ? -1 : 1) * e.label.offsetX : void 0, i = e.label ? (e.label.negY ? -1 : 1) * e.label.offsetY : void 0, a = e.decorator?.strategy;
		t.addNode(e.name, e.name, n.x, n.y, "component", r, i, e.inertia, a);
	}), e.notes.forEach((e) => {
		let n = v(e.visibility, e.evolution, `Note "${e.text}"`);
		t.addNote(e.text, n.x, n.y);
	}), e.pipelines.forEach((e) => {
		let n = t.getNode(e.parent);
		if (!n || typeof n.y != "number") throw Error(`Pipeline "${e.parent}" must reference an existing component with coordinates.`);
		let r = n.y;
		t.startPipeline(e.parent), e.components.forEach((n) => {
			let i = `${e.parent}_${n.name}`, a = n.label ? (n.label.negX ? -1 : 1) * n.label.offsetX : void 0, o = n.label ? (n.label.negY ? -1 : 1) * n.label.offsetY : void 0, s = _(n.evolution, `Pipeline component "${n.name}" evolution`);
			t.addNode(i, n.name, s, r, "pipeline-component", a, o), t.addPipelineComponent(e.parent, i);
		});
	}), e.links.forEach((e) => {
		let n = !!e.arrow && (e.arrow.includes("-.->") || e.arrow.includes(".-.")), r = y(e.fromPort) ?? y(e.toPort), { flow: i, label: a } = b(e.arrow);
		!r && i && (r = i);
		let o = e.linkLabel, s = a ?? o;
		t.addLink(t.resolveNodeId(e.from), t.resolveNodeId(e.to), n, s, r);
	}), e.evolves.forEach((e) => {
		let n = t.getNode(e.component);
		if (n?.y !== void 0) {
			let r = _(e.target, `Evolve target for "${e.component}"`);
			t.addTrend(e.component, r, n.y);
		}
	}), e.annotations.length > 0) {
		let n = e.annotations[0], r = v(n.x, n.y, "Annotations box");
		t.setAnnotationsBox(r.x, r.y);
	}
	e.annotation.forEach((e) => {
		let n = v(e.x, e.y, `Annotation ${e.number}`);
		t.addAnnotation(e.number, [{
			x: n.x,
			y: n.y
		}], e.text);
	}), e.accelerators.forEach((e) => {
		let n = v(e.x, e.y, `Accelerator "${e.name}"`);
		t.addAccelerator(e.name, n.x, n.y);
	}), e.deaccelerators.forEach((e) => {
		let n = v(e.x, e.y, `Deaccelerator "${e.name}"`);
		t.addDeaccelerator(e.name, n.x, n.y);
	});
}, "populateDb"), S = {
	parser: { yy: void 0 },
	parse: /* @__PURE__ */ m(async (e) => {
		let t = await g("wardley", e);
		l.debug(t);
		let n = S.parser?.yy;
		if (!n || typeof n.addNode != "function") throw Error("parser.parser?.yy was not a WardleyDB. This is due to a bug within Mermaid, please report this issue at https://github.com/mermaid-js/mermaid/issues.");
		x(t, n);
	}, "parse")
}, C, w = new (C = class {
	constructor() {
		this.nodes = /* @__PURE__ */ new Map(), this.links = [], this.trends = /* @__PURE__ */ new Map(), this.pipelines = /* @__PURE__ */ new Map(), this.annotations = [], this.notes = [], this.accelerators = [], this.deaccelerators = [], this.axes = {};
	}
	addNode(e) {
		let t = this.nodes.get(e.id) ?? {
			id: e.id,
			label: e.label
		}, n = {
			...t,
			...e,
			className: e.className ?? t.className,
			labelOffsetX: e.labelOffsetX ?? t.labelOffsetX,
			labelOffsetY: e.labelOffsetY ?? t.labelOffsetY
		};
		this.nodes.set(e.id, n);
	}
	addLink(e) {
		this.links.push(e);
	}
	addTrend(e) {
		this.trends.set(e.nodeId, e);
	}
	startPipeline(e) {
		this.pipelines.set(e, {
			nodeId: e,
			componentIds: []
		});
		let t = this.nodes.get(e);
		t && (t.isPipelineParent = !0);
	}
	addPipelineComponent(e, t) {
		let n = this.pipelines.get(e);
		n && n.componentIds.push(t);
		let r = this.nodes.get(t);
		r && (r.inPipeline = !0);
	}
	addAnnotation(e) {
		this.annotations.push(e);
	}
	addNote(e) {
		this.notes.push(e);
	}
	addAccelerator(e) {
		this.accelerators.push(e);
	}
	addDeaccelerator(e) {
		this.deaccelerators.push(e);
	}
	setAnnotationsBox(e, t) {
		this.annotationsBox = {
			x: e,
			y: t
		};
	}
	setAxes(e) {
		this.axes = {
			...this.axes,
			...e
		};
	}
	setSize(e, t) {
		this.size = {
			width: e,
			height: t
		};
	}
	getNode(e) {
		return this.nodes.get(e);
	}
	resolveNodeId(e) {
		if (this.nodes.has(e)) return e;
		for (let [t, n] of this.nodes) if (n.label === e) return t;
		return e;
	}
	build() {
		let e = [];
		for (let t of this.nodes.values()) {
			if (typeof t.x != "number" || typeof t.y != "number") throw Error(`Node "${t.label}" is missing coordinates`);
			e.push(t);
		}
		return {
			nodes: e,
			links: [...this.links],
			trends: [...this.trends.values()],
			pipelines: [...this.pipelines.values()],
			annotations: [...this.annotations],
			notes: [...this.notes],
			accelerators: [...this.accelerators],
			deaccelerators: [...this.deaccelerators],
			annotationsBox: this.annotationsBox,
			axes: { ...this.axes },
			size: this.size
		};
	}
	clear() {
		this.nodes.clear(), this.links = [], this.trends.clear(), this.pipelines.clear(), this.annotations = [], this.notes = [], this.accelerators = [], this.deaccelerators = [], this.annotationsBox = void 0, this.axes = {}, this.size = void 0;
	}
}, m(C, "WardleyBuilder"), C)();
function T() {
	return o()["wardley-beta"];
}
m(T, "getConfig");
function E(e, t, n, r, i, a, o, s, c) {
	w.addNode({
		id: e,
		label: t,
		x: n,
		y: r,
		className: i,
		labelOffsetX: a,
		labelOffsetY: o,
		inertia: s,
		sourceStrategy: c
	});
}
m(E, "addNode");
function D(e, t, n = !1, r, i) {
	w.addLink({
		source: e,
		target: t,
		dashed: n,
		label: r,
		flow: i
	});
}
m(D, "addLink");
function O(e, t, n) {
	w.addTrend({
		nodeId: e,
		targetX: t,
		targetY: n
	});
}
m(O, "addTrend");
function k(e, t, n) {
	w.addAnnotation({
		number: e,
		coordinates: t,
		text: n
	});
}
m(k, "addAnnotation");
function A(e, t, n) {
	w.addNote({
		text: e,
		x: t,
		y: n
	});
}
m(A, "addNote");
function j(e, t, n) {
	w.addAccelerator({
		name: e,
		x: t,
		y: n
	});
}
m(j, "addAccelerator");
function M(e, t, n) {
	w.addDeaccelerator({
		name: e,
		x: t,
		y: n
	});
}
m(M, "addDeaccelerator");
function N(e, t) {
	w.setAnnotationsBox(e, t);
}
m(N, "setAnnotationsBox");
function P(e, t) {
	w.setSize(e, t);
}
m(P, "setSize");
function F(e) {
	w.startPipeline(e);
}
m(F, "startPipeline");
function I(e, t) {
	w.addPipelineComponent(e, t);
}
m(I, "addPipelineComponent");
function L(e) {
	w.setAxes(e);
}
m(L, "updateAxes");
function R(e) {
	return w.getNode(e);
}
m(R, "getNode");
function z(e) {
	return w.resolveNodeId(e);
}
m(z, "resolveNodeId");
function B() {
	return w.build();
}
m(B, "getWardleyData");
function V() {
	w.clear(), t();
}
m(V, "clear");
var H = {
	getConfig: T,
	addNode: E,
	addLink: D,
	addTrend: O,
	addAnnotation: k,
	addNote: A,
	addAccelerator: j,
	addDeaccelerator: M,
	setAnnotationsBox: N,
	setSize: P,
	startPipeline: F,
	addPipelineComponent: I,
	updateAxes: L,
	getNode: R,
	resolveNodeId: z,
	getWardleyData: B,
	clear: V,
	setAccTitle: p,
	getAccTitle: i,
	setDiagramTitle: u,
	getDiagramTitle: s,
	getAccDescription: r,
	setAccDescription: f
}, U = [
	"Genesis",
	"Custom Built",
	"Product",
	"Commodity"
], W = /* @__PURE__ */ m(() => {
	let { themeVariables: e } = o();
	return {
		backgroundColor: e.wardley?.backgroundColor ?? e.background ?? "#fff",
		axisColor: e.wardley?.axisColor ?? "#000",
		axisTextColor: e.wardley?.axisTextColor ?? e.primaryTextColor ?? "#222",
		gridColor: e.wardley?.gridColor ?? "rgba(100, 100, 100, 0.2)",
		componentFill: e.wardley?.componentFill ?? "#fff",
		componentStroke: e.wardley?.componentStroke ?? "#000",
		componentLabelColor: e.wardley?.componentLabelColor ?? e.primaryTextColor ?? "#222",
		linkStroke: e.wardley?.linkStroke ?? "#000",
		evolutionStroke: e.wardley?.evolutionStroke ?? "#dc3545",
		annotationStroke: e.wardley?.annotationStroke ?? "#000",
		annotationTextColor: e.wardley?.annotationTextColor ?? e.primaryTextColor ?? "#222",
		annotationFill: e.wardley?.annotationFill ?? e.background ?? "#fff"
	};
}, "getTheme"), G = /* @__PURE__ */ m(() => {
	let e = o()["wardley-beta"];
	return {
		width: e?.width ?? 900,
		height: e?.height ?? 600,
		padding: e?.padding ?? 48,
		nodeRadius: e?.nodeRadius ?? 6,
		nodeLabelOffset: e?.nodeLabelOffset ?? 8,
		axisFontSize: e?.axisFontSize ?? 12,
		labelFontSize: e?.labelFontSize ?? 10,
		showGrid: e?.showGrid ?? !1,
		useMaxWidth: e?.useMaxWidth ?? !0
	};
}, "getConfigValues"), K = {
	parser: S,
	db: H,
	renderer: { draw: /* @__PURE__ */ m((e, t, r, i) => {
		l.debug("Rendering Wardley map\n" + e);
		let a = G(), o = W(), s = a.nodeRadius * 1.6, c = i.db, u = c.getWardleyData(), f = c.getDiagramTitle(), p = u.size?.width ?? a.width, h = u.size?.height ?? a.height, g = d(t);
		g.selectAll("*").remove(), n(g, h, p, a.useMaxWidth), g.attr("viewBox", `0 0 ${p} ${h}`);
		let _ = g.append("g").attr("class", "wardley-map"), v = g.append("defs");
		v.append("marker").attr("id", `arrow-${t}`).attr("viewBox", "0 0 10 10").attr("refX", 9).attr("refY", 5).attr("markerWidth", 6).attr("markerHeight", 6).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("fill", o.evolutionStroke).attr("stroke", "none"), v.append("marker").attr("id", `link-arrow-end-${t}`).attr("viewBox", "0 0 10 10").attr("refX", 9).attr("refY", 5).attr("markerWidth", 5).attr("markerHeight", 5).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("fill", o.linkStroke).attr("stroke", "none"), v.append("marker").attr("id", `link-arrow-start-${t}`).attr("viewBox", "0 0 10 10").attr("refX", 1).attr("refY", 5).attr("markerWidth", 5).attr("markerHeight", 5).attr("orient", "auto").append("path").attr("d", "M 10 0 L 0 5 L 10 10 z").attr("fill", o.linkStroke).attr("stroke", "none"), _.append("rect").attr("class", "wardley-background").attr("width", p).attr("height", h).attr("fill", o.backgroundColor);
		let y = p - a.padding * 2, b = h - a.padding * 2;
		f && _.append("text").attr("class", "wardley-title").attr("x", p / 2).attr("y", a.padding / 2).attr("fill", o.axisTextColor).attr("font-size", a.axisFontSize * 1.05).attr("font-weight", "bold").attr("text-anchor", "middle").attr("dominant-baseline", "middle").text(f);
		let x = /* @__PURE__ */ m((e) => a.padding + e / 100 * y, "projectX"), S = /* @__PURE__ */ m((e) => h - a.padding - e / 100 * b, "projectY"), C = _.append("g").attr("class", "wardley-axes");
		C.append("line").attr("x1", a.padding).attr("x2", p - a.padding).attr("y1", h - a.padding).attr("y2", h - a.padding).attr("stroke", o.axisColor).attr("stroke-width", 1), C.append("line").attr("x1", a.padding).attr("x2", a.padding).attr("y1", a.padding).attr("y2", h - a.padding).attr("stroke", o.axisColor).attr("stroke-width", 1);
		let w = u.axes.xLabel ?? "Evolution", T = u.axes.yLabel ?? "Visibility";
		C.append("text").attr("class", "wardley-axis-label wardley-axis-label-x").attr("x", a.padding + y / 2).attr("y", h - a.padding / 4).attr("fill", o.axisTextColor).attr("font-size", a.axisFontSize).attr("font-weight", "bold").attr("text-anchor", "middle").text(w), C.append("text").attr("class", "wardley-axis-label wardley-axis-label-y").attr("x", a.padding / 3).attr("y", a.padding + b / 2).attr("fill", o.axisTextColor).attr("font-size", a.axisFontSize).attr("font-weight", "bold").attr("text-anchor", "middle").attr("transform", `rotate(-90 ${a.padding / 3} ${a.padding + b / 2})`).text(T);
		let E = u.axes.stages && u.axes.stages.length > 0 ? u.axes.stages : U;
		if (E.length > 0) {
			let e = _.append("g").attr("class", "wardley-stages"), t = u.axes.stageBoundaries, n = [];
			if (t && t.length === E.length) {
				let e = 0;
				t.forEach((t) => {
					n.push({
						start: e,
						end: t
					}), e = t;
				});
			} else {
				let e = 1 / E.length;
				E.forEach((t, r) => {
					n.push({
						start: r * e,
						end: (r + 1) * e
					});
				});
			}
			E.forEach((t, r) => {
				let i = n[r], s = a.padding + i.start * y, c = (s + (a.padding + i.end * y)) / 2;
				r > 0 && e.append("line").attr("x1", s).attr("x2", s).attr("y1", a.padding).attr("y2", h - a.padding).attr("stroke", "#000").attr("stroke-width", 1).attr("stroke-dasharray", "5 5").attr("opacity", .8), e.append("text").attr("class", "wardley-stage-label").attr("x", c).attr("y", h - a.padding / 1.5).attr("fill", o.axisTextColor).attr("font-size", a.axisFontSize - 2).attr("text-anchor", "middle").text(t);
			});
		}
		if (a.showGrid) {
			let e = _.append("g").attr("class", "wardley-grid");
			for (let t = 1; t < 4; t++) {
				let n = t / 4, r = a.padding + y * n;
				e.append("line").attr("x1", r).attr("x2", r).attr("y1", a.padding).attr("y2", h - a.padding).attr("stroke", o.gridColor).attr("stroke-dasharray", "2 6"), e.append("line").attr("x1", a.padding).attr("x2", p - a.padding).attr("y1", h - a.padding - b * n).attr("y2", h - a.padding - b * n).attr("stroke", o.gridColor).attr("stroke-dasharray", "2 6");
			}
		}
		let D = /* @__PURE__ */ new Map();
		if (u.nodes.forEach((e) => {
			D.set(e.id, {
				x: x(e.x),
				y: S(e.y),
				node: e
			});
		}), u.pipelines.length > 0) {
			let e = _.append("g").attr("class", "wardley-pipelines"), t = _.append("g").attr("class", "wardley-pipeline-links");
			u.pipelines.forEach((n) => {
				if (n.componentIds.length === 0) return;
				let r = n.componentIds.map((e) => ({
					id: e,
					pos: D.get(e),
					node: u.nodes.find((t) => t.id === e)
				})).filter((e) => e.pos && e.node).sort((e, t) => e.node.x - t.node.x);
				for (let e = 0; e < r.length - 1; e++) {
					let n = r[e], i = r[e + 1];
					t.append("line").attr("class", "wardley-pipeline-evolution-link").attr("x1", n.pos.x).attr("y1", n.pos.y).attr("x2", i.pos.x).attr("y2", i.pos.y).attr("stroke", o.linkStroke).attr("stroke-width", 1).attr("stroke-dasharray", "4 4");
				}
				let i = 1 / 0, c = -1 / 0, l = 0;
				if (n.componentIds.forEach((e) => {
					let t = D.get(e);
					t && (i = Math.min(i, t.x), c = Math.max(c, t.x), l = t.y);
				}), i !== 1 / 0 && c !== -1 / 0) {
					let t = a.nodeRadius * 4, r = l - t / 2, u = D.get(n.nodeId);
					u && (u.x = (i + c) / 2, u.y = r - s / 6), e.append("rect").attr("class", "wardley-pipeline-box").attr("x", i - 15).attr("y", r).attr("width", c - i + 30).attr("height", t).attr("fill", "none").attr("stroke", o.axisColor).attr("stroke-width", 1.5).attr("rx", 4).attr("ry", 4);
				}
			});
		}
		let O = _.append("g").attr("class", "wardley-links"), k = /* @__PURE__ */ new Map();
		u.pipelines.forEach((e) => {
			k.set(e.nodeId, new Set(e.componentIds));
		});
		let A = u.links.filter((e) => !(!D.has(e.source) || !D.has(e.target) || k.get(e.target)?.has(e.source)));
		O.selectAll("line").data(A).enter().append("line").attr("class", (e) => `wardley-link${e.dashed ? " wardley-link--dashed" : ""}`).attr("x1", (e) => {
			let t = D.get(e.source), n = D.get(e.target), r = u.nodes.find((t) => t.id === e.source).isPipelineParent ? s / Math.sqrt(2) : a.nodeRadius, i = n.x - t.x, o = n.y - t.y, c = Math.sqrt(i * i + o * o);
			return t.x + i / c * r;
		}).attr("y1", (e) => {
			let t = D.get(e.source), n = D.get(e.target), r = u.nodes.find((t) => t.id === e.source).isPipelineParent ? s / Math.sqrt(2) : a.nodeRadius, i = n.x - t.x, o = n.y - t.y, c = Math.sqrt(i * i + o * o);
			return t.y + o / c * r;
		}).attr("x2", (e) => {
			let t = D.get(e.source), n = D.get(e.target), r = u.nodes.find((t) => t.id === e.target).isPipelineParent ? s / Math.sqrt(2) : a.nodeRadius, i = t.x - n.x, o = t.y - n.y, c = Math.sqrt(i * i + o * o);
			return n.x + i / c * r;
		}).attr("y2", (e) => {
			let t = D.get(e.source), n = D.get(e.target), r = u.nodes.find((t) => t.id === e.target).isPipelineParent ? s / Math.sqrt(2) : a.nodeRadius, i = t.x - n.x, o = t.y - n.y, c = Math.sqrt(i * i + o * o);
			return n.y + o / c * r;
		}).attr("stroke", o.linkStroke).attr("stroke-width", 1).attr("stroke-dasharray", (e) => e.dashed ? "6 6" : null).attr("marker-end", (e) => e.flow === "forward" || e.flow === "bidirectional" ? `url(#link-arrow-end-${t})` : null).attr("marker-start", (e) => e.flow === "backward" || e.flow === "bidirectional" ? `url(#link-arrow-start-${t})` : null), O.selectAll("text").data(A.filter((e) => e.label)).enter().append("text").attr("class", "wardley-link-label").attr("x", (e) => {
			let t = D.get(e.source), n = D.get(e.target), r = (t.x + n.x) / 2, i = n.y - t.y, a = n.x - t.x;
			return r + i / Math.sqrt(a * a + i * i) * 8;
		}).attr("y", (e) => {
			let t = D.get(e.source), n = D.get(e.target), r = (t.y + n.y) / 2, i = n.x - t.x, a = n.y - t.y, o = Math.sqrt(i * i + a * a);
			return r + -i / o * 8;
		}).attr("fill", o.axisTextColor).attr("font-size", a.labelFontSize).attr("text-anchor", "middle").attr("dominant-baseline", "middle").attr("transform", (e) => {
			let t = D.get(e.source), n = D.get(e.target), r = (t.x + n.x) / 2, i = (t.y + n.y) / 2, a = n.x - t.x, o = n.y - t.y, s = Math.sqrt(a * a + o * o), c = o / s, l = -a / s, u = r + c * 8, d = i + l * 8, f = Math.atan2(o, a) * 180 / Math.PI;
			return (f > 90 || f < -90) && (f += 180), `rotate(${f} ${u} ${d})`;
		}).text((e) => e.label);
		let j = _.append("g").attr("class", "wardley-trends"), M = u.trends.map((e) => {
			let t = D.get(e.nodeId);
			if (!t) return null;
			let n = x(e.targetX), r = S(e.targetY), i = n - t.x, o = r - t.y, s = Math.sqrt(i * i + o * o), c = a.nodeRadius + 2;
			return {
				origin: t,
				targetX: n,
				targetY: r,
				adjustedX2: s > c ? n - i / s * c : n,
				adjustedY2: s > c ? r - o / s * c : r
			};
		}).filter((e) => e !== null);
		j.selectAll("line").data(M).enter().append("line").attr("class", "wardley-trend").attr("x1", (e) => e.origin.x).attr("y1", (e) => e.origin.y).attr("x2", (e) => e.adjustedX2).attr("y2", (e) => e.adjustedY2).attr("stroke", o.evolutionStroke).attr("stroke-width", 1).attr("stroke-dasharray", "4 4").attr("marker-end", `url(#arrow-${t})`);
		let N = _.append("g").attr("class", "wardley-nodes").selectAll("g").data(u.nodes).enter().append("g").attr("class", (e) => ["wardley-node", e.className ? `wardley-node--${e.className}` : ""].filter(Boolean).join(" "));
		N.filter((e) => e.sourceStrategy === "outsource").append("circle").attr("class", "wardley-outsource-overlay").attr("cx", (e) => D.get(e.id).x).attr("cy", (e) => D.get(e.id).y).attr("r", a.nodeRadius * 2).attr("fill", "#666").attr("stroke", o.componentStroke).attr("stroke-width", 1), N.filter((e) => e.sourceStrategy === "buy").append("circle").attr("class", "wardley-buy-overlay").attr("cx", (e) => D.get(e.id).x).attr("cy", (e) => D.get(e.id).y).attr("r", a.nodeRadius * 2).attr("fill", "#ccc").attr("stroke", o.componentStroke).attr("stroke-width", 1), N.filter((e) => e.sourceStrategy === "build").append("circle").attr("class", "wardley-build-overlay").attr("cx", (e) => D.get(e.id).x).attr("cy", (e) => D.get(e.id).y).attr("r", a.nodeRadius * 2).attr("fill", "#eee").attr("stroke", "#000").attr("stroke-width", 1);
		let P = N.filter((e) => e.sourceStrategy === "market");
		P.append("circle").attr("class", "wardley-market-overlay").attr("cx", (e) => D.get(e.id).x).attr("cy", (e) => D.get(e.id).y).attr("r", a.nodeRadius * 2).attr("fill", "white").attr("stroke", o.componentStroke).attr("stroke-width", 1), N.filter((e) => !e.isPipelineParent && e.sourceStrategy !== "market" && e.className !== "anchor").append("circle").attr("cx", (e) => D.get(e.id).x).attr("cy", (e) => D.get(e.id).y).attr("r", a.nodeRadius).attr("fill", o.componentFill).attr("stroke", o.componentStroke).attr("stroke-width", 1);
		let F = a.nodeRadius * .7, I = a.nodeRadius * 1.2;
		if (P.append("line").attr("class", "wardley-market-line").attr("x1", (e) => D.get(e.id).x).attr("y1", (e) => D.get(e.id).y - I).attr("x2", (e) => D.get(e.id).x - I * Math.cos(Math.PI / 6)).attr("y2", (e) => D.get(e.id).y + I * Math.sin(Math.PI / 6)).attr("stroke", o.componentStroke).attr("stroke-width", 1), P.append("line").attr("class", "wardley-market-line").attr("x1", (e) => D.get(e.id).x - I * Math.cos(Math.PI / 6)).attr("y1", (e) => D.get(e.id).y + I * Math.sin(Math.PI / 6)).attr("x2", (e) => D.get(e.id).x + I * Math.cos(Math.PI / 6)).attr("y2", (e) => D.get(e.id).y + I * Math.sin(Math.PI / 6)).attr("stroke", o.componentStroke).attr("stroke-width", 1), P.append("line").attr("class", "wardley-market-line").attr("x1", (e) => D.get(e.id).x + I * Math.cos(Math.PI / 6)).attr("y1", (e) => D.get(e.id).y + I * Math.sin(Math.PI / 6)).attr("x2", (e) => D.get(e.id).x).attr("y2", (e) => D.get(e.id).y - I).attr("stroke", o.componentStroke).attr("stroke-width", 1), P.append("circle").attr("class", "wardley-market-dot").attr("cx", (e) => D.get(e.id).x).attr("cy", (e) => D.get(e.id).y - I).attr("r", F).attr("fill", "white").attr("stroke", o.componentStroke).attr("stroke-width", 2), P.append("circle").attr("class", "wardley-market-dot").attr("cx", (e) => D.get(e.id).x - I * Math.cos(Math.PI / 6)).attr("cy", (e) => D.get(e.id).y + I * Math.sin(Math.PI / 6)).attr("r", F).attr("fill", "white").attr("stroke", o.componentStroke).attr("stroke-width", 2), P.append("circle").attr("class", "wardley-market-dot").attr("cx", (e) => D.get(e.id).x + I * Math.cos(Math.PI / 6)).attr("cy", (e) => D.get(e.id).y + I * Math.sin(Math.PI / 6)).attr("r", F).attr("fill", "white").attr("stroke", o.componentStroke).attr("stroke-width", 2), N.filter((e) => e.isPipelineParent === !0).append("rect").attr("x", (e) => D.get(e.id).x - s / 2).attr("y", (e) => D.get(e.id).y - s / 2).attr("width", s).attr("height", s).attr("fill", o.componentFill).attr("stroke", o.componentStroke).attr("stroke-width", 1), N.filter((e) => e.inertia === !0).append("line").attr("class", "wardley-inertia").attr("x1", (e) => {
			let t = D.get(e.id), n = e.isPipelineParent ? s / 2 + 15 : a.nodeRadius + 15;
			return e.sourceStrategy && (n += a.nodeRadius + 10), t.x + n;
		}).attr("y1", (e) => {
			let t = D.get(e.id), n = e.isPipelineParent ? s : a.nodeRadius * 2;
			return t.y - n / 2;
		}).attr("x2", (e) => {
			let t = D.get(e.id), n = e.isPipelineParent ? s / 2 + 15 : a.nodeRadius + 15;
			return e.sourceStrategy && (n += a.nodeRadius + 10), t.x + n;
		}).attr("y2", (e) => {
			let t = D.get(e.id), n = e.isPipelineParent ? s : a.nodeRadius * 2;
			return t.y + n / 2;
		}).attr("stroke", o.componentStroke).attr("stroke-width", 6), N.append("text").attr("x", (e) => {
			let t = D.get(e.id);
			if (e.className === "anchor") return e.labelOffsetX === void 0 ? t.x : t.x + e.labelOffsetX;
			let n = a.nodeLabelOffset;
			e.sourceStrategy && e.labelOffsetX === void 0 && (n += 10);
			let r = e.labelOffsetX ?? n;
			return t.x + r;
		}).attr("y", (e) => {
			let t = D.get(e.id);
			if (e.className === "anchor") return e.labelOffsetY === void 0 ? t.y - 3 : t.y + e.labelOffsetY;
			let n = -a.nodeLabelOffset;
			e.sourceStrategy && e.labelOffsetY === void 0 && (n -= 10);
			let r = e.labelOffsetY ?? n;
			return t.y + r;
		}).attr("class", "wardley-node-label").attr("fill", (e) => e.className === "evolved" ? o.evolutionStroke : e.className === "anchor" ? "#000" : o.componentLabelColor).attr("font-size", a.labelFontSize).attr("font-weight", (e) => e.className === "anchor" ? "bold" : "normal").attr("text-anchor", (e) => e.className === "anchor" ? "middle" : "start").attr("dominant-baseline", (e) => e.className === "anchor" ? "middle" : "auto").text((e) => e.label), u.annotations.length > 0) {
			let e = _.append("g").attr("class", "wardley-annotations");
			if (u.annotations.forEach((t) => {
				let n = t.coordinates.map((e) => ({
					x: x(e.x),
					y: S(e.y)
				}));
				if (n.length > 1) for (let t = 0; t < n.length - 1; t++) e.append("line").attr("class", "wardley-annotation-line").attr("x1", n[t].x).attr("y1", n[t].y).attr("x2", n[t + 1].x).attr("y2", n[t + 1].y).attr("stroke", o.axisColor).attr("stroke-width", 1.5).attr("stroke-dasharray", "4 4");
				n.forEach((n) => {
					let r = e.append("g").attr("class", "wardley-annotation");
					r.append("circle").attr("cx", n.x).attr("cy", n.y).attr("r", 10).attr("fill", "white").attr("stroke", o.axisColor).attr("stroke-width", 1.5), r.append("text").attr("x", n.x).attr("y", n.y).attr("text-anchor", "middle").attr("dominant-baseline", "central").attr("font-size", 10).attr("fill", o.axisTextColor).attr("font-weight", "bold").text(t.number);
				});
			}), u.annotationsBox) {
				let t = x(u.annotationsBox.x), n = S(u.annotationsBox.y), r = e.append("g").attr("class", "wardley-annotations-box"), i = [...u.annotations].filter((e) => e.text).sort((e, t) => e.number - t.number), s = [];
				if (i.forEach((e, i) => {
					let a = r.append("text").attr("x", t + 10).attr("y", n + 10 + (i + 1) * 16).attr("font-size", 11).attr("fill", o.axisTextColor).attr("text-anchor", "start").attr("dominant-baseline", "middle").text(`${e.number}. ${e.text}`);
					s.push(a);
				}), s.length > 0) {
					let e = 0, c = 0;
					s.forEach((t) => {
						let n = t.node(), r = n.getComputedTextLength();
						e = Math.max(e, r);
						let i = n.getBBox();
						c = Math.max(c, i.height);
					});
					let l = e + 20 + 105, u = i.length * 16 + 20 + c / 2, d = a.padding, f = p - a.padding - l, m = a.padding, g = h - a.padding - u;
					t = Math.max(d, Math.min(t, f)), n = Math.max(m, Math.min(n, g)), s.forEach((e, r) => {
						e.attr("x", t + 10).attr("y", n + 10 + (r + 1) * 16);
					}), r.insert("rect", "text").attr("x", t).attr("y", n).attr("width", l).attr("height", u).attr("fill", "white").attr("stroke", o.axisColor).attr("stroke-width", 1.5).attr("rx", 4).attr("ry", 4);
				}
			}
		}
		if (u.notes.length > 0) {
			let e = _.append("g").attr("class", "wardley-notes");
			u.notes.forEach((t) => {
				let n = x(t.x), r = S(t.y);
				e.append("text").attr("x", n).attr("y", r).attr("text-anchor", "start").attr("font-size", 11).attr("fill", o.axisTextColor).attr("font-weight", "bold").text(t.text);
			});
		}
		if (u.accelerators.length > 0) {
			let e = _.append("g").attr("class", "wardley-accelerators");
			u.accelerators.forEach((t) => {
				let n = x(t.x), r = S(t.y), i = `
        M ${n} ${r - 15}
        L ${n + 60 - 20} ${r - 15}
        L ${n + 60 - 20} ${r - 15 - 8}
        L ${n + 60} ${r}
        L ${n + 60 - 20} ${r + 15 + 8}
        L ${n + 60 - 20} ${r + 15}
        L ${n} ${r + 15}
        Z
      `;
				e.append("path").attr("d", i).attr("fill", "white").attr("stroke", o.componentStroke).attr("stroke-width", 1), e.append("text").attr("x", n + 30).attr("y", r + 15 + 15).attr("text-anchor", "middle").attr("font-size", 10).attr("fill", o.axisTextColor).attr("font-weight", "bold").text(t.name);
			});
		}
		if (u.deaccelerators.length > 0) {
			let e = _.append("g").attr("class", "wardley-deaccelerators");
			u.deaccelerators.forEach((t) => {
				let n = x(t.x), r = S(t.y), i = `
        M ${n + 60} ${r - 15}
        L ${n + 20} ${r - 15}
        L ${n + 20} ${r - 15 - 8}
        L ${n} ${r}
        L ${n + 20} ${r + 15 + 8}
        L ${n + 20} ${r + 15}
        L ${n + 60} ${r + 15}
        Z
      `;
				e.append("path").attr("d", i).attr("fill", "white").attr("stroke", o.componentStroke).attr("stroke-width", 1), e.append("text").attr("x", n + 30).attr("y", r + 15 + 15).attr("text-anchor", "middle").attr("font-size", 10).attr("fill", o.axisTextColor).attr("font-weight", "bold").text(t.name);
			});
		}
	}, "draw") },
	styles: /* @__PURE__ */ m(({ wardley: t } = {}) => {
		let n = c(), r = a(), i = e(n, r.themeVariables), o = e(i.wardley, t);
		return `
  .wardley-background {
    fill: ${o.backgroundColor};
  }
  .wardley-axes line, .wardley-axes path {
    stroke: ${o.axisColor};
  }
  .wardley-axis-label {
    fill: ${o.axisTextColor};
  }
  .wardley-stage-label {
    fill: ${o.axisTextColor};
  }
  .wardley-grid line {
    stroke: ${o.gridColor};
  }
  .wardley-node circle {
    fill: ${o.componentFill};
    stroke: ${o.componentStroke};
  }
  .wardley-node-label {
    fill: ${o.componentLabelColor};
  }
  .wardley-link {
    stroke: ${o.linkStroke};
  }
  .wardley-link--dashed {
    stroke-dasharray: 4 4;
  }
  .wardley-link-label {
    fill: ${o.axisTextColor};
  }
  .wardley-trend line {
    stroke: ${o.evolutionStroke};
  }
  .wardley-annotation-line {
    stroke: ${o.annotationStroke};
  }
  .wardley-annotation circle {
    fill: ${o.annotationFill};
    stroke: ${o.annotationStroke};
  }
  .wardley-annotation text {
    fill: ${o.annotationTextColor};
  }
  .wardley-annotations-box rect {
    fill: ${o.annotationFill};
    stroke: ${o.annotationStroke};
  }
  .wardley-annotations-box text {
    fill: ${o.annotationTextColor};
  }
  .wardley-pipeline-box {
    stroke: ${o.componentStroke};
  }
  .wardley-notes text {
    fill: ${o.axisTextColor};
  }
  `;
	}, "styles")
};
//#endregion
export { K as diagram };

//# sourceMappingURL=wardleyDiagram-VM6X3IG4-B2PZkUwG-DYKwXw56.js.map