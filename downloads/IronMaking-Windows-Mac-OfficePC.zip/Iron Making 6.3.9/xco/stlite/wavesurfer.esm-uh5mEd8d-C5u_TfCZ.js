//#region ../react/build/wavesurfer.esm-uh5mEd8d.js
function e(e, t, n, r) {
	return new (n ||= Promise)(function(i, a) {
		function o(e) {
			try {
				c(r.next(e));
			} catch (e) {
				a(e);
			}
		}
		function s(e) {
			try {
				c(r.throw(e));
			} catch (e) {
				a(e);
			}
		}
		function c(e) {
			var t;
			e.done ? i(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
				e(t);
			})).then(o, s);
		}
		c((r = r.apply(e, t || [])).next());
	});
}
var t = class {
	constructor() {
		this.listeners = {};
	}
	on(e, t, n) {
		if (this.listeners[e] || (this.listeners[e] = /* @__PURE__ */ new Set()), n?.once) {
			let n = (...r) => {
				this.un(e, n), t(...r);
			};
			return this.listeners[e].add(n), () => this.un(e, n);
		}
		return this.listeners[e].add(t), () => this.un(e, t);
	}
	un(e, t) {
		var n;
		(n = this.listeners[e]) == null || n.delete(t);
	}
	once(e, t) {
		return this.on(e, t, { once: !0 });
	}
	unAll() {
		this.listeners = {};
	}
	emit(e, ...t) {
		this.listeners[e] && this.listeners[e].forEach((e) => e(...t));
	}
}, n = class e {
	constructor() {
		this.disposers = [], this.children = /* @__PURE__ */ new Set(), this.parent = null, this._disposed = !1, this.abortController = null;
	}
	get disposed() {
		return this._disposed;
	}
	add(e) {
		return this._disposed ? (this.safeRun(e), () => {}) : (this.disposers.push(e), () => {
			let t = this.disposers.indexOf(e);
			t !== -1 && (this.disposers.splice(t, 1), this.safeRun(e));
		});
	}
	child() {
		let t = new e();
		return this._disposed ? (t.dispose(), t) : (t.parent = this, this.children.add(t), t);
	}
	listen(e, t, n, r) {
		return e.addEventListener(t, n, r), this.add(() => e.removeEventListener(t, n, r));
	}
	timeout(e, t) {
		let n = setTimeout(() => {
			r(), e();
		}, t), r = this.add(() => clearTimeout(n));
		return r;
	}
	interval(e, t) {
		let n = setInterval(e, t);
		return this.add(() => clearInterval(n));
	}
	raf(e) {
		let t = requestAnimationFrame((t) => {
			n(), e(t);
		}), n = this.add(() => cancelAnimationFrame(t));
		return n;
	}
	observeResize(e, t) {
		e.observe(t), this.add(() => e.unobserve(t));
	}
	createResizeObserver(e, t) {
		let n = new ResizeObserver(t);
		return n.observe(e), this.add(() => n.disconnect()), n;
	}
	abortSignal() {
		return this.abortController || (this.abortController = new AbortController(), this._disposed && this.abortController.abort()), this.abortController.signal;
	}
	dispose() {
		var e;
		if (this._disposed) return;
		this._disposed = !0, this.parent &&= (this.parent.children.delete(this), null);
		for (let e of [...this.children]) e.dispose();
		this.children.clear();
		let t = this.disposers;
		this.disposers = [];
		for (let e = t.length - 1; e >= 0; e--) this.safeRun(t[e]);
		(e = this.abortController) == null || e.abort();
	}
	safeRun(e) {
		try {
			e();
		} catch (e) {
			console.error("Scope disposer error:", e);
		}
	}
}, r = class extends t {
	get destroyed() {
		return this.isDestroyed;
	}
	constructor(e) {
		super(), this.subscriptions = [], this.scope = new n(), this.isDestroyed = !1, this.options = e;
	}
	onInit() {}
	_init(e) {
		this.isDestroyed = !1, this.wavesurfer = e, this.onInit();
	}
	destroy() {
		this.isDestroyed || (this.isDestroyed = !0, this.emit("destroy"), this.subscriptions.forEach((e) => e()), this.subscriptions = [], this.unAll(), this.scope.dispose(), this.wavesurfer = void 0);
	}
}, i = {
	decode: function(t, n) {
		return e(this, void 0, void 0, function* () {
			let e = new AudioContext({ sampleRate: n });
			try {
				return yield e.decodeAudioData(t);
			} finally {
				e.state !== "closed" && (yield e.close().catch(() => {}));
			}
		});
	},
	createBuffer: function(e, t) {
		if (!e || e.length === 0) throw Error("channelData must be a non-empty array");
		if (t <= 0) throw Error("duration must be greater than 0");
		if (typeof e[0] == "number" && (e = [e]), !e[0] || e[0].length === 0) throw Error("channelData must contain non-empty channel arrays");
		let n = function(e) {
			let t = 0;
			for (let n of e) for (let e = 0; e < n.length; e++) {
				let r = Math.abs(n[e]);
				r > t && (t = r);
			}
			return t <= 1 ? e : e.map((e) => {
				let n = new Float32Array(e.length);
				for (let r = 0; r < e.length; r++) n[r] = e[r] / t;
				return n;
			});
		}(e).map((e) => e instanceof Float32Array ? e : Float32Array.from(e)), r = (e) => {
			let t = n[e];
			if (!t) throw Error(`Channel ${e} not found`);
			return t;
		};
		return {
			duration: t,
			length: n[0].length,
			sampleRate: n[0].length / t,
			numberOfChannels: n.length,
			getChannelData: r,
			copyFromChannel: (e, t, n = 0) => {
				let i = r(t), a = Math.max(0, n), o = Math.max(0, Math.min(e.length, i.length - a));
				e.set(i.subarray(a, a + o));
			},
			copyToChannel: (e, t, n = 0) => {
				let i = r(t), a = Math.max(0, n), o = Math.max(0, Math.min(e.length, i.length - a));
				i.set(e.subarray(0, o), a);
			}
		};
	}
}, a = /* @__PURE__ */ new Set([
	"destroy",
	"_init",
	"onInit",
	"emit",
	"on",
	"un",
	"once",
	"unAll",
	"options",
	"wavesurfer",
	"subscriptions",
	"scope",
	"destroyed",
	"isDestroyed",
	"listeners"
]);
function o(e, t) {
	let n = t.xmlns ? document.createElementNS(t.xmlns, e) : document.createElement(e);
	for (let [e, r] of Object.entries(t)) if (e === "children" && r) for (let [e, t] of Object.entries(r)) t instanceof Node ? n.appendChild(t) : typeof t == "string" ? n.appendChild(document.createTextNode(t)) : n.appendChild(o(e, t));
	else e === "style" ? Object.assign(n.style, r) : e === "textContent" ? n.textContent = r : n.setAttribute(e, r.toString());
	return n;
}
function s(e, t, n) {
	let r = o(e, t || {});
	return n?.appendChild(r), r;
}
function c(e) {
	if (e instanceof HTMLElement) return !0;
	if (typeof e != "object" || !e) return !1;
	let t = e;
	return t.nodeType === Node.ELEMENT_NODE && typeof t.nodeName == "string" && t.namespaceURI === "http://www.w3.org/1999/xhtml" && typeof t.style == "object" && t.style !== null && typeof t.appendChild == "function";
}
var l = Object.freeze({
	__proto__: null,
	createElement: s,
	default: s,
	isHTMLElement: c
}), u = { fetchBlob: function(t, n, r) {
	return e(this, void 0, void 0, function* () {
		let i = yield fetch(t, r);
		if (i.status >= 400) throw Error(`Failed to fetch ${t}: ${i.status} (${i.statusText})`);
		return function(t, n, r) {
			e(this, void 0, void 0, function* () {
				if (!t.body || !t.headers) return;
				let e = t.body.getReader(), i = Number(t.headers.get("Content-Length")) || 0, a = 0, o = () => {
					e.cancel();
				};
				if (r) {
					if (r.aborted) return void e.cancel();
					r.addEventListener("abort", o, { once: !0 });
				}
				try {
					for (;;) {
						let t = yield e.read();
						if (t.done) break;
						a += t.value?.length || 0, i > 0 && n(Math.round(a / i * 100));
					}
				} catch (e) {
					if (e instanceof DOMException && e.name === "AbortError") return;
					console.warn("Progress tracking error:", e);
				} finally {
					r && r.removeEventListener("abort", o);
				}
			});
		}(i.clone(), n, r?.signal ?? void 0), i.blob();
	});
} }, d = class {
	constructor(e) {
		this.frameId = null, this.callback = null, this.isRunning = !1, e.add(() => this.stop());
	}
	get running() {
		return this.isRunning;
	}
	start(e) {
		if (this.callback = e, this.isRunning) return;
		this.isRunning = !0;
		let t = () => {
			var e;
			this.isRunning && (this.frameId = requestAnimationFrame(t), (e = this.callback) == null || e.call(this));
		};
		t();
	}
	stop() {
		this.isRunning = !1, this.frameId !== null && (cancelAnimationFrame(this.frameId), this.frameId = null);
	}
}, f = null;
function p(e) {
	let t = e, n = /* @__PURE__ */ new Set(), r = !1, i = !1, a = {
		get value() {
			return f?.add(a), t;
		},
		set(e) {
			Object.is(t, e) || (t = e, (() => {
				if (r) i = !0;
				else {
					r = !0;
					try {
						do {
							i = !1;
							let e = [...n], r = t;
							for (let n of e) {
								try {
									n(r);
								} catch (e) {
									console.error("Signal subscriber error:", e);
								}
								if (!Object.is(t, r)) {
									i = !0;
									break;
								}
							}
						} while (i);
					} finally {
						r = !1;
					}
				}
			})());
		},
		update(e) {
			this.set(e(t));
		},
		subscribe: (e) => (n.add(e), () => n.delete(e))
	};
	return a;
}
function m(e) {
	let t = f, n = /* @__PURE__ */ new Set();
	f = n;
	try {
		return [e(), n];
	} finally {
		f = t;
	}
}
function h(e, t) {
	let n = p(void 0), r = [], i = !1, a = /* @__PURE__ */ new Set(), o = () => {
		if (!i) {
			if (t) n.set(e());
			else {
				r.forEach((e) => e());
				let [t, i] = m(e);
				r = [...i].map((e) => e.subscribe(o)), n.set(t);
			}
		}
	};
	t ? (r = t.map((e) => e.subscribe(o)), n.set(e())) : o();
	let s = () => {
		i = !0, r.forEach((e) => e()), r = [], a.forEach((e) => e()), a.clear();
	}, c = {
		get value() {
			return f?.add(c), n.value;
		},
		subscribe: (e) => {
			let t = n.subscribe(e);
			return a.add(t), () => {
				a.delete(t), t();
			};
		},
		dispose: s
	};
	return Object.defineProperty(c, "_cleanup", {
		value: s,
		enumerable: !1
	}), Object.defineProperty(c, "_subscriberCount", {
		value: () => a.size,
		enumerable: !1
	}), c;
}
function g(e, t) {
	let n, r = [], i = !1, a = () => {
		if (!i) {
			if (n) {
				try {
					n();
				} catch (e) {
					console.error("Effect cleanup error:", e);
				}
				n = void 0;
			}
			if (t) n = e();
			else {
				r.forEach((e) => e());
				let [t, i] = m(e);
				r = [...i].map((e) => e.subscribe(a)), n = t;
			}
		}
	};
	return t && (r = t.map((e) => e.subscribe(a))), a(), () => {
		if (i = !0, n) {
			try {
				n();
			} catch (e) {
				console.error("Effect cleanup error:", e);
			}
			n = void 0;
		}
		r.forEach((e) => e()), r = [];
	};
}
var _ = class {
	get isPlayingSignal() {
		return this._isPlaying;
	}
	get currentTimeSignal() {
		return this._currentTime;
	}
	get durationSignal() {
		return this._duration;
	}
	get volumeSignal() {
		return this._volume;
	}
	get mutedSignal() {
		return this._muted;
	}
	get playbackRateSignal() {
		return this._playbackRate;
	}
	get seekingSignal() {
		return this._seeking;
	}
	constructor(e) {
		this.isExternalMedia = !1, this._ownBlobUrl = null, this.pendingTime = null, this.mediaScope = new n(), e.media ? (this.media = e.media, this.isExternalMedia = !0) : this.media = document.createElement("audio"), this._isPlaying = p(!1), this._currentTime = p(0), this._duration = p(0), this._volume = p(this.media.volume), this._muted = p(this.media.muted), this._playbackRate = p(this.media.playbackRate || 1), this._seeking = p(!1), this.setupReactiveMediaEvents(), e.mediaControls && (this.media.controls = !0), e.autoplay && (this.media.autoplay = !0), e.playbackRate != null && this.mediaScope.add(this.onMediaEvent("canplay", () => {
			e.playbackRate != null && (this.media.playbackRate = e.playbackRate);
		}, { once: !0 }));
	}
	setupReactiveMediaEvents() {
		this.mediaScope.add(this.onMediaEvent("play", () => {
			this._isPlaying.set(!0);
		})), this.mediaScope.add(this.onMediaEvent("pause", () => {
			this._isPlaying.set(!1);
		})), this.mediaScope.add(this.onMediaEvent("ended", () => {
			this._isPlaying.set(!1);
		})), this.mediaScope.add(this.onMediaEvent("timeupdate", () => {
			this._currentTime.set(this.media.currentTime);
		})), this.mediaScope.add(this.onMediaEvent("durationchange", () => {
			this._duration.set(this.media.duration || 0);
		})), this.mediaScope.add(this.onMediaEvent("loadedmetadata", () => {
			this._duration.set(this.media.duration || 0);
		})), this.mediaScope.add(this.onMediaEvent("canplay", () => this.applyPendingTime())), this.mediaScope.add(this.onMediaEvent("seeking", () => {
			this.pendingTime != null && Math.abs(this.media.currentTime - this.pendingTime) > .01 && (this.pendingTime = null), this._seeking.set(!0);
		})), this.mediaScope.add(this.onMediaEvent("seeked", () => {
			this._seeking.set(!1);
		})), this.mediaScope.add(this.onMediaEvent("volumechange", () => {
			this._volume.set(this.media.volume), this._muted.set(this.media.muted);
		})), this.mediaScope.add(this.onMediaEvent("ratechange", () => {
			this._playbackRate.set(this.media.playbackRate);
		}));
	}
	onMediaEvent(e, t, n) {
		return this.media.addEventListener(e, t, n), () => this.media.removeEventListener(e, t, n);
	}
	getSrc() {
		return this.media.currentSrc || this.media.src || "";
	}
	revokeSrc() {
		this._ownBlobUrl &&= (URL.revokeObjectURL(this._ownBlobUrl), null);
	}
	canPlayType(e) {
		return this.media.canPlayType(e) !== "";
	}
	applyPendingTime() {
		if (this.pendingTime == null) return;
		let e = this.pendingTime;
		this.media.currentTime = e, this.pendingTime = null;
	}
	setSrc(e, t) {
		let n = this.getSrc();
		if (e && n === e) return;
		this.revokeSrc();
		let r = t instanceof Blob && (this.canPlayType(t.type) || !e) ? URL.createObjectURL(t) : e;
		if (this.pendingTime = null, r !== e && (this._ownBlobUrl = r), n && this.media.removeAttribute("src"), r || e) try {
			this.media.src = r;
		} catch {
			this.media.src = e;
		}
	}
	destroy() {
		this.pendingTime = null, this.mediaScope.dispose(), this.revokeSrc(), this.isExternalMedia || (this.media.pause(), this.media.removeAttribute("src"), this.media.load(), this.media.remove());
	}
	setMediaElement(e) {
		this.pendingTime = null, this.mediaScope.dispose(), this.mediaScope = new n(), this.media = e, this.setupReactiveMediaEvents();
	}
	play() {
		return e(this, void 0, void 0, function* () {
			try {
				this.media.readyState >= 3 && this.applyPendingTime();
				let e = yield this.media.play();
				return this.applyPendingTime(), e;
			} catch (e) {
				if (e instanceof DOMException && e.name === "AbortError") return;
				throw e;
			}
		});
	}
	pause() {
		this.media.pause();
	}
	isPlaying() {
		return !this.media.paused && !this.media.ended;
	}
	setTime(e) {
		let t = this.getDuration(), n = Number.isFinite(t) ? Math.max(0, Math.min(e, t)) : Math.max(0, e);
		this.media.readyState < 3 ? this.pendingTime = n : (this.pendingTime = null, this.media.currentTime = n);
	}
	getDuration() {
		return this.media.duration;
	}
	getCurrentTime() {
		return this.pendingTime ?? this.media.currentTime;
	}
	getVolume() {
		return this.media.volume;
	}
	setVolume(e) {
		this.media.volume = e;
	}
	getMuted() {
		return this.media.muted;
	}
	setMuted(e) {
		this.media.muted = e;
	}
	getPlaybackRate() {
		return this.media.playbackRate;
	}
	isSeeking() {
		return this.media.seeking;
	}
	setPlaybackRate(e, t) {
		t != null && (this.media.preservesPitch = t), this.media.playbackRate = e;
	}
	getMediaElement() {
		return this.media;
	}
	setSinkId(e) {
		return this.media.setSinkId(e);
	}
};
function v(e, t) {
	let n = e.barWidth ? e.barWidth * t : 1;
	return {
		barWidth: n,
		barGap: e.barGap ? e.barGap * t : e.barWidth ? n / 2 : 0
	};
}
function y({ maxTop: e, maxBottom: t, halfHeight: n, vScale: r, barMinHeight: i = 0, barAlign: a }) {
	let o = Math.round(e * n * r), s = o + Math.round(t * n * r) || 1;
	return s < i && (s = i, a || (o = s / 2)), {
		topHeight: o,
		totalHeight: s
	};
}
function b({ barAlign: e, halfHeight: t, topHeight: n, totalHeight: r, canvasHeight: i }) {
	return e === "top" ? 0 : e === "bottom" ? i - r : t - n;
}
function x(e, t, n) {
	return [e.width > 0 ? (t - e.left) / e.width : 0, e.height > 0 ? (n - e.top) / e.height : 0];
}
function S(e) {
	return !!(e.barWidth || e.barGap || e.barAlign);
}
var C = null;
function w(e, t) {
	if (!S(t)) return e;
	let { barWidth: n, barGap: r } = v(t, 1), i = n + r;
	return i === 0 ? e : Math.floor(e / i) * i;
}
function T({ totalWidth: e, clientWidth: t, options: n }) {
	let r = function({ clientWidth: e, totalWidth: t, options: n }) {
		return w(Math.min(8e3, e, t), n);
	}({
		clientWidth: t,
		totalWidth: e,
		options: n
	});
	if (r === 0) return {
		singleCanvasWidth: 0,
		numCanvases: 0,
		slots: []
	};
	let i = Math.ceil(e / r), a = [];
	for (let t = 0; t < i; t++) {
		let i = t * r, o = w(Math.min(e - i, r), n);
		o > 0 && a.push({
			index: t,
			offset: i,
			width: o
		});
	}
	return {
		singleCanvasWidth: r,
		numCanvases: i,
		slots: a
	};
}
function E({ scrollLeft: e, clientWidth: t, singleCanvasWidth: n, numCanvases: r }) {
	if (n <= 0 || r <= 0) return [0];
	let i = Math.min(r - 1, Math.floor(e / n)), a = Math.min(r - 1, Math.floor((e + t) / n)), o = [];
	for (let e = i - 1; e <= a + 1; e++) o.push(e);
	return o;
}
function D(e) {
	let t = 0;
	for (let n of e) for (let e = 0; e < n.length; e++) {
		let r = Math.abs(n[e] ?? 0);
		r > t && (t = r);
	}
	return t;
}
function O(e) {
	let t = () => ({
		scrollLeft: e.scrollLeft,
		scrollWidth: e.scrollWidth,
		clientWidth: e.clientWidth
	}), n = p(t()), r = h(() => function(e) {
		let { scrollLeft: t, scrollWidth: n, clientWidth: r } = e;
		if (n === 0) return {
			startX: 0,
			endX: 1
		};
		let i = t / n, a = (t + r) / n;
		return {
			startX: Math.max(0, Math.min(1, i)),
			endX: Math.max(0, Math.min(1, a))
		};
	}(n.value), [n]), i = h(() => function(e) {
		return {
			left: e.scrollLeft,
			right: e.scrollLeft + e.clientWidth
		};
	}(n.value), [n]), a = () => {
		n.set(t());
	};
	return e.addEventListener("scroll", a, { passive: !0 }), {
		scrollData: n,
		percentages: r,
		bounds: i,
		refresh: () => {
			let e = t(), r = n.value;
			r.scrollLeft === e.scrollLeft && r.scrollWidth === e.scrollWidth && r.clientWidth === e.clientWidth || n.set(e);
		},
		cleanup: () => {
			e.removeEventListener("scroll", a), r.dispose(), i.dispose();
		}
	};
}
var k = class {
	constructor(e, t) {
		this.isScrollable = p(!1), this.audioData = null, this.lastContainerWidth = 0, this.isDragging = !1, this.scope = new n(), this.scrollRenderScope = this.scope.child(), this.delayScope = this.scope.child(), this.dragScope = null, this.dragStream = null, this.scrollStream = null, this.containerInlinePadding = 0, this.audioDuration = p(0), this._clickSignal = p(null), this._dblclickSignal = p(null), this._dragEventsSignal = p(null), this._renderEpoch = p(0), this._renderedEpoch = p(0), this._resizeEpoch = p(0), this.onClickWrapper = (e) => {
			let [t, n] = x(this.wrapper.getBoundingClientRect(), e.clientX, e.clientY);
			this._clickSignal.set({
				relativeX: t,
				relativeY: n
			});
		}, this.onDblClickWrapper = (e) => {
			let [t, n] = x(this.wrapper.getBoundingClientRect(), e.clientX, e.clientY);
			this._dblclickSignal.set({
				relativeX: t,
				relativeY: n
			});
		}, this.options = e;
		let r = this.parentFromOptionsContainer(e.container);
		this.parent = r;
		let [i, a] = this.initHtml();
		r.appendChild(i), this.container = i, this.scrollContainer = a.querySelector(".scroll"), this.wrapper = a.querySelector(".wrapper"), this.canvasWrapper = a.querySelector(".canvases"), this.progressWrapper = a.querySelector(".progress"), this.cursor = a.querySelector(".cursor"), this.calculateInlinePadding(), t && a.appendChild(t), this.initEvents(), this.visibleRange = h(() => {
			let e = this.audioDuration.value;
			if (!this.isScrollable.value || e === 0 || !this.scrollStream) return {
				startTime: 0,
				endTime: e
			};
			let { startX: t, endX: n } = this.scrollStream.percentages.value;
			return {
				startTime: t * e,
				endTime: n * e
			};
		}), this.scope.add(() => this.visibleRange.dispose());
	}
	parentFromOptionsContainer(e) {
		let t;
		if (typeof e == "string" ? t = document.querySelector(e) : c(e) && (t = e), !t) throw Error("Container not found");
		return t;
	}
	initEvents() {
		if (this.scope.listen(this.wrapper, "click", this.onClickWrapper), this.scope.listen(this.wrapper, "dblclick", this.onDblClickWrapper), this.options.dragToSeek !== !0 && typeof this.options.dragToSeek != "object" || this.initDrag(), this.scrollStream = O(this.scrollContainer), this.scrollSignals = {
			percentages: this.scrollStream.percentages,
			bounds: this.scrollStream.bounds
		}, this.scope.add(() => {
			var e;
			(e = this.scrollStream) == null || e.cleanup(), this.scrollStream = null;
		}), typeof ResizeObserver == "function") {
			let e = this.createDelay(100);
			this.scope.createResizeObserver(this.scrollContainer, () => {
				e().then(() => this.onContainerResize()).catch(() => {});
			});
		}
	}
	onContainerResize() {
		var e;
		(e = this.scrollStream) == null || e.refresh();
		let t = this.parent.clientWidth;
		this.calculateInlinePadding(), t === this.lastContainerWidth && this.options.height !== "auto" || (this.lastContainerWidth = t, this.reRender(), this._resizeEpoch.update((e) => e + 1));
	}
	initDrag() {
		if (this.dragStream) return;
		let e = this.scope.child();
		this.dragScope = e, this.dragStream = function(e, t = {}) {
			let { threshold: n = 3, mouseButton: r = 0, touchDelay: i = 100 } = t, a = p(null), o = /* @__PURE__ */ new Map(), s = matchMedia("(pointer: coarse)").matches, c = () => {}, l = (t) => {
				if (t.button !== r || o.has(t.pointerId) || (o.set(t.pointerId, t), o.size > 1)) return;
				let l = t.pointerId, u = t.clientX, d = t.clientY, f = !1, p = Date.now(), { left: m, top: h } = e.getBoundingClientRect(), g = (e) => {
					if (e.pointerId !== l || e.defaultPrevented || o.size > 1 || s && Date.now() - p < i) return;
					let t = e.clientX, r = e.clientY, c = t - u, g = r - d;
					(f || Math.abs(c) > n || Math.abs(g) > n) && (e.preventDefault(), e.stopPropagation(), f ||= (a.set({
						type: "start",
						x: u - m,
						y: d - h
					}), !0), a.set({
						type: "move",
						x: t - m,
						y: r - h,
						deltaX: c,
						deltaY: g
					}), u = t, d = r);
				}, _ = (e) => {
					if (o.delete(e.pointerId)) {
						if (e.pointerId === l && f) {
							let t = e.clientX, n = e.clientY;
							a.set({
								type: "end",
								x: t - m,
								y: n - h
							});
						}
						o.size === 0 && c();
					}
				}, v = (e) => {
					f && (e.stopPropagation(), e.preventDefault());
				}, y = (e) => {
					e.defaultPrevented || o.size > 1 || f && e.preventDefault();
				};
				window.addEventListener("pointermove", g), window.addEventListener("pointerup", _), window.addEventListener("pointercancel", _), document.addEventListener("touchmove", y, { passive: !1 }), document.addEventListener("click", v, { capture: !0 }), c = () => {
					window.removeEventListener("pointermove", g), window.removeEventListener("pointerup", _), window.removeEventListener("pointercancel", _), document.removeEventListener("touchmove", y), setTimeout(() => {
						document.removeEventListener("click", v, { capture: !0 });
					}, 10);
				};
			};
			return e.addEventListener("pointerdown", l), {
				signal: a,
				cleanup: () => {
					c(), e.removeEventListener("pointerdown", l), o.clear();
				}
			};
		}(this.wrapper), e.add(() => {
			var e;
			(e = this.dragStream) == null || e.cleanup(), this.dragStream = null;
		});
		let t = g(() => {
			let e = this.dragStream.signal.value;
			if (!e) return;
			let t = this.wrapper.getBoundingClientRect().width, n = (r = e.x / t, Number.isNaN(r) || r < 0 ? 0 : r > 1 ? 1 : r);
			var r;
			e.type === "start" ? (this.isDragging = !0, this._dragEventsSignal.set({
				type: "start",
				relativeX: n
			})) : e.type === "move" ? this._dragEventsSignal.set({
				type: "move",
				relativeX: n
			}) : e.type === "end" && (this.isDragging = !1, this._dragEventsSignal.set({
				type: "end",
				relativeX: n
			}));
		}, [this.dragStream.signal]);
		e.add(t);
	}
	disposeDrag() {
		var e;
		(e = this.dragScope) == null || e.dispose(), this.dragScope = null;
	}
	calculateInlinePadding() {
		let { paddingLeft: e, paddingRight: t } = getComputedStyle(this.scrollContainer), n = parseFloat(e) + parseFloat(t);
		this.containerInlinePadding = Number.isNaN(n) ? 0 : n;
	}
	initHtml() {
		let e = document.createElement("div"), t = e.attachShadow({ mode: "open" }), n = this.options.cspNonce && typeof this.options.cspNonce == "string" ? this.options.cspNonce.replace(/"/g, "") : "";
		return t.innerHTML = `
      <style${n ? ` nonce="${n}"` : ""}>
        :host {
          user-select: none;
          min-width: 1px;
        }
        :host audio {
          display: block;
          width: 100%;
        }
        :host .scroll {
          overflow-x: auto;
          overflow-y: hidden;
          width: 100%;
          position: relative;
        }
        :host .noScrollbar {
          scrollbar-color: transparent;
          scrollbar-width: none;
        }
        :host .noScrollbar::-webkit-scrollbar {
          display: none;
          -webkit-appearance: none;
        }
        :host .wrapper {
          position: relative;
          overflow: visible;
          z-index: 2;
        }
        :host .canvases {
          min-height: ${this.getHeight(this.options.height, this.options.splitChannels)}px;
          pointer-events: none;
        }
        :host .canvases > div {
          position: relative;
        }
        :host canvas {
          display: block;
          position: absolute;
          top: 0;
          image-rendering: pixelated;
        }
        :host .progress {
          pointer-events: none;
          position: absolute;
          z-index: 2;
          top: 0;
          left: 0;
          width: 0;
          height: 100%;
          overflow: hidden;
        }
        :host .progress > div {
          position: relative;
        }
        :host .cursor {
          pointer-events: none;
          position: absolute;
          z-index: 5;
          top: 0;
          left: 0;
          height: 100%;
          border-radius: 2px;
        }
      </style>

      <div class="scroll" part="scroll">
        <div class="wrapper" part="wrapper">
          <div class="canvases" part="canvases"></div>
          <div class="progress" part="progress"></div>
          <div class="cursor" part="cursor"></div>
        </div>
      </div>
    `, [e, t];
	}
	setOptions(e) {
		if (this.options.container !== e.container) {
			let t = this.parentFromOptionsContainer(e.container);
			t.appendChild(this.container), this.parent = t;
		}
		e.dragToSeek === !0 || typeof e.dragToSeek == "object" ? this.initDrag() : this.disposeDrag(), this.options = e, this.reRender();
	}
	getWrapper() {
		return this.wrapper;
	}
	getWidth() {
		return this.scrollContainer.clientWidth - this.containerInlinePadding;
	}
	getScroll() {
		return this.scrollContainer.scrollLeft;
	}
	setScroll(e) {
		this.scrollContainer.scrollLeft = e;
	}
	setScrollPercentage(e) {
		let { scrollWidth: t } = this.scrollContainer, n = t * e;
		this.setScroll(n);
	}
	getVisibleRange() {
		return this.visibleRange;
	}
	get clickSignal() {
		return this._clickSignal;
	}
	get dblclickSignal() {
		return this._dblclickSignal;
	}
	get dragEventsSignal() {
		return this._dragEventsSignal;
	}
	get renderEpoch() {
		return this._renderEpoch;
	}
	get renderedEpoch() {
		return this._renderedEpoch;
	}
	get resizeEpoch() {
		return this._resizeEpoch;
	}
	getScrollSignals() {
		return this.scrollSignals;
	}
	destroy() {
		this.scope.dispose(), this.audioData = null, this.container.remove();
	}
	createDelay(e = 10) {
		let t, n, r, i = () => {
			t?.(), t = void 0, n?.(), n = void 0, r &&= (r(), void 0);
		};
		return () => new Promise((a, o) => {
			i(), r = o, t = this.delayScope.timeout(() => {
				r = void 0, n?.(), n = void 0, a();
			}, e), n = this.delayScope.add(i);
		});
	}
	getHeight(e, t) {
		let n = this.audioData?.numberOfChannels || 1;
		return function({ optionsHeight: e, optionsSplitChannels: t, parentHeight: n, numberOfChannels: r, defaultHeight: i = 128 }) {
			if (e == null) return i;
			let a = Number(e);
			if (!isNaN(a)) return a;
			if (e === "auto") {
				let e = n || i;
				return t?.every((e) => !e.overlay) ? e / r : e;
			}
			return i;
		}({
			optionsHeight: e,
			optionsSplitChannels: t,
			parentHeight: this.parent.clientHeight,
			numberOfChannels: n,
			defaultHeight: 128
		});
	}
	convertColorValues(e, t) {
		return function(e, t, n) {
			if (!Array.isArray(e)) return e || "";
			if (e.length === 0) return "#999";
			if (e.length < 2) return e[0] || "";
			C ??= document.createElement("canvas");
			let r = C.getContext("2d");
			if (!r) return e[0] || "";
			let i = n || C.height * t, a = r.createLinearGradient(0, 0, 0, i), o = 1 / (e.length - 1);
			return e.forEach((e, t) => {
				a.addColorStop(t * o, e);
			}), a;
		}(e, this.getPixelRatio(), t?.canvas.height);
	}
	getPixelRatio() {
		return e = window.devicePixelRatio, Math.max(1, e || 1);
		var e;
	}
	renderBarWaveform(e, t, n, r) {
		let { width: i, height: a } = n.canvas, { halfHeight: o, barWidth: s, barRadius: c, barIndexScale: l, barSpacing: u, barMinHeight: d } = function({ width: e, height: t, length: n, options: r, pixelRatio: i }) {
			let a = t / 2, { barWidth: o, barGap: s } = v(r, i), c = o + s || 1;
			return {
				halfHeight: a,
				barWidth: o,
				barGap: s,
				barRadius: r.barRadius || 0,
				barMinHeight: r.barMinHeight ? r.barMinHeight * i : 0,
				barIndexScale: n > 0 ? e / c / n : 0,
				barSpacing: c
			};
		}({
			width: i,
			height: a,
			length: (e[0] || []).length,
			options: t,
			pixelRatio: this.getPixelRatio()
		}), f = function({ channelData: e, barIndexScale: t, barSpacing: n, barWidth: r, halfHeight: i, vScale: a, canvasHeight: o, barAlign: s, barMinHeight: c }) {
			let l = e[0] || [], u = e[1] || l, d = l.length, f = [], p = 0, m = 0, h = 0;
			for (let e = 0; e <= d; e++) {
				let d = Math.round(e * t);
				if (d > p) {
					let { topHeight: e, totalHeight: t } = y({
						maxTop: m,
						maxBottom: h,
						halfHeight: i,
						vScale: a,
						barMinHeight: c,
						barAlign: s
					}), l = b({
						barAlign: s,
						halfHeight: i,
						topHeight: e,
						totalHeight: t,
						canvasHeight: o
					});
					f.push({
						x: p * n,
						y: l,
						width: r,
						height: t
					}), p = d, m = 0, h = 0;
				}
				let g = Math.abs(l[e] || 0), _ = Math.abs(u[e] || 0);
				g > m && (m = g), _ > h && (h = _);
			}
			return f;
		}({
			channelData: e,
			barIndexScale: l,
			barSpacing: u,
			barWidth: s,
			halfHeight: o,
			vScale: r,
			canvasHeight: a,
			barAlign: t.barAlign,
			barMinHeight: d
		});
		n.beginPath();
		for (let e of f) c && "roundRect" in n ? n.roundRect(e.x, e.y, e.width, e.height, c) : n.rect(e.x, e.y, e.width, e.height);
		n.fill(), n.closePath();
	}
	renderLineWaveform(e, t, n, r) {
		let { width: i, height: a } = n.canvas, o = function({ channelData: e, width: t, height: n, vScale: r }) {
			let i = n / 2, a = e[0] || [];
			return [a, e[1] || a].map((e, n) => {
				let a = e.length, o = a ? t / a : 0, s = i, c = n === 0 ? -1 : 1, l = [{
					x: 0,
					y: s
				}], u = 0, d = 0;
				for (let t = 0; t <= a; t++) {
					let n = Math.round(t * o);
					if (n > u) {
						let e = s + (Math.round(d * i * r) || 1) * c;
						l.push({
							x: u,
							y: e
						}), u = n, d = 0;
					}
					let a = Math.abs(e[t] || 0);
					a > d && (d = a);
				}
				return l.push({
					x: u,
					y: s
				}), l;
			});
		}({
			channelData: e,
			width: i,
			height: a,
			vScale: r
		});
		n.beginPath();
		for (let e of o) if (e.length) {
			n.moveTo(e[0].x, e[0].y);
			for (let t = 1; t < e.length; t++) {
				let r = e[t];
				n.lineTo(r.x, r.y);
			}
		}
		n.fill(), n.closePath();
	}
	renderWaveform(e, t, n) {
		if (n.fillStyle = this.convertColorValues(t.waveColor, n), t.renderFunction) return void t.renderFunction(e, n);
		let r = function({ channelData: e, barHeight: t, normalize: n, maxPeak: r }) {
			let i = t || 1;
			if (!n) return i;
			let a = e[0];
			if (!a || a.length === 0) return i;
			let o = r ?? 0;
			if (!r) for (let e = 0; e < a.length; e++) {
				let t = a[e] ?? 0, n = Math.abs(t);
				n > o && (o = n);
			}
			return o ? i / o : i;
		}({
			channelData: e,
			barHeight: t.barHeight,
			normalize: t.normalize,
			maxPeak: t.maxPeak
		});
		S(t) ? this.renderBarWaveform(e, t, n, r) : this.renderLineWaveform(e, t, n, r);
	}
	renderSingleCanvas(e, t, n, r, i, a, o) {
		let s = this.getPixelRatio(), c = document.createElement("canvas");
		c.width = Math.round(n * s), c.height = Math.round(r * s), c.style.width = `${n}px`, c.style.height = `${r}px`, c.style.left = `${Math.round(i)}px`, a.appendChild(c);
		let l = c.getContext("2d");
		if (t.renderFunction ? (l.fillStyle = this.convertColorValues(t.waveColor, l), t.renderFunction(e, l)) : this.renderWaveform(e, t, l), c.width > 0 && c.height > 0) {
			let e = c.cloneNode(), n = e.getContext("2d");
			n.drawImage(c, 0, 0), n.globalCompositeOperation = "source-in", n.fillStyle = this.convertColorValues(t.progressColor, n), n.fillRect(0, 0, c.width, c.height), o.appendChild(e);
		}
	}
	renderMultiCanvas(e, t, n, r, i, a) {
		let o = this.getPixelRatio(), { clientWidth: s } = this.scrollContainer, c = n / o, l = T({
			clientWidth: s,
			totalWidth: c,
			options: t
		}), u = {};
		if (l.singleCanvasWidth === 0) return;
		let d = (n) => {
			let o = l.slots[n];
			if (!o || u[n]) return;
			u[n] = !0;
			let s = function({ channelData: e, offset: t, clampedWidth: n, totalWidth: r }) {
				return e.map((e) => {
					let i = Math.floor(t / r * e.length), a = Math.floor((t + n) / r * e.length);
					return e.slice(i, a);
				});
			}({
				channelData: e,
				offset: o.offset,
				clampedWidth: o.width,
				totalWidth: c
			});
			this.renderSingleCanvas(s, t, o.width, r, o.offset, i, a);
		};
		if (!this.isScrollable.value) {
			for (let e = 0; e < l.numCanvases; e++) d(e);
			return;
		}
		if (E({
			scrollLeft: this.scrollContainer.scrollLeft,
			clientWidth: s,
			singleCanvasWidth: l.singleCanvasWidth,
			numCanvases: l.numCanvases
		}).forEach((e) => d(e)), l.numCanvases > 1) {
			let e = g(() => {
				let { scrollLeft: e, clientWidth: t } = this.scrollContainer;
				Object.keys(u).length > 10 && (i.innerHTML = "", a.innerHTML = "", u = {}), E({
					scrollLeft: e,
					clientWidth: t,
					singleCanvasWidth: l.singleCanvasWidth,
					numCanvases: l.numCanvases
				}).forEach((e) => d(e));
			}, [this.visibleRange]);
			this.scrollRenderScope.add(e);
		}
	}
	renderChannel(e, t, n, r) {
		var { overlay: i } = t, a = function(e, t) {
			var n = {};
			for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
			if (e != null && typeof Object.getOwnPropertySymbols == "function") {
				var i = 0;
				for (r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
			}
			return n;
		}(t, ["overlay"]);
		let o = document.createElement("div"), s = this.getHeight(a.height, a.splitChannels);
		o.style.height = `${s}px`, i && r > 0 && (o.style.marginTop = `-${s}px`), this.canvasWrapper.style.minHeight = `${s}px`, this.canvasWrapper.appendChild(o);
		let c = o.cloneNode();
		this.progressWrapper.appendChild(c), a.normalize && a.maxPeak == null && (a = Object.assign(Object.assign({}, a), { maxPeak: D(e) })), this.renderMultiCanvas(e, a, n, s, o, c);
	}
	render(t) {
		return e(this, void 0, void 0, function* () {
			var e;
			this.delayScope.dispose(), this.delayScope = this.scope.child(), this.scrollRenderScope.dispose(), this.scrollRenderScope = this.scope.child(), this.canvasWrapper.innerHTML = "", this.progressWrapper.innerHTML = "", this.options.width == null ? this.scrollContainer.style.width = "" : this.scrollContainer.style.width = typeof this.options.width == "number" ? `${this.options.width}px` : this.options.width;
			let n = this.getPixelRatio(), r = this.scrollContainer.clientWidth - this.containerInlinePadding, { scrollWidth: i, isScrollable: a, useParentWidth: o, width: s } = function({ duration: e, minPxPerSec: t = 0, parentWidth: n, fillParent: r, pixelRatio: i }) {
				let a = Math.ceil(e * t), o = a > n, s = !!(r && !o);
				return {
					scrollWidth: a,
					isScrollable: o,
					useParentWidth: s,
					width: (s ? n : a) * i
				};
			}({
				duration: t.duration,
				minPxPerSec: this.options.minPxPerSec || 0,
				parentWidth: r,
				fillParent: this.options.fillParent,
				pixelRatio: n
			});
			if (this.isScrollable.set(a), this.wrapper.style.width = o ? "100%" : `${i}px`, this.scrollContainer.style.overflowX = this.isScrollable.value ? "auto" : "hidden", this.scrollContainer.classList.toggle("noScrollbar", !!this.options.hideScrollbar), this.cursor.style.backgroundColor = `${this.options.cursorColor || this.options.progressColor}`, this.cursor.style.width = `${this.options.cursorWidth}px`, (e = this.scrollStream) == null || e.refresh(), this.audioData = t, this.audioDuration.set(t.duration), this._renderEpoch.update((e) => e + 1), this.options.splitChannels) for (let e = 0; e < t.numberOfChannels; e++) {
				let n = Object.assign(Object.assign({}, this.options), this.options.splitChannels?.[e]);
				this.renderChannel([t.getChannelData(e)], n, s, e);
			}
			else {
				let e = [t.getChannelData(0)];
				t.numberOfChannels > 1 && e.push(t.getChannelData(1)), this.renderChannel(e, this.options, s, 0);
			}
			Promise.resolve().then(() => this._renderedEpoch.update((e) => e + 1));
		});
	}
	reRender() {
		if (this.scrollRenderScope.dispose(), this.scrollRenderScope = this.scope.child(), !this.audioData) return;
		let { scrollWidth: e } = this.scrollContainer, { right: t } = this.progressWrapper.getBoundingClientRect();
		if (this.render(this.audioData), !this.isScrollable.value && this.scrollContainer.scrollLeft) this.scrollContainer.scrollLeft = 0;
		else if (this.isScrollable.value && e !== this.scrollContainer.scrollWidth) {
			let { right: e } = this.progressWrapper.getBoundingClientRect(), r = (n = e - t, Math.sign(n) * Math.round(Math.abs(n)));
			this.scrollContainer.scrollLeft += r;
		}
		var n;
	}
	zoom(e) {
		this.options.minPxPerSec = e, this.reRender();
	}
	scrollIntoView(e, t = !1) {
		let { scrollLeft: n, scrollWidth: r, clientWidth: i } = this.scrollContainer, a = e * r, o = n, s = n + i, c = i / 2;
		if (this.isDragging) a + 30 > s ? this.scrollContainer.scrollLeft += 30 : a - 30 < o && (this.scrollContainer.scrollLeft -= 30);
		else {
			(a < o || a > s) && (this.scrollContainer.scrollLeft = a - (this.options.autoCenter ? c : 0));
			let e = a - n - c;
			if (t && this.options.autoCenter && e > 0) {
				let t = this.audioData?.duration;
				if (t === void 0 || t <= 0) return void (this.scrollContainer.scrollLeft += e);
				let n = r / t;
				this.scrollContainer.scrollLeft += n <= 600 ? Math.min(e, 10) : e;
			}
		}
	}
	renderProgress(e, t) {
		if (isNaN(e)) return;
		let n = 100 * e;
		this.canvasWrapper.style.clipPath = `polygon(${n}% 0%, 100% 0%, 100% 100%, ${n}% 100%)`, this.progressWrapper.style.width = `${n}%`, this.cursor.style.left = `${n}%`, this.cursor.style.transform = this.options.cursorWidth ? `translateX(-${e * this.options.cursorWidth}px)` : "", this.isScrollable.value && this.options.autoScroll && this.audioData && this.audioData.duration > 0 && this.scrollIntoView(e, t);
	}
	exportImage(t, n, r) {
		return e(this, void 0, void 0, function* () {
			let e = this.canvasWrapper.querySelectorAll("canvas");
			if (!e.length) throw Error("No waveform data");
			if (r === "dataURL") {
				let r = Array.from(e).map((e) => e.toDataURL(t, n));
				return Promise.resolve(r);
			}
			return Promise.all(Array.from(e).map((e) => new Promise((r, i) => {
				e.toBlob((e) => {
					e ? r(e) : i(/* @__PURE__ */ Error("Could not export image"));
				}, t, n);
			})));
		});
	}
}, A = class extends t {
	constructor(e) {
		super(), this.bufferNode = null, this.playStartTime = 0, this.playbackPosition = 0, this._muted = !1, this._playbackRate = 1, this._duration = void 0, this.buffer = null, this.currentSrc = "", this.paused = !0, this.crossOrigin = null, this.seeking = !1, this.autoplay = !1, this.error = null, this.scope = new n(), this.scheduledStop = null, this.addEventListener = this.on, this.removeEventListener = this.un, this._destroyed = !1, this.srcGeneration = 0, this.srcFetchAbort = null, function() {
			let e = globalThis.navigator;
			if (e?.audioSession) try {
				e.audioSession.type = "playback";
			} catch (e) {
				console.warn("Setting navigator.audioSession.type failed:", e);
			}
		}(), this.audioContext = e || new AudioContext(), this.gainNode = this.audioContext.createGain(), this.gainNode.connect(this.audioContext.destination);
	}
	load() {
		return e(this, void 0, void 0, function* () {});
	}
	remove() {
		this.destroy();
	}
	destroy() {
		var e;
		if (!this._destroyed) {
			if (this._destroyed = !0, this.scope.dispose(), this.scheduledStop = null, this.srcGeneration++, (e = this.srcFetchAbort) == null || e.abort(), this.srcFetchAbort = null, this.currentSrc = "", this.bufferNode) {
				this.bufferNode.onended = null;
				try {
					this.bufferNode.stop();
				} catch {}
				this.bufferNode.disconnect(), this.bufferNode = null;
			}
			this.gainNode.disconnect(), typeof this.audioContext.close == "function" && Promise.resolve(this.audioContext.close.call(this.audioContext)).catch(() => {}), this.buffer = null, this.unAll();
		}
	}
	get src() {
		return this.currentSrc;
	}
	set src(e) {
		var t;
		this.currentSrc = e, this._duration = void 0, this.error = null;
		let n = ++this.srcGeneration;
		if ((t = this.srcFetchAbort) == null || t.abort(), this.srcFetchAbort = null, !e) return this.buffer = null, void this.emit("emptied");
		let r = new AbortController();
		this.srcFetchAbort = r, fetch(e, { signal: r.signal }).then((t) => {
			if (t.status >= 400) throw Error(`Failed to fetch ${e}: ${t.status} (${t.statusText})`);
			return t.arrayBuffer();
		}).then((e) => n === this.srcGeneration ? this.audioContext.decodeAudioData(e) : null).then((e) => {
			n === this.srcGeneration && (this.buffer = e, this.emit("loadedmetadata"), this.emit("canplay"), this.autoplay && this.play());
		}).catch((e) => {
			n === this.srcGeneration && (console.error("WebAudioPlayer load error:", e), this.error = e instanceof Error ? e : Error(String(e)), this.emit("error", this.error));
		});
	}
	_play() {
		if (!this.paused) return;
		this.paused = !1, this.bufferNode && (this.bufferNode.onended = null, this.bufferNode.disconnect()), this.bufferNode = this.audioContext.createBufferSource(), this.buffer && (this.bufferNode.buffer = this.buffer), this.bufferNode.playbackRate.value = this._playbackRate, this.bufferNode.connect(this.gainNode);
		let e = this.playbackPosition;
		(e >= this.duration || e < 0) && (e = 0, this.playbackPosition = 0), this.bufferNode.start(this.audioContext.currentTime, e), this.playStartTime = this.audioContext.currentTime, this.bufferNode.onended = () => {
			!this.paused && this.duration - this.currentTime < .01 && (this.pause(), this.emit("ended"));
		};
	}
	_pause() {
		if (this.scheduledStop && this.currentTime < this.scheduledStop.time && this.cancelScheduledStop(), this.playbackPosition = this.currentTime, this.paused = !0, this.bufferNode) {
			this.bufferNode.onended = null;
			try {
				this.bufferNode.stop();
			} catch {}
		}
	}
	play() {
		return e(this, void 0, void 0, function* () {
			this.paused && (this.audioContext.state === "suspended" && typeof this.audioContext.resume == "function" && this.audioContext.resume().catch(() => {}), this._play(), this.emit("play"));
		});
	}
	pause() {
		this.paused || (this._pause(), this.emit("pause"));
	}
	cancelScheduledStop() {
		var e;
		(e = this.scheduledStop) == null || e.cancel(), this.scheduledStop = null;
	}
	stopAt(e) {
		let t = this.bufferNode;
		if (!t) return;
		this.cancelScheduledStop();
		let n = (e - this.currentTime) / this._playbackRate;
		t.stop(this.audioContext.currentTime + Math.max(0, n));
		let r = this.scope.listen(t, "ended", () => {
			let n = this.scheduledStop;
			n?.node === t && (this.scheduledStop = null, n.cancel(), t === this.bufferNode && (this.bufferNode = null, this.pause(), this.playbackPosition = Math.min(e, this.duration), this.emit("timeupdate")));
		}, { once: !0 });
		this.scheduledStop = {
			node: t,
			time: e,
			cancel: r
		};
	}
	setSinkId(t) {
		return e(this, void 0, void 0, function* () {
			return this.audioContext.setSinkId(t);
		});
	}
	get playbackRate() {
		return this._playbackRate;
	}
	set playbackRate(e) {
		let t = !this.paused;
		t && this._pause(), this._playbackRate = e, t && this._play(), this.bufferNode && (this.bufferNode.playbackRate.value = e);
	}
	get currentTime() {
		return this.paused ? this.playbackPosition : this.playbackPosition + (this.audioContext.currentTime - this.playStartTime) * this._playbackRate;
	}
	set currentTime(e) {
		let t = !this.paused;
		t && this._pause(), this.playbackPosition = e, t && this._play(), this.emit("seeking"), this.emit("seeked"), this.emit("timeupdate");
	}
	get duration() {
		return this._duration ?? (this.buffer?.duration || 0);
	}
	set duration(e) {
		this._duration = e;
	}
	get volume() {
		return this.gainNode.gain.value;
	}
	set volume(e) {
		this.gainNode.gain.value = e, this.emit("volumechange");
	}
	get muted() {
		return this._muted;
	}
	set muted(e) {
		this._muted !== e && (this._muted = e, this._muted ? this.gainNode.disconnect() : this.gainNode.connect(this.audioContext.destination));
	}
	canPlayType(e) {
		return /^(audio|video)\//.test(e);
	}
	getGainNode() {
		return this.gainNode;
	}
	getChannelData() {
		let e = [];
		if (!this.buffer) return e;
		let t = this.buffer.numberOfChannels;
		for (let n = 0; n < t; n++) e.push(this.buffer.getChannelData(n));
		return e;
	}
	removeAttribute(e) {
		switch (e) {
			case "src":
				this.src = "";
				break;
			case "playbackRate":
				this.playbackRate = 0;
				break;
			case "currentTime":
				this.currentTime = 0;
				break;
			case "duration":
				this.duration = 0;
				break;
			case "volume":
				this.volume = 0;
				break;
			case "muted": this.muted = !1;
		}
	}
}, j = {
	waveColor: "#999",
	progressColor: "#555",
	cursorWidth: 1,
	minPxPerSec: 0,
	fillParent: !0,
	interact: !0,
	dragToSeek: !1,
	autoScroll: !0,
	autoCenter: !0,
	sampleRate: 8e3
}, M = class r extends t {
	static create(e) {
		return new r(e);
	}
	getState() {
		return this.wavesurferState;
	}
	getRenderer() {
		return this.renderer;
	}
	constructor(e) {
		super(), this.plugins = [], this.decodedData = null, this.stopAtPosition = null, this.internalWebAudioPlayer = null, this.webAudioPlayer = null, this.scope = new n(), this.mediaEventScope = this.scope.child(), this.frameScheduler = new d(this.scope), this.loadScope = null, this.supersededLoadScopes = /* @__PURE__ */ new WeakSet(), this.isDestroyed = !1, this.onTick = () => {
			if (!this.isSeeking()) {
				let e = this.updateProgress();
				if (this.emit("timeupdate", e), this.emit("audioprocess", e), this.stopAtPosition != null && this.isPlaying() && e >= this.stopAtPosition) {
					let e = this.stopAtPosition;
					this.pause(), this.setTime(e);
				}
			}
		};
		let t = e.media || e.backend !== "WebAudio" ? null : new A(), r = e.media ?? t ?? void 0;
		this.player = new _({
			media: r,
			mediaControls: e.mediaControls,
			autoplay: e.autoplay,
			playbackRate: e.audioRate
		}), this.internalWebAudioPlayer = t, this.webAudioPlayer = t ?? (e.media instanceof A ? e.media : null), this.options = Object.assign({}, j, e);
		let { state: i, actions: a, dispose: o } = function(e) {
			let t = e?.currentTime ?? p(0), n = e?.duration ?? p(0), r = e?.isPlaying ?? p(!1), i = e?.isSeeking ?? p(!1), a = e?.volume ?? p(1), o = e?.muted ?? p(!1), s = e?.playbackRate ?? p(1), c = p(null), l = p(null), u = p(""), d = p(0), f = p(0), m = p("idle"), g = h(() => !r.value, [r]), _ = h(() => c.value !== null, [c]), v = h(() => _.value && n.value > 0, [_, n]), y = h(() => t.value, [t]), b = h(() => n.value > 0 ? t.value / n.value : 0, [t, n]), x = [
				g,
				_,
				v,
				y,
				b
			];
			return {
				state: {
					currentTime: t,
					duration: n,
					isPlaying: r,
					isPaused: g,
					isSeeking: i,
					volume: a,
					muted: o,
					playbackRate: s,
					audioBuffer: c,
					peaks: l,
					url: u,
					zoom: d,
					scrollPosition: f,
					loadPhase: m,
					canPlay: _,
					isReady: v,
					progress: y,
					progressPercent: b
				},
				actions: {
					setCurrentTime: (e) => {
						let r = Math.max(0, Math.min(n.value || 1 / 0, e));
						t.set(r);
					},
					setDuration: (e) => {
						n.set(Math.max(0, e));
					},
					setPlaying: (e) => {
						r.set(e);
					},
					setSeeking: (e) => {
						i.set(e);
					},
					setVolume: (e) => {
						let t = Math.max(0, Math.min(1, e));
						a.set(t);
					},
					setPlaybackRate: (e) => {
						let t = Math.max(.1, Math.min(16, e));
						s.set(t);
					},
					setAudioBuffer: (e) => {
						if (c.set(e), e) {
							let t = n.value;
							(t === 0 || Number.isNaN(t) || t === 1 / 0) && n.set(e.duration);
						}
					},
					setPeaks: (e) => {
						l.set(e);
					},
					setUrl: (e) => {
						u.set(e);
					},
					setZoom: (e) => {
						d.set(Math.max(0, e));
					},
					setScrollPosition: (e) => {
						f.set(Math.max(0, e));
					},
					setLoadPhase: (e) => {
						m.set(e);
					}
				},
				dispose: () => {
					x.forEach((e) => e.dispose());
				}
			};
		}({
			isPlaying: this.player.isPlayingSignal,
			currentTime: this.player.currentTimeSignal,
			duration: this.player.durationSignal,
			volume: this.player.volumeSignal,
			muted: this.player.mutedSignal,
			playbackRate: this.player.playbackRateSignal,
			isSeeking: this.player.seekingSignal
		});
		this.wavesurferState = i, this.wavesurferActions = a, this.scope.add(o);
		let s = r ? void 0 : this.player.getMediaElement();
		this.renderer = new k(this.options, s), this.initPlayerEvents(), this.initRendererEvents(), this.initPlugins();
		let c = this.options.url || this.player.getSrc() || "";
		Promise.resolve().then(() => {
			if (this.isDestroyed) return;
			this.emit("init");
			let { peaks: e, duration: t } = this.options;
			(c || e && t) && this.load(c, e, t).catch(() => {});
		});
	}
	updateProgress(e = this.getCurrentTime()) {
		return this.renderer.renderProgress(e / this.getDuration(), this.isPlaying()), e;
	}
	initPlayerEvents() {
		this.isPlaying() && (this.emit("play"), this.frameScheduler.start(this.onTick)), this.mediaEventScope.add(this.player.onMediaEvent("timeupdate", () => {
			let e = this.updateProgress();
			if (this.emit("timeupdate", e), this.stopAtPosition != null && this.isPlaying() && e >= this.stopAtPosition) {
				let e = this.stopAtPosition;
				this.pause(), this.setTime(e);
			}
		})), this.mediaEventScope.add(this.player.onMediaEvent("play", () => {
			this.emit("play"), this.frameScheduler.start(this.onTick);
		})), this.mediaEventScope.add(this.player.onMediaEvent("pause", () => {
			this.emit("pause"), this.frameScheduler.stop(), this.stopAtPosition = null;
		})), this.mediaEventScope.add(this.player.onMediaEvent("emptied", () => {
			this.frameScheduler.stop(), this.stopAtPosition = null;
		})), this.mediaEventScope.add(this.player.onMediaEvent("ended", () => {
			this.emit("timeupdate", this.getDuration()), this.emit("finish"), this.stopAtPosition = null;
		})), this.mediaEventScope.add(this.player.onMediaEvent("seeking", () => {
			this.emit("seeking", this.getCurrentTime());
		})), this.mediaEventScope.add(this.player.onMediaEvent("error", () => {
			let e = this.player.getMediaElement().error, t;
			t = e instanceof Error ? e : Error(e ? e.message || `Media error ${e.code}` : "Media error"), this.emit("error", t), this.stopAtPosition = null;
		}));
	}
	initRendererEvents() {
		this.scope.add(this.renderer.clickSignal.subscribe((e) => {
			e && this.options.interact && (this.seekTo(e.relativeX), this.emit("interaction", e.relativeX * this.getDuration()), this.emit("click", e.relativeX, e.relativeY));
		})), this.scope.add(this.renderer.dblclickSignal.subscribe((e) => {
			e && this.emit("dblclick", e.relativeX, e.relativeY);
		}));
		{
			let { percentages: e, bounds: t } = this.renderer.getScrollSignals();
			this.scope.add(g(() => {
				let { startX: n, endX: r } = e.value, { left: i, right: a } = t.value, o = this.getDuration();
				this.wavesurferActions.setScrollPosition(i), this.emit("scroll", n * o, r * o, i, a);
			}, [e, t]));
		}
		this.scope.add(this.renderer.renderEpoch.subscribe(() => {
			this.emit("redraw");
		})), this.scope.add(this.renderer.renderedEpoch.subscribe(() => {
			this.emit("redrawcomplete");
		})), this.scope.add(this.renderer.resizeEpoch.subscribe(() => {
			this.emit("resize");
		}));
		{
			let e, t = this.renderer.dragEventsSignal.subscribe((t) => {
				if (!t) return;
				let { relativeX: n } = t;
				if (t.type === "start") return void this.emit("dragstart", n);
				if (t.type === "end") return void this.emit("dragend", n);
				if (!this.options.interact) return;
				this.renderer.renderProgress(n), e?.();
				let r = 0, i = this.options.dragToSeek;
				this.isPlaying() ? r = 0 : i === !0 ? r = 200 : i && typeof i == "object" && (r = i.debounceTime ?? 200), e = this.scope.timeout(() => {
					this.seekTo(n);
				}, r), this.emit("interaction", n * this.getDuration()), this.emit("drag", n);
			});
			this.scope.add(t);
		}
	}
	initPlugins() {
		var e;
		(e = this.options.plugins) != null && e.length && this.options.plugins.forEach((e) => {
			this.registerPlugin(e);
		});
	}
	unsubscribePlayerEvents() {
		this.mediaEventScope.dispose(), this.mediaEventScope = this.scope.child();
	}
	setOptions(e) {
		this.isDestroyed || (this.options = Object.assign({}, this.options, e), e.duration && !e.peaks && (this.decodedData = i.createBuffer(this.exportPeaks(), e.duration), this.wavesurferActions.setAudioBuffer(this.decodedData)), e.peaks && e.duration && (this.decodedData = i.createBuffer(e.peaks, e.duration), this.wavesurferActions.setAudioBuffer(this.decodedData)), this.renderer.setOptions(this.options), e.audioRate && this.setPlaybackRate(e.audioRate), e.mediaControls != null && (this.player.getMediaElement().controls = e.mediaControls));
	}
	registerPlugin(e) {
		if (this.isDestroyed) throw Error("Cannot register a plugin: wavesurfer was destroyed. Create a new instance instead.");
		if (this.plugins.includes(e)) return e;
		e._init(this), this.plugins.push(e);
		let t = this.scope.add(e.once("destroy", () => {
			this.plugins = this.plugins.filter((t) => t !== e), t();
		}));
		return e;
	}
	unregisterPlugin(e) {
		this.plugins = this.plugins.filter((t) => t !== e), e.destroy();
	}
	getWrapper() {
		return this.renderer.getWrapper();
	}
	getWidth() {
		return this.renderer.getWidth();
	}
	getScroll() {
		return this.renderer.getScroll();
	}
	setScroll(e) {
		if (!this.isDestroyed) return this.renderer.setScroll(e);
	}
	setScrollTime(e) {
		let t = e / this.getDuration();
		this.renderer.setScrollPercentage(t);
	}
	getActivePlugins() {
		return this.plugins;
	}
	bailedLoadOutcome(e) {
		return this.supersededLoadScopes.has(e) ? "superseded" : void 0;
	}
	loadAudio(t, n, r, a) {
		return e(this, void 0, void 0, function* () {
			var e;
			if (this.isDestroyed) throw Error("Cannot load audio: wavesurfer was destroyed. Create a new instance instead.");
			this.loadScope && !this.loadScope.disposed && this.supersededLoadScopes.add(this.loadScope), (e = this.loadScope) == null || e.dispose();
			let o = this.scope.child();
			this.loadScope = o;
			try {
				if (this.emit("load", t), o.disposed || n || r || this.wavesurferActions.setLoadPhase("fetching"), this.wavesurferActions.setUrl(t || ""), r ? this.wavesurferActions.setPeaks(r) : this.wavesurferActions.setPeaks(null), !this.options.media && this.isPlaying() && this.pause(), this.decodedData = null, this.wavesurferActions.setAudioBuffer(null), this.stopAtPosition = null, !n && !r) {
					let e = Object.assign({}, this.options.fetchParams);
					if (e.signal ||= o.abortSignal(), n = yield u.fetchBlob(t, (e) => this.emit("loading", e), e), o.disposed) return this.bailedLoadOutcome(o);
					let r = this.options.blobMimeType;
					r && (n = new Blob([n], { type: r }));
				}
				if (o.disposed) return this.bailedLoadOutcome(o);
				this.player.setSrc(t, n);
				let e = yield new Promise((e) => {
					let t = a || this.getDuration();
					if (t) e(t);
					else {
						this.mediaEventScope.add(this.player.onMediaEvent("loadedmetadata", () => e(this.getDuration()), { once: !0 }));
						let t = this.mediaEventScope.add(() => e(0));
						o.add(t);
					}
				});
				if (o.disposed) return this.bailedLoadOutcome(o);
				if (t || n || !this.webAudioPlayer || (this.webAudioPlayer.duration = e), o.disposed || this.wavesurferActions.setLoadPhase("decoding"), r) this.decodedData = i.createBuffer(r, e || 0);
				else if (n) {
					let e = yield n.arrayBuffer();
					if (o.disposed) return this.bailedLoadOutcome(o);
					let t = yield i.decode(e, this.options.sampleRate);
					if (o.disposed) return this.bailedLoadOutcome(o);
					this.decodedData = t;
				}
				if (o.disposed) return this.bailedLoadOutcome(o);
				this.decodedData && (this.wavesurferActions.setAudioBuffer(this.decodedData), this.emit("decode", this.getDuration()), this.renderer.render(this.decodedData)), o.disposed || this.wavesurferActions.setLoadPhase("ready"), this.emit("ready", this.getDuration());
			} catch (e) {
				if (!this.supersededLoadScopes.has(o)) throw this.loadScope !== o && this.loadScope !== null || this.wavesurferActions.setLoadPhase("error"), e;
				return "superseded";
			}
		});
	}
	classifyLoadResult(e) {
		let t = e.then((e) => {
			if (e === "superseded") throw new DOMException("The load was superseded by a newer load call", "AbortError");
		}, (e) => {
			throw this.emit("error", e), e;
		});
		return t.catch(() => {}), t;
	}
	load(e, t, n) {
		return this.classifyLoadResult(this.loadAudio(e, void 0, t, n));
	}
	loadBlob(e, t, n) {
		return this.classifyLoadResult(this.loadAudio("", e, t, n));
	}
	zoom(e) {
		if (!this.decodedData) throw Error("No audio loaded");
		this.renderer.zoom(e), this.wavesurferActions.setZoom(e), this.emit("zoom", e);
	}
	getDecodedData() {
		return this.decodedData;
	}
	exportPeaks({ channels: e = 2, maxLength: t = 8e3, precision: n = 1e4 } = {}) {
		if (!this.decodedData) throw Error("The audio has not been decoded yet");
		let r = Math.min(e, this.decodedData.numberOfChannels), i = [];
		for (let e = 0; e < r; e++) {
			let r = this.decodedData.getChannelData(e), a = [], o = r.length / t;
			for (let e = 0; e < t; e++) {
				let t = r.slice(Math.floor(e * o), Math.ceil((e + 1) * o)), i = 0;
				for (let e = 0; e < t.length; e++) {
					let n = t[e];
					Math.abs(n) > Math.abs(i) && (i = n);
				}
				a.push(Math.round(i * n) / n);
			}
			i.push(a);
		}
		return i;
	}
	getDuration() {
		let e = this.player.getDuration() || 0;
		return e !== 0 && e !== 1 / 0 || !this.decodedData || (e = this.decodedData.duration), e;
	}
	toggleInteraction(e) {
		this.options.interact = e;
	}
	setTime(e) {
		this.isDestroyed || (this.stopAtPosition = null, this.player.setTime(e), this.updateProgress(e), this.emit("timeupdate", e));
	}
	seekTo(e) {
		let t = this.getDuration() * e;
		this.setTime(t);
	}
	pause() {
		this.isDestroyed || this.player.pause();
	}
	isPlaying() {
		return this.player.isPlaying();
	}
	isSeeking() {
		return this.player.isSeeking();
	}
	getCurrentTime() {
		return this.player.getCurrentTime();
	}
	getVolume() {
		return this.player.getVolume();
	}
	setVolume(e) {
		this.isDestroyed || this.player.setVolume(e);
	}
	getMuted() {
		return this.player.getMuted();
	}
	setMuted(e) {
		this.isDestroyed || this.player.setMuted(e);
	}
	getPlaybackRate() {
		return this.player.getPlaybackRate();
	}
	setPlaybackRate(e, t) {
		this.isDestroyed || this.player.setPlaybackRate(e, t);
	}
	setSinkId(e) {
		return this.isDestroyed ? Promise.resolve() : this.player.setSinkId(e);
	}
	getMediaElement() {
		return this.webAudioPlayer ? null : this.player.getMediaElement();
	}
	play(t, n) {
		return e(this, void 0, void 0, function* () {
			if (this.isDestroyed) return;
			t != null && this.setTime(t);
			let e = yield this.player.play();
			return n != null && (this.webAudioPlayer ? this.webAudioPlayer.stopAt(n) : this.stopAtPosition = n), e;
		});
	}
	playPause() {
		return e(this, void 0, void 0, function* () {
			return this.isPlaying() ? this.pause() : this.play();
		});
	}
	stop() {
		this.pause(), this.setTime(0);
	}
	skip(e) {
		this.setTime(this.getCurrentTime() + e);
	}
	empty() {
		this.load("", [[0]], .001).catch(() => {});
	}
	setMediaElement(e) {
		this.isDestroyed || (this.unsubscribePlayerEvents(), this.player.setMediaElement(e), this.webAudioPlayer = e instanceof A ? e : null, this.initPlayerEvents());
	}
	exportImage() {
		return e(this, arguments, void 0, function* (e = "image/png", t = 1, n = "dataURL") {
			return this.renderer.exportImage(e, t, n);
		});
	}
	destroy() {
		var e;
		this.isDestroyed || (this.isDestroyed = !0, this.emit("destroy"), this.plugins.forEach((e) => e.destroy()), this.scope.dispose(), this.loadScope = null, this.decodedData = null, this.wavesurferActions.setAudioBuffer(null), this.renderer.destroy(), this.player.destroy(), this.unAll(), (e = this.internalWebAudioPlayer) == null || e.destroy());
	}
};
M.BasePlugin = r, M.dom = l, M.definePlugin = function(e, t) {
	class i extends r {
		static create(...e) {
			return new i(e[0]);
		}
		onInit() {
			this.scope.dispose(), this.scope = new n();
			let r = this, i = t({
				get wavesurfer() {
					return r.wavesurfer;
				},
				get state() {
					return r.wavesurfer.getState();
				},
				scope: this.scope,
				emit: (e, ...t) => this.emit(e, ...t)
			}, this.options);
			for (let t of Object.keys(i)) if (a.has(t)) throw Error(`definePlugin('${e}'): api key "${t}" collides with the plugin chassis`);
			Object.assign(this, i);
		}
		destroy() {
			this.scope.dispose(), super.destroy();
		}
	}
	return Object.defineProperty(i, "name", { value: e }), i;
};
//#endregion
export { M as default };

//# sourceMappingURL=wavesurfer.esm-uh5mEd8d-C5u_TfCZ.js.map