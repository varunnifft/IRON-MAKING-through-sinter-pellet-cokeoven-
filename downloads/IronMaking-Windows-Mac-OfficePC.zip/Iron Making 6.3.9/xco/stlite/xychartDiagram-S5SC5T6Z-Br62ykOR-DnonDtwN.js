import { t as e } from "./init-5BClRdiB-LyILMlTE.js";
import { d as t } from "./linear-CJvvCWKw-rrRTERsA.js";
import { t as n } from "./range-DdOGybNB-Ba7Spj1J.js";
import { n as r } from "./ordinal-DkyryJlW-DURmPlUH.js";
import "./transform-B2AI7qp--hg0kwf7R.js";
import { M as i, N as a, R as o, T as s, a7 as c, ai as l, aj as u, al as d, an as f, av as p, b3 as m, b6 as h, bB as g, bw as _, bx as v, by as y, bz as b, c as x } from "./mermaid.core-iLj2gv8s-DM09IeU-.js";
//#region ../react/build/xychartDiagram-S5SC5T6Z-Br62ykOR.js
function S() {
	var t = r().unknown(void 0), i = t.domain, a = t.range, o = 0, s = 1, c, l, u = !1, d = 0, f = 0, p = .5;
	delete t.unknown;
	function m() {
		var e = i().length, t = s < o, r = t ? s : o, m = t ? o : s;
		c = (m - r) / Math.max(1, e - d + f * 2), u && (c = Math.floor(c)), r += (m - r - c * (e - d)) * p, l = c * (1 - d), u && (r = Math.round(r), l = Math.round(l));
		var h = n(e).map(function(e) {
			return r + c * e;
		});
		return a(t ? h.reverse() : h);
	}
	return t.domain = function(e) {
		return arguments.length ? (i(e), m()) : i();
	}, t.range = function(e) {
		return arguments.length ? ([o, s] = e, o = +o, s = +s, m()) : [o, s];
	}, t.rangeRound = function(e) {
		return [o, s] = e, o = +o, s = +s, u = !0, m();
	}, t.bandwidth = function() {
		return l;
	}, t.step = function() {
		return c;
	}, t.round = function(e) {
		return arguments.length ? (u = !!e, m()) : u;
	}, t.padding = function(e) {
		return arguments.length ? (d = Math.min(1, f = +e), m()) : d;
	}, t.paddingInner = function(e) {
		return arguments.length ? (d = Math.min(1, e), m()) : d;
	}, t.paddingOuter = function(e) {
		return arguments.length ? (f = +e, m()) : f;
	}, t.align = function(e) {
		return arguments.length ? (p = Math.max(0, Math.min(1, e)), m()) : p;
	}, t.copy = function() {
		return S(i(), [o, s]).round(u).paddingInner(d).paddingOuter(f).align(p);
	}, e.apply(m(), arguments);
}
var C = function() {
	var e = /* @__PURE__ */ x(function(e, t, n, r) {
		for (n ||= {}, r = e.length; r--; n[e[r]] = t);
		return n;
	}, "o"), t = [
		1,
		10,
		12,
		14,
		16,
		18,
		19,
		21,
		23
	], n = [2, 6], r = [1, 3], i = [1, 5], a = [1, 6], o = [1, 7], s = [
		1,
		5,
		10,
		12,
		14,
		16,
		18,
		19,
		21,
		23,
		36,
		37,
		38
	], c = [1, 25], l = [1, 26], u = [1, 28], d = [1, 29], f = [1, 30], p = [1, 31], m = [1, 32], h = [1, 33], g = [1, 34], _ = [1, 35], v = [1, 36], y = [1, 37], b = [1, 43], S = [1, 42], C = [1, 47], w = [1, 50], T = [
		1,
		10,
		12,
		14,
		16,
		18,
		19,
		21,
		23,
		36,
		37,
		38
	], E = [
		1,
		10,
		12,
		14,
		16,
		18,
		19,
		21,
		23,
		24,
		26,
		28,
		29,
		36,
		37,
		38
	], D = [
		1,
		10,
		12,
		14,
		16,
		18,
		19,
		21,
		23,
		24,
		26,
		28,
		29,
		36,
		37,
		38,
		42,
		43,
		44,
		45,
		46,
		47,
		48,
		49,
		50,
		51
	], O = [1, 65], k = [26, 28], A = {
		trace: /* @__PURE__ */ x(function() {}, "trace"),
		yy: {},
		symbols_: {
			error: 2,
			start: 3,
			eol: 4,
			XYCHART: 5,
			chartConfig: 6,
			document: 7,
			CHART_ORIENTATION: 8,
			statement: 9,
			title: 10,
			text: 11,
			X_AXIS: 12,
			parseXAxis: 13,
			Y_AXIS: 14,
			parseYAxis: 15,
			LINE: 16,
			plotData: 17,
			BAR: 18,
			acc_title: 19,
			acc_title_value: 20,
			acc_descr: 21,
			acc_descr_value: 22,
			acc_descr_multiline_value: 23,
			SQUARE_BRACES_START: 24,
			dataPoints: 25,
			SQUARE_BRACES_END: 26,
			dataPoint: 27,
			COMMA: 28,
			NUMBER_WITH_DECIMAL: 29,
			STR: 30,
			xAxisData: 31,
			bandData: 32,
			ARROW_DELIMITER: 33,
			commaSeparatedTexts: 34,
			yAxisData: 35,
			NEWLINE: 36,
			SEMI: 37,
			EOF: 38,
			alphaNum: 39,
			MD_STR: 40,
			alphaNumToken: 41,
			AMP: 42,
			NUM: 43,
			ALPHA: 44,
			PLUS: 45,
			EQUALS: 46,
			MULT: 47,
			DOT: 48,
			BRKT: 49,
			MINUS: 50,
			UNDERSCORE: 51,
			$accept: 0,
			$end: 1
		},
		terminals_: {
			2: "error",
			5: "XYCHART",
			8: "CHART_ORIENTATION",
			10: "title",
			12: "X_AXIS",
			14: "Y_AXIS",
			16: "LINE",
			18: "BAR",
			19: "acc_title",
			20: "acc_title_value",
			21: "acc_descr",
			22: "acc_descr_value",
			23: "acc_descr_multiline_value",
			24: "SQUARE_BRACES_START",
			26: "SQUARE_BRACES_END",
			28: "COMMA",
			29: "NUMBER_WITH_DECIMAL",
			30: "STR",
			33: "ARROW_DELIMITER",
			36: "NEWLINE",
			37: "SEMI",
			38: "EOF",
			40: "MD_STR",
			42: "AMP",
			43: "NUM",
			44: "ALPHA",
			45: "PLUS",
			46: "EQUALS",
			47: "MULT",
			48: "DOT",
			49: "BRKT",
			50: "MINUS",
			51: "UNDERSCORE"
		},
		productions_: [
			0,
			[3, 2],
			[3, 3],
			[3, 2],
			[3, 1],
			[6, 1],
			[7, 0],
			[7, 2],
			[9, 2],
			[9, 2],
			[9, 2],
			[9, 2],
			[9, 2],
			[9, 3],
			[9, 2],
			[9, 3],
			[9, 2],
			[9, 2],
			[9, 1],
			[17, 3],
			[25, 3],
			[25, 1],
			[27, 2],
			[27, 1],
			[13, 1],
			[13, 2],
			[13, 1],
			[31, 1],
			[31, 3],
			[32, 3],
			[34, 3],
			[34, 1],
			[15, 1],
			[15, 2],
			[15, 1],
			[35, 3],
			[4, 1],
			[4, 1],
			[4, 1],
			[11, 1],
			[11, 1],
			[11, 1],
			[39, 1],
			[39, 2],
			[41, 1],
			[41, 1],
			[41, 1],
			[41, 1],
			[41, 1],
			[41, 1],
			[41, 1],
			[41, 1],
			[41, 1],
			[41, 1]
		],
		performAction: /* @__PURE__ */ x(function(e, t, n, r, i, a, o) {
			var s = a.length - 1;
			switch (i) {
				case 5:
					r.setOrientation(a[s]);
					break;
				case 9:
					r.setDiagramTitle(a[s].text.trim());
					break;
				case 12:
					r.setLineData({
						text: "",
						type: "text"
					}, a[s]);
					break;
				case 13:
					r.setLineData(a[s - 1], a[s]);
					break;
				case 14:
					r.setBarData({
						text: "",
						type: "text"
					}, a[s]);
					break;
				case 15:
					r.setBarData(a[s - 1], a[s]);
					break;
				case 16:
					this.$ = a[s].trim(), r.setAccTitle(this.$);
					break;
				case 17:
				case 18:
					this.$ = a[s].trim(), r.setAccDescription(this.$);
					break;
				case 19:
					this.$ = a[s - 1];
					break;
				case 20:
				case 30:
					this.$ = [a[s - 2], ...a[s]];
					break;
				case 21:
				case 31:
					this.$ = [a[s]];
					break;
				case 22:
					this.$ = {
						value: Number(a[s - 1]),
						label: a[s]
					};
					break;
				case 23:
					this.$ = {
						value: Number(a[s]),
						label: ""
					};
					break;
				case 24:
					r.setXAxisTitle(a[s]);
					break;
				case 25:
					r.setXAxisTitle(a[s - 1]);
					break;
				case 26:
					r.setXAxisTitle({
						type: "text",
						text: ""
					});
					break;
				case 27:
					r.setXAxisBand(a[s]);
					break;
				case 28:
					r.setXAxisRangeData(Number(a[s - 2]), Number(a[s]));
					break;
				case 29:
					this.$ = a[s - 1];
					break;
				case 32:
					r.setYAxisTitle(a[s]);
					break;
				case 33:
					r.setYAxisTitle(a[s - 1]);
					break;
				case 34:
					r.setYAxisTitle({
						type: "text",
						text: ""
					});
					break;
				case 35:
					r.setYAxisRangeData(Number(a[s - 2]), Number(a[s]));
					break;
				case 39:
					this.$ = {
						text: a[s],
						type: "text"
					};
					break;
				case 40:
					this.$ = {
						text: a[s],
						type: "text"
					};
					break;
				case 41:
					this.$ = {
						text: a[s],
						type: "markdown"
					};
					break;
				case 42:
					this.$ = a[s];
					break;
				case 43: this.$ = a[s - 1] + "" + a[s];
			}
		}, "anonymous"),
		table: [
			e(t, n, {
				3: 1,
				4: 2,
				7: 4,
				5: r,
				36: i,
				37: a,
				38: o
			}),
			{ 1: [3] },
			e(t, n, {
				4: 2,
				7: 4,
				3: 8,
				5: r,
				36: i,
				37: a,
				38: o
			}),
			e(t, n, {
				4: 2,
				7: 4,
				6: 9,
				3: 10,
				5: r,
				8: [1, 11],
				36: i,
				37: a,
				38: o
			}),
			{
				1: [2, 4],
				9: 12,
				10: [1, 13],
				12: [1, 14],
				14: [1, 15],
				16: [1, 16],
				18: [1, 17],
				19: [1, 18],
				21: [1, 19],
				23: [1, 20]
			},
			e(s, [2, 36]),
			e(s, [2, 37]),
			e(s, [2, 38]),
			{ 1: [2, 1] },
			e(t, n, {
				4: 2,
				7: 4,
				3: 21,
				5: r,
				36: i,
				37: a,
				38: o
			}),
			{ 1: [2, 3] },
			e(s, [2, 5]),
			e(t, [2, 7], {
				4: 22,
				36: i,
				37: a,
				38: o
			}),
			{
				11: 23,
				30: c,
				39: 24,
				40: l,
				41: 27,
				42: u,
				43: d,
				44: f,
				45: p,
				46: m,
				47: h,
				48: g,
				49: _,
				50: v,
				51: y
			},
			{
				11: 39,
				13: 38,
				24: b,
				29: S,
				30: c,
				31: 40,
				32: 41,
				39: 24,
				40: l,
				41: 27,
				42: u,
				43: d,
				44: f,
				45: p,
				46: m,
				47: h,
				48: g,
				49: _,
				50: v,
				51: y
			},
			{
				11: 45,
				15: 44,
				29: C,
				30: c,
				35: 46,
				39: 24,
				40: l,
				41: 27,
				42: u,
				43: d,
				44: f,
				45: p,
				46: m,
				47: h,
				48: g,
				49: _,
				50: v,
				51: y
			},
			{
				11: 49,
				17: 48,
				24: w,
				30: c,
				39: 24,
				40: l,
				41: 27,
				42: u,
				43: d,
				44: f,
				45: p,
				46: m,
				47: h,
				48: g,
				49: _,
				50: v,
				51: y
			},
			{
				11: 52,
				17: 51,
				24: w,
				30: c,
				39: 24,
				40: l,
				41: 27,
				42: u,
				43: d,
				44: f,
				45: p,
				46: m,
				47: h,
				48: g,
				49: _,
				50: v,
				51: y
			},
			{ 20: [1, 53] },
			{ 22: [1, 54] },
			e(T, [2, 18]),
			{ 1: [2, 2] },
			e(T, [2, 8]),
			e(T, [2, 9]),
			e(E, [2, 39], {
				41: 55,
				42: u,
				43: d,
				44: f,
				45: p,
				46: m,
				47: h,
				48: g,
				49: _,
				50: v,
				51: y
			}),
			e(E, [2, 40]),
			e(E, [2, 41]),
			e(D, [2, 42]),
			e(D, [2, 44]),
			e(D, [2, 45]),
			e(D, [2, 46]),
			e(D, [2, 47]),
			e(D, [2, 48]),
			e(D, [2, 49]),
			e(D, [2, 50]),
			e(D, [2, 51]),
			e(D, [2, 52]),
			e(D, [2, 53]),
			e(T, [2, 10]),
			e(T, [2, 24], {
				32: 41,
				31: 56,
				24: b,
				29: S
			}),
			e(T, [2, 26]),
			e(T, [2, 27]),
			{ 33: [1, 57] },
			{
				11: 59,
				30: c,
				34: 58,
				39: 24,
				40: l,
				41: 27,
				42: u,
				43: d,
				44: f,
				45: p,
				46: m,
				47: h,
				48: g,
				49: _,
				50: v,
				51: y
			},
			e(T, [2, 11]),
			e(T, [2, 32], {
				35: 60,
				29: C
			}),
			e(T, [2, 34]),
			{ 33: [1, 61] },
			e(T, [2, 12]),
			{
				17: 62,
				24: w
			},
			{
				25: 63,
				27: 64,
				29: O
			},
			e(T, [2, 14]),
			{
				17: 66,
				24: w
			},
			e(T, [2, 16]),
			e(T, [2, 17]),
			e(D, [2, 43]),
			e(T, [2, 25]),
			{ 29: [1, 67] },
			{ 26: [1, 68] },
			{
				26: [2, 31],
				28: [1, 69]
			},
			e(T, [2, 33]),
			{ 29: [1, 70] },
			e(T, [2, 13]),
			{ 26: [1, 71] },
			{
				26: [2, 21],
				28: [1, 72]
			},
			e(k, [2, 23], { 30: [1, 73] }),
			e(T, [2, 15]),
			e(T, [2, 28]),
			e(T, [2, 29]),
			{
				11: 59,
				30: c,
				34: 74,
				39: 24,
				40: l,
				41: 27,
				42: u,
				43: d,
				44: f,
				45: p,
				46: m,
				47: h,
				48: g,
				49: _,
				50: v,
				51: y
			},
			e(T, [2, 35]),
			e(T, [2, 19]),
			{
				25: 75,
				27: 64,
				29: O
			},
			e(k, [2, 22]),
			{ 26: [2, 30] },
			{ 26: [2, 20] }
		],
		defaultActions: {
			8: [2, 1],
			10: [2, 3],
			21: [2, 2],
			74: [2, 30],
			75: [2, 20]
		},
		parseError: /* @__PURE__ */ x(function(e, t) {
			if (t.recoverable) this.trace(e);
			else {
				var n = Error(e);
				throw n.hash = t, n;
			}
		}, "parseError"),
		parse: /* @__PURE__ */ x(function(e) {
			var t = this, n = [0], r = [], i = [null], a = [], o = this.table, s = "", c = 0, l = 0, u = 2, d = 1, f = a.slice.call(arguments, 1), p = Object.create(this.lexer), m = { yy: {} };
			for (var h in this.yy) Object.prototype.hasOwnProperty.call(this.yy, h) && (m.yy[h] = this.yy[h]);
			p.setInput(e, m.yy), m.yy.lexer = p, m.yy.parser = this, typeof p.yylloc > "u" && (p.yylloc = {});
			var g = p.yylloc;
			a.push(g);
			var _ = p.options && p.options.ranges;
			this.parseError = typeof m.yy.parseError == "function" ? m.yy.parseError : Object.getPrototypeOf(this).parseError;
			function v(e) {
				n.length -= 2 * e, i.length -= e, a.length -= e;
			}
			x(v, "popStack");
			function y() {
				var e;
				return e = r.pop() || p.lex() || d, typeof e != "number" && (e instanceof Array && (r = e, e = r.pop()), e = t.symbols_[e] || e), e;
			}
			x(y, "lex");
			for (var b, S, C, w, T = {}, E, D, O, k;;) {
				if (S = n[n.length - 1], this.defaultActions[S] ? C = this.defaultActions[S] : ((b === null || typeof b > "u") && (b = y()), C = o[S] && o[S][b]), typeof C > "u" || !C.length || !C[0]) {
					var A = "";
					for (E in k = [], o[S]) this.terminals_[E] && E > u && k.push("'" + this.terminals_[E] + "'");
					A = p.showPosition ? "Parse error on line " + (c + 1) + ":\n" + p.showPosition() + "\nExpecting " + k.join(", ") + ", got '" + (this.terminals_[b] || b) + "'" : "Parse error on line " + (c + 1) + ": Unexpected " + (b == d ? "end of input" : "'" + (this.terminals_[b] || b) + "'"), this.parseError(A, {
						text: p.match,
						token: this.terminals_[b] || b,
						line: p.yylineno,
						loc: g,
						expected: k
					});
				}
				if (C[0] instanceof Array && C.length > 1) throw Error("Parse Error: multiple actions possible at state: " + S + ", token: " + b);
				switch (C[0]) {
					case 1:
						n.push(b), i.push(p.yytext), a.push(p.yylloc), n.push(C[1]), b = null, l = p.yyleng, s = p.yytext, c = p.yylineno, g = p.yylloc;
						break;
					case 2:
						if (D = this.productions_[C[1]][1], T.$ = i[i.length - D], T._$ = {
							first_line: a[a.length - (D || 1)].first_line,
							last_line: a[a.length - 1].last_line,
							first_column: a[a.length - (D || 1)].first_column,
							last_column: a[a.length - 1].last_column
						}, _ && (T._$.range = [a[a.length - (D || 1)].range[0], a[a.length - 1].range[1]]), w = this.performAction.apply(T, [
							s,
							l,
							c,
							m.yy,
							C[1],
							i,
							a
						].concat(f)), typeof w < "u") return w;
						D && (n = n.slice(0, -1 * D * 2), i = i.slice(0, -1 * D), a = a.slice(0, -1 * D)), n.push(this.productions_[C[1]][0]), i.push(T.$), a.push(T._$), O = o[n[n.length - 2]][n[n.length - 1]], n.push(O);
						break;
					case 3: return !0;
				}
			}
			return !0;
		}, "parse")
	};
	A.lexer = /* @__PURE__ */ function() {
		return {
			EOF: 1,
			parseError: /* @__PURE__ */ x(function(e, t) {
				if (this.yy.parser) this.yy.parser.parseError(e, t);
				else throw Error(e);
			}, "parseError"),
			setInput: /* @__PURE__ */ x(function(e, t) {
				return this.yy = t || this.yy || {}, this._input = e, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
					first_line: 1,
					first_column: 0,
					last_line: 1,
					last_column: 0
				}, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
			}, "setInput"),
			input: /* @__PURE__ */ x(function() {
				var e = this._input[0];
				return this.yytext += e, this.yyleng++, this.offset++, this.match += e, this.matched += e, e.match(/(?:\r\n?|\n).*/g) ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), e;
			}, "input"),
			unput: /* @__PURE__ */ x(function(e) {
				var t = e.length, n = e.split(/(?:\r\n?|\n)/g);
				this._input = e + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - t), this.offset -= t;
				var r = this.match.split(/(?:\r\n?|\n)/g);
				this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), n.length - 1 && (this.yylineno -= n.length - 1);
				var i = this.yylloc.range;
				return this.yylloc = {
					first_line: this.yylloc.first_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.first_column,
					last_column: n ? (n.length === r.length ? this.yylloc.first_column : 0) + r[r.length - n.length].length - n[0].length : this.yylloc.first_column - t
				}, this.options.ranges && (this.yylloc.range = [i[0], i[0] + this.yyleng - t]), this.yyleng = this.yytext.length, this;
			}, "unput"),
			more: /* @__PURE__ */ x(function() {
				return this._more = !0, this;
			}, "more"),
			reject: /* @__PURE__ */ x(function() {
				if (this.options.backtrack_lexer) this._backtrack = !0;
				else return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
				return this;
			}, "reject"),
			less: /* @__PURE__ */ x(function(e) {
				this.unput(this.match.slice(e));
			}, "less"),
			pastInput: /* @__PURE__ */ x(function() {
				var e = this.matched.substr(0, this.matched.length - this.match.length);
				return (e.length > 20 ? "..." : "") + e.substr(-20).replace(/\n/g, "");
			}, "pastInput"),
			upcomingInput: /* @__PURE__ */ x(function() {
				var e = this.match;
				return e.length < 20 && (e += this._input.substr(0, 20 - e.length)), (e.substr(0, 20) + (e.length > 20 ? "..." : "")).replace(/\n/g, "");
			}, "upcomingInput"),
			showPosition: /* @__PURE__ */ x(function() {
				var e = this.pastInput(), t = Array(e.length + 1).join("-");
				return e + this.upcomingInput() + "\n" + t + "^";
			}, "showPosition"),
			test_match: /* @__PURE__ */ x(function(e, t) {
				var n, r, i;
				if (this.options.backtrack_lexer && (i = {
					yylineno: this.yylineno,
					yylloc: {
						first_line: this.yylloc.first_line,
						last_line: this.last_line,
						first_column: this.yylloc.first_column,
						last_column: this.yylloc.last_column
					},
					yytext: this.yytext,
					match: this.match,
					matches: this.matches,
					matched: this.matched,
					yyleng: this.yyleng,
					offset: this.offset,
					_more: this._more,
					_input: this._input,
					yy: this.yy,
					conditionStack: this.conditionStack.slice(0),
					done: this.done
				}, this.options.ranges && (i.yylloc.range = this.yylloc.range.slice(0))), r = e[0].match(/(?:\r\n?|\n).*/g), r && (this.yylineno += r.length), this.yylloc = {
					first_line: this.yylloc.last_line,
					last_line: this.yylineno + 1,
					first_column: this.yylloc.last_column,
					last_column: r ? r[r.length - 1].length - r[r.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + e[0].length
				}, this.yytext += e[0], this.match += e[0], this.matches = e, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(e[0].length), this.matched += e[0], n = this.performAction.call(this, this.yy, this, t, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), n) return n;
				if (this._backtrack) {
					for (var a in i) this[a] = i[a];
					return !1;
				}
				return !1;
			}, "test_match"),
			next: /* @__PURE__ */ x(function() {
				if (this.done) return this.EOF;
				this._input || (this.done = !0);
				var e, t, n, r;
				this._more || (this.yytext = "", this.match = "");
				for (var i = this._currentRules(), a = 0; a < i.length; a++) if (n = this._input.match(this.rules[i[a]]), n && (!t || n[0].length > t[0].length)) {
					if (t = n, r = a, this.options.backtrack_lexer) {
						if (e = this.test_match(n, i[a]), e !== !1) return e;
						if (this._backtrack) {
							t = !1;
							continue;
						}
						return !1;
					}
					if (!this.options.flex) break;
				}
				return t ? (e = this.test_match(t, i[r]), e !== !1 && e) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
					text: "",
					token: null,
					line: this.yylineno
				});
			}, "next"),
			lex: /* @__PURE__ */ x(function() {
				return this.next() || this.lex();
			}, "lex"),
			begin: /* @__PURE__ */ x(function(e) {
				this.conditionStack.push(e);
			}, "begin"),
			popState: /* @__PURE__ */ x(function() {
				return this.conditionStack.length - 1 > 0 ? this.conditionStack.pop() : this.conditionStack[0];
			}, "popState"),
			_currentRules: /* @__PURE__ */ x(function() {
				return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
			}, "_currentRules"),
			topState: /* @__PURE__ */ x(function(e) {
				return e = this.conditionStack.length - 1 - Math.abs(e || 0), e >= 0 ? this.conditionStack[e] : "INITIAL";
			}, "topState"),
			pushState: /* @__PURE__ */ x(function(e) {
				this.begin(e);
			}, "pushState"),
			stateStackSize: /* @__PURE__ */ x(function() {
				return this.conditionStack.length;
			}, "stateStackSize"),
			options: { "case-insensitive": !0 },
			performAction: /* @__PURE__ */ x(function(e, t, n, r) {
				switch (n) {
					case 0: break;
					case 1: break;
					case 2: return this.popState(), 36;
					case 3: return this.popState(), 36;
					case 4: return 36;
					case 5: break;
					case 6: return 10;
					case 7: return this.pushState("acc_title"), 19;
					case 8: return this.popState(), "acc_title_value";
					case 9: return this.pushState("acc_descr"), 21;
					case 10: return this.popState(), "acc_descr_value";
					case 11:
						this.pushState("acc_descr_multiline");
						break;
					case 12:
						this.popState();
						break;
					case 13: return "acc_descr_multiline_value";
					case 14: return 5;
					case 15: return 5;
					case 16: return 8;
					case 17: return this.pushState("axis_data"), "X_AXIS";
					case 18: return this.pushState("axis_data"), "Y_AXIS";
					case 19: return this.pushState("axis_band_data"), 24;
					case 20: return 33;
					case 21: return this.pushState("data"), 16;
					case 22: return this.pushState("data"), 18;
					case 23: return this.pushState("data_inner"), 24;
					case 24: return 29;
					case 25: return this.popState(), 26;
					case 26:
						this.popState();
						break;
					case 27:
						this.pushState("string");
						break;
					case 28:
						this.popState();
						break;
					case 29: return "STR";
					case 30: return 24;
					case 31: return 26;
					case 32: return 44;
					case 33: return "COLON";
					case 34: return 45;
					case 35: return 28;
					case 36: return 46;
					case 37: return 47;
					case 38: return 49;
					case 39: return 51;
					case 40: return 48;
					case 41: return 42;
					case 42: return 50;
					case 43: return 43;
					case 44: break;
					case 45: return 37;
					case 46: return 38;
				}
			}, "anonymous"),
			rules: [
				/^(?:%%(?!\{)[^\n]*)/i,
				/^(?:[^\}]%%[^\n]*)/i,
				/^(?:(\r?\n))/i,
				/^(?:(\r?\n))/i,
				/^(?:[\n\r]+)/i,
				/^(?:%%[^\n]*)/i,
				/^(?:title\b)/i,
				/^(?:accTitle\s*:\s*)/i,
				/^(?:(?!\n||)*[^\n]*)/i,
				/^(?:accDescr\s*:\s*)/i,
				/^(?:(?!\n||)*[^\n]*)/i,
				/^(?:accDescr\s*\{\s*)/i,
				/^(?:\})/i,
				/^(?:[^\}]*)/i,
				/^(?:xychart-beta\b)/i,
				/^(?:xychart\b)/i,
				/^(?:(?:vertical|horizontal))/i,
				/^(?:x-axis\b)/i,
				/^(?:y-axis\b)/i,
				/^(?:\[)/i,
				/^(?:-->)/i,
				/^(?:line\b)/i,
				/^(?:bar\b)/i,
				/^(?:\[)/i,
				/^(?:[+-]?(?:\d+(?:\.\d+)?|\.\d+))/i,
				/^(?:\])/i,
				/^(?:(?:`\)                                    \{ this\.pushState\(md_string\); \}\n<md_string>\(\?:\(\?!`"\)\.\)\+                  \{ return MD_STR; \}\n<md_string>\(\?:`))/i,
				/^(?:["])/i,
				/^(?:["])/i,
				/^(?:[^"]*)/i,
				/^(?:\[)/i,
				/^(?:\])/i,
				/^(?:[A-Za-z]+)/i,
				/^(?::)/i,
				/^(?:\+)/i,
				/^(?:,)/i,
				/^(?:=)/i,
				/^(?:\*)/i,
				/^(?:#)/i,
				/^(?:[\_])/i,
				/^(?:\.)/i,
				/^(?:&)/i,
				/^(?:-)/i,
				/^(?:[0-9]+)/i,
				/^(?:\s+)/i,
				/^(?:;)/i,
				/^(?:$)/i
			],
			conditions: {
				data_inner: {
					rules: [
						0,
						1,
						4,
						5,
						6,
						7,
						9,
						11,
						14,
						15,
						16,
						17,
						18,
						21,
						22,
						24,
						25,
						26,
						27,
						30,
						31,
						32,
						33,
						34,
						35,
						36,
						37,
						38,
						39,
						40,
						41,
						42,
						43,
						44,
						45,
						46
					],
					inclusive: !0
				},
				data: {
					rules: [
						0,
						1,
						3,
						4,
						5,
						6,
						7,
						9,
						11,
						14,
						15,
						16,
						17,
						18,
						21,
						22,
						23,
						26,
						27,
						30,
						31,
						32,
						33,
						34,
						35,
						36,
						37,
						38,
						39,
						40,
						41,
						42,
						43,
						44,
						45,
						46
					],
					inclusive: !0
				},
				axis_band_data: {
					rules: [
						0,
						1,
						4,
						5,
						6,
						7,
						9,
						11,
						14,
						15,
						16,
						17,
						18,
						21,
						22,
						25,
						26,
						27,
						30,
						31,
						32,
						33,
						34,
						35,
						36,
						37,
						38,
						39,
						40,
						41,
						42,
						43,
						44,
						45,
						46
					],
					inclusive: !0
				},
				axis_data: {
					rules: [
						0,
						1,
						2,
						4,
						5,
						6,
						7,
						9,
						11,
						14,
						15,
						16,
						17,
						18,
						19,
						20,
						21,
						22,
						24,
						26,
						27,
						30,
						31,
						32,
						33,
						34,
						35,
						36,
						37,
						38,
						39,
						40,
						41,
						42,
						43,
						44,
						45,
						46
					],
					inclusive: !0
				},
				acc_descr_multiline: {
					rules: [12, 13],
					inclusive: !1
				},
				acc_descr: {
					rules: [10],
					inclusive: !1
				},
				acc_title: {
					rules: [8],
					inclusive: !1
				},
				title: {
					rules: [],
					inclusive: !1
				},
				md_string: {
					rules: [],
					inclusive: !1
				},
				string: {
					rules: [28, 29],
					inclusive: !1
				},
				INITIAL: {
					rules: [
						0,
						1,
						4,
						5,
						6,
						7,
						9,
						11,
						14,
						15,
						16,
						17,
						18,
						21,
						22,
						26,
						27,
						30,
						31,
						32,
						33,
						34,
						35,
						36,
						37,
						38,
						39,
						40,
						41,
						42,
						43,
						44,
						45,
						46
					],
					inclusive: !0
				}
			}
		};
	}();
	function j() {
		this.yy = {};
	}
	return x(j, "Parser"), j.prototype = A, A.Parser = j, new j();
}();
C.parser = C;
var w = C;
function T(e) {
	return e.type === "bar";
}
x(T, "isBarPlot");
function E(e) {
	return e.type === "band";
}
x(E, "isBandAxisData");
function D(e) {
	return e.type === "linear";
}
x(D, "isLinearAxisData");
var O, k = (O = class {
	constructor(e) {
		this.parentGroup = e;
	}
	getMaxDimension(e, t) {
		if (!this.parentGroup) return {
			width: e.reduce((e, t) => Math.max(t.length, e), 0) * t,
			height: t
		};
		let n = {
			width: 0,
			height: 0
		}, r = this.parentGroup.append("g").attr("visibility", "hidden").attr("font-size", t);
		for (let i of e) {
			let e = o(r, 1, i), a = e ? e.width : i.length * t, s = e ? e.height : t;
			n.width = Math.max(n.width, a), n.height = Math.max(n.height, s);
		}
		return r.remove(), n;
	}
}, x(O, "TextDimensionCalculatorWithFont"), O), A = .7, j = .2, M, ee = (M = class {
	constructor(e, t, n, r) {
		this.axisConfig = e, this.title = t, this.textDimensionCalculator = n, this.axisThemeConfig = r, this.boundingRect = {
			x: 0,
			y: 0,
			width: 0,
			height: 0
		}, this.axisPosition = "left", this.showTitle = !1, this.showLabel = !1, this.showTick = !1, this.showAxisLine = !1, this.outerPadding = 0, this.titleTextHeight = 0, this.labelTextHeight = 0, this.normalizedLabelRotationInRad = 0, this.range = [0, 10], this.boundingRect = {
			x: 0,
			y: 0,
			width: 0,
			height: 0
		}, this.axisPosition = "left", this.normalizedLabelRotationInRad = this.axisConfig.labelRotation >= -90 && this.axisConfig.labelRotation <= 90 ? this.axisConfig.labelRotation * Math.PI / 180 : 0;
	}
	setRange(e) {
		this.range = e, this.axisPosition === "left" || this.axisPosition === "right" ? this.boundingRect.height = e[1] - e[0] : this.boundingRect.width = e[1] - e[0], this.recalculateScale();
	}
	getRange() {
		return [this.range[0] + this.outerPadding, this.range[1] - this.outerPadding];
	}
	setAxisPosition(e) {
		this.axisPosition = e, this.setRange(this.range);
	}
	getTickDistance() {
		let e = this.getRange();
		return Math.abs(e[0] - e[1]) / this.getTickValues().length;
	}
	getAxisOuterPadding() {
		return this.outerPadding;
	}
	getLabelDimension() {
		return this.textDimensionCalculator.getMaxDimension(this.getTickValues().map((e) => e.toString()), this.axisConfig.labelFontSize);
	}
	recalculateOuterPaddingToDrawBar() {
		A * this.getTickDistance() > this.outerPadding * 2 && (this.outerPadding = Math.floor(A * this.getTickDistance() / 2)), this.recalculateScale();
	}
	calculateSpaceIfDrawnHorizontally(e) {
		let t = e.height;
		if (this.axisConfig.showAxisLine && t > this.axisConfig.axisLineWidth && (t -= this.axisConfig.axisLineWidth, this.showAxisLine = !0), this.axisConfig.showLabel) {
			let n = this.getLabelDimension(), r = j * e.width;
			this.outerPadding = Math.min(n.width / 2, r);
			let i = n.height;
			this.axisPosition === "bottom" && this.normalizedLabelRotationInRad !== 0 && (i = Math.max(i, Math.abs(Math.sin(this.normalizedLabelRotationInRad) * n.width) + Math.abs(Math.cos(this.normalizedLabelRotationInRad) * n.height))), i += this.axisConfig.labelPadding * 2, this.labelTextHeight = n.height, i <= t && (t -= i, this.showLabel = !0);
		}
		if (this.axisConfig.showTick && t >= this.axisConfig.tickLength && (this.showTick = !0, t -= this.axisConfig.tickLength), this.axisConfig.showTitle && this.title) {
			let e = this.textDimensionCalculator.getMaxDimension([this.title], this.axisConfig.titleFontSize), n = e.height + this.axisConfig.titlePadding * 2;
			this.titleTextHeight = e.height, n <= t && (t -= n, this.showTitle = !0);
		}
		this.boundingRect.width = e.width, this.boundingRect.height = e.height - t;
	}
	calculateSpaceIfDrawnVertical(e) {
		let t = e.width;
		if (this.axisConfig.showAxisLine && t > this.axisConfig.axisLineWidth && (t -= this.axisConfig.axisLineWidth, this.showAxisLine = !0), this.axisConfig.showLabel) {
			let n = this.getLabelDimension(), r = j * e.height;
			this.outerPadding = Math.min(n.height / 2, r);
			let i = n.width + this.axisConfig.labelPadding * 2;
			i <= t && (t -= i, this.showLabel = !0);
		}
		if (this.axisConfig.showTick && t >= this.axisConfig.tickLength && (this.showTick = !0, t -= this.axisConfig.tickLength), this.axisConfig.showTitle && this.title) {
			let e = this.textDimensionCalculator.getMaxDimension([this.title], this.axisConfig.titleFontSize), n = e.height + this.axisConfig.titlePadding * 2;
			this.titleTextHeight = e.height, n <= t && (t -= n, this.showTitle = !0);
		}
		this.boundingRect.width = e.width - t, this.boundingRect.height = e.height;
	}
	calculateSpace(e) {
		return this.axisPosition === "left" || this.axisPosition === "right" ? this.calculateSpaceIfDrawnVertical(e) : this.calculateSpaceIfDrawnHorizontally(e), this.recalculateScale(), {
			width: this.boundingRect.width,
			height: this.boundingRect.height
		};
	}
	setBoundingBoxXY(e) {
		this.boundingRect.x = e.x, this.boundingRect.y = e.y;
	}
	calculateOffsetByRotation(e) {
		let t = this.normalizedLabelRotationInRad;
		return t === 0 ? 0 : Math.sin(t) * this.getLabelDimension()[e] / 2;
	}
	getDrawableElementsForLeftAxis() {
		let e = [];
		if (this.showAxisLine) {
			let t = this.boundingRect.x + this.boundingRect.width - this.axisConfig.axisLineWidth / 2;
			e.push({
				type: "path",
				groupTexts: ["left-axis", "axisl-line"],
				data: [{
					path: `M ${t},${this.boundingRect.y} L ${t},${this.boundingRect.y + this.boundingRect.height} `,
					strokeFill: this.axisThemeConfig.axisLineColor,
					strokeWidth: this.axisConfig.axisLineWidth
				}]
			});
		}
		if (this.showLabel && e.push({
			type: "text",
			groupTexts: ["left-axis", "label"],
			data: this.getTickValues().map((e) => ({
				text: e.toString(),
				x: this.boundingRect.x + this.boundingRect.width - (this.showLabel ? this.axisConfig.labelPadding : 0) - (this.showTick ? this.axisConfig.tickLength : 0) - (this.showAxisLine ? this.axisConfig.axisLineWidth : 0),
				y: this.getScaleValue(e),
				fill: this.axisThemeConfig.labelColor,
				fontSize: this.axisConfig.labelFontSize,
				rotation: 0,
				verticalPos: "middle",
				horizontalPos: "right"
			}))
		}), this.showTick) {
			let t = this.boundingRect.x + this.boundingRect.width - (this.showAxisLine ? this.axisConfig.axisLineWidth : 0);
			e.push({
				type: "path",
				groupTexts: ["left-axis", "ticks"],
				data: this.getTickValues().map((e) => ({
					path: `M ${t},${this.getScaleValue(e)} L ${t - this.axisConfig.tickLength},${this.getScaleValue(e)}`,
					strokeFill: this.axisThemeConfig.tickColor,
					strokeWidth: this.axisConfig.tickWidth
				}))
			});
		}
		return this.showTitle && e.push({
			type: "text",
			groupTexts: ["left-axis", "title"],
			data: [{
				text: this.title,
				x: this.boundingRect.x + this.axisConfig.titlePadding,
				y: this.boundingRect.y + this.boundingRect.height / 2,
				fill: this.axisThemeConfig.titleColor,
				fontSize: this.axisConfig.titleFontSize,
				rotation: 270,
				verticalPos: "top",
				horizontalPos: "center"
			}]
		}), e;
	}
	getDrawableElementsForBottomAxis() {
		let e = [];
		if (this.showAxisLine) {
			let t = this.boundingRect.y + this.axisConfig.axisLineWidth / 2;
			e.push({
				type: "path",
				groupTexts: ["bottom-axis", "axis-line"],
				data: [{
					path: `M ${this.boundingRect.x},${t} L ${this.boundingRect.x + this.boundingRect.width},${t}`,
					strokeFill: this.axisThemeConfig.axisLineColor,
					strokeWidth: this.axisConfig.axisLineWidth
				}]
			});
		}
		if (this.showLabel && e.push({
			type: "text",
			groupTexts: ["bottom-axis", "label"],
			data: this.getTickValues().map((e) => ({
				text: e.toString(),
				x: this.getScaleValue(e) + this.calculateOffsetByRotation("height"),
				y: this.boundingRect.y + this.axisConfig.labelPadding + (this.showTick ? this.axisConfig.tickLength : 0) + (this.showAxisLine ? this.axisConfig.axisLineWidth : 0) + Math.abs(this.calculateOffsetByRotation("width")),
				fill: this.axisThemeConfig.labelColor,
				fontSize: this.axisConfig.labelFontSize,
				rotation: this.normalizedLabelRotationInRad * 180 / Math.PI,
				verticalPos: "top",
				horizontalPos: "center"
			}))
		}), this.showTick) {
			let t = this.boundingRect.y + (this.showAxisLine ? this.axisConfig.axisLineWidth : 0);
			e.push({
				type: "path",
				groupTexts: ["bottom-axis", "ticks"],
				data: this.getTickValues().map((e) => ({
					path: `M ${this.getScaleValue(e)},${t} L ${this.getScaleValue(e)},${t + this.axisConfig.tickLength}`,
					strokeFill: this.axisThemeConfig.tickColor,
					strokeWidth: this.axisConfig.tickWidth
				}))
			});
		}
		return this.showTitle && e.push({
			type: "text",
			groupTexts: ["bottom-axis", "title"],
			data: [{
				text: this.title,
				x: this.range[0] + (this.range[1] - this.range[0]) / 2,
				y: this.boundingRect.y + this.boundingRect.height - this.axisConfig.titlePadding - this.titleTextHeight,
				fill: this.axisThemeConfig.titleColor,
				fontSize: this.axisConfig.titleFontSize,
				rotation: 0,
				verticalPos: "top",
				horizontalPos: "center"
			}]
		}), e;
	}
	getDrawableElementsForTopAxis() {
		let e = [];
		if (this.showAxisLine) {
			let t = this.boundingRect.y + this.boundingRect.height - this.axisConfig.axisLineWidth / 2;
			e.push({
				type: "path",
				groupTexts: ["top-axis", "axis-line"],
				data: [{
					path: `M ${this.boundingRect.x},${t} L ${this.boundingRect.x + this.boundingRect.width},${t}`,
					strokeFill: this.axisThemeConfig.axisLineColor,
					strokeWidth: this.axisConfig.axisLineWidth
				}]
			});
		}
		if (this.showLabel && e.push({
			type: "text",
			groupTexts: ["top-axis", "label"],
			data: this.getTickValues().map((e) => ({
				text: e.toString(),
				x: this.getScaleValue(e),
				y: this.boundingRect.y + (this.showTitle ? this.titleTextHeight + this.axisConfig.titlePadding * 2 : 0) + this.axisConfig.labelPadding,
				fill: this.axisThemeConfig.labelColor,
				fontSize: this.axisConfig.labelFontSize,
				rotation: 0,
				verticalPos: "top",
				horizontalPos: "center"
			}))
		}), this.showTick) {
			let t = this.boundingRect.y;
			e.push({
				type: "path",
				groupTexts: ["top-axis", "ticks"],
				data: this.getTickValues().map((e) => ({
					path: `M ${this.getScaleValue(e)},${t + this.boundingRect.height - (this.showAxisLine ? this.axisConfig.axisLineWidth : 0)} L ${this.getScaleValue(e)},${t + this.boundingRect.height - this.axisConfig.tickLength - (this.showAxisLine ? this.axisConfig.axisLineWidth : 0)}`,
					strokeFill: this.axisThemeConfig.tickColor,
					strokeWidth: this.axisConfig.tickWidth
				}))
			});
		}
		return this.showTitle && e.push({
			type: "text",
			groupTexts: ["top-axis", "title"],
			data: [{
				text: this.title,
				x: this.boundingRect.x + this.boundingRect.width / 2,
				y: this.boundingRect.y + this.axisConfig.titlePadding,
				fill: this.axisThemeConfig.titleColor,
				fontSize: this.axisConfig.titleFontSize,
				rotation: 0,
				verticalPos: "top",
				horizontalPos: "center"
			}]
		}), e;
	}
	getDrawableElements() {
		if (this.axisPosition === "left") return this.getDrawableElementsForLeftAxis();
		if (this.axisPosition === "right") throw Error("Drawing of right axis is not implemented");
		return this.axisPosition === "bottom" ? this.getDrawableElementsForBottomAxis() : this.axisPosition === "top" ? this.getDrawableElementsForTopAxis() : [];
	}
}, x(M, "BaseAxis"), M), N, te = (N = class extends ee {
	constructor(e, t, n, r, i) {
		super(e, r, i, t), this.categories = n, this.scale = S().domain(this.categories).range(this.getRange());
	}
	setRange(e) {
		super.setRange(e);
	}
	recalculateScale() {
		this.scale = S().domain(this.categories).range(this.getRange()).paddingInner(1).paddingOuter(0).align(.5), h.trace("BandAxis axis final categories, range: ", this.categories, this.getRange());
	}
	getTickValues() {
		return this.categories;
	}
	getScaleValue(e) {
		return this.scale(e) ?? this.getRange()[0];
	}
}, x(N, "BandAxis"), N), P, ne = (P = class extends ee {
	constructor(e, n, r, i, a) {
		super(e, i, a, n), this.domain = r, this.scale = t().domain(this.domain).range(this.getRange());
	}
	getTickValues() {
		return this.scale.ticks();
	}
	recalculateScale() {
		let e = [...this.domain];
		this.axisPosition === "left" && e.reverse(), this.scale = t().domain(e).range(this.getRange());
	}
	getScaleValue(e) {
		return this.scale(e);
	}
}, x(P, "LinearAxis"), P);
function F(e, t, n, r) {
	let i = new k(r);
	return E(e) ? new te(t, n, e.categories, e.title, i) : new ne(t, n, [e.min, e.max], e.title, i);
}
x(F, "getAxis");
var I, re = (I = class {
	constructor(e, t, n, r) {
		this.textDimensionCalculator = e, this.chartConfig = t, this.chartData = n, this.chartThemeConfig = r, this.boundingRect = {
			x: 0,
			y: 0,
			width: 0,
			height: 0
		}, this.showChartTitle = !1;
	}
	setBoundingBoxXY(e) {
		this.boundingRect.x = e.x, this.boundingRect.y = e.y;
	}
	calculateSpace(e) {
		let t = this.textDimensionCalculator.getMaxDimension([this.chartData.title], this.chartConfig.titleFontSize), n = Math.max(t.width, e.width), r = t.height + 2 * this.chartConfig.titlePadding;
		return t.width <= n && t.height <= r && this.chartConfig.showTitle && this.chartData.title && (this.boundingRect.width = n, this.boundingRect.height = r, this.showChartTitle = !0), {
			width: this.boundingRect.width,
			height: this.boundingRect.height
		};
	}
	getDrawableElements() {
		let e = [];
		return this.showChartTitle && e.push({
			groupTexts: ["chart-title"],
			type: "text",
			data: [{
				fontSize: this.chartConfig.titleFontSize,
				text: this.chartData.title,
				verticalPos: "middle",
				horizontalPos: "center",
				x: this.boundingRect.x + this.boundingRect.width / 2,
				y: this.boundingRect.y + this.boundingRect.height / 2,
				fill: this.chartThemeConfig.titleColor,
				rotation: 0
			}]
		}), e;
	}
}, x(I, "ChartTitle"), I);
function ie(e, t, n, r) {
	return new re(new k(r), e, t, n);
}
x(ie, "getChartTitleComponent");
var ae = .75, oe = .5, se = .35;
function L(e) {
	return {
		fontSize: e,
		markerSize: e * ae,
		markerSpacing: e * se,
		itemSpacing: e * oe
	};
}
x(L, "getLegendLayout");
var R, ce = (R = class {
	constructor(e, t, n, r) {
		this.textDimensionCalculator = e, this.chartConfig = t, this.chartData = n, this.chartThemeConfig = r, this.boundingRect = {
			x: 0,
			y: 0,
			width: 0,
			height: 0
		}, this.visiblePlots = [];
	}
	setBoundingBoxXY(e) {
		this.boundingRect.x = e.x, this.boundingRect.y = e.y;
	}
	calculateSpace(e) {
		if (this.visiblePlots = this.chartConfig.showLegend ? this.chartData.plots.filter((e) => e.title) : [], this.visiblePlots.length === 0) return this.boundingRect.width = 0, this.boundingRect.height = 0, {
			width: 0,
			height: 0
		};
		let { fontSize: t, markerSize: n, markerSpacing: r, itemSpacing: i } = L(this.chartConfig.legendFontSize), a = this.textDimensionCalculator.getMaxDimension(this.visiblePlots.map((e) => e.title), t), o = this.chartConfig.legendPadding * 2 + n + r + a.width, s = this.chartConfig.legendPadding * 2 + this.visiblePlots.length * t + (this.visiblePlots.length - 1) * i;
		return o <= e.width && s <= e.height ? (this.boundingRect.width = o, this.boundingRect.height = s) : (this.visiblePlots = [], this.boundingRect.width = 0, this.boundingRect.height = 0), {
			width: this.boundingRect.width,
			height: this.boundingRect.height
		};
	}
	getDrawableElements() {
		if (this.visiblePlots.length === 0) return [];
		let { fontSize: e, markerSize: t, markerSpacing: n, itemSpacing: r } = L(this.chartConfig.legendFontSize), i = e + r, a = this.boundingRect.x + this.chartConfig.legendPadding, o = this.boundingRect.y + this.chartConfig.legendPadding, s = [], c = [];
		for (let [e, n] of this.visiblePlots.entries()) if (T(n)) s.push({
			x: a,
			y: o + e * i,
			width: t,
			height: t,
			fill: n.fill,
			strokeFill: n.fill,
			strokeWidth: 0
		});
		else {
			let r = o + e * i + t / 2;
			c.push({
				path: `M ${a},${r} L ${a + t},${r}`,
				strokeFill: n.strokeFill,
				strokeWidth: n.strokeWidth
			});
		}
		return [
			{
				groupTexts: ["legend", "markers"],
				type: "rect",
				data: s
			},
			{
				groupTexts: ["legend", "markers"],
				type: "path",
				data: c
			},
			{
				groupTexts: ["legend", "label"],
				type: "text",
				data: this.visiblePlots.map((r, s) => ({
					text: r.title,
					x: a + t + n,
					y: o + s * i + t / 2,
					fill: this.chartThemeConfig.legendTextColor,
					fontSize: e,
					rotation: 0,
					verticalPos: "middle",
					horizontalPos: "left"
				}))
			}
		];
	}
}, x(R, "ChartLegend"), R);
function le(e, t, n, r) {
	return new ce(new k(r), e, t, n);
}
x(le, "getChartLegendComponent");
var z, ue = (z = class {
	constructor(e, t, n, r, i) {
		this.plotData = e, this.xAxis = t, this.yAxis = n, this.orientation = r, this.plotIndex = i;
	}
	getDrawableElement() {
		let e = this.plotData.data.map((e) => [this.xAxis.getScaleValue(e[0]), this.yAxis.getScaleValue(e[1])]), t;
		if (t = this.orientation === "horizontal" ? m().y((e) => e[0]).x((e) => e[1])(e) : m().x((e) => e[0]).y((e) => e[1])(e), !t) return [];
		let n = [{
			groupTexts: ["plot", `line-plot-${this.plotIndex}`],
			type: "path",
			data: [{
				path: t,
				strokeFill: this.plotData.strokeFill,
				strokeWidth: this.plotData.strokeWidth
			}]
		}];
		if (this.plotData.pointLabels && this.plotData.pointLabels.length > 0) {
			let t = [];
			for (let [n, [r, i]] of e.entries()) {
				let e = this.plotData.pointLabels[n];
				e && (this.orientation === "horizontal" ? t.push({
					x: i + 10,
					y: r,
					text: e,
					fill: this.plotData.strokeFill,
					verticalPos: "middle",
					horizontalPos: "left",
					fontSize: 12,
					rotation: 0
				}) : t.push({
					x: r,
					y: i - 10,
					text: e,
					fill: this.plotData.strokeFill,
					verticalPos: "middle",
					horizontalPos: "center",
					fontSize: 12,
					rotation: 0
				}));
			}
			t.length > 0 && n.push({
				groupTexts: [
					"plot",
					`line-plot-${this.plotIndex}`,
					"labels"
				],
				type: "text",
				data: t
			});
		}
		return n;
	}
}, x(z, "LinePlot"), z), B, de = (B = class {
	constructor(e, t, n, r, i, a) {
		this.barData = e, this.boundingRect = t, this.xAxis = n, this.yAxis = r, this.orientation = i, this.plotIndex = a;
	}
	getDrawableElement() {
		let e = this.barData.data.map((e) => [this.xAxis.getScaleValue(e[0]), this.yAxis.getScaleValue(e[1])]), t = Math.min(this.xAxis.getAxisOuterPadding() * 2, this.xAxis.getTickDistance()) * .95, n = t / 2;
		return this.orientation === "horizontal" ? [{
			groupTexts: ["plot", `bar-plot-${this.plotIndex}`],
			type: "rect",
			data: e.map((e) => ({
				x: this.boundingRect.x,
				y: e[0] - n,
				height: t,
				width: e[1] - this.boundingRect.x,
				fill: this.barData.fill,
				strokeWidth: 0,
				strokeFill: this.barData.fill
			}))
		}] : [{
			groupTexts: ["plot", `bar-plot-${this.plotIndex}`],
			type: "rect",
			data: e.map((e) => ({
				x: e[0] - n,
				y: e[1],
				width: t,
				height: this.boundingRect.y + this.boundingRect.height - e[1],
				fill: this.barData.fill,
				strokeWidth: 0,
				strokeFill: this.barData.fill
			}))
		}];
	}
}, x(B, "BarPlot"), B), V, fe = (V = class {
	constructor(e, t, n) {
		this.chartConfig = e, this.chartData = t, this.chartThemeConfig = n, this.boundingRect = {
			x: 0,
			y: 0,
			width: 0,
			height: 0
		};
	}
	setAxes(e, t) {
		this.xAxis = e, this.yAxis = t;
	}
	setBoundingBoxXY(e) {
		this.boundingRect.x = e.x, this.boundingRect.y = e.y;
	}
	calculateSpace(e) {
		return this.boundingRect.width = e.width, this.boundingRect.height = e.height, {
			width: this.boundingRect.width,
			height: this.boundingRect.height
		};
	}
	getDrawableElements() {
		if (!(this.xAxis && this.yAxis)) throw Error("Axes must be passed to render Plots");
		let e = [];
		for (let [t, n] of this.chartData.plots.entries()) switch (n.type) {
			case "line":
				{
					let r = new ue(n, this.xAxis, this.yAxis, this.chartConfig.chartOrientation, t);
					e.push(...r.getDrawableElement());
				}
				break;
			case "bar": {
				let r = new de(n, this.boundingRect, this.xAxis, this.yAxis, this.chartConfig.chartOrientation, t);
				e.push(...r.getDrawableElement());
			}
		}
		return e;
	}
}, x(V, "BasePlot"), V);
function pe(e, t, n) {
	return new fe(e, t, n);
}
x(pe, "getPlotComponent");
var H, me = (H = class {
	constructor(e, t, n, r) {
		this.chartConfig = e, this.chartData = t, this.componentStore = {
			title: ie(e, t, n, r),
			plot: pe(e, t, n),
			legend: le(e, t, n, r),
			xAxis: F(t.xAxis, e.xAxis, {
				titleColor: n.xAxisTitleColor,
				labelColor: n.xAxisLabelColor,
				tickColor: n.xAxisTickColor,
				axisLineColor: n.xAxisLineColor
			}, r),
			yAxis: F(t.yAxis, e.yAxis, {
				titleColor: n.yAxisTitleColor,
				labelColor: n.yAxisLabelColor,
				tickColor: n.yAxisTickColor,
				axisLineColor: n.yAxisLineColor
			}, r)
		};
	}
	calculateVerticalSpace() {
		let e = this.chartConfig.width, t = this.chartConfig.height, n = 0, r = 0, i = {
			width: 0,
			height: 0
		}, a = Math.floor(e * this.chartConfig.plotReservedSpacePercent / 100), o = Math.floor(t * this.chartConfig.plotReservedSpacePercent / 100), s = this.componentStore.plot.calculateSpace({
			width: a,
			height: o
		});
		e -= s.width, t -= s.height, s = this.componentStore.title.calculateSpace({
			width: this.chartConfig.width,
			height: t
		}), r = s.height, t -= s.height, this.componentStore.xAxis.setAxisPosition("bottom"), s = this.componentStore.xAxis.calculateSpace({
			width: e,
			height: t
		}), t -= s.height, this.componentStore.yAxis.setAxisPosition("left"), s = this.componentStore.yAxis.calculateSpace({
			width: e,
			height: t
		}), n = s.width, e -= s.width, i = this.componentStore.legend.calculateSpace({
			width: e,
			height: o
		}), e -= i.width, e > 0 && (a += e, e = 0), t > 0 && (o += t, t = 0), this.componentStore.plot.calculateSpace({
			width: a,
			height: o
		}), this.componentStore.plot.setBoundingBoxXY({
			x: n,
			y: r
		}), this.componentStore.legend.setBoundingBoxXY({
			x: n + a,
			y: r + Math.max((o - i.height) / 2, 0)
		}), this.componentStore.xAxis.setRange([n, n + a]), this.componentStore.xAxis.setBoundingBoxXY({
			x: n,
			y: r + o
		}), this.componentStore.yAxis.setRange([r, r + o]), this.componentStore.yAxis.setBoundingBoxXY({
			x: 0,
			y: r
		}), this.chartData.plots.some((e) => T(e)) && this.componentStore.xAxis.recalculateOuterPaddingToDrawBar();
	}
	calculateHorizontalSpace() {
		let e = this.chartConfig.width, t = this.chartConfig.height, n = 0, r = 0, i = 0, a = {
			width: 0,
			height: 0
		}, o = Math.floor(e * this.chartConfig.plotReservedSpacePercent / 100), s = Math.floor(t * this.chartConfig.plotReservedSpacePercent / 100), c = this.componentStore.plot.calculateSpace({
			width: o,
			height: s
		});
		e -= c.width, t -= c.height, c = this.componentStore.title.calculateSpace({
			width: this.chartConfig.width,
			height: t
		}), n = c.height, t -= c.height, this.componentStore.xAxis.setAxisPosition("left"), c = this.componentStore.xAxis.calculateSpace({
			width: e,
			height: t
		}), e -= c.width, r = c.width, this.componentStore.yAxis.setAxisPosition("top"), c = this.componentStore.yAxis.calculateSpace({
			width: e,
			height: t
		}), t -= c.height, i = n + c.height, a = this.componentStore.legend.calculateSpace({
			width: e,
			height: s
		}), e -= a.width, e > 0 && (o += e, e = 0), t > 0 && (s += t, t = 0), this.componentStore.plot.calculateSpace({
			width: o,
			height: s
		}), this.componentStore.plot.setBoundingBoxXY({
			x: r,
			y: i
		}), this.componentStore.legend.setBoundingBoxXY({
			x: r + o,
			y: i + Math.max((s - a.height) / 2, 0)
		}), this.componentStore.yAxis.setRange([r, r + o]), this.componentStore.yAxis.setBoundingBoxXY({
			x: r,
			y: n
		}), this.componentStore.xAxis.setRange([i, i + s]), this.componentStore.xAxis.setBoundingBoxXY({
			x: 0,
			y: i
		}), this.chartData.plots.some((e) => T(e)) && this.componentStore.xAxis.recalculateOuterPaddingToDrawBar();
	}
	calculateSpace() {
		this.chartConfig.chartOrientation === "horizontal" ? this.calculateHorizontalSpace() : this.calculateVerticalSpace();
	}
	getDrawableElement() {
		this.calculateSpace();
		let e = [];
		this.componentStore.plot.setAxes(this.componentStore.xAxis, this.componentStore.yAxis);
		for (let t of Object.values(this.componentStore)) e.push(...t.getDrawableElements());
		return e;
	}
}, x(H, "Orchestrator"), H), U, he = (U = class {
	static build(e, t, n, r) {
		return new me(e, t, n, r).getDrawableElement();
	}
}, x(U, "XYChartBuilder"), U), W = 0, ge, G = Q(), K = Z(), q = _e(), J = K.plotColorPalette.split(",").map((e) => e.trim()), Y = !1, X = !1;
function Z() {
	let e = p(), t = d();
	return i(e.xyChart, t.themeVariables.xyChart);
}
x(Z, "getChartDefaultThemeConfig");
function Q() {
	let e = d();
	return i(c.xyChart, e.xyChart);
}
x(Q, "getChartDefaultConfig");
function _e() {
	return {
		yAxis: {
			type: "linear",
			title: "",
			min: 1 / 0,
			max: -1 / 0
		},
		xAxis: {
			type: "band",
			title: "",
			categories: []
		},
		title: "",
		plots: []
	};
}
x(_e, "getChartDefaultData");
function $(e) {
	let t = d();
	return _(e.trim(), t);
}
x($, "textSanitizer");
function ve(e) {
	ge = e;
}
x(ve, "setTmpSVGG");
function ye(e) {
	e === "horizontal" ? G.chartOrientation = "horizontal" : G.chartOrientation = "vertical";
}
x(ye, "setOrientation");
function be(e) {
	q.xAxis.title = $(e.text);
}
x(be, "setXAxisTitle");
function xe(e, t) {
	q.xAxis = {
		type: "linear",
		title: q.xAxis.title,
		min: e,
		max: t
	}, Y = !0;
}
x(xe, "setXAxisRangeData");
function Se(e) {
	q.xAxis = {
		type: "band",
		title: q.xAxis.title,
		categories: e.map((e) => $(e.text))
	}, Y = !0;
}
x(Se, "setXAxisBand");
function Ce(e) {
	q.yAxis.title = $(e.text);
}
x(Ce, "setYAxisTitle");
function we(e, t) {
	q.yAxis = {
		type: "linear",
		title: q.yAxis.title,
		min: e,
		max: t
	}, X = !0;
}
x(we, "setYAxisRangeData");
function Te(e) {
	let t = Math.min(...e), n = Math.max(...e), r = D(q.yAxis) ? q.yAxis.min : 1 / 0, i = D(q.yAxis) ? q.yAxis.max : -1 / 0;
	q.yAxis = {
		type: "linear",
		title: q.yAxis.title,
		min: Math.min(r, t),
		max: Math.max(i, n)
	};
}
x(Te, "setYAxisRangeFromPlotData");
function Ee(e) {
	let t = [];
	if (e.length === 0) return t;
	if (!Y) {
		let t = D(q.xAxis) ? q.xAxis.min : 1 / 0, n = D(q.xAxis) ? q.xAxis.max : -1 / 0;
		xe(Math.min(t, 1), Math.max(n, e.length));
	}
	if (E(q.xAxis) && e.length > q.xAxis.categories.length && (e = e.slice(0, q.xAxis.categories.length)), X || Te(e), E(q.xAxis) && (t = q.xAxis.categories.map((t, n) => [t, e[n]])), D(q.xAxis)) {
		let n = q.xAxis.min, r = q.xAxis.max;
		if (e.length === 1) t = [[`${n}`, e[0]]];
		else {
			let i = (r - n) / (e.length - 1);
			t = e.map((e, t) => [`${n + t * i}`, e]);
		}
	}
	return t;
}
x(Ee, "transformDataWithoutCategory");
function De(e) {
	return J[e === 0 ? 0 : e % J.length];
}
x(De, "getPlotColorFromPalette");
function Oe(e, t) {
	let n = t.map((e) => e.value), r = t.map((e) => e.label ? $(e.label) : ""), i = Ee(n), a = r.some((e) => e !== "");
	q.plots.push({
		type: "line",
		title: $(e.text),
		strokeFill: De(W),
		strokeWidth: 2,
		data: i,
		...a ? { pointLabels: r } : {}
	}), W++;
}
x(Oe, "setLineData");
function ke(e, t) {
	let n = Ee(t.map((e) => e.value));
	q.plots.push({
		type: "bar",
		title: $(e.text),
		fill: De(W),
		data: n
	}), W++;
}
x(ke, "setBarData");
function Ae() {
	if (q.plots.length === 0) throw Error("No Plot to render, please provide a plot with some data");
	return q.title = f(), he.build(G, q, K, ge);
}
x(Ae, "getDrawableElem");
function je() {
	return K;
}
x(je, "getChartThemeConfig");
function Me() {
	return G;
}
x(Me, "getChartConfig");
function Ne() {
	return q;
}
x(Ne, "getXYChartData");
var Pe = {
	parser: w,
	db: {
		getDrawableElem: Ae,
		clear: /* @__PURE__ */ x(function() {
			a(), W = 0, G = Q(), q = _e(), K = Z(), J = K.plotColorPalette.split(",").map((e) => e.trim()), Y = !1, X = !1;
		}, "clear"),
		setAccTitle: b,
		getAccTitle: u,
		setDiagramTitle: g,
		getDiagramTitle: f,
		getAccDescription: l,
		setAccDescription: y,
		setOrientation: ye,
		setXAxisTitle: be,
		setXAxisRangeData: xe,
		setXAxisBand: Se,
		setYAxisTitle: Ce,
		setYAxisRangeData: we,
		setLineData: Oe,
		setBarData: ke,
		setTmpSVGG: ve,
		getChartThemeConfig: je,
		getChartConfig: Me,
		getXYChartData: Ne
	},
	renderer: { draw: /* @__PURE__ */ x((e, t, n, r) => {
		let i = r.db, a = i.getChartThemeConfig(), o = i.getChartConfig(), c = i.getXYChartData().plots[0].data.map((e) => e[1]);
		function l(e) {
			return e === "top" ? "text-before-edge" : "middle";
		}
		x(l, "getDominantBaseLine");
		function u(e) {
			return e === "left" ? "start" : e === "right" ? "end" : "middle";
		}
		x(u, "getTextAnchor");
		function d(e) {
			return `translate(${e.x}, ${e.y}) rotate(${e.rotation || 0})`;
		}
		x(d, "getTextTransformation"), h.debug("Rendering xychart chart\n" + e);
		let f = v(t), p = f.append("g").attr("class", "main"), m = p.append("rect").attr("width", o.width).attr("height", o.height).attr("class", "background");
		s(f, o.height, o.width, !0), f.attr("viewBox", `0 0 ${o.width} ${o.height}`), m.attr("fill", a.backgroundColor), i.setTmpSVGG(f.append("g").attr("class", "mermaid-tmp-group"));
		let g = i.getDrawableElem(), _ = {};
		function y(e) {
			let t = p, n = "";
			for (let [r] of e.entries()) {
				let i = p;
				r > 0 && _[n] && (i = _[n]), n += e[r], t = _[n], t ||= _[n] = i.append("g").attr("class", e[r]);
			}
			return t;
		}
		x(y, "getGroup");
		for (let e of g) {
			if (e.data.length === 0) continue;
			let t = y(e.groupTexts);
			switch (e.type) {
				case "rect":
					if (t.selectAll("rect").data(e.data).enter().append("rect").attr("x", (e) => e.x).attr("y", (e) => e.y).attr("width", (e) => e.width).attr("height", (e) => e.height).attr("fill", (e) => e.fill).attr("stroke", (e) => e.strokeFill).attr("stroke-width", (e) => e.strokeWidth), o.showDataLabel) {
						let n = o.showDataLabelOutsideBar;
						if (o.chartOrientation === "horizontal") {
							let r = function(e, t) {
								let { data: n, label: r } = e;
								return t * r.length * i <= n.width - o;
							};
							x(r, "fitsHorizontally");
							let i = .7, o = 10, s = e.data.map((e, t) => ({
								data: e,
								label: c[t].toString()
							})).filter((e) => e.data.width > 0 && e.data.height > 0), l = s.map((e) => {
								let { data: t } = e, n = t.height * .7;
								for (; !r(e, n) && n > 0;) --n;
								return n;
							}), u = Math.floor(Math.min(...l)), d = /* @__PURE__ */ x((e) => n ? e.data.x + e.data.width + 10 : e.data.x + e.data.width - 10, "determineLabelXPosition");
							t.selectAll("text").data(s).enter().append("text").attr("x", d).attr("y", (e) => e.data.y + e.data.height / 2).attr("text-anchor", n ? "start" : "end").attr("dominant-baseline", "middle").attr("fill", a.dataLabelColor).attr("font-size", `${u}px`).text((e) => e.label);
						} else {
							let r = function(e, t, n) {
								let { data: r, label: i } = e, a = t * i.length * .7, o = r.x + r.width / 2, s = o - a / 2, c = o + a / 2, l = s >= r.x && c <= r.x + r.width, u = r.y + n + t <= r.y + r.height;
								return l && u;
							};
							x(r, "fitsInBar");
							let i = e.data.map((e, t) => ({
								data: e,
								label: c[t].toString()
							})).filter((e) => e.data.width > 0 && e.data.height > 0), o = i.map((e) => {
								let { data: t, label: n } = e, i = t.width / (n.length * .7);
								for (; !r(e, i, 10) && i > 0;) --i;
								return i;
							}), s = Math.floor(Math.min(...o)), l = /* @__PURE__ */ x((e) => n ? e.data.y - 10 : e.data.y + 10, "determineLabelYPosition");
							t.selectAll("text").data(i).enter().append("text").attr("x", (e) => e.data.x + e.data.width / 2).attr("y", l).attr("text-anchor", "middle").attr("dominant-baseline", n ? "auto" : "hanging").attr("fill", a.dataLabelColor).attr("font-size", `${s}px`).text((e) => e.label);
						}
					}
					break;
				case "text":
					t.selectAll("text").data(e.data).enter().append("text").attr("x", 0).attr("y", 0).attr("fill", (e) => e.fill).attr("font-size", (e) => e.fontSize).attr("dominant-baseline", (e) => l(e.verticalPos)).attr("text-anchor", (e) => u(e.horizontalPos)).attr("transform", (e) => d(e)).text((e) => e.text);
					break;
				case "path": t.selectAll("path").data(e.data).enter().append("path").attr("d", (e) => e.path).attr("fill", (e) => e.fill ? e.fill : "none").attr("stroke", (e) => e.strokeFill).attr("stroke-width", (e) => e.strokeWidth);
			}
		}
	}, "draw") }
};
//#endregion
export { Pe as diagram };

//# sourceMappingURL=xychartDiagram-S5SC5T6Z-Br62ykOR-DnonDtwN.js.map